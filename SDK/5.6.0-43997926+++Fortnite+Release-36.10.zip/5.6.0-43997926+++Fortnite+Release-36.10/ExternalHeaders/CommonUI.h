/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CommonUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "EnhancedInput.h"
#include "SlateCore.h"
#include "Engine.h"
#include "InputCore.h"
#include "GameplayTags.h"
#include "CommonInput.h"
#include "UMG.h"
#include "Slate.h"
#include "CoreUObject.h"
#include "MediaAssets.h"

// Size: 0x28
class UCommonBoundActionButtonInterface : public UInterface
{
public:
};

// Size: 0x660
class UAnalogSlider : public USlider
{
public:
};

// Size: 0x28
class UCommonActionHandlerInterface : public UInterface
{
public:
};

// Size: 0x420
class UCommonActionWidget : public UWidget
{
public:
    FSlateBrush ProgressMaterialBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0xb0, Type: StructProperty)
    FName ProgressMaterialParam() const { return Read<FName>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x4, Type: NameProperty)
    FSlateBrush IconRimBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0xb0, Type: StructProperty)
    TArray<FDataTableRowHandle> InputActions() const { return Read<TArray<FDataTableRowHandle>>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x10, Type: ArrayProperty)
    UInputAction* EnhancedInputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* ProgressDynamicMaterial() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x8, Type: ObjectProperty)
    FSlateBrush Icon() const { return Read<FSlateBrush>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0xb0, Type: StructProperty)

    void SET_ProgressMaterialBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0xb0, Type: StructProperty)
    void SET_ProgressMaterialParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x4, Type: NameProperty)
    void SET_IconRimBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0xb0, Type: StructProperty)
    void SET_InputActions(const TArray<FDataTableRowHandle>& Value) { Write<TArray<FDataTableRowHandle>>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x10, Type: ArrayProperty)
    void SET_EnhancedInputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    void SET_ProgressDynamicMaterial(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x8, Type: ObjectProperty)
    void SET_Icon(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0xb0, Type: StructProperty)
};

// Size: 0x478
class UCommonActivatableWidget : public UCommonUserWidget
{
public:
    bool bIsBackHandler() const { return Read<bool>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x1, Type: BoolProperty)
    bool bIsBackActionDisplayedInActionBar() const { return Read<bool>(uintptr_t(this) + 0x349); } // 0x349 (Size: 0x1, Type: BoolProperty)
    FText OverrideBackActionDisplayName() const { return Read<FText>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x10, Type: TextProperty)
    bool bAutoActivate() const { return Read<bool>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x1, Type: BoolProperty)
    bool bSupportsActivationFocus() const { return Read<bool>(uintptr_t(this) + 0x361); } // 0x361 (Size: 0x1, Type: BoolProperty)
    bool bIsModal() const { return Read<bool>(uintptr_t(this) + 0x362); } // 0x362 (Size: 0x1, Type: BoolProperty)
    bool bAutoRestoreFocus() const { return Read<bool>(uintptr_t(this) + 0x363); } // 0x363 (Size: 0x1, Type: BoolProperty)
    bool bOverrideActionDomain() const { return Read<bool>(uintptr_t(this) + 0x364); } // 0x364 (Size: 0x1, Type: BoolProperty)
    UInputMappingContext* InputMapping() const { return Read<UInputMappingContext*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    int32_t InputMappingPriority() const { return Read<int32_t>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x4, Type: IntProperty)
    TSoftObjectPtr<UCommonInputActionDomain> ActionDomainOverride() const { return Read<TSoftObjectPtr<UCommonInputActionDomain>>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x20, Type: SoftObjectProperty)
    bool bIsActive() const { return Read<bool>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x1, Type: BoolProperty)
    TArray<TWeakObjectPtr<UCommonActivatableWidget*>> VisibilityBoundWidgets() const { return Read<TArray<TWeakObjectPtr<UCommonActivatableWidget*>>>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x10, Type: ArrayProperty)
    bool bSetVisibilityOnActivated() const { return Read<bool>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x1, Type: BoolProperty)
    uint8_t ActivatedVisibility() const { return Read<uint8_t>(uintptr_t(this) + 0x471); } // 0x471 (Size: 0x1, Type: EnumProperty)
    bool bSetVisibilityOnDeactivated() const { return Read<bool>(uintptr_t(this) + 0x472); } // 0x472 (Size: 0x1, Type: BoolProperty)
    uint8_t DeactivatedVisibility() const { return Read<uint8_t>(uintptr_t(this) + 0x473); } // 0x473 (Size: 0x1, Type: EnumProperty)

    void SET_bIsBackHandler(const bool& Value) { Write<bool>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x1, Type: BoolProperty)
    void SET_bIsBackActionDisplayedInActionBar(const bool& Value) { Write<bool>(uintptr_t(this) + 0x349, Value); } // 0x349 (Size: 0x1, Type: BoolProperty)
    void SET_OverrideBackActionDisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x10, Type: TextProperty)
    void SET_bAutoActivate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x1, Type: BoolProperty)
    void SET_bSupportsActivationFocus(const bool& Value) { Write<bool>(uintptr_t(this) + 0x361, Value); } // 0x361 (Size: 0x1, Type: BoolProperty)
    void SET_bIsModal(const bool& Value) { Write<bool>(uintptr_t(this) + 0x362, Value); } // 0x362 (Size: 0x1, Type: BoolProperty)
    void SET_bAutoRestoreFocus(const bool& Value) { Write<bool>(uintptr_t(this) + 0x363, Value); } // 0x363 (Size: 0x1, Type: BoolProperty)
    void SET_bOverrideActionDomain(const bool& Value) { Write<bool>(uintptr_t(this) + 0x364, Value); } // 0x364 (Size: 0x1, Type: BoolProperty)
    void SET_InputMapping(const UInputMappingContext*& Value) { Write<UInputMappingContext*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_InputMappingPriority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x4, Type: IntProperty)
    void SET_ActionDomainOverride(const TSoftObjectPtr<UCommonInputActionDomain>& Value) { Write<TSoftObjectPtr<UCommonInputActionDomain>>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x20, Type: SoftObjectProperty)
    void SET_bIsActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x1, Type: BoolProperty)
    void SET_VisibilityBoundWidgets(const TArray<TWeakObjectPtr<UCommonActivatableWidget*>>& Value) { Write<TArray<TWeakObjectPtr<UCommonActivatableWidget*>>>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x10, Type: ArrayProperty)
    void SET_bSetVisibilityOnActivated(const bool& Value) { Write<bool>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x1, Type: BoolProperty)
    void SET_ActivatedVisibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x471, Value); } // 0x471 (Size: 0x1, Type: EnumProperty)
    void SET_bSetVisibilityOnDeactivated(const bool& Value) { Write<bool>(uintptr_t(this) + 0x472, Value); } // 0x472 (Size: 0x1, Type: BoolProperty)
    void SET_DeactivatedVisibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x473, Value); } // 0x473 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x348
class UCommonUserWidget : public UUserWidget
{
public:
    bool bDisplayInActionBar() const { return Read<bool>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x1, Type: BoolProperty)
    bool bConsumePointerInput() const { return Read<bool>(uintptr_t(this) + 0x321); } // 0x321 (Size: 0x1, Type: BoolProperty)

    void SET_bDisplayInActionBar(const bool& Value) { Write<bool>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x1, Type: BoolProperty)
    void SET_bConsumePointerInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x321, Value); } // 0x321 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x220
class UCommonActivatableWidgetSwitcher : public UCommonAnimatedSwitcher
{
public:
    bool bClearFocusRestorationTargetOfDeactivatedWidgets() const { return Read<bool>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x1, Type: BoolProperty)

    void SET_bClearFocusRestorationTargetOfDeactivatedWidgets(const bool& Value) { Write<bool>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x210
class UCommonAnimatedSwitcher : public UWidgetSwitcher
{
public:
    uint8_t TransitionType() const { return Read<uint8_t>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x1, Type: EnumProperty)
    uint8_t TransitionCurveType() const { return Read<uint8_t>(uintptr_t(this) + 0x1c9); } // 0x1c9 (Size: 0x1, Type: EnumProperty)
    float TransitionDuration() const { return Read<float>(uintptr_t(this) + 0x1cc); } // 0x1cc (Size: 0x4, Type: FloatProperty)
    uint8_t TransitionFallbackStrategy() const { return Read<uint8_t>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x1, Type: EnumProperty)

    void SET_TransitionType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x1, Type: EnumProperty)
    void SET_TransitionCurveType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1c9, Value); } // 0x1c9 (Size: 0x1, Type: EnumProperty)
    void SET_TransitionDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x1cc, Value); } // 0x1cc (Size: 0x4, Type: FloatProperty)
    void SET_TransitionFallbackStrategy(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x1, Type: EnumProperty)
};

// Size: 0xe0
class UCommonBorderStyle : public UObject
{
public:
    FSlateBrush Background() const { return Read<FSlateBrush>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0xb0, Type: StructProperty)

    void SET_Background(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0xb0, Type: StructProperty)
};

// Size: 0x2f0
class UCommonBorder : public UBorder
{
public:
    UClass* Style() const { return Read<UClass*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ClassProperty)
    bool bReducePaddingBySafezone() const { return Read<bool>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x1, Type: BoolProperty)
    FMargin MinimumPadding() const { return Read<FMargin>(uintptr_t(this) + 0x2dc); } // 0x2dc (Size: 0x10, Type: StructProperty)

    void SET_Style(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ClassProperty)
    void SET_bReducePaddingBySafezone(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x1, Type: BoolProperty)
    void SET_MinimumPadding(const FMargin& Value) { Write<FMargin>(uintptr_t(this) + 0x2dc, Value); } // 0x2dc (Size: 0x10, Type: StructProperty)
};

// Size: 0x710
class UCommonButtonStyle : public UObject
{
public:
    bool bSingleMaterial() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    FSlateBrush SingleMaterialBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0xb0, Type: StructProperty)
    FSlateBrush NormalBase() const { return Read<FSlateBrush>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0xb0, Type: StructProperty)
    FSlateBrush NormalHovered() const { return Read<FSlateBrush>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0xb0, Type: StructProperty)
    FSlateBrush NormalPressed() const { return Read<FSlateBrush>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0xb0, Type: StructProperty)
    FSlateBrush SelectedBase() const { return Read<FSlateBrush>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0xb0, Type: StructProperty)
    FSlateBrush SelectedHovered() const { return Read<FSlateBrush>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0xb0, Type: StructProperty)
    FSlateBrush SelectedPressed() const { return Read<FSlateBrush>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0xb0, Type: StructProperty)
    FSlateBrush Disabled() const { return Read<FSlateBrush>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0xb0, Type: StructProperty)
    FMargin ButtonPadding() const { return Read<FMargin>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x10, Type: StructProperty)
    FMargin CustomPadding() const { return Read<FMargin>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x10, Type: StructProperty)
    int32_t MinWidth() const { return Read<int32_t>(uintptr_t(this) + 0x5d0); } // 0x5d0 (Size: 0x4, Type: IntProperty)
    int32_t MinHeight() const { return Read<int32_t>(uintptr_t(this) + 0x5d4); } // 0x5d4 (Size: 0x4, Type: IntProperty)
    int32_t MaxWidth() const { return Read<int32_t>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x4, Type: IntProperty)
    int32_t MaxHeight() const { return Read<int32_t>(uintptr_t(this) + 0x5dc); } // 0x5dc (Size: 0x4, Type: IntProperty)
    UClass* NormalTextStyle() const { return Read<UClass*>(uintptr_t(this) + 0x5e0); } // 0x5e0 (Size: 0x8, Type: ClassProperty)
    UClass* NormalHoveredTextStyle() const { return Read<UClass*>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x8, Type: ClassProperty)
    UClass* SelectedTextStyle() const { return Read<UClass*>(uintptr_t(this) + 0x5f0); } // 0x5f0 (Size: 0x8, Type: ClassProperty)
    UClass* SelectedHoveredTextStyle() const { return Read<UClass*>(uintptr_t(this) + 0x5f8); } // 0x5f8 (Size: 0x8, Type: ClassProperty)
    UClass* DisabledTextStyle() const { return Read<UClass*>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x8, Type: ClassProperty)
    FSlateSound PressedSlateSound() const { return Read<FSlateSound>(uintptr_t(this) + 0x608); } // 0x608 (Size: 0x18, Type: StructProperty)
    FSlateSound ClickedSlateSound() const { return Read<FSlateSound>(uintptr_t(this) + 0x620); } // 0x620 (Size: 0x18, Type: StructProperty)
    FCommonButtonStyleOptionalSlateSound SelectedPressedSlateSound() const { return Read<FCommonButtonStyleOptionalSlateSound>(uintptr_t(this) + 0x638); } // 0x638 (Size: 0x20, Type: StructProperty)
    FCommonButtonStyleOptionalSlateSound SelectedClickedSlateSound() const { return Read<FCommonButtonStyleOptionalSlateSound>(uintptr_t(this) + 0x658); } // 0x658 (Size: 0x20, Type: StructProperty)
    FCommonButtonStyleOptionalSlateSound LockedPressedSlateSound() const { return Read<FCommonButtonStyleOptionalSlateSound>(uintptr_t(this) + 0x678); } // 0x678 (Size: 0x20, Type: StructProperty)
    FCommonButtonStyleOptionalSlateSound LockedClickedSlateSound() const { return Read<FCommonButtonStyleOptionalSlateSound>(uintptr_t(this) + 0x698); } // 0x698 (Size: 0x20, Type: StructProperty)
    FSlateSound HoveredSlateSound() const { return Read<FSlateSound>(uintptr_t(this) + 0x6b8); } // 0x6b8 (Size: 0x18, Type: StructProperty)
    FCommonButtonStyleOptionalSlateSound SelectedHoveredSlateSound() const { return Read<FCommonButtonStyleOptionalSlateSound>(uintptr_t(this) + 0x6d0); } // 0x6d0 (Size: 0x20, Type: StructProperty)
    FCommonButtonStyleOptionalSlateSound LockedHoveredSlateSound() const { return Read<FCommonButtonStyleOptionalSlateSound>(uintptr_t(this) + 0x6f0); } // 0x6f0 (Size: 0x20, Type: StructProperty)

    void SET_bSingleMaterial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_SingleMaterialBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0xb0, Type: StructProperty)
    void SET_NormalBase(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0xb0, Type: StructProperty)
    void SET_NormalHovered(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0xb0, Type: StructProperty)
    void SET_NormalPressed(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0xb0, Type: StructProperty)
    void SET_SelectedBase(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0xb0, Type: StructProperty)
    void SET_SelectedHovered(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0xb0, Type: StructProperty)
    void SET_SelectedPressed(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0xb0, Type: StructProperty)
    void SET_Disabled(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0xb0, Type: StructProperty)
    void SET_ButtonPadding(const FMargin& Value) { Write<FMargin>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x10, Type: StructProperty)
    void SET_CustomPadding(const FMargin& Value) { Write<FMargin>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x10, Type: StructProperty)
    void SET_MinWidth(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5d0, Value); } // 0x5d0 (Size: 0x4, Type: IntProperty)
    void SET_MinHeight(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5d4, Value); } // 0x5d4 (Size: 0x4, Type: IntProperty)
    void SET_MaxWidth(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x4, Type: IntProperty)
    void SET_MaxHeight(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5dc, Value); } // 0x5dc (Size: 0x4, Type: IntProperty)
    void SET_NormalTextStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x5e0, Value); } // 0x5e0 (Size: 0x8, Type: ClassProperty)
    void SET_NormalHoveredTextStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x8, Type: ClassProperty)
    void SET_SelectedTextStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x5f0, Value); } // 0x5f0 (Size: 0x8, Type: ClassProperty)
    void SET_SelectedHoveredTextStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x5f8, Value); } // 0x5f8 (Size: 0x8, Type: ClassProperty)
    void SET_DisabledTextStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x8, Type: ClassProperty)
    void SET_PressedSlateSound(const FSlateSound& Value) { Write<FSlateSound>(uintptr_t(this) + 0x608, Value); } // 0x608 (Size: 0x18, Type: StructProperty)
    void SET_ClickedSlateSound(const FSlateSound& Value) { Write<FSlateSound>(uintptr_t(this) + 0x620, Value); } // 0x620 (Size: 0x18, Type: StructProperty)
    void SET_SelectedPressedSlateSound(const FCommonButtonStyleOptionalSlateSound& Value) { Write<FCommonButtonStyleOptionalSlateSound>(uintptr_t(this) + 0x638, Value); } // 0x638 (Size: 0x20, Type: StructProperty)
    void SET_SelectedClickedSlateSound(const FCommonButtonStyleOptionalSlateSound& Value) { Write<FCommonButtonStyleOptionalSlateSound>(uintptr_t(this) + 0x658, Value); } // 0x658 (Size: 0x20, Type: StructProperty)
    void SET_LockedPressedSlateSound(const FCommonButtonStyleOptionalSlateSound& Value) { Write<FCommonButtonStyleOptionalSlateSound>(uintptr_t(this) + 0x678, Value); } // 0x678 (Size: 0x20, Type: StructProperty)
    void SET_LockedClickedSlateSound(const FCommonButtonStyleOptionalSlateSound& Value) { Write<FCommonButtonStyleOptionalSlateSound>(uintptr_t(this) + 0x698, Value); } // 0x698 (Size: 0x20, Type: StructProperty)
    void SET_HoveredSlateSound(const FSlateSound& Value) { Write<FSlateSound>(uintptr_t(this) + 0x6b8, Value); } // 0x6b8 (Size: 0x18, Type: StructProperty)
    void SET_SelectedHoveredSlateSound(const FCommonButtonStyleOptionalSlateSound& Value) { Write<FCommonButtonStyleOptionalSlateSound>(uintptr_t(this) + 0x6d0, Value); } // 0x6d0 (Size: 0x20, Type: StructProperty)
    void SET_LockedHoveredSlateSound(const FCommonButtonStyleOptionalSlateSound& Value) { Write<FCommonButtonStyleOptionalSlateSound>(uintptr_t(this) + 0x6f0, Value); } // 0x6f0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x600
class UCommonButtonInternalBase : public UButton
{
public:
    int32_t MinWidth() const { return Read<int32_t>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x4, Type: IntProperty)
    int32_t MinHeight() const { return Read<int32_t>(uintptr_t(this) + 0x5cc); } // 0x5cc (Size: 0x4, Type: IntProperty)
    int32_t MaxWidth() const { return Read<int32_t>(uintptr_t(this) + 0x5d0); } // 0x5d0 (Size: 0x4, Type: IntProperty)
    int32_t MaxHeight() const { return Read<int32_t>(uintptr_t(this) + 0x5d4); } // 0x5d4 (Size: 0x4, Type: IntProperty)
    bool bButtonEnabled() const { return Read<bool>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x1, Type: BoolProperty)
    bool bInteractionEnabled() const { return Read<bool>(uintptr_t(this) + 0x5d9); } // 0x5d9 (Size: 0x1, Type: BoolProperty)

    void SET_MinWidth(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x4, Type: IntProperty)
    void SET_MinHeight(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5cc, Value); } // 0x5cc (Size: 0x4, Type: IntProperty)
    void SET_MaxWidth(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5d0, Value); } // 0x5d0 (Size: 0x4, Type: IntProperty)
    void SET_MaxHeight(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5d4, Value); } // 0x5d4 (Size: 0x4, Type: IntProperty)
    void SET_bButtonEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x1, Type: BoolProperty)
    void SET_bInteractionEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5d9, Value); } // 0x5d9 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1510
class UCommonButtonBase : public UCommonUserWidget
{
public:
    FWidgetEventField ClickEvent() const { return Read<FWidgetEventField>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x1, Type: StructProperty)
    int32_t MinWidth() const { return Read<int32_t>(uintptr_t(this) + 0x34c); } // 0x34c (Size: 0x4, Type: IntProperty)
    int32_t MinHeight() const { return Read<int32_t>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x4, Type: IntProperty)
    int32_t MaxWidth() const { return Read<int32_t>(uintptr_t(this) + 0x354); } // 0x354 (Size: 0x4, Type: IntProperty)
    int32_t MaxHeight() const { return Read<int32_t>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x4, Type: IntProperty)
    UClass* Style() const { return Read<UClass*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ClassProperty)
    bool bHideInputAction() const { return Read<bool>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x1, Type: BoolProperty)
    FSlateSound PressedSlateSoundOverride() const { return Read<FSlateSound>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x18, Type: StructProperty)
    FSlateSound ClickedSlateSoundOverride() const { return Read<FSlateSound>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x18, Type: StructProperty)
    FSlateSound HoveredSlateSoundOverride() const { return Read<FSlateSound>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x18, Type: StructProperty)
    FSlateSound SelectedPressedSlateSoundOverride() const { return Read<FSlateSound>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x18, Type: StructProperty)
    FSlateSound SelectedClickedSlateSoundOverride() const { return Read<FSlateSound>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x18, Type: StructProperty)
    FSlateSound SelectedHoveredSlateSoundOverride() const { return Read<FSlateSound>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x18, Type: StructProperty)
    FSlateSound LockedPressedSlateSoundOverride() const { return Read<FSlateSound>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x18, Type: StructProperty)
    FSlateSound LockedClickedSlateSoundOverride() const { return Read<FSlateSound>(uintptr_t(this) + 0x418); } // 0x418 (Size: 0x18, Type: StructProperty)
    FSlateSound LockedHoveredSlateSoundOverride() const { return Read<FSlateSound>(uintptr_t(this) + 0x430); } // 0x430 (Size: 0x18, Type: StructProperty)
    bool bApplyAlphaOnDisable() const { return (Read<uint8_t>(uintptr_t(this) + 0x448) >> 0x0) & 1; } // 0x448:0 (Size: 0x1, Type: BoolProperty)
    bool bLocked() const { return (Read<uint8_t>(uintptr_t(this) + 0x448) >> 0x1) & 1; } // 0x448:1 (Size: 0x1, Type: BoolProperty)
    bool bSelectable() const { return (Read<uint8_t>(uintptr_t(this) + 0x448) >> 0x2) & 1; } // 0x448:2 (Size: 0x1, Type: BoolProperty)
    bool bShouldSelectUponReceivingFocus() const { return (Read<uint8_t>(uintptr_t(this) + 0x448) >> 0x3) & 1; } // 0x448:3 (Size: 0x1, Type: BoolProperty)
    bool bInteractableWhenSelected() const { return (Read<uint8_t>(uintptr_t(this) + 0x448) >> 0x4) & 1; } // 0x448:4 (Size: 0x1, Type: BoolProperty)
    bool bToggleable() const { return (Read<uint8_t>(uintptr_t(this) + 0x448) >> 0x5) & 1; } // 0x448:5 (Size: 0x1, Type: BoolProperty)
    bool bTriggerClickedAfterSelection() const { return (Read<uint8_t>(uintptr_t(this) + 0x448) >> 0x6) & 1; } // 0x448:6 (Size: 0x1, Type: BoolProperty)
    bool bDisplayInputActionWhenNotInteractable() const { return (Read<uint8_t>(uintptr_t(this) + 0x448) >> 0x7) & 1; } // 0x448:7 (Size: 0x1, Type: BoolProperty)
    bool bHideInputActionWithKeyboard() const { return (Read<uint8_t>(uintptr_t(this) + 0x449) >> 0x0) & 1; } // 0x449:0 (Size: 0x1, Type: BoolProperty)
    bool bShouldUseFallbackDefaultInputAction() const { return (Read<uint8_t>(uintptr_t(this) + 0x449) >> 0x1) & 1; } // 0x449:1 (Size: 0x1, Type: BoolProperty)
    bool bRequiresHold() const { return (Read<uint8_t>(uintptr_t(this) + 0x449) >> 0x2) & 1; } // 0x449:2 (Size: 0x1, Type: BoolProperty)
    UClass* HoldData() const { return Read<UClass*>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x8, Type: ClassProperty)
    bool bSimulateHoverOnTouchInput() const { return Read<bool>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EButtonClickMethod> ClickMethod() const { return Read<TEnumAsByte<EButtonClickMethod>>(uintptr_t(this) + 0x45a); } // 0x45a (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EButtonTouchMethod> TouchMethod() const { return Read<TEnumAsByte<EButtonTouchMethod>>(uintptr_t(this) + 0x45b); } // 0x45b (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EButtonPressMethod> PressMethod() const { return Read<TEnumAsByte<EButtonPressMethod>>(uintptr_t(this) + 0x45c); } // 0x45c (Size: 0x1, Type: ByteProperty)
    int32_t InputPriority() const { return Read<int32_t>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x4, Type: IntProperty)
    FDataTableRowHandle TriggeringInputAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x10, Type: StructProperty)
    UInputAction* TriggeringEnhancedInputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    bool bNavigateToNextWidgetOnDisable() const { return (Read<uint8_t>(uintptr_t(this) + 0x490) >> 0x0) & 1; } // 0x490:0 (Size: 0x1, Type: BoolProperty)
    bool bIsPersistentBinding() const { return Read<bool>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x1, Type: BoolProperty)
    uint8_t InputModeOverride() const { return Read<uint8_t>(uintptr_t(this) + 0x581); } // 0x581 (Size: 0x1, Type: EnumProperty)
    UMaterialInstanceDynamic* SingleMaterialStyleMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    FButtonStyle NormalStyle() const { return Read<FButtonStyle>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x390, Type: StructProperty)
    FButtonStyle SelectedStyle() const { return Read<FButtonStyle>(uintptr_t(this) + 0x940); } // 0x940 (Size: 0x390, Type: StructProperty)
    FButtonStyle DisabledStyle() const { return Read<FButtonStyle>(uintptr_t(this) + 0xcd0); } // 0xcd0 (Size: 0x390, Type: StructProperty)
    FButtonStyle LockedStyle() const { return Read<FButtonStyle>(uintptr_t(this) + 0x1060); } // 0x1060 (Size: 0x390, Type: StructProperty)
    bool bStopDoubleClickPropagation() const { return (Read<uint8_t>(uintptr_t(this) + 0x13f0) >> 0x0) & 1; } // 0x13f0:0 (Size: 0x1, Type: BoolProperty)
    UCommonActionWidget* InputActionWidget() const { return Read<UCommonActionWidget*>(uintptr_t(this) + 0x1508); } // 0x1508 (Size: 0x8, Type: ObjectProperty)

    void SET_ClickEvent(const FWidgetEventField& Value) { Write<FWidgetEventField>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x1, Type: StructProperty)
    void SET_MinWidth(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x34c, Value); } // 0x34c (Size: 0x4, Type: IntProperty)
    void SET_MinHeight(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x4, Type: IntProperty)
    void SET_MaxWidth(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x354, Value); } // 0x354 (Size: 0x4, Type: IntProperty)
    void SET_MaxHeight(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x4, Type: IntProperty)
    void SET_Style(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ClassProperty)
    void SET_bHideInputAction(const bool& Value) { Write<bool>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x1, Type: BoolProperty)
    void SET_PressedSlateSoundOverride(const FSlateSound& Value) { Write<FSlateSound>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x18, Type: StructProperty)
    void SET_ClickedSlateSoundOverride(const FSlateSound& Value) { Write<FSlateSound>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x18, Type: StructProperty)
    void SET_HoveredSlateSoundOverride(const FSlateSound& Value) { Write<FSlateSound>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x18, Type: StructProperty)
    void SET_SelectedPressedSlateSoundOverride(const FSlateSound& Value) { Write<FSlateSound>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x18, Type: StructProperty)
    void SET_SelectedClickedSlateSoundOverride(const FSlateSound& Value) { Write<FSlateSound>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x18, Type: StructProperty)
    void SET_SelectedHoveredSlateSoundOverride(const FSlateSound& Value) { Write<FSlateSound>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x18, Type: StructProperty)
    void SET_LockedPressedSlateSoundOverride(const FSlateSound& Value) { Write<FSlateSound>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x18, Type: StructProperty)
    void SET_LockedClickedSlateSoundOverride(const FSlateSound& Value) { Write<FSlateSound>(uintptr_t(this) + 0x418, Value); } // 0x418 (Size: 0x18, Type: StructProperty)
    void SET_LockedHoveredSlateSoundOverride(const FSlateSound& Value) { Write<FSlateSound>(uintptr_t(this) + 0x430, Value); } // 0x430 (Size: 0x18, Type: StructProperty)
    void SET_bApplyAlphaOnDisable(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x448); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x448, B); } // 0x448:0 (Size: 0x1, Type: BoolProperty)
    void SET_bLocked(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x448); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x448, B); } // 0x448:1 (Size: 0x1, Type: BoolProperty)
    void SET_bSelectable(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x448); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x448, B); } // 0x448:2 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldSelectUponReceivingFocus(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x448); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x448, B); } // 0x448:3 (Size: 0x1, Type: BoolProperty)
    void SET_bInteractableWhenSelected(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x448); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x448, B); } // 0x448:4 (Size: 0x1, Type: BoolProperty)
    void SET_bToggleable(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x448); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x448, B); } // 0x448:5 (Size: 0x1, Type: BoolProperty)
    void SET_bTriggerClickedAfterSelection(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x448); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x448, B); } // 0x448:6 (Size: 0x1, Type: BoolProperty)
    void SET_bDisplayInputActionWhenNotInteractable(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x448); B = (B & ~(1 << 0x7)) | (Value << 0x7); Write<uint8_t>(uintptr_t(this) + 0x448, B); } // 0x448:7 (Size: 0x1, Type: BoolProperty)
    void SET_bHideInputActionWithKeyboard(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x449); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x449, B); } // 0x449:0 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldUseFallbackDefaultInputAction(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x449); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x449, B); } // 0x449:1 (Size: 0x1, Type: BoolProperty)
    void SET_bRequiresHold(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x449); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x449, B); } // 0x449:2 (Size: 0x1, Type: BoolProperty)
    void SET_HoldData(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x8, Type: ClassProperty)
    void SET_bSimulateHoverOnTouchInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x1, Type: BoolProperty)
    void SET_ClickMethod(const TEnumAsByte<EButtonClickMethod>& Value) { Write<TEnumAsByte<EButtonClickMethod>>(uintptr_t(this) + 0x45a, Value); } // 0x45a (Size: 0x1, Type: ByteProperty)
    void SET_TouchMethod(const TEnumAsByte<EButtonTouchMethod>& Value) { Write<TEnumAsByte<EButtonTouchMethod>>(uintptr_t(this) + 0x45b, Value); } // 0x45b (Size: 0x1, Type: ByteProperty)
    void SET_PressMethod(const TEnumAsByte<EButtonPressMethod>& Value) { Write<TEnumAsByte<EButtonPressMethod>>(uintptr_t(this) + 0x45c, Value); } // 0x45c (Size: 0x1, Type: ByteProperty)
    void SET_InputPriority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x4, Type: IntProperty)
    void SET_TriggeringInputAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x10, Type: StructProperty)
    void SET_TriggeringEnhancedInputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    void SET_bNavigateToNextWidgetOnDisable(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x490); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x490, B); } // 0x490:0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsPersistentBinding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x1, Type: BoolProperty)
    void SET_InputModeOverride(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x581, Value); } // 0x581 (Size: 0x1, Type: EnumProperty)
    void SET_SingleMaterialStyleMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    void SET_NormalStyle(const FButtonStyle& Value) { Write<FButtonStyle>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x390, Type: StructProperty)
    void SET_SelectedStyle(const FButtonStyle& Value) { Write<FButtonStyle>(uintptr_t(this) + 0x940, Value); } // 0x940 (Size: 0x390, Type: StructProperty)
    void SET_DisabledStyle(const FButtonStyle& Value) { Write<FButtonStyle>(uintptr_t(this) + 0xcd0, Value); } // 0xcd0 (Size: 0x390, Type: StructProperty)
    void SET_LockedStyle(const FButtonStyle& Value) { Write<FButtonStyle>(uintptr_t(this) + 0x1060, Value); } // 0x1060 (Size: 0x390, Type: StructProperty)
    void SET_bStopDoubleClickPropagation(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x13f0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x13f0, B); } // 0x13f0:0 (Size: 0x1, Type: BoolProperty)
    void SET_InputActionWidget(const UCommonActionWidget*& Value) { Write<UCommonActionWidget*>(uintptr_t(this) + 0x1508, Value); } // 0x1508 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UWidgetLockedStateRegistration : public UWidgetBinaryStateRegistration
{
public:
};

// Size: 0x2e0
class UCommonCustomNavigation : public UBorder
{
public:
};

// Size: 0x3a0
class UCommonDateTimeTextBlock : public UCommonTextBlock
{
public:
    FText CustomTimespanFormat() const { return Read<FText>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x10, Type: TextProperty)
    bool bCustomTimespanLeadingZeros() const { return Read<bool>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x1, Type: BoolProperty)

    void SET_CustomTimespanFormat(const FText& Value) { Write<FText>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x10, Type: TextProperty)
    void SET_bCustomTimespanLeadingZeros(const bool& Value) { Write<bool>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x330
class UCommonTextBlock : public UTextBlock
{
public:
    float MobileFontSizeMultiplier() const { return Read<float>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x4, Type: FloatProperty)
    bool bIsScrollingEnabled() const { return Read<bool>(uintptr_t(this) + 0x304); } // 0x304 (Size: 0x1, Type: BoolProperty)
    bool bDisplayAllCaps() const { return Read<bool>(uintptr_t(this) + 0x305); } // 0x305 (Size: 0x1, Type: BoolProperty)
    bool bAutoCollapseWithEmptyText() const { return Read<bool>(uintptr_t(this) + 0x306); } // 0x306 (Size: 0x1, Type: BoolProperty)
    UClass* Style() const { return Read<UClass*>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: ClassProperty)
    UClass* ScrollStyle() const { return Read<UClass*>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EOrientation> ScrollOrientation() const { return Read<TEnumAsByte<EOrientation>>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x1, Type: ByteProperty)

    void SET_MobileFontSizeMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x4, Type: FloatProperty)
    void SET_bIsScrollingEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x304, Value); } // 0x304 (Size: 0x1, Type: BoolProperty)
    void SET_bDisplayAllCaps(const bool& Value) { Write<bool>(uintptr_t(this) + 0x305, Value); } // 0x305 (Size: 0x1, Type: BoolProperty)
    void SET_bAutoCollapseWithEmptyText(const bool& Value) { Write<bool>(uintptr_t(this) + 0x306, Value); } // 0x306 (Size: 0x1, Type: BoolProperty)
    void SET_Style(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: ClassProperty)
    void SET_ScrollStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x8, Type: ClassProperty)
    void SET_ScrollOrientation(const TEnumAsByte<EOrientation>& Value) { Write<TEnumAsByte<EOrientation>>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x3f8
class UCommonGameViewportClient : public UGameViewportClient
{
public:
};

// Size: 0x340
class UCommonHardwareVisibilityBorder : public UCommonBorder
{
public:
    FGameplayTagQuery VisibilityQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x48, Type: StructProperty)
    uint8_t VisibleType() const { return Read<uint8_t>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x1, Type: EnumProperty)
    uint8_t HiddenType() const { return Read<uint8_t>(uintptr_t(this) + 0x339); } // 0x339 (Size: 0x1, Type: EnumProperty)

    void SET_VisibilityQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x48, Type: StructProperty)
    void SET_VisibleType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x1, Type: EnumProperty)
    void SET_HiddenType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x339, Value); } // 0x339 (Size: 0x1, Type: EnumProperty)
};

// Size: 0xb80
class UCommonHierarchicalScrollBox : public UScrollBox
{
public:
};

// Size: 0x420
class UCommonLazyImage : public UImage
{
public:
    FSlateBrush LoadingBackgroundBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0xb0, Type: StructProperty)
    FSlateBrush LoadingThrobberBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0xb0, Type: StructProperty)
    FName MaterialTextureParamName() const { return Read<FName>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x4, Type: NameProperty)

    void SET_LoadingBackgroundBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0xb0, Type: StructProperty)
    void SET_LoadingThrobberBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0xb0, Type: StructProperty)
    void SET_MaterialTextureParamName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x4, Type: NameProperty)
};

// Size: 0x340
class UCommonLazyWidget : public UWidget
{
public:
    FSlateBrush LoadingThrobberBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0xb0, Type: StructProperty)
    FSlateBrush LoadingBackgroundBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0xb0, Type: StructProperty)
    UUserWidget* Content() const { return Read<UUserWidget*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)

    void SET_LoadingThrobberBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0xb0, Type: StructProperty)
    void SET_LoadingBackgroundBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0xb0, Type: StructProperty)
    void SET_Content(const UUserWidget*& Value) { Write<UUserWidget*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xb60
class UCommonListView : public UListView
{
public:
};

// Size: 0x60
class ULoadGuardSlot : public UPanelSlot
{
public:
    FMargin Padding() const { return Read<FMargin>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    TEnumAsByte<EHorizontalAlignment> HorizontalAlignment() const { return Read<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EVerticalAlignment> VerticalAlignment() const { return Read<TEnumAsByte<EVerticalAlignment>>(uintptr_t(this) + 0x49); } // 0x49 (Size: 0x1, Type: ByteProperty)

    void SET_Padding(const FMargin& Value) { Write<FMargin>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_HorizontalAlignment(const TEnumAsByte<EHorizontalAlignment>& Value) { Write<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: ByteProperty)
    void SET_VerticalAlignment(const TEnumAsByte<EVerticalAlignment>& Value) { Write<TEnumAsByte<EVerticalAlignment>>(uintptr_t(this) + 0x49, Value); } // 0x49 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x350
class UCommonLoadGuard : public UContentWidget
{
public:
    FSlateBrush LoadingBackgroundBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0xb0, Type: StructProperty)
    FSlateBrush LoadingThrobberBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0xb0, Type: StructProperty)
    TEnumAsByte<EHorizontalAlignment> ThrobberAlignment() const { return Read<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x1, Type: ByteProperty)
    FMargin ThrobberPadding() const { return Read<FMargin>(uintptr_t(this) + 0x2d4); } // 0x2d4 (Size: 0x10, Type: StructProperty)
    FText LoadingText() const { return Read<FText>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x10, Type: TextProperty)
    UClass* TextStyle() const { return Read<UClass*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ClassProperty)
    FSoftObjectPath SpinnerMaterialPath() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x18, Type: StructProperty)

    void SET_LoadingBackgroundBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0xb0, Type: StructProperty)
    void SET_LoadingThrobberBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0xb0, Type: StructProperty)
    void SET_ThrobberAlignment(const TEnumAsByte<EHorizontalAlignment>& Value) { Write<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x1, Type: ByteProperty)
    void SET_ThrobberPadding(const FMargin& Value) { Write<FMargin>(uintptr_t(this) + 0x2d4, Value); } // 0x2d4 (Size: 0x10, Type: StructProperty)
    void SET_LoadingText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x10, Type: TextProperty)
    void SET_TextStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ClassProperty)
    void SET_SpinnerMaterialPath(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x18, Type: StructProperty)
};

// Size: 0x3d0
class UCommonNumericTextBlock : public UCommonTextBlock
{
public:
    float CurrentNumericValue() const { return Read<float>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x4, Type: FloatProperty)
    uint8_t NumericType() const { return Read<uint8_t>(uintptr_t(this) + 0x374); } // 0x374 (Size: 0x1, Type: EnumProperty)
    FCommonNumberFormattingOptions FormattingSpecification() const { return Read<FCommonNumberFormattingOptions>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x14, Type: StructProperty)
    float EaseOutInterpolationExponent() const { return Read<float>(uintptr_t(this) + 0x38c); } // 0x38c (Size: 0x4, Type: FloatProperty)
    float InterpolationUpdateInterval() const { return Read<float>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x4, Type: FloatProperty)
    float PostInterpolationShrinkDuration() const { return Read<float>(uintptr_t(this) + 0x394); } // 0x394 (Size: 0x4, Type: FloatProperty)
    bool PerformSizeInterpolation() const { return Read<bool>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x1, Type: BoolProperty)
    bool IsPercentage() const { return Read<bool>(uintptr_t(this) + 0x399); } // 0x399 (Size: 0x1, Type: BoolProperty)

    void SET_CurrentNumericValue(const float& Value) { Write<float>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x4, Type: FloatProperty)
    void SET_NumericType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x374, Value); } // 0x374 (Size: 0x1, Type: EnumProperty)
    void SET_FormattingSpecification(const FCommonNumberFormattingOptions& Value) { Write<FCommonNumberFormattingOptions>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x14, Type: StructProperty)
    void SET_EaseOutInterpolationExponent(const float& Value) { Write<float>(uintptr_t(this) + 0x38c, Value); } // 0x38c (Size: 0x4, Type: FloatProperty)
    void SET_InterpolationUpdateInterval(const float& Value) { Write<float>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x4, Type: FloatProperty)
    void SET_PostInterpolationShrinkDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x394, Value); } // 0x394 (Size: 0x4, Type: FloatProperty)
    void SET_PerformSizeInterpolation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x1, Type: BoolProperty)
    void SET_IsPercentage(const bool& Value) { Write<bool>(uintptr_t(this) + 0x399, Value); } // 0x399 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UCommonPoolableWidgetInterface : public UInterface
{
public:
};

// Size: 0x7d0
class UCommonRichTextBlock : public URichTextBlock
{
public:
    uint8_t InlineIconDisplayMode() const { return Read<uint8_t>(uintptr_t(this) + 0x7a0); } // 0x7a0 (Size: 0x1, Type: EnumProperty)
    bool bTintInlineIcon() const { return Read<bool>(uintptr_t(this) + 0x7a1); } // 0x7a1 (Size: 0x1, Type: BoolProperty)
    float MobileTextBlockScale() const { return Read<float>(uintptr_t(this) + 0x7a4); } // 0x7a4 (Size: 0x4, Type: FloatProperty)
    UClass* DefaultTextStyleOverrideClass() const { return Read<UClass*>(uintptr_t(this) + 0x7a8); } // 0x7a8 (Size: 0x8, Type: ClassProperty)
    UClass* ScrollStyle() const { return Read<UClass*>(uintptr_t(this) + 0x7b0); } // 0x7b0 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EOrientation> ScrollOrientation() const { return Read<TEnumAsByte<EOrientation>>(uintptr_t(this) + 0x7b8); } // 0x7b8 (Size: 0x1, Type: ByteProperty)
    bool bIsScrollingEnabled() const { return Read<bool>(uintptr_t(this) + 0x7b9); } // 0x7b9 (Size: 0x1, Type: BoolProperty)
    bool bDisplayAllCaps() const { return Read<bool>(uintptr_t(this) + 0x7ba); } // 0x7ba (Size: 0x1, Type: BoolProperty)
    bool bAutoCollapseWithEmptyText() const { return Read<bool>(uintptr_t(this) + 0x7bb); } // 0x7bb (Size: 0x1, Type: BoolProperty)

    void SET_InlineIconDisplayMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x7a0, Value); } // 0x7a0 (Size: 0x1, Type: EnumProperty)
    void SET_bTintInlineIcon(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7a1, Value); } // 0x7a1 (Size: 0x1, Type: BoolProperty)
    void SET_MobileTextBlockScale(const float& Value) { Write<float>(uintptr_t(this) + 0x7a4, Value); } // 0x7a4 (Size: 0x4, Type: FloatProperty)
    void SET_DefaultTextStyleOverrideClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x7a8, Value); } // 0x7a8 (Size: 0x8, Type: ClassProperty)
    void SET_ScrollStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x7b0, Value); } // 0x7b0 (Size: 0x8, Type: ClassProperty)
    void SET_ScrollOrientation(const TEnumAsByte<EOrientation>& Value) { Write<TEnumAsByte<EOrientation>>(uintptr_t(this) + 0x7b8, Value); } // 0x7b8 (Size: 0x1, Type: ByteProperty)
    void SET_bIsScrollingEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7b9, Value); } // 0x7b9 (Size: 0x1, Type: BoolProperty)
    void SET_bDisplayAllCaps(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7ba, Value); } // 0x7ba (Size: 0x1, Type: BoolProperty)
    void SET_bAutoCollapseWithEmptyText(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7bb, Value); } // 0x7bb (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1580
class UCommonRotator : public UCommonButtonBase
{
public:
    UCommonTextBlock* MyText() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1558); } // 0x1558 (Size: 0x8, Type: ObjectProperty)

    void SET_MyText(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1558, Value); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4c0
class UCommonTabListWidgetBase : public UCommonUserWidget
{
public:
    FDataTableRowHandle NextTabInputActionData() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle PreviousTabInputActionData() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x10, Type: StructProperty)
    UInputAction* NextTabEnhancedInputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    UInputAction* PreviousTabEnhancedInputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x8, Type: ObjectProperty)
    bool bAutoListenForInput() const { return Read<bool>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x1, Type: BoolProperty)
    bool bShouldWrapNavigation() const { return Read<bool>(uintptr_t(this) + 0x3b9); } // 0x3b9 (Size: 0x1, Type: BoolProperty)
    bool bDeferRebuildingTabList() const { return Read<bool>(uintptr_t(this) + 0x3ba); } // 0x3ba (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<UCommonAnimatedSwitcher*> LinkedSwitcher() const { return Read<TWeakObjectPtr<UCommonAnimatedSwitcher*>>(uintptr_t(this) + 0x3bc); } // 0x3bc (Size: 0x8, Type: WeakObjectProperty)
    UCommonButtonGroupBase* TabButtonGroup() const { return Read<UCommonButtonGroupBase*>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    TMap<FCommonRegisteredTabInfo, FName> RegisteredTabsByID() const { return Read<TMap<FCommonRegisteredTabInfo, FName>>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x50, Type: MapProperty)
    FUserWidgetPool TabButtonWidgetPool() const { return Read<FUserWidgetPool>(uintptr_t(this) + 0x428); } // 0x428 (Size: 0x88, Type: StructProperty)

    void SET_NextTabInputActionData(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x10, Type: StructProperty)
    void SET_PreviousTabInputActionData(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x10, Type: StructProperty)
    void SET_NextTabEnhancedInputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    void SET_PreviousTabEnhancedInputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x8, Type: ObjectProperty)
    void SET_bAutoListenForInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldWrapNavigation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3b9, Value); } // 0x3b9 (Size: 0x1, Type: BoolProperty)
    void SET_bDeferRebuildingTabList(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3ba, Value); } // 0x3ba (Size: 0x1, Type: BoolProperty)
    void SET_LinkedSwitcher(const TWeakObjectPtr<UCommonAnimatedSwitcher*>& Value) { Write<TWeakObjectPtr<UCommonAnimatedSwitcher*>>(uintptr_t(this) + 0x3bc, Value); } // 0x3bc (Size: 0x8, Type: WeakObjectProperty)
    void SET_TabButtonGroup(const UCommonButtonGroupBase*& Value) { Write<UCommonButtonGroupBase*>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    void SET_RegisteredTabsByID(const TMap<FCommonRegisteredTabInfo, FName>& Value) { Write<TMap<FCommonRegisteredTabInfo, FName>>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x50, Type: MapProperty)
    void SET_TabButtonWidgetPool(const FUserWidgetPool& Value) { Write<FUserWidgetPool>(uintptr_t(this) + 0x428, Value); } // 0x428 (Size: 0x88, Type: StructProperty)
};

// Size: 0x190
class UCommonTextStyle : public UObject
{
public:
    FSlateFontInfo Font() const { return Read<FSlateFontInfo>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x58, Type: StructProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StructProperty)
    bool bUsesDropShadow() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)
    FVector2D ShadowOffset() const { return Read<FVector2D>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: StructProperty)
    FLinearColor ShadowColor() const { return Read<FLinearColor>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: StructProperty)
    FMargin Margin() const { return Read<FMargin>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: StructProperty)
    FSlateBrush StrikeBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0xb0, Type: StructProperty)
    float LineHeightPercentage() const { return Read<float>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x4, Type: FloatProperty)
    bool ApplyLineHeightToBottomLine() const { return Read<bool>(uintptr_t(this) + 0x184); } // 0x184 (Size: 0x1, Type: BoolProperty)

    void SET_Font(const FSlateFontInfo& Value) { Write<FSlateFontInfo>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x58, Type: StructProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StructProperty)
    void SET_bUsesDropShadow(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
    void SET_ShadowOffset(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: StructProperty)
    void SET_ShadowColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: StructProperty)
    void SET_Margin(const FMargin& Value) { Write<FMargin>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: StructProperty)
    void SET_StrikeBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0xb0, Type: StructProperty)
    void SET_LineHeightPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x4, Type: FloatProperty)
    void SET_ApplyLineHeightToBottomLine(const bool& Value) { Write<bool>(uintptr_t(this) + 0x184, Value); } // 0x184 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x40
class UCommonTextScrollStyle : public UObject
{
public:
    float Speed() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float StartDelay() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float EndDelay() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float FadeInDelay() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float FadeOutDelay() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Clipping() const { return Read<uint8_t>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x1, Type: EnumProperty)

    void SET_Speed(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_StartDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_EndDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_FadeInDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_FadeOutDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_Clipping(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x1, Type: EnumProperty)
};

// Size: 0xb90
class UCommonTileView : public UTileView
{
public:
};

// Size: 0xbc0
class UCommonTreeView : public UTreeView
{
public:
};

// Size: 0x90
class UCommonUIEditorSettings : public UObject
{
public:
};

// Size: 0x28
class UCommonUILibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x30
class UCommonUIRichTextData : public UObject
{
public:
    UDataTable* InlineIconSet() const { return Read<UDataTable*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_InlineIconSet(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1a0
class UCommonUISettings : public UObject
{
public:
    bool bAutoLoadData() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    TSoftObjectPtr<UObject> DefaultImageResourceObject() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInterface> DefaultThrobberMaterial() const { return Read<TSoftObjectPtr<UMaterialInterface>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FGameplayTag> PlatformTraits() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    UObject* DefaultImageResourceObjectInstance() const { return Read<UObject*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* DefaultThrobberMaterialInstance() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    FSlateBrush DefaultThrobberBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0xb0, Type: StructProperty)
    UCommonUIRichTextData* RichTextDataInstance() const { return Read<UCommonUIRichTextData*>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x8, Type: ObjectProperty)

    void SET_bAutoLoadData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_DefaultImageResourceObject(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    void SET_DefaultThrobberMaterial(const TSoftObjectPtr<UMaterialInterface>& Value) { Write<TSoftObjectPtr<UMaterialInterface>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x20, Type: SoftObjectProperty)
    void SET_PlatformTraits(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    void SET_DefaultImageResourceObjectInstance(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultThrobberMaterialInstance(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultThrobberBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0xb0, Type: StructProperty)
    void SET_RichTextDataInstance(const UCommonUIRichTextData*& Value) { Write<UCommonUIRichTextData*>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class UCommonUISubsystemBase : public UGameInstanceSubsystem
{
public:
};

// Size: 0x30
class UCommonInputMetadata : public UObject
{
public:
    int32_t NavBarPriority() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    bool bIsGenericInputAction() const { return Read<bool>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: BoolProperty)

    void SET_NavBarPriority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_bIsGenericInputAction(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UCommonMappingContextMetadataInterface : public UInterface
{
public:
};

// Size: 0x90
class UCommonMappingContextMetadata : public UDataAsset
{
public:
    UCommonInputMetadata* EnhancedInputMetadata() const { return Read<UCommonInputMetadata*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    TMap<UCommonInputMetadata*, UInputAction*> PerActionEnhancedInputMetadata() const { return Read<TMap<UCommonInputMetadata*, UInputAction*>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x50, Type: MapProperty)

    void SET_EnhancedInputMetadata(const UCommonInputMetadata*& Value) { Write<UCommonInputMetadata*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_PerActionEnhancedInputMetadata(const TMap<UCommonInputMetadata*, UInputAction*>& Value) { Write<TMap<UCommonInputMetadata*, UInputAction*>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x50, Type: MapProperty)
};

// Size: 0x88
class UCommonUIVisibilitySubsystem : public ULocalPlayerSubsystem
{
public:
};

// Size: 0x2a0
class UCommonVideoPlayer : public UWidget
{
public:
    UMediaSource* Video() const { return Read<UMediaSource*>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x8, Type: ObjectProperty)
    bool bMatchSize() const { return Read<bool>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x1, Type: BoolProperty)
    UMediaPlayer* MediaPlayer() const { return Read<UMediaPlayer*>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x8, Type: ObjectProperty)
    UMediaTexture* MediaTexture() const { return Read<UMediaTexture*>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x8, Type: ObjectProperty)
    UMaterial* VideoMaterial() const { return Read<UMaterial*>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x8, Type: ObjectProperty)
    UMediaSoundComponent* SoundComponent() const { return Read<UMediaSoundComponent*>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x8, Type: ObjectProperty)
    FSlateBrush VideoBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0xb0, Type: StructProperty)

    void SET_Video(const UMediaSource*& Value) { Write<UMediaSource*>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x8, Type: ObjectProperty)
    void SET_bMatchSize(const bool& Value) { Write<bool>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x1, Type: BoolProperty)
    void SET_MediaPlayer(const UMediaPlayer*& Value) { Write<UMediaPlayer*>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x8, Type: ObjectProperty)
    void SET_MediaTexture(const UMediaTexture*& Value) { Write<UMediaTexture*>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x8, Type: ObjectProperty)
    void SET_VideoMaterial(const UMaterial*& Value) { Write<UMaterial*>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundComponent(const UMediaSoundComponent*& Value) { Write<UMediaSoundComponent*>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x8, Type: ObjectProperty)
    void SET_VideoBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0xb0, Type: StructProperty)
};

// Size: 0x1a8
class UCommonVisibilitySwitcher : public UOverlay
{
public:
    uint8_t ShownVisibility() const { return Read<uint8_t>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x1, Type: EnumProperty)
    int32_t ActiveWidgetIndex() const { return Read<int32_t>(uintptr_t(this) + 0x184); } // 0x184 (Size: 0x4, Type: IntProperty)
    bool bAutoActivateSlot() const { return Read<bool>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x1, Type: BoolProperty)
    bool bActivateFirstSlotOnAdding() const { return Read<bool>(uintptr_t(this) + 0x189); } // 0x189 (Size: 0x1, Type: BoolProperty)

    void SET_ShownVisibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x1, Type: EnumProperty)
    void SET_ActiveWidgetIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x184, Value); } // 0x184 (Size: 0x4, Type: IntProperty)
    void SET_bAutoActivateSlot(const bool& Value) { Write<bool>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x1, Type: BoolProperty)
    void SET_bActivateFirstSlotOnAdding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x189, Value); } // 0x189 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x68
class UCommonVisibilitySwitcherSlot : public UOverlaySlot
{
public:
};

// Size: 0x350
class UUCommonVisibilityWidgetBase : public UCommonBorder
{
public:
    TMap<bool, FName> VisibilityControls() const { return Read<TMap<bool, FName>>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x50, Type: MapProperty)
    bool bShowForGamepad() const { return Read<bool>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x1, Type: BoolProperty)
    bool bShowForMouseAndKeyboard() const { return Read<bool>(uintptr_t(this) + 0x341); } // 0x341 (Size: 0x1, Type: BoolProperty)
    bool bShowForTouch() const { return Read<bool>(uintptr_t(this) + 0x342); } // 0x342 (Size: 0x1, Type: BoolProperty)
    uint8_t VisibleType() const { return Read<uint8_t>(uintptr_t(this) + 0x343); } // 0x343 (Size: 0x1, Type: EnumProperty)
    uint8_t HiddenType() const { return Read<uint8_t>(uintptr_t(this) + 0x344); } // 0x344 (Size: 0x1, Type: EnumProperty)

    void SET_VisibilityControls(const TMap<bool, FName>& Value) { Write<TMap<bool, FName>>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x50, Type: MapProperty)
    void SET_bShowForGamepad(const bool& Value) { Write<bool>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x1, Type: BoolProperty)
    void SET_bShowForMouseAndKeyboard(const bool& Value) { Write<bool>(uintptr_t(this) + 0x341, Value); } // 0x341 (Size: 0x1, Type: BoolProperty)
    void SET_bShowForTouch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x342, Value); } // 0x342 (Size: 0x1, Type: BoolProperty)
    void SET_VisibleType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x343, Value); } // 0x343 (Size: 0x1, Type: EnumProperty)
    void SET_HiddenType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x344, Value); } // 0x344 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x1c8
class UCommonVisualAttachment : public USizeBox
{
public:
    FVector2D ContentAnchor() const { return Read<FVector2D>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x10, Type: StructProperty)

    void SET_ContentAnchor(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x1b8
class UCommonWidgetCarousel : public UPanelWidget
{
public:
    int32_t ActiveWidgetIndex() const { return Read<int32_t>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x4, Type: IntProperty)
    float MoveSpeed() const { return Read<float>(uintptr_t(this) + 0x174); } // 0x174 (Size: 0x4, Type: FloatProperty)

    void SET_ActiveWidgetIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x4, Type: IntProperty)
    void SET_MoveSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x174, Value); } // 0x174 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x1a0
class UCommonWidgetCarouselNavBar : public UWidget
{
public:
    UClass* ButtonWidgetType() const { return Read<UClass*>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x8, Type: ClassProperty)
    FMargin ButtonPadding() const { return Read<FMargin>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x10, Type: StructProperty)
    UCommonWidgetCarousel* LinkedCarousel() const { return Read<UCommonWidgetCarousel*>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonGroupBase* ButtonGroup() const { return Read<UCommonButtonGroupBase*>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x8, Type: ObjectProperty)
    TArray<UCommonButtonBase*> Buttons() const { return Read<TArray<UCommonButtonBase*>>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x10, Type: ArrayProperty)

    void SET_ButtonWidgetType(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x8, Type: ClassProperty)
    void SET_ButtonPadding(const FMargin& Value) { Write<FMargin>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x10, Type: StructProperty)
    void SET_LinkedCarousel(const UCommonWidgetCarousel*& Value) { Write<UCommonWidgetCarousel*>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x8, Type: ObjectProperty)
    void SET_ButtonGroup(const UCommonButtonGroupBase*& Value) { Write<UCommonButtonGroupBase*>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x8, Type: ObjectProperty)
    void SET_Buttons(const TArray<UCommonButtonBase*>& Value) { Write<TArray<UCommonButtonBase*>>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x160
class UCommonButtonGroupBase : public UCommonWidgetGroupBase
{
public:
    bool bSelectionRequired() const { return Read<bool>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x1, Type: BoolProperty)

    void SET_bSelectionRequired(const bool& Value) { Write<bool>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UCommonWidgetGroupBase : public UObject
{
public:
};

// Size: 0x260
class UCommonBoundActionBar : public UDynamicEntryBoxBase
{
public:
    UClass* ActionButtonClass() const { return Read<UClass*>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x8, Type: ClassProperty)
    bool bDisplayOwningPlayerActionsOnly() const { return Read<bool>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreDuplicateActions() const { return Read<bool>(uintptr_t(this) + 0x241); } // 0x241 (Size: 0x1, Type: BoolProperty)

    void SET_ActionButtonClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x8, Type: ClassProperty)
    void SET_bDisplayOwningPlayerActionsOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x1, Type: BoolProperty)
    void SET_bIgnoreDuplicateActions(const bool& Value) { Write<bool>(uintptr_t(this) + 0x241, Value); } // 0x241 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1530
class UCommonBoundActionButton : public UCommonButtonBase
{
public:
    UCommonTextBlock* Text_ActionName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1518); } // 0x1518 (Size: 0x8, Type: ObjectProperty)
    bool bLinkRequiresHoldToBindingHold() const { return Read<bool>(uintptr_t(this) + 0x1520); } // 0x1520 (Size: 0x1, Type: BoolProperty)

    void SET_Text_ActionName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1518, Value); } // 0x1518 (Size: 0x8, Type: ObjectProperty)
    void SET_bLinkRequiresHoldToBindingHold(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1520, Value); } // 0x1520 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb0
class UCommonGenericInputActionDataTable : public UDataTable
{
public:
};

// Size: 0x28
class UCommonInputActionDataProcessor : public UObject
{
public:
};

// Size: 0x1d8
class UCommonUIActionRouterBase : public ULocalPlayerSubsystem
{
public:
};

// Size: 0x80
class UCommonUIInputSettings : public UObject
{
public:
    bool bLinkCursorToGamepadFocus() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    int32_t UIActionProcessingPriority() const { return Read<int32_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: IntProperty)
    TArray<FUIInputAction> InputActions() const { return Read<TArray<FUIInputAction>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FUIInputAction> ActionOverrides() const { return Read<TArray<FUIInputAction>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    FCommonAnalogCursorSettings AnalogCursorSettings() const { return Read<FCommonAnalogCursorSettings>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x2c, Type: StructProperty)

    void SET_bLinkCursorToGamepadFocus(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_UIActionProcessingPriority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: IntProperty)
    void SET_InputActions(const TArray<FUIInputAction>& Value) { Write<TArray<FUIInputAction>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_ActionOverrides(const TArray<FUIInputAction>& Value) { Write<TArray<FUIInputAction>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_AnalogCursorSettings(const FCommonAnalogCursorSettings& Value) { Write<FCommonAnalogCursorSettings>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x2c, Type: StructProperty)
};

// Size: 0x280
class UCommonActivatableWidgetContainerBase : public UWidget
{
public:
    uint8_t TransitionType() const { return Read<uint8_t>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x1, Type: EnumProperty)
    uint8_t TransitionCurveType() const { return Read<uint8_t>(uintptr_t(this) + 0x171); } // 0x171 (Size: 0x1, Type: EnumProperty)
    float TransitionDuration() const { return Read<float>(uintptr_t(this) + 0x174); } // 0x174 (Size: 0x4, Type: FloatProperty)
    bool bResetPoolWhenReleasingSlateResources() const { return Read<bool>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x1, Type: BoolProperty)
    uint8_t TransitionFallbackStrategy() const { return Read<uint8_t>(uintptr_t(this) + 0x179); } // 0x179 (Size: 0x1, Type: EnumProperty)
    TArray<UCommonActivatableWidget*> WidgetList() const { return Read<TArray<UCommonActivatableWidget*>>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x10, Type: ArrayProperty)
    UCommonActivatableWidget* DisplayedWidget() const { return Read<UCommonActivatableWidget*>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x8, Type: ObjectProperty)
    FUserWidgetPool GeneratedWidgetsPool() const { return Read<FUserWidgetPool>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x88, Type: StructProperty)

    void SET_TransitionType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x1, Type: EnumProperty)
    void SET_TransitionCurveType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x171, Value); } // 0x171 (Size: 0x1, Type: EnumProperty)
    void SET_TransitionDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x174, Value); } // 0x174 (Size: 0x4, Type: FloatProperty)
    void SET_bResetPoolWhenReleasingSlateResources(const bool& Value) { Write<bool>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x1, Type: BoolProperty)
    void SET_TransitionFallbackStrategy(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x179, Value); } // 0x179 (Size: 0x1, Type: EnumProperty)
    void SET_WidgetList(const TArray<UCommonActivatableWidget*>& Value) { Write<TArray<UCommonActivatableWidget*>>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x10, Type: ArrayProperty)
    void SET_DisplayedWidget(const UCommonActivatableWidget*& Value) { Write<UCommonActivatableWidget*>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x8, Type: ObjectProperty)
    void SET_GeneratedWidgetsPool(const FUserWidgetPool& Value) { Write<FUserWidgetPool>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x88, Type: StructProperty)
};

// Size: 0x290
class UCommonActivatableWidgetStack : public UCommonActivatableWidgetContainerBase
{
public:
    UClass* RootContentWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x8, Type: ClassProperty)
    UCommonActivatableWidget* RootContentWidget() const { return Read<UCommonActivatableWidget*>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x8, Type: ObjectProperty)

    void SET_RootContentWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x8, Type: ClassProperty)
    void SET_RootContentWidget(const UCommonActivatableWidget*& Value) { Write<UCommonActivatableWidget*>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x280
class UCommonActivatableWidgetQueue : public UCommonActivatableWidgetContainerBase
{
public:
};

// Size: 0x4
struct FUIActionBindingHandle
{
public:
};

// Size: 0x14
struct FCommonNumberFormattingOptions
{
public:
    TEnumAsByte<ERoundingMode> RoundingMode() const { return Read<TEnumAsByte<ERoundingMode>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    bool AlwaysSign() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    bool UseGrouping() const { return Read<bool>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: BoolProperty)
    int32_t MinimumIntegralDigits() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t MaximumIntegralDigits() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t MinimumFractionalDigits() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    int32_t MaximumFractionalDigits() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_RoundingMode(const TEnumAsByte<ERoundingMode>& Value) { Write<TEnumAsByte<ERoundingMode>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_AlwaysSign(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_UseGrouping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: BoolProperty)
    void SET_MinimumIntegralDigits(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_MaximumIntegralDigits(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_MinimumFractionalDigits(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_MaximumFractionalDigits(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x20
struct FCommonRegisteredTabInfo
{
public:
    int32_t TabIndex() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    UClass* TabButtonClass() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)
    UCommonButtonBase* TabButton() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    UWidget* ContentInstance() const { return Read<UWidget*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)

    void SET_TabIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_TabButtonClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
    void SET_TabButton(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_ContentInstance(const UWidget*& Value) { Write<UWidget*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x6
struct FUIInputConfig
{
public:
    bool bIgnoreMoveInput() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreLookInput() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t InputMode() const { return Read<uint8_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: EnumProperty)
    uint8_t MouseCaptureMode() const { return Read<uint8_t>(uintptr_t(this) + 0x3); } // 0x3 (Size: 0x1, Type: EnumProperty)
    uint8_t MouseLockMode() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    bool bHideCursorDuringViewportCapture() const { return Read<bool>(uintptr_t(this) + 0x5); } // 0x5 (Size: 0x1, Type: BoolProperty)

    void SET_bIgnoreMoveInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bIgnoreLookInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_InputMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: EnumProperty)
    void SET_MouseCaptureMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3, Value); } // 0x3 (Size: 0x1, Type: EnumProperty)
    void SET_MouseLockMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_bHideCursorDuringViewportCapture(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5, Value); } // 0x5 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FCommonInputActionHandlerData
{
public:
    FDataTableRowHandle InputActionRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    uint8_t State() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)

    void SET_InputActionRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_State(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x4
struct FUITag : public FGameplayTag
{
public:
};

// Size: 0x4
struct FUIActionTag : public FUITag
{
public:
};

// Size: 0x20
struct FCommonButtonStyleOptionalSlateSound
{
public:
    bool bHasSound() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    FSlateSound Sound() const { return Read<FSlateSound>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)

    void SET_bHasSound(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_Sound(const FSlateSound& Value) { Write<FSlateSound>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x48
struct FRichTextIconData : public FTableRowBase
{
public:
    FText DisplayName() const { return Read<FText>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UObject> ResourceObject() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x20, Type: SoftObjectProperty)
    FVector2D ImageSize() const { return Read<FVector2D>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)

    void SET_DisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: TextProperty)
    void SET_ResourceObject(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x20, Type: SoftObjectProperty)
    void SET_ImageSize(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
};

// Size: 0xe0
struct FCommonInputTypeInfo
{
public:
    FKey Key() const { return Read<FKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    uint8_t OverrrideState() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    bool bActionRequiresHold() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    float HoldTime() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float HoldRollbackTime() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    FSlateBrush OverrideBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0xb0, Type: StructProperty)

    void SET_Key(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_OverrrideState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_bActionRequiresHold(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET_HoldTime(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_HoldRollbackTime(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_OverrideBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0xb0, Type: StructProperty)
};

// Size: 0x320
struct FCommonInputActionDataBase : public FTableRowBase
{
public:
    FText DisplayName() const { return Read<FText>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: TextProperty)
    FText HoldDisplayName() const { return Read<FText>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: TextProperty)
    int32_t NavBarPriority() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    FCommonInputTypeInfo KeyboardInputTypeInfo() const { return Read<FCommonInputTypeInfo>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0xe0, Type: StructProperty)
    FCommonInputTypeInfo DefaultGamepadInputTypeInfo() const { return Read<FCommonInputTypeInfo>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0xe0, Type: StructProperty)
    TMap<FCommonInputTypeInfo, FName> GamepadInputOverrides() const { return Read<TMap<FCommonInputTypeInfo, FName>>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x50, Type: MapProperty)
    FCommonInputTypeInfo TouchInputTypeInfo() const { return Read<FCommonInputTypeInfo>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0xe0, Type: StructProperty)

    void SET_DisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: TextProperty)
    void SET_HoldDisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: TextProperty)
    void SET_NavBarPriority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_KeyboardInputTypeInfo(const FCommonInputTypeInfo& Value) { Write<FCommonInputTypeInfo>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0xe0, Type: StructProperty)
    void SET_DefaultGamepadInputTypeInfo(const FCommonInputTypeInfo& Value) { Write<FCommonInputTypeInfo>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0xe0, Type: StructProperty)
    void SET_GamepadInputOverrides(const TMap<FCommonInputTypeInfo, FName>& Value) { Write<TMap<FCommonInputTypeInfo, FName>>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x50, Type: MapProperty)
    void SET_TouchInputTypeInfo(const FCommonInputTypeInfo& Value) { Write<FCommonInputTypeInfo>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0xe0, Type: StructProperty)
};

// Size: 0x20
struct FUIActionKeyMapping
{
public:
    FKey Key() const { return Read<FKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    float HoldTime() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float HoldRollbackTime() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)

    void SET_Key(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_HoldTime(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_HoldRollbackTime(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FUIInputAction
{
public:
    FUIActionTag ActionTag() const { return Read<FUIActionTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FText DefaultDisplayName() const { return Read<FText>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: TextProperty)
    TArray<FUIActionKeyMapping> KeyMappings() const { return Read<TArray<FUIActionKeyMapping>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_ActionTag(const FUIActionTag& Value) { Write<FUIActionTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_DefaultDisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: TextProperty)
    void SET_KeyMappings(const TArray<FUIActionKeyMapping>& Value) { Write<TArray<FUIActionKeyMapping>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2c
struct FCommonAnalogCursorSettings
{
public:
    int32_t PreprocessorPriority() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    FInputPreprocessorRegistrationKey PreprocessorRegistrationInfo() const { return Read<FInputPreprocessorRegistrationKey>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x8, Type: StructProperty)
    bool bEnableCursorAcceleration() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)
    float CursorAcceleration() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float CursorMaxSpeed() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float CursorDeadZone() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float HoverSlowdownFactor() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float ScrollDeadZone() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float ScrollUpdatePeriod() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float ScrollMultiplier() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)

    void SET_PreprocessorPriority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_PreprocessorRegistrationInfo(const FInputPreprocessorRegistrationKey& Value) { Write<FInputPreprocessorRegistrationKey>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x8, Type: StructProperty)
    void SET_bEnableCursorAcceleration(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
    void SET_CursorAcceleration(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_CursorMaxSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_CursorDeadZone(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_HoverSlowdownFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_ScrollDeadZone(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_ScrollUpdatePeriod(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_ScrollMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
};

