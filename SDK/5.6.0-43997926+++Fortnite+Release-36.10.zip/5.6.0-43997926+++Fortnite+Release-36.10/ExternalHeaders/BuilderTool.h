/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BuilderTool
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "EnhancedInput.h"

// Size: 0x28
class UBuilderToolSelectedActorInterface : public UInterface
{
public:
};

// Size: 0x1a48
class ABuilderTool : public AFortWeapon
{
public:
    UInputMappingContext* InputMappingContext() const { return Read<UInputMappingContext*>(uintptr_t(this) + 0x19e8); } // 0x19e8 (Size: 0x8, Type: ObjectProperty)
    int32_t InputMappingPriority() const { return Read<int32_t>(uintptr_t(this) + 0x19f0); } // 0x19f0 (Size: 0x4, Type: IntProperty)
    UInputAction* UnEquipInputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x19f8); } // 0x19f8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer ActivatedTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x1a00); } // 0x1a00 (Size: 0x20, Type: StructProperty)
    TArray<UBuilderToolBehavior*> Behaviors() const { return Read<TArray<UBuilderToolBehavior*>>(uintptr_t(this) + 0x1a20); } // 0x1a20 (Size: 0x10, Type: ArrayProperty)
    UBuilderToolBehavior* ActiveBehavior() const { return Read<UBuilderToolBehavior*>(uintptr_t(this) + 0x1a30); } // 0x1a30 (Size: 0x8, Type: ObjectProperty)

    void SET_InputMappingContext(const UInputMappingContext*& Value) { Write<UInputMappingContext*>(uintptr_t(this) + 0x19e8, Value); } // 0x19e8 (Size: 0x8, Type: ObjectProperty)
    void SET_InputMappingPriority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x19f0, Value); } // 0x19f0 (Size: 0x4, Type: IntProperty)
    void SET_UnEquipInputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x19f8, Value); } // 0x19f8 (Size: 0x8, Type: ObjectProperty)
    void SET_ActivatedTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x1a00, Value); } // 0x1a00 (Size: 0x20, Type: StructProperty)
    void SET_Behaviors(const TArray<UBuilderToolBehavior*>& Value) { Write<TArray<UBuilderToolBehavior*>>(uintptr_t(this) + 0x1a20, Value); } // 0x1a20 (Size: 0x10, Type: ArrayProperty)
    void SET_ActiveBehavior(const UBuilderToolBehavior*& Value) { Write<UBuilderToolBehavior*>(uintptr_t(this) + 0x1a30, Value); } // 0x1a30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x270
class UBuilderToolBehavior : public UActorComponent
{
public:
    bool bShouldAddToParent() const { return Read<bool>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x1, Type: BoolProperty)
    int32_t Priority() const { return Read<int32_t>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x4, Type: IntProperty)
    FDataTableRowHandle ConfigData() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: StructProperty)
    FGameplayTagContainer ActivatedTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x20, Type: StructProperty)
    UInputMappingContext* InputMappingContext() const { return Read<UInputMappingContext*>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x8, Type: ObjectProperty)
    int32_t InputMappingPriority() const { return Read<int32_t>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: IntProperty)
    UInputAction* TriggerInputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: ObjectProperty)
    UInputAction* ExitInputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x8, Type: ObjectProperty)
    UClass* StartInteractionAbility() const { return Read<UClass*>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x8, Type: ClassProperty)
    UClass* EndInteractionAbility() const { return Read<UClass*>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x8, Type: ClassProperty)
    UClass* FailAbility() const { return Read<UClass*>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x8, Type: ClassProperty)
    UClass* ExitAbility() const { return Read<UClass*>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x8, Type: ClassProperty)
    FBuilderToolActorClassSet SupportedClasses() const { return Read<FBuilderToolActorClassSet>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0xa0, Type: StructProperty)
    TArray<FBuilderToolSelectedActor> SelectedActors() const { return Read<TArray<FBuilderToolSelectedActor>>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x10, Type: ArrayProperty)
    FGuid SelectionGUID() const { return Read<FGuid>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x10, Type: StructProperty)
    TArray<FBuilderToolTimedActors> ClientPredictedActors() const { return Read<TArray<FBuilderToolTimedActors>>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x10, Type: ArrayProperty)
    TArray<FBuilderToolSpawnedSelection> ServerSpawnedSelections() const { return Read<TArray<FBuilderToolSpawnedSelection>>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x10, Type: ArrayProperty)

    void SET_bShouldAddToParent(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x1, Type: BoolProperty)
    void SET_Priority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x4, Type: IntProperty)
    void SET_ConfigData(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: StructProperty)
    void SET_ActivatedTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x20, Type: StructProperty)
    void SET_InputMappingContext(const UInputMappingContext*& Value) { Write<UInputMappingContext*>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x8, Type: ObjectProperty)
    void SET_InputMappingPriority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: IntProperty)
    void SET_TriggerInputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: ObjectProperty)
    void SET_ExitInputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x8, Type: ObjectProperty)
    void SET_StartInteractionAbility(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x8, Type: ClassProperty)
    void SET_EndInteractionAbility(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x8, Type: ClassProperty)
    void SET_FailAbility(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x8, Type: ClassProperty)
    void SET_ExitAbility(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x8, Type: ClassProperty)
    void SET_SupportedClasses(const FBuilderToolActorClassSet& Value) { Write<FBuilderToolActorClassSet>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0xa0, Type: StructProperty)
    void SET_SelectedActors(const TArray<FBuilderToolSelectedActor>& Value) { Write<TArray<FBuilderToolSelectedActor>>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x10, Type: ArrayProperty)
    void SET_SelectionGUID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x10, Type: StructProperty)
    void SET_ClientPredictedActors(const TArray<FBuilderToolTimedActors>& Value) { Write<TArray<FBuilderToolTimedActors>>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x10, Type: ArrayProperty)
    void SET_ServerSpawnedSelections(const TArray<FBuilderToolSpawnedSelection>& Value) { Write<TArray<FBuilderToolSpawnedSelection>>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa8
class UBuilderToolItemDefinition : public UFortWorldItemDefinition
{
public:
};

// Size: 0x100
class UBuilderToolPlayerComponent : public UFortControllerComponent
{
public:
    UFortWeaponItemDefinition* BuilderToolWeaponItemDefinition() const { return Read<UFortWeaponItemDefinition*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)

    void SET_BuilderToolWeaponItemDefinition(const UFortWeaponItemDefinition*& Value) { Write<UFortWeaponItemDefinition*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x38
struct FBuilderToolItemDisplayData
{
public:
    uint8_t ItemType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FText DisplayName() const { return Read<FText>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: TextProperty)
    FText ShortDescription() const { return Read<FText>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: TextProperty)
    FText Description() const { return Read<FText>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: TextProperty)

    void SET_ItemType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_DisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: TextProperty)
    void SET_ShortDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: TextProperty)
    void SET_Description(const FText& Value) { Write<FText>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: TextProperty)
};

// Size: 0x70
struct FBuilderToolSelectedActor
{
public:
    UClass* Class() const { return Read<UClass*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<AActor*> Actor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    FTransform ToSelection() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)

    void SET_Class(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ClassProperty)
    void SET_Actor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ToSelection(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
};

// Size: 0x90
struct FBuilderToolSoftSelectedActor
{
public:
    TWeakObjectPtr<AActor*> Actor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    FTransform ToSelection() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)

    void SET_Actor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ToSelection(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
};

// Size: 0xa0
struct FBuilderToolActorClassSet
{
public:
    TSet<TSoftClassPtr> Classes() const { return Read<TSet<TSoftClassPtr>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: SetProperty)
    TSet<TSoftClassPtr> ExcludedSubclasses() const { return Read<TSet<TSoftClassPtr>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x50, Type: SetProperty)

    void SET_Classes(const TSet<TSoftClassPtr>& Value) { Write<TSet<TSoftClassPtr>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: SetProperty)
    void SET_ExcludedSubclasses(const TSet<TSoftClassPtr>& Value) { Write<TSet<TSoftClassPtr>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x50, Type: SetProperty)
};

// Size: 0xa8
struct FBuilderToolBehaviorRow : public FTableRowBase
{
public:
    FBuilderToolActorClassSet SupportedClasses() const { return Read<FBuilderToolActorClassSet>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0xa0, Type: StructProperty)

    void SET_SupportedClasses(const FBuilderToolActorClassSet& Value) { Write<FBuilderToolActorClassSet>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0xa0, Type: StructProperty)
};

// Size: 0x10
struct FBuilderToolSupportActorComponentPair
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UPrimitiveComponent* Component() const { return Read<UPrimitiveComponent*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Component(const UPrimitiveComponent*& Value) { Write<UPrimitiveComponent*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FBuilderToolSupportCandidate
{
public:
    TWeakObjectPtr<AActor*> Actor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UPrimitiveComponent*> Component() const { return Read<TWeakObjectPtr<UPrimitiveComponent*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Actor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Component(const TWeakObjectPtr<UPrimitiveComponent*>& Value) { Write<TWeakObjectPtr<UPrimitiveComponent*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xb0
struct FBuilderToolSelectionSpawnParams
{
public:
    int32_t SpawnID() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    FGuid SelectionGUID() const { return Read<FGuid>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x10, Type: StructProperty)
    TArray<FBuilderToolSoftSelectedActor> SelectedActors() const { return Read<TArray<FBuilderToolSoftSelectedActor>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    FTransform SelectionTransform() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)
    APawn* Instigator() const { return Read<APawn*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    TArray<FName> StableNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: ArrayProperty)

    void SET_SpawnID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_SelectionGUID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x10, Type: StructProperty)
    void SET_SelectedActors(const TArray<FBuilderToolSoftSelectedActor>& Value) { Write<TArray<FBuilderToolSoftSelectedActor>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_SelectionTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
    void SET_Instigator(const APawn*& Value) { Write<APawn*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    void SET_StableNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FBuilderToolTimedActors
{
public:
    TArray<TWeakObjectPtr<AActor*>> Actors() const { return Read<TArray<TWeakObjectPtr<AActor*>>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Actors(const TArray<TWeakObjectPtr<AActor*>>& Value) { Write<TArray<TWeakObjectPtr<AActor*>>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xc
struct FBuilderToolSpawnedActor
{
public:
    TWeakObjectPtr<AActor*> Actor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FName StableName() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)

    void SET_Actor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_StableName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
};

// Size: 0x28
struct FBuilderToolSpawnedSelection
{
public:
    int32_t SpawnID() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    FGuid Guid() const { return Read<FGuid>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x10, Type: StructProperty)
    TArray<FBuilderToolSpawnedActor> Actors() const { return Read<TArray<FBuilderToolSpawnedActor>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_SpawnID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Guid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x10, Type: StructProperty)
    void SET_Actors(const TArray<FBuilderToolSpawnedActor>& Value) { Write<TArray<FBuilderToolSpawnedActor>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FItemComponentData_BuilderTool : public FItemComponentData
{
public:
};

