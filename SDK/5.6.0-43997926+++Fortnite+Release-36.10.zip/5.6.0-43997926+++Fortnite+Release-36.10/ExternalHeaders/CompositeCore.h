/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CompositeCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x50
class UCompositeCoreSubsystem : public UTickableWorldSubsystem
{
public:
};

// Size: 0x250
class UHoldoutCompositeComponent : public USceneComponent
{
public:
    bool bIsEnabled() const { return Read<bool>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x1, Type: BoolProperty)

    void SET_bIsEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb8
class UCompositeCorePluginSettings : public UDeveloperSettings
{
public:
    bool bApplyPreExposure() const { return (Read<uint8_t>(uintptr_t(this) + 0x30) >> 0x0) & 1; } // 0x30:0 (Size: 0x1, Type: BoolProperty)
    bool bApplyFXAA() const { return (Read<uint8_t>(uintptr_t(this) + 0x30) >> 0x1) & 1; } // 0x30:1 (Size: 0x1, Type: BoolProperty)
    TArray<FSoftClassPath> DisabledPrimitiveClasses() const { return Read<TArray<FSoftClassPath>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FSoftClassPath> AllowedComponentClasses() const { return Read<TArray<FSoftClassPath>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    int32_t SceneViewExtensionPriority() const { return Read<int32_t>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: IntProperty)

    void SET_bApplyPreExposure(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x30); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x30, B); } // 0x30:0 (Size: 0x1, Type: BoolProperty)
    void SET_bApplyFXAA(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x30); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x30, B); } // 0x30:1 (Size: 0x1, Type: BoolProperty)
    void SET_DisabledPrimitiveClasses(const TArray<FSoftClassPath>& Value) { Write<TArray<FSoftClassPath>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_AllowedComponentClasses(const TArray<FSoftClassPath>& Value) { Write<TArray<FSoftClassPath>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_SceneViewExtensionPriority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: IntProperty)
};

