/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioLinkEngine
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x28
class UAudioLinkBlueprintInterface : public UInterface
{
public:
};

