/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DaySequence
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "MovieScene.h"

// Size: 0x4b8
class ABaseDaySequenceActor : public ADaySequenceActor
{
public:
    USceneComponent* SunRootComponent() const { return Read<USceneComponent*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    UDirectionalLightComponent* SunComponent() const { return Read<UDirectionalLightComponent*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    USkyAtmosphereComponent* SkyAtmosphereComponent() const { return Read<USkyAtmosphereComponent*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    USkyLightComponent* SkyLightComponent() const { return Read<USkyLightComponent*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    UExponentialHeightFogComponent* ExponentialHeightFogComponent() const { return Read<UExponentialHeightFogComponent*>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    UVolumetricCloudComponent* VolumetricCloudComponent() const { return Read<UVolumetricCloudComponent*>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SkySphereComponent() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)

    void SET_SunRootComponent(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_SunComponent(const UDirectionalLightComponent*& Value) { Write<UDirectionalLightComponent*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    void SET_SkyAtmosphereComponent(const USkyAtmosphereComponent*& Value) { Write<USkyAtmosphereComponent*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_SkyLightComponent(const USkyLightComponent*& Value) { Write<USkyLightComponent*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    void SET_ExponentialHeightFogComponent(const UExponentialHeightFogComponent*& Value) { Write<UExponentialHeightFogComponent*>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    void SET_VolumetricCloudComponent(const UVolumetricCloudComponent*& Value) { Write<UVolumetricCloudComponent*>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    void SET_SkySphereComponent(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x480
class ADaySequenceActor : public AInfo
{
public:
    UCurveFloat* DayInterpCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UDaySequenceCollectionAsset* DaySequenceCollection() const { return Read<UDaySequenceCollectionAsset*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    TArray<UDaySequenceCollectionAsset*> DaySequenceCollections() const { return Read<TArray<UDaySequenceCollectionAsset*>>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x10, Type: ArrayProperty)
    int32_t Bias() const { return Read<int32_t>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x4, Type: IntProperty)
    UMovieSceneBindingOverrides* BindingOverrides() const { return Read<UMovieSceneBindingOverrides*>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    bool bReplicatePlayback() const { return (Read<uint8_t>(uintptr_t(this) + 0x2e8) >> 0x0) & 1; } // 0x2e8:0 (Size: 0x1, Type: BoolProperty)
    UDaySequencePlayer* SequencePlayer() const { return Read<UDaySequencePlayer*>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UDaySequence* RootSequence() const { return Read<UDaySequence*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    float SequenceUpdateInterval() const { return Read<float>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x4, Type: FloatProperty)
    bool bRunDayCycle() const { return Read<bool>(uintptr_t(this) + 0x304); } // 0x304 (Size: 0x1, Type: BoolProperty)
    bool bUseInterpCurve() const { return Read<bool>(uintptr_t(this) + 0x305); } // 0x305 (Size: 0x1, Type: BoolProperty)
    FDaySequenceTime DayLength() const { return Read<FDaySequenceTime>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0xc, Type: StructProperty)
    FDaySequenceTime TimePerCycle() const { return Read<FDaySequenceTime>(uintptr_t(this) + 0x314); } // 0x314 (Size: 0xc, Type: StructProperty)
    FDaySequenceTime InitialTimeOfDay() const { return Read<FDaySequenceTime>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0xc, Type: StructProperty)
    UDaySequenceCameraModifierManager* CameraModifierManager() const { return Read<UDaySequenceCameraModifierManager*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    TMap<UDaySequenceConditionTag*, UClass*> TrackConditionMap() const { return Read<TMap<UDaySequenceConditionTag*, UClass*>>(uintptr_t(this) + 0x430); } // 0x430 (Size: 0x50, Type: MapProperty)

    void SET_DayInterpCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_DaySequenceCollection(const UDaySequenceCollectionAsset*& Value) { Write<UDaySequenceCollectionAsset*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    void SET_DaySequenceCollections(const TArray<UDaySequenceCollectionAsset*>& Value) { Write<TArray<UDaySequenceCollectionAsset*>>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x10, Type: ArrayProperty)
    void SET_Bias(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x4, Type: IntProperty)
    void SET_BindingOverrides(const UMovieSceneBindingOverrides*& Value) { Write<UMovieSceneBindingOverrides*>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    void SET_bReplicatePlayback(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2e8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x2e8, B); } // 0x2e8:0 (Size: 0x1, Type: BoolProperty)
    void SET_SequencePlayer(const UDaySequencePlayer*& Value) { Write<UDaySequencePlayer*>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    void SET_RootSequence(const UDaySequence*& Value) { Write<UDaySequence*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    void SET_SequenceUpdateInterval(const float& Value) { Write<float>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x4, Type: FloatProperty)
    void SET_bRunDayCycle(const bool& Value) { Write<bool>(uintptr_t(this) + 0x304, Value); } // 0x304 (Size: 0x1, Type: BoolProperty)
    void SET_bUseInterpCurve(const bool& Value) { Write<bool>(uintptr_t(this) + 0x305, Value); } // 0x305 (Size: 0x1, Type: BoolProperty)
    void SET_DayLength(const FDaySequenceTime& Value) { Write<FDaySequenceTime>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0xc, Type: StructProperty)
    void SET_TimePerCycle(const FDaySequenceTime& Value) { Write<FDaySequenceTime>(uintptr_t(this) + 0x314, Value); } // 0x314 (Size: 0xc, Type: StructProperty)
    void SET_InitialTimeOfDay(const FDaySequenceTime& Value) { Write<FDaySequenceTime>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0xc, Type: StructProperty)
    void SET_CameraModifierManager(const UDaySequenceCameraModifierManager*& Value) { Write<UDaySequenceCameraModifierManager*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_TrackConditionMap(const TMap<UDaySequenceConditionTag*, UClass*>& Value) { Write<TMap<UDaySequenceConditionTag*, UClass*>>(uintptr_t(this) + 0x430, Value); } // 0x430 (Size: 0x50, Type: MapProperty)
};

// Size: 0x28
class UDaySequenceCheatManagerExtension : public UCheatManagerExtension
{
public:
};

// Size: 0x60
class UDaySequenceConditionTag : public UObject
{
public:
    FString ConditionName() const { return Read<FString>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StrProperty)
    uint8_t InitializationPhase() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)

    void SET_ConditionName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StrProperty)
    void SET_InitializationPhase(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x60
class UDaySequenceModifierEasingFunction : public UObject
{
public:
};

// Size: 0x330
class UDaySequenceModifierComponent : public USceneComponent
{
public:
    ADaySequenceActor* TargetActor() const { return Read<ADaySequenceActor*>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x8, Type: ObjectProperty)
    TArray<FComponentReference> VolumeShapeComponents() const { return Read<TArray<FComponentReference>>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<APlayerController*> WeakBlendTarget() const { return Read<TWeakObjectPtr<APlayerController*>>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x8, Type: WeakObjectProperty)
    UDaySequence* UserDaySequence() const { return Read<UDaySequence*>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x8, Type: ObjectProperty)
    UDaySequence* TransientSequence() const { return Read<UDaySequence*>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x8, Type: ObjectProperty)
    UDaySequenceCollectionAsset* DaySequenceCollection() const { return Read<UDaySequenceCollectionAsset*>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x8, Type: ObjectProperty)
    TArray<UDaySequenceCollectionAsset*> DaySequenceCollections() const { return Read<TArray<UDaySequenceCollectionAsset*>>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x10, Type: ArrayProperty)
    UDaySequenceModifierEasingFunction* EasingFunction() const { return Read<UDaySequenceModifierEasingFunction*>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x8, Type: ObjectProperty)
    int32_t Bias() const { return Read<int32_t>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x4, Type: IntProperty)
    float DayNightCycleTime() const { return Read<float>(uintptr_t(this) + 0x2a4); } // 0x2a4 (Size: 0x4, Type: FloatProperty)
    float BlendAmount() const { return Read<float>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x4, Type: FloatProperty)
    float BlendTime() const { return Read<float>(uintptr_t(this) + 0x2ac); } // 0x2ac (Size: 0x4, Type: FloatProperty)
    float UserBlendWeight() const { return Read<float>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x4, Type: FloatProperty)
    uint8_t DayNightCycle() const { return Read<uint8_t>(uintptr_t(this) + 0x2b4); } // 0x2b4 (Size: 0x1, Type: EnumProperty)
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x2b5); } // 0x2b5 (Size: 0x1, Type: EnumProperty)
    uint8_t BlendPolicy() const { return Read<uint8_t>(uintptr_t(this) + 0x2b6); } // 0x2b6 (Size: 0x1, Type: EnumProperty)
    bool bIgnoreBias() const { return (Read<uint8_t>(uintptr_t(this) + 0x2d8) >> 0x0) & 1; } // 0x2d8:0 (Size: 0x1, Type: BoolProperty)
    bool bIsComponentEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x2d8) >> 0x1) & 1; } // 0x2d8:1 (Size: 0x1, Type: BoolProperty)
    bool bIsEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x2d8) >> 0x2) & 1; } // 0x2d8:2 (Size: 0x1, Type: BoolProperty)
    bool bPreview() const { return (Read<uint8_t>(uintptr_t(this) + 0x2d8) >> 0x3) & 1; } // 0x2d8:3 (Size: 0x1, Type: BoolProperty)
    bool bUseCollection() const { return (Read<uint8_t>(uintptr_t(this) + 0x2d8) >> 0x4) & 1; } // 0x2d8:4 (Size: 0x1, Type: BoolProperty)
    bool bSmoothBlending() const { return (Read<uint8_t>(uintptr_t(this) + 0x2d8) >> 0x5) & 1; } // 0x2d8:5 (Size: 0x1, Type: BoolProperty)
    bool bForceSmoothBlending() const { return (Read<uint8_t>(uintptr_t(this) + 0x2d8) >> 0x6) & 1; } // 0x2d8:6 (Size: 0x1, Type: BoolProperty)

    void SET_TargetActor(const ADaySequenceActor*& Value) { Write<ADaySequenceActor*>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x8, Type: ObjectProperty)
    void SET_VolumeShapeComponents(const TArray<FComponentReference>& Value) { Write<TArray<FComponentReference>>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x10, Type: ArrayProperty)
    void SET_WeakBlendTarget(const TWeakObjectPtr<APlayerController*>& Value) { Write<TWeakObjectPtr<APlayerController*>>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x8, Type: WeakObjectProperty)
    void SET_UserDaySequence(const UDaySequence*& Value) { Write<UDaySequence*>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x8, Type: ObjectProperty)
    void SET_TransientSequence(const UDaySequence*& Value) { Write<UDaySequence*>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x8, Type: ObjectProperty)
    void SET_DaySequenceCollection(const UDaySequenceCollectionAsset*& Value) { Write<UDaySequenceCollectionAsset*>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x8, Type: ObjectProperty)
    void SET_DaySequenceCollections(const TArray<UDaySequenceCollectionAsset*>& Value) { Write<TArray<UDaySequenceCollectionAsset*>>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x10, Type: ArrayProperty)
    void SET_EasingFunction(const UDaySequenceModifierEasingFunction*& Value) { Write<UDaySequenceModifierEasingFunction*>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x8, Type: ObjectProperty)
    void SET_Bias(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x4, Type: IntProperty)
    void SET_DayNightCycleTime(const float& Value) { Write<float>(uintptr_t(this) + 0x2a4, Value); } // 0x2a4 (Size: 0x4, Type: FloatProperty)
    void SET_BlendAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x4, Type: FloatProperty)
    void SET_BlendTime(const float& Value) { Write<float>(uintptr_t(this) + 0x2ac, Value); } // 0x2ac (Size: 0x4, Type: FloatProperty)
    void SET_UserBlendWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x4, Type: FloatProperty)
    void SET_DayNightCycle(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2b4, Value); } // 0x2b4 (Size: 0x1, Type: EnumProperty)
    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2b5, Value); } // 0x2b5 (Size: 0x1, Type: EnumProperty)
    void SET_BlendPolicy(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2b6, Value); } // 0x2b6 (Size: 0x1, Type: EnumProperty)
    void SET_bIgnoreBias(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2d8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x2d8, B); } // 0x2d8:0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsComponentEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2d8); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x2d8, B); } // 0x2d8:1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2d8); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x2d8, B); } // 0x2d8:2 (Size: 0x1, Type: BoolProperty)
    void SET_bPreview(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2d8); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x2d8, B); } // 0x2d8:3 (Size: 0x1, Type: BoolProperty)
    void SET_bUseCollection(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2d8); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x2d8, B); } // 0x2d8:4 (Size: 0x1, Type: BoolProperty)
    void SET_bSmoothBlending(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2d8); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x2d8, B); } // 0x2d8:5 (Size: 0x1, Type: BoolProperty)
    void SET_bForceSmoothBlending(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2d8); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x2d8, B); } // 0x2d8:6 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x330
class ADaySequenceModifierVolume : public AActor
{
public:
    UDaySequenceModifierComponent* DaySequenceModifier() const { return Read<UDaySequenceModifierComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    UBoxComponent* DefaultBox() const { return Read<UBoxComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    ADaySequenceActor* DaySequenceActor() const { return Read<ADaySequenceActor*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    APlayerController* CachedPlayerController() const { return Read<APlayerController*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    bool bEnableSplitscreenSupport() const { return Read<bool>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x1, Type: BoolProperty)
    TMap<UDaySequenceModifierComponent*, APlayerController*> AdditionalPlayers() const { return Read<TMap<UDaySequenceModifierComponent*, APlayerController*>>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x50, Type: MapProperty)

    void SET_DaySequenceModifier(const UDaySequenceModifierComponent*& Value) { Write<UDaySequenceModifierComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultBox(const UBoxComponent*& Value) { Write<UBoxComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_DaySequenceActor(const ADaySequenceActor*& Value) { Write<ADaySequenceActor*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedPlayerController(const APlayerController*& Value) { Write<APlayerController*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    void SET_bEnableSplitscreenSupport(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x1, Type: BoolProperty)
    void SET_AdditionalPlayers(const TMap<UDaySequenceModifierComponent*, APlayerController*>& Value) { Write<TMap<UDaySequenceModifierComponent*, APlayerController*>>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x50, Type: MapProperty)
};

// Size: 0x40
class UDaySequenceStaticTimeContributor : public UObject
{
public:
    float BlendWeight() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float StaticTime() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    bool bWantsStaticTime() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    ADaySequenceActor* TargetActor() const { return Read<ADaySequenceActor*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_BlendWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_StaticTime(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_bWantsStaticTime(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_TargetActor(const ADaySequenceActor*& Value) { Write<ADaySequenceActor*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x50
class UProceduralDaySequenceBuilder : public UObject
{
public:
};

// Size: 0x4c0
class ASunMoonDaySequenceActor : public ABaseDaySequenceActor
{
public:
    UDirectionalLightComponent* MoonComponent() const { return Read<UDirectionalLightComponent*>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)

    void SET_MoonComponent(const UDirectionalLightComponent*& Value) { Write<UDirectionalLightComponent*>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1d0
class UDaySequence : public UMovieSceneSequence
{
public:
    UMovieScene* MovieScene() const { return Read<UMovieScene*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    FDaySequenceBindingReferences BindingReferences() const { return Read<FDaySequenceBindingReferences>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x140, Type: StructProperty)
    UClass* DirectorClass() const { return Read<UClass*>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: ClassProperty)
    TArray<UAssetUserData*> AssetUserData() const { return Read<TArray<UAssetUserData*>>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x10, Type: ArrayProperty)

    void SET_MovieScene(const UMovieScene*& Value) { Write<UMovieScene*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_BindingReferences(const FDaySequenceBindingReferences& Value) { Write<FDaySequenceBindingReferences>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x140, Type: StructProperty)
    void SET_DirectorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: ClassProperty)
    void SET_AssetUserData(const TArray<UAssetUserData*>& Value) { Write<TArray<UAssetUserData*>>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x78
class UDaySequenceCameraModifierManager : public UObject
{
public:
};

// Size: 0x7b0
class UDaySequenceCameraModifier : public UCameraModifier
{
public:
    FPostProcessSettings Settings() const { return Read<FPostProcessSettings>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x760, Type: StructProperty)

    void SET_Settings(const FPostProcessSettings& Value) { Write<FPostProcessSettings>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x760, Type: StructProperty)
};

// Size: 0x50
class UDaySequenceCollectionAsset : public UDataAsset
{
public:
    TArray<FDaySequenceCollectionEntry> DaySequences() const { return Read<TArray<FDaySequenceCollectionEntry>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> ProceduralDaySequences() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_DaySequences(const TArray<FDaySequenceCollectionEntry>& Value) { Write<TArray<FDaySequenceCollectionEntry>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_ProceduralDaySequences(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
class UDaySequenceDirector : public UObject
{
public:
    UDaySequencePlayer* Player() const { return Read<UDaySequencePlayer*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    int32_t SubSequenceID() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    int32_t MovieScenePlayerIndex() const { return Read<int32_t>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: IntProperty)

    void SET_Player(const UDaySequencePlayer*& Value) { Write<UDaySequencePlayer*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_SubSequenceID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_MovieScenePlayerIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: IntProperty)
};

// Size: 0x478
class UDaySequencePlayer : public UObject
{
public:
    TScriptInterface<Class> Observer() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x10, Type: InterfaceProperty)
    TEnumAsByte<EMovieScenePlayerStatus> Status() const { return Read<TEnumAsByte<EMovieScenePlayerStatus>>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x1, Type: ByteProperty)
    UMovieSceneSequence* Sequence() const { return Read<UMovieSceneSequence*>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x8, Type: ObjectProperty)
    FFrameNumber StartTime() const { return Read<FFrameNumber>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x4, Type: StructProperty)
    int32_t DurationFrames() const { return Read<int32_t>(uintptr_t(this) + 0x2a4); } // 0x2a4 (Size: 0x4, Type: IntProperty)
    float DurationSubFrames() const { return Read<float>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x4, Type: FloatProperty)
    int32_t CurrentNumLoops() const { return Read<int32_t>(uintptr_t(this) + 0x2ac); } // 0x2ac (Size: 0x4, Type: IntProperty)
    int32_t SerialNumber() const { return Read<int32_t>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x4, Type: IntProperty)
    FMovieSceneSequencePlaybackSettings PlaybackSettings() const { return Read<FMovieSceneSequencePlaybackSettings>(uintptr_t(this) + 0x2b4); } // 0x2b4 (Size: 0x28, Type: StructProperty)
    FMovieSceneRootEvaluationTemplateInstance RootTemplateInstance() const { return Read<FMovieSceneRootEvaluationTemplateInstance>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x20, Type: StructProperty)
    FMovieSceneSequenceReplProperties NetSyncProps() const { return Read<FMovieSceneSequenceReplProperties>(uintptr_t(this) + 0x384); } // 0x384 (Size: 0x14, Type: StructProperty)
    TScriptInterface<Class> PlaybackClient() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x10, Type: InterfaceProperty)
    UMovieSceneEntitySystemLinker* Linker() const { return Read<UMovieSceneEntitySystemLinker*>(uintptr_t(this) + 0x448); } // 0x448 (Size: 0x8, Type: ObjectProperty)

    void SET_Observer(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x10, Type: InterfaceProperty)
    void SET_Status(const TEnumAsByte<EMovieScenePlayerStatus>& Value) { Write<TEnumAsByte<EMovieScenePlayerStatus>>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x1, Type: ByteProperty)
    void SET_Sequence(const UMovieSceneSequence*& Value) { Write<UMovieSceneSequence*>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x8, Type: ObjectProperty)
    void SET_StartTime(const FFrameNumber& Value) { Write<FFrameNumber>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x4, Type: StructProperty)
    void SET_DurationFrames(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2a4, Value); } // 0x2a4 (Size: 0x4, Type: IntProperty)
    void SET_DurationSubFrames(const float& Value) { Write<float>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x4, Type: FloatProperty)
    void SET_CurrentNumLoops(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2ac, Value); } // 0x2ac (Size: 0x4, Type: IntProperty)
    void SET_SerialNumber(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x4, Type: IntProperty)
    void SET_PlaybackSettings(const FMovieSceneSequencePlaybackSettings& Value) { Write<FMovieSceneSequencePlaybackSettings>(uintptr_t(this) + 0x2b4, Value); } // 0x2b4 (Size: 0x28, Type: StructProperty)
    void SET_RootTemplateInstance(const FMovieSceneRootEvaluationTemplateInstance& Value) { Write<FMovieSceneRootEvaluationTemplateInstance>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x20, Type: StructProperty)
    void SET_NetSyncProps(const FMovieSceneSequenceReplProperties& Value) { Write<FMovieSceneSequenceReplProperties>(uintptr_t(this) + 0x384, Value); } // 0x384 (Size: 0x14, Type: StructProperty)
    void SET_PlaybackClient(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x10, Type: InterfaceProperty)
    void SET_Linker(const UMovieSceneEntitySystemLinker*& Value) { Write<UMovieSceneEntitySystemLinker*>(uintptr_t(this) + 0x448, Value); } // 0x448 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x60
class UDaySequenceProjectSettings : public UDeveloperSettings
{
public:
    bool bDefaultLockEngineToDisplayRate() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    FString DefaultDisplayRate() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)
    FString DefaultTickResolution() const { return Read<FString>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StrProperty)
    uint8_t DefaultClockSource() const { return Read<uint8_t>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x1, Type: EnumProperty)

    void SET_bDefaultLockEngineToDisplayRate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_DefaultDisplayRate(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
    void SET_DefaultTickResolution(const FString& Value) { Write<FString>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StrProperty)
    void SET_DefaultClockSource(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x68
class UDaySequenceSubsystem : public UWorldSubsystem
{
public:
};

// Size: 0x120
class UDaySequenceTrack : public UMovieSceneSubTrack
{
public:
};

// Size: 0x50
struct FDaySequenceConditionSet
{
public:
    TMap<bool, UClass*> Conditions() const { return Read<TMap<bool, UClass*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_Conditions(const TMap<bool, UClass*>& Value) { Write<TMap<bool, UClass*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0xc
struct FDaySequenceTime
{
public:
    int32_t Hours() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Minutes() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t Seconds() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)

    void SET_Hours(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Minutes(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_Seconds(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x38
struct FDaySequenceBindingReference
{
public:
    TSoftObjectPtr<UObject> ExternalObjectPath() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    FString ObjectPath() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)

    void SET_ExternalObjectPath(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_ObjectPath(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
};

// Size: 0x10
struct FDaySequenceBindingReferenceArray
{
public:
    TArray<FDaySequenceBindingReference> References() const { return Read<TArray<FDaySequenceBindingReference>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_References(const TArray<FDaySequenceBindingReference>& Value) { Write<TArray<FDaySequenceBindingReference>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x140
struct FDaySequenceBindingReferences
{
public:
    TMap<FDaySequenceBindingReferenceArray, FGuid> BindingIdToReferences() const { return Read<TMap<FDaySequenceBindingReferenceArray, FGuid>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)
    TSet<FGuid> AnimSequenceInstances() const { return Read<TSet<FGuid>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x50, Type: SetProperty)
    TMap<FGuid, EDaySequenceBindingReferenceSpecialization> SpecializedReferenceToGuid() const { return Read<TMap<FGuid, EDaySequenceBindingReferenceSpecialization>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x50, Type: MapProperty)
    TMap<EDaySequenceBindingReferenceSpecialization, FGuid> GuidToSpecializedReference() const { return Read<TMap<EDaySequenceBindingReferenceSpecialization, FGuid>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x50, Type: MapProperty)

    void SET_BindingIdToReferences(const TMap<FDaySequenceBindingReferenceArray, FGuid>& Value) { Write<TMap<FDaySequenceBindingReferenceArray, FGuid>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
    void SET_AnimSequenceInstances(const TSet<FGuid>& Value) { Write<TSet<FGuid>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x50, Type: SetProperty)
    void SET_SpecializedReferenceToGuid(const TMap<FGuid, EDaySequenceBindingReferenceSpecialization>& Value) { Write<TMap<FGuid, EDaySequenceBindingReferenceSpecialization>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x50, Type: MapProperty)
    void SET_GuidToSpecializedReference(const TMap<EDaySequenceBindingReferenceSpecialization, FGuid>& Value) { Write<TMap<EDaySequenceBindingReferenceSpecialization, FGuid>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x60
struct FDaySequenceCollectionEntry
{
public:
    UDaySequence* Sequence() const { return Read<UDaySequence*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    int32_t BiasOffset() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    FDaySequenceConditionSet Conditions() const { return Read<FDaySequenceConditionSet>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x50, Type: StructProperty)

    void SET_Sequence(const UDaySequence*& Value) { Write<UDaySequence*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_BiasOffset(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_Conditions(const FDaySequenceConditionSet& Value) { Write<FDaySequenceConditionSet>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x50, Type: StructProperty)
};

// Size: 0xc
struct FDaySequencePlaybackParams
{
public:
};

// Size: 0x60
struct FProceduralDaySequence
{
public:
    FDaySequenceConditionSet Conditions() const { return Read<FDaySequenceConditionSet>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x50, Type: StructProperty)

    void SET_Conditions(const FDaySequenceConditionSet& Value) { Write<FDaySequenceConditionSet>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x50, Type: StructProperty)
};

// Size: 0x80
struct FSineSequence : public FProceduralDaySequence
{
public:
    FName PropertyName() const { return Read<FName>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: NameProperty)
    FName ComponentName() const { return Read<FName>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: NameProperty)
    uint32_t KeyCount() const { return Read<uint32_t>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: UInt32Property)
    float Amplitude() const { return Read<float>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: FloatProperty)
    float Frequency() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    float PhaseShift() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)
    float VerticalShift() const { return Read<float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: FloatProperty)

    void SET_PropertyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: NameProperty)
    void SET_ComponentName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: NameProperty)
    void SET_KeyCount(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: UInt32Property)
    void SET_Amplitude(const float& Value) { Write<float>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: FloatProperty)
    void SET_Frequency(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_PhaseShift(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
    void SET_VerticalShift(const float& Value) { Write<float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x68
struct FSunAngleSequence : public FProceduralDaySequence
{
public:
    FName SunComponentName() const { return Read<FName>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: NameProperty)

    void SET_SunComponentName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: NameProperty)
};

// Size: 0x90
struct FSunPositionSequence : public FProceduralDaySequence
{
public:
    FName SunComponentName() const { return Read<FName>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: NameProperty)
    uint32_t KeyCount() const { return Read<uint32_t>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: UInt32Property)
    FDateTime time() const { return Read<FDateTime>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: StructProperty)
    double TimeZone() const { return Read<double>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: DoubleProperty)
    double Latitude() const { return Read<double>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: DoubleProperty)
    double Longitude() const { return Read<double>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: DoubleProperty)
    bool bIsDaylightSavings() const { return Read<bool>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: BoolProperty)

    void SET_SunComponentName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: NameProperty)
    void SET_KeyCount(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: UInt32Property)
    void SET_time(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: StructProperty)
    void SET_TimeZone(const double& Value) { Write<double>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: DoubleProperty)
    void SET_Latitude(const double& Value) { Write<double>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: DoubleProperty)
    void SET_Longitude(const double& Value) { Write<double>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: DoubleProperty)
    void SET_bIsDaylightSavings(const bool& Value) { Write<bool>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: BoolProperty)
};

