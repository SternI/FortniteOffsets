/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortGameplayGraph
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayGraph.h"
#include "Engine.h"

// Size: 0x130
class UFortConnectivityGraph : public UGraph
{
public:
};

// Size: 0x150
class UFortConnectivityGraphIsland : public UGraphIsland
{
public:
    TSet<FGraphVertexHandle> SupportNodes() const { return Read<TSet<FGraphVertexHandle>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x50, Type: SetProperty)

    void SET_SupportNodes(const TSet<FGraphVertexHandle>& Value) { Write<TSet<FGraphVertexHandle>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x50, Type: SetProperty)
};

// Size: 0x118
class UFortConnectivityGraphVertex : public UGraphVertex
{
public:
    bool bIsIndependentlySupported() const { return Read<bool>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<AActor*> ConnectionActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x10c); } // 0x10c (Size: 0x8, Type: WeakObjectProperty)

    void SET_bIsIndependentlySupported(const bool& Value) { Write<bool>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x1, Type: BoolProperty)
    void SET_ConnectionActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x10c, Value); } // 0x10c (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x1
struct FSerializableConnectivityGraphVertex
{
public:
    bool bIsIndependentlySupported() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)

    void SET_bIsIndependentlySupported(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc8
struct FSerializableConnectivityGraph_v2 : public FSerializableGraph
{
public:
    TMap<FSerializableConnectivityGraphVertex, FGraphVertexHandle> ConnectivityVertexData() const { return Read<TMap<FSerializableConnectivityGraphVertex, FGraphVertexHandle>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x50, Type: MapProperty)

    void SET_ConnectivityVertexData(const TMap<FSerializableConnectivityGraphVertex, FGraphVertexHandle>& Value) { Write<TMap<FSerializableConnectivityGraphVertex, FGraphVertexHandle>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x50, Type: MapProperty)
};

