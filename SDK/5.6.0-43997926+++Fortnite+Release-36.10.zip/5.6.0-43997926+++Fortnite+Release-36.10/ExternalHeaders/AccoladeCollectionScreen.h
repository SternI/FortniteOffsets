/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AccoladeCollectionScreen
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteUI.h"
#include "UMG.h"
#include "GameplayAbilities.h"
#include "CommonUI.h"

// Size: 0x350
class UFortAccoladeStageListEntry : public UCommonUserWidget
{
public:
    UAthenaChallengeRewards* UserWidget_Rewards() const { return Read<UAthenaChallengeRewards*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)

    void SET_UserWidget_Rewards(const UAthenaChallengeRewards*& Value) { Write<UAthenaChallengeRewards*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x398
class UPinnedAccoladeWidget : public UFortHUDElementWidget
{
public:
    UFortLazyImage* LazyImage_PinColor() const { return Read<UFortLazyImage*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    int32_t NumAllowedDescCharacters() const { return Read<int32_t>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x4, Type: IntProperty)

    void SET_LazyImage_PinColor(const UFortLazyImage*& Value) { Write<UFortLazyImage*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    void SET_NumAllowedDescCharacters(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x4, Type: IntProperty)
};

// Size: 0x40
class UFortCollectionDataEntryAccolade : public UFortCollectionDataEntry
{
public:
};

// Size: 0x1600
class UFortPlayerAccoladeCollectionListEntry : public UAthenaCollectionListEntry
{
public:
    UImage* Image_Background() const { return Read<UImage*>(uintptr_t(this) + 0x15f0); } // 0x15f0 (Size: 0x8, Type: ObjectProperty)
    FName ParamName_ItemIcon() const { return Read<FName>(uintptr_t(this) + 0x15f8); } // 0x15f8 (Size: 0x4, Type: NameProperty)
    FName ParamName_IsDiscovered() const { return Read<FName>(uintptr_t(this) + 0x15fc); } // 0x15fc (Size: 0x4, Type: NameProperty)

    void SET_Image_Background(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x15f0, Value); } // 0x15f0 (Size: 0x8, Type: ObjectProperty)
    void SET_ParamName_ItemIcon(const FName& Value) { Write<FName>(uintptr_t(this) + 0x15f8, Value); } // 0x15f8 (Size: 0x4, Type: NameProperty)
    void SET_ParamName_IsDiscovered(const FName& Value) { Write<FName>(uintptr_t(this) + 0x15fc, Value); } // 0x15fc (Size: 0x4, Type: NameProperty)
};

// Size: 0x748
class UFortPlayerAccoladeCollectionScreen : public UAthenaCollectionScreenBase
{
public:
    FScalableFloat AccoladesEnabledViaHotfix() const { return Read<FScalableFloat>(uintptr_t(this) + 0x6f0); } // 0x6f0 (Size: 0x28, Type: StructProperty)
    UCommonTextBlock* Text_CategoryTitle() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x718); } // 0x718 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_ClearBangs() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x720); } // 0x720 (Size: 0x8, Type: ObjectProperty)
    bool bUserProgressSuccessfullyRetrieved() const { return Read<bool>(uintptr_t(this) + 0x740); } // 0x740 (Size: 0x1, Type: BoolProperty)

    void SET_AccoladesEnabledViaHotfix(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x6f0, Value); } // 0x6f0 (Size: 0x28, Type: StructProperty)
    void SET_Text_CategoryTitle(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x718, Value); } // 0x718 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_ClearBangs(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x720, Value); } // 0x720 (Size: 0x8, Type: ObjectProperty)
    void SET_bUserProgressSuccessfullyRetrieved(const bool& Value) { Write<bool>(uintptr_t(this) + 0x740, Value); } // 0x740 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x5c8
class UFortPlayerAccoladeCollectionScreenContainer : public UAthenaCollectionScreenContainer
{
public:
    UAccoladeProductData* BRProductData() const { return Read<UAccoladeProductData*>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x8, Type: ObjectProperty)

    void SET_BRProductData(const UAccoladeProductData*& Value) { Write<UAccoladeProductData*>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x540
class UFortPlayerAccoladeCollectionScreenInfoOverlay : public UAthenaCollectionScreenInfoOverlay
{
public:
    UFortCTAButton* Button_TrackAccolade() const { return Read<UFortCTAButton*>(uintptr_t(this) + 0x530); } // 0x530 (Size: 0x8, Type: ObjectProperty)
    UFortAccoladeStageListEntry* Widget_AccoladeGoal() const { return Read<UFortAccoladeStageListEntry*>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x8, Type: ObjectProperty)

    void SET_Button_TrackAccolade(const UFortCTAButton*& Value) { Write<UFortCTAButton*>(uintptr_t(this) + 0x530, Value); } // 0x530 (Size: 0x8, Type: ObjectProperty)
    void SET_Widget_AccoladeGoal(const UFortAccoladeStageListEntry*& Value) { Write<UFortAccoladeStageListEntry*>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x8, Type: ObjectProperty)
};

