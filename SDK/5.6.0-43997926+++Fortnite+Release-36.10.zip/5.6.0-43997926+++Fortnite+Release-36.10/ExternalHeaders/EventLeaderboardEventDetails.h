/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EventLeaderboardEventDetails
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CommonUI.h"

// Size: 0x7b8
class UEventLeaderboardEventDetails_C : public UFortShowdownDetailView
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x798); } // 0x798 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_SessionName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x7a0); } // 0x7a0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_RoundAndRegionName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x7a8); } // 0x7a8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_EventName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x7b0); } // 0x7b0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x798, Value); } // 0x798 (Size: 0x8, Type: StructProperty)
    void SET_Text_SessionName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x7a0, Value); } // 0x7a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_RoundAndRegionName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x7a8, Value); } // 0x7a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_EventName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x7b0, Value); } // 0x7b0 (Size: 0x8, Type: ObjectProperty)
};

