/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CosmeticsFrameworkFlowgraph
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "GameplayTags.h"

// Size: 0x50
class UCosmeticsFlowgraphDebugger : public UObject
{
public:
};

// Size: 0x28
class UCosmeticsFlowgraphManagerSource : public UInterface
{
public:
};

// Size: 0x40
class UCosmeticsFlowgraphSubsystem : public UGameInstanceSubsystem
{
public:
    UCosmeticsFlowgraphManager* FlowManager() const { return Read<UCosmeticsFlowgraphManager*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_FlowManager(const UCosmeticsFlowgraphManager*& Value) { Write<UCosmeticsFlowgraphManager*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UOrderedOperation : public UObject
{
public:
};

// Size: 0x158
class UCosmeticsFlowgraphManager : public UObject
{
public:
    TMap<FCosmeticFlowgraphState, FCosmeticFlowGraphKey> CosmeticCategories() const { return Read<TMap<FCosmeticFlowgraphState, FCosmeticFlowGraphKey>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: MapProperty)
    TArray<FExtensibilityPassContextEntry> AllocatedContexts() const { return Read<TArray<FExtensibilityPassContextEntry>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    TMap<UFortCosmeticPassContext*, FCosmeticsPassLookupKey> ActorToVarianceFlow() const { return Read<TMap<UFortCosmeticPassContext*, FCosmeticsPassLookupKey>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x50, Type: MapProperty)
    TArray<UFortCosmeticPassContext*> UniquePassContexts() const { return Read<TArray<UFortCosmeticPassContext*>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    TMap<UFortCosmeticFlowOptionSet*, FCosmeticFlowOptionSetKey> CosmeticFlowOptionSets() const { return Read<TMap<UFortCosmeticFlowOptionSet*, FCosmeticFlowOptionSetKey>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x50, Type: MapProperty)
    UCosmeticsFlowgraphDebugger* FlowgraphDebugger() const { return Read<UCosmeticsFlowgraphDebugger*>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x8, Type: ObjectProperty)

    void SET_CosmeticCategories(const TMap<FCosmeticFlowgraphState, FCosmeticFlowGraphKey>& Value) { Write<TMap<FCosmeticFlowgraphState, FCosmeticFlowGraphKey>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: MapProperty)
    void SET_AllocatedContexts(const TArray<FExtensibilityPassContextEntry>& Value) { Write<TArray<FExtensibilityPassContextEntry>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    void SET_ActorToVarianceFlow(const TMap<UFortCosmeticPassContext*, FCosmeticsPassLookupKey>& Value) { Write<TMap<UFortCosmeticPassContext*, FCosmeticsPassLookupKey>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x50, Type: MapProperty)
    void SET_UniquePassContexts(const TArray<UFortCosmeticPassContext*>& Value) { Write<TArray<UFortCosmeticPassContext*>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    void SET_CosmeticFlowOptionSets(const TMap<UFortCosmeticFlowOptionSet*, FCosmeticFlowOptionSetKey>& Value) { Write<TMap<UFortCosmeticFlowOptionSet*, FCosmeticFlowOptionSetKey>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x50, Type: MapProperty)
    void SET_FlowgraphDebugger(const UCosmeticsFlowgraphDebugger*& Value) { Write<UCosmeticsFlowgraphDebugger*>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1b8
class UCosmeticStepDependencyBuilder : public UObject
{
public:
    FCosmeticsStepSequenceContainer ComputedStepSequence() const { return Read<FCosmeticsStepSequenceContainer>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x60, Type: StructProperty)

    void SET_ComputedStepSequence(const FCosmeticsStepSequenceContainer& Value) { Write<FCosmeticsStepSequenceContainer>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x60, Type: StructProperty)
};

// Size: 0x30
class UFortCosmeticFlowNode : public UObject
{
public:
};

// Size: 0x38
class UFortCosmeticFlowOption : public UFortCosmeticFlowNode
{
public:
};

// Size: 0x38
class UFortCosmeticFlowOptionSet : public UObject
{
public:
    TArray<TSoftClassPtr> Options() const { return Read<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_Options(const TArray<TSoftClassPtr>& Value) { Write<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x80
class UFortCosmeticStep : public UFortCosmeticFlowNode
{
public:
    FCosmeticFlowGraphKey FlowGraphKey() const { return Read<FCosmeticFlowGraphKey>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: StructProperty)

    void SET_FlowGraphKey(const FCosmeticFlowGraphKey& Value) { Write<FCosmeticFlowGraphKey>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: StructProperty)
};

// Size: 0x168
class UFortCosmeticPassContext : public UObject
{
public:
};

// Size: 0x50
struct FCosmeticFlowData
{
public:
    TMap<FInstancedStruct, FName> NamedData() const { return Read<TMap<FInstancedStruct, FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_NamedData(const TMap<FInstancedStruct, FName>& Value) { Write<TMap<FInstancedStruct, FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x8
struct FCosmeticFlowGraphKey
{
public:
    FGameplayTag CategoryTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FGameplayTag FlowTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)

    void SET_CategoryTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_FlowTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
};

// Size: 0x4
struct FCosmeticFlowOptionSetKey
{
public:
    FGameplayTag OptionSetTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)

    void SET_OptionSetTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
};

// Size: 0x8
struct FCosmeticStepParentData
{
public:
};

// Size: 0x28
struct FCosmeticStepDetails
{
public:
};

// Size: 0x10
struct FOperationSequenceHandle
{
public:
};

// Size: 0x40
struct FCosmeticsPassLookupKey
{
public:
};

// Size: 0x18
struct FCosmeticFlowgraphState
{
public:
    UCosmeticStepDependencyBuilder* Builder() const { return Read<UCosmeticStepDependencyBuilder*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<TSoftClassPtr> Steps() const { return Read<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Builder(const UCosmeticStepDependencyBuilder*& Value) { Write<UCosmeticStepDependencyBuilder*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Steps(const TArray<TSoftClassPtr>& Value) { Write<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FExtensibilityPassContextEntry
{
public:
    UFortCosmeticPassContext* Context() const { return Read<UFortCosmeticPassContext*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_Context(const UFortCosmeticPassContext*& Value) { Write<UFortCosmeticPassContext*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x60
struct FCosmeticsStepSequenceContainer
{
public:
    TArray<UFortCosmeticStep*> StepCDOsByIndex() const { return Read<TArray<UFortCosmeticStep*>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)

    void SET_StepCDOsByIndex(const TArray<UFortCosmeticStep*>& Value) { Write<TArray<UFortCosmeticStep*>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
};

