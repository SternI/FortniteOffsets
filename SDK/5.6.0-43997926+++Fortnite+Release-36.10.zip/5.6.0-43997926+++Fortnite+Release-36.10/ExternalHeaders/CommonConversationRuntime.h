/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CommonConversationRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "GameplayTags.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x90
class UConversationChoiceNode : public UConversationSubNode
{
public:
    FText DefaultChoiceDisplayText() const { return Read<FText>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: TextProperty)
    FGameplayTagContainer ChoiceTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x20, Type: StructProperty)

    void SET_DefaultChoiceDisplayText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: TextProperty)
    void SET_ChoiceTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x20, Type: StructProperty)
};

// Size: 0x58
class UConversationSubNode : public UConversationNode
{
public:
};

// Size: 0x58
class UConversationNode : public UObject
{
public:
    UObject* EvalWorldContextObj() const { return Read<UObject*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    FString NodeName() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    FGuid Compiled_NodeGUID() const { return Read<FGuid>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StructProperty)
    UConversationNode* ParentNode() const { return Read<UConversationNode*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_EvalWorldContextObj(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_NodeName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_Compiled_NodeGUID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StructProperty)
    void SET_ParentNode(const UConversationNode*& Value) { Write<UConversationNode*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UConversationContextHelpers : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0xe8
class UConversationDatabase : public UPrimaryDataAsset
{
public:
    int32_t CompilerVersion() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    TMap<UConversationNode*, FGuid> ReachableNodeMap() const { return Read<TMap<UConversationNode*, FGuid>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x50, Type: MapProperty)
    TArray<FConversationEntryList> EntryTags() const { return Read<TArray<FConversationEntryList>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer ExitTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x20, Type: StructProperty)
    TArray<FGuid> InternalNodeIds() const { return Read<TArray<FGuid>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TArray<FGuid> LinkedToNodeIds() const { return Read<TArray<FGuid>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    TArray<FCommonDialogueBankParticipant> Speakers() const { return Read<TArray<FCommonDialogueBankParticipant>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)

    void SET_CompilerVersion(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_ReachableNodeMap(const TMap<UConversationNode*, FGuid>& Value) { Write<TMap<UConversationNode*, FGuid>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x50, Type: MapProperty)
    void SET_EntryTags(const TArray<FConversationEntryList>& Value) { Write<TArray<FConversationEntryList>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    void SET_ExitTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x20, Type: StructProperty)
    void SET_InternalNodeIds(const TArray<FGuid>& Value) { Write<TArray<FGuid>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    void SET_LinkedToNodeIds(const TArray<FGuid>& Value) { Write<TArray<FGuid>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    void SET_Speakers(const TArray<FCommonDialogueBankParticipant>& Value) { Write<TArray<FCommonDialogueBankParticipant>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x70
class UConversationEntryPointNode : public UConversationNodeWithLinks
{
public:
    FGameplayTag EntryTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: StructProperty)

    void SET_EntryTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: StructProperty)
};

// Size: 0x68
class UConversationNodeWithLinks : public UConversationNode
{
public:
    TArray<FGuid> OutputConnections() const { return Read<TArray<FGuid>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)

    void SET_OutputConnections(const TArray<FGuid>& Value) { Write<TArray<FGuid>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1a0
class UConversationInstance : public UObject
{
public:
    FConversationParticipants Participants() const { return Read<FConversationParticipants>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: StructProperty)
    UConversationDatabase* ActiveConversationGraph() const { return Read<UConversationDatabase*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)

    void SET_Participants(const FConversationParticipants& Value) { Write<FConversationParticipants>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: StructProperty)
    void SET_ActiveConversationGraph(const UConversationDatabase*& Value) { Write<UConversationDatabase*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UConversationLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x88
class UConversationLinkNode : public UConversationTaskNode
{
public:
    FGameplayTag RemoteEntryTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: StructProperty)

    void SET_RemoteEntryTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: StructProperty)
};

// Size: 0x80
class UConversationTaskNode : public UConversationNodeWithLinks
{
public:
    TArray<UConversationSubNode*> SubNodes() const { return Read<TArray<UConversationSubNode*>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    bool bIgnoreRequirementsWhileAdvancingConversations() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)

    void SET_SubNodes(const TArray<UConversationSubNode*>& Value) { Write<TArray<UConversationSubNode*>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_bIgnoreRequirementsWhileAdvancingConversations(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1a8
class UConversationParticipantComponent : public UActorComponent
{
public:
    int32_t ConversationsActive() const { return Read<int32_t>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x4, Type: IntProperty)
    UConversationInstance* Auth_CurrentConversation() const { return Read<UConversationInstance*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    TArray<UConversationInstance*> Auth_Conversations() const { return Read<TArray<UConversationInstance*>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x10, Type: ArrayProperty)
    FClientConversationMessagePayload LastMessage() const { return Read<FClientConversationMessagePayload>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x68, Type: StructProperty)

    void SET_ConversationsActive(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x4, Type: IntProperty)
    void SET_Auth_CurrentConversation(const UConversationInstance*& Value) { Write<UConversationInstance*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    void SET_Auth_Conversations(const TArray<UConversationInstance*>& Value) { Write<TArray<UConversationInstance*>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x10, Type: ArrayProperty)
    void SET_LastMessage(const FClientConversationMessagePayload& Value) { Write<FClientConversationMessagePayload>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x68, Type: StructProperty)
};

// Size: 0x1f8
class UConversationRegistry : public UWorldSubsystem
{
public:
    FNetSerializeScriptStructCache_ConvVersion ConversationChoiceDataStructCache() const { return Read<FNetSerializeScriptStructCache_ConvVersion>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x60, Type: StructProperty)

    void SET_ConversationChoiceDataStructCache(const FNetSerializeScriptStructCache_ConvVersion& Value) { Write<FNetSerializeScriptStructCache_ConvVersion>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x60, Type: StructProperty)
};

// Size: 0x58
class UConversationRequirementNode : public UConversationSubNode
{
public:
};

// Size: 0x50
class UConversationSettings : public UDeveloperSettings
{
public:
};

// Size: 0x58
class UConversationSideEffectNode : public UConversationSubNode
{
public:
};

// Size: 0x68
struct FClientConversationMessagePayload
{
public:
    FClientConversationMessage Message() const { return Read<FClientConversationMessage>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x38, Type: StructProperty)
    FConversationParticipants Participants() const { return Read<FConversationParticipants>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FConversationNodeHandle CurrentNode() const { return Read<FConversationNodeHandle>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    TArray<FClientConversationOptionEntry> Options() const { return Read<TArray<FClientConversationOptionEntry>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)

    void SET_Message(const FClientConversationMessage& Value) { Write<FClientConversationMessage>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x38, Type: StructProperty)
    void SET_Participants(const FConversationParticipants& Value) { Write<FConversationParticipants>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_CurrentNode(const FConversationNodeHandle& Value) { Write<FConversationNodeHandle>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_Options(const TArray<FClientConversationOptionEntry>& Value) { Write<TArray<FClientConversationOptionEntry>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x68
struct FClientConversationOptionEntry
{
public:
    FText ChoiceText() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    FGameplayTagContainer ChoiceTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    uint8_t ChoiceType() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)
    FConversationChoiceReference ChoiceReference() const { return Read<FConversationChoiceReference>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x20, Type: StructProperty)
    TArray<FConversationNodeParameterPair> ExtraData() const { return Read<TArray<FConversationNodeParameterPair>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)

    void SET_ChoiceText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_ChoiceTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_ChoiceType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
    void SET_ChoiceReference(const FConversationChoiceReference& Value) { Write<FConversationChoiceReference>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x20, Type: StructProperty)
    void SET_ExtraData(const TArray<FConversationNodeParameterPair>& Value) { Write<TArray<FConversationNodeParameterPair>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FConversationNodeParameterPair
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString Value() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Value(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x20
struct FConversationChoiceReference
{
public:
    FConversationNodeHandle NodeReference() const { return Read<FConversationNodeHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    TArray<FConversationNodeParameterPair> NodeParameters() const { return Read<TArray<FConversationNodeParameterPair>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_NodeReference(const FConversationNodeHandle& Value) { Write<FConversationNodeHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_NodeParameters(const TArray<FConversationNodeParameterPair>& Value) { Write<TArray<FConversationNodeParameterPair>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FConversationNodeHandle
{
public:
    FGuid NodeGUID() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)

    void SET_NodeGUID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x10
struct FConversationParticipants
{
public:
    TArray<FConversationParticipantEntry> List() const { return Read<TArray<FConversationParticipantEntry>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_List(const TArray<FConversationParticipantEntry>& Value) { Write<TArray<FConversationParticipantEntry>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FConversationParticipantEntry
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag ParticipantID() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ParticipantID(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
};

// Size: 0x38
struct FClientConversationMessage
{
public:
    FGameplayTag SpeakerID() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FText ParticipantDisplayName() const { return Read<FText>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: TextProperty)
    FText Text() const { return Read<FText>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: TextProperty)
    TArray<FConversationNodeParameterPair> MetadataParameters() const { return Read<TArray<FConversationNodeParameterPair>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_SpeakerID(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_ParticipantDisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: TextProperty)
    void SET_Text(const FText& Value) { Write<FText>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: TextProperty)
    void SET_MetadataParameters(const TArray<FConversationNodeParameterPair>& Value) { Write<TArray<FConversationNodeParameterPair>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x70
struct FConversationTaskResult
{
public:
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FAdvanceConversationRequest AdvanceToChoice() const { return Read<FAdvanceConversationRequest>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x30, Type: StructProperty)
    FClientConversationMessage Message() const { return Read<FClientConversationMessage>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x38, Type: StructProperty)

    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_AdvanceToChoice(const FAdvanceConversationRequest& Value) { Write<FAdvanceConversationRequest>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x30, Type: StructProperty)
    void SET_Message(const FClientConversationMessage& Value) { Write<FClientConversationMessage>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x38, Type: StructProperty)
};

// Size: 0x30
struct FAdvanceConversationRequest
{
public:
    FConversationChoiceReference Choice() const { return Read<FConversationChoiceReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    TArray<FConversationNodeParameterPair> UserParameters() const { return Read<TArray<FConversationNodeParameterPair>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_Choice(const FConversationChoiceReference& Value) { Write<FConversationChoiceReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_UserParameters(const TArray<FConversationNodeParameterPair>& Value) { Write<TArray<FConversationNodeParameterPair>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
struct FConversationContext
{
public:
    UConversationRegistry* ConversationRegistry() const { return Read<UConversationRegistry*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UConversationInstance* ActiveConversation() const { return Read<UConversationInstance*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UConversationParticipantComponent* ClientParticipant() const { return Read<UConversationParticipantComponent*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    UConversationTaskNode* TaskBeingConsidered() const { return Read<UConversationTaskNode*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    TArray<FConversationNodeHandle> ReturnScopeStack() const { return Read<TArray<FConversationNodeHandle>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    bool bServer_PRIVATE() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bClient_PRIVATE() const { return Read<bool>(uintptr_t(this) + 0x31); } // 0x31 (Size: 0x1, Type: BoolProperty)

    void SET_ConversationRegistry(const UConversationRegistry*& Value) { Write<UConversationRegistry*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ActiveConversation(const UConversationInstance*& Value) { Write<UConversationInstance*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_ClientParticipant(const UConversationParticipantComponent*& Value) { Write<UConversationParticipantComponent*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_TaskBeingConsidered(const UConversationTaskNode*& Value) { Write<UConversationTaskNode*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET_ReturnScopeStack(const TArray<FConversationNodeHandle>& Value) { Write<TArray<FConversationNodeHandle>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_bServer_PRIVATE(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_bClient_PRIVATE(const bool& Value) { Write<bool>(uintptr_t(this) + 0x31, Value); } // 0x31 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FConversationEntryList
{
public:
    FGameplayTag EntryTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    TArray<FGuid> DestinationList() const { return Read<TArray<FGuid>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    FString EntryIdentifier() const { return Read<FString>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StrProperty)

    void SET_EntryTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_DestinationList(const TArray<FGuid>& Value) { Write<TArray<FGuid>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_EntryIdentifier(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StrProperty)
};

// Size: 0x28
struct FCommonDialogueBankParticipant
{
public:
    FText FallbackName() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    FGameplayTag ParticipantName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: StructProperty)
    FLinearColor NodeTint() const { return Read<FLinearColor>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x10, Type: StructProperty)

    void SET_FallbackName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_ParticipantName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: StructProperty)
    void SET_NodeTint(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x10, Type: StructProperty)
};

// Size: 0x60
struct FNetSerializeScriptStructCache_ConvVersion
{
public:
    TMap<int32_t, UScriptStruct*> ScriptStructsToIndex() const { return Read<TMap<int32_t, UScriptStruct*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)
    TArray<UScriptStruct*> IndexToScriptStructs() const { return Read<TArray<UScriptStruct*>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)

    void SET_ScriptStructsToIndex(const TMap<int32_t, UScriptStruct*>& Value) { Write<TMap<int32_t, UScriptStruct*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
    void SET_IndexToScriptStructs(const TArray<UScriptStruct*>& Value) { Write<TArray<UScriptStruct*>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FConversationChoiceData
{
public:
};

// Size: 0x20
struct FConversationChoiceDataHandle
{
public:
};

// Size: 0x78
struct FConversationBranchPoint
{
public:
    TArray<FConversationNodeHandle> ReturnScopeStack() const { return Read<TArray<FConversationNodeHandle>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    FClientConversationOptionEntry ClientChoice() const { return Read<FClientConversationOptionEntry>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x68, Type: StructProperty)

    void SET_ReturnScopeStack(const TArray<FConversationNodeHandle>& Value) { Write<TArray<FConversationNodeHandle>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_ClientChoice(const FClientConversationOptionEntry& Value) { Write<FClientConversationOptionEntry>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x68, Type: StructProperty)
};

