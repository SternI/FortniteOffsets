/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayEffects
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0xa68
class UGE_Riding_NotPetableCreature_IsBeingRidden_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Riding_Creature_Sprint_Burt_C : public UGE_Riding_Creature_Sprint_C
{
public:
};

// Size: 0xa68
class UGE_Riding_Creature_Sprint_C : public UGameplayEffect
{
public:
};

