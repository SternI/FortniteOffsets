/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeCoreDevicesUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "ModelViewViewModel.h"
#include "Engine.h"
#include "UMG.h"
#include "CoreUObject.h"

// Size: 0x450
class UFortCreativeTimerContainerWidget : public UFortHUDElementWidget
{
public:
    UClass* TimerViewModelClass() const { return Read<UClass*>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x8, Type: ClassProperty)
    UClass* TimerWidgetDefaultClass() const { return Read<UClass*>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x8, Type: ClassProperty)
    TMap<FViewModelRelation, UObject*> InterfaceViewModelMap() const { return Read<TMap<FViewModelRelation, UObject*>>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x50, Type: MapProperty)
    TScriptInterface<Class> ActiveInterface() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x10, Type: InterfaceProperty)

    void SET_TimerViewModelClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x8, Type: ClassProperty)
    void SET_TimerWidgetDefaultClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x8, Type: ClassProperty)
    void SET_InterfaceViewModelMap(const TMap<FViewModelRelation, UObject*>& Value) { Write<TMap<FViewModelRelation, UObject*>>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x50, Type: MapProperty)
    void SET_ActiveInterface(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x10, Type: InterfaceProperty)
};

// Size: 0x10
struct FViewModelRelation
{
public:
};

