/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Blueprint
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x108
class UBP_CosmeticsOverride_Figure_Frontend_C : public USparksCosmeticOverrides
{
public:
};

