/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DiscoveryOverrideMatchmakingUIComponent
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x100
class UDiscoveryOverrideMatchmakingUIComponent_C : public UOverrideMatchmakingUIComponent
{
public:
};

