/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CustomControlsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CustomControlsRuntime.h"

// Size: 0x2c8
class ACustomControlsUIDirector : public ADynamicUIDirectorBase
{
public:
};

// Size: 0x328
class UTwinStickCursorWidget : public UUserWidget
{
public:
};

