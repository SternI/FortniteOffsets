/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DeveloperSettings
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x30
class UDeveloperSettings : public UObject
{
public:
};

// Size: 0x30
class UDeveloperSettingsBackedByCVars : public UDeveloperSettings
{
public:
};

// Size: 0x40
class UPlatformSettings : public UObject
{
public:
};

// Size: 0x80
class UPlatformSettingsManager : public UObject
{
public:
    TMap<FPlatformSettingsInstances, UClass*> SettingsMap() const { return Read<TMap<FPlatformSettingsInstances, UClass*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: MapProperty)

    void SET_SettingsMap(const TMap<FPlatformSettingsInstances, UClass*>& Value) { Write<TMap<FPlatformSettingsInstances, UClass*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: MapProperty)
};

// Size: 0x10
struct FPerPlatformSettings
{
public:
    TArray<UPlatformSettings*> Settings() const { return Read<TArray<UPlatformSettings*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Settings(const TArray<UPlatformSettings*>& Value) { Write<TArray<UPlatformSettings*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x58
struct FPlatformSettingsInstances
{
public:
    UPlatformSettings* PlatformInstance() const { return Read<UPlatformSettings*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TMap<UPlatformSettings*, FName> OtherPlatforms() const { return Read<TMap<UPlatformSettings*, FName>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x50, Type: MapProperty)

    void SET_PlatformInstance(const UPlatformSettings*& Value) { Write<UPlatformSettings*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_OtherPlatforms(const TMap<UPlatformSettings*, FName>& Value) { Write<TMap<UPlatformSettings*, FName>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x50, Type: MapProperty)
};

