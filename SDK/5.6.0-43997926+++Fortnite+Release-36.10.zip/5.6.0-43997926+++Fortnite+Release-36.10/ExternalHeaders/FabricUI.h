/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "SlateCore.h"
#include "UMG.h"
#include "ModelViewViewModel.h"

// Size: 0x70
class UFabricBeatDisplayViewModel : public UMVVMViewModelBase
{
public:
    float NumberOfBeats() const { return Read<float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: FloatProperty)
    bool bVisible() const { return Read<bool>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x1, Type: BoolProperty)

    void SET_NumberOfBeats(const float& Value) { Write<float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: FloatProperty)
    void SET_bVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x98
class UFabricButtonBaseViewModel : public UFabricInteractableViewModel
{
public:
    uint8_t ToggleState() const { return Read<uint8_t>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: EnumProperty)

    void SET_ToggleState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x90
class UFabricInteractableViewModel : public UMVVMViewModelBase
{
public:
    FText Label() const { return Read<FText>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: TextProperty)
    FText Value() const { return Read<FText>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: TextProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: BoolProperty)
    bool bVisible() const { return Read<bool>(uintptr_t(this) + 0x89); } // 0x89 (Size: 0x1, Type: BoolProperty)

    void SET_Label(const FText& Value) { Write<FText>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: TextProperty)
    void SET_Value(const FText& Value) { Write<FText>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: TextProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: BoolProperty)
    void SET_bVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x89, Value); } // 0x89 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x98
class UFabricCarouselViewModel : public UFabricInteractableViewModel
{
public:
    bool bPresetEnabled() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)
    bool bShowBorder() const { return Read<bool>(uintptr_t(this) + 0x91); } // 0x91 (Size: 0x1, Type: BoolProperty)
    int32_t CurrentOptionIndex() const { return Read<int32_t>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: IntProperty)

    void SET_bPresetEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
    void SET_bShowBorder(const bool& Value) { Write<bool>(uintptr_t(this) + 0x91, Value); } // 0x91 (Size: 0x1, Type: BoolProperty)
    void SET_CurrentOptionIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: IntProperty)
};

// Size: 0x358
class UFabricGeneralTextWidget : public UFabricWidget
{
public:
};

// Size: 0x358
class UFabricWidget : public UCommonUserWidget
{
public:
    UClass* GridStyle() const { return Read<UClass*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ClassProperty)
    UClass* ViewModelClass() const { return Read<UClass*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ClassProperty)

    void SET_GridStyle(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ClassProperty)
    void SET_ViewModelClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x48
class UFabricGridStyle : public UObject
{
public:
    FMargin Padding() const { return Read<FMargin>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    TEnumAsByte<EHorizontalAlignment> HorizontalAlignment() const { return Read<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EVerticalAlignment> VerticalAlignment() const { return Read<TEnumAsByte<EVerticalAlignment>>(uintptr_t(this) + 0x39); } // 0x39 (Size: 0x1, Type: ByteProperty)
    int32_t RowSpan() const { return Read<int32_t>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: IntProperty)
    int32_t ColumnSpan() const { return Read<int32_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: IntProperty)

    void SET_Padding(const FMargin& Value) { Write<FMargin>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_HorizontalAlignment(const TEnumAsByte<EHorizontalAlignment>& Value) { Write<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: ByteProperty)
    void SET_VerticalAlignment(const TEnumAsByte<EVerticalAlignment>& Value) { Write<TEnumAsByte<EVerticalAlignment>>(uintptr_t(this) + 0x39, Value); } // 0x39 (Size: 0x1, Type: ByteProperty)
    void SET_RowSpan(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: IntProperty)
    void SET_ColumnSpan(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: IntProperty)
};

// Size: 0x358
class UFabricInfoWidget : public UFabricWidget
{
public:
};

// Size: 0x98
class UFabricKnobViewModel : public UFabricInteractableViewModel
{
public:
    bool bValueVisible() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)

    void SET_bValueVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
class UFabricMeasureViewModel : public UMVVMViewModelBase
{
public:
    FText MeasureCount() const { return Read<FText>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: TextProperty)
    bool bVisible() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)

    void SET_MeasureCount(const FText& Value) { Write<FText>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: TextProperty)
    void SET_bVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x70
class UFabricPageInfoViewModel : public UMVVMViewModelBase
{
public:
    bool bHasContent() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)
    bool bActivePage() const { return Read<bool>(uintptr_t(this) + 0x69); } // 0x69 (Size: 0x1, Type: BoolProperty)

    void SET_bHasContent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
    void SET_bActivePage(const bool& Value) { Write<bool>(uintptr_t(this) + 0x69, Value); } // 0x69 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x78
class UFabricPlaybackTimeViewModel : public UMVVMViewModelBase
{
public:
    float ElapsedSeconds() const { return Read<float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: FloatProperty)
    float TotalSeconds() const { return Read<float>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: FloatProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    bool bVisible() const { return Read<bool>(uintptr_t(this) + 0x71); } // 0x71 (Size: 0x1, Type: BoolProperty)

    void SET_ElapsedSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: FloatProperty)
    void SET_TotalSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: FloatProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_bVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x71, Value); } // 0x71 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x368
class UFabricPlaybackTimeWidget : public UFabricWidget
{
public:
    UNamedSlot* NamedSlot_Left() const { return Read<UNamedSlot*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    UNamedSlot* NamedSlot_Right() const { return Read<UNamedSlot*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)

    void SET_NamedSlot_Left(const UNamedSlot*& Value) { Write<UNamedSlot*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_NamedSlot_Right(const UNamedSlot*& Value) { Write<UNamedSlot*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x378
class UFabricScreenWidget : public UCommonUserWidget
{
public:
    UInvalidationBox* InvalidationBox_RootBox() const { return Read<UInvalidationBox*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    UScaleBox* ScaleBox_ScreenScale() const { return Read<UScaleBox*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* GridPanel_ScreenGrid() const { return Read<UGridPanel*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    USpacer* Spacer_ElementSpacer() const { return Read<USpacer*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)

    void SET_InvalidationBox_RootBox(const UInvalidationBox*& Value) { Write<UInvalidationBox*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_ScaleBox_ScreenScale(const UScaleBox*& Value) { Write<UScaleBox*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_GridPanel_ScreenGrid(const UGridPanel*& Value) { Write<UGridPanel*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_Spacer_ElementSpacer(const USpacer*& Value) { Write<USpacer*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x70
class UFabricSongSyncViewModel : public UMVVMViewModelBase
{
public:
    uint8_t ControlTempoState() const { return Read<uint8_t>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: EnumProperty)
    bool bHasLinkedSongSyncDevices() const { return Read<bool>(uintptr_t(this) + 0x69); } // 0x69 (Size: 0x1, Type: BoolProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x6a); } // 0x6a (Size: 0x1, Type: BoolProperty)

    void SET_ControlTempoState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: EnumProperty)
    void SET_bHasLinkedSongSyncDevices(const bool& Value) { Write<bool>(uintptr_t(this) + 0x69, Value); } // 0x69 (Size: 0x1, Type: BoolProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6a, Value); } // 0x6a (Size: 0x1, Type: BoolProperty)
};

// Size: 0x90
class UFabricTimeSignatureViewModel : public UMVVMViewModelBase
{
public:
    FText TopValue() const { return Read<FText>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: TextProperty)
    FText BottomValue() const { return Read<FText>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: TextProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: BoolProperty)
    bool bVisible() const { return Read<bool>(uintptr_t(this) + 0x89); } // 0x89 (Size: 0x1, Type: BoolProperty)

    void SET_TopValue(const FText& Value) { Write<FText>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: TextProperty)
    void SET_BottomValue(const FText& Value) { Write<FText>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: TextProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: BoolProperty)
    void SET_bVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x89, Value); } // 0x89 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x358
class UFabricTimeSignatureWidget : public UFabricWidget
{
public:
};

// Size: 0x98
class UFabricTrackInfoViewModel : public UMVVMViewModelBase
{
public:
    uint8_t TrackInfoState() const { return Read<uint8_t>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: EnumProperty)
    FString Artist() const { return Read<FString>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: StrProperty)
    FString Title() const { return Read<FString>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StrProperty)
    bool bLoading() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)

    void SET_TrackInfoState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: EnumProperty)
    void SET_Artist(const FString& Value) { Write<FString>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: StrProperty)
    void SET_Title(const FString& Value) { Write<FString>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StrProperty)
    void SET_bLoading(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x358
class UFabricTrackInfoWidget : public UFabricWidget
{
public:
};

// Size: 0x78
class UFabricTrackNumberViewModel : public UMVVMViewModelBase
{
public:
    int32_t CurrentTrackNumber() const { return Read<int32_t>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: IntProperty)
    int32_t TotalNumberOfTracks() const { return Read<int32_t>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: IntProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    bool bVisible() const { return Read<bool>(uintptr_t(this) + 0x71); } // 0x71 (Size: 0x1, Type: BoolProperty)

    void SET_CurrentTrackNumber(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: IntProperty)
    void SET_TotalNumberOfTracks(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: IntProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_bVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x71, Value); } // 0x71 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x358
class UFabricTrackNumberWidget : public UFabricWidget
{
public:
};

// Size: 0x6c0
class UFabricWidgetComponent : public UWidgetComponent
{
public:
    bool bShouldSuscribeToSignificanceSubsystem() const { return Read<bool>(uintptr_t(this) + 0x6b8); } // 0x6b8 (Size: 0x1, Type: BoolProperty)

    void SET_bShouldSuscribeToSignificanceSubsystem(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6b8, Value); } // 0x6b8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x58
class UFabricWidgetTickControlSubsystem : public UTickableWorldSubsystem
{
public:
};

// Size: 0x108
class UPlayspaceComponent_FabricViewModelManager : public UPlayspaceComponent
{
public:
    TMap<UMVVMViewModelBase*, UClass*> Viewmodels() const { return Read<TMap<UMVVMViewModelBase*, UClass*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x50, Type: MapProperty)

    void SET_Viewmodels(const TMap<UMVVMViewModelBase*, UClass*>& Value) { Write<TMap<UMVVMViewModelBase*, UClass*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x50, Type: MapProperty)
};

