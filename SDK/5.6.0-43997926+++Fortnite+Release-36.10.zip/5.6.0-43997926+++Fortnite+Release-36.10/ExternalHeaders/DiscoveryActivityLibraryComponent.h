/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DiscoveryActivityLibraryComponent
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0xe8
class UDiscoveryActivityLibraryComponent_C : public UActivityLibraryComponent
{
public:
};

