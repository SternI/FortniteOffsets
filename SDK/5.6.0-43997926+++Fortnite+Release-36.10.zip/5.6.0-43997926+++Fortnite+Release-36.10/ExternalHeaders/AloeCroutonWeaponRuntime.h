/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AloeCroutonWeaponRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"

// Size: 0x158
class UFortChargingSet_AloeCrouton : public UFortChargingSet_Base
{
public:
    FFortGameplayAttributeData Charge() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData MaxCharge() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData ChargeRate() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData ChargeIncrementAmount() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData ChargeRegenThreshold() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData ServerTimeChargeIncrements() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x28, Type: StructProperty)

    void SET_Charge(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x28, Type: StructProperty)
    void SET_MaxCharge(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x28, Type: StructProperty)
    void SET_ChargeRate(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x28, Type: StructProperty)
    void SET_ChargeIncrementAmount(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x28, Type: StructProperty)
    void SET_ChargeRegenThreshold(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x28, Type: StructProperty)
    void SET_ServerTimeChargeIncrements(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x28, Type: StructProperty)
};

// Size: 0x88
class UFortCosmeticStatObject_AloeCroutonCharge : public UFortCosmeticStatObject
{
public:
};

