/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteDynamicXpTypes
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
// Size: 0x8
struct FRestedXpUsage
{
public:
    uint8_t RestedXpUsage() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    int32_t FixedRestedXpAmount() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_RestedXpUsage(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_FixedRestedXpAmount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

