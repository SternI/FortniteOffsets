/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortAudioClustersRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "Engine.h"
#include "GameplayAbilities.h"
#include "AudioClustersRuntime.h"
#include "CoreUObject.h"

// Size: 0x80
class UFortAudioClustersSettings : public UDeveloperSettings
{
public:
    TMap<double, FGameplayTag> ParameterDefaults() const { return Read<TMap<double, FGameplayTag>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)

    void SET_ParameterDefaults(const TMap<double, FGameplayTag>& Value) { Write<TMap<double, FGameplayTag>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
};

// Size: 0x40
class UFortAudioClustersSubsystem : public UTickableWorldSubsystem
{
public:
};

// Size: 0xf0
class UGameFeatureAction_AddAudioCluster : public UGameFeatureAction
{
public:
    TArray<FGameFeatureAudioClusterEntry> Clusters() const { return Read<TArray<FGameFeatureAudioClusterEntry>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TMap<FGameplayTag, FName> OverrideTable() const { return Read<TMap<FGameplayTag, FName>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x50, Type: MapProperty)
    FName DisabledActorTag() const { return Read<FName>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: NameProperty)

    void SET_Clusters(const TArray<FGameFeatureAudioClusterEntry>& Value) { Write<TArray<FGameFeatureAudioClusterEntry>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_OverrideTable(const TMap<FGameplayTag, FName>& Value) { Write<TMap<FGameplayTag, FName>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x50, Type: MapProperty)
    void SET_DisabledActorTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: NameProperty)
};

// Size: 0x88
class UGameFeatureAction_AddAudioClusterConfigMaps : public UGameFeatureAction
{
public:
    TArray<TSoftObjectPtr<UAudioClusterConfigMap*>> ConfigMaps() const { return Read<TArray<TSoftObjectPtr<UAudioClusterConfigMap*>>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_ConfigMaps(const TArray<TSoftObjectPtr<UAudioClusterConfigMap*>>& Value) { Write<TArray<TSoftObjectPtr<UAudioClusterConfigMap*>>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xc8
class UGameFeatureAction_AddAudioClusterSettings : public UGameFeatureAction
{
public:
    TMap<double, FGameplayTag> SettingsMap() const { return Read<TMap<double, FGameplayTag>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: MapProperty)

    void SET_SettingsMap(const TMap<double, FGameplayTag>& Value) { Write<TMap<double, FGameplayTag>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: MapProperty)
};

// Size: 0x18
struct FGameFeatureAudioClusterEntry
{
public:
    FGameplayTag ClusterTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    TArray<TSoftClassPtr> ActorClasses() const { return Read<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_ClusterTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_ActorClasses(const TArray<TSoftClassPtr>& Value) { Write<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

