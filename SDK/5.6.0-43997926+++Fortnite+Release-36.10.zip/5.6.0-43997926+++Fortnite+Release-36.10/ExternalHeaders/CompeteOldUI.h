/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CompeteOldUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x48
class UFortUIGameFeatureAction_CompeteOldUI : public UFortUIGameFeatureAction
{
public:
};

