/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChaosNiagara
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Niagara.h"
#include "ChaosSolverEngine.h"
#include "CoreUObject.h"
#include "PhysicsCore.h"
#include "GeometryCollectionEngine.h"

// Size: 0x348
class UNiagaraDataInterfaceChaosDestruction : public UNiagaraDataInterface
{
public:
    TSet<AChaosSolverActor*> ChaosSolverActorSet() const { return Read<TSet<AChaosSolverActor*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x50, Type: SetProperty)
    uint8_t DataSourceType() const { return Read<uint8_t>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: EnumProperty)
    int32_t DataProcessFrequency() const { return Read<int32_t>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: IntProperty)
    int32_t MaxNumberOfDataEntriesToSpawn() const { return Read<int32_t>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: IntProperty)
    bool DoSpawn() const { return Read<bool>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x1, Type: BoolProperty)
    FVector2D SpawnMultiplierMinMax() const { return Read<FVector2D>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: StructProperty)
    float SpawnChance() const { return Read<float>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    FVector2D ImpulseToSpawnMinMax() const { return Read<FVector2D>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: StructProperty)
    FVector2D SpeedToSpawnMinMax() const { return Read<FVector2D>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: StructProperty)
    FVector2D MassToSpawnMinMax() const { return Read<FVector2D>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: StructProperty)
    FVector2D ExtentMinToSpawnMinMax() const { return Read<FVector2D>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: StructProperty)
    FVector2D ExtentMaxToSpawnMinMax() const { return Read<FVector2D>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: StructProperty)
    FVector2D VolumeToSpawnMinMax() const { return Read<FVector2D>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: StructProperty)
    FVector2D SolverTimeToSpawnMinMax() const { return Read<FVector2D>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: StructProperty)
    int32_t SurfaceTypeToSpawn() const { return Read<int32_t>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: IntProperty)
    uint8_t LocationFilteringMode() const { return Read<uint8_t>(uintptr_t(this) + 0x124); } // 0x124 (Size: 0x1, Type: EnumProperty)
    uint8_t LocationXToSpawn() const { return Read<uint8_t>(uintptr_t(this) + 0x125); } // 0x125 (Size: 0x1, Type: EnumProperty)
    FVector2D LocationXToSpawnMinMax() const { return Read<FVector2D>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x10, Type: StructProperty)
    uint8_t LocationYToSpawn() const { return Read<uint8_t>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x1, Type: EnumProperty)
    FVector2D LocationYToSpawnMinMax() const { return Read<FVector2D>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x10, Type: StructProperty)
    uint8_t LocationZToSpawn() const { return Read<uint8_t>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x1, Type: EnumProperty)
    FVector2D LocationZToSpawnMinMax() const { return Read<FVector2D>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x10, Type: StructProperty)
    float TrailMinSpeedToSpawn() const { return Read<float>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x4, Type: FloatProperty)
    uint8_t DataSortingType() const { return Read<uint8_t>(uintptr_t(this) + 0x16c); } // 0x16c (Size: 0x1, Type: EnumProperty)
    bool bGetExternalCollisionData() const { return Read<bool>(uintptr_t(this) + 0x16d); } // 0x16d (Size: 0x1, Type: BoolProperty)
    bool DoSpatialHash() const { return Read<bool>(uintptr_t(this) + 0x16e); } // 0x16e (Size: 0x1, Type: BoolProperty)
    FVector SpatialHashVolumeMin() const { return Read<FVector>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x18, Type: StructProperty)
    FVector SpatialHashVolumeMax() const { return Read<FVector>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x18, Type: StructProperty)
    FVector SpatialHashVolumeCellSize() const { return Read<FVector>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x18, Type: StructProperty)
    int32_t MaxDataPerCell() const { return Read<int32_t>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: IntProperty)
    bool bApplyMaterialsFilter() const { return Read<bool>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0x1, Type: BoolProperty)
    TSet<UPhysicalMaterial*> ChaosBreakingMaterialSet() const { return Read<TSet<UPhysicalMaterial*>>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x50, Type: SetProperty)
    bool bGetExternalBreakingData() const { return Read<bool>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x1, Type: BoolProperty)
    bool bGetExternalTrailingData() const { return Read<bool>(uintptr_t(this) + 0x211); } // 0x211 (Size: 0x1, Type: BoolProperty)
    FVector2D RandomPositionMagnitudeMinMax() const { return Read<FVector2D>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x10, Type: StructProperty)
    float InheritedVelocityMultiplier() const { return Read<float>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x4, Type: FloatProperty)
    uint8_t RandomVelocityGenerationType() const { return Read<uint8_t>(uintptr_t(this) + 0x22c); } // 0x22c (Size: 0x1, Type: EnumProperty)
    FVector2D RandomVelocityMagnitudeMinMax() const { return Read<FVector2D>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x10, Type: StructProperty)
    float SpreadAngleMax() const { return Read<float>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x4, Type: FloatProperty)
    FVector VelocityOffsetMin() const { return Read<FVector>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x18, Type: StructProperty)
    FVector VelocityOffsetMax() const { return Read<FVector>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x18, Type: StructProperty)
    FVector2D FinalVelocityMagnitudeMinMax() const { return Read<FVector2D>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x10, Type: StructProperty)
    float MaxLatency() const { return Read<float>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x4, Type: FloatProperty)
    uint8_t DebugType() const { return Read<uint8_t>(uintptr_t(this) + 0x28c); } // 0x28c (Size: 0x1, Type: EnumProperty)
    int32_t LastSpawnedPointID() const { return Read<int32_t>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x4, Type: IntProperty)
    float LastSpawnTime() const { return Read<float>(uintptr_t(this) + 0x294); } // 0x294 (Size: 0x4, Type: FloatProperty)
    float SolverTime() const { return Read<float>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x4, Type: FloatProperty)
    float TimeStampOfLastProcessedData() const { return Read<float>(uintptr_t(this) + 0x2ac); } // 0x2ac (Size: 0x4, Type: FloatProperty)

    void SET_ChaosSolverActorSet(const TSet<AChaosSolverActor*>& Value) { Write<TSet<AChaosSolverActor*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x50, Type: SetProperty)
    void SET_DataSourceType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: EnumProperty)
    void SET_DataProcessFrequency(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: IntProperty)
    void SET_MaxNumberOfDataEntriesToSpawn(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: IntProperty)
    void SET_DoSpawn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x1, Type: BoolProperty)
    void SET_SpawnMultiplierMinMax(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: StructProperty)
    void SET_SpawnChance(const float& Value) { Write<float>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    void SET_ImpulseToSpawnMinMax(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: StructProperty)
    void SET_SpeedToSpawnMinMax(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: StructProperty)
    void SET_MassToSpawnMinMax(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: StructProperty)
    void SET_ExtentMinToSpawnMinMax(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: StructProperty)
    void SET_ExtentMaxToSpawnMinMax(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: StructProperty)
    void SET_VolumeToSpawnMinMax(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: StructProperty)
    void SET_SolverTimeToSpawnMinMax(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: StructProperty)
    void SET_SurfaceTypeToSpawn(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: IntProperty)
    void SET_LocationFilteringMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x124, Value); } // 0x124 (Size: 0x1, Type: EnumProperty)
    void SET_LocationXToSpawn(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x125, Value); } // 0x125 (Size: 0x1, Type: EnumProperty)
    void SET_LocationXToSpawnMinMax(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x10, Type: StructProperty)
    void SET_LocationYToSpawn(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x1, Type: EnumProperty)
    void SET_LocationYToSpawnMinMax(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x10, Type: StructProperty)
    void SET_LocationZToSpawn(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x1, Type: EnumProperty)
    void SET_LocationZToSpawnMinMax(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x10, Type: StructProperty)
    void SET_TrailMinSpeedToSpawn(const float& Value) { Write<float>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x4, Type: FloatProperty)
    void SET_DataSortingType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x16c, Value); } // 0x16c (Size: 0x1, Type: EnumProperty)
    void SET_bGetExternalCollisionData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x16d, Value); } // 0x16d (Size: 0x1, Type: BoolProperty)
    void SET_DoSpatialHash(const bool& Value) { Write<bool>(uintptr_t(this) + 0x16e, Value); } // 0x16e (Size: 0x1, Type: BoolProperty)
    void SET_SpatialHashVolumeMin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x18, Type: StructProperty)
    void SET_SpatialHashVolumeMax(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x18, Type: StructProperty)
    void SET_SpatialHashVolumeCellSize(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x18, Type: StructProperty)
    void SET_MaxDataPerCell(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: IntProperty)
    void SET_bApplyMaterialsFilter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0x1, Type: BoolProperty)
    void SET_ChaosBreakingMaterialSet(const TSet<UPhysicalMaterial*>& Value) { Write<TSet<UPhysicalMaterial*>>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x50, Type: SetProperty)
    void SET_bGetExternalBreakingData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x1, Type: BoolProperty)
    void SET_bGetExternalTrailingData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x211, Value); } // 0x211 (Size: 0x1, Type: BoolProperty)
    void SET_RandomPositionMagnitudeMinMax(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x10, Type: StructProperty)
    void SET_InheritedVelocityMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x4, Type: FloatProperty)
    void SET_RandomVelocityGenerationType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x22c, Value); } // 0x22c (Size: 0x1, Type: EnumProperty)
    void SET_RandomVelocityMagnitudeMinMax(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x10, Type: StructProperty)
    void SET_SpreadAngleMax(const float& Value) { Write<float>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x4, Type: FloatProperty)
    void SET_VelocityOffsetMin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x18, Type: StructProperty)
    void SET_VelocityOffsetMax(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x18, Type: StructProperty)
    void SET_FinalVelocityMagnitudeMinMax(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x10, Type: StructProperty)
    void SET_MaxLatency(const float& Value) { Write<float>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x4, Type: FloatProperty)
    void SET_DebugType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28c, Value); } // 0x28c (Size: 0x1, Type: EnumProperty)
    void SET_LastSpawnedPointID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x4, Type: IntProperty)
    void SET_LastSpawnTime(const float& Value) { Write<float>(uintptr_t(this) + 0x294, Value); } // 0x294 (Size: 0x4, Type: FloatProperty)
    void SET_SolverTime(const float& Value) { Write<float>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x4, Type: FloatProperty)
    void SET_TimeStampOfLastProcessedData(const float& Value) { Write<float>(uintptr_t(this) + 0x2ac, Value); } // 0x2ac (Size: 0x4, Type: FloatProperty)
};

// Size: 0x90
class UNiagaraDataInterfaceGeometryCollection : public UNiagaraDataInterface
{
public:
    uint8_t SourceMode() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)
    UGeometryCollection* DefaultGeometryCollection() const { return Read<UGeometryCollection*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<AGeometryCollectionActor> GeometryCollectionActor() const { return Read<TSoftObjectPtr<AGeometryCollectionActor>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x20, Type: SoftObjectProperty)
    UGeometryCollectionComponent* SourceComponent() const { return Read<UGeometryCollectionComponent*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    FNiagaraUserParameterBinding GeometryCollectionUserParameter() const { return Read<FNiagaraUserParameterBinding>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)
    bool bIncludeIntermediateBones() const { return Read<bool>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: BoolProperty)

    void SET_SourceMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
    void SET_DefaultGeometryCollection(const UGeometryCollection*& Value) { Write<UGeometryCollection*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_GeometryCollectionActor(const TSoftObjectPtr<AGeometryCollectionActor>& Value) { Write<TSoftObjectPtr<AGeometryCollectionActor>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SourceComponent(const UGeometryCollectionComponent*& Value) { Write<UGeometryCollectionComponent*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_GeometryCollectionUserParameter(const FNiagaraUserParameterBinding& Value) { Write<FNiagaraUserParameterBinding>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
    void SET_bIncludeIntermediateBones(const bool& Value) { Write<bool>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x38
class UNiagaraDataInterfacePhysicsField : public UNiagaraDataInterface
{
public:
};

// Size: 0x78
struct FChaosDestructionEvent
{
public:
    FVector Position() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Normal() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FVector Velocity() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity() const { return Read<FVector>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    float ExtentMin() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    float ExtentMax() const { return Read<float>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: FloatProperty)
    int32_t ParticleID() const { return Read<int32_t>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: IntProperty)
    float time() const { return Read<float>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: FloatProperty)
    int32_t Type() const { return Read<int32_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: IntProperty)

    void SET_Position(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Normal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_Velocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_AngularVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_ExtentMin(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_ExtentMax(const float& Value) { Write<float>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: FloatProperty)
    void SET_ParticleID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: IntProperty)
    void SET_time(const float& Value) { Write<float>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: FloatProperty)
    void SET_Type(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: IntProperty)
};

