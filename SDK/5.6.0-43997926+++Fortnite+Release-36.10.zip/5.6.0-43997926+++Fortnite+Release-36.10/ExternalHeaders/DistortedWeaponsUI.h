/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DistortedWeaponsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "FortniteUI.h"

// Size: 0x3a8
class UChromeWeaponInfoWidget : public UFortHUDElementWidget
{
public:
    UFortHUDContext* HUDContext() const { return Read<UFortHUDContext*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    UFortWorldMultiItemXPComponent* CurrentXpComponent() const { return Read<UFortWorldMultiItemXPComponent*>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    UAthenaItemTierWidget* ItemTierWidget() const { return Read<UAthenaItemTierWidget*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    UFortKeybindWidget* KeybindWidget() const { return Read<UFortKeybindWidget*>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)

    void SET_HUDContext(const UFortHUDContext*& Value) { Write<UFortHUDContext*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentXpComponent(const UFortWorldMultiItemXPComponent*& Value) { Write<UFortWorldMultiItemXPComponent*>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemTierWidget(const UAthenaItemTierWidget*& Value) { Write<UAthenaItemTierWidget*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    void SET_KeybindWidget(const UFortKeybindWidget*& Value) { Write<UFortKeybindWidget*>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
};

