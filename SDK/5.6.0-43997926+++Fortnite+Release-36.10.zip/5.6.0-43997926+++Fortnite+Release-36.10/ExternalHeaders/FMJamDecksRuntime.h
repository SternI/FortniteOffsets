/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamDecksRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "FMJamPlayspaceRuntime.h"
#include "SparksCoreRuntime.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "CoreUObject.h"

// Size: 0x140
class UControllerComponent_JamDeckCoordinator : public UControllerComponent
{
public:
    AActor* LastFocusedActor() const { return Read<AActor*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)

    void SET_LastFocusedActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x228
class UFortClientsidePlayerInstancedStateTreeComponent : public UFortPlayerInstancedStateTreeComponent
{
public:
};

// Size: 0xb68
class UJamDeckAbility : public UFortGameplayAbility
{
public:
};

// Size: 0x410
class AJamDeckEmitter : public AActor
{
public:
    FCollisionResponseContainer CollisionResponse_AimMode() const { return Read<FCollisionResponseContainer>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x20, Type: StructProperty)
    FCollisionResponseContainer CollisionResponse_OverlapMode() const { return Read<FCollisionResponseContainer>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x20, Type: StructProperty)
    TArray<FJamDeckProxyControlEditorPrerequisite> ProxyControlConditions() const { return Read<TArray<FJamDeckProxyControlEditorPrerequisite>>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x10, Type: ArrayProperty)
    TArray<FJamDeckHotfixableProxySelection> PossibleProxyClasses() const { return Read<TArray<FJamDeckHotfixableProxySelection>>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x10, Type: ArrayProperty)
    AJamDeckProxy* SpawnedProxy() const { return Read<AJamDeckProxy*>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    AJamPlayspace* PertinentPlayspace() const { return Read<AJamPlayspace*>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x8, Type: ObjectProperty)
    bool bSupportAllPartsPlayback() const { return (Read<uint8_t>(uintptr_t(this) + 0x408) >> 0x0) & 1; } // 0x408:0 (Size: 0x1, Type: BoolProperty)
    bool bAllowNonJamEmotes() const { return (Read<uint8_t>(uintptr_t(this) + 0x408) >> 0x1) & 1; } // 0x408:1 (Size: 0x1, Type: BoolProperty)
    bool bAutoRemoveEmitterWhenOwningPlayerLeaves() const { return (Read<uint8_t>(uintptr_t(this) + 0x408) >> 0x2) & 1; } // 0x408:2 (Size: 0x1, Type: BoolProperty)

    void SET_CollisionResponse_AimMode(const FCollisionResponseContainer& Value) { Write<FCollisionResponseContainer>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x20, Type: StructProperty)
    void SET_CollisionResponse_OverlapMode(const FCollisionResponseContainer& Value) { Write<FCollisionResponseContainer>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x20, Type: StructProperty)
    void SET_ProxyControlConditions(const TArray<FJamDeckProxyControlEditorPrerequisite>& Value) { Write<TArray<FJamDeckProxyControlEditorPrerequisite>>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x10, Type: ArrayProperty)
    void SET_PossibleProxyClasses(const TArray<FJamDeckHotfixableProxySelection>& Value) { Write<TArray<FJamDeckHotfixableProxySelection>>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x10, Type: ArrayProperty)
    void SET_SpawnedProxy(const AJamDeckProxy*& Value) { Write<AJamDeckProxy*>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    void SET_PertinentPlayspace(const AJamPlayspace*& Value) { Write<AJamPlayspace*>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x8, Type: ObjectProperty)
    void SET_bSupportAllPartsPlayback(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x408); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x408, B); } // 0x408:0 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowNonJamEmotes(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x408); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x408, B); } // 0x408:1 (Size: 0x1, Type: BoolProperty)
    void SET_bAutoRemoveEmitterWhenOwningPlayerLeaves(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x408); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x408, B); } // 0x408:2 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x310
class AJamDeckProxy : public AActor
{
public:
    bool bShouldTieLifecycleToOwnersMusicSlot() const { return Read<bool>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x1, Type: BoolProperty)
    UJamMusicSlot* InUseMusicSlot() const { return Read<UJamMusicSlot*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)

    void SET_bShouldTieLifecycleToOwnersMusicSlot(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x1, Type: BoolProperty)
    void SET_InUseMusicSlot(const UJamMusicSlot*& Value) { Write<UJamMusicSlot*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x150
class UJamPlayspaceVolumeComponent_EmitterSpawner : public UActorComponent
{
public:
    UClass* EmitterClassToSpawn() const { return Read<UClass*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ClassProperty)
    TArray<FJamDeckProxyControlEditorPrerequisite> DefaultProxyControlPrerequisitesForEmitters() const { return Read<TArray<FJamDeckProxyControlEditorPrerequisite>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    TArray<FJamPlayspaceEmitterSpawner_SpawnableEmitterPlacementData> EmitterData() const { return Read<TArray<FJamPlayspaceEmitterSpawner_SpawnableEmitterPlacementData>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    int32_t AmountOfEmittersToSpawn() const { return Read<int32_t>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: IntProperty)
    int32_t AmountOfEmittersWithoutProxiesAllowed() const { return Read<int32_t>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x4, Type: IntProperty)

    void SET_EmitterClassToSpawn(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ClassProperty)
    void SET_DefaultProxyControlPrerequisitesForEmitters(const TArray<FJamDeckProxyControlEditorPrerequisite>& Value) { Write<TArray<FJamDeckProxyControlEditorPrerequisite>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    void SET_EmitterData(const TArray<FJamPlayspaceEmitterSpawner_SpawnableEmitterPlacementData>& Value) { Write<TArray<FJamPlayspaceEmitterSpawner_SpawnableEmitterPlacementData>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    void SET_AmountOfEmittersToSpawn(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: IntProperty)
    void SET_AmountOfEmittersWithoutProxiesAllowed(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x4, Type: IntProperty)
};

// Size: 0x70
struct FJamDeckProxyControlEditorPrerequisite
{
public:
    uint8_t ControlType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FGameplayTagQuery TagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x48, Type: StructProperty)

    void SET_ControlType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_TagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x48, Type: StructProperty)
};

// Size: 0x38
struct FJamDeckHotfixableProxySelection
{
public:
    int32_t CVarValue() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)

    void SET_CVarValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
};

// Size: 0x8
struct FJamDecksEventReactionBase
{
public:
};

// Size: 0x10
struct FJamDecksEventReactionParams
{
public:
    UObject* Target() const { return Read<UObject*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UObject* Source() const { return Read<UObject*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Target(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Source(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FJamDecksEventReactionComponentSelection
{
public:
    TArray<FName> ComponentTagsToInclude() const { return Read<TArray<FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_ComponentTagsToInclude(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FJamEventReactionComponentVisibilitySetting
{
public:
    FJamDecksEventReactionComponentSelection ComponentSelection() const { return Read<FJamDecksEventReactionComponentSelection>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    uint8_t NewVisibilitySetting() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    bool bApplyToChildrenComponents() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)

    void SET_ComponentSelection(const FJamDecksEventReactionComponentSelection& Value) { Write<FJamDecksEventReactionComponentSelection>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_NewVisibilitySetting(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_bApplyToChildrenComponents(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FJamDecksEventReaction_ManageComponentVisibility : public FJamDecksEventReactionBase
{
public:
    TArray<FJamEventReactionComponentVisibilitySetting> Settings() const { return Read<TArray<FJamEventReactionComponentVisibilitySetting>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Settings(const TArray<FJamEventReactionComponentVisibilitySetting>& Value) { Write<TArray<FJamEventReactionComponentVisibilitySetting>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FJamDecksEventReaction_UpdateSpecificStaticMeshComponentSetting
{
public:
    FJamDecksEventReactionComponentSelection ComponentSelection() const { return Read<FJamDecksEventReactionComponentSelection>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    UStaticMesh* StaticMeshToApply() const { return Read<UStaticMesh*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_ComponentSelection(const FJamDecksEventReactionComponentSelection& Value) { Write<FJamDecksEventReactionComponentSelection>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_StaticMeshToApply(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x18
struct FJamDecksEventReaction_UpdateSpecificStaticMeshComponent : public FJamDecksEventReactionBase
{
public:
    TArray<FJamDecksEventReaction_UpdateSpecificStaticMeshComponentSetting> Settings() const { return Read<TArray<FJamDecksEventReaction_UpdateSpecificStaticMeshComponentSetting>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Settings(const TArray<FJamDecksEventReaction_UpdateSpecificStaticMeshComponentSetting>& Value) { Write<TArray<FJamDecksEventReaction_UpdateSpecificStaticMeshComponentSetting>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FJamDecksStateTreeTask_PerformReactionsInfo
{
public:
    TArray<FInstancedStruct> ReactionsToPerform() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_ReactionsToPerform(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FJamDecksStateTreeTask_PerformReactionsInstanceData
{
public:
    FJamDecksStateTreeTask_PerformReactionsInfo ReactionInfo() const { return Read<FJamDecksStateTreeTask_PerformReactionsInfo>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    UObject* SourceObject() const { return Read<UObject*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    uint8_t ResultStatus() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)

    void SET_ReactionInfo(const FJamDecksStateTreeTask_PerformReactionsInfo& Value) { Write<FJamDecksStateTreeTask_PerformReactionsInfo>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_SourceObject(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_ResultStatus(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x20
struct FJamDecksStateTreeTask_PerformReactions : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x10
struct FJamDecksStateTreeEventDesc
{
public:
    FGameplayTag Tag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    UScriptStruct* PayloadStruct() const { return Read<UScriptStruct*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Tag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_PayloadStruct(const UScriptStruct*& Value) { Write<UScriptStruct*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x18
struct FJamDecksStateTreeTask_TrackEvents_TrackedEventData
{
public:
    FJamDecksStateTreeEventDesc EventDescription() const { return Read<FJamDecksStateTreeEventDesc>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    int32_t NewValue() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    bool bConsumeEvent() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)

    void SET_EventDescription(const FJamDecksStateTreeEventDesc& Value) { Write<FJamDecksStateTreeEventDesc>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_NewValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_bConsumeEvent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FJamDecksStateTreeTask_TrackEventsInstanceData
{
public:
    TArray<FJamDecksStateTreeTask_TrackEvents_TrackedEventData> ObservedEvents() const { return Read<TArray<FJamDecksStateTreeTask_TrackEvents_TrackedEventData>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t Result() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_ObservedEvents(const TArray<FJamDecksStateTreeTask_TrackEvents_TrackedEventData>& Value) { Write<TArray<FJamDecksStateTreeTask_TrackEvents_TrackedEventData>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Result(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x20
struct FJamDecksStateTreeTask_TrackEvents : public FStateTreeTaskCommonBase
{
public:
};

// Size: 0x80
struct FJamPlayspaceEmitterSpawner_SpawnableEmitterPlacementData
{
public:
    AJamDeckEmitter* SpawnedEmitter() const { return Read<AJamDeckEmitter*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_SpawnedEmitter(const AJamDeckEmitter*& Value) { Write<AJamDeckEmitter*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

