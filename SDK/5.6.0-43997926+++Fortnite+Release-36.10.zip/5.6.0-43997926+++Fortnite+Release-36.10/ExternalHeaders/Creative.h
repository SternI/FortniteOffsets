/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Creative
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "AIModule.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "GameplayAbilities.h"

// Size: 0x270
class UCreativeTeamColors_C : public USceneComponent
{
public:
    TArray<FLinearColor> TeamLightColors() const { return Read<TArray<FLinearColor>>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x10, Type: ArrayProperty)
    TArray<FLinearColor> TeamSelectorColors() const { return Read<TArray<FLinearColor>>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x10, Type: ArrayProperty)
    TArray<FLinearColor> TeamBoldColors() const { return Read<TArray<FLinearColor>>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x10, Type: ArrayProperty)

    void SET_TeamLightColors(const TArray<FLinearColor>& Value) { Write<TArray<FLinearColor>>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x10, Type: ArrayProperty)
    void SET_TeamSelectorColors(const TArray<FLinearColor>& Value) { Write<TArray<FLinearColor>>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x10, Type: ArrayProperty)
    void SET_TeamBoldColors(const TArray<FLinearColor>& Value) { Write<TArray<FLinearColor>>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa68
class UGE_LaunchedByVent_C : public UGameplayEffect
{
public:
};

// Size: 0x28
class UCreative_CommonAIFunctionLibrary_C : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UCreative_CommonDeviceFunctionLibrary_C : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0xbe4
class UGA_Creative_OnKillSiphon_C : public UGAT_Creative_TriggeredAbility_Pawn_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xba0); } // 0xba0 (Size: 0x8, Type: StructProperty)
    AFortGameStateAthena* GameState() const { return Read<AFortGameStateAthena*>(uintptr_t(this) + 0xba8); } // 0xba8 (Size: 0x8, Type: ObjectProperty)
    bool IsCreativeOrPlayground() const { return Read<bool>(uintptr_t(this) + 0xbb0); } // 0xbb0 (Size: 0x1, Type: BoolProperty)
    UClass* GE_HealPlayer() const { return Read<UClass*>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x8, Type: ClassProperty)
    bool bShouldConvertExcessHealthToShields() const { return Read<bool>(uintptr_t(this) + 0xbc0); } // 0xbc0 (Size: 0x1, Type: BoolProperty)
    UClass* ShieldGE() const { return Read<UClass*>(uintptr_t(this) + 0xbc8); } // 0xbc8 (Size: 0x8, Type: ClassProperty)
    FGameplayTag ConsumedCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xbd0); } // 0xbd0 (Size: 0x4, Type: StructProperty)
    bool bDebugBypasLocalMapEnable() const { return Read<bool>(uintptr_t(this) + 0xbd4); } // 0xbd4 (Size: 0x1, Type: BoolProperty)
    bool bAttemptHealthRestore() const { return Read<bool>(uintptr_t(this) + 0xbd5); } // 0xbd5 (Size: 0x1, Type: BoolProperty)
    bool bAttemptMatsRestore() const { return Read<bool>(uintptr_t(this) + 0xbd6); } // 0xbd6 (Size: 0x1, Type: BoolProperty)
    FName NameGrantWood() const { return Read<FName>(uintptr_t(this) + 0xbd8); } // 0xbd8 (Size: 0x4, Type: NameProperty)
    FName NameGrantStone() const { return Read<FName>(uintptr_t(this) + 0xbdc); } // 0xbdc (Size: 0x4, Type: NameProperty)
    FName NameGrantMetal() const { return Read<FName>(uintptr_t(this) + 0xbe0); } // 0xbe0 (Size: 0x4, Type: NameProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xba0, Value); } // 0xba0 (Size: 0x8, Type: StructProperty)
    void SET_GameState(const AFortGameStateAthena*& Value) { Write<AFortGameStateAthena*>(uintptr_t(this) + 0xba8, Value); } // 0xba8 (Size: 0x8, Type: ObjectProperty)
    void SET_IsCreativeOrPlayground(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbb0, Value); } // 0xbb0 (Size: 0x1, Type: BoolProperty)
    void SET_GE_HealPlayer(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x8, Type: ClassProperty)
    void SET_bShouldConvertExcessHealthToShields(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbc0, Value); } // 0xbc0 (Size: 0x1, Type: BoolProperty)
    void SET_ShieldGE(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xbc8, Value); } // 0xbc8 (Size: 0x8, Type: ClassProperty)
    void SET_ConsumedCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xbd0, Value); } // 0xbd0 (Size: 0x4, Type: StructProperty)
    void SET_bDebugBypasLocalMapEnable(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbd4, Value); } // 0xbd4 (Size: 0x1, Type: BoolProperty)
    void SET_bAttemptHealthRestore(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbd5, Value); } // 0xbd5 (Size: 0x1, Type: BoolProperty)
    void SET_bAttemptMatsRestore(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbd6, Value); } // 0xbd6 (Size: 0x1, Type: BoolProperty)
    void SET_NameGrantWood(const FName& Value) { Write<FName>(uintptr_t(this) + 0xbd8, Value); } // 0xbd8 (Size: 0x4, Type: NameProperty)
    void SET_NameGrantStone(const FName& Value) { Write<FName>(uintptr_t(this) + 0xbdc, Value); } // 0xbdc (Size: 0x4, Type: NameProperty)
    void SET_NameGrantMetal(const FName& Value) { Write<FName>(uintptr_t(this) + 0xbe0, Value); } // 0xbe0 (Size: 0x4, Type: NameProperty)
};

// Size: 0xba0
class UGAT_Creative_TriggeredAbility_Pawn_C : public UGAT_Creative_TriggeredAbility_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x8, Type: StructProperty)
    AFortPawn* AbilityOwner() const { return Read<AFortPawn*>(uintptr_t(this) + 0xb98); } // 0xb98 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x8, Type: StructProperty)
    void SET_AbilityOwner(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0xb98, Value); } // 0xb98 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xb90
class UGAT_Creative_TriggeredAbility_C : public UGAT_TriggeredAbility_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: StructProperty)
    TArray<FName> OverriddenPropertyNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x10, Type: ArrayProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: StructProperty)
    void SET_OverriddenPropertyNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FPawnHighlight
{
public:
    float Priority_28_E2E1B5344846E187B9C11B863A7F0698() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FLinearColor Inner_21_4CC2801147EA190DE16F59B34F36853E() const { return Read<FLinearColor>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x10, Type: StructProperty)
    FLinearColor Outer_22_5A1D7D0543D303E8B54B66A7F7BD2E2E() const { return Read<FLinearColor>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x10, Type: StructProperty)
    float FresnelBrightness_23_52B0F96447FF640F47DF2895B0602E92() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float FresnelExponent_24_B427CF0C441AA37ED49833BF7579DE6D() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float UsesPulse_25_E29229F64E540F0617E4C4987AD77605() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)

    void SET_Priority_28_E2E1B5344846E187B9C11B863A7F0698(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Inner_21_4CC2801147EA190DE16F59B34F36853E(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x10, Type: StructProperty)
    void SET_Outer_22_5A1D7D0543D303E8B54B66A7F7BD2E2E(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x10, Type: StructProperty)
    void SET_FresnelBrightness_23_52B0F96447FF640F47DF2895B0602E92(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_FresnelExponent_24_B427CF0C441AA37ED49833BF7579DE6D(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_UsesPulse_25_E29229F64E540F0617E4C4987AD77605(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
};

// Size: 0xe10
class AMilitaryBase_Door_01_C : public AParent_BuildingWall_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xd80); } // 0xd80 (Size: 0x8, Type: StructProperty)
    UBoxComponent* DoorSlideOverlapVolume() const { return Read<UBoxComponent*>(uintptr_t(this) + 0xd88); } // 0xd88 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* DoorStaticMesh1() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0xd90); } // 0xd90 (Size: 0x8, Type: ObjectProperty)
    float Timeline_0_EmissiveColorLerp_75727DFA4F9CA24A009D23ADC967876F() const { return Read<float>(uintptr_t(this) + 0xd98); } // 0xd98 (Size: 0x4, Type: FloatProperty)
    float Timeline_0_SlideAnimation_75727DFA4F9CA24A009D23ADC967876F() const { return Read<float>(uintptr_t(this) + 0xd9c); } // 0xd9c (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_0__Direction_75727DFA4F9CA24A009D23ADC967876F() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xda0); } // 0xda0 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Timeline_0() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0xda8); } // 0xda8 (Size: 0x8, Type: ObjectProperty)
    int32_t NumberOfPawnsWithinVolume() const { return Read<int32_t>(uintptr_t(this) + 0xdb0); } // 0xdb0 (Size: 0x4, Type: IntProperty)
    bool DoorOpen() const { return Read<bool>(uintptr_t(this) + 0xdb4); } // 0xdb4 (Size: 0x1, Type: BoolProperty)
    UMaterialInstanceDynamic* DoorMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0xdb8); } // 0xdb8 (Size: 0x8, Type: ObjectProperty)
    FLinearColor DefaultDoorEmissiveValue() const { return Read<FLinearColor>(uintptr_t(this) + 0xdc0); } // 0xdc0 (Size: 0x10, Type: StructProperty)
    FLinearColor ActiveDoorEmissiveValue() const { return Read<FLinearColor>(uintptr_t(this) + 0xdd0); } // 0xdd0 (Size: 0x10, Type: StructProperty)
    UMaterialInterface* DoorBaseMaterial() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0xde0); } // 0xde0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* Door_Source_Materials() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0xde8); } // 0xde8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SlidingDoorClose_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0xdf0); } // 0xdf0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SlidingDoorOpen_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0xdf8); } // 0xdf8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xd80, Value); } // 0xd80 (Size: 0x8, Type: StructProperty)
    void SET_DoorSlideOverlapVolume(const UBoxComponent*& Value) { Write<UBoxComponent*>(uintptr_t(this) + 0xd88, Value); } // 0xd88 (Size: 0x8, Type: ObjectProperty)
    void SET_DoorStaticMesh1(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0xd90, Value); } // 0xd90 (Size: 0x8, Type: ObjectProperty)
    void SET_Timeline_0_EmissiveColorLerp_75727DFA4F9CA24A009D23ADC967876F(const float& Value) { Write<float>(uintptr_t(this) + 0xd98, Value); } // 0xd98 (Size: 0x4, Type: FloatProperty)
    void SET_Timeline_0_SlideAnimation_75727DFA4F9CA24A009D23ADC967876F(const float& Value) { Write<float>(uintptr_t(this) + 0xd9c, Value); } // 0xd9c (Size: 0x4, Type: FloatProperty)
    void SET_Timeline_0__Direction_75727DFA4F9CA24A009D23ADC967876F(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xda0, Value); } // 0xda0 (Size: 0x1, Type: ByteProperty)
    void SET_Timeline_0(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0xda8, Value); } // 0xda8 (Size: 0x8, Type: ObjectProperty)
    void SET_NumberOfPawnsWithinVolume(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xdb0, Value); } // 0xdb0 (Size: 0x4, Type: IntProperty)
    void SET_DoorOpen(const bool& Value) { Write<bool>(uintptr_t(this) + 0xdb4, Value); } // 0xdb4 (Size: 0x1, Type: BoolProperty)
    void SET_DoorMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0xdb8, Value); } // 0xdb8 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultDoorEmissiveValue(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xdc0, Value); } // 0xdc0 (Size: 0x10, Type: StructProperty)
    void SET_ActiveDoorEmissiveValue(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xdd0, Value); } // 0xdd0 (Size: 0x10, Type: StructProperty)
    void SET_DoorBaseMaterial(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0xde0, Value); } // 0xde0 (Size: 0x8, Type: ObjectProperty)
    void SET_Door_Source_Materials(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0xde8, Value); } // 0xde8 (Size: 0x8, Type: ObjectProperty)
    void SET_SlidingDoorClose_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xdf0, Value); } // 0xdf0 (Size: 0x8, Type: ObjectProperty)
    void SET_SlidingDoorOpen_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xdf8, Value); } // 0xdf8 (Size: 0x8, Type: ObjectProperty)
};

