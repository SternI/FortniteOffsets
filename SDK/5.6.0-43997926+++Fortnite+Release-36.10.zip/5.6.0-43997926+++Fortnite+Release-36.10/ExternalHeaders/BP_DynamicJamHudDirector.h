/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_DynamicJamHudDirector
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "DynamicUI.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "PlayspaceSystem.h"
#include "Engine.h"
#include "GameplayAbilities.h"
#include "InputPromptManagerRuntime.h"

// Size: 0x310
class ABP_DynamicJamHudDirector_C : public ADynamicUIDirectorBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: StructProperty)
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* StartJamPromptScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* LoudStartJamPromptScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    bool bHaveAddedStartJamPrompt() const { return Read<bool>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x1, Type: BoolProperty)
    UAbilityAsync_WaitGameplayTagRemoved* RemoveShowWhenInPlayspaceTagListener() const { return Read<UAbilityAsync_WaitGameplayTagRemoved*>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UAbilityAsync_WaitGameplayTagAdded* AddShowWhenInPlayspaceTagListener() const { return Read<UAbilityAsync_WaitGameplayTagAdded*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    TArray<UInputAlias*> Active_Input_Aliases() const { return Read<TArray<UInputAlias*>>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x10, Type: ArrayProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: StructProperty)
    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    void SET_StartJamPromptScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    void SET_LoudStartJamPromptScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    void SET_bHaveAddedStartJamPrompt(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x1, Type: BoolProperty)
    void SET_RemoveShowWhenInPlayspaceTagListener(const UAbilityAsync_WaitGameplayTagRemoved*& Value) { Write<UAbilityAsync_WaitGameplayTagRemoved*>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    void SET_AddShowWhenInPlayspaceTagListener(const UAbilityAsync_WaitGameplayTagAdded*& Value) { Write<UAbilityAsync_WaitGameplayTagAdded*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    void SET_Active_Input_Aliases(const TArray<UInputAlias*>& Value) { Write<TArray<UInputAlias*>>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x10, Type: ArrayProperty)
};

