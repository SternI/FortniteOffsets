/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BlastBerryUIRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"
#include "FortniteUI.h"
#include "Engine.h"
#include "CommonUI.h"

// Size: 0x88
class UFortMobileActionButtonBehaviorExtension_Reboot : public UFortMobileActionButtonBehaviorExtension
{
public:
};

// Size: 0x630
class UBlastBerryDeathLocationIndicator : public UAthenaEliminationIndicator
{
public:
};

// Size: 0x3e0
class UBlastBerryInstantRebootWidget : public UFortHUDElementWidget
{
public:
    float HoldDuration() const { return Read<float>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x4, Type: FloatProperty)
    float InvulnerabilityRespawnDisplayDelay() const { return Read<float>(uintptr_t(this) + 0x38c); } // 0x38c (Size: 0x4, Type: FloatProperty)
    FGameplayTag InvulnerabilityGameplayTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x4, Type: StructProperty)
    UFortKeybindWidget* KeybindWidget() const { return Read<UFortKeybindWidget*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    UInputComponent* BlastBerryInstantRebootInputComponent() const { return Read<UInputComponent*>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UAbilitySystemComponent*> OwnerASC() const { return Read<TWeakObjectPtr<UAbilitySystemComponent*>>(uintptr_t(this) + 0x3cc); } // 0x3cc (Size: 0x8, Type: WeakObjectProperty)

    void SET_HoldDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x4, Type: FloatProperty)
    void SET_InvulnerabilityRespawnDisplayDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x38c, Value); } // 0x38c (Size: 0x4, Type: FloatProperty)
    void SET_InvulnerabilityGameplayTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x4, Type: StructProperty)
    void SET_KeybindWidget(const UFortKeybindWidget*& Value) { Write<UFortKeybindWidget*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    void SET_BlastBerryInstantRebootInputComponent(const UInputComponent*& Value) { Write<UInputComponent*>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    void SET_OwnerASC(const TWeakObjectPtr<UAbilitySystemComponent*>& Value) { Write<TWeakObjectPtr<UAbilitySystemComponent*>>(uintptr_t(this) + 0x3cc, Value); } // 0x3cc (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x3b0
class UBlastBerryPlayerInfoRespawn : public UFortHUDElementWidget
{
public:
    TWeakObjectPtr<AFortPlayerStateAthena*> WeakPlayerStateAthena_RepresentedPlayer() const { return Read<TWeakObjectPtr<AFortPlayerStateAthena*>>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: WeakObjectProperty)
    UCommonTextBlock* Text_Time() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ObjectProperty)

    void SET_WeakPlayerStateAthena_RepresentedPlayer(const TWeakObjectPtr<AFortPlayerStateAthena*>& Value) { Write<TWeakObjectPtr<AFortPlayerStateAthena*>>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Text_Time(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ObjectProperty)
};

