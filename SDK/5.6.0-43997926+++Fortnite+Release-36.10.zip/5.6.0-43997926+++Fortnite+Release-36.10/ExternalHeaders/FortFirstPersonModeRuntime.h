/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortFirstPersonModeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "AnimationBudgetAllocator.h"

// Size: 0x5b0
class AFortFirstPersonMode_CameraController : public AFortFirstPersonCameraController
{
public:
    float HeadMotionScalar() const { return Read<float>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x4, Type: FloatProperty)
    bool bDisplayReticleWhileADS() const { return Read<bool>(uintptr_t(this) + 0x51c); } // 0x51c (Size: 0x1, Type: BoolProperty)
    bool bDisplayAmmoCountWhileADS() const { return Read<bool>(uintptr_t(this) + 0x51d); } // 0x51d (Size: 0x1, Type: BoolProperty)
    TArray<UClass*> AllowedWeaponClassList() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x520); } // 0x520 (Size: 0x10, Type: ArrayProperty)
    UMaterialParameterCollection* MaterialParameterCollection() const { return Read<UMaterialParameterCollection*>(uintptr_t(this) + 0x530); } // 0x530 (Size: 0x8, Type: ObjectProperty)
    FName FP_MaterialParameterName() const { return Read<FName>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x4, Type: NameProperty)
    UCustomCharacterPart* DefaultGauntletPart() const { return Read<UCustomCharacterPart*>(uintptr_t(this) + 0x540); } // 0x540 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponentBudgeted* FirstPersonSkeletalMeshComp() const { return Read<USkeletalMeshComponentBudgeted*>(uintptr_t(this) + 0x548); } // 0x548 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponentBudgeted* KicksSkeletalMeshComp() const { return Read<USkeletalMeshComponentBudgeted*>(uintptr_t(this) + 0x550); } // 0x550 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponentBudgeted* GauntletSkeletalMeshComp() const { return Read<USkeletalMeshComponentBudgeted*>(uintptr_t(this) + 0x558); } // 0x558 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponentBudgeted* ThirdPersonWeaponMeshComp() const { return Read<USkeletalMeshComponentBudgeted*>(uintptr_t(this) + 0x560); } // 0x560 (Size: 0x8, Type: ObjectProperty)
    float CameraYawClampAngleForStasis() const { return Read<float>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x4, Type: FloatProperty)
    UClass* CachedOutgoingCameraMode() const { return Read<UClass*>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x8, Type: ClassProperty)

    void SET_HeadMotionScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x4, Type: FloatProperty)
    void SET_bDisplayReticleWhileADS(const bool& Value) { Write<bool>(uintptr_t(this) + 0x51c, Value); } // 0x51c (Size: 0x1, Type: BoolProperty)
    void SET_bDisplayAmmoCountWhileADS(const bool& Value) { Write<bool>(uintptr_t(this) + 0x51d, Value); } // 0x51d (Size: 0x1, Type: BoolProperty)
    void SET_AllowedWeaponClassList(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x520, Value); } // 0x520 (Size: 0x10, Type: ArrayProperty)
    void SET_MaterialParameterCollection(const UMaterialParameterCollection*& Value) { Write<UMaterialParameterCollection*>(uintptr_t(this) + 0x530, Value); } // 0x530 (Size: 0x8, Type: ObjectProperty)
    void SET_FP_MaterialParameterName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x4, Type: NameProperty)
    void SET_DefaultGauntletPart(const UCustomCharacterPart*& Value) { Write<UCustomCharacterPart*>(uintptr_t(this) + 0x540, Value); } // 0x540 (Size: 0x8, Type: ObjectProperty)
    void SET_FirstPersonSkeletalMeshComp(const USkeletalMeshComponentBudgeted*& Value) { Write<USkeletalMeshComponentBudgeted*>(uintptr_t(this) + 0x548, Value); } // 0x548 (Size: 0x8, Type: ObjectProperty)
    void SET_KicksSkeletalMeshComp(const USkeletalMeshComponentBudgeted*& Value) { Write<USkeletalMeshComponentBudgeted*>(uintptr_t(this) + 0x550, Value); } // 0x550 (Size: 0x8, Type: ObjectProperty)
    void SET_GauntletSkeletalMeshComp(const USkeletalMeshComponentBudgeted*& Value) { Write<USkeletalMeshComponentBudgeted*>(uintptr_t(this) + 0x558, Value); } // 0x558 (Size: 0x8, Type: ObjectProperty)
    void SET_ThirdPersonWeaponMeshComp(const USkeletalMeshComponentBudgeted*& Value) { Write<USkeletalMeshComponentBudgeted*>(uintptr_t(this) + 0x560, Value); } // 0x560 (Size: 0x8, Type: ObjectProperty)
    void SET_CameraYawClampAngleForStasis(const float& Value) { Write<float>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x4, Type: FloatProperty)
    void SET_CachedOutgoingCameraMode(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x30
class UFortFirstPersonMode_CheatManager : public UChildCheatManager
{
public:
    UClass* CameraControllerClass() const { return Read<UClass*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ClassProperty)

    void SET_CameraControllerClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x8
struct FCameraModeRotationClampSettings
{
public:
};

