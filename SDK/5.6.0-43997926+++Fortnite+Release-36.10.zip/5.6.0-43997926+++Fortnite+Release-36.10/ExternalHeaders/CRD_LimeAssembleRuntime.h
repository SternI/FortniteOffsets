/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_LimeAssembleRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "GameplayAbilities.h"

// Size: 0x1d0
class UAtomGeometryAssemblyComponent : public UActorComponent
{
public:
    uint8_t AssemblyEventFlags() const { return Read<uint8_t>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x1, Type: EnumProperty)
    FAtomAssemblyState AssemblyState() const { return Read<FAtomAssemblyState>(uintptr_t(this) + 0x12c); } // 0x12c (Size: 0xc, Type: StructProperty)
    FAtomAssemblyCollision AssemblyCollision() const { return Read<FAtomAssemblyCollision>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x2, Type: StructProperty)
    FAtomAssemblyRange MarshalledRange() const { return Read<FAtomAssemblyRange>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x18, Type: StructProperty)

    void SET_AssemblyEventFlags(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x1, Type: EnumProperty)
    void SET_AssemblyState(const FAtomAssemblyState& Value) { Write<FAtomAssemblyState>(uintptr_t(this) + 0x12c, Value); } // 0x12c (Size: 0xc, Type: StructProperty)
    void SET_AssemblyCollision(const FAtomAssemblyCollision& Value) { Write<FAtomAssemblyCollision>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x2, Type: StructProperty)
    void SET_MarshalledRange(const FAtomAssemblyRange& Value) { Write<FAtomAssemblyRange>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x18, Type: StructProperty)
};

// Size: 0x28
class ULimeAssembleBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x160
class ULimeAssembleComponent : public UActorComponent
{
public:
    TArray<TSoftObjectPtr<AActor*>> TargetActors() const { return Read<TArray<TSoftObjectPtr<AActor*>>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    AActor* ContextActor() const { return Read<AActor*>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer IgnoredActorTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x20, Type: StructProperty)

    void SET_TargetActors(const TArray<TSoftObjectPtr<AActor*>>& Value) { Write<TArray<TSoftObjectPtr<AActor*>>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    void SET_ContextActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    void SET_IgnoredActorTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x1c0
class ULimeAssembleContextActorComponent : public UActorComponent
{
public:
    bool bNormalizeAssembly() const { return Read<bool>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x1, Type: BoolProperty)
    TArray<AActor*> TargetActors() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x10, Type: ArrayProperty)
    FBox Bounds() const { return Read<FBox>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x38, Type: StructProperty)
    uint8_t LastEvent() const { return Read<uint8_t>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x1, Type: EnumProperty)

    void SET_bNormalizeAssembly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x1, Type: BoolProperty)
    void SET_TargetActors(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x10, Type: ArrayProperty)
    void SET_Bounds(const FBox& Value) { Write<FBox>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x38, Type: StructProperty)
    void SET_LastEvent(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x1f0
class ULimeGeometryAssemblyComponent : public UAtomGeometryAssemblyComponent
{
public:
    UClass* DamageImmunityEffectClass() const { return Read<UClass*>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x8, Type: ClassProperty)
    AActor* PreviewActor() const { return Read<AActor*>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    bool bWantsPreviewActorVisible() const { return Read<bool>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x1, Type: BoolProperty)
    bool bIsPreviewActorVisible() const { return Read<bool>(uintptr_t(this) + 0x1e1); } // 0x1e1 (Size: 0x1, Type: BoolProperty)
    FActiveGameplayEffectHandle DamageImmunityHandle() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x1e4); } // 0x1e4 (Size: 0x8, Type: StructProperty)

    void SET_DamageImmunityEffectClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x8, Type: ClassProperty)
    void SET_PreviewActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    void SET_bWantsPreviewActorVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsPreviewActorVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e1, Value); } // 0x1e1 (Size: 0x1, Type: BoolProperty)
    void SET_DamageImmunityHandle(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x1e4, Value); } // 0x1e4 (Size: 0x8, Type: StructProperty)
};

// Size: 0x268
class ULimeGeometryAssemblyComponent_BrickRain : public ULimeGeometryAssemblyComponent
{
public:
    int32_t TotalGeometryCount() const { return Read<int32_t>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x4, Type: IntProperty)
    float GeometryAssemblyRate() const { return Read<float>(uintptr_t(this) + 0x1f4); } // 0x1f4 (Size: 0x4, Type: FloatProperty)
    float SingleGeometryDuration() const { return Read<float>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x4, Type: FloatProperty)
    float DisassembledZDistance() const { return Read<float>(uintptr_t(this) + 0x1fc); } // 0x1fc (Size: 0x4, Type: FloatProperty)
    float DisassembledZDistanceRandomRatio() const { return Read<float>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x4, Type: FloatProperty)
    float DisassembledRotationAmount() const { return Read<float>(uintptr_t(this) + 0x204); } // 0x204 (Size: 0x4, Type: FloatProperty)

    void SET_TotalGeometryCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x4, Type: IntProperty)
    void SET_GeometryAssemblyRate(const float& Value) { Write<float>(uintptr_t(this) + 0x1f4, Value); } // 0x1f4 (Size: 0x4, Type: FloatProperty)
    void SET_SingleGeometryDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x4, Type: FloatProperty)
    void SET_DisassembledZDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x1fc, Value); } // 0x1fc (Size: 0x4, Type: FloatProperty)
    void SET_DisassembledZDistanceRandomRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x4, Type: FloatProperty)
    void SET_DisassembledRotationAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x204, Value); } // 0x204 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc
struct FAtomAssemblyState
{
public:
    FName CurrentState() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    float CurrentRatio() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float TargetRatio() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_CurrentState(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_CurrentRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_TargetRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x2
struct FAtomAssemblyCollision
{
public:
    bool bOverrideCollisionEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x0) & 1; } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<ECollisionEnabled> CollisionEnabled() const { return Read<TEnumAsByte<ECollisionEnabled>>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: ByteProperty)

    void SET_bOverrideCollisionEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    void SET_CollisionEnabled(const TEnumAsByte<ECollisionEnabled>& Value) { Write<TEnumAsByte<ECollisionEnabled>>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x18
struct FAtomAssemblyRange
{
public:
    bool bHasValue() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x0) & 1; } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    double RangeMin() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    double RangeMax() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)

    void SET_bHasValue(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    void SET_RangeMin(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_RangeMax(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
};

