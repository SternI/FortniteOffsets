/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DynamicPoiPointProviderRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "FortniteGame.h"
#include "FortniteAI.h"
#include "GameplayTags.h"
#include "CoreUObject.h"
#include "LagerRuntime.h"

// Size: 0xd0
class UAIServiceDynamicPoiPointProvider : public UAthenaAIService
{
public:
    FGameplayTagContainer DynamicPOIPointProviderTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x20, Type: StructProperty)
    uint8_t SpawnLimiterBehavior() const { return Read<uint8_t>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: EnumProperty)
    TArray<FDynamicPOIMaxActorCondition> MaxActorConditions() const { return Read<TArray<FDynamicPOIMaxActorCondition>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
    int32_t DefaultMaxActorCount() const { return Read<int32_t>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: IntProperty)
    UAthenaAIServicePlayerBots* CachedAIServicePlayerBots() const { return Read<UAthenaAIServicePlayerBots*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    TArray<UDynamicPoiPointProvider*> DynamicPoiPointProviders() const { return Read<TArray<UDynamicPoiPointProvider*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: ArrayProperty)

    void SET_DynamicPOIPointProviderTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x20, Type: StructProperty)
    void SET_SpawnLimiterBehavior(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: EnumProperty)
    void SET_MaxActorConditions(const TArray<FDynamicPOIMaxActorCondition>& Value) { Write<TArray<FDynamicPOIMaxActorCondition>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
    void SET_DefaultMaxActorCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: IntProperty)
    void SET_CachedAIServicePlayerBots(const UAthenaAIServicePlayerBots*& Value) { Write<UAthenaAIServicePlayerBots*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_DynamicPoiPointProviders(const TArray<UDynamicPoiPointProvider*>& Value) { Write<TArray<UDynamicPoiPointProvider*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x118
class UDynamicPoiPointProvider : public UObject
{
public:
    AFortGameStateAthena* CachedGameState() const { return Read<AFortGameStateAthena*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaLivingWorldManager* CachedLivingWorldManager() const { return Read<UFortAthenaLivingWorldManager*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer PointProviderFiltersTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: StructProperty)
    FFortAthenaLivingWorldPointProviderSpawnLimiter SpawnLimiter() const { return Read<FFortAthenaLivingWorldPointProviderSpawnLimiter>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x68, Type: StructProperty)
    FBox Box() const { return Read<FBox>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x38, Type: StructProperty)
    TArray<FVector> Locations() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: ArrayProperty)

    void SET_CachedGameState(const AFortGameStateAthena*& Value) { Write<AFortGameStateAthena*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedLivingWorldManager(const UFortAthenaLivingWorldManager*& Value) { Write<UFortAthenaLivingWorldManager*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_PointProviderFiltersTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: StructProperty)
    void SET_SpawnLimiter(const FFortAthenaLivingWorldPointProviderSpawnLimiter& Value) { Write<FFortAthenaLivingWorldPointProviderSpawnLimiter>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x68, Type: StructProperty)
    void SET_Box(const FBox& Value) { Write<FBox>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x38, Type: StructProperty)
    void SET_Locations(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xc
struct FDynamicPOIMaxActorCondition
{
public:
    float MinAreaSize() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxAreaSize() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    int32_t MaxCount() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)

    void SET_MinAreaSize(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxAreaSize(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MaxCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
};

