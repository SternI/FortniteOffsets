/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EncountersRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "FortniteAI.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "Engine.h"
#include "DataRegistry.h"
#include "PlayspaceSystem.h"
#include "CoreUObject.h"
#include "LagerRuntime.h"
#include "WorldConditions.h"
#include "GameplayAbilities.h"
#include "VariableSelectionsRuntime.h"
#include "StateTreeModule.h"
#include "AIModule.h"

// Size: 0x2a8
class AEncounterGameplayCueActor : public AActor
{
public:
};

// Size: 0x2c8
class AEncounterMobAnchor : public AActor
{
public:
    FGameplayTagContainer FilterTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x20, Type: StructProperty)

    void SET_FilterTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x20, Type: StructProperty)
};

// Size: 0x230
class UEncounterMobManagerComponent : public UGameFrameworkComponent
{
public:
    TArray<FEncounterMobInstance> SpawnedMobs() const { return Read<TArray<FEncounterMobInstance>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TArray<FEncounterMobSpawnData> MobEncounterSpawnData() const { return Read<TArray<FEncounterMobSpawnData>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    FEncounterMobSpawnInfo DefaultMobSpawnInfo() const { return Read<FEncounterMobSpawnInfo>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0xa0, Type: StructProperty)
    FScalableFloat LWMDensityWeight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x28, Type: StructProperty)
    FScalableFloat LWMDensityRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x28, Type: StructProperty)
    TWeakObjectPtr<ALivingWorldEncounterPrefab*> EncounterPrefab() const { return Read<TWeakObjectPtr<ALivingWorldEncounterPrefab*>>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x8, Type: WeakObjectProperty)

    void SET_SpawnedMobs(const TArray<FEncounterMobInstance>& Value) { Write<TArray<FEncounterMobInstance>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    void SET_MobEncounterSpawnData(const TArray<FEncounterMobSpawnData>& Value) { Write<TArray<FEncounterMobSpawnData>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    void SET_DefaultMobSpawnInfo(const FEncounterMobSpawnInfo& Value) { Write<FEncounterMobSpawnInfo>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0xa0, Type: StructProperty)
    void SET_LWMDensityWeight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x28, Type: StructProperty)
    void SET_LWMDensityRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x28, Type: StructProperty)
    void SET_EncounterPrefab(const TWeakObjectPtr<ALivingWorldEncounterPrefab*>& Value) { Write<TWeakObjectPtr<ALivingWorldEncounterPrefab*>>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x40
class UEncounterWorldConditionSchema : public UWorldConditionSchema
{
public:
};

// Size: 0x178
class ULWMEncounterInstance : public UObject
{
public:
    TWeakObjectPtr<UFortAthenaLivingWorldEncounterInstance*> LWMInstance() const { return Read<TWeakObjectPtr<UFortAthenaLivingWorldEncounterInstance*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    TArray<TWeakObjectPtr<AFortPawn*>> SpawnedMobPawns() const { return Read<TArray<TWeakObjectPtr<AFortPawn*>>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FLWMEncounterInstanceSavedTargetInfo> SavedTargetActors() const { return Read<TArray<FLWMEncounterInstanceSavedTargetInfo>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FLWMEncounterInstanceSavedFactionMods> SavedFactionMods() const { return Read<TArray<FLWMEncounterInstanceSavedFactionMods>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<AActor*> EncounterAnchorPoint() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AActor*> UserActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    TArray<TScriptInterface<Class>> ActivePointProviderInterfaces() const { return Read<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)

    void SET_LWMInstance(const TWeakObjectPtr<UFortAthenaLivingWorldEncounterInstance*>& Value) { Write<TWeakObjectPtr<UFortAthenaLivingWorldEncounterInstance*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    void SET_SpawnedMobPawns(const TArray<TWeakObjectPtr<AFortPawn*>>& Value) { Write<TArray<TWeakObjectPtr<AFortPawn*>>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_SavedTargetActors(const TArray<FLWMEncounterInstanceSavedTargetInfo>& Value) { Write<TArray<FLWMEncounterInstanceSavedTargetInfo>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_SavedFactionMods(const TArray<FLWMEncounterInstanceSavedFactionMods>& Value) { Write<TArray<FLWMEncounterInstanceSavedFactionMods>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_EncounterAnchorPoint(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_UserActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ActivePointProviderInterfaces(const TArray<TScriptInterface<Class>>& Value) { Write<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
class USpawnActorTaskHelper : public UObject
{
public:
};

// Size: 0xa0
class UEncounterActorSpawnerData : public UFortAthenaActorSpawnerData
{
public:
    FEncounterPrefabEntry EncounterEntry() const { return Read<FEncounterPrefabEntry>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x50, Type: StructProperty)

    void SET_EncounterEntry(const FEncounterPrefabEntry& Value) { Write<FEncounterPrefabEntry>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x50, Type: StructProperty)
};

// Size: 0x28
class UEncounterBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x9c0
class AEncounterCompositeVolume : public AEncounterGameplayVolume
{
public:
    FGameplayTagQuery VolumeTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x970); } // 0x970 (Size: 0x48, Type: StructProperty)
    bool bUseOverlappingVolumesOnly() const { return Read<bool>(uintptr_t(this) + 0x9b8); } // 0x9b8 (Size: 0x1, Type: BoolProperty)

    void SET_VolumeTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x970, Value); } // 0x970 (Size: 0x48, Type: StructProperty)
    void SET_bUseOverlappingVolumesOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9b8, Value); } // 0x9b8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x970
class AEncounterGameplayVolume : public AFortQuestManagerVolume
{
public:
    UEncounterStateTreeComponent* EncounterStateTreeComponent() const { return Read<UEncounterStateTreeComponent*>(uintptr_t(this) + 0x898); } // 0x898 (Size: 0x8, Type: ObjectProperty)
    TArray<TScriptInterface<Class>> TrackedEncounterPointProviders() const { return Read<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0x8a8); } // 0x8a8 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<AEncounterMobAnchor*>> TrackedEncounterAnchors() const { return Read<TArray<TWeakObjectPtr<AEncounterMobAnchor*>>>(uintptr_t(this) + 0x8b8); } // 0x8b8 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<AActor*>> TrackedActors() const { return Read<TArray<TWeakObjectPtr<AActor*>>>(uintptr_t(this) + 0x8c8); } // 0x8c8 (Size: 0x10, Type: ArrayProperty)
    TMap<FString, FString> AllVisitedPlayersMap() const { return Read<TMap<FString, FString>>(uintptr_t(this) + 0x8d8); } // 0x8d8 (Size: 0x50, Type: MapProperty)

    void SET_EncounterStateTreeComponent(const UEncounterStateTreeComponent*& Value) { Write<UEncounterStateTreeComponent*>(uintptr_t(this) + 0x898, Value); } // 0x898 (Size: 0x8, Type: ObjectProperty)
    void SET_TrackedEncounterPointProviders(const TArray<TScriptInterface<Class>>& Value) { Write<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0x8a8, Value); } // 0x8a8 (Size: 0x10, Type: ArrayProperty)
    void SET_TrackedEncounterAnchors(const TArray<TWeakObjectPtr<AEncounterMobAnchor*>>& Value) { Write<TArray<TWeakObjectPtr<AEncounterMobAnchor*>>>(uintptr_t(this) + 0x8b8, Value); } // 0x8b8 (Size: 0x10, Type: ArrayProperty)
    void SET_TrackedActors(const TArray<TWeakObjectPtr<AActor*>>& Value) { Write<TArray<TWeakObjectPtr<AActor*>>>(uintptr_t(this) + 0x8c8, Value); } // 0x8c8 (Size: 0x10, Type: ArrayProperty)
    void SET_AllVisitedPlayersMap(const TMap<FString, FString>& Value) { Write<TMap<FString, FString>>(uintptr_t(this) + 0x8d8, Value); } // 0x8d8 (Size: 0x50, Type: MapProperty)
};

// Size: 0x100
class UEncounterFactionData : public UPrimaryDataAsset
{
public:
    FGameplayTagContainer FactionCapabilities() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)
    FWorldConditionQueryDefinition WorldConditionDefinition() const { return Read<FWorldConditionQueryDefinition>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)
    UDataTable* LWMEncounterTable() const { return Read<UDataTable*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    FVariableSelections_Faction EnemiesSelection() const { return Read<FVariableSelections_Faction>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x90, Type: StructProperty)

    void SET_FactionCapabilities(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
    void SET_WorldConditionDefinition(const FWorldConditionQueryDefinition& Value) { Write<FWorldConditionQueryDefinition>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
    void SET_LWMEncounterTable(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_EnemiesSelection(const FVariableSelections_Faction& Value) { Write<FVariableSelections_Faction>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x90, Type: StructProperty)
};

// Size: 0x300
class UEncounterItemDefinition : public UFortItemDefinition
{
public:
    bool bAutoHandleSuccessFailure() const { return Read<bool>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    TSoftObjectPtr<UWorld> Level() const { return Read<TSoftObjectPtr<UWorld>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStateTree> StateTreeOverride() const { return Read<TSoftObjectPtr<UStateTree>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x20, Type: SoftObjectProperty)
    FGameplayCueTag ProximityGameplayCueTag() const { return Read<FGameplayCueTag>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: StructProperty)
    FGameplayCueTag ActorCleanupGameplayCueTag() const { return Read<FGameplayCueTag>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: StructProperty)
    bool bUseOverlapTestForActorCollection() const { return Read<bool>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x1, Type: BoolProperty)
    TArray<FEncounterLootEntry> SuccessRewards() const { return Read<TArray<FEncounterLootEntry>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> ReactionsToGrantOnSuccess() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: ArrayProperty)
    FEncounterRewardBehavior SuccessRewardBehavior() const { return Read<FEncounterRewardBehavior>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x80, Type: StructProperty)
    FGameplayCueTag ActorSuccessGameplayCueTag() const { return Read<FGameplayCueTag>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x4, Type: StructProperty)
    FGameplayCueTag PlayerSuccessGameplayCueTag() const { return Read<FGameplayCueTag>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: StructProperty)
    TArray<FEncounterLootEntry> FailureRewards() const { return Read<TArray<FEncounterLootEntry>>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> ReactionsToGrantOnFailure() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x10, Type: ArrayProperty)
    FEncounterRewardBehavior FailureRewardBehavior() const { return Read<FEncounterRewardBehavior>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x80, Type: StructProperty)
    FGameplayCueTag ActorFailureGameplayCueTag() const { return Read<FGameplayCueTag>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x4, Type: StructProperty)
    FGameplayCueTag PlayerFailureGameplayCueTag() const { return Read<FGameplayCueTag>(uintptr_t(this) + 0x24c); } // 0x24c (Size: 0x4, Type: StructProperty)
    FScalableFloat LWMDensityWeight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x28, Type: StructProperty)
    FScalableFloat LWMDensityRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x28, Type: StructProperty)
    bool bUseGlobalLWMBudget() const { return Read<bool>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x1, Type: BoolProperty)
    TArray<FInstancedStruct> Vars() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> VariableSelections() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x10, Type: ArrayProperty)
    TArray<FVariableCollectionSelection> VariableCollectionSelections() const { return Read<TArray<FVariableCollectionSelection>>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x10, Type: ArrayProperty)
    FWorldConditionQueryDefinition CanSpawnWorldConditionDefinition() const { return Read<FWorldConditionQueryDefinition>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x18, Type: StructProperty)
    TArray<FFortAthenaLivingWorldPrefabActorSpawnerData> ActorSpawnerDatas() const { return Read<TArray<FFortAthenaLivingWorldPrefabActorSpawnerData>>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x10, Type: ArrayProperty)

    void SET_bAutoHandleSuccessFailure(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    void SET_Level(const TSoftObjectPtr<UWorld>& Value) { Write<TSoftObjectPtr<UWorld>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_StateTreeOverride(const TSoftObjectPtr<UStateTree>& Value) { Write<TSoftObjectPtr<UStateTree>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_ProximityGameplayCueTag(const FGameplayCueTag& Value) { Write<FGameplayCueTag>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: StructProperty)
    void SET_ActorCleanupGameplayCueTag(const FGameplayCueTag& Value) { Write<FGameplayCueTag>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: StructProperty)
    void SET_bUseOverlapTestForActorCollection(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x1, Type: BoolProperty)
    void SET_SuccessRewards(const TArray<FEncounterLootEntry>& Value) { Write<TArray<FEncounterLootEntry>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    void SET_ReactionsToGrantOnSuccess(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: ArrayProperty)
    void SET_SuccessRewardBehavior(const FEncounterRewardBehavior& Value) { Write<FEncounterRewardBehavior>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x80, Type: StructProperty)
    void SET_ActorSuccessGameplayCueTag(const FGameplayCueTag& Value) { Write<FGameplayCueTag>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x4, Type: StructProperty)
    void SET_PlayerSuccessGameplayCueTag(const FGameplayCueTag& Value) { Write<FGameplayCueTag>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: StructProperty)
    void SET_FailureRewards(const TArray<FEncounterLootEntry>& Value) { Write<TArray<FEncounterLootEntry>>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    void SET_ReactionsToGrantOnFailure(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x10, Type: ArrayProperty)
    void SET_FailureRewardBehavior(const FEncounterRewardBehavior& Value) { Write<FEncounterRewardBehavior>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x80, Type: StructProperty)
    void SET_ActorFailureGameplayCueTag(const FGameplayCueTag& Value) { Write<FGameplayCueTag>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x4, Type: StructProperty)
    void SET_PlayerFailureGameplayCueTag(const FGameplayCueTag& Value) { Write<FGameplayCueTag>(uintptr_t(this) + 0x24c, Value); } // 0x24c (Size: 0x4, Type: StructProperty)
    void SET_LWMDensityWeight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x28, Type: StructProperty)
    void SET_LWMDensityRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x28, Type: StructProperty)
    void SET_bUseGlobalLWMBudget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x1, Type: BoolProperty)
    void SET_Vars(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    void SET_VariableSelections(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x10, Type: ArrayProperty)
    void SET_VariableCollectionSelections(const TArray<FVariableCollectionSelection>& Value) { Write<TArray<FVariableCollectionSelection>>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x10, Type: ArrayProperty)
    void SET_CanSpawnWorldConditionDefinition(const FWorldConditionQueryDefinition& Value) { Write<FWorldConditionQueryDefinition>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x18, Type: StructProperty)
    void SET_ActorSpawnerDatas(const TArray<FFortAthenaLivingWorldPrefabActorSpawnerData>& Value) { Write<TArray<FFortAthenaLivingWorldPrefabActorSpawnerData>>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x338
class UEncounterManagerComponent : public UGameFrameworkComponent
{
public:
    TWeakObjectPtr<AEncounterGameplayVolume*> EncounterVolume() const { return Read<TWeakObjectPtr<AEncounterGameplayVolume*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    UEncounterItemDefinition* EncounterDefinition() const { return Read<UEncounterItemDefinition*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AActor*> CenterActorOverride() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    FDataTableRowHandle PostEncounterLWMEvent() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle PostEncounterLWMCategory() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: StructProperty)
    FGameplayTagQuery PostEncounterTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x48, Type: StructProperty)
    TSet<AFortPlayerController*> ExplicitContributors() const { return Read<TSet<AFortPlayerController*>>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x50, Type: SetProperty)
    TArray<FActorIdentifierEntry> ActorIdentifiers() const { return Read<TArray<FActorIdentifierEntry>>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x10, Type: ArrayProperty)
    bool bHasHandledSuccessFailure() const { return Read<bool>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x1, Type: BoolProperty)
    TArray<FLWMEncounterInfo> EncounterInfos() const { return Read<TArray<FLWMEncounterInfo>>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayEffectIdentifierInfo> GameplayEffectInfos() const { return Read<TArray<FGameplayEffectIdentifierInfo>>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<ALivingWorldEncounterPrefab*> EncounterPrefab() const { return Read<TWeakObjectPtr<ALivingWorldEncounterPrefab*>>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x8, Type: WeakObjectProperty)
    UEncounterFactionData* SelectedFaction() const { return Read<UEncounterFactionData*>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x8, Type: ObjectProperty)
    UDataTable* LWMEncounterTable() const { return Read<UDataTable*>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AActor*> LastThreat() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AActor*> ReservoirActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: WeakObjectProperty)
    TArray<FTrackedActorInfo> TrackedActorInfos() const { return Read<TArray<FTrackedActorInfo>>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x10, Type: ArrayProperty)
    TArray<UObject*> LoadedObjects() const { return Read<TArray<UObject*>>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x10, Type: ArrayProperty)

    void SET_EncounterVolume(const TWeakObjectPtr<AEncounterGameplayVolume*>& Value) { Write<TWeakObjectPtr<AEncounterGameplayVolume*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_EncounterDefinition(const UEncounterItemDefinition*& Value) { Write<UEncounterItemDefinition*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_CenterActorOverride(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PostEncounterLWMEvent(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: StructProperty)
    void SET_PostEncounterLWMCategory(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: StructProperty)
    void SET_PostEncounterTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x48, Type: StructProperty)
    void SET_ExplicitContributors(const TSet<AFortPlayerController*>& Value) { Write<TSet<AFortPlayerController*>>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x50, Type: SetProperty)
    void SET_ActorIdentifiers(const TArray<FActorIdentifierEntry>& Value) { Write<TArray<FActorIdentifierEntry>>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x10, Type: ArrayProperty)
    void SET_bHasHandledSuccessFailure(const bool& Value) { Write<bool>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x1, Type: BoolProperty)
    void SET_EncounterInfos(const TArray<FLWMEncounterInfo>& Value) { Write<TArray<FLWMEncounterInfo>>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x10, Type: ArrayProperty)
    void SET_GameplayEffectInfos(const TArray<FGameplayEffectIdentifierInfo>& Value) { Write<TArray<FGameplayEffectIdentifierInfo>>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x10, Type: ArrayProperty)
    void SET_EncounterPrefab(const TWeakObjectPtr<ALivingWorldEncounterPrefab*>& Value) { Write<TWeakObjectPtr<ALivingWorldEncounterPrefab*>>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_SelectedFaction(const UEncounterFactionData*& Value) { Write<UEncounterFactionData*>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x8, Type: ObjectProperty)
    void SET_LWMEncounterTable(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    void SET_LastThreat(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ReservoirActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_TrackedActorInfos(const TArray<FTrackedActorInfo>& Value) { Write<TArray<FTrackedActorInfo>>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x10, Type: ArrayProperty)
    void SET_LoadedObjects(const TArray<UObject*>& Value) { Write<TArray<UObject*>>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x3b8
class AEncounterPatrolPathPointProvider : public AFortAthenaPatrolPathPointProvider
{
public:
};

// Size: 0x28
class UEncounterPointProviderInterface : public UInterface
{
public:
};

// Size: 0x188
class UEncounterStateTreeComponent : public UStateTreeComponent
{
public:
};

// Size: 0x3b0
class AEncounterStaticPointProvider : public AFortAthenaLivingWorldStaticPointProvider
{
public:
};

// Size: 0x600
class AEncounterVolumePointProvider : public AFortAthenaLivingWorldVolume
{
public:
};

// Size: 0x28
class UFortCheatManager_Encounters : public UChildCheatManager
{
public:
};

// Size: 0xac8
class ALivingWorldEncounterPrefab : public AFortAthenaLivingWorldPrefab
{
public:
    TArray<FEncounterPrefabInfo> EncounterEntries() const { return Read<TArray<FEncounterPrefabInfo>>(uintptr_t(this) + 0xa70); } // 0xa70 (Size: 0x10, Type: ArrayProperty)
    UEncounterItemDefinition* EncounterDefinition() const { return Read<UEncounterItemDefinition*>(uintptr_t(this) + 0xa80); } // 0xa80 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AActor*> ReservoirActorOverride() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0xaa8); } // 0xaa8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ALivingWorldEncounterPrefab*> ParentScenarioPrefab() const { return Read<TWeakObjectPtr<ALivingWorldEncounterPrefab*>>(uintptr_t(this) + 0xab0); } // 0xab0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UEncounterManagerComponent*> EncounterManager() const { return Read<TWeakObjectPtr<UEncounterManagerComponent*>>(uintptr_t(this) + 0xab8); } // 0xab8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_EncounterEntries(const TArray<FEncounterPrefabInfo>& Value) { Write<TArray<FEncounterPrefabInfo>>(uintptr_t(this) + 0xa70, Value); } // 0xa70 (Size: 0x10, Type: ArrayProperty)
    void SET_EncounterDefinition(const UEncounterItemDefinition*& Value) { Write<UEncounterItemDefinition*>(uintptr_t(this) + 0xa80, Value); } // 0xa80 (Size: 0x8, Type: ObjectProperty)
    void SET_ReservoirActorOverride(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0xaa8, Value); } // 0xaa8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ParentScenarioPrefab(const TWeakObjectPtr<ALivingWorldEncounterPrefab*>& Value) { Write<TWeakObjectPtr<ALivingWorldEncounterPrefab*>>(uintptr_t(this) + 0xab0, Value); } // 0xab0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_EncounterManager(const TWeakObjectPtr<UEncounterManagerComponent*>& Value) { Write<TWeakObjectPtr<UEncounterManagerComponent*>>(uintptr_t(this) + 0xab8, Value); } // 0xab8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x98
class UFortVerbProcessor_EncounterCompleted : public UFortObjectiveProcessor
{
public:
};

// Size: 0xa0
struct FEncounterMobSpawnInfo
{
public:
    FScalableFloat LeashRadiusInner() const { return Read<FScalableFloat>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x28, Type: StructProperty)
    FScalableFloat LeashRadiusOuter() const { return Read<FScalableFloat>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x28, Type: StructProperty)
    TWeakObjectPtr<AEncounterMobAnchor*> EncounterAnchorPoint() const { return Read<TWeakObjectPtr<AEncounterMobAnchor*>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: WeakObjectProperty)
    FGameplayTagContainer PointProviderFilterTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x20, Type: StructProperty)
    TArray<TWeakObjectPtr<AFortAthenaLivingWorldStaticPointProvider*>> StaticPointProviders() const { return Read<TArray<TWeakObjectPtr<AFortAthenaLivingWorldStaticPointProvider*>>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    UEnvQuery* PointProviderEQS() const { return Read<UEnvQuery*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    UClass* PointProviderVolumeClass() const { return Read<UClass*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ClassProperty)

    void SET_LeashRadiusInner(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x28, Type: StructProperty)
    void SET_LeashRadiusOuter(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x28, Type: StructProperty)
    void SET_EncounterAnchorPoint(const TWeakObjectPtr<AEncounterMobAnchor*>& Value) { Write<TWeakObjectPtr<AEncounterMobAnchor*>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PointProviderFilterTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x20, Type: StructProperty)
    void SET_StaticPointProviders(const TArray<TWeakObjectPtr<AFortAthenaLivingWorldStaticPointProvider*>>& Value) { Write<TArray<TWeakObjectPtr<AFortAthenaLivingWorldStaticPointProvider*>>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_PointProviderEQS(const UEnvQuery*& Value) { Write<UEnvQuery*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    void SET_PointProviderVolumeClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ClassProperty)
};

// Size: 0xe0
struct FEncounterMobSpawnData
{
public:
    FString DevNotes() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FGameplayTag MobIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: StructProperty)
    bool bActiveOnStart() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)
    TSoftObjectPtr<UFortAthenaLivingWorldEncounter> MobEncounterData() const { return Read<TSoftObjectPtr<UFortAthenaLivingWorldEncounter>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x20, Type: SoftObjectProperty)
    bool bOverrideDefaultSpawnInfo() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)
    FEncounterMobSpawnInfo MobSpawnInfo() const { return Read<FEncounterMobSpawnInfo>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0xa0, Type: StructProperty)

    void SET_DevNotes(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_MobIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: StructProperty)
    void SET_bActiveOnStart(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
    void SET_MobEncounterData(const TSoftObjectPtr<UFortAthenaLivingWorldEncounter>& Value) { Write<TSoftObjectPtr<UFortAthenaLivingWorldEncounter>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x20, Type: SoftObjectProperty)
    void SET_bOverrideDefaultSpawnInfo(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
    void SET_MobSpawnInfo(const FEncounterMobSpawnInfo& Value) { Write<FEncounterMobSpawnInfo>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0xa0, Type: StructProperty)
};

// Size: 0x58
struct FEncounterMobInstance
{
public:
    AFortAthenaLivingWorldVolume* VolumePointProvider() const { return Read<AFortAthenaLivingWorldVolume*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    TArray<TScriptInterface<Class>> CurrentPointProviders() const { return Read<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_VolumePointProvider(const AFortAthenaLivingWorldVolume*& Value) { Write<AFortAthenaLivingWorldVolume*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentPointProviders(const TArray<TScriptInterface<Class>>& Value) { Write<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
struct FActorAddLooseTagsStateTreeTaskInstanceData
{
public:
    TWeakObjectPtr<AActor*> InActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FGameplayTagContainer ActorTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)
    bool bAddTags() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_InActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ActorTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
    void SET_bAddTags(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FActorAddLooseTagsStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x58
struct FActorPhysicsStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery ActorQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    bool bShouldWakeup() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_ActorQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_bShouldWakeup(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FActorPhysicsStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x10
struct FAddEncounterPrefabTagStateTreeTaskInstanceData
{
public:
    FGameplayTag PrefabTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    bool bRemoveOnExit() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_PrefabTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_bRemoveOnExit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FAddEncounterPrefabTagStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x70
struct FAddGameplayCueStateTreeTaskInstanceData
{
public:
    FGameplayCueTag GameplayCue() const { return Read<FGameplayCueTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    bool bApplyToActor() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<AActor*> TargetActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    bool bApplyToLWMEncounters() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x48, Type: StructProperty)
    bool bApplyToParticipatingPlayers() const { return Read<bool>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x1, Type: BoolProperty)
    bool bIsLooping() const { return Read<bool>(uintptr_t(this) + 0x61); } // 0x61 (Size: 0x1, Type: BoolProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)

    void SET_GameplayCue(const FGameplayCueTag& Value) { Write<FGameplayCueTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_bApplyToActor(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_TargetActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_bApplyToLWMEncounters(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x48, Type: StructProperty)
    void SET_bApplyToParticipatingPlayers(const bool& Value) { Write<bool>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x1, Type: BoolProperty)
    void SET_bIsLooping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x61, Value); } // 0x61 (Size: 0x1, Type: BoolProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FAddGameplayCueStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x50
struct FDestroyActorsStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery ActorQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)

    void SET_ActorQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FDestroyActorsStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x58
struct FEnableEncounterPointProvidersStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery ProviderTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    bool bEnableProvider() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_ProviderTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_bEnableProvider(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEnableEncounterPointProvidersStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x80
struct FEnableSmartObjectsStateTreeTaskInstanceData
{
public:
    bool bUseTagQuery() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    FGameplayTagQuery ActorQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x48, Type: StructProperty)
    AActor* TargetActor() const { return Read<AActor*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    bool bEnable() const { return Read<bool>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x1, Type: BoolProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    TArray<AActor*> AIActors() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    FFortAICommandSOUsageDataBase AICommandSOUsageData() const { return Read<FFortAICommandSOUsageDataBase>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: StructProperty)

    void SET_bUseTagQuery(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_ActorQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x48, Type: StructProperty)
    void SET_TargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    void SET_bEnable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x1, Type: BoolProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_AIActors(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_AICommandSOUsageData(const FFortAICommandSOUsageDataBase& Value) { Write<FFortAICommandSOUsageDataBase>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: StructProperty)
};

// Size: 0x20
struct FEnableSmartObjectsStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x28
struct FEncounterVariableDebugInfo
{
public:
    FGameplayTag VariableTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FDataRegistryOrTableRow VariableValue() const { return Read<FDataRegistryOrTableRow>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)

    void SET_VariableTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_VariableValue(const FDataRegistryOrTableRow& Value) { Write<FDataRegistryOrTableRow>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
};

// Size: 0x30
struct FEncounterDebugVolumeInfo
{
public:
    FVector VolumeOrigin() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector VolumeExtents() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_VolumeOrigin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_VolumeExtents(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0xa8
struct FEncounterDebugInfo
{
public:
    FGuid EncounterGuid() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    UEncounterItemDefinition* EncounterDefinition() const { return Read<UEncounterItemDefinition*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    UDataTable* EncounterTable() const { return Read<UDataTable*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery EncounterVariantQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x48, Type: StructProperty)
    TArray<FEncounterVariableDebugInfo> DynamicVariables() const { return Read<TArray<FEncounterVariableDebugInfo>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    FVector EncounterOrigin() const { return Read<FVector>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x18, Type: StructProperty)
    TArray<FEncounterDebugVolumeInfo> VolumeEntries() const { return Read<TArray<FEncounterDebugVolumeInfo>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)

    void SET_EncounterGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_EncounterDefinition(const UEncounterItemDefinition*& Value) { Write<UEncounterItemDefinition*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_EncounterTable(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET_EncounterVariantQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x48, Type: StructProperty)
    void SET_DynamicVariables(const TArray<FEncounterVariableDebugInfo>& Value) { Write<TArray<FEncounterVariableDebugInfo>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_EncounterOrigin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x18, Type: StructProperty)
    void SET_VolumeEntries(const TArray<FEncounterDebugVolumeInfo>& Value) { Write<TArray<FEncounterDebugVolumeInfo>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
struct FEncounterFactionRow : public FTableRowBase
{
public:
    UEncounterFactionData* FactionData() const { return Read<UEncounterFactionData*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat Weight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x28, Type: StructProperty)

    void SET_FactionData(const UEncounterFactionData*& Value) { Write<UEncounterFactionData*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Weight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x28, Type: StructProperty)
};

// Size: 0x8
struct FEncounterFreeLWMReservoirStateTreeTaskInstanceData
{
public:
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterFreeLWMReservoirStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x68
struct FEncounterGetEnemyFactionStateTreeTaskInstanceData
{
public:
    bool bSpecifyFaction() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    UEncounterFactionData* Faction() const { return Read<UEncounterFactionData*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery EnemyTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x48, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: ObjectProperty)
    UEncounterFactionData* EnemyFaction() const { return Read<UEncounterFactionData*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)

    void SET_bSpecifyFaction(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_Faction(const UEncounterFactionData*& Value) { Write<UEncounterFactionData*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_EnemyTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x48, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: ObjectProperty)
    void SET_EnemyFaction(const UEncounterFactionData*& Value) { Write<UEncounterFactionData*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetEnemyFactionStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x58
struct FEncounterGetKillCountStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: IntProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: IntProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetKillCountStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x10
struct FEncounterGetPersistentValueStateTreeTaskInstanceData
{
public:
    FGameplayTag VariableIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetPersistentValueStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x10
struct FEncounterGetPlayerCountStateTreeTaskInstanceData
{
public:
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetPlayerCountStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x58
struct FEncounterGetRemainingCountStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: IntProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: IntProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetRemainingCountStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x30
struct FEncounterGetVariableActorClassStateTreeTaskInstanceData
{
public:
    FGameplayTag VariableIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetVariableActorClassStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x20
struct FEncounterGetVariableActorDescriptionStateTreeTaskInstanceData
{
public:
    FGameplayTag VariableIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription> Value() const { return Read<TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Value(const TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription>& Value) { Write<TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetVariableActorDescriptionStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x10
struct FEncounterGetVariableBoolStateTreeTaskInstanceData
{
public:
    FGameplayTag VariableIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    bool bValue() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_bValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetVariableBoolStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x20
struct FEncounterGetVariableDynamicEncounterConfigStateTreeTaskInstanceData
{
public:
    FGameplayTag VariableIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    TArray<FDynamicEncounterEntry> Value() const { return Read<TArray<FDynamicEncounterEntry>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Value(const TArray<FDynamicEncounterEntry>& Value) { Write<TArray<FDynamicEncounterEntry>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2a0
struct FDynamicEncounterEntry
{
public:
    FString DebugName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    bool bUseEventTemplate() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    int32_t SpawnCount() const { return Read<int32_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: IntProperty)
    int32_t MaxConcurrentSpawns() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    FFortAthenaLivingWorldEvent EventTemplate() const { return Read<FFortAthenaLivingWorldEvent>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1c0, Type: StructProperty)
    bool bOverrideActorCount() const { return Read<bool>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x1, Type: BoolProperty)
    int32_t ActorCountOverrideMax() const { return Read<int32_t>(uintptr_t(this) + 0x1e4); } // 0x1e4 (Size: 0x4, Type: IntProperty)
    int32_t ActorCountOverrideMin() const { return Read<int32_t>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x4, Type: IntProperty)
    FGameplayTagQuery PointProviderTagQueryOverride() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x48, Type: StructProperty)
    bool bUseEncounterTagQuery() const { return Read<bool>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x1, Type: BoolProperty)
    FGameplayTagQuery EncounterTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x48, Type: StructProperty)
    bool bCreateRandomSingleActorEvents() const { return Read<bool>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x1, Type: BoolProperty)
    int32_t NoActorLimitEventCount() const { return Read<int32_t>(uintptr_t(this) + 0x28c); } // 0x28c (Size: 0x4, Type: IntProperty)
    TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription> ActorDescriptions() const { return Read<TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription>>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x10, Type: ArrayProperty)

    void SET_DebugName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_bUseEventTemplate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_SpawnCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: IntProperty)
    void SET_MaxConcurrentSpawns(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_EventTemplate(const FFortAthenaLivingWorldEvent& Value) { Write<FFortAthenaLivingWorldEvent>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1c0, Type: StructProperty)
    void SET_bOverrideActorCount(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x1, Type: BoolProperty)
    void SET_ActorCountOverrideMax(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1e4, Value); } // 0x1e4 (Size: 0x4, Type: IntProperty)
    void SET_ActorCountOverrideMin(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x4, Type: IntProperty)
    void SET_PointProviderTagQueryOverride(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x48, Type: StructProperty)
    void SET_bUseEncounterTagQuery(const bool& Value) { Write<bool>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x1, Type: BoolProperty)
    void SET_EncounterTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x48, Type: StructProperty)
    void SET_bCreateRandomSingleActorEvents(const bool& Value) { Write<bool>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x1, Type: BoolProperty)
    void SET_NoActorLimitEventCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28c, Value); } // 0x28c (Size: 0x4, Type: IntProperty)
    void SET_ActorDescriptions(const TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription>& Value) { Write<TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription>>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FEncounterGetVariableDynamicEncounterConfigStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x30
struct FEncounterGetVariableFactionStateTreeTaskInstanceData
{
public:
    FGameplayTag VariableIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    TSoftObjectPtr<UEncounterFactionData> Value() const { return Read<TSoftObjectPtr<UEncounterFactionData>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Value(const TSoftObjectPtr<UEncounterFactionData>& Value) { Write<TSoftObjectPtr<UEncounterFactionData>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetVariableFactionStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x10
struct FEncounterGetVariableFloatStateTreeTaskInstanceData
{
public:
    FGameplayTag VariableIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    float Value() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetVariableFloatStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x30
struct FEncounterGetVariableGameplayTagContainerStateTreeTaskInstanceData
{
public:
    FGameplayTag VariableIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer Value() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Value(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetVariableGameplayTagContainerStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x10
struct FEncounterGetVariableGameplayTagStateTreeTaskInstanceData
{
public:
    FGameplayTag VariableIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FGameplayTag Value() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Value(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetVariableGameplayTagStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x10
struct FEncounterGetVariableIntStateTreeTaskInstanceData
{
public:
    FGameplayTag VariableIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetVariableIntStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x30
struct FEncounterGetVariableItemDefinitionStateTreeTaskInstanceData
{
public:
    FGameplayTag VariableIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    TSoftObjectPtr<UFortWorldItemDefinition> Value() const { return Read<TSoftObjectPtr<UFortWorldItemDefinition>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Value(const TSoftObjectPtr<UFortWorldItemDefinition>& Value) { Write<TSoftObjectPtr<UFortWorldItemDefinition>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetVariableItemDefinitionStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x30
struct FEncounterGetVariableLWMEncounterStateTreeTaskInstanceData
{
public:
    FGameplayTag VariableIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    TSoftObjectPtr<UFortAthenaLivingWorldEncounter> Value() const { return Read<TSoftObjectPtr<UFortAthenaLivingWorldEncounter>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Value(const TSoftObjectPtr<UFortAthenaLivingWorldEncounter>& Value) { Write<TSoftObjectPtr<UFortAthenaLivingWorldEncounter>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetVariableLWMEncounterStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x30
struct FEncounterGetVariableQuestDefinitionStateTreeTaskInstanceData
{
public:
    FGameplayTag VariableIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    TSoftObjectPtr<UFortQuestItemDefinition> Value() const { return Read<TSoftObjectPtr<UFortQuestItemDefinition>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Value(const TSoftObjectPtr<UFortQuestItemDefinition>& Value) { Write<TSoftObjectPtr<UFortQuestItemDefinition>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetVariableQuestDefinitionStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x30
struct FEncounterGetVariableScenarioDefinitionStateTreeTaskInstanceData
{
public:
    FGameplayTag VariableIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    TSoftObjectPtr<UEncounterItemDefinition> Value() const { return Read<TSoftObjectPtr<UEncounterItemDefinition>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Value(const TSoftObjectPtr<UEncounterItemDefinition>& Value) { Write<TSoftObjectPtr<UEncounterItemDefinition>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetVariableScenarioDefinitionStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x10
struct FEncounterGetVariableStringStateTreeTaskInstanceData
{
public:
    FGameplayTag VariableIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FName Value() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Value(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetVariableStringStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x58
struct FEncounterGetVariableTagQueryStateTreeTaskInstanceData
{
public:
    FGameplayTag VariableIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FGameplayTagQuery Value() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x48, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Value(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x48, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetVariableTagQueryStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x98
struct FEncounterGetVariantTagQueryStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery BaseTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery Value() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x48, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)

    void SET_BaseTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_Value(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x48, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterGetVariantTagQueryStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x50
struct FEncounterPrefabEntry
{
public:
    UEncounterItemDefinition* EncounterDefinition() const { return Read<UEncounterItemDefinition*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag EncounterIdentifierTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    FScalableFloat Weight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x28, Type: StructProperty)
    FWorldConditionQueryDefinition CanSpawnCondition() const { return Read<FWorldConditionQueryDefinition>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)

    void SET_EncounterDefinition(const UEncounterItemDefinition*& Value) { Write<UEncounterItemDefinition*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_EncounterIdentifierTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_Weight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x28, Type: StructProperty)
    void SET_CanSpawnCondition(const FWorldConditionQueryDefinition& Value) { Write<FWorldConditionQueryDefinition>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
};

// Size: 0x70
struct FEncounterSelectFactionStateTreeTaskInstanceData
{
public:
    UDataRegistry* FactionRegistry() const { return Read<UDataRegistry*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery FactionRequirements() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x48, Type: StructProperty)
    bool bSaveToEncounterManager() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: ObjectProperty)
    UEncounterFactionData* Faction() const { return Read<UEncounterFactionData*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)

    void SET_FactionRegistry(const UDataRegistry*& Value) { Write<UDataRegistry*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_FactionRequirements(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x48, Type: StructProperty)
    void SET_bSaveToEncounterManager(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: ObjectProperty)
    void SET_Faction(const UEncounterFactionData*& Value) { Write<UEncounterFactionData*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterSelectFactionStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x10
struct FEncounterSetCenterActorStateTreeTaskInstanceData
{
public:
    TWeakObjectPtr<AActor*> CenterActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_CenterActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterSetCenterActorStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x18
struct FEncounterSetPersistentValueStateTreeTaskInstanceData
{
public:
    FGameplayTag VariableIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    uint8_t Scope() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_VariableIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_Scope(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterSetPersistentValueStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x8
struct FEndAllMobEncountersStateTreeTaskInstanceData
{
public:
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEndAllMobEncountersStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x138
struct FFortVerbMessage_EncounterCompleted : public FVerbMessage
{
public:
    FSubjectTagsPair EncounterItemDef() const { return Read<FSubjectTagsPair>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x38, Type: StructProperty)
    bool bSuccess() const { return Read<bool>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x1, Type: BoolProperty)
    TArray<FSubjectTagsPair> EncounterPlayers() const { return Read<TArray<FSubjectTagsPair>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    FSubjectTagsPair Faction() const { return Read<FSubjectTagsPair>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x38, Type: StructProperty)
    FSubjectTagsPair EncounterVolumeTags() const { return Read<FSubjectTagsPair>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x38, Type: StructProperty)

    void SET_EncounterItemDef(const FSubjectTagsPair& Value) { Write<FSubjectTagsPair>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x38, Type: StructProperty)
    void SET_bSuccess(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x1, Type: BoolProperty)
    void SET_EncounterPlayers(const TArray<FSubjectTagsPair>& Value) { Write<TArray<FSubjectTagsPair>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    void SET_Faction(const FSubjectTagsPair& Value) { Write<FSubjectTagsPair>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x38, Type: StructProperty)
    void SET_EncounterVolumeTags(const FSubjectTagsPair& Value) { Write<FSubjectTagsPair>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x38, Type: StructProperty)
};

// Size: 0x58
struct FGetAnchorStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery AnchorQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    TWeakObjectPtr<AActor*> AnchorActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: WeakObjectProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_AnchorQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_AnchorActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: WeakObjectProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FGetAnchorStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x60
struct FGetEncounterActorStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery ActorQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    bool bQueryAgainstTrackedActorIdentifiers() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<AActor*> ChosenActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x8, Type: WeakObjectProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: ObjectProperty)

    void SET_ActorQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_bQueryAgainstTrackedActorIdentifiers(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
    void SET_ChosenActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x8, Type: WeakObjectProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FGetEncounterActorStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0xd0
struct FGetFactionEntryStateTreeTaskInstanceData
{
public:
    bool bSpecifyFaction() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    UEncounterFactionData* Faction() const { return Read<UEncounterFactionData*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UDataRegistry* FactionRegistry() const { return Read<UDataRegistry*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery FactionRequirements() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery LWMEncounterTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x48, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription> ActorDescriptions() const { return Read<TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortAthenaLivingWorldTaggedSpawnActionClass> SpawnActions() const { return Read<TArray<FFortAthenaLivingWorldTaggedSpawnActionClass>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: ArrayProperty)

    void SET_bSpecifyFaction(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_Faction(const UEncounterFactionData*& Value) { Write<UEncounterFactionData*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_FactionRegistry(const UDataRegistry*& Value) { Write<UDataRegistry*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_FactionRequirements(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x48, Type: StructProperty)
    void SET_LWMEncounterTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x48, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
    void SET_ActorDescriptions(const TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription>& Value) { Write<TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    void SET_SpawnActions(const TArray<FFortAthenaLivingWorldTaggedSpawnActionClass>& Value) { Write<TArray<FFortAthenaLivingWorldTaggedSpawnActionClass>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FGetFactionEntryStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x60
struct FGetLWMEncounterPawnsStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    TArray<TWeakObjectPtr<AFortPawn*>> FoundPawns() const { return Read<TArray<TWeakObjectPtr<AFortPawn*>>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: ObjectProperty)

    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_FoundPawns(const TArray<TWeakObjectPtr<AFortPawn*>>& Value) { Write<TArray<TWeakObjectPtr<AFortPawn*>>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FGetLWMEncounterPawnsStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x58
struct FGetLWMEncounterPawnStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    TWeakObjectPtr<AFortPawn*> ChosenPawn() const { return Read<TWeakObjectPtr<AFortPawn*>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: WeakObjectProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_ChosenPawn(const TWeakObjectPtr<AFortPawn*>& Value) { Write<TWeakObjectPtr<AFortPawn*>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: WeakObjectProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FGetLWMEncounterPawnStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x38
struct FGrantQuestStateTreeTaskInstanceData
{
public:
    TSoftObjectPtr<UFortQuestItemDefinition> QuestToGrant() const { return Read<TSoftObjectPtr<UFortQuestItemDefinition>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    uint8_t GrantType() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)
    AActor* TargetActor() const { return Read<AActor*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_QuestToGrant(const TSoftObjectPtr<UFortQuestItemDefinition>& Value) { Write<TSoftObjectPtr<UFortQuestItemDefinition>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_GrantType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
    void SET_TargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FGrantQuestStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x40
struct FGrantReactionStateTreeTaskInstanceData : public FFortStateTreeEncounterInstanceDataBase
{
public:
    TArray<FScenarioReactionEntry> ReactionEntries() const { return Read<TArray<FScenarioReactionEntry>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> Reactions() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    uint8_t GrantType() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    TWeakObjectPtr<AActor*> TargetActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x8, Type: WeakObjectProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_ReactionEntries(const TArray<FScenarioReactionEntry>& Value) { Write<TArray<FScenarioReactionEntry>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_Reactions(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_GrantType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_TargetActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x8, Type: WeakObjectProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FScenarioReactionEntry
{
public:
    FDataRegistryOrTableRow RowValue() const { return Read<FDataRegistryOrTableRow>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)

    void SET_RowValue(const FDataRegistryOrTableRow& Value) { Write<FDataRegistryOrTableRow>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x20
struct FGrantReactionStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x88
struct FLWMEncounterAddGameplayEffectStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    UClass* GameplayEffect() const { return Read<UClass*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ClassProperty)
    bool bRemoveEffectOnExit() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer IdentifierTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x20, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)

    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_GameplayEffect(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ClassProperty)
    void SET_bRemoveEffectOnExit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_IdentifierTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x20, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FLWMEncounterAddGameplayEffectStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x50
struct FLWMEncounterAdvanceStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)

    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FLWMEncounterAdvanceStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0xa0
struct FLWMEncounterAssignPointProvidersStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery PatrolPathTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x48, Type: StructProperty)
    bool bUseClosestProvider() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ObjectProperty)

    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_PatrolPathTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x48, Type: StructProperty)
    void SET_bUseClosestProvider(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FLWMEncounterAssignPointProvidersStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x170
struct FLWMEncounterStartSharedStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery PointProviderTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    bool bAttachVolumeToSpawn() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)
    bool bOverrideAnchorPosition() const { return Read<bool>(uintptr_t(this) + 0x49); } // 0x49 (Size: 0x1, Type: BoolProperty)
    bool bUseVolumeAsAnchor() const { return Read<bool>(uintptr_t(this) + 0x4a); } // 0x4a (Size: 0x1, Type: BoolProperty)
    FGameplayTagQuery AnchorPointTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x48, Type: StructProperty)
    FScalableFloat LeashRadiusInner() const { return Read<FScalableFloat>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x28, Type: StructProperty)
    FScalableFloat LeashRadiusOuter() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x28, Type: StructProperty)
    FGameplayTagContainer EncounterIdentifierTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ActorTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x20, Type: StructProperty)
    FScalableFloat SpawnTimeout() const { return Read<FScalableFloat>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x28, Type: StructProperty)
    bool bPauseOnExit() const { return Read<bool>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<AActor*> OwningActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x154); } // 0x154 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<APawn*> Instigator() const { return Read<TWeakObjectPtr<APawn*>>(uintptr_t(this) + 0x15c); } // 0x15c (Size: 0x8, Type: WeakObjectProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x8, Type: ObjectProperty)

    void SET_PointProviderTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_bAttachVolumeToSpawn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
    void SET_bOverrideAnchorPosition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x49, Value); } // 0x49 (Size: 0x1, Type: BoolProperty)
    void SET_bUseVolumeAsAnchor(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4a, Value); } // 0x4a (Size: 0x1, Type: BoolProperty)
    void SET_AnchorPointTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x48, Type: StructProperty)
    void SET_LeashRadiusInner(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x28, Type: StructProperty)
    void SET_LeashRadiusOuter(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x28, Type: StructProperty)
    void SET_EncounterIdentifierTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x20, Type: StructProperty)
    void SET_ActorTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x20, Type: StructProperty)
    void SET_SpawnTimeout(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x28, Type: StructProperty)
    void SET_bPauseOnExit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x1, Type: BoolProperty)
    void SET_OwningActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x154, Value); } // 0x154 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Instigator(const TWeakObjectPtr<APawn*>& Value) { Write<TWeakObjectPtr<APawn*>>(uintptr_t(this) + 0x15c, Value); } // 0x15c (Size: 0x8, Type: WeakObjectProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x218
struct FLWMEncounterDynamicStartStateTreeTaskInstanceData : public FLWMEncounterStartSharedStateTreeTaskInstanceData
{
public:
    bool bSpecifyFaction() const { return Read<bool>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x1, Type: BoolProperty)
    UEncounterFactionData* Faction() const { return Read<UEncounterFactionData*>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x8, Type: ObjectProperty)
    TArray<FDynamicEncounterEntry> DynamicEncounterEntries() const { return Read<TArray<FDynamicEncounterEntry>>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x10, Type: ArrayProperty)
    TSoftObjectPtr<UFortAthenaLivingWorldEncounter> DynamicEmptyEncounter() const { return Read<TSoftObjectPtr<UFortAthenaLivingWorldEncounter>>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FFortAthenaLivingWorldTaggedSpawnActionClass> SpawnActions() const { return Read<TArray<FFortAthenaLivingWorldTaggedSpawnActionClass>>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x10, Type: ArrayProperty)
    bool bOverrideEnvQuery() const { return Read<bool>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x1, Type: BoolProperty)
    UEnvQuery* SpawnAroundEnvironmentQuery() const { return Read<UEnvQuery*>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EEnvQueryRunMode> SpawnAroundEnvironmentQueryRunMode() const { return Read<TEnumAsByte<EEnvQueryRunMode>>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x1, Type: ByteProperty)
    FSoftClassPath SpawnAroundNavigationSourceOverride() const { return Read<FSoftClassPath>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x18, Type: StructProperty)
    bool bWaitForEncounterDoneSpawning() const { return Read<bool>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x1, Type: BoolProperty)
    bool bOverrideDelayBetweenEvents() const { return Read<bool>(uintptr_t(this) + 0x1f1); } // 0x1f1 (Size: 0x1, Type: BoolProperty)
    float DelayBetweenEventsMin() const { return Read<float>(uintptr_t(this) + 0x1f4); } // 0x1f4 (Size: 0x4, Type: FloatProperty)
    float DelayBetweenEventsMax() const { return Read<float>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x4, Type: FloatProperty)
    bool bOverrideStageActorMaxCount() const { return Read<bool>(uintptr_t(this) + 0x1fc); } // 0x1fc (Size: 0x1, Type: BoolProperty)
    int32_t StageActorMaxCount() const { return Read<int32_t>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x4, Type: IntProperty)
    bool bOverrideStageActorMaxSpawnedCount() const { return Read<bool>(uintptr_t(this) + 0x204); } // 0x204 (Size: 0x1, Type: BoolProperty)
    int32_t StageActorMaxSpawnedCount() const { return Read<int32_t>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<ULWMEncounterInstance*> EncounterInstance() const { return Read<TWeakObjectPtr<ULWMEncounterInstance*>>(uintptr_t(this) + 0x20c); } // 0x20c (Size: 0x8, Type: WeakObjectProperty)

    void SET_bSpecifyFaction(const bool& Value) { Write<bool>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x1, Type: BoolProperty)
    void SET_Faction(const UEncounterFactionData*& Value) { Write<UEncounterFactionData*>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x8, Type: ObjectProperty)
    void SET_DynamicEncounterEntries(const TArray<FDynamicEncounterEntry>& Value) { Write<TArray<FDynamicEncounterEntry>>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x10, Type: ArrayProperty)
    void SET_DynamicEmptyEncounter(const TSoftObjectPtr<UFortAthenaLivingWorldEncounter>& Value) { Write<TSoftObjectPtr<UFortAthenaLivingWorldEncounter>>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SpawnActions(const TArray<FFortAthenaLivingWorldTaggedSpawnActionClass>& Value) { Write<TArray<FFortAthenaLivingWorldTaggedSpawnActionClass>>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x10, Type: ArrayProperty)
    void SET_bOverrideEnvQuery(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x1, Type: BoolProperty)
    void SET_SpawnAroundEnvironmentQuery(const UEnvQuery*& Value) { Write<UEnvQuery*>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x8, Type: ObjectProperty)
    void SET_SpawnAroundEnvironmentQueryRunMode(const TEnumAsByte<EEnvQueryRunMode>& Value) { Write<TEnumAsByte<EEnvQueryRunMode>>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x1, Type: ByteProperty)
    void SET_SpawnAroundNavigationSourceOverride(const FSoftClassPath& Value) { Write<FSoftClassPath>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x18, Type: StructProperty)
    void SET_bWaitForEncounterDoneSpawning(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x1, Type: BoolProperty)
    void SET_bOverrideDelayBetweenEvents(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1f1, Value); } // 0x1f1 (Size: 0x1, Type: BoolProperty)
    void SET_DelayBetweenEventsMin(const float& Value) { Write<float>(uintptr_t(this) + 0x1f4, Value); } // 0x1f4 (Size: 0x4, Type: FloatProperty)
    void SET_DelayBetweenEventsMax(const float& Value) { Write<float>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x4, Type: FloatProperty)
    void SET_bOverrideStageActorMaxCount(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1fc, Value); } // 0x1fc (Size: 0x1, Type: BoolProperty)
    void SET_StageActorMaxCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x4, Type: IntProperty)
    void SET_bOverrideStageActorMaxSpawnedCount(const bool& Value) { Write<bool>(uintptr_t(this) + 0x204, Value); } // 0x204 (Size: 0x1, Type: BoolProperty)
    void SET_StageActorMaxSpawnedCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x4, Type: IntProperty)
    void SET_EncounterInstance(const TWeakObjectPtr<ULWMEncounterInstance*>& Value) { Write<TWeakObjectPtr<ULWMEncounterInstance*>>(uintptr_t(this) + 0x20c, Value); } // 0x20c (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x20
struct FLWMEncounterDynamicStartStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x4
struct FLWMEncounterAlertLevelTargetInfo
{
public:
    float AwareForgetTime() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)

    void SET_AwareForgetTime(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc
struct FLWMEncounterInstanceSavedTargetInfo
{
public:
    TWeakObjectPtr<AActor*> Target() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Target(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x8
struct FLWMEncounterInstanceSavedFactionMods
{
public:
};

// Size: 0x58
struct FLWMEncounterInstanceEffectInfo
{
public:
    UClass* GameplayEffect() const { return Read<UClass*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ClassProperty)

    void SET_GameplayEffect(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x58
struct FLWMEncounterModifyActorFactionStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    FGameplayTag FactionTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: StructProperty)
    uint8_t ModificationAction() const { return Read<uint8_t>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x1, Type: EnumProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_FactionTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: StructProperty)
    void SET_ModificationAction(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x1, Type: EnumProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FLWMEncounterModifyActorFactionStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x50
struct FLWMEncounterPauseStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)

    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FLWMEncounterPauseStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x50
struct FLWMEncounterRemoveGameplayEffectStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery GameplayEffectQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)

    void SET_GameplayEffectQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FLWMEncounterRemoveGameplayEffectStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x50
struct FLWMEncounterResumeStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)

    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FLWMEncounterResumeStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x50
struct FLWMEncounterRow : public FTableRowBase
{
public:
    TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription> DynamicActorDescriptions() const { return Read<TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortAthenaLivingWorldTaggedSpawnActionClass> DynamicSpawnActions() const { return Read<TArray<FFortAthenaLivingWorldTaggedSpawnActionClass>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer Tags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)

    void SET_DynamicActorDescriptions(const TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription>& Value) { Write<TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_DynamicSpawnActions(const TArray<FFortAthenaLivingWorldTaggedSpawnActionClass>& Value) { Write<TArray<FFortAthenaLivingWorldTaggedSpawnActionClass>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_Tags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xb0
struct FLWMEncounterSetAlertLevelStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    FLWMEncounterAlertLevelTargetInfo TargetInfo() const { return Read<FLWMEncounterAlertLevelTargetInfo>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: StructProperty)
    TWeakObjectPtr<AActor*> TargetActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x8, Type: WeakObjectProperty)
    FGameplayTagQuery TargetEncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x48, Type: StructProperty)
    uint8_t TargetBehavior() const { return Read<uint8_t>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: EnumProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x8, Type: ObjectProperty)

    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_TargetInfo(const FLWMEncounterAlertLevelTargetInfo& Value) { Write<FLWMEncounterAlertLevelTargetInfo>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: StructProperty)
    void SET_TargetActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x8, Type: WeakObjectProperty)
    void SET_TargetEncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x48, Type: StructProperty)
    void SET_TargetBehavior(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: EnumProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FLWMEncounterSetAlertLevelStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x58
struct FLWMEncounterSetStageStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    int32_t StageIndex() const { return Read<int32_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: IntProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_StageIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: IntProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FLWMEncounterSetStageStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x198
struct FLWMEncounterStartStateTreeTaskInstanceData : public FLWMEncounterStartSharedStateTreeTaskInstanceData
{
public:
    TSoftObjectPtr<UFortAthenaLivingWorldEncounter> LWMEncounter() const { return Read<TSoftObjectPtr<UFortAthenaLivingWorldEncounter>>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x20, Type: SoftObjectProperty)
    TWeakObjectPtr<ULWMEncounterInstance*> EncounterInstance() const { return Read<TWeakObjectPtr<ULWMEncounterInstance*>>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x8, Type: WeakObjectProperty)

    void SET_LWMEncounter(const TSoftObjectPtr<UFortAthenaLivingWorldEncounter>& Value) { Write<TSoftObjectPtr<UFortAthenaLivingWorldEncounter>>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x20, Type: SoftObjectProperty)
    void SET_EncounterInstance(const TWeakObjectPtr<ULWMEncounterInstance*>& Value) { Write<TWeakObjectPtr<ULWMEncounterInstance*>>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x20
struct FLWMEncounterStartStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x50
struct FLWMEncounterStopStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)

    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FLWMEncounterStopStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x58
struct FUpdateLeashAlertLevelOverrideEntry
{
public:
    uint8_t AlertLevel() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FScalableFloat LeashRadiusInner() const { return Read<FScalableFloat>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x28, Type: StructProperty)
    FScalableFloat LeashRadiusOuter() const { return Read<FScalableFloat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x28, Type: StructProperty)

    void SET_AlertLevel(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_LeashRadiusInner(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x28, Type: StructProperty)
    void SET_LeashRadiusOuter(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x28, Type: StructProperty)
};

// Size: 0x108
struct FLWMEncounterUpdateLeashStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    AActor* TargetActor() const { return Read<AActor*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    bool bOverrideAnchorPosition() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    bool bUseVolumeAsAnchor() const { return Read<bool>(uintptr_t(this) + 0x51); } // 0x51 (Size: 0x1, Type: BoolProperty)
    FGameplayTagQuery AnchorPointTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x48, Type: StructProperty)
    FScalableFloat LeashRadiusInner() const { return Read<FScalableFloat>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x28, Type: StructProperty)
    FScalableFloat LeashRadiusOuter() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x28, Type: StructProperty)
    TArray<FUpdateLeashAlertLevelOverrideEntry> AlertLevelOverrides() const { return Read<TArray<FUpdateLeashAlertLevelOverrideEntry>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: ObjectProperty)

    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_TargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    void SET_bOverrideAnchorPosition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_bUseVolumeAsAnchor(const bool& Value) { Write<bool>(uintptr_t(this) + 0x51, Value); } // 0x51 (Size: 0x1, Type: BoolProperty)
    void SET_AnchorPointTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x48, Type: StructProperty)
    void SET_LeashRadiusInner(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x28, Type: StructProperty)
    void SET_LeashRadiusOuter(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x28, Type: StructProperty)
    void SET_AlertLevelOverrides(const TArray<FUpdateLeashAlertLevelOverrideEntry>& Value) { Write<TArray<FUpdateLeashAlertLevelOverrideEntry>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FLWMEncounterUpdateLeashStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x18
struct FOverrideAIBehaviorStateTreeTaskInstanceData
{
public:
    TWeakObjectPtr<AActor*> TargetActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    int32_t BehaviorControl() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_TargetActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_BehaviorControl(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FOverrideAIBehaviorStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x10
struct FPauseMobEncounterStateTreeTaskInstanceData
{
public:
    FGameplayTag MobIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_MobIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FPauseMobEncounterStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x10
struct FRemoveEncounterPrefabTagStateTreeTaskInstanceData
{
public:
    FGameplayTag PrefabTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_PrefabTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FRemoveEncounterPrefabTagStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x10
struct FResumeMobEncounterStateTreeTaskInstanceData
{
public:
    FGameplayTag MobIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_MobIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FResumeMobEncounterStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x158
struct FSpawnActorStateTreeTaskInstanceData
{
public:
    bool bUseActorLocation() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<AActor*> TargetActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x8, Type: WeakObjectProperty)
    FGameplayTagQuery AnchorQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x48, Type: StructProperty)
    FVector AnchorOffset() const { return Read<FVector>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x18, Type: StructProperty)
    bool bEnablePhysics() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)
    bool bAttachEncounterVolume() const { return Read<bool>(uintptr_t(this) + 0x91); } // 0x91 (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer ActorTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ActorIdentifierTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x20, Type: StructProperty)
    uint8_t PersistenceBehavior() const { return Read<uint8_t>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x1, Type: EnumProperty)
    FGameplayTagQuery ExistingActorQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x48, Type: StructProperty)
    TWeakObjectPtr<AActor*> OwningActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: WeakObjectProperty)
    bool bWaitForSpawnedActor() const { return Read<bool>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<AActor*> SpawnedActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x134); } // 0x134 (Size: 0x8, Type: WeakObjectProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: ObjectProperty)
    USpawnActorTaskHelper* SpawnActorHelper() const { return Read<USpawnActorTaskHelper*>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x8, Type: ObjectProperty)

    void SET_bUseActorLocation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_TargetActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x8, Type: WeakObjectProperty)
    void SET_AnchorQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x48, Type: StructProperty)
    void SET_AnchorOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x18, Type: StructProperty)
    void SET_bEnablePhysics(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
    void SET_bAttachEncounterVolume(const bool& Value) { Write<bool>(uintptr_t(this) + 0x91, Value); } // 0x91 (Size: 0x1, Type: BoolProperty)
    void SET_ActorTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x20, Type: StructProperty)
    void SET_ActorIdentifierTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x20, Type: StructProperty)
    void SET_PersistenceBehavior(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x1, Type: EnumProperty)
    void SET_ExistingActorQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x48, Type: StructProperty)
    void SET_OwningActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: WeakObjectProperty)
    void SET_bWaitForSpawnedActor(const bool& Value) { Write<bool>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x1, Type: BoolProperty)
    void SET_SpawnedActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x134, Value); } // 0x134 (Size: 0x8, Type: WeakObjectProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: ObjectProperty)
    void SET_SpawnActorHelper(const USpawnActorTaskHelper*& Value) { Write<USpawnActorTaskHelper*>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FSpawnActorStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x10
struct FStartMobEncounterStateTreeTaskInstanceData
{
public:
    FGameplayTag MobIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_MobIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FStartMobEncounterStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
    bool bStopEncounterOnExit() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_bStopEncounterOnExit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb8
struct FStartScenarioStateTreeTaskInstanceData
{
public:
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UClass* PrefabClass() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)
    TSoftObjectPtr<UEncounterItemDefinition> ScenarioDefinition() const { return Read<TSoftObjectPtr<UEncounterItemDefinition>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: SoftObjectProperty)
    FGameplayTagContainer ScenarioIdentifierTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer AdditionalScenarioCompletionVerbTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x20, Type: StructProperty)
    FGameplayTagQuery LocationQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x48, Type: StructProperty)

    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_PrefabClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
    void SET_ScenarioDefinition(const TSoftObjectPtr<UEncounterItemDefinition>& Value) { Write<TSoftObjectPtr<UEncounterItemDefinition>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: SoftObjectProperty)
    void SET_ScenarioIdentifierTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
    void SET_AdditionalScenarioCompletionVerbTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x20, Type: StructProperty)
    void SET_LocationQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x48, Type: StructProperty)
};

// Size: 0x20
struct FStartScenarioStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x10
struct FStopMobEncounterStateTreeTaskInstanceData
{
public:
    FGameplayTag MobIdentifier() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_MobIdentifier(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FStopMobEncounterStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x18
struct FToggleStateActorStateTreeTaskInstanceData
{
public:
    AActor* TargetActor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bToggleOn() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_TargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_bToggleOn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FToggleStateActorStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x40
struct FTrackScenarioActorsStateTreeTaskInstanceData
{
public:
    TArray<TWeakObjectPtr<AActor*>> TargetActors() const { return Read<TArray<TWeakObjectPtr<AActor*>>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer ActorIdentifierTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    bool bDestroyOnScenarioComplete() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_TargetActors(const TArray<TWeakObjectPtr<AActor*>>& Value) { Write<TArray<TWeakObjectPtr<AActor*>>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_ActorIdentifierTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_bDestroyOnScenarioComplete(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FTrackScenarioActorsStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0x68
struct FVariableSelectionsRow_DynamicEncounterConfig : public FVariableSelectionsRow
{
public:
    FDataRegistryOrTableRow RowValue() const { return Read<FDataRegistryOrTableRow>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x20, Type: StructProperty)

    void SET_RowValue(const FDataRegistryOrTableRow& Value) { Write<FDataRegistryOrTableRow>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x20, Type: StructProperty)
};

// Size: 0x68
struct FVariableSelectionsRow_Faction : public FVariableSelectionsRow
{
public:
    FDataRegistryOrTableRow RowValue() const { return Read<FDataRegistryOrTableRow>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x20, Type: StructProperty)

    void SET_RowValue(const FDataRegistryOrTableRow& Value) { Write<FDataRegistryOrTableRow>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x20, Type: StructProperty)
};

// Size: 0x68
struct FVariableSelectionsRow_QuestDefinition : public FVariableSelectionsRow
{
public:
    FDataRegistryOrTableRow RowValue() const { return Read<FDataRegistryOrTableRow>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x20, Type: StructProperty)

    void SET_RowValue(const FDataRegistryOrTableRow& Value) { Write<FDataRegistryOrTableRow>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x20, Type: StructProperty)
};

// Size: 0x68
struct FVariableSelectionsRow_ScenarioDefinition : public FVariableSelectionsRow
{
public:
    FDataRegistryOrTableRow RowValue() const { return Read<FDataRegistryOrTableRow>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x20, Type: StructProperty)

    void SET_RowValue(const FDataRegistryOrTableRow& Value) { Write<FDataRegistryOrTableRow>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x20, Type: StructProperty)
};

// Size: 0x90
struct FVariableSelections_DynamicEncounterConfig : public FVariableSelections
{
public:
    FSoftDataRegistryOrTable ValueChoiceTable() const { return Read<FSoftDataRegistryOrTable>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x30, Type: StructProperty)

    void SET_ValueChoiceTable(const FSoftDataRegistryOrTable& Value) { Write<FSoftDataRegistryOrTable>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x30, Type: StructProperty)
};

// Size: 0x90
struct FVariableSelections_Faction : public FVariableSelections
{
public:
    FSoftDataRegistryOrTable ValueChoiceTable() const { return Read<FSoftDataRegistryOrTable>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x30, Type: StructProperty)

    void SET_ValueChoiceTable(const FSoftDataRegistryOrTable& Value) { Write<FSoftDataRegistryOrTable>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x30, Type: StructProperty)
};

// Size: 0x90
struct FVariableSelections_QuestDefinition : public FVariableSelections
{
public:
    FSoftDataRegistryOrTable ValueChoiceTable() const { return Read<FSoftDataRegistryOrTable>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x30, Type: StructProperty)

    void SET_ValueChoiceTable(const FSoftDataRegistryOrTable& Value) { Write<FSoftDataRegistryOrTable>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x30, Type: StructProperty)
};

// Size: 0x90
struct FVariableSelections_ScenarioDefinition : public FVariableSelections
{
public:
    FSoftDataRegistryOrTable ValueChoiceTable() const { return Read<FSoftDataRegistryOrTable>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x30, Type: StructProperty)

    void SET_ValueChoiceTable(const FSoftDataRegistryOrTable& Value) { Write<FSoftDataRegistryOrTable>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x30, Type: StructProperty)
};

// Size: 0x20
struct FVariable_DynamicEncounterConfig : public FVariable
{
public:
    FDataTableRowHandle RowValue() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_RowValue(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x20
struct FVariable_Faction : public FVariable
{
public:
    FDataTableRowHandle RowValue() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_RowValue(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x20
struct FVariable_QuestDefinition : public FVariable
{
public:
    FDataTableRowHandle RowValue() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_RowValue(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x20
struct FVariable_ScenarioDefinition : public FVariable
{
public:
    FDataTableRowHandle RowValue() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_RowValue(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x18
struct FVarRow_DynamicEncounterConfig : public FVarRow
{
public:
    TArray<FDynamicEncounterEntry> Value() const { return Read<TArray<FDynamicEncounterEntry>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Value(const TArray<FDynamicEncounterEntry>& Value) { Write<TArray<FDynamicEncounterEntry>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FVarRow_Faction : public FVarRow
{
public:
    UEncounterFactionData* Value() const { return Read<UEncounterFactionData*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Value(const UEncounterFactionData*& Value) { Write<UEncounterFactionData*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FVarRow_QuestDefinition : public FVarRow
{
public:
    TSoftObjectPtr<UFortQuestItemDefinition> Value() const { return Read<TSoftObjectPtr<UFortQuestItemDefinition>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)

    void SET_Value(const TSoftObjectPtr<UFortQuestItemDefinition>& Value) { Write<TSoftObjectPtr<UFortQuestItemDefinition>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x28
struct FVarRow_ScenarioDefinition : public FVarRow
{
public:
    TSoftObjectPtr<UEncounterItemDefinition> Value() const { return Read<TSoftObjectPtr<UEncounterItemDefinition>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)

    void SET_Value(const TSoftObjectPtr<UEncounterItemDefinition>& Value) { Write<TSoftObjectPtr<UEncounterItemDefinition>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x10
struct FEncounterFactionEnemy
{
public:
    UEncounterFactionData* FactionData() const { return Read<UEncounterFactionData*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_FactionData(const UEncounterFactionData*& Value) { Write<UEncounterFactionData*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x98
struct FEncounterLootEntry
{
public:
    bool bUseLootSelectionTable() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    FName LootTierName() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    FVariableSelections_String LootTierSelection() const { return Read<FVariableSelections_String>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x90, Type: StructProperty)

    void SET_bUseLootSelectionTable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_LootTierName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_LootTierSelection(const FVariableSelections_String& Value) { Write<FVariableSelections_String>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x90, Type: StructProperty)
};

// Size: 0x80
struct FEncounterRewardBehavior
{
public:
    FVector RewardOffset() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector RewardDirection() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FScalableFloat RewardConeAngle() const { return Read<FScalableFloat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x28, Type: StructProperty)
    FScalableFloat RewardFlingMagnitude() const { return Read<FScalableFloat>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x28, Type: StructProperty)

    void SET_RewardOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_RewardDirection(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_RewardConeAngle(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x28, Type: StructProperty)
    void SET_RewardFlingMagnitude(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x28, Type: StructProperty)
};

// Size: 0x28
struct FActorIdentifierEntry
{
public:
    FGameplayTagContainer IdentifierTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    TWeakObjectPtr<AActor*> TargetActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: WeakObjectProperty)

    void SET_IdentifierTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_TargetActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x28
struct FLWMEncounterInfo
{
public:
    ULWMEncounterInstance* LWMEncounter() const { return Read<ULWMEncounterInstance*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_LWMEncounter(const ULWMEncounterInstance*& Value) { Write<ULWMEncounterInstance*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FGameplayEffectIdentifierInfo
{
public:
};

// Size: 0x50
struct FEncounterGroupEffectInfo
{
public:
};

// Size: 0x30
struct FTrackedActorInfo
{
public:
    TWeakObjectPtr<AActor*> TrackedActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_TrackedActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x38
struct FEncounterPrefabInfo
{
public:
    UEncounterItemDefinition* EncounterDefinition() const { return Read<UEncounterItemDefinition*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag EncounterIdentifierTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    FScalableFloat Weight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x28, Type: StructProperty)

    void SET_EncounterDefinition(const UEncounterItemDefinition*& Value) { Write<UEncounterItemDefinition*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_EncounterIdentifierTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_Weight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x28, Type: StructProperty)
};

// Size: 0xa0
struct FActorRemainingCountTransitionStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery ActorIdentifierQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    uint32_t Value() const { return Read<uint32_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: UInt32Property)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    bool bOnlyTriggerOnce() const { return Read<bool>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x1, Type: BoolProperty)
    FEncounterCustomVerbData CustomVerb() const { return Read<FEncounterCustomVerbData>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x28, Type: StructProperty)
    bool bShouldTransition() const { return Read<bool>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: BoolProperty)
    int32_t RemainingCount() const { return Read<int32_t>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: IntProperty)

    void SET_ActorIdentifierQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_Value(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: UInt32Property)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    void SET_bOnlyTriggerOnce(const bool& Value) { Write<bool>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x1, Type: BoolProperty)
    void SET_CustomVerb(const FEncounterCustomVerbData& Value) { Write<FEncounterCustomVerbData>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x28, Type: StructProperty)
    void SET_bShouldTransition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: BoolProperty)
    void SET_RemainingCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: IntProperty)
};

// Size: 0x28
struct FEncounterCustomVerbData
{
public:
    FGameplayTag CustomVerbTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    uint32_t Amount() const { return Read<uint32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: UInt32Property)
    TArray<FFEncounterCustomVerbSubject> Subjects() const { return Read<TArray<FFEncounterCustomVerbSubject>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FFEncounterCustomVerbValue> Values() const { return Read<TArray<FFEncounterCustomVerbValue>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_CustomVerbTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Amount(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: UInt32Property)
    void SET_Subjects(const TArray<FFEncounterCustomVerbSubject>& Value) { Write<TArray<FFEncounterCustomVerbSubject>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_Values(const TArray<FFEncounterCustomVerbValue>& Value) { Write<TArray<FFEncounterCustomVerbValue>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FFEncounterCustomVerbValue
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    double Value() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Value(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x30
struct FFEncounterCustomVerbSubject
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer AdditionalTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_AdditionalTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
};

// Size: 0x28
struct FActorRemainingCountTransitionStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
    FStateTreeStateLink TransitionTo() const { return Read<FStateTreeStateLink>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)

    void SET_TransitionTo(const FStateTreeStateLink& Value) { Write<FStateTreeStateLink>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
};

// Size: 0x50
struct FEncounterPlayerCountTransitionStateTreeTaskInstanceData
{
public:
    uint8_t ComparisonOperator() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    FEncounterCustomVerbData CustomVerb() const { return Read<FEncounterCustomVerbData>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x28, Type: StructProperty)
    bool bShouldTransition() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bOnlyTriggerOnce() const { return Read<bool>(uintptr_t(this) + 0x31); } // 0x31 (Size: 0x1, Type: BoolProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_ComparisonOperator(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_CustomVerb(const FEncounterCustomVerbData& Value) { Write<FEncounterCustomVerbData>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x28, Type: StructProperty)
    void SET_bShouldTransition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_bOnlyTriggerOnce(const bool& Value) { Write<bool>(uintptr_t(this) + 0x31, Value); } // 0x31 (Size: 0x1, Type: BoolProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FEncounterPlayerCountTransitionStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
    FStateTreeStateLink TransitionTo() const { return Read<FStateTreeStateLink>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)

    void SET_TransitionTo(const FStateTreeStateLink& Value) { Write<FStateTreeStateLink>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
};

// Size: 0x38
struct FEncounterSendCustomVerbStateTreeTaskInstanceData
{
public:
    FEncounterCustomVerbData CustomVerb() const { return Read<FEncounterCustomVerbData>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x28, Type: StructProperty)
    bool bSendVerbForEachPlayerAuthor() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_CustomVerb(const FEncounterCustomVerbData& Value) { Write<FEncounterCustomVerbData>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x28, Type: StructProperty)
    void SET_bSendVerbForEachPlayerAuthor(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FEncounterSendCustomVerbStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
};

// Size: 0xc
struct FEncounterValueConditionEntry
{
public:
    int32_t LeftValue() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t RightValue() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    uint8_t ComparisonOperator() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)

    void SET_LeftValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_RightValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_ComparisonOperator(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x50
struct FEncounterValueConditionTransitionStateTreeTaskInstanceData
{
public:
    TArray<FEncounterValueConditionEntry> ValueConditions() const { return Read<TArray<FEncounterValueConditionEntry>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    FEncounterCustomVerbData CustomVerb() const { return Read<FEncounterCustomVerbData>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x28, Type: StructProperty)
    bool bShouldTransition() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)
    bool bOnlyTriggerOnce() const { return Read<bool>(uintptr_t(this) + 0x39); } // 0x39 (Size: 0x1, Type: BoolProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)

    void SET_ValueConditions(const TArray<FEncounterValueConditionEntry>& Value) { Write<TArray<FEncounterValueConditionEntry>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_CustomVerb(const FEncounterCustomVerbData& Value) { Write<FEncounterCustomVerbData>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x28, Type: StructProperty)
    void SET_bShouldTransition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
    void SET_bOnlyTriggerOnce(const bool& Value) { Write<bool>(uintptr_t(this) + 0x39, Value); } // 0x39 (Size: 0x1, Type: BoolProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FEncounterValueConditionTransitionStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
    FStateTreeStateLink TransitionTo() const { return Read<FStateTreeStateLink>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)

    void SET_TransitionTo(const FStateTreeStateLink& Value) { Write<FStateTreeStateLink>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
};

// Size: 0x38
struct FEncounterVerbTransitionConditionEntry
{
public:
    TArray<FInstancedStruct> ObjectiveVerbs() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t ObjectiveValueThreshold() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_ObjectiveVerbs(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_ObjectiveValueThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x60
struct FEncounterVerbTransitionStateTreeTaskInstanceData
{
public:
    bool bUseAdvancedObjectives() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    TArray<FInstancedStruct> ObjectiveVerbs() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    int32_t ObjectiveValueThreshold() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    TArray<FEncounterVerbTransitionConditionEntry> Objectives() const { return Read<TArray<FEncounterVerbTransitionConditionEntry>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_bUseAdvancedObjectives(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_ObjectiveVerbs(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_ObjectiveValueThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_Objectives(const TArray<FEncounterVerbTransitionConditionEntry>& Value) { Write<TArray<FEncounterVerbTransitionConditionEntry>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FEncounterVerbTransitionStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
    FStateTreeStateLink TransitionTo() const { return Read<FStateTreeStateLink>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)

    void SET_TransitionTo(const FStateTreeStateLink& Value) { Write<FStateTreeStateLink>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
};

// Size: 0xa8
struct FLWMEncounterAlertLevelTransitionStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    TArray<EAlertLevel> AlertLevels() const { return Read<TArray<EAlertLevel>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    uint8_t ComparisonOperator() const { return Read<uint8_t>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x1, Type: EnumProperty)
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: IntProperty)
    FEncounterCustomVerbData CustomVerb() const { return Read<FEncounterCustomVerbData>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x28, Type: StructProperty)
    bool bShouldTransition() const { return Read<bool>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: BoolProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)

    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_AlertLevels(const TArray<EAlertLevel>& Value) { Write<TArray<EAlertLevel>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_ComparisonOperator(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x1, Type: EnumProperty)
    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: IntProperty)
    void SET_CustomVerb(const FEncounterCustomVerbData& Value) { Write<FEncounterCustomVerbData>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x28, Type: StructProperty)
    void SET_bShouldTransition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: BoolProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FLWMEncounterAlertLevelTransitionStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
    FStateTreeStateLink TransitionTo() const { return Read<FStateTreeStateLink>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)

    void SET_TransitionTo(const FStateTreeStateLink& Value) { Write<FStateTreeStateLink>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
};

// Size: 0x98
struct FLWMEncounterKillCountTransitionStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    uint32_t Value() const { return Read<uint32_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: UInt32Property)
    FEncounterCustomVerbData CustomVerb() const { return Read<FEncounterCustomVerbData>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x28, Type: StructProperty)
    bool bShouldTransition() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ObjectProperty)

    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_Value(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: UInt32Property)
    void SET_CustomVerb(const FEncounterCustomVerbData& Value) { Write<FEncounterCustomVerbData>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x28, Type: StructProperty)
    void SET_bShouldTransition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FLWMEncounterKillCountTransitionStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
    FStateTreeStateLink TransitionTo() const { return Read<FStateTreeStateLink>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)

    void SET_TransitionTo(const FStateTreeStateLink& Value) { Write<FStateTreeStateLink>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
};

// Size: 0x98
struct FLWMEncounterRemainingCountTransitionStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: IntProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    bool bOnlyTriggerOnce() const { return Read<bool>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x1, Type: BoolProperty)
    FEncounterCustomVerbData CustomVerb() const { return Read<FEncounterCustomVerbData>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x28, Type: StructProperty)
    bool bShouldTransition() const { return Read<bool>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: BoolProperty)

    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: IntProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    void SET_bOnlyTriggerOnce(const bool& Value) { Write<bool>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x1, Type: BoolProperty)
    void SET_CustomVerb(const FEncounterCustomVerbData& Value) { Write<FEncounterCustomVerbData>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x28, Type: StructProperty)
    void SET_bShouldTransition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FLWMEncounterRemainingCountTransitionStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
    FStateTreeStateLink TransitionTo() const { return Read<FStateTreeStateLink>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)

    void SET_TransitionTo(const FStateTreeStateLink& Value) { Write<FStateTreeStateLink>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
};

// Size: 0x90
struct FLWMEncounterSpawnCompleteTransitionStateTreeTaskInstanceData
{
public:
    FGameplayTagQuery EncounterQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    bool bOnlyTriggerOnce() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    FEncounterCustomVerbData CustomVerb() const { return Read<FEncounterCustomVerbData>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x28, Type: StructProperty)
    bool bShouldTransition() const { return Read<bool>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: BoolProperty)

    void SET_EncounterQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    void SET_bOnlyTriggerOnce(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_CustomVerb(const FEncounterCustomVerbData& Value) { Write<FEncounterCustomVerbData>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x28, Type: StructProperty)
    void SET_bShouldTransition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FLWMEncounterSpawnCompleteTransitionStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
    FStateTreeStateLink TransitionTo() const { return Read<FStateTreeStateLink>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)

    void SET_TransitionTo(const FStateTreeStateLink& Value) { Write<FStateTreeStateLink>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
};

// Size: 0x70
struct FLWMWaitForNavMeshTransitionStateTreeTaskInstanceData
{
public:
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AActor*> TargetActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    FScalableFloat Radius() const { return Read<FScalableFloat>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x28, Type: StructProperty)
    FNavAgentProperties NavAgentProperties() const { return Read<FNavAgentProperties>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x30, Type: StructProperty)
    bool bOnlyTriggerOnce() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)

    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Radius(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x28, Type: StructProperty)
    void SET_NavAgentProperties(const FNavAgentProperties& Value) { Write<FNavAgentProperties>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x30, Type: StructProperty)
    void SET_bOnlyTriggerOnce(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FLWMWaitForNavMeshTransitionStateTreeTask : public FFortStateTreeEncounterTaskBase
{
public:
    FStateTreeStateLink TransitionTo() const { return Read<FStateTreeStateLink>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)

    void SET_TransitionTo(const FStateTreeStateLink& Value) { Write<FStateTreeStateLink>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
};

// Size: 0x1d0
struct FFortVerbFilter_EncounterCompleted : public FObjectiveFilter
{
public:
    FObjectiveSubjectTags EncounterItemDef() const { return Read<FObjectiveSubjectTags>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x48, Type: StructProperty)
    uint8_t SuccessState() const { return Read<uint8_t>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: EnumProperty)
    FObjectiveSubjectTags_Progressible Participants() const { return Read<FObjectiveSubjectTags_Progressible>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x50, Type: StructProperty)
    FObjectiveSubjectTags Faction() const { return Read<FObjectiveSubjectTags>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x48, Type: StructProperty)
    FObjectiveSubjectTags EncounterVolumeTags() const { return Read<FObjectiveSubjectTags>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x48, Type: StructProperty)

    void SET_EncounterItemDef(const FObjectiveSubjectTags& Value) { Write<FObjectiveSubjectTags>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x48, Type: StructProperty)
    void SET_SuccessState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: EnumProperty)
    void SET_Participants(const FObjectiveSubjectTags_Progressible& Value) { Write<FObjectiveSubjectTags_Progressible>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x50, Type: StructProperty)
    void SET_Faction(const FObjectiveSubjectTags& Value) { Write<FObjectiveSubjectTags>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x48, Type: StructProperty)
    void SET_EncounterVolumeTags(const FObjectiveSubjectTags& Value) { Write<FObjectiveSubjectTags>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x48, Type: StructProperty)
};

