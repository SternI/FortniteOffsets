/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeVideoPlayerRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "MediaAssets.h"
#include "Engine.h"
#include "GameplayAbilities.h"
#include "CoreUObject.h"
#include "UMG.h"
#include "FortniteGame.h"

// Size: 0xbe8
class UCreativeVideoPlayerFullscreenGameplayAbility : public UFortGameplayAbility
{
public:
    UClass* NoCollisionGameplayEffectClass() const { return Read<UClass*>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: ClassProperty)
    UClass* NoDamageGameplayEffectClass() const { return Read<UClass*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ClassProperty)
    TArray<UClass*> AnimationStateGameplayEffectClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x10, Type: ArrayProperty)
    UClass* FullscreenWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0xb88); } // 0xb88 (Size: 0x8, Type: ClassProperty)
    uint8_t FullscreenEffects() const { return Read<uint8_t>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x1, Type: EnumProperty)
    bool bPromptToConfirmFullscreen() const { return Read<bool>(uintptr_t(this) + 0xb91); } // 0xb91 (Size: 0x1, Type: BoolProperty)
    bool bIsDismissable() const { return Read<bool>(uintptr_t(this) + 0xb92); } // 0xb92 (Size: 0x1, Type: BoolProperty)
    UFortInputComponent* OverrideMovementInputComponent() const { return Read<UFortInputComponent*>(uintptr_t(this) + 0xb98); } // 0xb98 (Size: 0x8, Type: ObjectProperty)
    UFortInputComponent* SelectFullscreenModeInputComponent() const { return Read<UFortInputComponent*>(uintptr_t(this) + 0xba0); } // 0xba0 (Size: 0x8, Type: ObjectProperty)
    TArray<FActiveGameplayEffectHandle> ActiveGameplayEffects() const { return Read<TArray<FActiveGameplayEffectHandle>>(uintptr_t(this) + 0xba8); } // 0xba8 (Size: 0x10, Type: ArrayProperty)
    uint8_t RequestedFullscreenEffects() const { return Read<uint8_t>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x1, Type: EnumProperty)
    UUserWidget* VideoPlayerWidget() const { return Read<UUserWidget*>(uintptr_t(this) + 0xbc0); } // 0xbc0 (Size: 0x8, Type: ObjectProperty)
    UMediaTexture* ExtMediaTextureCached() const { return Read<UMediaTexture*>(uintptr_t(this) + 0xbc8); } // 0xbc8 (Size: 0x8, Type: ObjectProperty)
    USoundSourceBus* ExtSourceBusCached() const { return Read<USoundSourceBus*>(uintptr_t(this) + 0xbd0); } // 0xbd0 (Size: 0x8, Type: ObjectProperty)
    UMediaSoundComponent* ExtMediaSoundComponentCached() const { return Read<UMediaSoundComponent*>(uintptr_t(this) + 0xbd8); } // 0xbd8 (Size: 0x8, Type: ObjectProperty)
    bool bExtComponentsSet() const { return Read<bool>(uintptr_t(this) + 0xbe0); } // 0xbe0 (Size: 0x1, Type: BoolProperty)
    bool bActivatedFullscreen() const { return Read<bool>(uintptr_t(this) + 0xbe1); } // 0xbe1 (Size: 0x1, Type: BoolProperty)

    void SET_NoCollisionGameplayEffectClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: ClassProperty)
    void SET_NoDamageGameplayEffectClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ClassProperty)
    void SET_AnimationStateGameplayEffectClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x10, Type: ArrayProperty)
    void SET_FullscreenWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb88, Value); } // 0xb88 (Size: 0x8, Type: ClassProperty)
    void SET_FullscreenEffects(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x1, Type: EnumProperty)
    void SET_bPromptToConfirmFullscreen(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb91, Value); } // 0xb91 (Size: 0x1, Type: BoolProperty)
    void SET_bIsDismissable(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb92, Value); } // 0xb92 (Size: 0x1, Type: BoolProperty)
    void SET_OverrideMovementInputComponent(const UFortInputComponent*& Value) { Write<UFortInputComponent*>(uintptr_t(this) + 0xb98, Value); } // 0xb98 (Size: 0x8, Type: ObjectProperty)
    void SET_SelectFullscreenModeInputComponent(const UFortInputComponent*& Value) { Write<UFortInputComponent*>(uintptr_t(this) + 0xba0, Value); } // 0xba0 (Size: 0x8, Type: ObjectProperty)
    void SET_ActiveGameplayEffects(const TArray<FActiveGameplayEffectHandle>& Value) { Write<TArray<FActiveGameplayEffectHandle>>(uintptr_t(this) + 0xba8, Value); } // 0xba8 (Size: 0x10, Type: ArrayProperty)
    void SET_RequestedFullscreenEffects(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x1, Type: EnumProperty)
    void SET_VideoPlayerWidget(const UUserWidget*& Value) { Write<UUserWidget*>(uintptr_t(this) + 0xbc0, Value); } // 0xbc0 (Size: 0x8, Type: ObjectProperty)
    void SET_ExtMediaTextureCached(const UMediaTexture*& Value) { Write<UMediaTexture*>(uintptr_t(this) + 0xbc8, Value); } // 0xbc8 (Size: 0x8, Type: ObjectProperty)
    void SET_ExtSourceBusCached(const USoundSourceBus*& Value) { Write<USoundSourceBus*>(uintptr_t(this) + 0xbd0, Value); } // 0xbd0 (Size: 0x8, Type: ObjectProperty)
    void SET_ExtMediaSoundComponentCached(const UMediaSoundComponent*& Value) { Write<UMediaSoundComponent*>(uintptr_t(this) + 0xbd8, Value); } // 0xbd8 (Size: 0x8, Type: ObjectProperty)
    void SET_bExtComponentsSet(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbe0, Value); } // 0xbe0 (Size: 0x1, Type: BoolProperty)
    void SET_bActivatedFullscreen(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbe1, Value); } // 0xbe1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UCreativeVideoPlayerFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x40
class UCreativeVideoPlayerWorldSubsystem : public UWorldSubsystem
{
public:
};

// Size: 0x2
struct FCreativeVideoPlayerFullscreenOptions
{
public:
    uint8_t GameplayEffects() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    bool bPromptFirst() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)

    void SET_GameplayEffects(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_bPromptFirst(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
};

