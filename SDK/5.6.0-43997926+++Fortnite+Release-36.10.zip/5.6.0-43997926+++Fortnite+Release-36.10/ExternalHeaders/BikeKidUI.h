/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BikeKidUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "UMG.h"
#include "BikeKidRuntime.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"
#include "Engine.h"

// Size: 0xa0
class UFortMobileActionButtonBehaviorExtension_BikeKidUse : public UFortMobileActionButtonBehaviorExtension
{
public:
    FGameplayTagContainer ContextTagToCheck() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x20, Type: StructProperty)

    void SET_ContextTagToCheck(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x20, Type: StructProperty)
};

// Size: 0x418
class UBikeKidHUD : public UUserWidget
{
public:
    float TimeToConfirmTargetCache() const { return Read<float>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x4, Type: FloatProperty)
    float InitialHealth() const { return Read<float>(uintptr_t(this) + 0x324); } // 0x324 (Size: 0x4, Type: FloatProperty)
    FScalableFloat WarningRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x28, Type: StructProperty)
    FScalableFloat SignalLossRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x28, Type: StructProperty)
    FScalableFloat UpdateSignalInterval() const { return Read<FScalableFloat>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x28, Type: StructProperty)
    FGameplayTag MarkAbilityTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x4, Type: StructProperty)
    FGameplayTag DismissAbilityTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3a4); } // 0x3a4 (Size: 0x4, Type: StructProperty)
    FGameplayTag SpeedBoostAbilityTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x4, Type: StructProperty)
    UOverlay* Overlay_Health() const { return Read<UOverlay*>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_EnergyLevel() const { return Read<UOverlay*>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_Reticle() const { return Read<UOverlay*>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_TetheringIndicator() const { return Read<UOverlay*>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    float MaxHealthCache() const { return Read<float>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x4, Type: FloatProperty)
    float MaxEnergyCache() const { return Read<float>(uintptr_t(this) + 0x3d4); } // 0x3d4 (Size: 0x4, Type: FloatProperty)
    FTimerHandle SignalDataTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x8, Type: StructProperty)
    TArray<FBikeKidWidgetIdentifier> HUDIdentifiers() const { return Read<TArray<FBikeKidWidgetIdentifier>>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x10, Type: ArrayProperty)

    void SET_TimeToConfirmTargetCache(const float& Value) { Write<float>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x4, Type: FloatProperty)
    void SET_InitialHealth(const float& Value) { Write<float>(uintptr_t(this) + 0x324, Value); } // 0x324 (Size: 0x4, Type: FloatProperty)
    void SET_WarningRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x28, Type: StructProperty)
    void SET_SignalLossRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x28, Type: StructProperty)
    void SET_UpdateSignalInterval(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x28, Type: StructProperty)
    void SET_MarkAbilityTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x4, Type: StructProperty)
    void SET_DismissAbilityTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3a4, Value); } // 0x3a4 (Size: 0x4, Type: StructProperty)
    void SET_SpeedBoostAbilityTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x4, Type: StructProperty)
    void SET_Overlay_Health(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_EnergyLevel(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_Reticle(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_TetheringIndicator(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    void SET_MaxHealthCache(const float& Value) { Write<float>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxEnergyCache(const float& Value) { Write<float>(uintptr_t(this) + 0x3d4, Value); } // 0x3d4 (Size: 0x4, Type: FloatProperty)
    void SET_SignalDataTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x8, Type: StructProperty)
    void SET_HUDIdentifiers(const TArray<FBikeKidWidgetIdentifier>& Value) { Write<TArray<FBikeKidWidgetIdentifier>>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x340
class UBikeKidTetherIndicator : public UUserWidget
{
public:
};

// Size: 0x2e8
class ABikeKidUIDirector : public ADynamicUIDirectorBase
{
public:
    FGameplayTagContainer HUDTagsToHide() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x20, Type: StructProperty)

    void SET_HUDTagsToHide(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x20, Type: StructProperty)
};

// Size: 0x28
struct FBikeKidWidgetIdentifier
{
public:
    FGameplayTagContainer Tags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    TWeakObjectPtr<UWidget*> WeakWdiget() const { return Read<TWeakObjectPtr<UWidget*>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Tags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_WeakWdiget(const TWeakObjectPtr<UWidget*>& Value) { Write<TWeakObjectPtr<UWidget*>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: WeakObjectProperty)
};

