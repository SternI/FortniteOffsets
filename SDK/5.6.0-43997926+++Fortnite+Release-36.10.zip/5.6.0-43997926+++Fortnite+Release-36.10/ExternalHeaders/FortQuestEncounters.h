/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortQuestEncounters
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "EncountersRuntime.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x48
class UFortQuestEncounterHotfixData : public UObject
{
public:
    TArray<FString> DisabledScenarios() const { return Read<TArray<FString>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> DisabledSpawners() const { return Read<TArray<FName>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_DisabledScenarios(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_DisabledSpawners(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x9c0
class AFortQuestEncounterGameplayVolume : public AEncounterGameplayVolume
{
public:
    bool bShouldOverridePlayspaceParticipation() const { return Read<bool>(uintptr_t(this) + 0x970); } // 0x970 (Size: 0x1, Type: BoolProperty)
    bool bShouldOverrideQuestSpatialRelevancy() const { return Read<bool>(uintptr_t(this) + 0x971); } // 0x971 (Size: 0x1, Type: BoolProperty)
    FGameplayTagQuery IncludedOverlapTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x978); } // 0x978 (Size: 0x48, Type: StructProperty)

    void SET_bShouldOverridePlayspaceParticipation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x970, Value); } // 0x970 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldOverrideQuestSpatialRelevancy(const bool& Value) { Write<bool>(uintptr_t(this) + 0x971, Value); } // 0x971 (Size: 0x1, Type: BoolProperty)
    void SET_IncludedOverlapTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x978, Value); } // 0x978 (Size: 0x48, Type: StructProperty)
};

// Size: 0x450
class AFortQuestEncounterSpawnerVolume : public AFortOverlapTrackingVolume
{
public:
    USceneComponent* ComponentAnchor() const { return Read<USceneComponent*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    bool bIsEncounterSpawningEnabled() const { return Read<bool>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x1, Type: BoolProperty)
    USceneComponent* EncounterSpawnPoint() const { return Read<USceneComponent*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    FInstancedStruct EncounterTrigger() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x10, Type: StructProperty)
    TArray<FEncounterPrefabInfo> EncounterEntries() const { return Read<TArray<FEncounterPrefabInfo>>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x10, Type: ArrayProperty)
    FName SpawnerVolumeName() const { return Read<FName>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x4, Type: NameProperty)
    bool bAllowInclusionInExternalOverlaps() const { return Read<bool>(uintptr_t(this) + 0x3c4); } // 0x3c4 (Size: 0x1, Type: BoolProperty)
    ALivingWorldEncounterPrefab* LivingWorldPrefab() const { return Read<ALivingWorldEncounterPrefab*>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    TArray<FFilteredEventReceiverHandle> VerbHandles() const { return Read<TArray<FFilteredEventReceiverHandle>>(uintptr_t(this) + 0x438); } // 0x438 (Size: 0x10, Type: ArrayProperty)

    void SET_ComponentAnchor(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsEncounterSpawningEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x1, Type: BoolProperty)
    void SET_EncounterSpawnPoint(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    void SET_EncounterTrigger(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x10, Type: StructProperty)
    void SET_EncounterEntries(const TArray<FEncounterPrefabInfo>& Value) { Write<TArray<FEncounterPrefabInfo>>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x10, Type: ArrayProperty)
    void SET_SpawnerVolumeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x4, Type: NameProperty)
    void SET_bAllowInclusionInExternalOverlaps(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c4, Value); } // 0x3c4 (Size: 0x1, Type: BoolProperty)
    void SET_LivingWorldPrefab(const ALivingWorldEncounterPrefab*& Value) { Write<ALivingWorldEncounterPrefab*>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    void SET_VerbHandles(const TArray<FFilteredEventReceiverHandle>& Value) { Write<TArray<FFilteredEventReceiverHandle>>(uintptr_t(this) + 0x438, Value); } // 0x438 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xac8
class ALivingWorldEncounterPrefab_QuestEncounters : public ALivingWorldEncounterPrefab
{
public:
};

// Size: 0x8
struct FQuestEncounterTriggerType
{
public:
};

// Size: 0x8
struct FQuestEncounterTriggerType_VolumeEntered : public FQuestEncounterTriggerType
{
public:
};

// Size: 0x10
struct FQuestEncounterTriggerType_RequiredQuest : public FQuestEncounterTriggerType
{
public:
    UFortQuestItemDefinition* RequiredQuest() const { return Read<UFortQuestItemDefinition*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_RequiredQuest(const UFortQuestItemDefinition*& Value) { Write<UFortQuestItemDefinition*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FQuestEncounterTriggerType_EventTrigger : public FQuestEncounterTriggerType
{
public:
    TArray<FInstancedStruct> EventVerbs() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    int32_t DesiredCount() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)

    void SET_EventVerbs(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_DesiredCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
};

// Size: 0x28
struct FQuestEncounterTriggerType_QuestAndEventTrigger : public FQuestEncounterTriggerType_EventTrigger
{
public:
    UFortQuestItemDefinition* RequiredQuest() const { return Read<UFortQuestItemDefinition*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)

    void SET_RequiredQuest(const UFortQuestItemDefinition*& Value) { Write<UFortQuestItemDefinition*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
};

