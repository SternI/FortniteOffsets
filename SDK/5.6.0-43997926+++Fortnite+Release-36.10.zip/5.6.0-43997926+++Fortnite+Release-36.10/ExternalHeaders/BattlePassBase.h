/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BattlePassBase
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CommonUI.h"

// Size: 0x330
class UFortBattlePassLevelCount : public UUserWidget
{
public:
    UCommonTextBlock* Text_LevelCount() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: ObjectProperty)

    void SET_Text_LevelCount(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x320
class URebootRallyQuestPanel : public UUserWidget
{
public:
};

