/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarFrontendMinimal
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "VehicleCosmeticsPreviewRuntime.h"
#include "FortniteUI.h"
#include "CosmeticsFrameworkLoadouts.h"

// Size: 0x100
class UDelMarFrontendSubsystem : public UFortLocalPlayerSubsystem
{
public:
    TWeakObjectPtr<AVehicleCosmeticsPreviewVehicle*> PreviewVehicle() const { return Read<TWeakObjectPtr<AVehicleCosmeticsPreviewVehicle*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: WeakObjectProperty)
    FFrontendLobbyActor LobbyVehicleActorData() const { return Read<FFrontendLobbyActor>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x70, Type: StructProperty)
    FCosmeticLoadoutSlot LobbyVehicleDefaultBody() const { return Read<FCosmeticLoadoutSlot>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x20, Type: StructProperty)

    void SET_PreviewVehicle(const TWeakObjectPtr<AVehicleCosmeticsPreviewVehicle*>& Value) { Write<TWeakObjectPtr<AVehicleCosmeticsPreviewVehicle*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: WeakObjectProperty)
    void SET_LobbyVehicleActorData(const FFrontendLobbyActor& Value) { Write<FFrontendLobbyActor>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x70, Type: StructProperty)
    void SET_LobbyVehicleDefaultBody(const FCosmeticLoadoutSlot& Value) { Write<FCosmeticLoadoutSlot>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x20, Type: StructProperty)
};

