/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EngineCameras
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "TemplateSequence.h"

// Size: 0x1f0
class ULegacyCameraShake : public UCameraShakeBase
{
public:
    float OscillationDuration() const { return Read<float>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    float OscillationBlendInTime() const { return Read<float>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x4, Type: FloatProperty)
    float OscillationBlendOutTime() const { return Read<float>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: FloatProperty)
    FROscillator RotOscillation() const { return Read<FROscillator>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x24, Type: StructProperty)
    FVOscillator LocOscillation() const { return Read<FVOscillator>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x24, Type: StructProperty)
    FFOscillator FOVOscillation() const { return Read<FFOscillator>(uintptr_t(this) + 0x12c); } // 0x12c (Size: 0xc, Type: StructProperty)
    float AnimPlayRate() const { return Read<float>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: FloatProperty)
    float AnimScale() const { return Read<float>(uintptr_t(this) + 0x13c); } // 0x13c (Size: 0x4, Type: FloatProperty)
    float AnimBlendInTime() const { return Read<float>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x4, Type: FloatProperty)
    float AnimBlendOutTime() const { return Read<float>(uintptr_t(this) + 0x144); } // 0x144 (Size: 0x4, Type: FloatProperty)
    float RandomAnimSegmentDuration() const { return Read<float>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x4, Type: FloatProperty)
    UCameraAnimationSequence* AnimSequence() const { return Read<UCameraAnimationSequence*>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x8, Type: ObjectProperty)
    bool bRandomAnimSegment() const { return (Read<uint8_t>(uintptr_t(this) + 0x158) >> 0x0) & 1; } // 0x158:0 (Size: 0x1, Type: BoolProperty)
    float OscillatorTimeRemaining() const { return Read<float>(uintptr_t(this) + 0x15c); } // 0x15c (Size: 0x4, Type: FloatProperty)
    USequenceCameraShakePattern* SequenceShakePattern() const { return Read<USequenceCameraShakePattern*>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)

    void SET_OscillationDuration(const float& Value) { Write<float>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    void SET_OscillationBlendInTime(const float& Value) { Write<float>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x4, Type: FloatProperty)
    void SET_OscillationBlendOutTime(const float& Value) { Write<float>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: FloatProperty)
    void SET_RotOscillation(const FROscillator& Value) { Write<FROscillator>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x24, Type: StructProperty)
    void SET_LocOscillation(const FVOscillator& Value) { Write<FVOscillator>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x24, Type: StructProperty)
    void SET_FOVOscillation(const FFOscillator& Value) { Write<FFOscillator>(uintptr_t(this) + 0x12c, Value); } // 0x12c (Size: 0xc, Type: StructProperty)
    void SET_AnimPlayRate(const float& Value) { Write<float>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: FloatProperty)
    void SET_AnimScale(const float& Value) { Write<float>(uintptr_t(this) + 0x13c, Value); } // 0x13c (Size: 0x4, Type: FloatProperty)
    void SET_AnimBlendInTime(const float& Value) { Write<float>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x4, Type: FloatProperty)
    void SET_AnimBlendOutTime(const float& Value) { Write<float>(uintptr_t(this) + 0x144, Value); } // 0x144 (Size: 0x4, Type: FloatProperty)
    void SET_RandomAnimSegmentDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x4, Type: FloatProperty)
    void SET_AnimSequence(const UCameraAnimationSequence*& Value) { Write<UCameraAnimationSequence*>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x8, Type: ObjectProperty)
    void SET_bRandomAnimSegment(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x158); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x158, B); } // 0x158:0 (Size: 0x1, Type: BoolProperty)
    void SET_OscillatorTimeRemaining(const float& Value) { Write<float>(uintptr_t(this) + 0x15c, Value); } // 0x15c (Size: 0x4, Type: FloatProperty)
    void SET_SequenceShakePattern(const USequenceCameraShakePattern*& Value) { Write<USequenceCameraShakePattern*>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class ULegacyCameraShakePattern : public UCameraShakePattern
{
public:
};

// Size: 0x28
class ULegacyCameraShakeFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x60
class UCameraAnimationCameraModifier : public UCameraModifier
{
public:
    TArray<FActiveCameraAnimationInfo> ActiveAnimations() const { return Read<TArray<FActiveCameraAnimationInfo>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    uint16_t NextInstanceSerialNumber() const { return Read<uint16_t>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x2, Type: UInt16Property)

    void SET_ActiveAnimations(const TArray<FActiveCameraAnimationInfo>& Value) { Write<TArray<FActiveCameraAnimationInfo>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_NextInstanceSerialNumber(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x2, Type: UInt16Property)
};

// Size: 0x28
class UEngineCameraAnimationFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x30
class UEngineCamerasSubsystem : public UWorldSubsystem
{
public:
};

// Size: 0x38
class UCompositeCameraShakePattern : public UCameraShakePattern
{
public:
    TArray<UCameraShakePattern*> ChildPatterns() const { return Read<TArray<UCameraShakePattern*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_ChildPatterns(const TArray<UCameraShakePattern*>& Value) { Write<TArray<UCameraShakePattern*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xe0
class UDefaultCameraShakeBase : public UCameraShakeBase
{
public:
};

// Size: 0xd8
class UPerlinNoiseCameraShakePattern : public USimpleCameraShakePattern
{
public:
    float LocationAmplitudeMultiplier() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    float LocationFrequencyMultiplier() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)
    FPerlinNoiseShaker X() const { return Read<FPerlinNoiseShaker>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: StructProperty)
    FPerlinNoiseShaker Y() const { return Read<FPerlinNoiseShaker>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: StructProperty)
    FPerlinNoiseShaker Z() const { return Read<FPerlinNoiseShaker>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: StructProperty)
    float RotationAmplitudeMultiplier() const { return Read<float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: FloatProperty)
    float RotationFrequencyMultiplier() const { return Read<float>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: FloatProperty)
    FPerlinNoiseShaker pitch() const { return Read<FPerlinNoiseShaker>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: StructProperty)
    FPerlinNoiseShaker Yaw() const { return Read<FPerlinNoiseShaker>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: StructProperty)
    FPerlinNoiseShaker Roll() const { return Read<FPerlinNoiseShaker>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: StructProperty)
    FPerlinNoiseShaker FOV() const { return Read<FPerlinNoiseShaker>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: StructProperty)

    void SET_LocationAmplitudeMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_LocationFrequencyMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
    void SET_X(const FPerlinNoiseShaker& Value) { Write<FPerlinNoiseShaker>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: StructProperty)
    void SET_Y(const FPerlinNoiseShaker& Value) { Write<FPerlinNoiseShaker>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: StructProperty)
    void SET_Z(const FPerlinNoiseShaker& Value) { Write<FPerlinNoiseShaker>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: StructProperty)
    void SET_RotationAmplitudeMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: FloatProperty)
    void SET_RotationFrequencyMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: FloatProperty)
    void SET_pitch(const FPerlinNoiseShaker& Value) { Write<FPerlinNoiseShaker>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: StructProperty)
    void SET_Yaw(const FPerlinNoiseShaker& Value) { Write<FPerlinNoiseShaker>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: StructProperty)
    void SET_Roll(const FPerlinNoiseShaker& Value) { Write<FPerlinNoiseShaker>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: StructProperty)
    void SET_FOV(const FPerlinNoiseShaker& Value) { Write<FPerlinNoiseShaker>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: StructProperty)
};

// Size: 0x58
class USimpleCameraShakePattern : public UCameraShakePattern
{
public:
    float duration() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float BlendInTime() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float BlendOutTime() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)

    void SET_duration(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_BlendInTime(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_BlendOutTime(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xf8
class UWaveOscillatorCameraShakePattern : public USimpleCameraShakePattern
{
public:
    float LocationAmplitudeMultiplier() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    float LocationFrequencyMultiplier() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)
    FWaveOscillator X() const { return Read<FWaveOscillator>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0xc, Type: StructProperty)
    FWaveOscillator Y() const { return Read<FWaveOscillator>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0xc, Type: StructProperty)
    FWaveOscillator Z() const { return Read<FWaveOscillator>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0xc, Type: StructProperty)
    float RotationAmplitudeMultiplier() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    float RotationFrequencyMultiplier() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)
    FWaveOscillator pitch() const { return Read<FWaveOscillator>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0xc, Type: StructProperty)
    FWaveOscillator Yaw() const { return Read<FWaveOscillator>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0xc, Type: StructProperty)
    FWaveOscillator Roll() const { return Read<FWaveOscillator>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0xc, Type: StructProperty)
    FWaveOscillator FOV() const { return Read<FWaveOscillator>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0xc, Type: StructProperty)

    void SET_LocationAmplitudeMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_LocationFrequencyMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
    void SET_X(const FWaveOscillator& Value) { Write<FWaveOscillator>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0xc, Type: StructProperty)
    void SET_Y(const FWaveOscillator& Value) { Write<FWaveOscillator>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0xc, Type: StructProperty)
    void SET_Z(const FWaveOscillator& Value) { Write<FWaveOscillator>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0xc, Type: StructProperty)
    void SET_RotationAmplitudeMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_RotationFrequencyMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
    void SET_pitch(const FWaveOscillator& Value) { Write<FWaveOscillator>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0xc, Type: StructProperty)
    void SET_Yaw(const FWaveOscillator& Value) { Write<FWaveOscillator>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0xc, Type: StructProperty)
    void SET_Roll(const FWaveOscillator& Value) { Write<FWaveOscillator>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0xc, Type: StructProperty)
    void SET_FOV(const FWaveOscillator& Value) { Write<FWaveOscillator>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0xc, Type: StructProperty)
};

// Size: 0xe0
class UTestCameraShake : public UCameraShakeBase
{
public:
};

// Size: 0x88
class UConstantCameraShakePattern : public USimpleCameraShakePattern
{
public:
    FVector LocationOffset() const { return Read<FVector>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)
    FRotator RotationOffset() const { return Read<FRotator>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)

    void SET_LocationOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
    void SET_RotationOffset(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
};

// Size: 0xc
struct FFOscillator
{
public:
    float Amplitude() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Frequency() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EInitialOscillatorOffset> InitialOffset() const { return Read<TEnumAsByte<EInitialOscillatorOffset>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: ByteProperty)
    uint8_t Waveform() const { return Read<uint8_t>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: EnumProperty)

    void SET_Amplitude(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Frequency(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_InitialOffset(const TEnumAsByte<EInitialOscillatorOffset>& Value) { Write<TEnumAsByte<EInitialOscillatorOffset>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: ByteProperty)
    void SET_Waveform(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x24
struct FROscillator
{
public:
    FFOscillator pitch() const { return Read<FFOscillator>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FFOscillator Yaw() const { return Read<FFOscillator>(uintptr_t(this) + 0xc); } // 0xc (Size: 0xc, Type: StructProperty)
    FFOscillator Roll() const { return Read<FFOscillator>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0xc, Type: StructProperty)

    void SET_pitch(const FFOscillator& Value) { Write<FFOscillator>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_Yaw(const FFOscillator& Value) { Write<FFOscillator>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0xc, Type: StructProperty)
    void SET_Roll(const FFOscillator& Value) { Write<FFOscillator>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0xc, Type: StructProperty)
};

// Size: 0x24
struct FVOscillator
{
public:
    FFOscillator X() const { return Read<FFOscillator>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FFOscillator Y() const { return Read<FFOscillator>(uintptr_t(this) + 0xc); } // 0xc (Size: 0xc, Type: StructProperty)
    FFOscillator Z() const { return Read<FFOscillator>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0xc, Type: StructProperty)

    void SET_X(const FFOscillator& Value) { Write<FFOscillator>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_Y(const FFOscillator& Value) { Write<FFOscillator>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0xc, Type: StructProperty)
    void SET_Z(const FFOscillator& Value) { Write<FFOscillator>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0xc, Type: StructProperty)
};

// Size: 0x48
struct FCameraAnimationParams
{
public:
    float PlayRate() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t EaseInType() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    float EaseInDuration() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    uint8_t EaseOutType() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    float EaseOutDuration() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    bool bLoop() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    int32_t StartOffset() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    bool bRandomStartTime() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    float DurationOverride() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    uint8_t Playspace() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    FRotator UserPlaySpaceRot() const { return Read<FRotator>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)

    void SET_PlayRate(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_EaseInType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_EaseInDuration(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_EaseOutType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_EaseOutDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_bLoop(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_StartOffset(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_bRandomStartTime(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_DurationOverride(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_Playspace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_UserPlaySpaceRot(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
};

// Size: 0x4
struct FCameraAnimationHandle
{
public:
};

// Size: 0x78
struct FActiveCameraAnimationInfo
{
public:
    UCameraAnimationSequence* Sequence() const { return Read<UCameraAnimationSequence*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FCameraAnimationParams Params() const { return Read<FCameraAnimationParams>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x48, Type: StructProperty)
    FCameraAnimationHandle Handle() const { return Read<FCameraAnimationHandle>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: StructProperty)
    UCameraAnimationSequencePlayer* Player() const { return Read<UCameraAnimationSequencePlayer*>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: ObjectProperty)
    UCameraAnimationSequenceCameraStandIn* CameraStandIn() const { return Read<UCameraAnimationSequenceCameraStandIn*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    float EaseInCurrentTime() const { return Read<float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: FloatProperty)
    float EaseOutCurrentTime() const { return Read<float>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: FloatProperty)
    bool bIsEasingIn() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    bool bIsEasingOut() const { return Read<bool>(uintptr_t(this) + 0x71); } // 0x71 (Size: 0x1, Type: BoolProperty)

    void SET_Sequence(const UCameraAnimationSequence*& Value) { Write<UCameraAnimationSequence*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Params(const FCameraAnimationParams& Value) { Write<FCameraAnimationParams>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x48, Type: StructProperty)
    void SET_Handle(const FCameraAnimationHandle& Value) { Write<FCameraAnimationHandle>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: StructProperty)
    void SET_Player(const UCameraAnimationSequencePlayer*& Value) { Write<UCameraAnimationSequencePlayer*>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: ObjectProperty)
    void SET_CameraStandIn(const UCameraAnimationSequenceCameraStandIn*& Value) { Write<UCameraAnimationSequenceCameraStandIn*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_EaseInCurrentTime(const float& Value) { Write<float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: FloatProperty)
    void SET_EaseOutCurrentTime(const float& Value) { Write<float>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: FloatProperty)
    void SET_bIsEasingIn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_bIsEasingOut(const bool& Value) { Write<bool>(uintptr_t(this) + 0x71, Value); } // 0x71 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x8
struct FPerlinNoiseShaker
{
public:
    float Amplitude() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Frequency() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_Amplitude(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Frequency(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc
struct FWaveOscillator
{
public:
    float Amplitude() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Frequency() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t InitialOffsetType() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)

    void SET_Amplitude(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Frequency(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_InitialOffsetType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
};

