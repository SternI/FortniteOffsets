/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_ModalDialogRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "UMG.h"

// Size: 0x498
class UModalDialogVariant : public UCommonActivatableWidget
{
public:
    UWidgetAnimation* BoundAnim_Open() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* BoundAnim_Response() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)

    void SET_BoundAnim_Open(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    void SET_BoundAnim_Response(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
};

