/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_VehicleCosmeticsTrailTest
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x2b8
class ABP_VehicleCosmeticsTrailTest_C : public AActor
{
public:
    UStaticMeshComponent* StaticMesh() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)

    void SET_StaticMesh(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
};

