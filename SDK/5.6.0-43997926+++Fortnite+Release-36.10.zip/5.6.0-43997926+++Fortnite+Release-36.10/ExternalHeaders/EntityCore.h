/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EntityCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "_Verse.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x60
class UEntityPositionComponent : public UEntityDataBackedComponent
{
public:
};

// Size: 0x60
class UEntityDataBackedComponent : public UEntityComponent
{
public:
};

// Size: 0x58
class UEntityComponent : public UObject
{
public:
};

// Size: 0x60
class UEntityRotationComponent : public UEntityDataBackedComponent
{
public:
};

// Size: 0x60
class UEntityScaleComponent : public UEntityDataBackedComponent
{
public:
};

// Size: 0x60
class UEntityCoreDataBackedRelativePositionComponent : public UEntityDataBackedComponent
{
public:
};

// Size: 0x38
class UEntity : public UObject
{
public:
    ULevel* Level() const { return Read<ULevel*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_Level(const ULevel*& Value) { Write<ULevel*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x150
class UEntityCoreSubsystem : public UWorldSubsystem
{
public:
    TMap<FEntityComponentContainer, uint32_t> ComponentMap() const { return Read<TMap<FEntityComponentContainer, uint32_t>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x50, Type: MapProperty)
    TArray<UEntityComponent*> ComponentArray() const { return Read<TArray<UEntityComponent*>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
    TMap<UEntity*, uint32_t> Entities() const { return Read<TMap<UEntity*, uint32_t>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x50, Type: MapProperty)

    void SET_ComponentMap(const TMap<FEntityComponentContainer, uint32_t>& Value) { Write<TMap<FEntityComponentContainer, uint32_t>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x50, Type: MapProperty)
    void SET_ComponentArray(const TArray<UEntityComponent*>& Value) { Write<TArray<UEntityComponent*>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
    void SET_Entities(const TMap<UEntity*, uint32_t>& Value) { Write<TMap<UEntity*, uint32_t>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x50, Type: MapProperty)
};

// Size: 0x78
class UEntityEnableableComponent : public UEntityComponent
{
public:
    bool IsEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x58) >> 0x0) & 1; } // 0x58:0 (Size: 0x1, Type: BoolProperty)
    bool LastIsEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x58) >> 0x1) & 1; } // 0x58:1 (Size: 0x1, Type: BoolProperty)

    void SET_IsEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x58); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x58, B); } // 0x58:0 (Size: 0x1, Type: BoolProperty)
    void SET_LastIsEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x58); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x58, B); } // 0x58:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb0
class UEntityScriptComponent : public UEntityTickableComponent
{
public:
};

// Size: 0xb0
class UEntityTickableComponent : public UEntityEnableableComponent
{
public:
};

// Size: 0x1
struct FComponentData
{
public:
};

// Size: 0x18
struct FEntityPositionComponentData : public FComponentData
{
public:
    FVector WorldPosition() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)

    void SET_WorldPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
};

// Size: 0x18
struct FEntityRotationComponentData : public FComponentData
{
public:
    FRotator WorldRotation() const { return Read<FRotator>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)

    void SET_WorldRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
};

// Size: 0x18
struct FEntityScaleComponentData : public FComponentData
{
public:
    FVector WorldScale3D() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)

    void SET_WorldScale3D(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
};

// Size: 0x20
struct FEntityCoreSystemRelativePositionComponentData : public FComponentData
{
public:
};

// Size: 0x10
struct FEntityComponentContainer
{
public:
    TArray<UEntityComponent*> Array() const { return Read<TArray<UEntityComponent*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Array(const TArray<UEntityComponent*>& Value) { Write<TArray<UEntityComponent*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FEntityTickFunction : public FTickFunction
{
public:
};

