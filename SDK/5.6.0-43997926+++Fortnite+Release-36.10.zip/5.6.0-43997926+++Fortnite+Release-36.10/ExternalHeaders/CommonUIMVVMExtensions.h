/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CommonUIMVVMExtensions
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "EnhancedInput.h"
#include "ModelViewViewModel.h"
#include "Engine.h"
#include "CommonUI.h"

// Size: 0x420
class UActionWidget : public UCommonActionWidget
{
public:
};

// Size: 0x78
class UMVVMViewEnhancedInputExtension : public UMVVMViewExtension
{
public:
    FUIActionBindingHandle UIActionBindingHandle() const { return Read<FUIActionBindingHandle>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: StructProperty)
    FTimerHandle PendingWidgetParentAssignmentTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: StructProperty)
    TWeakObjectPtr<UCommonActionWidget*> ActionWidget() const { return Read<TWeakObjectPtr<UCommonActionWidget*>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: WeakObjectProperty)
    UMVVMViewEnhancedInputClassExtension* ClassExtension() const { return Read<UMVVMViewEnhancedInputClassExtension*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)

    void SET_UIActionBindingHandle(const FUIActionBindingHandle& Value) { Write<FUIActionBindingHandle>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: StructProperty)
    void SET_PendingWidgetParentAssignmentTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: StructProperty)
    void SET_ActionWidget(const TWeakObjectPtr<UCommonActionWidget*>& Value) { Write<TWeakObjectPtr<UCommonActionWidget*>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ClassExtension(const UMVVMViewEnhancedInputClassExtension*& Value) { Write<UMVVMViewEnhancedInputClassExtension*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x38
class UMVVMViewEnhancedInputClassExtension : public UMVVMViewClassExtension
{
public:
    FName WidgetName() const { return Read<FName>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: NameProperty)
    FName EnhancedInputPropertyName() const { return Read<FName>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: NameProperty)
    int32_t Priority() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    FMVVMVCompiledFieldPath WidgetPath() const { return Read<FMVVMVCompiledFieldPath>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: StructProperty)

    void SET_WidgetName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: NameProperty)
    void SET_EnhancedInputPropertyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: NameProperty)
    void SET_Priority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_WidgetPath(const FMVVMVCompiledFieldPath& Value) { Write<FMVVMVCompiledFieldPath>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: StructProperty)
};

