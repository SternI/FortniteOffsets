/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CosmeticShoesRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "CoreUObject.h"
#include "CustomizableObject.h"
#include "Engine.h"

// Size: 0x80
class UCosmeticItemStep_ShoesCharacterPartSetup : public UFortCosmeticStep
{
public:
};

// Size: 0x80
class UCosmeticItemStep_ShoesPostCharacterPartSetup : public UFortCosmeticStep
{
public:
};

// Size: 0x80
class UCosmeticItemStep_ShoesPostCustomizableObject : public UFortCosmeticStep
{
public:
};

// Size: 0x80
class UCosmeticItemStep_ShoesRunCustomizableObject : public UFortCosmeticStep
{
public:
};

// Size: 0x3e0
class UCosmeticShoesAnimInstance : public UAnimInstance
{
public:
};

// Size: 0x140
class UCosmeticShoesItem : public UAthenaCosmeticAccountItem
{
public:
};

// Size: 0x4a0
class UCosmeticShoesItemDefinition : public UAthenaCharacterPartItemDefinition
{
public:
    FVector LeftShoesPosition() const { return Read<FVector>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x18, Type: StructProperty)
    FVector RightShoesPosition() const { return Read<FVector>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x18, Type: StructProperty)

    void SET_LeftShoesPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x18, Type: StructProperty)
    void SET_RightShoesPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x18, Type: StructProperty)
};

// Size: 0x310
class ACosmeticShoesPreviewPrefabAsset : public AActor
{
public:
    USkeletalMeshComponent* Mesh() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UFXSystemComponent*> IdleVFX() const { return Read<TWeakObjectPtr<UFXSystemComponent*>>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: WeakObjectProperty)
    UCustomizableSkeletalComponent* CustomizableComponent() const { return Read<UCustomizableSkeletalComponent*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UCosmeticShoesItemDefinition*> ShoesItemDefinition() const { return Read<TWeakObjectPtr<UCosmeticShoesItemDefinition*>>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: WeakObjectProperty)
    float CylinderHalfHeight() const { return Read<float>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x4, Type: FloatProperty)
    float CylinderRadius() const { return Read<float>(uintptr_t(this) + 0x2dc); } // 0x2dc (Size: 0x4, Type: FloatProperty)

    void SET_Mesh(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_IdleVFX(const TWeakObjectPtr<UFXSystemComponent*>& Value) { Write<TWeakObjectPtr<UFXSystemComponent*>>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CustomizableComponent(const UCustomizableSkeletalComponent*& Value) { Write<UCustomizableSkeletalComponent*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    void SET_ShoesItemDefinition(const TWeakObjectPtr<UCosmeticShoesItemDefinition*>& Value) { Write<TWeakObjectPtr<UCosmeticShoesItemDefinition*>>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CylinderHalfHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x4, Type: FloatProperty)
    void SET_CylinderRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x2dc, Value); } // 0x2dc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FShoesFlowCommonData
{
public:
    TArray<UCustomCharacterPart*> ShoeParts() const { return Read<TArray<UCustomCharacterPart*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<UFXSystemComponent*> IdleVFX() const { return Read<TWeakObjectPtr<UFXSystemComponent*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: WeakObjectProperty)

    void SET_ShoeParts(const TArray<UCustomCharacterPart*>& Value) { Write<TArray<UCustomCharacterPart*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_IdleVFX(const TWeakObjectPtr<UFXSystemComponent*>& Value) { Write<TWeakObjectPtr<UFXSystemComponent*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x28
struct FFlowgraphShoesCustomizationParameters
{
public:
    UCosmeticShoesItemDefinition* ShoesItemDef() const { return Read<UCosmeticShoesItemDefinition*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* Mesh() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    UCustomizableSkeletalComponent* CustomizableComponent() const { return Read<UCustomizableSkeletalComponent*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)

    void SET_ShoesItemDef(const UCosmeticShoesItemDefinition*& Value) { Write<UCosmeticShoesItemDefinition*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_Mesh(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET_CustomizableComponent(const UCustomizableSkeletalComponent*& Value) { Write<UCustomizableSkeletalComponent*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
};

