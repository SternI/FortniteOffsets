/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ElevenLabs
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "DataRegistry.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x28
class UElevenLabsFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x50
class UElevenLabsSettings : public UObject
{
public:
    FDataRegistryType VoiceRegistryType() const { return Read<FDataRegistryType>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: StructProperty)
    FString TextToSpeechEndpoint() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    FString Location() const { return Read<FString>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StrProperty)

    void SET_VoiceRegistryType(const FDataRegistryType& Value) { Write<FDataRegistryType>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: StructProperty)
    void SET_TextToSpeechEndpoint(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_Location(const FString& Value) { Write<FString>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StrProperty)
};

// Size: 0x88
class UElevenLabsSubsystem : public UEngineSubsystem
{
public:
    FString AnalyticsEventNamespace() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)

    void SET_AnalyticsEventNamespace(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
};

// Size: 0x20
struct FElevenLabsTextToSpeechResult
{
public:
    FGuid RequestID() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    TArray<char> PCMAudioData() const { return Read<TArray<char>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_RequestID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_PCMAudioData(const TArray<char>& Value) { Write<TArray<char>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FElevenLabsTextToSpeechStreamHandle
{
public:
};

// Size: 0x14
struct FElevenLabsVoiceSettings
{
public:
    float Stability() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float SimilarityBoost() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Style() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float Speed() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    bool bUseSpearkerBoost() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_Stability(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_SimilarityBoost(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Style(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Speed(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_bUseSpearkerBoost(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x38
struct FElevenLabsVoice : public FTableRowBase
{
public:
    FString VoiceId() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)
    FElevenLabsVoiceSettings VoiceSettings() const { return Read<FElevenLabsVoiceSettings>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x14, Type: StructProperty)
    float PlaybackVolumeMultiplier() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float PlaybackPitch() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)

    void SET_VoiceId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
    void SET_VoiceSettings(const FElevenLabsVoiceSettings& Value) { Write<FElevenLabsVoiceSettings>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x14, Type: StructProperty)
    void SET_PlaybackVolumeMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_PlaybackPitch(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x60
struct FElevenLabsTextToSpeechRequestParams
{
public:
    FGuid RequestID() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    uint8_t Model() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t OutputFormat() const { return Read<uint8_t>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: EnumProperty)
    FElevenLabsVoice Voice() const { return Read<FElevenLabsVoice>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x38, Type: StructProperty)
    FGuid AnalyticsEventGroupID() const { return Read<FGuid>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: StructProperty)

    void SET_RequestID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_Model(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_OutputFormat(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: EnumProperty)
    void SET_Voice(const FElevenLabsVoice& Value) { Write<FElevenLabsVoice>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x38, Type: StructProperty)
    void SET_AnalyticsEventGroupID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: StructProperty)
};

// Size: 0x10
struct FElevenLabsTextToSpeechRequestHandle
{
public:
};

// Size: 0x18
struct FElevenLabsStreamGenerationConfig
{
public:
    bool bAutoMode() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    TArray<int32_t> ChunkLengthSchedule() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_bAutoMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_ChunkLengthSchedule(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x78
struct FElevenLabsTextToSpeechStreamParams : public FElevenLabsTextToSpeechRequestParams
{
public:
    FElevenLabsStreamGenerationConfig GenerationConfig() const { return Read<FElevenLabsStreamGenerationConfig>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x18, Type: StructProperty)

    void SET_GenerationConfig(const FElevenLabsStreamGenerationConfig& Value) { Write<FElevenLabsStreamGenerationConfig>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x18, Type: StructProperty)
};

