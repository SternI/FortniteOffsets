/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FlexLegendWeaponGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
// Size: 0x1310
class UFlexLegendLeverShotgunLayerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    bool bPlayUpperBodyTargetingCustomOrIsTargetingCustom() const { return Read<bool>(uintptr_t(this) + 0x1308); } // 0x1308 (Size: 0x1, Type: BoolProperty)

    void SET_bPlayUpperBodyTargetingCustomOrIsTargetingCustom(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1308, Value); } // 0x1308 (Size: 0x1, Type: BoolProperty)
};

