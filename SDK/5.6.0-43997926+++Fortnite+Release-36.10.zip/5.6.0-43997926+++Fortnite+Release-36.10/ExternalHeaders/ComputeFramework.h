/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ComputeFramework
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"

// Size: 0x28
class UComputeDataInterface : public UObject
{
public:
};

// Size: 0x28
class UComputeDataProvider : public UObject
{
public:
};

// Size: 0x98
class UComputeKernelSource : public UObject
{
public:
    FString EntryPoint() const { return Read<FString>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StrProperty)
    FIntVector GroupSize() const { return Read<FIntVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0xc, Type: StructProperty)
    FComputeKernelPermutationSet PermutationSet() const { return Read<FComputeKernelPermutationSet>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    FComputeKernelDefinitionSet DefinitionsSet() const { return Read<FComputeKernelDefinitionSet>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    TArray<UComputeSource*> AdditionalSources() const { return Read<TArray<UComputeSource*>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    TArray<FShaderFunctionDefinition> ExternalInputs() const { return Read<TArray<FShaderFunctionDefinition>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    TArray<FShaderFunctionDefinition> ExternalOutputs() const { return Read<TArray<FShaderFunctionDefinition>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)

    void SET_EntryPoint(const FString& Value) { Write<FString>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StrProperty)
    void SET_GroupSize(const FIntVector& Value) { Write<FIntVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0xc, Type: StructProperty)
    void SET_PermutationSet(const FComputeKernelPermutationSet& Value) { Write<FComputeKernelPermutationSet>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_DefinitionsSet(const FComputeKernelDefinitionSet& Value) { Write<FComputeKernelDefinitionSet>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_AdditionalSources(const TArray<UComputeSource*>& Value) { Write<TArray<UComputeSource*>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_ExternalInputs(const TArray<FShaderFunctionDefinition>& Value) { Write<TArray<FShaderFunctionDefinition>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    void SET_ExternalOutputs(const TArray<FShaderFunctionDefinition>& Value) { Write<TArray<FShaderFunctionDefinition>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
class UComputeSource : public UObject
{
public:
    TArray<UComputeSource*> AdditionalSources() const { return Read<TArray<UComputeSource*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_AdditionalSources(const TArray<UComputeSource*>& Value) { Write<TArray<UComputeSource*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xe0
class UComputeGraph : public UObject
{
public:
    TArray<UComputeKernel*> KernelInvocations() const { return Read<TArray<UComputeKernel*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<UComputeDataInterface*> DataInterfaces() const { return Read<TArray<UComputeDataInterface*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FComputeGraphEdge> GraphEdges() const { return Read<TArray<FComputeGraphEdge>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> Bindings() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> DataInterfaceToBinding() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)

    void SET_KernelInvocations(const TArray<UComputeKernel*>& Value) { Write<TArray<UComputeKernel*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_DataInterfaces(const TArray<UComputeDataInterface*>& Value) { Write<TArray<UComputeDataInterface*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_GraphEdges(const TArray<FComputeGraphEdge>& Value) { Write<TArray<FComputeGraphEdge>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_Bindings(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_DataInterfaceToBinding(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xd8
class UComputeGraphComponent : public UActorComponent
{
public:
    UComputeGraph* ComputeGraph() const { return Read<UComputeGraph*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    FComputeGraphInstance ComputeGraphInstance() const { return Read<FComputeGraphInstance>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x18, Type: StructProperty)

    void SET_ComputeGraph(const UComputeGraph*& Value) { Write<UComputeGraph*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_ComputeGraphInstance(const FComputeGraphInstance& Value) { Write<FComputeGraphInstance>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x18, Type: StructProperty)
};

// Size: 0x38
class UComputeKernel : public UObject
{
public:
    UComputeKernelSource* KernelSource() const { return Read<UComputeKernelSource*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    int32_t KernelFlags() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)

    void SET_KernelSource(const UComputeKernelSource*& Value) { Write<UComputeKernelSource*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_KernelFlags(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
};

// Size: 0xa8
class UComputeKernelFromText : public UComputeKernelSource
{
public:
    FFilePath SourceFile() const { return Read<FFilePath>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: StructProperty)

    void SET_SourceFile(const FFilePath& Value) { Write<FFilePath>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: StructProperty)
};

// Size: 0x48
class UComputeSourceFromText : public UComputeSource
{
public:
    FFilePath SourceFile() const { return Read<FFilePath>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)

    void SET_SourceFile(const FFilePath& Value) { Write<FFilePath>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
};

// Size: 0x38
struct FComputeGraphEdge
{
public:
    int32_t KernelIndex() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t KernelBindingIndex() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t DataInterfaceIndex() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t DataInterfaceBindingIndex() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    bool bKernelInput() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    FString BindingFunctionNameOverride() const { return Read<FString>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StrProperty)
    FString BindingFunctionNamespace() const { return Read<FString>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StrProperty)

    void SET_KernelIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_KernelBindingIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_DataInterfaceIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_DataInterfaceBindingIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_bKernelInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_BindingFunctionNameOverride(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StrProperty)
    void SET_BindingFunctionNamespace(const FString& Value) { Write<FString>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StrProperty)
};

// Size: 0x18
struct FComputeGraphInstance
{
public:
    TArray<UComputeDataProvider*> DataProviders() const { return Read<TArray<UComputeDataProvider*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_DataProviders(const TArray<UComputeDataProvider*>& Value) { Write<TArray<UComputeDataProvider*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FComputeKernelPermutationBool
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    bool Value() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Value(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FComputeKernelPermutationSet
{
public:
    TArray<FComputeKernelPermutationBool> BooleanOptions() const { return Read<TArray<FComputeKernelPermutationBool>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_BooleanOptions(const TArray<FComputeKernelPermutationBool>& Value) { Write<TArray<FComputeKernelPermutationBool>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FComputeKernelDefinition
{
public:
    FString Symbol() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString Define() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_Symbol(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Define(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x10
struct FComputeKernelDefinitionSet
{
public:
    TArray<FComputeKernelDefinition> Defines() const { return Read<TArray<FComputeKernelDefinition>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Defines(const TArray<FComputeKernelDefinition>& Value) { Write<TArray<FComputeKernelDefinition>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x58
struct FComputeKernelPermutationVector
{
public:
    TMap<uint32_t, FString> Permutations() const { return Read<TMap<uint32_t, FString>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)
    uint32_t BitCount() const { return Read<uint32_t>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: UInt32Property)

    void SET_Permutations(const TMap<uint32_t, FString>& Value) { Write<TMap<uint32_t, FString>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
    void SET_BitCount(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x8
struct FShaderValueTypeHandle
{
public:
};

// Size: 0x10
struct FArrayShaderValue
{
public:
    TArray<char> ArrayOfValues() const { return Read<TArray<char>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_ArrayOfValues(const TArray<char>& Value) { Write<TArray<char>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FShaderValueContainer
{
public:
    TArray<char> ShaderValue() const { return Read<TArray<char>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FArrayShaderValue> ArrayList() const { return Read<TArray<FArrayShaderValue>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_ShaderValue(const TArray<char>& Value) { Write<TArray<char>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_ArrayList(const TArray<FArrayShaderValue>& Value) { Write<TArray<FArrayShaderValue>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FShaderValueType
{
public:
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t DimensionType() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    bool bIsDynamicArray() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_DimensionType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_bIsDynamicArray(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FShaderParamTypeDefinition
{
public:
    FString TypeDeclaration() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FShaderValueTypeHandle ValueType() const { return Read<FShaderValueTypeHandle>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: StructProperty)
    uint16_t ArrayElementCount() const { return Read<uint16_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x2, Type: UInt16Property)
    uint8_t BindingType() const { return Read<uint8_t>(uintptr_t(this) + 0x2a); } // 0x2a (Size: 0x1, Type: EnumProperty)
    uint8_t ResourceType() const { return Read<uint8_t>(uintptr_t(this) + 0x2b); } // 0x2b (Size: 0x1, Type: EnumProperty)
    uint8_t Modifier() const { return Read<uint8_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: EnumProperty)

    void SET_TypeDeclaration(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_ValueType(const FShaderValueTypeHandle& Value) { Write<FShaderValueTypeHandle>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: StructProperty)
    void SET_ArrayElementCount(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x2, Type: UInt16Property)
    void SET_BindingType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2a, Value); } // 0x2a (Size: 0x1, Type: EnumProperty)
    void SET_ResourceType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2b, Value); } // 0x2b (Size: 0x1, Type: EnumProperty)
    void SET_Modifier(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: EnumProperty)
};

// Size: 0x28
struct FShaderFunctionDefinition
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    TArray<FShaderParamTypeDefinition> ParamTypes() const { return Read<TArray<FShaderParamTypeDefinition>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    bool bHasReturnType() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_ParamTypes(const TArray<FShaderParamTypeDefinition>& Value) { Write<TArray<FShaderParamTypeDefinition>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_bHasReturnType(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

