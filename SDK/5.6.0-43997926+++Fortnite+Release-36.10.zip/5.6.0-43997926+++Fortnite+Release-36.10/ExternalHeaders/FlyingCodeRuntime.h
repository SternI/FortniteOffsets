/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FlyingCodeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "FortniteGame.h"

// Size: 0x2020
class UFortCameraMode_Flying : public UFortCameraMode_ThirdPerson
{
public:
    float LastActiveTimeSeconds() const { return Read<float>(uintptr_t(this) + 0x2018); } // 0x2018 (Size: 0x4, Type: FloatProperty)

    void SET_LastActiveTimeSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x2018, Value); } // 0x2018 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x78
class UFortMovementMode_FlyingRuntimeData : public UFortMovementMode_BaseExtRuntimeData
{
public:
    FVector2D MovementInput() const { return Read<FVector2D>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StructProperty)
    float CeilingHeight() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    FRotator MoveOrientation() const { return Read<FRotator>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)

    void SET_MovementInput(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StructProperty)
    void SET_CeilingHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_MoveOrientation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
};

// Size: 0x208
class UFortMovementMode_ExtLogicFlying : public UFortMovementMode_BaseExtLogic
{
public:
    bool bEnableInput() const { return Read<bool>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x1, Type: BoolProperty)

    void SET_bEnableInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb0
class UFlyingAttributeSet : public UFortAttributeSet
{
public:
    FFortGameplayAttributeData MaxFuel() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData FuelUsageRate() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData LocalFuel() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x28, Type: StructProperty)

    void SET_MaxFuel(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x28, Type: StructProperty)
    void SET_FuelUsageRate(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x28, Type: StructProperty)
    void SET_LocalFuel(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x28, Type: StructProperty)
};

// Size: 0x30
struct FFortMovementMode_FlyingCreationData : public FFortMovementMode_BaseExtCreationData
{
public:
    float CeilingHeight() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    FRotator MoveOrientation() const { return Read<FRotator>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_CeilingHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_MoveOrientation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

