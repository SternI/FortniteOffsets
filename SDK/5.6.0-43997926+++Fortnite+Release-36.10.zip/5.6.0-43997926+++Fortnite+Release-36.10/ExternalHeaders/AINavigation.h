/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AINavigation
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x410
class UNavigationElementProcessor : public UMassProcessor
{
public:
};

// Size: 0x4d0
class UDirtyNavigationRelevantUpdateProcessor : public UMassSignalProcessorBase
{
public:
};

// Size: 0x430
class UNavigationRelevantMassDeinitializer : public UMassObserverProcessor
{
public:
};

// Size: 0x28
class UNavigationFilter : public UObject
{
public:
};

// Size: 0x58
class UCompositeNavigationQuery : public UNavigationQueryFilter
{
public:
    TArray<UNavigationFilter*> NavigationFilters() const { return Read<TArray<UNavigationFilter*>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)

    void SET_NavigationFilters(const TArray<UNavigationFilter*>& Value) { Write<TArray<UNavigationFilter*>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
};

