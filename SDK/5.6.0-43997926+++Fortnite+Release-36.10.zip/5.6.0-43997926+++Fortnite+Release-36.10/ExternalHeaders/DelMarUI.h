/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "DynamicUI.h"
#include "CommonInput.h"
#include "GameplayTags.h"
#include "InputCore.h"
#include "UMG.h"
#include "DelMarCore.h"
#include "UIChart.h"
#include "SlateCore.h"
#include "EnhancedInput.h"
#include "Engine.h"
#include "ModelViewViewModel.h"
#include "FortniteGame.h"
#include "CommonUI.h"
#include "CoreUObject.h"
#include "Slate.h"
#include "FortniteUI.h"

// Size: 0x400
class UDelMarCountdownTimerWidget : public UDelMarUserWidget
{
public:
    UTextBlock* TextBlock_RemainingTime() const { return Read<UTextBlock*>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    double InitialCoundownTime() const { return Read<double>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x8, Type: DoubleProperty)

    void SET_TextBlock_RemainingTime(const UTextBlock*& Value) { Write<UTextBlock*>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    void SET_InitialCoundownTime(const double& Value) { Write<double>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x3c0
class UDelMarUserWidget : public UCommonUserWidget
{
public:
    uint8_t InitialTransitionStatus() const { return Read<uint8_t>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x1, Type: EnumProperty)
    uint8_t HiddenVisibility() const { return Read<uint8_t>(uintptr_t(this) + 0x3a1); } // 0x3a1 (Size: 0x1, Type: EnumProperty)
    bool bAlwaysReverseInterruptedAnimations() const { return Read<bool>(uintptr_t(this) + 0x3a2); } // 0x3a2 (Size: 0x1, Type: BoolProperty)
    UWidgetTransitioner* WidgetTransitioner() const { return Read<UWidgetTransitioner*>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* NormalTransitionIn() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* NormalTransitionOut() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)

    void SET_InitialTransitionStatus(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x1, Type: EnumProperty)
    void SET_HiddenVisibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3a1, Value); } // 0x3a1 (Size: 0x1, Type: EnumProperty)
    void SET_bAlwaysReverseInterruptedAnimations(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3a2, Value); } // 0x3a2 (Size: 0x1, Type: BoolProperty)
    void SET_WidgetTransitioner(const UWidgetTransitioner*& Value) { Write<UWidgetTransitioner*>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    void SET_NormalTransitionIn(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x8, Type: ObjectProperty)
    void SET_NormalTransitionOut(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2e0
class ADelMarCreativeUIDirector : public ADynamicUIDirectorBase
{
public:
    ADelMarVehicle* CachedDelMarVehicle() const { return Read<ADelMarVehicle*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* CreativeDelMarUI() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag VehicleInAirTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x4, Type: StructProperty)

    void SET_CachedDelMarVehicle(const ADelMarVehicle*& Value) { Write<ADelMarVehicle*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    void SET_CreativeDelMarUI(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    void SET_VehicleInAirTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x4, Type: StructProperty)
};

// Size: 0x4f8
class UDelMarDriverCameraWidget : public UDelMarUserWidget
{
public:
    UWidgetAnimation* DefaultIntercomAnimation() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ReactiveDriverCamera_Persistent() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    float ReactiveWidgetOutroDelay() const { return Read<float>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x4, Type: FloatProperty)
    float ReactiveWidgetMaxActiveTime() const { return Read<float>(uintptr_t(this) + 0x3d4); } // 0x3d4 (Size: 0x4, Type: FloatProperty)
    TMap<FName, FGameplayTag> MainChannelAnimationTagTable() const { return Read<TMap<FName, FGameplayTag>>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x50, Type: MapProperty)
    TMap<FDelMarReactiveWidgetAnimation, int32_t> ReactiveAnimationTable() const { return Read<TMap<FDelMarReactiveWidgetAnimation, int32_t>>(uintptr_t(this) + 0x428); } // 0x428 (Size: 0x50, Type: MapProperty)
    TMap<UWidgetAnimation*, FName> AnimationNameTable() const { return Read<TMap<UWidgetAnimation*, FName>>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x50, Type: MapProperty)
    FWidgetAnimationHandle IntercomSequenceHandle() const { return Read<FWidgetAnimationHandle>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x10, Type: StructProperty)
    FWidgetAnimationHandle ReactiveSequenceHandle() const { return Read<FWidgetAnimationHandle>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x10, Type: StructProperty)

    void SET_DefaultIntercomAnimation(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    void SET_ReactiveDriverCamera_Persistent(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    void SET_ReactiveWidgetOutroDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x4, Type: FloatProperty)
    void SET_ReactiveWidgetMaxActiveTime(const float& Value) { Write<float>(uintptr_t(this) + 0x3d4, Value); } // 0x3d4 (Size: 0x4, Type: FloatProperty)
    void SET_MainChannelAnimationTagTable(const TMap<FName, FGameplayTag>& Value) { Write<TMap<FName, FGameplayTag>>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x50, Type: MapProperty)
    void SET_ReactiveAnimationTable(const TMap<FDelMarReactiveWidgetAnimation, int32_t>& Value) { Write<TMap<FDelMarReactiveWidgetAnimation, int32_t>>(uintptr_t(this) + 0x428, Value); } // 0x428 (Size: 0x50, Type: MapProperty)
    void SET_AnimationNameTable(const TMap<UWidgetAnimation*, FName>& Value) { Write<TMap<UWidgetAnimation*, FName>>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x50, Type: MapProperty)
    void SET_IntercomSequenceHandle(const FWidgetAnimationHandle& Value) { Write<FWidgetAnimationHandle>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x10, Type: StructProperty)
    void SET_ReactiveSequenceHandle(const FWidgetAnimationHandle& Value) { Write<FWidgetAnimationHandle>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x130
class UDelMarInputActionRichTextBlockDecorator : public URichTextBlockDecorator
{
public:
    UInputAction* InputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    FText DisplayName() const { return Read<FText>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: TextProperty)
    FKey Key() const { return Read<FKey>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    FSlateBrush Icon() const { return Read<FSlateBrush>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0xb0, Type: StructProperty)
    URichTextBlock* OwnerWidget() const { return Read<URichTextBlock*>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<ULocalPlayer*> OwningLocalPlayer() const { return Read<TWeakObjectPtr<ULocalPlayer*>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UCommonInputSubsystem*> CommonInputSubsystem() const { return Read<TWeakObjectPtr<UCommonInputSubsystem*>>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UEnhancedInputLocalPlayerSubsystem*> EnhancedInputSubsystem() const { return Read<TWeakObjectPtr<UEnhancedInputLocalPlayerSubsystem*>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: WeakObjectProperty)

    void SET_InputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_DisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: TextProperty)
    void SET_Key(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_Icon(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0xb0, Type: StructProperty)
    void SET_OwnerWidget(const URichTextBlock*& Value) { Write<URichTextBlock*>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: ObjectProperty)
    void SET_OwningLocalPlayer(const TWeakObjectPtr<ULocalPlayer*>& Value) { Write<TWeakObjectPtr<ULocalPlayer*>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CommonInputSubsystem(const TWeakObjectPtr<UCommonInputSubsystem*>& Value) { Write<TWeakObjectPtr<UCommonInputSubsystem*>>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: WeakObjectProperty)
    void SET_EnhancedInputSubsystem(const TWeakObjectPtr<UEnhancedInputLocalPlayerSubsystem*>& Value) { Write<TWeakObjectPtr<UEnhancedInputLocalPlayerSubsystem*>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xb80
class UDelMarListView : public UCommonListView
{
public:
    bool bTreatNavigationAsScrolling() const { return Read<bool>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x1, Type: BoolProperty)

    void SET_bTreatNavigationAsScrolling(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x78
class UDelMarListViewModel : public UMVVMViewModelBase
{
public:
    TArray<UMVVMViewModelBase*> Elements() const { return Read<TArray<UMVVMViewModelBase*>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)

    void SET_Elements(const TArray<UMVVMViewModelBase*>& Value) { Write<TArray<UMVVMViewModelBase*>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x80
class UDelMarMatchEventViewModel : public UDelMarViewModelBase
{
public:
};

// Size: 0x70
class UDelMarViewModelBase : public UFortPerUserViewModel
{
public:
};

// Size: 0x518
class UDelMarPlayerIndicatorsContainer : public UDelMarUserWidget
{
public:
    UCanvasPanel* IndicatorCanvas() const { return Read<UCanvasPanel*>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    UClass* IndicatorWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x8, Type: ClassProperty)
    FVector IndicatorOffset() const { return Read<FVector>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x18, Type: StructProperty)
    float RearVerticalHintThreshold() const { return Read<float>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x4, Type: FloatProperty)
    float RearIndicatorMaxDistance() const { return Read<float>(uintptr_t(this) + 0x3ec); } // 0x3ec (Size: 0x4, Type: FloatProperty)
    float RearIndicatorMinDistance() const { return Read<float>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x4, Type: FloatProperty)
    float RearIndicatorRangeWidth() const { return Read<float>(uintptr_t(this) + 0x3f4); } // 0x3f4 (Size: 0x4, Type: FloatProperty)
    float RearIndicatorRangeDegree() const { return Read<float>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x4, Type: FloatProperty)
    float ForwardIndicatorMaxDistance() const { return Read<float>(uintptr_t(this) + 0x3fc); } // 0x3fc (Size: 0x4, Type: FloatProperty)
    FAnchors IndicatorAnchors() const { return Read<FAnchors>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x20, Type: StructProperty)
    FVector2D IndicatorAlignment() const { return Read<FVector2D>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x10, Type: StructProperty)
    FVector2D RearIndicatorSize() const { return Read<FVector2D>(uintptr_t(this) + 0x430); } // 0x430 (Size: 0x10, Type: StructProperty)
    UCurveFloat* RearDistanceScaleCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* RearDistanceOpacityCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x448); } // 0x448 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* ForwardDistanceScaleCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* ForwardDistanceOpacityCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x8, Type: ObjectProperty)
    int32_t MaxRearIndicators() const { return Read<int32_t>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x4, Type: IntProperty)
    int32_t MaxForwardIndicators() const { return Read<int32_t>(uintptr_t(this) + 0x464); } // 0x464 (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<UDelMarVehicleManager*> VehicleManager() const { return Read<TWeakObjectPtr<UDelMarVehicleManager*>>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> ViewingVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> ViewingPlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: WeakObjectProperty)
    TArray<FDelMarPlayerIndicatorData> IndicatorsData() const { return Read<TArray<FDelMarPlayerIndicatorData>>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x10, Type: ArrayProperty)
    TMap<UDelMarPlayerIndicatorWidget*, AFortPlayerState*> IndicatorWidgets() const { return Read<TMap<UDelMarPlayerIndicatorWidget*, AFortPlayerState*>>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x50, Type: MapProperty)
    TArray<UDelMarPlayerIndicatorWidget*> IndicatorPool() const { return Read<TArray<UDelMarPlayerIndicatorWidget*>>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<UDelMarPositionalTrackerComponent*> PositionalTrackerComponent() const { return Read<TWeakObjectPtr<UDelMarPositionalTrackerComponent*>>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_IndicatorCanvas(const UCanvasPanel*& Value) { Write<UCanvasPanel*>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    void SET_IndicatorWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x8, Type: ClassProperty)
    void SET_IndicatorOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x18, Type: StructProperty)
    void SET_RearVerticalHintThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x4, Type: FloatProperty)
    void SET_RearIndicatorMaxDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x3ec, Value); } // 0x3ec (Size: 0x4, Type: FloatProperty)
    void SET_RearIndicatorMinDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x4, Type: FloatProperty)
    void SET_RearIndicatorRangeWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x3f4, Value); } // 0x3f4 (Size: 0x4, Type: FloatProperty)
    void SET_RearIndicatorRangeDegree(const float& Value) { Write<float>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x4, Type: FloatProperty)
    void SET_ForwardIndicatorMaxDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x3fc, Value); } // 0x3fc (Size: 0x4, Type: FloatProperty)
    void SET_IndicatorAnchors(const FAnchors& Value) { Write<FAnchors>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x20, Type: StructProperty)
    void SET_IndicatorAlignment(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x10, Type: StructProperty)
    void SET_RearIndicatorSize(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x430, Value); } // 0x430 (Size: 0x10, Type: StructProperty)
    void SET_RearDistanceScaleCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x8, Type: ObjectProperty)
    void SET_RearDistanceOpacityCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x448, Value); } // 0x448 (Size: 0x8, Type: ObjectProperty)
    void SET_ForwardDistanceScaleCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x8, Type: ObjectProperty)
    void SET_ForwardDistanceOpacityCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x8, Type: ObjectProperty)
    void SET_MaxRearIndicators(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x4, Type: IntProperty)
    void SET_MaxForwardIndicators(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x464, Value); } // 0x464 (Size: 0x4, Type: IntProperty)
    void SET_VehicleManager(const TWeakObjectPtr<UDelMarVehicleManager*>& Value) { Write<TWeakObjectPtr<UDelMarVehicleManager*>>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ViewingVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ViewingPlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: WeakObjectProperty)
    void SET_IndicatorsData(const TArray<FDelMarPlayerIndicatorData>& Value) { Write<TArray<FDelMarPlayerIndicatorData>>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x10, Type: ArrayProperty)
    void SET_IndicatorWidgets(const TMap<UDelMarPlayerIndicatorWidget*, AFortPlayerState*>& Value) { Write<TMap<UDelMarPlayerIndicatorWidget*, AFortPlayerState*>>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x50, Type: MapProperty)
    void SET_IndicatorPool(const TArray<UDelMarPlayerIndicatorWidget*>& Value) { Write<TArray<UDelMarPlayerIndicatorWidget*>>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x10, Type: ArrayProperty)
    void SET_PositionalTrackerComponent(const TWeakObjectPtr<UDelMarPositionalTrackerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarPositionalTrackerComponent*>>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x378
class UDelMarPlayerIndicatorWidget : public UUserWidget
{
public:
    USizeBox* AvatarSizeBox() const { return Read<USizeBox*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UFortLazyImage* AvatarLazyImage() const { return Read<UFortLazyImage*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    USizeBox* PlayerNameSizeBox() const { return Read<USizeBox*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    UImage* UpArrowImage() const { return Read<UImage*>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    UImage* DownArrowImage() const { return Read<UImage*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    UOverlay* BackgroundOverlay() const { return Read<UOverlay*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    float BehindAvatarSizeBoxWidth() const { return Read<float>(uintptr_t(this) + 0x35c); } // 0x35c (Size: 0x4, Type: FloatProperty)
    float AheadAvatarSizeBoxWidth() const { return Read<float>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x4, Type: FloatProperty)
    bool bBehindAvatarImageIsExpanded() const { return Read<bool>(uintptr_t(this) + 0x364); } // 0x364 (Size: 0x1, Type: BoolProperty)
    bool bAheadAvatarImageIsExpanded() const { return Read<bool>(uintptr_t(this) + 0x365); } // 0x365 (Size: 0x1, Type: BoolProperty)
    float BehindPlayerNameSizeBoxMaxWidth() const { return Read<float>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x4, Type: FloatProperty)
    float AheadPlayerNameSizeBoxMaxWidth() const { return Read<float>(uintptr_t(this) + 0x36c); } // 0x36c (Size: 0x4, Type: FloatProperty)
    float BehindBackgroundOverlaySlotPadding() const { return Read<float>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x4, Type: FloatProperty)
    float AheadBackgroundOverlaySlotPadding() const { return Read<float>(uintptr_t(this) + 0x374); } // 0x374 (Size: 0x4, Type: FloatProperty)

    void SET_AvatarSizeBox(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_AvatarLazyImage(const UFortLazyImage*& Value) { Write<UFortLazyImage*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerNameSizeBox(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_UpArrowImage(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    void SET_DownArrowImage(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_BackgroundOverlay(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_BehindAvatarSizeBoxWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x35c, Value); } // 0x35c (Size: 0x4, Type: FloatProperty)
    void SET_AheadAvatarSizeBoxWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x4, Type: FloatProperty)
    void SET_bBehindAvatarImageIsExpanded(const bool& Value) { Write<bool>(uintptr_t(this) + 0x364, Value); } // 0x364 (Size: 0x1, Type: BoolProperty)
    void SET_bAheadAvatarImageIsExpanded(const bool& Value) { Write<bool>(uintptr_t(this) + 0x365, Value); } // 0x365 (Size: 0x1, Type: BoolProperty)
    void SET_BehindPlayerNameSizeBoxMaxWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x4, Type: FloatProperty)
    void SET_AheadPlayerNameSizeBoxMaxWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x36c, Value); } // 0x36c (Size: 0x4, Type: FloatProperty)
    void SET_BehindBackgroundOverlaySlotPadding(const float& Value) { Write<float>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x4, Type: FloatProperty)
    void SET_AheadBackgroundOverlaySlotPadding(const float& Value) { Write<float>(uintptr_t(this) + 0x374, Value); } // 0x374 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x498
class UDelMarPositionalTrackerWidget : public UDelMarExpandableHudWidget
{
public:
    int32_t MinPlayersToStart() const { return Read<int32_t>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x4, Type: IntProperty)
    TArray<UDelMarPlayerViewModel*> DisplayedPlayers() const { return Read<TArray<UDelMarPlayerViewModel*>>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x10, Type: ArrayProperty)

    void SET_MinPlayersToStart(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x4, Type: IntProperty)
    void SET_DisplayedPlayers(const TArray<UDelMarPlayerViewModel*>& Value) { Write<TArray<UDelMarPlayerViewModel*>>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x478
class UDelMarExpandableHudWidget : public UDelMarUserWidget
{
public:
    UImage* NavigateEntriesBindingImage() const { return Read<UImage*>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    UClass* ExpandableHudWidgetEntryClass() const { return Read<UClass*>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: ClassProperty)
    int32_t NumDesignerPreviewEntries() const { return Read<int32_t>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x4, Type: IntProperty)
    float EntrySpacing() const { return Read<float>(uintptr_t(this) + 0x3ec); } // 0x3ec (Size: 0x4, Type: FloatProperty)
    bool bExpanded() const { return Read<bool>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x1, Type: BoolProperty)
    bool bNavigationEnabled() const { return Read<bool>(uintptr_t(this) + 0x3f1); } // 0x3f1 (Size: 0x1, Type: BoolProperty)
    UTexture2D* NavigateEntriesGamepadTexture() const { return Read<UTexture2D*>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* NavigateEntriesPCTexture() const { return Read<UTexture2D*>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x8, Type: ObjectProperty)
    UDelMarPlayerPreferencesComponent* PlayerPreferences() const { return Read<UDelMarPlayerPreferencesComponent*>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x8, Type: ObjectProperty)
    UOverlay* EntryOverlay() const { return Read<UOverlay*>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x8, Type: ObjectProperty)
    URetainerBox* EdgeFadeRetainerBox() const { return Read<URetainerBox*>(uintptr_t(this) + 0x418); } // 0x418 (Size: 0x8, Type: ObjectProperty)
    USizeBox* ContentSizeBox() const { return Read<USizeBox*>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x8, Type: ObjectProperty)
    TArray<UDelMarUserWidget*> DisplayedHudWidgetEntries() const { return Read<TArray<UDelMarUserWidget*>>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x10, Type: ArrayProperty)

    void SET_NavigateEntriesBindingImage(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    void SET_ExpandableHudWidgetEntryClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: ClassProperty)
    void SET_NumDesignerPreviewEntries(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x4, Type: IntProperty)
    void SET_EntrySpacing(const float& Value) { Write<float>(uintptr_t(this) + 0x3ec, Value); } // 0x3ec (Size: 0x4, Type: FloatProperty)
    void SET_bExpanded(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x1, Type: BoolProperty)
    void SET_bNavigationEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3f1, Value); } // 0x3f1 (Size: 0x1, Type: BoolProperty)
    void SET_NavigateEntriesGamepadTexture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    void SET_NavigateEntriesPCTexture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerPreferences(const UDelMarPlayerPreferencesComponent*& Value) { Write<UDelMarPlayerPreferencesComponent*>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x8, Type: ObjectProperty)
    void SET_EntryOverlay(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x8, Type: ObjectProperty)
    void SET_EdgeFadeRetainerBox(const URetainerBox*& Value) { Write<URetainerBox*>(uintptr_t(this) + 0x418, Value); } // 0x418 (Size: 0x8, Type: ObjectProperty)
    void SET_ContentSizeBox(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x8, Type: ObjectProperty)
    void SET_DisplayedHudWidgetEntries(const TArray<UDelMarUserWidget*>& Value) { Write<TArray<UDelMarUserWidget*>>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x510
class UDelMarPostRaceLeaderboard : public UDelMarScreenBase
{
public:
    FDataTableRowHandle FilterDataTableRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x10, Type: StructProperty)

    void SET_FilterDataTableRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x4f8
class UDelMarScreenBase : public UCommonActivatableWidget
{
public:
    uint8_t InitialTransitionStatus() const { return Read<uint8_t>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x1, Type: EnumProperty)
    UWidgetTransitioner* WidgetTransitioner() const { return Read<UWidgetTransitioner*>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x8, Type: ObjectProperty)
    bool bActivateOnShow() const { return Read<bool>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x1, Type: BoolProperty)
    UWidgetAnimation* NormalTransitionIn() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* NormalTransitionOut() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x8, Type: ObjectProperty)

    void SET_InitialTransitionStatus(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x1, Type: EnumProperty)
    void SET_WidgetTransitioner(const UWidgetTransitioner*& Value) { Write<UWidgetTransitioner*>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x8, Type: ObjectProperty)
    void SET_bActivateOnShow(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x1, Type: BoolProperty)
    void SET_NormalTransitionIn(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    void SET_NormalTransitionOut(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x5b0
class UDelMarPostRaceScreen : public UDelMarScreenBase
{
public:
    FDataTableRowHandle TabNavLeftDataTableRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle TabNavRightDataTableRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle ReadyUpDataTableRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle SpectateDataTableRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x528); } // 0x528 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle ResetRunDataTableRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle ReturnToLobbyDataTableRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x548); } // 0x548 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle OpenQuestBrowserDataTableRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x558); } // 0x558 (Size: 0x10, Type: StructProperty)
    UInputAction* ToggleQuestBrowserInputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x8, Type: ObjectProperty)
    TArray<EDelMarRaceMode> QuestBrowserAllowedRaceModes() const { return Read<TArray<EDelMarRaceMode>>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x10, Type: ArrayProperty)
    UCommonButtonGroupBase* ButtonGroup_PostMatchNavigation() const { return Read<UCommonButtonGroupBase*>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x8, Type: WeakObjectProperty)

    void SET_TabNavLeftDataTableRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x10, Type: StructProperty)
    void SET_TabNavRightDataTableRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x10, Type: StructProperty)
    void SET_ReadyUpDataTableRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x10, Type: StructProperty)
    void SET_SpectateDataTableRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x528, Value); } // 0x528 (Size: 0x10, Type: StructProperty)
    void SET_ResetRunDataTableRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x10, Type: StructProperty)
    void SET_ReturnToLobbyDataTableRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x548, Value); } // 0x548 (Size: 0x10, Type: StructProperty)
    void SET_OpenQuestBrowserDataTableRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x558, Value); } // 0x558 (Size: 0x10, Type: StructProperty)
    void SET_ToggleQuestBrowserInputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x8, Type: ObjectProperty)
    void SET_QuestBrowserAllowedRaceModes(const TArray<EDelMarRaceMode>& Value) { Write<TArray<EDelMarRaceMode>>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x10, Type: ArrayProperty)
    void SET_ButtonGroup_PostMatchNavigation(const UCommonButtonGroupBase*& Value) { Write<UCommonButtonGroupBase*>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedRaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x3c0
class UDelMarPostRaceVoteWidget : public UDelMarUserWidget
{
public:
};

// Size: 0x490
class UDelMarQuestScreenContainer : public UDelMarUserWidget
{
public:
    FGameplayTagContainer AllowedRaceGameplayStates() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer AllowedRacerStates() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer AllowedRaceModes() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer PreRaceInputRaceStates() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x20, Type: StructProperty)
    FGameplayTag RaceGameplayState() const { return Read<FGameplayTag>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x4, Type: StructProperty)
    FGameplayTag RaceMode() const { return Read<FGameplayTag>(uintptr_t(this) + 0x444); } // 0x444 (Size: 0x4, Type: StructProperty)
    FGameplayTag RacerState() const { return Read<FGameplayTag>(uintptr_t(this) + 0x448); } // 0x448 (Size: 0x4, Type: StructProperty)
    UAthenaMapScreenContainer* AthenaScreenContainer() const { return Read<UAthenaMapScreenContainer*>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x8, Type: ObjectProperty)
    bool bAthenaScreenContainerVisible() const { return Read<bool>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x1, Type: BoolProperty)
    double LastOnVisibleTimeSeconds() const { return Read<double>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: DoubleProperty)
    FGameplayTag LastOnVisibleRaceState() const { return Read<FGameplayTag>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x4, Type: StructProperty)

    void SET_AllowedRaceGameplayStates(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x20, Type: StructProperty)
    void SET_AllowedRacerStates(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x20, Type: StructProperty)
    void SET_AllowedRaceModes(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x20, Type: StructProperty)
    void SET_PreRaceInputRaceStates(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x20, Type: StructProperty)
    void SET_RaceGameplayState(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x4, Type: StructProperty)
    void SET_RaceMode(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x444, Value); } // 0x444 (Size: 0x4, Type: StructProperty)
    void SET_RacerState(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x448, Value); } // 0x448 (Size: 0x4, Type: StructProperty)
    void SET_AthenaScreenContainer(const UAthenaMapScreenContainer*& Value) { Write<UAthenaMapScreenContainer*>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x8, Type: ObjectProperty)
    void SET_bAthenaScreenContainerVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x1, Type: BoolProperty)
    void SET_LastOnVisibleTimeSeconds(const double& Value) { Write<double>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: DoubleProperty)
    void SET_LastOnVisibleRaceState(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x4, Type: StructProperty)
};

// Size: 0x3c8
class UDelMarRichTextInputSwitcher : public UUserWidget
{
public:
    bool bUseFormattedText() const { return Read<bool>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x1, Type: BoolProperty)
    FText TextFormat() const { return Read<FText>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x10, Type: TextProperty)
    TMap<FDelMarKeyPair, FString> Args() const { return Read<TMap<FDelMarKeyPair, FString>>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x50, Type: MapProperty)
    FText TextKBM() const { return Read<FText>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x10, Type: TextProperty)
    FText TextGamepad() const { return Read<FText>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x10, Type: TextProperty)
    FText TextTouch() const { return Read<FText>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x10, Type: TextProperty)
    UCommonRichTextBlock* Widget_RichText() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)

    void SET_bUseFormattedText(const bool& Value) { Write<bool>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x1, Type: BoolProperty)
    void SET_TextFormat(const FText& Value) { Write<FText>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x10, Type: TextProperty)
    void SET_Args(const TMap<FDelMarKeyPair, FString>& Value) { Write<TMap<FDelMarKeyPair, FString>>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x50, Type: MapProperty)
    void SET_TextKBM(const FText& Value) { Write<FText>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x10, Type: TextProperty)
    void SET_TextGamepad(const FText& Value) { Write<FText>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x10, Type: TextProperty)
    void SET_TextTouch(const FText& Value) { Write<FText>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x10, Type: TextProperty)
    void SET_Widget_RichText(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x98
class UDelMarSelectionListViewModel : public UDelMarListViewModel
{
public:
    int32_t SelectedIndex() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)

    void SET_SelectedIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
};

// Size: 0x460
class UDelMarTouchActionButton : public UDelMarTouchWidgetBase
{
public:
    uint8_t State() const { return Read<uint8_t>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x1, Type: EnumProperty)
    TMap<FDelMarTouchActionButtonStateData, EDelMarTouchActionButtonState> ButtonStateData() const { return Read<TMap<FDelMarTouchActionButtonStateData, EDelMarTouchActionButtonState>>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x50, Type: MapProperty)
    bool bHighlightActive() const { return Read<bool>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x1, Type: BoolProperty)
    bool bIsUpdatingState() const { return Read<bool>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x1, Type: BoolProperty)

    void SET_State(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x1, Type: EnumProperty)
    void SET_ButtonStateData(const TMap<FDelMarTouchActionButtonStateData, EDelMarTouchActionButtonState>& Value) { Write<TMap<FDelMarTouchActionButtonStateData, EDelMarTouchActionButtonState>>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x50, Type: MapProperty)
    void SET_bHighlightActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x1, Type: BoolProperty)
    void SET_bIsUpdatingState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x3e8
class UDelMarTouchWidgetBase : public UDelMarUserWidget
{
public:
    TArray<FDelMarTouchInputDefinition> InputActionsData() const { return Read<TArray<FDelMarTouchInputDefinition>>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x10, Type: ArrayProperty)
    bool bTrackInputPastBounds() const { return Read<bool>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x1, Type: BoolProperty)
    bool bTrackInputFromEnter() const { return Read<bool>(uintptr_t(this) + 0x3d1); } // 0x3d1 (Size: 0x1, Type: BoolProperty)
    bool bIsInjectingInput() const { return Read<bool>(uintptr_t(this) + 0x3d2); } // 0x3d2 (Size: 0x1, Type: BoolProperty)
    uint8_t CurrentInputTrackingState() const { return Read<uint8_t>(uintptr_t(this) + 0x3d3); } // 0x3d3 (Size: 0x1, Type: EnumProperty)
    uint8_t RequiredInputMode() const { return Read<uint8_t>(uintptr_t(this) + 0x3d4); } // 0x3d4 (Size: 0x1, Type: EnumProperty)

    void SET_InputActionsData(const TArray<FDelMarTouchInputDefinition>& Value) { Write<TArray<FDelMarTouchInputDefinition>>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x10, Type: ArrayProperty)
    void SET_bTrackInputPastBounds(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x1, Type: BoolProperty)
    void SET_bTrackInputFromEnter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3d1, Value); } // 0x3d1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsInjectingInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3d2, Value); } // 0x3d2 (Size: 0x1, Type: BoolProperty)
    void SET_CurrentInputTrackingState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3d3, Value); } // 0x3d3 (Size: 0x1, Type: EnumProperty)
    void SET_RequiredInputMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3d4, Value); } // 0x3d4 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x3f8
class UDelMarTouchRegion : public UDelMarTouchWidgetBase
{
public:
    TArray<UDelMarTouchActionButton*> TouchActionButtons() const { return Read<TArray<UDelMarTouchActionButton*>>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x10, Type: ArrayProperty)

    void SET_TouchActionButtons(const TArray<UDelMarTouchActionButton*>& Value) { Write<TArray<UDelMarTouchActionButton*>>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x80
class UDelMarUICheatManager : public UChildCheatManager
{
public:
    UDynamicUIScene* DriverCameraHiddenScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* PlayerIndicatorHiddenScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* PointsDebugWidgetVisibleScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* RubberbandingWidgetVisibleScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* StaticVehicleMeterHiddenScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* VehicleDebugVisibleScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* VehicleHealthDebugVisibleScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* CheckpointDebugWidgetScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* MapNameDebugWidgetScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* GameplayTrackList() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    bool bAttachedWidgetEnabled() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)

    void SET_DriverCameraHiddenScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerIndicatorHiddenScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_PointsDebugWidgetVisibleScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_RubberbandingWidgetVisibleScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_StaticVehicleMeterHiddenScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    void SET_VehicleDebugVisibleScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    void SET_VehicleHealthDebugVisibleScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: ObjectProperty)
    void SET_CheckpointDebugWidgetScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_MapNameDebugWidgetScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_GameplayTrackList(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_bAttachedWidgetEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x38
class UUIAnimationController : public UObject
{
public:
};

// Size: 0x60
class UUITimelineAnimationController : public UUIAnimationController
{
public:
    UUserWidget* WidgetTarget() const { return Read<UUserWidget*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Animation() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    FWidgetAnimationHandle ActiveAnimationHandle() const { return Read<FWidgetAnimationHandle>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)

    void SET_WidgetTarget(const UUserWidget*& Value) { Write<UUserWidget*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_Animation(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_ActiveAnimationHandle(const FWidgetAnimationHandle& Value) { Write<FWidgetAnimationHandle>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
};

// Size: 0x38
class UUIAnimationControllerEntry : public UObject
{
public:
    UUIAnimationController* AnimationController() const { return Read<UUIAnimationController*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    bool bIsInverted() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)

    void SET_AnimationController(const UUIAnimationController*& Value) { Write<UUIAnimationController*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsInverted(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x108
class UWidgetTransitioner : public UObject
{
public:
    UWidget* TargetWidget() const { return Read<UWidget*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    uint8_t HiddenVisibility() const { return Read<uint8_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: EnumProperty)
    uint8_t ShownVisibility() const { return Read<uint8_t>(uintptr_t(this) + 0x41); } // 0x41 (Size: 0x1, Type: EnumProperty)
    uint8_t TransitionerStatus() const { return Read<uint8_t>(uintptr_t(this) + 0x42); } // 0x42 (Size: 0x1, Type: EnumProperty)
    UUIAnimationControllerEntry* NormalTransitionIn() const { return Read<UUIAnimationControllerEntry*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    UUIAnimationControllerEntry* NormalTransitionOut() const { return Read<UUIAnimationControllerEntry*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    TMap<UUIAnimationControllerEntry*, FGameplayTag> HintedTransitionsIn() const { return Read<TMap<UUIAnimationControllerEntry*, FGameplayTag>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x50, Type: MapProperty)
    TMap<UUIAnimationControllerEntry*, FGameplayTag> HintedTransitionsOut() const { return Read<TMap<UUIAnimationControllerEntry*, FGameplayTag>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x50, Type: MapProperty)
    UUIAnimationControllerEntry* ActiveEntry() const { return Read<UUIAnimationControllerEntry*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    bool bAlwaysReverseInterruptedAnimations() const { return Read<bool>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: BoolProperty)

    void SET_TargetWidget(const UWidget*& Value) { Write<UWidget*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_HiddenVisibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: EnumProperty)
    void SET_ShownVisibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x41, Value); } // 0x41 (Size: 0x1, Type: EnumProperty)
    void SET_TransitionerStatus(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x42, Value); } // 0x42 (Size: 0x1, Type: EnumProperty)
    void SET_NormalTransitionIn(const UUIAnimationControllerEntry*& Value) { Write<UUIAnimationControllerEntry*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    void SET_NormalTransitionOut(const UUIAnimationControllerEntry*& Value) { Write<UUIAnimationControllerEntry*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    void SET_HintedTransitionsIn(const TMap<UUIAnimationControllerEntry*, FGameplayTag>& Value) { Write<TMap<UUIAnimationControllerEntry*, FGameplayTag>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x50, Type: MapProperty)
    void SET_HintedTransitionsOut(const TMap<UUIAnimationControllerEntry*, FGameplayTag>& Value) { Write<TMap<UUIAnimationControllerEntry*, FGameplayTag>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x50, Type: MapProperty)
    void SET_ActiveEntry(const UUIAnimationControllerEntry*& Value) { Write<UUIAnimationControllerEntry*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    void SET_bAlwaysReverseInterruptedAnimations(const bool& Value) { Write<bool>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x410
class UDelMarActionWidget : public UWidget
{
public:
    FSlateBrush ProgressMaterialBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0xb0, Type: StructProperty)
    FName ProgressMaterialParam() const { return Read<FName>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x4, Type: NameProperty)
    FSlateBrush IconRimBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0xb0, Type: StructProperty)
    TArray<FDataTableRowHandle> InputActions() const { return Read<TArray<FDataTableRowHandle>>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    UInputAction* EnhancedInputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* ProgressDynamicMaterial() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)

    void SET_ProgressMaterialBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0xb0, Type: StructProperty)
    void SET_ProgressMaterialParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x4, Type: NameProperty)
    void SET_IconRimBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0xb0, Type: StructProperty)
    void SET_InputActions(const TArray<FDataTableRowHandle>& Value) { Write<TArray<FDataTableRowHandle>>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    void SET_EnhancedInputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    void SET_ProgressDynamicMaterial(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x490
class UDelMarDialogBase : public UCommonActivatableWidget
{
public:
};

// Size: 0x78
class UDelMarDialogHelper : public UObject
{
public:
    TMap<TSoftClassPtr, FGameplayTag> DialogMapping() const { return Read<TMap<TSoftClassPtr, FGameplayTag>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: MapProperty)

    void SET_DialogMapping(const TMap<TSoftClassPtr, FGameplayTag>& Value) { Write<TMap<TSoftClassPtr, FGameplayTag>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: MapProperty)
};

// Size: 0x480
class UDelMarInputConfigWidgetBase : public UCommonActivatableWidget
{
public:
    FUIInputConfig DesiredInputConfig() const { return Read<FUIInputConfig>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x6, Type: StructProperty)
    bool bFlushPlayerInputWhenActivating() const { return Read<bool>(uintptr_t(this) + 0x47e); } // 0x47e (Size: 0x1, Type: BoolProperty)
    bool bFlushPlayerInputWhenDeactivating() const { return Read<bool>(uintptr_t(this) + 0x47f); } // 0x47f (Size: 0x1, Type: BoolProperty)

    void SET_DesiredInputConfig(const FUIInputConfig& Value) { Write<FUIInputConfig>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x6, Type: StructProperty)
    void SET_bFlushPlayerInputWhenActivating(const bool& Value) { Write<bool>(uintptr_t(this) + 0x47e, Value); } // 0x47e (Size: 0x1, Type: BoolProperty)
    void SET_bFlushPlayerInputWhenDeactivating(const bool& Value) { Write<bool>(uintptr_t(this) + 0x47f, Value); } // 0x47f (Size: 0x1, Type: BoolProperty)
};

// Size: 0x128
class UDelMarLoadingScreenHelper : public UObject
{
public:
    FVector2D BackgroundDesiredSize() const { return Read<FVector2D>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    FZoneLoadingScreenConfig ZoneConfig() const { return Read<FZoneLoadingScreenConfig>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0xd0, Type: StructProperty)

    void SET_BackgroundDesiredSize(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_ZoneConfig(const FZoneLoadingScreenConfig& Value) { Write<FZoneLoadingScreenConfig>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0xd0, Type: StructProperty)
};

// Size: 0x2e0
class ADelMarUIDirector : public ADynamicUIDirectorBase
{
public:
    UClass* DialogHelperClass() const { return Read<UClass*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ClassProperty)
    UDelMarDialogHelper* DialogHelper() const { return Read<UDelMarDialogHelper*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)

    void SET_DialogHelperClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ClassProperty)
    void SET_DialogHelper(const UDelMarDialogHelper*& Value) { Write<UDelMarDialogHelper*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UDelMarUIGlobals : public UObject
{
public:
};

// Size: 0x300
class ADelMarAttachedWidgetActor : public AActor
{
public:
    float DriftFollowDampening() const { return Read<float>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x4, Type: FloatProperty)
    float WallFollowDampening() const { return Read<float>(uintptr_t(this) + 0x2ac); } // 0x2ac (Size: 0x4, Type: FloatProperty)
    float RotateDampeningRate() const { return Read<float>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<APlayerState*> ViewPlayerState() const { return Read<TWeakObjectPtr<APlayerState*>>(uintptr_t(this) + 0x2b4); } // 0x2b4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<USceneComponent*> AttachedTarget() const { return Read<TWeakObjectPtr<USceneComponent*>>(uintptr_t(this) + 0x2bc); } // 0x2bc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> AttachedVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x2c4); } // 0x2c4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<APlayerCameraManager*> CameraManager() const { return Read<TWeakObjectPtr<APlayerCameraManager*>>(uintptr_t(this) + 0x2cc); } // 0x2cc (Size: 0x8, Type: WeakObjectProperty)
    USceneComponent* AttachmentBaseComponent() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UDelMarWidgetComponent* SpeedometerWidget() const { return Read<UDelMarWidgetComponent*>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UDelMarWidgetComponent* DriftBoostWidget() const { return Read<UDelMarWidgetComponent*>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UDelMarWidgetComponent* UnderthrustWidget() const { return Read<UDelMarWidgetComponent*>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)

    void SET_DriftFollowDampening(const float& Value) { Write<float>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x4, Type: FloatProperty)
    void SET_WallFollowDampening(const float& Value) { Write<float>(uintptr_t(this) + 0x2ac, Value); } // 0x2ac (Size: 0x4, Type: FloatProperty)
    void SET_RotateDampeningRate(const float& Value) { Write<float>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x4, Type: FloatProperty)
    void SET_ViewPlayerState(const TWeakObjectPtr<APlayerState*>& Value) { Write<TWeakObjectPtr<APlayerState*>>(uintptr_t(this) + 0x2b4, Value); } // 0x2b4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_AttachedTarget(const TWeakObjectPtr<USceneComponent*>& Value) { Write<TWeakObjectPtr<USceneComponent*>>(uintptr_t(this) + 0x2bc, Value); } // 0x2bc (Size: 0x8, Type: WeakObjectProperty)
    void SET_AttachedVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x2c4, Value); } // 0x2c4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CameraManager(const TWeakObjectPtr<APlayerCameraManager*>& Value) { Write<TWeakObjectPtr<APlayerCameraManager*>>(uintptr_t(this) + 0x2cc, Value); } // 0x2cc (Size: 0x8, Type: WeakObjectProperty)
    void SET_AttachmentBaseComponent(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    void SET_SpeedometerWidget(const UDelMarWidgetComponent*& Value) { Write<UDelMarWidgetComponent*>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    void SET_DriftBoostWidget(const UDelMarWidgetComponent*& Value) { Write<UDelMarWidgetComponent*>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    void SET_UnderthrustWidget(const UDelMarWidgetComponent*& Value) { Write<UDelMarWidgetComponent*>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xd8
class UDelMarAttachedWidgetComponent : public UControllerComponent
{
public:
    TArray<UClass*> AttachedWidgetActorsClass() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TArray<ADelMarAttachedWidgetActor*> AttachedWidgetActors() const { return Read<TArray<ADelMarAttachedWidgetActor*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)

    void SET_AttachedWidgetActorsClass(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    void SET_AttachedWidgetActors(const TArray<ADelMarAttachedWidgetActor*>& Value) { Write<TArray<ADelMarAttachedWidgetActor*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x6e0
class UDelMarWidgetComponent : public UWidgetComponent
{
public:
    FVector2D LeftTopPadding() const { return Read<FVector2D>(uintptr_t(this) + 0x6b8); } // 0x6b8 (Size: 0x10, Type: StructProperty)
    FVector2D RightBottomPadding() const { return Read<FVector2D>(uintptr_t(this) + 0x6c8); } // 0x6c8 (Size: 0x10, Type: StructProperty)

    void SET_LeftTopPadding(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x6b8, Value); } // 0x6b8 (Size: 0x10, Type: StructProperty)
    void SET_RightBottomPadding(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x6c8, Value); } // 0x6c8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x538
class UDelMarDebugCountdown : public UDelMarScreenBase
{
public:
    UCommonRichTextBlock* CountdownText() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)

    void SET_CountdownText(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x408
class UDelMarStartlineCountdownWidget : public UDelMarUserWidget
{
public:
    TWeakObjectPtr<ADelMarVehicle*> CachedDelMarVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AActor*> CurrentViewTarget() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_CachedDelMarVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CurrentViewTarget(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x3e0
class UDelMarCheckpointTrackerEntryWidget : public UDelMarUserWidget
{
public:
    UWidgetAnimation* AnimTransitionIn() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)

    void SET_AnimTransitionIn(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x408
class UDelMarCheckpointTrackerWidget : public UDelMarUserWidget
{
public:
    UClass* CheckpointTrackerEntryClass() const { return Read<UClass*>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: ClassProperty)
    int32_t NumDesignerPreviewEntries() const { return Read<int32_t>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x4, Type: IntProperty)
    float EntrySpacing() const { return Read<float>(uintptr_t(this) + 0x3cc); } // 0x3cc (Size: 0x4, Type: FloatProperty)
    int32_t MaxEntriesToDisplay() const { return Read<int32_t>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x4, Type: IntProperty)
    UOverlay* CheckpointEntryOverlay() const { return Read<UOverlay*>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    URetainerBox* EdgeFadeRetainerBox() const { return Read<URetainerBox*>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    USizeBox* TrackerSizeBox() const { return Read<USizeBox*>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    TArray<UDelMarCheckpointTrackerEntryWidget*> DisplayedCheckpointTrackerEntries() const { return Read<TArray<UDelMarCheckpointTrackerEntryWidget*>>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x10, Type: ArrayProperty)

    void SET_CheckpointTrackerEntryClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: ClassProperty)
    void SET_NumDesignerPreviewEntries(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x4, Type: IntProperty)
    void SET_EntrySpacing(const float& Value) { Write<float>(uintptr_t(this) + 0x3cc, Value); } // 0x3cc (Size: 0x4, Type: FloatProperty)
    void SET_MaxEntriesToDisplay(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x4, Type: IntProperty)
    void SET_CheckpointEntryOverlay(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    void SET_EdgeFadeRetainerBox(const URetainerBox*& Value) { Write<URetainerBox*>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    void SET_TrackerSizeBox(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    void SET_DisplayedCheckpointTrackerEntries(const TArray<UDelMarCheckpointTrackerEntryWidget*>& Value) { Write<TArray<UDelMarCheckpointTrackerEntryWidget*>>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x508
class UDelMarBladeMenuContainer : public UDelMarScreenBase
{
public:
    UFortDualBladeMenu* DualBladeMenu() const { return Read<UFortDualBladeMenu*>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag CloseBladeMenuTriggerTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x4, Type: StructProperty)

    void SET_DualBladeMenu(const UFortDualBladeMenu*& Value) { Write<UFortDualBladeMenu*>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)
    void SET_CloseBladeMenuTriggerTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x4, Type: StructProperty)
};

// Size: 0x528
class UDelMarCheckpointTimer : public UDelMarScreenBase
{
public:
    UCommonTextBlock* Text_LapCount() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_CheckpointIndex() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Timestamp() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_LapTimestamp() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x510); } // 0x510 (Size: 0x8, Type: ObjectProperty)

    void SET_Text_LapCount(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_CheckpointIndex(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_Timestamp(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_LapTimestamp(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x510, Value); } // 0x510 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x420
class UDelMarDebugPointWidget : public UDelMarUserWidget
{
public:
    FString PlayerPointsString() const { return Read<FString>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x10, Type: StrProperty)

    void SET_PlayerPointsString(const FString& Value) { Write<FString>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x408
class UDelMarDebugRubberbandingWidget : public UDelMarUserWidget
{
public:
    bool bRubberbandingEnabled() const { return Read<bool>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x1, Type: BoolProperty)
    float PackDistance() const { return Read<float>(uintptr_t(this) + 0x3c4); } // 0x3c4 (Size: 0x4, Type: FloatProperty)
    float MinPackDistance() const { return Read<float>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x4, Type: FloatProperty)
    float MaxPackDistance() const { return Read<float>(uintptr_t(this) + 0x3cc); } // 0x3cc (Size: 0x4, Type: FloatProperty)
    float DistanceToPack() const { return Read<float>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x4, Type: FloatProperty)
    float MinDistanceFromPack() const { return Read<float>(uintptr_t(this) + 0x3d4); } // 0x3d4 (Size: 0x4, Type: FloatProperty)
    float MaxDistanceFromPack() const { return Read<float>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x4, Type: FloatProperty)
    float MinSpeed() const { return Read<float>(uintptr_t(this) + 0x3dc); } // 0x3dc (Size: 0x4, Type: FloatProperty)
    float StableSpeed() const { return Read<float>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x4, Type: FloatProperty)
    float AppliedBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x3e4); } // 0x3e4 (Size: 0x4, Type: FloatProperty)
    float DistanceToPackRatio() const { return Read<float>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x4, Type: FloatProperty)
    float MaxBonusSpeedAtPosition() const { return Read<float>(uintptr_t(this) + 0x3ec); } // 0x3ec (Size: 0x4, Type: FloatProperty)
    float MaxSpeedAtPosition() const { return Read<float>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x4, Type: FloatProperty)
    float MaxAllowedBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x3f4); } // 0x3f4 (Size: 0x4, Type: FloatProperty)
    float BonusSpeedGainedPerSecond() const { return Read<float>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x4, Type: FloatProperty)
    float BonusSpeedLostPerSecond() const { return Read<float>(uintptr_t(this) + 0x3fc); } // 0x3fc (Size: 0x4, Type: FloatProperty)
    int32_t MMRUsed() const { return Read<int32_t>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x4, Type: IntProperty)
    float MaxBonusSpeedScalar() const { return Read<float>(uintptr_t(this) + 0x404); } // 0x404 (Size: 0x4, Type: FloatProperty)

    void SET_bRubberbandingEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x1, Type: BoolProperty)
    void SET_PackDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x3c4, Value); } // 0x3c4 (Size: 0x4, Type: FloatProperty)
    void SET_MinPackDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxPackDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x3cc, Value); } // 0x3cc (Size: 0x4, Type: FloatProperty)
    void SET_DistanceToPack(const float& Value) { Write<float>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x4, Type: FloatProperty)
    void SET_MinDistanceFromPack(const float& Value) { Write<float>(uintptr_t(this) + 0x3d4, Value); } // 0x3d4 (Size: 0x4, Type: FloatProperty)
    void SET_MaxDistanceFromPack(const float& Value) { Write<float>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x4, Type: FloatProperty)
    void SET_MinSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x3dc, Value); } // 0x3dc (Size: 0x4, Type: FloatProperty)
    void SET_StableSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x4, Type: FloatProperty)
    void SET_AppliedBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x3e4, Value); } // 0x3e4 (Size: 0x4, Type: FloatProperty)
    void SET_DistanceToPackRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxBonusSpeedAtPosition(const float& Value) { Write<float>(uintptr_t(this) + 0x3ec, Value); } // 0x3ec (Size: 0x4, Type: FloatProperty)
    void SET_MaxSpeedAtPosition(const float& Value) { Write<float>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxAllowedBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x3f4, Value); } // 0x3f4 (Size: 0x4, Type: FloatProperty)
    void SET_BonusSpeedGainedPerSecond(const float& Value) { Write<float>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x4, Type: FloatProperty)
    void SET_BonusSpeedLostPerSecond(const float& Value) { Write<float>(uintptr_t(this) + 0x3fc, Value); } // 0x3fc (Size: 0x4, Type: FloatProperty)
    void SET_MMRUsed(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x4, Type: IntProperty)
    void SET_MaxBonusSpeedScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x404, Value); } // 0x404 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x3d0
class UDelMarDebugVehicleHealthWidget : public UDelMarUserWidget
{
public:
    float CurrentHealth() const { return Read<float>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x4, Type: FloatProperty)
    float MaxHealth() const { return Read<float>(uintptr_t(this) + 0x3c4); } // 0x3c4 (Size: 0x4, Type: FloatProperty)

    void SET_CurrentHealth(const float& Value) { Write<float>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxHealth(const float& Value) { Write<float>(uintptr_t(this) + 0x3c4, Value); } // 0x3c4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x488
class UDelMarDebugVehicleWidget : public UDelMarUserWidget
{
public:
    float BaseTargetSpeed() const { return Read<float>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x4, Type: FloatProperty)
    float FinalTargetSpeed() const { return Read<float>(uintptr_t(this) + 0x3c4); } // 0x3c4 (Size: 0x4, Type: FloatProperty)
    float OversteerPercentage() const { return Read<float>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x4, Type: FloatProperty)
    bool bHasValidDraftingTarget() const { return Read<bool>(uintptr_t(this) + 0x3cc); } // 0x3cc (Size: 0x1, Type: BoolProperty)
    uint8_t DraftingState() const { return Read<uint8_t>(uintptr_t(this) + 0x3cd); } // 0x3cd (Size: 0x1, Type: EnumProperty)
    float DraftingBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x4, Type: FloatProperty)
    float DraftingTargetDegrees() const { return Read<float>(uintptr_t(this) + 0x3d4); } // 0x3d4 (Size: 0x4, Type: FloatProperty)
    float DraftingCurrentBonusSpeedPercentage() const { return Read<float>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x4, Type: FloatProperty)
    float DraftingMaxBonusSpeedPercentage() const { return Read<float>(uintptr_t(this) + 0x3dc); } // 0x3dc (Size: 0x4, Type: FloatProperty)
    float SecondsInDrift() const { return Read<float>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x4, Type: FloatProperty)
    float AccumulatedWaitingPeriodSeconds() const { return Read<float>(uintptr_t(this) + 0x3e4); } // 0x3e4 (Size: 0x4, Type: FloatProperty)
    float DriftBoostBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x4, Type: FloatProperty)
    float DriftBoostDuration() const { return Read<float>(uintptr_t(this) + 0x3ec); } // 0x3ec (Size: 0x4, Type: FloatProperty)
    float DriftBoostDurationSecondsLeft() const { return Read<float>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x4, Type: FloatProperty)
    float PotentialDriftBoostBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x3f4); } // 0x3f4 (Size: 0x4, Type: FloatProperty)
    float PotentialDriftBoostDuration() const { return Read<float>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x4, Type: FloatProperty)
    float QueuedDriftBoostBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x3fc); } // 0x3fc (Size: 0x4, Type: FloatProperty)
    float StartlineBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x4, Type: FloatProperty)
    float TurboBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x404); } // 0x404 (Size: 0x4, Type: FloatProperty)
    float TurboZoneBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x4, Type: FloatProperty)
    float TurboSecondsRemaining() const { return Read<float>(uintptr_t(this) + 0x40c); } // 0x40c (Size: 0x4, Type: FloatProperty)
    float TurboCharges() const { return Read<float>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x4, Type: FloatProperty)
    float WorldBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x414); } // 0x414 (Size: 0x4, Type: FloatProperty)
    float TotalBonusSpeed() const { return Read<float>(uintptr_t(this) + 0x418); } // 0x418 (Size: 0x4, Type: FloatProperty)
    FDelMarTerrainData TerrainData() const { return Read<FDelMarTerrainData>(uintptr_t(this) + 0x41c); } // 0x41c (Size: 0x18, Type: StructProperty)
    int32_t NumWheelWorldContacts() const { return Read<int32_t>(uintptr_t(this) + 0x434); } // 0x434 (Size: 0x4, Type: IntProperty)
    FVector AverageWheelWorldContactNormal() const { return Read<FVector>(uintptr_t(this) + 0x438); } // 0x438 (Size: 0x18, Type: StructProperty)
    float MinimumLandingSpeed() const { return Read<float>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x4, Type: FloatProperty)
    float BaseForwardSpeed() const { return Read<float>(uintptr_t(this) + 0x454); } // 0x454 (Size: 0x4, Type: FloatProperty)
    float StableSpeed() const { return Read<float>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x4, Type: FloatProperty)
    float UpwardSpeed() const { return Read<float>(uintptr_t(this) + 0x45c); } // 0x45c (Size: 0x4, Type: FloatProperty)
    float VehicleSpeed() const { return Read<float>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x4, Type: FloatProperty)
    bool bInvertedSteeringActive() const { return Read<bool>(uintptr_t(this) + 0x464); } // 0x464 (Size: 0x1, Type: BoolProperty)
    float MaxForwardSpeed() const { return Read<float>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x4, Type: FloatProperty)
    float SecondsSinceTerrainPenalty() const { return Read<float>(uintptr_t(this) + 0x46c); } // 0x46c (Size: 0x4, Type: FloatProperty)
    int32_t KickflipActivationCharges() const { return Read<int32_t>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x4, Type: IntProperty)
    bool bStrafeDisabled() const { return Read<bool>(uintptr_t(this) + 0x474); } // 0x474 (Size: 0x1, Type: BoolProperty)
    bool bCanActivateStrafe() const { return Read<bool>(uintptr_t(this) + 0x475); } // 0x475 (Size: 0x1, Type: BoolProperty)
    float StrafeCooldownSeconds() const { return Read<float>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x4, Type: FloatProperty)
    float StrafeCooldownPercentage() const { return Read<float>(uintptr_t(this) + 0x47c); } // 0x47c (Size: 0x4, Type: FloatProperty)
    float VehicleMass() const { return Read<float>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x4, Type: FloatProperty)

    void SET_BaseTargetSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x4, Type: FloatProperty)
    void SET_FinalTargetSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x3c4, Value); } // 0x3c4 (Size: 0x4, Type: FloatProperty)
    void SET_OversteerPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x4, Type: FloatProperty)
    void SET_bHasValidDraftingTarget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3cc, Value); } // 0x3cc (Size: 0x1, Type: BoolProperty)
    void SET_DraftingState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3cd, Value); } // 0x3cd (Size: 0x1, Type: EnumProperty)
    void SET_DraftingBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x4, Type: FloatProperty)
    void SET_DraftingTargetDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x3d4, Value); } // 0x3d4 (Size: 0x4, Type: FloatProperty)
    void SET_DraftingCurrentBonusSpeedPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x4, Type: FloatProperty)
    void SET_DraftingMaxBonusSpeedPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x3dc, Value); } // 0x3dc (Size: 0x4, Type: FloatProperty)
    void SET_SecondsInDrift(const float& Value) { Write<float>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x4, Type: FloatProperty)
    void SET_AccumulatedWaitingPeriodSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x3e4, Value); } // 0x3e4 (Size: 0x4, Type: FloatProperty)
    void SET_DriftBoostBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x4, Type: FloatProperty)
    void SET_DriftBoostDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x3ec, Value); } // 0x3ec (Size: 0x4, Type: FloatProperty)
    void SET_DriftBoostDurationSecondsLeft(const float& Value) { Write<float>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x4, Type: FloatProperty)
    void SET_PotentialDriftBoostBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x3f4, Value); } // 0x3f4 (Size: 0x4, Type: FloatProperty)
    void SET_PotentialDriftBoostDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x4, Type: FloatProperty)
    void SET_QueuedDriftBoostBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x3fc, Value); } // 0x3fc (Size: 0x4, Type: FloatProperty)
    void SET_StartlineBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x4, Type: FloatProperty)
    void SET_TurboBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x404, Value); } // 0x404 (Size: 0x4, Type: FloatProperty)
    void SET_TurboZoneBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x4, Type: FloatProperty)
    void SET_TurboSecondsRemaining(const float& Value) { Write<float>(uintptr_t(this) + 0x40c, Value); } // 0x40c (Size: 0x4, Type: FloatProperty)
    void SET_TurboCharges(const float& Value) { Write<float>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x4, Type: FloatProperty)
    void SET_WorldBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x414, Value); } // 0x414 (Size: 0x4, Type: FloatProperty)
    void SET_TotalBonusSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x418, Value); } // 0x418 (Size: 0x4, Type: FloatProperty)
    void SET_TerrainData(const FDelMarTerrainData& Value) { Write<FDelMarTerrainData>(uintptr_t(this) + 0x41c, Value); } // 0x41c (Size: 0x18, Type: StructProperty)
    void SET_NumWheelWorldContacts(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x434, Value); } // 0x434 (Size: 0x4, Type: IntProperty)
    void SET_AverageWheelWorldContactNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x438, Value); } // 0x438 (Size: 0x18, Type: StructProperty)
    void SET_MinimumLandingSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x4, Type: FloatProperty)
    void SET_BaseForwardSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x454, Value); } // 0x454 (Size: 0x4, Type: FloatProperty)
    void SET_StableSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x4, Type: FloatProperty)
    void SET_UpwardSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x45c, Value); } // 0x45c (Size: 0x4, Type: FloatProperty)
    void SET_VehicleSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x4, Type: FloatProperty)
    void SET_bInvertedSteeringActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x464, Value); } // 0x464 (Size: 0x1, Type: BoolProperty)
    void SET_MaxForwardSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x4, Type: FloatProperty)
    void SET_SecondsSinceTerrainPenalty(const float& Value) { Write<float>(uintptr_t(this) + 0x46c, Value); } // 0x46c (Size: 0x4, Type: FloatProperty)
    void SET_KickflipActivationCharges(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x4, Type: IntProperty)
    void SET_bStrafeDisabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x474, Value); } // 0x474 (Size: 0x1, Type: BoolProperty)
    void SET_bCanActivateStrafe(const bool& Value) { Write<bool>(uintptr_t(this) + 0x475, Value); } // 0x475 (Size: 0x1, Type: BoolProperty)
    void SET_StrafeCooldownSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x4, Type: FloatProperty)
    void SET_StrafeCooldownPercentage(const float& Value) { Write<float>(uintptr_t(this) + 0x47c, Value); } // 0x47c (Size: 0x4, Type: FloatProperty)
    void SET_VehicleMass(const float& Value) { Write<float>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x500
class UDelMarEmotePickerContainer : public UDelMarScreenBase
{
public:
    FGameplayTag CloseEmotePickerTriggerTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x4, Type: StructProperty)

    void SET_CloseEmotePickerTriggerTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x4, Type: StructProperty)
};

// Size: 0x320
class UDelMarReadyUpWidget : public UUserWidget
{
public:
};

// Size: 0x3c8
class UDelMarTurboBonusZoneWidget : public UDelMarUserWidget
{
public:
    TWeakObjectPtr<ADelMarVehicle*> CachedDelMarVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_CachedDelMarVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x390
class UDelMarInteractionIndicatorContainer : public UFortHUDElementWidget
{
public:
    UFortActorCanvas* VehicleIndicators() const { return Read<UFortActorCanvas*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)

    void SET_VehicleIndicators(const UFortActorCanvas*& Value) { Write<UFortActorCanvas*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x3f0
class UDelMarPositionalTrackerEntryWidget : public UDelMarUserWidget
{
public:
    UWidgetAnimation* AnimIsTargetPlayer() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    bool bTargetPlayer() const { return Read<bool>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x1, Type: BoolProperty)

    void SET_AnimIsTargetPlayer(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    void SET_bTargetPlayer(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x360
class UDelMarLoadingScreenWidget : public UCommonUserWidget
{
public:
    TArray<FText> LoadingScreenTips() const { return Read<TArray<FText>>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x10, Type: ArrayProperty)

    void SET_LoadingScreenTips(const TArray<FText>& Value) { Write<TArray<FText>>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x478
class UDelMarPostRaceRankedRecap : public UCommonActivatableWidget
{
public:
};

// Size: 0x340
class UDelMarDebugGameplayTrackEntry : public UDelMarDebugTrackEntry
{
public:
    UDynamicUIScene* GameplayTrackListScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)

    void SET_GameplayTrackListScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x338
class UDelMarDebugTrackEntry : public UUserWidget
{
public:
    UCommonTextBlock* TrackNameText() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UDelMarLevelDataAsset* LevelDataAsset() const { return Read<UDelMarLevelDataAsset*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)

    void SET_TrackNameText(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_LevelDataAsset(const UDelMarLevelDataAsset*& Value) { Write<UDelMarLevelDataAsset*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x508
class UDelMarDebugTrackList : public UDelMarScreenBase
{
public:
    UCommonListView* TrackView() const { return Read<UCommonListView*>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)
    bool bOnlyReturnAllowedLevels() const { return Read<bool>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x1, Type: BoolProperty)

    void SET_TrackView(const UCommonListView*& Value) { Write<UCommonListView*>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)
    void SET_bOnlyReturnAllowedLevels(const bool& Value) { Write<bool>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x260
class UDelMarBoundActionBar : public UCommonBoundActionBar
{
public:
};

// Size: 0x1530
class UDelMarBoundActionButton : public UCommonButtonBase
{
public:
    FText Text() const { return Read<FText>(uintptr_t(this) + 0x1518); } // 0x1518 (Size: 0x10, Type: TextProperty)

    void SET_Text(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1518, Value); } // 0x1518 (Size: 0x10, Type: TextProperty)
};

// Size: 0x58
class UDelMarBladeMenuTriggerUIStateComponent : public UUIStateComponent
{
public:
    UDelMarBladeMenuTriggerUIStateComponentConfiguration* Configuration() const { return Read<UDelMarBladeMenuTriggerUIStateComponentConfiguration*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    UFortHUDContext* HUDContext() const { return Read<UFortHUDContext*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_Configuration(const UDelMarBladeMenuTriggerUIStateComponentConfiguration*& Value) { Write<UDelMarBladeMenuTriggerUIStateComponentConfiguration*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    void SET_HUDContext(const UFortHUDContext*& Value) { Write<UFortHUDContext*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
class UDelMarBladeMenuTriggerUIStateComponentConfiguration : public UUIStateComponentConfiguration
{
public:
    FGameplayTag BladeMenuTriggerTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: StructProperty)

    void SET_BladeMenuTriggerTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: StructProperty)
};

// Size: 0x50
class UDelMarEmotePickerTriggerUIStateComponent : public UUIStateComponent
{
public:
    UDelMarEmotePickerTriggerUIStateComponentConfiguration* Configuration() const { return Read<UDelMarEmotePickerTriggerUIStateComponentConfiguration*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)

    void SET_Configuration(const UDelMarEmotePickerTriggerUIStateComponentConfiguration*& Value) { Write<UDelMarEmotePickerTriggerUIStateComponentConfiguration*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x38
class UDelMarEmotePickerTriggerUIStateComponentConfiguration : public UUIStateComponentConfiguration
{
public:
    FGameplayTag EmotePickerOpenTriggerTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: StructProperty)
    UFortPickerData* PickerData() const { return Read<UFortPickerData*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_EmotePickerOpenTriggerTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: StructProperty)
    void SET_PickerData(const UFortPickerData*& Value) { Write<UFortPickerData*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xe0
class UDelMarGameplayContextUpdaterUIStateComponent : public UUIStateComponent
{
public:
    TMap<FString, FGameplayTag> GameStateToUITagMap() const { return Read<TMap<FString, FGameplayTag>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x50, Type: MapProperty)
    FGameplayTag CurrentRacerState() const { return Read<FGameplayTag>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: StructProperty)
    FGameplayTag CurrentGameState() const { return Read<FGameplayTag>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: StructProperty)
    FGameplayTag CurrentRaceMode() const { return Read<FGameplayTag>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: StructProperty)
    TWeakObjectPtr<AFortPlayerState*> OwnerPlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> SpectatedPlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerController*> OwnerPlayerController() const { return Read<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPlayerPreferencesComponent*> CachedPreferences() const { return Read<TWeakObjectPtr<UDelMarPlayerPreferencesComponent*>>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarLevelManagerComponent*> LevelManager() const { return Read<TWeakObjectPtr<UDelMarLevelManagerComponent*>>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFortSocialChatV3Manager*> ChatManager() const { return Read<TWeakObjectPtr<UFortSocialChatV3Manager*>>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x8, Type: WeakObjectProperty)

    void SET_GameStateToUITagMap(const TMap<FString, FGameplayTag>& Value) { Write<TMap<FString, FGameplayTag>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x50, Type: MapProperty)
    void SET_CurrentRacerState(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: StructProperty)
    void SET_CurrentGameState(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: StructProperty)
    void SET_CurrentRaceMode(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: StructProperty)
    void SET_OwnerPlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_SpectatedPlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x8, Type: WeakObjectProperty)
    void SET_OwnerPlayerController(const TWeakObjectPtr<AFortPlayerController*>& Value) { Write<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedPreferences(const TWeakObjectPtr<UDelMarPlayerPreferencesComponent*>& Value) { Write<TWeakObjectPtr<UDelMarPlayerPreferencesComponent*>>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x8, Type: WeakObjectProperty)
    void SET_LevelManager(const TWeakObjectPtr<UDelMarLevelManagerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarLevelManagerComponent*>>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CachedVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x8, Type: WeakObjectProperty)
    void SET_ChatManager(const TWeakObjectPtr<UFortSocialChatV3Manager*>& Value) { Write<TWeakObjectPtr<UFortSocialChatV3Manager*>>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x28
class UDelMarGameplayContextUpdaterUIStateComponentConfiguration : public UUIStateComponentConfiguration
{
public:
};

// Size: 0x68
class UDelMarIdleMonitorUIStateComponent : public UUIStateComponent
{
public:
    UDelMarIdleMonitorUIStateComponentConfiguration* Configuration() const { return Read<UDelMarIdleMonitorUIStateComponentConfiguration*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    UDelMarRequestComponent* CachedRequestComponent() const { return Read<UDelMarRequestComponent*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)

    void SET_Configuration(const UDelMarIdleMonitorUIStateComponentConfiguration*& Value) { Write<UDelMarIdleMonitorUIStateComponentConfiguration*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedRequestComponent(const UDelMarRequestComponent*& Value) { Write<UDelMarRequestComponent*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
class UDelMarIdleMonitorUIStateComponentConfiguration : public UUIStateComponentConfiguration
{
public:
    float ActivityCheckPeriod() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)

    void SET_ActivityCheckPeriod(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xf8
class UDelMarGlobalLeaderboardEntryViewModel : public UDelMarViewModelBase
{
public:
    FString PlayerAccountId() const { return Read<FString>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: StrProperty)
    FString PlayerName() const { return Read<FString>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StrProperty)
    double RunDuration() const { return Read<double>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: DoubleProperty)
    int64_t Rank() const { return Read<int64_t>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: Int64Property)
    bool bIsLocalPlayer() const { return Read<bool>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: BoolProperty)
    FDelMarGlobalLeaderboardEntry GlobalLeaderboardEntry() const { return Read<FDelMarGlobalLeaderboardEntry>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x40, Type: StructProperty)

    void SET_PlayerAccountId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: StrProperty)
    void SET_PlayerName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StrProperty)
    void SET_RunDuration(const double& Value) { Write<double>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: DoubleProperty)
    void SET_Rank(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: Int64Property)
    void SET_bIsLocalPlayer(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: BoolProperty)
    void SET_GlobalLeaderboardEntry(const FDelMarGlobalLeaderboardEntry& Value) { Write<FDelMarGlobalLeaderboardEntry>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x40, Type: StructProperty)
};

// Size: 0xd0
class UDelMarLoadingScreenViewModel : public UDelMarViewModelBase
{
public:
    bool bHasValidTrackData() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    FText MapName() const { return Read<FText>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: TextProperty)
    FText MapCreator() const { return Read<FText>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: TextProperty)
    FText MapDescription() const { return Read<FText>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: TextProperty)
    FGameplayTag RaceMode() const { return Read<FGameplayTag>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: StructProperty)
    TSoftObjectPtr<UTexture2D> LoadingBackgroundImage() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x20, Type: SoftObjectProperty)

    void SET_bHasValidTrackData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_MapName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: TextProperty)
    void SET_MapCreator(const FText& Value) { Write<FText>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: TextProperty)
    void SET_MapDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: TextProperty)
    void SET_RaceMode(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: StructProperty)
    void SET_LoadingBackgroundImage(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x80
class UDelMarLocalPlayerSettingsViewModel : public UDelMarViewModelBase
{
public:
    bool bUseIconOnlyPlayerNameplates() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<UDelMarPlayerPreferencesComponent*> CachedPreferences() const { return Read<TWeakObjectPtr<UDelMarPlayerPreferencesComponent*>>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x8, Type: WeakObjectProperty)

    void SET_bUseIconOnlyPlayerNameplates(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_CachedPreferences(const TWeakObjectPtr<UDelMarPlayerPreferencesComponent*>& Value) { Write<TWeakObjectPtr<UDelMarPlayerPreferencesComponent*>>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x110
class UDelMarPlayerRaceStateViewModel : public UDelMarViewModelBase
{
public:
    bool bHasValidData() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    int32_t CurrentLap() const { return Read<int32_t>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: IntProperty)
    bool bHasCompletedRace() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)
    FTimespan RaceCompletionTime() const { return Read<FTimespan>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: StructProperty)
    int32_t SpectatorCount() const { return Read<int32_t>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: IntProperty)
    int32_t CurrentPlacement() const { return Read<int32_t>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: IntProperty)
    int32_t CurrentPlacementByBestRun() const { return Read<int32_t>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: IntProperty)
    double CurrentRunStartTimestamp() const { return Read<double>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: DoubleProperty)
    int32_t LastCompletedSectionIndex() const { return Read<int32_t>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: IntProperty)
    bool bIsNewBestRun() const { return Read<bool>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x1, Type: BoolProperty)
    bool bRunActive() const { return Read<bool>(uintptr_t(this) + 0xa5); } // 0xa5 (Size: 0x1, Type: BoolProperty)
    bool bIsSubsequentRun() const { return Read<bool>(uintptr_t(this) + 0xa6); } // 0xa6 (Size: 0x1, Type: BoolProperty)
    bool bIsPedestrian() const { return Read<bool>(uintptr_t(this) + 0xa7); } // 0xa7 (Size: 0x1, Type: BoolProperty)
    bool bIsSpectator() const { return Read<bool>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    UDelMarRunRecordViewModel* CurrentRunRecord() const { return Read<UDelMarRunRecordViewModel*>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x8, Type: ObjectProperty)
    UDelMarRunRecordViewModel* BestRunRecord() const { return Read<UDelMarRunRecordViewModel*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UDelMarRunRecordViewModel* PreviousBestRunRecord() const { return Read<UDelMarRunRecordViewModel*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    TArray<UDelMarRunRecordViewModel*> MatchRunRecords() const { return Read<TArray<UDelMarRunRecordViewModel*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    UDelMarGlobalLeaderboardEntryViewModel* PersonalBestLeaderboardEntry() const { return Read<UDelMarGlobalLeaderboardEntryViewModel*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    UDelMarGlobalLeaderboardEntryViewModel* NewPersonalBestLeaderboardEntry() const { return Read<UDelMarGlobalLeaderboardEntryViewModel*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    UDelMarVehicleViewModel* Vehicle() const { return Read<UDelMarVehicleViewModel*>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag PreviousRacerState() const { return Read<FGameplayTag>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: StructProperty)
    FGameplayTag RacerState() const { return Read<FGameplayTag>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: StructProperty)
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> PlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPositionalTrackerComponent*> PositionalTrackerComponent() const { return Read<TWeakObjectPtr<UDelMarPositionalTrackerComponent*>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: WeakObjectProperty)

    void SET_bHasValidData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_CurrentLap(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: IntProperty)
    void SET_bHasCompletedRace(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
    void SET_RaceCompletionTime(const FTimespan& Value) { Write<FTimespan>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: StructProperty)
    void SET_SpectatorCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: IntProperty)
    void SET_CurrentPlacement(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: IntProperty)
    void SET_CurrentPlacementByBestRun(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: IntProperty)
    void SET_CurrentRunStartTimestamp(const double& Value) { Write<double>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: DoubleProperty)
    void SET_LastCompletedSectionIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: IntProperty)
    void SET_bIsNewBestRun(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x1, Type: BoolProperty)
    void SET_bRunActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa5, Value); } // 0xa5 (Size: 0x1, Type: BoolProperty)
    void SET_bIsSubsequentRun(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa6, Value); } // 0xa6 (Size: 0x1, Type: BoolProperty)
    void SET_bIsPedestrian(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa7, Value); } // 0xa7 (Size: 0x1, Type: BoolProperty)
    void SET_bIsSpectator(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    void SET_CurrentRunRecord(const UDelMarRunRecordViewModel*& Value) { Write<UDelMarRunRecordViewModel*>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x8, Type: ObjectProperty)
    void SET_BestRunRecord(const UDelMarRunRecordViewModel*& Value) { Write<UDelMarRunRecordViewModel*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_PreviousBestRunRecord(const UDelMarRunRecordViewModel*& Value) { Write<UDelMarRunRecordViewModel*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_MatchRunRecords(const TArray<UDelMarRunRecordViewModel*>& Value) { Write<TArray<UDelMarRunRecordViewModel*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    void SET_PersonalBestLeaderboardEntry(const UDelMarGlobalLeaderboardEntryViewModel*& Value) { Write<UDelMarGlobalLeaderboardEntryViewModel*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_NewPersonalBestLeaderboardEntry(const UDelMarGlobalLeaderboardEntryViewModel*& Value) { Write<UDelMarGlobalLeaderboardEntryViewModel*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    void SET_Vehicle(const UDelMarVehicleViewModel*& Value) { Write<UDelMarVehicleViewModel*>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    void SET_PreviousRacerState(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: StructProperty)
    void SET_RacerState(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: StructProperty)
    void SET_RaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PositionalTrackerComponent(const TWeakObjectPtr<UDelMarPositionalTrackerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarPositionalTrackerComponent*>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xe8
class UDelMarPlayerViewModel : public UDelMarViewModelBase
{
public:
    FText DisplayName() const { return Read<FText>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UTexture2D> AvatarLargeImage() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D> AvatarSmallImage() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x20, Type: SoftObjectProperty)
    FColor AvatarBackgroundColor() const { return Read<FColor>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: StructProperty)
    FColor AvatarHighlightColor() const { return Read<FColor>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: StructProperty)
    UTextureRenderTarget2D* DriverCameraRT() const { return Read<UTextureRenderTarget2D*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    UDelMarPlayerRaceStateViewModel* PlayerRaceState() const { return Read<UDelMarPlayerRaceStateViewModel*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> PlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_DisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: TextProperty)
    void SET_AvatarLargeImage(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x20, Type: SoftObjectProperty)
    void SET_AvatarSmallImage(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_AvatarBackgroundColor(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: StructProperty)
    void SET_AvatarHighlightColor(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: StructProperty)
    void SET_DriverCameraRT(const UTextureRenderTarget2D*& Value) { Write<UTextureRenderTarget2D*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerRaceState(const UDelMarPlayerRaceStateViewModel*& Value) { Write<UDelMarPlayerRaceStateViewModel*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_RaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x228
class UDelMarRaceViewModel : public UDelMarViewModelBase
{
public:
    int32_t TotalLaps() const { return Read<int32_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: IntProperty)
    int32_t TotalPlayers() const { return Read<int32_t>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: IntProperty)
    int32_t TotalReadyPlayers() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)
    int32_t TotalLoadedPlayers() const { return Read<int32_t>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: IntProperty)
    int32_t TotalJoiningPlayers() const { return Read<int32_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: IntProperty)
    int32_t TotalPlacements() const { return Read<int32_t>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: IntProperty)
    FText MapName() const { return Read<FText>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: TextProperty)
    FText MapCreator() const { return Read<FText>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: TextProperty)
    FText MapDescription() const { return Read<FText>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: TextProperty)
    FGameplayTag RaceMode() const { return Read<FGameplayTag>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: StructProperty)
    FGameplayTag DelMarGameplayState() const { return Read<FGameplayTag>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: StructProperty)
    TSoftObjectPtr<UTexture2D> LoadingBackgroundImage() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x20, Type: SoftObjectProperty)
    double TimeUntilRaceStart() const { return Read<double>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: DoubleProperty)
    double RaceEndTimestamp() const { return Read<double>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: DoubleProperty)
    int32_t MatchTimeLimitSeconds() const { return Read<int32_t>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: IntProperty)
    bool bIsOvertime() const { return Read<bool>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x1, Type: BoolProperty)
    double TimeUntilTrackChange() const { return Read<double>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: DoubleProperty)
    double FirstPlayerFinishedServerTimestamp() const { return Read<double>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: DoubleProperty)
    double FirstPlayerFinishedRaceEndServerTimestamp() const { return Read<double>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: DoubleProperty)
    char CurrentMatchmakingState() const { return Read<char>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x1, Type: ByteProperty)
    bool bIsRaceFinished() const { return Read<bool>(uintptr_t(this) + 0x111); } // 0x111 (Size: 0x1, Type: BoolProperty)
    bool bIsRaceStarted() const { return Read<bool>(uintptr_t(this) + 0x112); } // 0x112 (Size: 0x1, Type: BoolProperty)
    bool bHasPreRaceSocial() const { return Read<bool>(uintptr_t(this) + 0x113); } // 0x113 (Size: 0x1, Type: BoolProperty)
    UDelMarMatchEventViewModel* MatchEventViewModel() const { return Read<UDelMarMatchEventViewModel*>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    UDelMarTrackInfoViewModel* TrackInfoViewModel() const { return Read<UDelMarTrackInfoViewModel*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    UDelMarPlayerViewModel* LocalPlayer() const { return Read<UDelMarPlayerViewModel*>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    UDelMarPlayerViewModel* TargetPlayer() const { return Read<UDelMarPlayerViewModel*>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x8, Type: ObjectProperty)
    UDelMarPlayerViewModel* LastTargetPlayer() const { return Read<UDelMarPlayerViewModel*>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x8, Type: ObjectProperty)
    TArray<UDelMarPlayerViewModel*> PositionPlayers() const { return Read<TArray<UDelMarPlayerViewModel*>>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x10, Type: ArrayProperty)
    TArray<UDelMarPlayerViewModel*> FinalPlacements() const { return Read<TArray<UDelMarPlayerViewModel*>>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x10, Type: ArrayProperty)
    TMap<UDelMarPlayerViewModel*, int32_t> RacePlayers() const { return Read<TMap<UDelMarPlayerViewModel*, int32_t>>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x50, Type: MapProperty)
    TArray<UDelMarGlobalLeaderboardEntryViewModel*> TopLeaderboardEntries() const { return Read<TArray<UDelMarGlobalLeaderboardEntryViewModel*>>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x10, Type: ArrayProperty)
    TArray<UDelMarGlobalLeaderboardEntryViewModel*> FocusedLeaderboardEntries() const { return Read<TArray<UDelMarGlobalLeaderboardEntryViewModel*>>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x10, Type: ArrayProperty)
    TArray<UDelMarGlobalLeaderboardEntryViewModel*> FriendLeaderboardEntries() const { return Read<TArray<UDelMarGlobalLeaderboardEntryViewModel*>>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x10, Type: ArrayProperty)
    FString GameSessionId() const { return Read<FString>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x10, Type: StrProperty)
    FString IslandCode() const { return Read<FString>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x10, Type: StrProperty)
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager() const { return Read<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerController*> LocalPlayerController() const { return Read<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> ViewTargetPlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPositionalTrackerComponent*> PositionalTrackerComponent() const { return Read<TWeakObjectPtr<UDelMarPositionalTrackerComponent*>>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x8, Type: WeakObjectProperty)
    UDelMarPlayerViewModel* EmptyPlayerViewModel() const { return Read<UDelMarPlayerViewModel*>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x8, Type: ObjectProperty)

    void SET_TotalLaps(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: IntProperty)
    void SET_TotalPlayers(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: IntProperty)
    void SET_TotalReadyPlayers(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
    void SET_TotalLoadedPlayers(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: IntProperty)
    void SET_TotalJoiningPlayers(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: IntProperty)
    void SET_TotalPlacements(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: IntProperty)
    void SET_MapName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: TextProperty)
    void SET_MapCreator(const FText& Value) { Write<FText>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: TextProperty)
    void SET_MapDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: TextProperty)
    void SET_RaceMode(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: StructProperty)
    void SET_DelMarGameplayState(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: StructProperty)
    void SET_LoadingBackgroundImage(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_TimeUntilRaceStart(const double& Value) { Write<double>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: DoubleProperty)
    void SET_RaceEndTimestamp(const double& Value) { Write<double>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: DoubleProperty)
    void SET_MatchTimeLimitSeconds(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: IntProperty)
    void SET_bIsOvertime(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x1, Type: BoolProperty)
    void SET_TimeUntilTrackChange(const double& Value) { Write<double>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: DoubleProperty)
    void SET_FirstPlayerFinishedServerTimestamp(const double& Value) { Write<double>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: DoubleProperty)
    void SET_FirstPlayerFinishedRaceEndServerTimestamp(const double& Value) { Write<double>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: DoubleProperty)
    void SET_CurrentMatchmakingState(const char& Value) { Write<char>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x1, Type: ByteProperty)
    void SET_bIsRaceFinished(const bool& Value) { Write<bool>(uintptr_t(this) + 0x111, Value); } // 0x111 (Size: 0x1, Type: BoolProperty)
    void SET_bIsRaceStarted(const bool& Value) { Write<bool>(uintptr_t(this) + 0x112, Value); } // 0x112 (Size: 0x1, Type: BoolProperty)
    void SET_bHasPreRaceSocial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x113, Value); } // 0x113 (Size: 0x1, Type: BoolProperty)
    void SET_MatchEventViewModel(const UDelMarMatchEventViewModel*& Value) { Write<UDelMarMatchEventViewModel*>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    void SET_TrackInfoViewModel(const UDelMarTrackInfoViewModel*& Value) { Write<UDelMarTrackInfoViewModel*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    void SET_LocalPlayer(const UDelMarPlayerViewModel*& Value) { Write<UDelMarPlayerViewModel*>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetPlayer(const UDelMarPlayerViewModel*& Value) { Write<UDelMarPlayerViewModel*>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x8, Type: ObjectProperty)
    void SET_LastTargetPlayer(const UDelMarPlayerViewModel*& Value) { Write<UDelMarPlayerViewModel*>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x8, Type: ObjectProperty)
    void SET_PositionPlayers(const TArray<UDelMarPlayerViewModel*>& Value) { Write<TArray<UDelMarPlayerViewModel*>>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x10, Type: ArrayProperty)
    void SET_FinalPlacements(const TArray<UDelMarPlayerViewModel*>& Value) { Write<TArray<UDelMarPlayerViewModel*>>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x10, Type: ArrayProperty)
    void SET_RacePlayers(const TMap<UDelMarPlayerViewModel*, int32_t>& Value) { Write<TMap<UDelMarPlayerViewModel*, int32_t>>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x50, Type: MapProperty)
    void SET_TopLeaderboardEntries(const TArray<UDelMarGlobalLeaderboardEntryViewModel*>& Value) { Write<TArray<UDelMarGlobalLeaderboardEntryViewModel*>>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x10, Type: ArrayProperty)
    void SET_FocusedLeaderboardEntries(const TArray<UDelMarGlobalLeaderboardEntryViewModel*>& Value) { Write<TArray<UDelMarGlobalLeaderboardEntryViewModel*>>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x10, Type: ArrayProperty)
    void SET_FriendLeaderboardEntries(const TArray<UDelMarGlobalLeaderboardEntryViewModel*>& Value) { Write<TArray<UDelMarGlobalLeaderboardEntryViewModel*>>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x10, Type: ArrayProperty)
    void SET_GameSessionId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x10, Type: StrProperty)
    void SET_IslandCode(const FString& Value) { Write<FString>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x10, Type: StrProperty)
    void SET_RaceManager(const TWeakObjectPtr<ADelMarRaceManager*>& Value) { Write<TWeakObjectPtr<ADelMarRaceManager*>>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x8, Type: WeakObjectProperty)
    void SET_LocalPlayerController(const TWeakObjectPtr<AFortPlayerController*>& Value) { Write<TWeakObjectPtr<AFortPlayerController*>>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ViewTargetPlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PositionalTrackerComponent(const TWeakObjectPtr<UDelMarPositionalTrackerComponent*>& Value) { Write<TWeakObjectPtr<UDelMarPositionalTrackerComponent*>>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x8, Type: WeakObjectProperty)
    void SET_EmptyPlayerViewModel(const UDelMarPlayerViewModel*& Value) { Write<UDelMarPlayerViewModel*>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xa8
class UDelMarRunRecordViewModel : public UDelMarViewModelBase
{
public:
    FDelMarRunRecord Record() const { return Read<FDelMarRunRecord>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x20, Type: StructProperty)
    TArray<FDelMarSectionData> RunRecordSectionData() const { return Read<TArray<FDelMarSectionData>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    bool bHasValidData() const { return Read<bool>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: BoolProperty)

    void SET_Record(const FDelMarRunRecord& Value) { Write<FDelMarRunRecord>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x20, Type: StructProperty)
    void SET_RunRecordSectionData(const TArray<FDelMarSectionData>& Value) { Write<TArray<FDelMarSectionData>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    void SET_bHasValidData(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xd0
class UDelMarTrackInfoViewModel : public UDelMarViewModelBase
{
public:
    bool bHasValidTrackData() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    FText TrackName() const { return Read<FText>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: TextProperty)
    FText TrackDescription() const { return Read<FText>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UTexture2D> LoadingBackgroundImage() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x20, Type: SoftObjectProperty)
    FText CreatorName() const { return Read<FText>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: TextProperty)
    bool bIsEpicCreated() const { return Read<bool>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: BoolProperty)
    bool bHasValidCreatorData() const { return Read<bool>(uintptr_t(this) + 0xc9); } // 0xc9 (Size: 0x1, Type: BoolProperty)

    void SET_bHasValidTrackData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_TrackName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: TextProperty)
    void SET_TrackDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: TextProperty)
    void SET_LoadingBackgroundImage(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x20, Type: SoftObjectProperty)
    void SET_CreatorName(const FText& Value) { Write<FText>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: TextProperty)
    void SET_bIsEpicCreated(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: BoolProperty)
    void SET_bHasValidCreatorData(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc9, Value); } // 0xc9 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb0
class UDelMarTutorialViewModel : public UDelMarViewModelBase
{
public:
    FText SectionTitle() const { return Read<FText>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: TextProperty)
    int32_t CurrentSection() const { return Read<int32_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: IntProperty)
    int32_t TotalSections() const { return Read<int32_t>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: IntProperty)
    TArray<UInputAction*> CurrentTutorialAnnouncementInputActions() const { return Read<TArray<UInputAction*>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    TArray<UInputAction*> CurrentTutorialHintInputActions() const { return Read<TArray<UInputAction*>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    FTimespan FinishTargetTime() const { return Read<FTimespan>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x8, Type: StructProperty)

    void SET_SectionTitle(const FText& Value) { Write<FText>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: TextProperty)
    void SET_CurrentSection(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: IntProperty)
    void SET_TotalSections(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: IntProperty)
    void SET_CurrentTutorialAnnouncementInputActions(const TArray<UInputAction*>& Value) { Write<TArray<UInputAction*>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentTutorialHintInputActions(const TArray<UInputAction*>& Value) { Write<TArray<UInputAction*>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    void SET_FinishTargetTime(const FTimespan& Value) { Write<FTimespan>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x8, Type: StructProperty)
};

// Size: 0xf0
class UDelMarVehicleViewModel : public UDelMarViewModelBase
{
public:
    bool bHasValidData() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    bool bIsTurboEnabled() const { return Read<bool>(uintptr_t(this) + 0x71); } // 0x71 (Size: 0x1, Type: BoolProperty)
    bool bIsDrifting() const { return Read<bool>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x1, Type: BoolProperty)
    bool bIsDriftingRight() const { return Read<bool>(uintptr_t(this) + 0x75); } // 0x75 (Size: 0x1, Type: BoolProperty)
    bool bWheelsOnGround() const { return Read<bool>(uintptr_t(this) + 0x76); } // 0x76 (Size: 0x1, Type: BoolProperty)
    bool bAnyWheelsOnGround() const { return Read<bool>(uintptr_t(this) + 0x77); } // 0x77 (Size: 0x1, Type: BoolProperty)
    TArray<double> DriftRanges() const { return Read<TArray<double>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    float DriftSlipAngleRatio() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)
    uint8_t DriftSteerState() const { return Read<uint8_t>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x1, Type: EnumProperty)
    float PotentialDriftBoostPercent() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    float StartlineBoostBonus() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)
    uint8_t SpeedometerState() const { return Read<uint8_t>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: EnumProperty)
    float CurrentSpeed() const { return Read<float>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: FloatProperty)
    float NumTurboMaxCharges() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    float NumTurboCurrentCharges() const { return Read<float>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    uint8_t TurboBonusZoneState() const { return Read<uint8_t>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x1, Type: EnumProperty)
    float UnderthrustPercent() const { return Read<float>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: FloatProperty)
    double MissedCheckpointDemoTimestamp() const { return Read<double>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x8, Type: DoubleProperty)
    double ReturnToTrackDemoTimestamp() const { return Read<double>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: DoubleProperty)
    bool bIsHeadingWrongWay() const { return Read<bool>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    bool bToggleThrottle() const { return Read<bool>(uintptr_t(this) + 0xc1); } // 0xc1 (Size: 0x1, Type: BoolProperty)
    float ThrottleInputValue() const { return Read<float>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    bool bDemolished() const { return Read<bool>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: BoolProperty)
    float DemolishActionPressedPercent() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    bool bDemolishActionEnabled() const { return Read<bool>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<AFortPlayerState*> PlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> CurrentVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarGlobalInputDisabler*> GlobalInputDisabler() const { return Read<TWeakObjectPtr<UDelMarGlobalInputDisabler*>>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x8, Type: WeakObjectProperty)

    void SET_bHasValidData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_bIsTurboEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x71, Value); } // 0x71 (Size: 0x1, Type: BoolProperty)
    void SET_bIsDrifting(const bool& Value) { Write<bool>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x1, Type: BoolProperty)
    void SET_bIsDriftingRight(const bool& Value) { Write<bool>(uintptr_t(this) + 0x75, Value); } // 0x75 (Size: 0x1, Type: BoolProperty)
    void SET_bWheelsOnGround(const bool& Value) { Write<bool>(uintptr_t(this) + 0x76, Value); } // 0x76 (Size: 0x1, Type: BoolProperty)
    void SET_bAnyWheelsOnGround(const bool& Value) { Write<bool>(uintptr_t(this) + 0x77, Value); } // 0x77 (Size: 0x1, Type: BoolProperty)
    void SET_DriftRanges(const TArray<double>& Value) { Write<TArray<double>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    void SET_DriftSlipAngleRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
    void SET_DriftSteerState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x1, Type: EnumProperty)
    void SET_PotentialDriftBoostPercent(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_StartlineBoostBonus(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
    void SET_SpeedometerState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: EnumProperty)
    void SET_CurrentSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: FloatProperty)
    void SET_NumTurboMaxCharges(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    void SET_NumTurboCurrentCharges(const float& Value) { Write<float>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: FloatProperty)
    void SET_TurboBonusZoneState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x1, Type: EnumProperty)
    void SET_UnderthrustPercent(const float& Value) { Write<float>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: FloatProperty)
    void SET_MissedCheckpointDemoTimestamp(const double& Value) { Write<double>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x8, Type: DoubleProperty)
    void SET_ReturnToTrackDemoTimestamp(const double& Value) { Write<double>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: DoubleProperty)
    void SET_bIsHeadingWrongWay(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    void SET_bToggleThrottle(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc1, Value); } // 0xc1 (Size: 0x1, Type: BoolProperty)
    void SET_ThrottleInputValue(const float& Value) { Write<float>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    void SET_bDemolished(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: BoolProperty)
    void SET_DemolishActionPressedPercent(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_bDemolishActionEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    void SET_PlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CurrentVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x8, Type: WeakObjectProperty)
    void SET_GlobalInputDisabler(const TWeakObjectPtr<UDelMarGlobalInputDisabler*>& Value) { Write<TWeakObjectPtr<UDelMarGlobalInputDisabler*>>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x80
class UDelMarRankedPlacementChangeVM : public UMVVMViewModelBase
{
public:
    UDelMarRankedPlacementVM* InitialPlacement() const { return Read<UDelMarRankedPlacementVM*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    UDelMarRankedPlacementVM* CurrentPlacement() const { return Read<UDelMarRankedPlacementVM*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    int32_t PositionDelta() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)
    bool bIsDataValid() const { return Read<bool>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x1, Type: BoolProperty)

    void SET_InitialPlacement(const UDelMarRankedPlacementVM*& Value) { Write<UDelMarRankedPlacementVM*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentPlacement(const UDelMarRankedPlacementVM*& Value) { Write<UDelMarRankedPlacementVM*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_PositionDelta(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
    void SET_bIsDataValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1c0
class UDelMarRankedPlacementVM : public UMVVMViewModelBase
{
public:
    bool bIsUnranked() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)
    int32_t TierIndex() const { return Read<int32_t>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: IntProperty)
    int32_t PlayerPosition() const { return Read<int32_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: IntProperty)
    float ProgressTowardNextTier() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)
    bool bIsDataValid() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)
    TArray<FFortHabaneroTier> TierList() const { return Read<TArray<FFortHabaneroTier>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    UFortHabaneroDisplayData* RankedDisplayData() const { return Read<UFortHabaneroDisplayData*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)

    void SET_bIsUnranked(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
    void SET_TierIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: IntProperty)
    void SET_PlayerPosition(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: IntProperty)
    void SET_ProgressTowardNextTier(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
    void SET_bIsDataValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
    void SET_TierList(const TArray<FFortHabaneroTier>& Value) { Write<TArray<FFortHabaneroTier>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_RankedDisplayData(const UFortHabaneroDisplayData*& Value) { Write<UFortHabaneroDisplayData*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xb8
class UDelMarRankedRecapVM : public UMVVMViewModelBase
{
public:
    UDelMarRankedPlacementChangeVM* PlacementChange() const { return Read<UDelMarRankedPlacementChangeVM*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    uint8_t ErrorState() const { return Read<uint8_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: EnumProperty)
    FString OptionalErrorText() const { return Read<FString>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StrProperty)
    TWeakObjectPtr<ULocalPlayer*> OwningLocalPlayer() const { return Read<TWeakObjectPtr<ULocalPlayer*>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerControllerAthena*> OwningPlayerController() const { return Read<TWeakObjectPtr<AFortPlayerControllerAthena*>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: WeakObjectProperty)
    UFortHabaneroDisplayData* RankedDisplayData() const { return Read<UFortHabaneroDisplayData*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ObjectProperty)

    void SET_PlacementChange(const UDelMarRankedPlacementChangeVM*& Value) { Write<UDelMarRankedPlacementChangeVM*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_ErrorState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: EnumProperty)
    void SET_OptionalErrorText(const FString& Value) { Write<FString>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StrProperty)
    void SET_OwningLocalPlayer(const TWeakObjectPtr<ULocalPlayer*>& Value) { Write<TWeakObjectPtr<ULocalPlayer*>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: WeakObjectProperty)
    void SET_OwningPlayerController(const TWeakObjectPtr<AFortPlayerControllerAthena*>& Value) { Write<TWeakObjectPtr<AFortPlayerControllerAthena*>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: WeakObjectProperty)
    void SET_RankedDisplayData(const UFortHabaneroDisplayData*& Value) { Write<UFortHabaneroDisplayData*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class UDelMarRankedVMContextResolver : public UMVVMViewModelContextResolver
{
public:
    UFortHabaneroDisplayData* RankedDisplayData() const { return Read<UFortHabaneroDisplayData*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    FString DevelopmentRankedKey() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)

    void SET_RankedDisplayData(const UFortHabaneroDisplayData*& Value) { Write<UFortHabaneroDisplayData*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_DevelopmentRankedKey(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
};

// Size: 0x8
struct FDelMarReactiveWidgetAnimation
{
public:
    FName Intro() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName Outro() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)

    void SET_Intro(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Outro(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x28
struct FDelMarPlayerIndicatorData
{
public:
    TWeakObjectPtr<AFortPlayerState*> PlayerState() const { return Read<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    float LateralRatio() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    FVector2D ScreenPosition() const { return Read<FVector2D>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    float SquareDistance() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t VerticalHint() const { return Read<uint8_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: EnumProperty)
    bool bRearIndicator() const { return Read<bool>(uintptr_t(this) + 0x25); } // 0x25 (Size: 0x1, Type: BoolProperty)
    bool bShow() const { return Read<bool>(uintptr_t(this) + 0x26); } // 0x26 (Size: 0x1, Type: BoolProperty)

    void SET_PlayerState(const TWeakObjectPtr<AFortPlayerState*>& Value) { Write<TWeakObjectPtr<AFortPlayerState*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_LateralRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_ScreenPosition(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_SquareDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_VerticalHint(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: EnumProperty)
    void SET_bRearIndicator(const bool& Value) { Write<bool>(uintptr_t(this) + 0x25, Value); } // 0x25 (Size: 0x1, Type: BoolProperty)
    void SET_bShow(const bool& Value) { Write<bool>(uintptr_t(this) + 0x26, Value); } // 0x26 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FDelMarKeyPair
{
public:
    FKey KBMKey() const { return Read<FKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FKey GamepadKey() const { return Read<FKey>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_KBMKey(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_GamepadKey(const FKey& Value) { Write<FKey>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x170
struct FDelMarTouchActionButtonStateData
{
public:
    FSlateBrush IconBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xb0, Type: StructProperty)
    FSlateBrush BackgroundBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0xb0, Type: StructProperty)
    uint8_t ButtonVisibility() const { return Read<uint8_t>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x1, Type: EnumProperty)
    bool bCancelInputOnEnter() const { return Read<bool>(uintptr_t(this) + 0x161); } // 0x161 (Size: 0x1, Type: BoolProperty)
    bool bCancelInputOnLeave() const { return Read<bool>(uintptr_t(this) + 0x162); } // 0x162 (Size: 0x1, Type: BoolProperty)

    void SET_IconBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xb0, Type: StructProperty)
    void SET_BackgroundBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0xb0, Type: StructProperty)
    void SET_ButtonVisibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x1, Type: EnumProperty)
    void SET_bCancelInputOnEnter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x161, Value); } // 0x161 (Size: 0x1, Type: BoolProperty)
    void SET_bCancelInputOnLeave(const bool& Value) { Write<bool>(uintptr_t(this) + 0x162, Value); } // 0x162 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FDelMarTouchInputDefinition
{
public:
    UInputAction* InputAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<UInputModifier*> Modifiers() const { return Read<TArray<UInputModifier*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<UInputTrigger*> Triggers() const { return Read<TArray<UInputTrigger*>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    bool bUseYAxis() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)

    void SET_InputAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Modifiers(const TArray<UInputModifier*>& Value) { Write<TArray<UInputModifier*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_Triggers(const TArray<UInputTrigger*>& Value) { Write<TArray<UInputTrigger*>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_bUseYAxis(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FDelMarSectionData
{
public:
    int32_t SectionIndex() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    double LapDurationAtSection() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    double DeltaTime() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)

    void SET_SectionIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_LapDurationAtSection(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_DeltaTime(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
};

