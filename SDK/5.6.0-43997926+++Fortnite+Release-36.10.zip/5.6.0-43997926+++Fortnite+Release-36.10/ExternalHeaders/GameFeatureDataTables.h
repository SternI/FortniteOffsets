/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameFeatureDataTables
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x50
class UGameFeatureAction_GameFeatureDataTables : public UGameFeatureAction
{
public:
    FGameplayTag GameFeatureDataTableID() const { return Read<FGameplayTag>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: StructProperty)
    FSoftObjectPath DataTable() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    bool bIsParentDataTable() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)
    bool bAllowOnDedicatedServers() const { return Read<bool>(uintptr_t(this) + 0x49); } // 0x49 (Size: 0x1, Type: BoolProperty)

    void SET_GameFeatureDataTableID(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: StructProperty)
    void SET_DataTable(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_bIsParentDataTable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowOnDedicatedServers(const bool& Value) { Write<bool>(uintptr_t(this) + 0x49, Value); } // 0x49 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
class UGameFeatureDataTablesSubsystem : public UEngineSubsystem
{
public:
    TMap<FGameFeatureDataTableEntry, FGameplayTag> DataTableEntryMap() const { return Read<TMap<FGameFeatureDataTableEntry, FGameplayTag>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)

    void SET_DataTableEntryMap(const TMap<FGameFeatureDataTableEntry, FGameplayTag>& Value) { Write<TMap<FGameFeatureDataTableEntry, FGameplayTag>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
};

// Size: 0x48
struct FGameFeatureDataTableEntry
{
public:
    TArray<UCompositeDataTable*> CompositeDataTables() const { return Read<TArray<UCompositeDataTable*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<UDataTable*> ParentDataTables() const { return Read<TArray<UDataTable*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    UScriptStruct* StructType() const { return Read<UScriptStruct*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)

    void SET_CompositeDataTables(const TArray<UCompositeDataTable*>& Value) { Write<TArray<UCompositeDataTable*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_ParentDataTables(const TArray<UDataTable*>& Value) { Write<TArray<UDataTable*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_StructType(const UScriptStruct*& Value) { Write<UScriptStruct*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
};

