/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarCore_Test
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "DelMarCore.h"

// Size: 0xc0
class UDelMarTestControllerTrackScrubber : public UFortTestControllerBase
{
public:
};

