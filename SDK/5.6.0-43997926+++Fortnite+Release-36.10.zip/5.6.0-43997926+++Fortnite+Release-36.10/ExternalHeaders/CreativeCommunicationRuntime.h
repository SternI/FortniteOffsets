/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeCommunicationRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "DynamicUI.h"
#include "FortniteGame.h"
#include "GameplayAbilities.h"
#include "CoreUObject.h"

// Size: 0x228
class UCreativeGameStateComponent_CommunicationOverride : public UFortGameStateComponent_CommunicationOverride
{
public:
    AFortMinigame* CachedMinigame() const { return Read<AFortMinigame*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* SproutStyleBubbleChatWidgetScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    FCreativeBubbleChatSettings CreativeBubbleChatSettings() const { return Read<FCreativeBubbleChatSettings>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x38, Type: StructProperty)
    FScalableFloat BubbleChatEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x28, Type: StructProperty)
    FScalableFloat BubbleChatMaximumRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x28, Type: StructProperty)
    FScalableFloat BubbleChatMinLifeTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x28, Type: StructProperty)
    FScalableFloat BubbleChatMaxLifeTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x28, Type: StructProperty)
    FScalableFloat BubbleChatOcculdeBubble() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x28, Type: StructProperty)
    FScalableFloat BubbleChatStyle() const { return Read<FScalableFloat>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x28, Type: StructProperty)

    void SET_CachedMinigame(const AFortMinigame*& Value) { Write<AFortMinigame*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    void SET_SproutStyleBubbleChatWidgetScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    void SET_CreativeBubbleChatSettings(const FCreativeBubbleChatSettings& Value) { Write<FCreativeBubbleChatSettings>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x38, Type: StructProperty)
    void SET_BubbleChatEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x28, Type: StructProperty)
    void SET_BubbleChatMaximumRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x28, Type: StructProperty)
    void SET_BubbleChatMinLifeTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x28, Type: StructProperty)
    void SET_BubbleChatMaxLifeTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x28, Type: StructProperty)
    void SET_BubbleChatOcculdeBubble(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x28, Type: StructProperty)
    void SET_BubbleChatStyle(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x28, Type: StructProperty)
};

// Size: 0x28
class UCreativeCommunicationOverrideBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x38
struct FCreativeBubbleChatSettings
{
public:
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float MaximumRange() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinLifetime() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaxLifetime() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    bool bOcculdeBubble() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t BubbleChatStyle() const { return Read<uint8_t>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: EnumProperty)

    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_MaximumRange(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MinLifetime(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxLifetime(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_bOcculdeBubble(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_BubbleChatStyle(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: EnumProperty)
};

