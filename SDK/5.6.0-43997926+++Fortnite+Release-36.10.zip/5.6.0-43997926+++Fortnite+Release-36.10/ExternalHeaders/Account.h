/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Account
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
// Size: 0x38
class UExternalAccountProvider : public UObject
{
public:
    TArray<FExternalAccountServiceConfig> Services() const { return Read<TArray<FExternalAccountServiceConfig>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_Services(const TArray<FExternalAccountServiceConfig>& Value) { Write<TArray<FExternalAccountServiceConfig>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xc90
class UOnlineAccountCommon : public UObject
{
public:
    FString AvailabilityServiceGameName() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)
    bool bRequireLightswitchAtStartup() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)
    bool bPartialLoginEnabled() const { return Read<bool>(uintptr_t(this) + 0x49); } // 0x49 (Size: 0x1, Type: BoolProperty)
    bool bRedeemOfflinePurchasesEnabled() const { return Read<bool>(uintptr_t(this) + 0x4a); } // 0x4a (Size: 0x1, Type: BoolProperty)
    bool bCheckingRejoinEnabled() const { return Read<bool>(uintptr_t(this) + 0x4b); } // 0x4b (Size: 0x1, Type: BoolProperty)
    FString EULAKey() const { return Read<FString>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: StrProperty)
    TArray<FString> EulaKeys() const { return Read<TArray<FString>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    TMap<FString, FString> EulaKeyMapping() const { return Read<TMap<FString, FString>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x50, Type: MapProperty)
    bool bEnableWaitingRoom() const { return Read<bool>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    TArray<FWebEnvUrl> WebCreateEpicAccountUrl() const { return Read<TArray<FWebEnvUrl>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    bool bAllowLocalLogout() const { return Read<bool>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x1, Type: BoolProperty)
    float DefaultLoginStepTimeout() const { return Read<float>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x4, Type: FloatProperty)
    TMap<float, FName> CustomLoginStepTimeouts() const { return Read<TMap<float, FName>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x50, Type: MapProperty)
    bool bEnableDevLoginStepTimeouts() const { return Read<bool>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x1, Type: BoolProperty)
    float DefaultLogoutStepTimeout() const { return Read<float>(uintptr_t(this) + 0x16c); } // 0x16c (Size: 0x4, Type: FloatProperty)
    TMap<float, FName> CustomLogoutStepTimeouts() const { return Read<TMap<float, FName>>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x50, Type: MapProperty)
    bool bEnableDevLogoutStepTimeouts() const { return Read<bool>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x1, Type: BoolProperty)
    int32_t LogoutFrameDelay() const { return Read<int32_t>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x4, Type: IntProperty)
    TArray<FServiceLoginConfig> ServiceLoginConfig() const { return Read<TArray<FServiceLoginConfig>>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x10, Type: ArrayProperty)
    FString RedeemAccessUrl() const { return Read<FString>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x10, Type: StrProperty)
    FString RequestFreeAccessUrl() const { return Read<FString>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x10, Type: StrProperty)
    FString RealGameAccessUrl() const { return Read<FString>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x10, Type: StrProperty)
    float SkipRedeemOfflinePurchasesChance() const { return Read<float>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x4, Type: FloatProperty)
    bool bUseFreeAccessInsteadOfGameAccess() const { return Read<bool>(uintptr_t(this) + 0x234); } // 0x234 (Size: 0x1, Type: BoolProperty)
    bool bShouldGrantFreeAccess() const { return Read<bool>(uintptr_t(this) + 0x235); } // 0x235 (Size: 0x1, Type: BoolProperty)
    bool bAllowHomeSharingAccess() const { return Read<bool>(uintptr_t(this) + 0x237); } // 0x237 (Size: 0x1, Type: BoolProperty)
    bool bRequireUGCPrivilege() const { return Read<bool>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x1, Type: BoolProperty)
    float AccessGrantDelaySeconds() const { return Read<float>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x4, Type: FloatProperty)
    UWaitingRoomState* WaitingRoomState() const { return Read<UWaitingRoomState*>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    TArray<FOnlineAccountOperationStepConfig> LoginStepConfig() const { return Read<TArray<FOnlineAccountOperationStepConfig>>(uintptr_t(this) + 0xaf0); } // 0xaf0 (Size: 0x10, Type: ArrayProperty)
    TArray<FOnlineAccountOperationStepConfig> LogoutStepConfig() const { return Read<TArray<FOnlineAccountOperationStepConfig>>(uintptr_t(this) + 0xb00); } // 0xb00 (Size: 0x10, Type: ArrayProperty)
    TArray<FOnlineAccountOperationStepConfig> CreateAccountStepConfig() const { return Read<TArray<FOnlineAccountOperationStepConfig>>(uintptr_t(this) + 0xb10); } // 0xb10 (Size: 0x10, Type: ArrayProperty)

    void SET_AvailabilityServiceGameName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
    void SET_bRequireLightswitchAtStartup(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
    void SET_bPartialLoginEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x49, Value); } // 0x49 (Size: 0x1, Type: BoolProperty)
    void SET_bRedeemOfflinePurchasesEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4a, Value); } // 0x4a (Size: 0x1, Type: BoolProperty)
    void SET_bCheckingRejoinEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4b, Value); } // 0x4b (Size: 0x1, Type: BoolProperty)
    void SET_EULAKey(const FString& Value) { Write<FString>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: StrProperty)
    void SET_EulaKeys(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_EulaKeyMapping(const TMap<FString, FString>& Value) { Write<TMap<FString, FString>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x50, Type: MapProperty)
    void SET_bEnableWaitingRoom(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    void SET_WebCreateEpicAccountUrl(const TArray<FWebEnvUrl>& Value) { Write<TArray<FWebEnvUrl>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    void SET_bAllowLocalLogout(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x1, Type: BoolProperty)
    void SET_DefaultLoginStepTimeout(const float& Value) { Write<float>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x4, Type: FloatProperty)
    void SET_CustomLoginStepTimeouts(const TMap<float, FName>& Value) { Write<TMap<float, FName>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x50, Type: MapProperty)
    void SET_bEnableDevLoginStepTimeouts(const bool& Value) { Write<bool>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x1, Type: BoolProperty)
    void SET_DefaultLogoutStepTimeout(const float& Value) { Write<float>(uintptr_t(this) + 0x16c, Value); } // 0x16c (Size: 0x4, Type: FloatProperty)
    void SET_CustomLogoutStepTimeouts(const TMap<float, FName>& Value) { Write<TMap<float, FName>>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x50, Type: MapProperty)
    void SET_bEnableDevLogoutStepTimeouts(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x1, Type: BoolProperty)
    void SET_LogoutFrameDelay(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x4, Type: IntProperty)
    void SET_ServiceLoginConfig(const TArray<FServiceLoginConfig>& Value) { Write<TArray<FServiceLoginConfig>>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x10, Type: ArrayProperty)
    void SET_RedeemAccessUrl(const FString& Value) { Write<FString>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x10, Type: StrProperty)
    void SET_RequestFreeAccessUrl(const FString& Value) { Write<FString>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x10, Type: StrProperty)
    void SET_RealGameAccessUrl(const FString& Value) { Write<FString>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x10, Type: StrProperty)
    void SET_SkipRedeemOfflinePurchasesChance(const float& Value) { Write<float>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x4, Type: FloatProperty)
    void SET_bUseFreeAccessInsteadOfGameAccess(const bool& Value) { Write<bool>(uintptr_t(this) + 0x234, Value); } // 0x234 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldGrantFreeAccess(const bool& Value) { Write<bool>(uintptr_t(this) + 0x235, Value); } // 0x235 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowHomeSharingAccess(const bool& Value) { Write<bool>(uintptr_t(this) + 0x237, Value); } // 0x237 (Size: 0x1, Type: BoolProperty)
    void SET_bRequireUGCPrivilege(const bool& Value) { Write<bool>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x1, Type: BoolProperty)
    void SET_AccessGrantDelaySeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x4, Type: FloatProperty)
    void SET_WaitingRoomState(const UWaitingRoomState*& Value) { Write<UWaitingRoomState*>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    void SET_LoginStepConfig(const TArray<FOnlineAccountOperationStepConfig>& Value) { Write<TArray<FOnlineAccountOperationStepConfig>>(uintptr_t(this) + 0xaf0, Value); } // 0xaf0 (Size: 0x10, Type: ArrayProperty)
    void SET_LogoutStepConfig(const TArray<FOnlineAccountOperationStepConfig>& Value) { Write<TArray<FOnlineAccountOperationStepConfig>>(uintptr_t(this) + 0xb00, Value); } // 0xb00 (Size: 0x10, Type: ArrayProperty)
    void SET_CreateAccountStepConfig(const TArray<FOnlineAccountOperationStepConfig>& Value) { Write<TArray<FOnlineAccountOperationStepConfig>>(uintptr_t(this) + 0xb10, Value); } // 0xb10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x88
class UWaitingRoomState : public UObject
{
public:
    int32_t GracePeriodMins() const { return Read<int32_t>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: IntProperty)

    void SET_GracePeriodMins(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: IntProperty)
};

// Size: 0x30
struct FWebEnvUrl
{
public:
    FString URL() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString RedirectUrl() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FString Environment() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)

    void SET_URL(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_RedirectUrl(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_Environment(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
};

// Size: 0x8
struct FExternalAccountServiceConfig
{
public:
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FName ExternalServiceName() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)

    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_ExternalServiceName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x40
struct FExchangeAccessParams
{
public:
    FString EntitlementId() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString ReceiptId() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FString VendorReceipt() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)
    FString AppStore() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)

    void SET_EntitlementId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_ReceiptId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_VendorReceipt(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
    void SET_AppStore(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
};

// Size: 0x30
struct FGiftMessage
{
public:
    FString GiftCode() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString SenderName() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_GiftCode(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_SenderName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0xc
struct FServiceLoginConfig
{
public:
    FName LoginType() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName ExternalAuthMethod() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)

    void SET_LoginType(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_ExternalAuthMethod(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x18
struct FOnlineAccountOperationStepConfig
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    TArray<FName> Dependencies() const { return Read<TArray<FName>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Dependencies(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xf0
struct FOnlineAccountTexts_FailedLoginConsole
{
public:
    FText AgeRestriction() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    FText Generic() const { return Read<FText>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: TextProperty)
    FText MissingAuthAssociation() const { return Read<FText>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: TextProperty)
    FText NeedPremiumAccount() const { return Read<FText>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: TextProperty)
    FText OnlinePlayRestriction() const { return Read<FText>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: TextProperty)
    FText PatchAvailable() const { return Read<FText>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: TextProperty)
    FText PatchAvailableInstruction_Default() const { return Read<FText>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: TextProperty)
    FText PatchAvailableInstruction_Xbox() const { return Read<FText>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: TextProperty)
    FText PleaseSignIn() const { return Read<FText>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: TextProperty)
    FText SystemUpdateAvailable() const { return Read<FText>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: TextProperty)
    FText UI() const { return Read<FText>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: TextProperty)
    FText UnableToComplete() const { return Read<FText>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: TextProperty)
    FText UnableToSignIn() const { return Read<FText>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: TextProperty)
    FText UnableToStartPrivCheck() const { return Read<FText>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: TextProperty)
    FText UnexpectedError() const { return Read<FText>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: TextProperty)

    void SET_AgeRestriction(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_Generic(const FText& Value) { Write<FText>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: TextProperty)
    void SET_MissingAuthAssociation(const FText& Value) { Write<FText>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: TextProperty)
    void SET_NeedPremiumAccount(const FText& Value) { Write<FText>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: TextProperty)
    void SET_OnlinePlayRestriction(const FText& Value) { Write<FText>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: TextProperty)
    void SET_PatchAvailable(const FText& Value) { Write<FText>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: TextProperty)
    void SET_PatchAvailableInstruction_Default(const FText& Value) { Write<FText>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: TextProperty)
    void SET_PatchAvailableInstruction_Xbox(const FText& Value) { Write<FText>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: TextProperty)
    void SET_PleaseSignIn(const FText& Value) { Write<FText>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: TextProperty)
    void SET_SystemUpdateAvailable(const FText& Value) { Write<FText>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: TextProperty)
    void SET_UI(const FText& Value) { Write<FText>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: TextProperty)
    void SET_UnableToComplete(const FText& Value) { Write<FText>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: TextProperty)
    void SET_UnableToSignIn(const FText& Value) { Write<FText>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: TextProperty)
    void SET_UnableToStartPrivCheck(const FText& Value) { Write<FText>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: TextProperty)
    void SET_UnexpectedError(const FText& Value) { Write<FText>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: TextProperty)
};

// Size: 0x670
struct FOnlineAccountTexts
{
public:
    FText AllGiftCodesUsed() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    FText AssociateConsoleAuth() const { return Read<FText>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: TextProperty)
    FText AutoLoginFailed() const { return Read<FText>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: TextProperty)
    FText AutoLoginFailedMobile() const { return Read<FText>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: TextProperty)
    FText BannedFromGame() const { return Read<FText>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: TextProperty)
    FText CheckEntitledToPlay() const { return Read<FText>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: TextProperty)
    FText CheckingRejoin() const { return Read<FText>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: TextProperty)
    FText CheckServiceAvailability() const { return Read<FText>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: TextProperty)
    FText ConsolePrivileges() const { return Read<FText>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: TextProperty)
    FText CreateAccountCompleted() const { return Read<FText>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: TextProperty)
    FText CreateAccountFailure() const { return Read<FText>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: TextProperty)
    FText CreateAccountStepTimeout() const { return Read<FText>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: TextProperty)
    FText CreateHeadless() const { return Read<FText>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: TextProperty)
    FText DoQosPingTests() const { return Read<FText>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: TextProperty)
    FText DowntimeMinutesWarningText() const { return Read<FText>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: TextProperty)
    FText DowntimeSecondsWarningText() const { return Read<FText>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: TextProperty)
    FText DuplicateAuthAssociaton() const { return Read<FText>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: TextProperty)
    FText EulaCheck() const { return Read<FText>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: TextProperty)
    FText ExchangeConsoleGiftsForAccess() const { return Read<FText>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x10, Type: TextProperty)
    FText FailedAccountCreate() const { return Read<FText>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x10, Type: TextProperty)
    FText FailedEulaCheck_EulaAcceptanceFailed() const { return Read<FText>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x10, Type: TextProperty)
    FText FailedEulaCheck_MustAcceptEula() const { return Read<FText>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x10, Type: TextProperty)
    FText FailedLoginCredentialsMsg() const { return Read<FText>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x10, Type: TextProperty)
    FText FailedLoginAgeVerificationIncomplete() const { return Read<FText>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x10, Type: TextProperty)
    FText FailedLoginParentalLock() const { return Read<FText>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x10, Type: TextProperty)
    FText FailedLoginNoRealId() const { return Read<FText>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x10, Type: TextProperty)
    FText FailedLoginLockoutMsg() const { return Read<FText>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x10, Type: TextProperty)
    FText FailedLoginRequiresMFA() const { return Read<FText>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x10, Type: TextProperty)
    FText FailedLoginRequiresAuthAppMFA() const { return Read<FText>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x10, Type: TextProperty)
    FText FailedInvalidMFA() const { return Read<FText>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x10, Type: TextProperty)
    FText FailedLoginRequiresCorrectiveAction() const { return Read<FText>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x10, Type: TextProperty)
    FText FailedLoginMsg() const { return Read<FText>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x10, Type: TextProperty)
    FText FailedLoginMsg_InvalidRefreshToken() const { return Read<FText>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x10, Type: TextProperty)
    FText FailedStartLogin() const { return Read<FText>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x10, Type: TextProperty)
    FText FounderChatExitedText() const { return Read<FText>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x10, Type: TextProperty)
    FText FounderChatJoinedText() const { return Read<FText>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x10, Type: TextProperty)
    FText GameDisplayName() const { return Read<FText>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x10, Type: TextProperty)
    FText GeneralLoginFailure() const { return Read<FText>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x10, Type: TextProperty)
    FText GlobalChatExitedText() const { return Read<FText>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x10, Type: TextProperty)
    FText GlobalChatJoinedText() const { return Read<FText>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x10, Type: TextProperty)
    FText HeadlessAccountFailed() const { return Read<FText>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: TextProperty)
    FText InMatchShutdownTimeWarningText() const { return Read<FText>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x10, Type: TextProperty)
    FText InvalidUser() const { return Read<FText>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x10, Type: TextProperty)
    FText LoggedOutofMCP() const { return Read<FText>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x10, Type: TextProperty)
    FText DisconnectedFromMCP() const { return Read<FText>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x10, Type: TextProperty)
    FText LoggedOutReturnedToTitle() const { return Read<FText>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x10, Type: TextProperty)
    FText LoggedOutSwitchedProfile() const { return Read<FText>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x10, Type: TextProperty)
    FText LoggingIn() const { return Read<FText>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x10, Type: TextProperty)
    FText LoggingInConsoleAuth() const { return Read<FText>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x10, Type: TextProperty)
    FText LoggingOut() const { return Read<FText>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x10, Type: TextProperty)
    FText LoginConsole() const { return Read<FText>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x10, Type: TextProperty)
    FText LoginFailure() const { return Read<FText>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x10, Type: TextProperty)
    FText Logout_Unlink() const { return Read<FText>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x10, Type: TextProperty)
    FText LogoutCompleted() const { return Read<FText>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x10, Type: TextProperty)
    FText LostConnection() const { return Read<FText>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x10, Type: TextProperty)
    FText LoginStepTimeout() const { return Read<FText>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x10, Type: TextProperty)
    FText MCPTimeout() const { return Read<FText>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x10, Type: TextProperty)
    FText LightswitchCheckNetworkFailureMsg() const { return Read<FText>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x10, Type: TextProperty)
    FText NetworkConnectionUnavailable() const { return Read<FText>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x10, Type: TextProperty)
    FText NoPlayEntitlement() const { return Read<FText>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x10, Type: TextProperty)
    FText NoServerAccess() const { return Read<FText>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x10, Type: TextProperty)
    FText PlayAccessRevoked() const { return Read<FText>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x10, Type: TextProperty)
    FText PremiumAccountName_Default() const { return Read<FText>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x10, Type: TextProperty)
    FText PremiumAccountName_Sony() const { return Read<FText>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x10, Type: TextProperty)
    FText PremiumAccountName_Nintendo() const { return Read<FText>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x10, Type: TextProperty)
    FText PremiumAccountName_XboxOne() const { return Read<FText>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x10, Type: TextProperty)
    FText RedeemOfflinePurchases() const { return Read<FText>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x10, Type: TextProperty)
    FText ServiceDowntime() const { return Read<FText>(uintptr_t(this) + 0x430); } // 0x430 (Size: 0x10, Type: TextProperty)
    FText SignInCompleting() const { return Read<FText>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x10, Type: TextProperty)
    FText SignIntoConsoleServices() const { return Read<FText>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x10, Type: TextProperty)
    FText TokenExpired() const { return Read<FText>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x10, Type: TextProperty)
    FText UnableToConnect() const { return Read<FText>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x10, Type: TextProperty)
    FText UnableToJoinWaitingRoomLoginQueue() const { return Read<FText>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x10, Type: TextProperty)
    FText UnexpectedConsoleAuthFailure() const { return Read<FText>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x10, Type: TextProperty)
    FText UnlinkConsoleFailed() const { return Read<FText>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x10, Type: TextProperty)
    FText UserLoginFailed() const { return Read<FText>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x10, Type: TextProperty)
    FText WaitingRoom() const { return Read<FText>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x10, Type: TextProperty)
    FText WaitingRoomError() const { return Read<FText>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x10, Type: TextProperty)
    FText WaitingRoomFailure() const { return Read<FText>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x10, Type: TextProperty)
    FText WaitingRoomWaiting() const { return Read<FText>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x10, Type: TextProperty)
    FOnlineAccountTexts_FailedLoginConsole FailedLoginConsole() const { return Read<FOnlineAccountTexts_FailedLoginConsole>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0xf0, Type: StructProperty)
    FText LoggingInExternalAuth() const { return Read<FText>(uintptr_t(this) + 0x5f0); } // 0x5f0 (Size: 0x10, Type: TextProperty)
    FText CreateDeviceAuth() const { return Read<FText>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x10, Type: TextProperty)
    FText ExtAuthCanceled() const { return Read<FText>(uintptr_t(this) + 0x610); } // 0x610 (Size: 0x10, Type: TextProperty)
    FText ExtAuthFailure() const { return Read<FText>(uintptr_t(this) + 0x620); } // 0x620 (Size: 0x10, Type: TextProperty)
    FText ExtAuthAssociationFailure() const { return Read<FText>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0x10, Type: TextProperty)
    FText ExtAuthTimeout() const { return Read<FText>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0x10, Type: TextProperty)
    FText ExtAuthMissingAuthAssociation() const { return Read<FText>(uintptr_t(this) + 0x650); } // 0x650 (Size: 0x10, Type: TextProperty)
    FText UnableToQueryReceipts() const { return Read<FText>(uintptr_t(this) + 0x660); } // 0x660 (Size: 0x10, Type: TextProperty)

    void SET_AllGiftCodesUsed(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_AssociateConsoleAuth(const FText& Value) { Write<FText>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: TextProperty)
    void SET_AutoLoginFailed(const FText& Value) { Write<FText>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: TextProperty)
    void SET_AutoLoginFailedMobile(const FText& Value) { Write<FText>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: TextProperty)
    void SET_BannedFromGame(const FText& Value) { Write<FText>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: TextProperty)
    void SET_CheckEntitledToPlay(const FText& Value) { Write<FText>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: TextProperty)
    void SET_CheckingRejoin(const FText& Value) { Write<FText>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: TextProperty)
    void SET_CheckServiceAvailability(const FText& Value) { Write<FText>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: TextProperty)
    void SET_ConsolePrivileges(const FText& Value) { Write<FText>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: TextProperty)
    void SET_CreateAccountCompleted(const FText& Value) { Write<FText>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: TextProperty)
    void SET_CreateAccountFailure(const FText& Value) { Write<FText>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: TextProperty)
    void SET_CreateAccountStepTimeout(const FText& Value) { Write<FText>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: TextProperty)
    void SET_CreateHeadless(const FText& Value) { Write<FText>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: TextProperty)
    void SET_DoQosPingTests(const FText& Value) { Write<FText>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: TextProperty)
    void SET_DowntimeMinutesWarningText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: TextProperty)
    void SET_DowntimeSecondsWarningText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: TextProperty)
    void SET_DuplicateAuthAssociaton(const FText& Value) { Write<FText>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: TextProperty)
    void SET_EulaCheck(const FText& Value) { Write<FText>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: TextProperty)
    void SET_ExchangeConsoleGiftsForAccess(const FText& Value) { Write<FText>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x10, Type: TextProperty)
    void SET_FailedAccountCreate(const FText& Value) { Write<FText>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x10, Type: TextProperty)
    void SET_FailedEulaCheck_EulaAcceptanceFailed(const FText& Value) { Write<FText>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x10, Type: TextProperty)
    void SET_FailedEulaCheck_MustAcceptEula(const FText& Value) { Write<FText>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x10, Type: TextProperty)
    void SET_FailedLoginCredentialsMsg(const FText& Value) { Write<FText>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x10, Type: TextProperty)
    void SET_FailedLoginAgeVerificationIncomplete(const FText& Value) { Write<FText>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x10, Type: TextProperty)
    void SET_FailedLoginParentalLock(const FText& Value) { Write<FText>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x10, Type: TextProperty)
    void SET_FailedLoginNoRealId(const FText& Value) { Write<FText>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x10, Type: TextProperty)
    void SET_FailedLoginLockoutMsg(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x10, Type: TextProperty)
    void SET_FailedLoginRequiresMFA(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x10, Type: TextProperty)
    void SET_FailedLoginRequiresAuthAppMFA(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x10, Type: TextProperty)
    void SET_FailedInvalidMFA(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x10, Type: TextProperty)
    void SET_FailedLoginRequiresCorrectiveAction(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x10, Type: TextProperty)
    void SET_FailedLoginMsg(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x10, Type: TextProperty)
    void SET_FailedLoginMsg_InvalidRefreshToken(const FText& Value) { Write<FText>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x10, Type: TextProperty)
    void SET_FailedStartLogin(const FText& Value) { Write<FText>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x10, Type: TextProperty)
    void SET_FounderChatExitedText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x10, Type: TextProperty)
    void SET_FounderChatJoinedText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x10, Type: TextProperty)
    void SET_GameDisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x10, Type: TextProperty)
    void SET_GeneralLoginFailure(const FText& Value) { Write<FText>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x10, Type: TextProperty)
    void SET_GlobalChatExitedText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x10, Type: TextProperty)
    void SET_GlobalChatJoinedText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x10, Type: TextProperty)
    void SET_HeadlessAccountFailed(const FText& Value) { Write<FText>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: TextProperty)
    void SET_InMatchShutdownTimeWarningText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x10, Type: TextProperty)
    void SET_InvalidUser(const FText& Value) { Write<FText>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x10, Type: TextProperty)
    void SET_LoggedOutofMCP(const FText& Value) { Write<FText>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x10, Type: TextProperty)
    void SET_DisconnectedFromMCP(const FText& Value) { Write<FText>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x10, Type: TextProperty)
    void SET_LoggedOutReturnedToTitle(const FText& Value) { Write<FText>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x10, Type: TextProperty)
    void SET_LoggedOutSwitchedProfile(const FText& Value) { Write<FText>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x10, Type: TextProperty)
    void SET_LoggingIn(const FText& Value) { Write<FText>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x10, Type: TextProperty)
    void SET_LoggingInConsoleAuth(const FText& Value) { Write<FText>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x10, Type: TextProperty)
    void SET_LoggingOut(const FText& Value) { Write<FText>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x10, Type: TextProperty)
    void SET_LoginConsole(const FText& Value) { Write<FText>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x10, Type: TextProperty)
    void SET_LoginFailure(const FText& Value) { Write<FText>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x10, Type: TextProperty)
    void SET_Logout_Unlink(const FText& Value) { Write<FText>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x10, Type: TextProperty)
    void SET_LogoutCompleted(const FText& Value) { Write<FText>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x10, Type: TextProperty)
    void SET_LostConnection(const FText& Value) { Write<FText>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x10, Type: TextProperty)
    void SET_LoginStepTimeout(const FText& Value) { Write<FText>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x10, Type: TextProperty)
    void SET_MCPTimeout(const FText& Value) { Write<FText>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x10, Type: TextProperty)
    void SET_LightswitchCheckNetworkFailureMsg(const FText& Value) { Write<FText>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x10, Type: TextProperty)
    void SET_NetworkConnectionUnavailable(const FText& Value) { Write<FText>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x10, Type: TextProperty)
    void SET_NoPlayEntitlement(const FText& Value) { Write<FText>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x10, Type: TextProperty)
    void SET_NoServerAccess(const FText& Value) { Write<FText>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x10, Type: TextProperty)
    void SET_PlayAccessRevoked(const FText& Value) { Write<FText>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x10, Type: TextProperty)
    void SET_PremiumAccountName_Default(const FText& Value) { Write<FText>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x10, Type: TextProperty)
    void SET_PremiumAccountName_Sony(const FText& Value) { Write<FText>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x10, Type: TextProperty)
    void SET_PremiumAccountName_Nintendo(const FText& Value) { Write<FText>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x10, Type: TextProperty)
    void SET_PremiumAccountName_XboxOne(const FText& Value) { Write<FText>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x10, Type: TextProperty)
    void SET_RedeemOfflinePurchases(const FText& Value) { Write<FText>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x10, Type: TextProperty)
    void SET_ServiceDowntime(const FText& Value) { Write<FText>(uintptr_t(this) + 0x430, Value); } // 0x430 (Size: 0x10, Type: TextProperty)
    void SET_SignInCompleting(const FText& Value) { Write<FText>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x10, Type: TextProperty)
    void SET_SignIntoConsoleServices(const FText& Value) { Write<FText>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x10, Type: TextProperty)
    void SET_TokenExpired(const FText& Value) { Write<FText>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x10, Type: TextProperty)
    void SET_UnableToConnect(const FText& Value) { Write<FText>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x10, Type: TextProperty)
    void SET_UnableToJoinWaitingRoomLoginQueue(const FText& Value) { Write<FText>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x10, Type: TextProperty)
    void SET_UnexpectedConsoleAuthFailure(const FText& Value) { Write<FText>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x10, Type: TextProperty)
    void SET_UnlinkConsoleFailed(const FText& Value) { Write<FText>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x10, Type: TextProperty)
    void SET_UserLoginFailed(const FText& Value) { Write<FText>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x10, Type: TextProperty)
    void SET_WaitingRoom(const FText& Value) { Write<FText>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x10, Type: TextProperty)
    void SET_WaitingRoomError(const FText& Value) { Write<FText>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x10, Type: TextProperty)
    void SET_WaitingRoomFailure(const FText& Value) { Write<FText>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x10, Type: TextProperty)
    void SET_WaitingRoomWaiting(const FText& Value) { Write<FText>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x10, Type: TextProperty)
    void SET_FailedLoginConsole(const FOnlineAccountTexts_FailedLoginConsole& Value) { Write<FOnlineAccountTexts_FailedLoginConsole>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0xf0, Type: StructProperty)
    void SET_LoggingInExternalAuth(const FText& Value) { Write<FText>(uintptr_t(this) + 0x5f0, Value); } // 0x5f0 (Size: 0x10, Type: TextProperty)
    void SET_CreateDeviceAuth(const FText& Value) { Write<FText>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x10, Type: TextProperty)
    void SET_ExtAuthCanceled(const FText& Value) { Write<FText>(uintptr_t(this) + 0x610, Value); } // 0x610 (Size: 0x10, Type: TextProperty)
    void SET_ExtAuthFailure(const FText& Value) { Write<FText>(uintptr_t(this) + 0x620, Value); } // 0x620 (Size: 0x10, Type: TextProperty)
    void SET_ExtAuthAssociationFailure(const FText& Value) { Write<FText>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0x10, Type: TextProperty)
    void SET_ExtAuthTimeout(const FText& Value) { Write<FText>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0x10, Type: TextProperty)
    void SET_ExtAuthMissingAuthAssociation(const FText& Value) { Write<FText>(uintptr_t(this) + 0x650, Value); } // 0x650 (Size: 0x10, Type: TextProperty)
    void SET_UnableToQueryReceipts(const FText& Value) { Write<FText>(uintptr_t(this) + 0x660, Value); } // 0x660 (Size: 0x10, Type: TextProperty)
};

