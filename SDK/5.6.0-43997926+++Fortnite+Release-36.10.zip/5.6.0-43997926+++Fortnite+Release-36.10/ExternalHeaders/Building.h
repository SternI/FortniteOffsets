/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Building
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "FortniteGame.h"
#include "GameplayAbilities.h"
#include "CoreUObject.h"
#include "Niagara.h"

// Size: 0xd80
class APBWA_BG_QuarterWallS_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_BG_QuarterWallHalf_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_BG_HalfWallDoorS_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_BG_HalfWallDoor_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_BG_HalfWall_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_BG_DoorSide_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_BG_DoorS_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_BG_DoorC_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_BG_Brace_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_BG_RoofO_C : public ABuildingRoof
{
public:
};

// Size: 0x80
class UNavLink_Floor_C : public UFortNavLinkDefinition
{
public:
};

// Size: 0xd80
class APBWA_M1_WindowSide_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_M1_Windows_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_M1_BalconyS_C : public ABuildingFloor
{
public:
};

// Size: 0x80
class UNavLink_RoofC_C : public UFortNavLinkDefinition
{
public:
};

// Size: 0x58
class UFortMetaNavAreaDef_C : public UFortMetaNavArea
{
public:
};

// Size: 0xd98
class APBW_BP_Parent_C : public ABuildingWall
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xd80); } // 0xd80 (Size: 0x8, Type: StructProperty)
    TArray<UStaticMesh*> StaticMeshAlternateArray() const { return Read<TArray<UStaticMesh*>>(uintptr_t(this) + 0xd88); } // 0xd88 (Size: 0x10, Type: ArrayProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xd80, Value); } // 0xd80 (Size: 0x8, Type: StructProperty)
    void SET_StaticMeshAlternateArray(const TArray<UStaticMesh*>& Value) { Write<TArray<UStaticMesh*>>(uintptr_t(this) + 0xd88, Value); } // 0xd88 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xd80
class APBWA_BG_RoofWall_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_BG_Solid_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_M1_Solid_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_S1_RoofO_C : public ABuildingRoof
{
public:
};

// Size: 0xd80
class APBWA_S1_QuarterWallHalf_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_S1_Pillar_C : public ABuildingPillar
{
public:
};

// Size: 0xd80
class APBWA_S1_HalfWallHalf_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_S1_HalfWallDoorSide_C : public ABuildingWall
{
public:
};

// Size: 0xbd8
class APBWA_W1_StairW_C : public ABuildingStairs
{
public:
};

// Size: 0xd80
class APBWA_S1_HalfWallDoor_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_S1_DoorSide_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_S1_DoorS_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_S1_DoorC_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_S1_ArchwayLarge_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_S1_ArchwayLargeSupport_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_S1_RoofD_C : public ABuildingRoof
{
public:
};

// Size: 0xbd0
class APBWA_W1_Floor_C : public ABuildingFloor
{
public:
};

// Size: 0xd80
class APBWA_W1_Solid_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_W1_WindowC_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_W1_RoofC_C : public ABuildingRoof
{
public:
};

// Size: 0xbd0
class APBWA_S1_Floor_C : public ABuildingFloor
{
public:
};

// Size: 0xbd0
class APBWA_S1_RoofI_C : public ABuildingRoof
{
public:
};

// Size: 0xd80
class APBWA_BG_WindowC_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_S1_HalfWallS_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_S1_WindowsSide_C : public ABuildingWall
{
public:
};

// Size: 0xbd8
class APBWA_S1_StairF_C : public ABuildingStairs
{
public:
};

// Size: 0xbd0
class APBWA_S1_RoofS_C : public ABuildingRoof
{
public:
};

// Size: 0xbd0
class APBWA_S1_BalconyO_C : public ABuildingFloor
{
public:
};

// Size: 0xd80
class APBWA_S1_QuarterWallS_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_S1_Archway_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_S1_BalconyI_C : public ABuildingFloor
{
public:
};

// Size: 0xd80
class APBWA_S1_Windows_C : public ABuildingWall
{
public:
};

// Size: 0xbd8
class APBWA_S1_StairT_C : public ABuildingStairs
{
public:
};

// Size: 0xbd8
class APBWA_S1_StairR_C : public ABuildingStairs
{
public:
};

// Size: 0xd80
class APBWA_S1_RoofWall_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_W1_RoofS_C : public ABuildingRoof
{
public:
};

// Size: 0xbd0
class APBWA_W1_RoofO_C : public ABuildingRoof
{
public:
};

// Size: 0xbd8
class APBWA_W1_StairF_C : public ABuildingStairs
{
public:
};

// Size: 0xd80
class APBWA_W1_RoofWall_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_W1_BalconyO_C : public ABuildingFloor
{
public:
};

// Size: 0xd80
class APBWA_W1_DoorSide_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_W1_HalfWallS_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_W1_Windows_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_W1_QuarterWallS_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_W1_RoofD_C : public ABuildingRoof
{
public:
};

// Size: 0xbd8
class APBWA_W1_StairT_C : public ABuildingStairs
{
public:
};

// Size: 0xd80
class APBWA_W1_WindowSide_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_W1_ArchwayLargeSupport_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_W1_DoorC_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_W1_Brace_C : public ABuildingWall
{
public:
};

// Size: 0xbd8
class APBWA_W1_StairSpiral_C : public ABuildingStairs
{
public:
};

// Size: 0xd80
class APBWA_W1_Archway_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_W1_ArchwayLarge_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_W1_BalconyD_C : public ABuildingFloor
{
public:
};

// Size: 0xbd0
class APBWA_W1_BalconyI_C : public ABuildingFloor
{
public:
};

// Size: 0xbd0
class APBWA_W1_BalconyS_C : public ABuildingFloor
{
public:
};

// Size: 0xd80
class APBWA_W1_DoorS_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_W1_HalfWallDoor_C : public ABuildingWall
{
public:
};

// Size: 0xbd8
class APBWA_W1_StairR_C : public ABuildingStairs
{
public:
};

// Size: 0xd80
class APBWA_W1_HalfWallDoorS_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_W1_HalfWallHalf_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_W1_Pillar_C : public ABuildingPillar
{
public:
};

// Size: 0xd80
class APBWA_W1_QuarterWallHalf_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_W1_RoofI_C : public ABuildingRoof
{
public:
};

// Size: 0xd80
class APBWA_BG_HalfWallHalf_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_M1_RoofO_C : public ABuildingRoof
{
public:
};

// Size: 0xd80
class APBWA_M1_RoofWall_C : public ABuildingWall
{
public:
};

// Size: 0xbd8
class APBWA_M1_StairF_C : public ABuildingStairs
{
public:
};

// Size: 0xbd8
class APBWA_M1_StairT_C : public ABuildingStairs
{
public:
};

// Size: 0x220
class UDoorSoundIndicatorComponent_C : public UFortSoundIndicatorComponent
{
public:
};

// Size: 0xd80
class APBWA_M1_Brace_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_M1_RoofC_C : public ABuildingRoof
{
public:
};

// Size: 0xbd0
class APBWA_M1_Floor_C : public ABuildingFloor
{
public:
};

// Size: 0xbd0
class APBWA_M1_BalconyO_C : public ABuildingFloor
{
public:
};

// Size: 0xbd0
class APBWA_M1_BalconyD_C : public ABuildingFloor
{
public:
};

// Size: 0xd80
class APBWA_M1_DoorS_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_M1_HalfWall_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_M1_Pillar_C : public ABuildingPillar
{
public:
};

// Size: 0xd80
class APBWA_M1_HalfWallDoor_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_BG_WindowSide_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_M1_QuarterWallHalf_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_BG_ArchwayLarge_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_BG_Archway_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_BG_ArchwayLargeSupport_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_BG_RoofS_C : public ABuildingRoof
{
public:
};

// Size: 0xd80
class APBWA_M1_DoorC_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_BG_BalconyI_C : public ABuildingFloor
{
public:
};

// Size: 0xd80
class APBWA_M1_QuarterWallS_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_M1_RoofD_C : public ABuildingRoof
{
public:
};

// Size: 0xd80
class APBWA_BG_Windows_C : public ABuildingWall
{
public:
};

// Size: 0xbd8
class APBWA_BG_StairW_C : public ABuildingStairs
{
public:
};

// Size: 0xbd8
class APBWA_BG_StairT_C : public ABuildingStairs
{
public:
};

// Size: 0xbd0
class APBWA_M1_RoofI_C : public ABuildingRoof
{
public:
};

// Size: 0xd80
class APBWA_M1_HalfWallDoorS_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_BG_RoofD_C : public ABuildingRoof
{
public:
};

// Size: 0xd80
class APBWA_M1_ArchwayLarge_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_M1_RoofS_C : public ABuildingRoof
{
public:
};

// Size: 0xbd8
class APBWA_M1_StairR_C : public ABuildingStairs
{
public:
};

// Size: 0xbd0
class APBWA_M1_BalconyI_C : public ABuildingFloor
{
public:
};

// Size: 0xc8
class UDoorMetaObstacle_C : public UNavAreaMeta_SwitchByAgent
{
public:
};

// Size: 0xd80
class APBWA_M1_HalfWallHalf_C : public ABuildingWall
{
public:
};

// Size: 0xbd8
class APBWA_M1_StairW_C : public ABuildingStairs
{
public:
};

// Size: 0xd80
class APBWA_M1_WindowC_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_M1_ArchwayLargeSupport_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_S1_BalconyS_C : public ABuildingFloor
{
public:
};

// Size: 0xbd0
class APBWA_S1_BalconyD_C : public ABuildingFloor
{
public:
};

// Size: 0xbd8
class APBWA_S1_StairW_C : public ABuildingStairs
{
public:
};

// Size: 0xd80
class APBWA_S1_WindowsC_C : public ABuildingWall
{
public:
};

// Size: 0xda8
class APBWA_S1_Solid_C : public ABuildingWall
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xd80); } // 0xd80 (Size: 0x8, Type: StructProperty)
    int32_t GnomeWallChance() const { return Read<int32_t>(uintptr_t(this) + 0xd88); } // 0xd88 (Size: 0x4, Type: IntProperty)
    int32_t GnomeWallMax() const { return Read<int32_t>(uintptr_t(this) + 0xd8c); } // 0xd8c (Size: 0x4, Type: IntProperty)
    bool Gnomed() const { return Read<bool>(uintptr_t(this) + 0xd90); } // 0xd90 (Size: 0x1, Type: BoolProperty)
    UMaterialInstanceConstant* GnomeMaterial() const { return Read<UMaterialInstanceConstant*>(uintptr_t(this) + 0xd98); } // 0xd98 (Size: 0x8, Type: ObjectProperty)
    UStaticMesh* GnomeWall() const { return Read<UStaticMesh*>(uintptr_t(this) + 0xda0); } // 0xda0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xd80, Value); } // 0xd80 (Size: 0x8, Type: StructProperty)
    void SET_GnomeWallChance(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd88, Value); } // 0xd88 (Size: 0x4, Type: IntProperty)
    void SET_GnomeWallMax(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd8c, Value); } // 0xd8c (Size: 0x4, Type: IntProperty)
    void SET_Gnomed(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd90, Value); } // 0xd90 (Size: 0x1, Type: BoolProperty)
    void SET_GnomeMaterial(const UMaterialInstanceConstant*& Value) { Write<UMaterialInstanceConstant*>(uintptr_t(this) + 0xd98, Value); } // 0xd98 (Size: 0x8, Type: ObjectProperty)
    void SET_GnomeWall(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0xda0, Value); } // 0xda0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xbd0
class APBWA_S1_RoofC_C : public ABuildingRoof
{
public:
};

// Size: 0xd80
class APBWA_S1_Brace_C : public ABuildingWall
{
public:
};

// Size: 0xbd0
class APBWA_BG_Floor_C : public ABuildingFloor
{
public:
};

// Size: 0xbd0
class APBWA_BG_RoofC_C : public ABuildingRoof
{
public:
};

// Size: 0xbd0
class APBWA_BG_BalconyD_C : public ABuildingFloor
{
public:
};

// Size: 0xbd0
class APBWA_BG_BalconyO_C : public ABuildingFloor
{
public:
};

// Size: 0xbd8
class APBWA_BG_StairF_C : public ABuildingStairs
{
public:
};

// Size: 0xbd0
class APBWA_BG_RoofI_C : public ABuildingRoof
{
public:
};

// Size: 0xbd0
class APBWA_BG_BalconyS_C : public ABuildingFloor
{
public:
};

// Size: 0xbd8
class APBWA_BG_StairR_C : public ABuildingStairs
{
public:
};

// Size: 0xd80
class APBWA_M1_DoorSide_C : public ABuildingWall
{
public:
};

// Size: 0xd80
class APBWA_M1_Archway_C : public ABuildingWall
{
public:
};

// Size: 0x10
struct FDayPhaseFloats
{
public:
    float Morning_2_DA7D290F4DA80AC0D79B888F8B1E63AF() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Day_6_7AC9422D4E5DA1F7855ECF8DF66BAFB1() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Evening_7_A7E95DF64346D1824EB55E8083A4525F() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float Night_8_BD65E285445A3ED05CA26694CF4E873E() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_Morning_2_DA7D290F4DA80AC0D79B888F8B1E63AF(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Day_6_7AC9422D4E5DA1F7855ECF8DF66BAFB1(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Evening_7_A7E95DF64346D1824EB55E8083A4525F(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Night_8_BD65E285445A3ED05CA26694CF4E873E(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0xd80
class AParent_BuildingWall_C : public ABuildingWall
{
public:
};

// Size: 0xf54
class ACreative_Tiered_Chest_C : public ABuildingCustomizableSpawnContainer
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xe78); } // 0xe78 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* S_Chest_SmokeSheet() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0xe80); } // 0xe80 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* NS_Athena_Loot_Chest_Aura() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0xe88); } // 0xe88 (Size: 0x8, Type: ObjectProperty)
    UCreativeIslandResourceComponent* CreativeIslandResource() const { return Read<UCreativeIslandResourceComponent*>(uintptr_t(this) + 0xe90); } // 0xe90 (Size: 0x8, Type: ObjectProperty)
    UPointLightComponent* TrasureLight() const { return Read<UPointLightComponent*>(uintptr_t(this) + 0xe98); } // 0xe98 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* Chest_Ambient_Sound() const { return Read<UAudioComponent*>(uintptr_t(this) + 0xea0); } // 0xea0 (Size: 0x8, Type: ObjectProperty)
    float MobileSelectedTL_LerpInteactoIcon_3B3245644A941BB300D1A3B017FAF4AC() const { return Read<float>(uintptr_t(this) + 0xea8); } // 0xea8 (Size: 0x4, Type: FloatProperty)
    float MobileSelectedTL_LerpObject_3B3245644A941BB300D1A3B017FAF4AC() const { return Read<float>(uintptr_t(this) + 0xeac); } // 0xeac (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> MobileSelectedTL__Direction_3B3245644A941BB300D1A3B017FAF4AC() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xeb0); } // 0xeb0 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* MobileSelectedTL() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0xeb8); } // 0xeb8 (Size: 0x8, Type: ObjectProperty)
    float MobileOnInteractTL_LERP_0EDB17994610CCA511D017A7FCB5FD6E() const { return Read<float>(uintptr_t(this) + 0xec0); } // 0xec0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> MobileOnInteractTL__Direction_0EDB17994610CCA511D017A7FCB5FD6E() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xec4); } // 0xec4 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* MobileOnInteractTL() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0xec8); } // 0xec8 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* Loot_Effect() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0xed0); } // 0xed0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SpecialChestOpenSound() const { return Read<USoundBase*>(uintptr_t(this) + 0xed8); } // 0xed8 (Size: 0x8, Type: ObjectProperty)
    TArray<UMaterialInstanceDynamic*> MIDs() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0xee0); } // 0xee0 (Size: 0x10, Type: ArrayProperty)
    double MobileWiggleAmount() const { return Read<double>(uintptr_t(this) + 0xef0); } // 0xef0 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle ChimeTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0xef8); } // 0xef8 (Size: 0x8, Type: StructProperty)
    double ChestChimeVisualUpdate() const { return Read<double>(uintptr_t(this) + 0xf00); } // 0xf00 (Size: 0x8, Type: DoubleProperty)
    UMaterialInterface* MobileInteractionMaterial() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0xf08); } // 0xf08 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* MobileInteractIcon() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0xf10); } // 0xf10 (Size: 0x8, Type: ObjectProperty)
    FVector MobileInteractIconLocation() const { return Read<FVector>(uintptr_t(this) + 0xf18); } // 0xf18 (Size: 0x18, Type: StructProperty)
    FVector MobileInteractIconScale() const { return Read<FVector>(uintptr_t(this) + 0xf30); } // 0xf30 (Size: 0x18, Type: StructProperty)
    FName ResourceLightTag() const { return Read<FName>(uintptr_t(this) + 0xf48); } // 0xf48 (Size: 0x4, Type: NameProperty)
    FName ResourceVFXTag() const { return Read<FName>(uintptr_t(this) + 0xf4c); } // 0xf4c (Size: 0x4, Type: NameProperty)
    FName ResourceAudioTag() const { return Read<FName>(uintptr_t(this) + 0xf50); } // 0xf50 (Size: 0x4, Type: NameProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xe78, Value); } // 0xe78 (Size: 0x8, Type: StructProperty)
    void SET_S_Chest_SmokeSheet(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0xe80, Value); } // 0xe80 (Size: 0x8, Type: ObjectProperty)
    void SET_NS_Athena_Loot_Chest_Aura(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0xe88, Value); } // 0xe88 (Size: 0x8, Type: ObjectProperty)
    void SET_CreativeIslandResource(const UCreativeIslandResourceComponent*& Value) { Write<UCreativeIslandResourceComponent*>(uintptr_t(this) + 0xe90, Value); } // 0xe90 (Size: 0x8, Type: ObjectProperty)
    void SET_TrasureLight(const UPointLightComponent*& Value) { Write<UPointLightComponent*>(uintptr_t(this) + 0xe98, Value); } // 0xe98 (Size: 0x8, Type: ObjectProperty)
    void SET_Chest_Ambient_Sound(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0xea0, Value); } // 0xea0 (Size: 0x8, Type: ObjectProperty)
    void SET_MobileSelectedTL_LerpInteactoIcon_3B3245644A941BB300D1A3B017FAF4AC(const float& Value) { Write<float>(uintptr_t(this) + 0xea8, Value); } // 0xea8 (Size: 0x4, Type: FloatProperty)
    void SET_MobileSelectedTL_LerpObject_3B3245644A941BB300D1A3B017FAF4AC(const float& Value) { Write<float>(uintptr_t(this) + 0xeac, Value); } // 0xeac (Size: 0x4, Type: FloatProperty)
    void SET_MobileSelectedTL__Direction_3B3245644A941BB300D1A3B017FAF4AC(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xeb0, Value); } // 0xeb0 (Size: 0x1, Type: ByteProperty)
    void SET_MobileSelectedTL(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0xeb8, Value); } // 0xeb8 (Size: 0x8, Type: ObjectProperty)
    void SET_MobileOnInteractTL_LERP_0EDB17994610CCA511D017A7FCB5FD6E(const float& Value) { Write<float>(uintptr_t(this) + 0xec0, Value); } // 0xec0 (Size: 0x4, Type: FloatProperty)
    void SET_MobileOnInteractTL__Direction_0EDB17994610CCA511D017A7FCB5FD6E(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xec4, Value); } // 0xec4 (Size: 0x1, Type: ByteProperty)
    void SET_MobileOnInteractTL(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0xec8, Value); } // 0xec8 (Size: 0x8, Type: ObjectProperty)
    void SET_Loot_Effect(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0xed0, Value); } // 0xed0 (Size: 0x8, Type: ObjectProperty)
    void SET_SpecialChestOpenSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xed8, Value); } // 0xed8 (Size: 0x8, Type: ObjectProperty)
    void SET_MIDs(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0xee0, Value); } // 0xee0 (Size: 0x10, Type: ArrayProperty)
    void SET_MobileWiggleAmount(const double& Value) { Write<double>(uintptr_t(this) + 0xef0, Value); } // 0xef0 (Size: 0x8, Type: DoubleProperty)
    void SET_ChimeTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xef8, Value); } // 0xef8 (Size: 0x8, Type: StructProperty)
    void SET_ChestChimeVisualUpdate(const double& Value) { Write<double>(uintptr_t(this) + 0xf00, Value); } // 0xf00 (Size: 0x8, Type: DoubleProperty)
    void SET_MobileInteractionMaterial(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0xf08, Value); } // 0xf08 (Size: 0x8, Type: ObjectProperty)
    void SET_MobileInteractIcon(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0xf10, Value); } // 0xf10 (Size: 0x8, Type: ObjectProperty)
    void SET_MobileInteractIconLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf18, Value); } // 0xf18 (Size: 0x18, Type: StructProperty)
    void SET_MobileInteractIconScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf30, Value); } // 0xf30 (Size: 0x18, Type: StructProperty)
    void SET_ResourceLightTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0xf48, Value); } // 0xf48 (Size: 0x4, Type: NameProperty)
    void SET_ResourceVFXTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0xf4c, Value); } // 0xf4c (Size: 0x4, Type: NameProperty)
    void SET_ResourceAudioTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0xf50, Value); } // 0xf50 (Size: 0x4, Type: NameProperty)
};

