/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CommChannelsDebugRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x40
class UCommChannelsDebugDrawSubsystem : public UTickableWorldSubsystem
{
public:
};

