/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioCapture
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0xb0
class UAudioCapture : public UAudioGenerator
{
public:
};

// Size: 0x28
class UAudioCaptureFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UAudioCaptureBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x960
class UAudioCaptureComponent : public USynthComponent
{
public:
    int32_t JitterLatencyFrames() const { return Read<int32_t>(uintptr_t(this) + 0x8a0); } // 0x8a0 (Size: 0x4, Type: IntProperty)

    void SET_JitterLatencyFrames(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8a0, Value); } // 0x8a0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x30
struct FAudioInputDeviceInfo
{
public:
    FString DeviceName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString DeviceID() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t InputChannels() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)
    int32_t PreferredSampleRate() const { return Read<int32_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: IntProperty)
    bool bSupportsHardwareAEC() const { return (Read<uint8_t>(uintptr_t(this) + 0x28) >> 0x0) & 1; } // 0x28:0 (Size: 0x1, Type: BoolProperty)

    void SET_DeviceName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_DeviceID(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_InputChannels(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
    void SET_PreferredSampleRate(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: IntProperty)
    void SET_bSupportsHardwareAEC(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x28); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x28, B); } // 0x28:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc
struct FAudioCaptureDeviceInfo
{
public:
    FName DeviceName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t NumInputChannels() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t SampleRate() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)

    void SET_DeviceName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_NumInputChannels(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_SampleRate(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
};

