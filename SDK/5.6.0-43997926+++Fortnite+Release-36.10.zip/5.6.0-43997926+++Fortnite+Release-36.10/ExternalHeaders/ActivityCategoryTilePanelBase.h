/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityCategoryTilePanelBase
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "UMG.h"

// Size: 0x3e8
class UActivityCategoryTilePanelBase_C : public UFortActivityCategoryTilePanel
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x8, Type: StructProperty)
    UVerticalBox* VerticalBox_Content() const { return Read<UVerticalBox*>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ActiveInactivate() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnMoveUpOutOfView() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    double EntryHeight() const { return Read<double>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: DoubleProperty)
    double EntryWidth() const { return Read<double>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x8, Type: StructProperty)
    void SET_VerticalBox_Content(const UVerticalBox*& Value) { Write<UVerticalBox*>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    void SET_ActiveInactivate(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    void SET_OnMoveUpOutOfView(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    void SET_EntryHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: DoubleProperty)
    void SET_EntryWidth(const double& Value) { Write<double>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: DoubleProperty)
};

