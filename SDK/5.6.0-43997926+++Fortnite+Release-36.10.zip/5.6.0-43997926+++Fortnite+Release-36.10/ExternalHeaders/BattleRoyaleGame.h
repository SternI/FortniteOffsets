/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BattleRoyaleGame
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0xb8
class UFortGameStateComponent_BattleRoyalePlacementInfo : public UFortGameStateComponent_PlacementInfo
{
public:
};

