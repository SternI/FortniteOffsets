/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Gadgets
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "Niagara.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "Athena.h"
#include "CoreUObject.h"
#include "GameplayAbilities.h"

// Size: 0x3f8
class ABP_ZipLine_Athena_Harness_Yellow_C : public ABP_ZipLine_Athena_Harness_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x8, Type: StructProperty)
    UNiagaraComponent* NS_Zipline_Pulley_SpeedLines_Converted() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* NS_Zipline_Speedline() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    float Alpha_NewTrack_0_AF34CA1D47D28FE19CCA3C98688125DE() const { return Read<float>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Alpha__Direction_AF34CA1D47D28FE19CCA3C98688125DE() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x3cc); } // 0x3cc (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Alpha() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    float Spark_NewTrack_0_A812B2F04CB78DDF352B84A578861501() const { return Read<float>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Spark__Direction_A812B2F04CB78DDF352B84A578861501() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x3dc); } // 0x3dc (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* spark() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    double BeginLocation_z() const { return Read<double>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x8, Type: DoubleProperty)
    double Location() const { return Read<double>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x8, Type: StructProperty)
    void SET_NS_Zipline_Pulley_SpeedLines_Converted(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)
    void SET_NS_Zipline_Speedline(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    void SET_Alpha_NewTrack_0_AF34CA1D47D28FE19CCA3C98688125DE(const float& Value) { Write<float>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x4, Type: FloatProperty)
    void SET_Alpha__Direction_AF34CA1D47D28FE19CCA3C98688125DE(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x3cc, Value); } // 0x3cc (Size: 0x1, Type: ByteProperty)
    void SET_Alpha(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    void SET_Spark_NewTrack_0_A812B2F04CB78DDF352B84A578861501(const float& Value) { Write<float>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x4, Type: FloatProperty)
    void SET_Spark__Direction_A812B2F04CB78DDF352B84A578861501(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x3dc, Value); } // 0x3dc (Size: 0x1, Type: ByteProperty)
    void SET_spark(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    void SET_BeginLocation_z(const double& Value) { Write<double>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x8, Type: DoubleProperty)
    void SET_Location(const double& Value) { Write<double>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x3b0
class ABP_ZipLine_Athena_Harness_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    UParticleSystemComponent* P_Zipline_AttachedToPlayer() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SM_Zipline_Magnet() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UArrowComponent* Arrow() const { return Read<UArrowComponent*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* P_Zipline_Pulley_SpeedLines() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SM_Zipline_Motor() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* Scene() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* SpawnFX() const { return Read<UParticleSystem*>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* DestroyFX() const { return Read<UParticleSystem*>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* CollideDestroyVFX() const { return Read<UParticleSystem*>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* AttachSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* DetachSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawn* AttachedPlayer() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    bool HasHitAnotherPlayer() const { return Read<bool>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x1, Type: BoolProperty)
    double ZiplineChimeVisualUpdate() const { return Read<double>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle ChimeTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: StructProperty)
    FVector ZiplineDirection() const { return Read<FVector>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x18, Type: StructProperty)
    ABP_Athena_Environmental_ZipLine_Spline_C* EnvZiplineSpline() const { return Read<ABP_Athena_Environmental_ZipLine_Spline_C*>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    double SplineRotationUpdateSeconds() const { return Read<double>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle MotorUpdateTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: StructProperty)
    AFortAthenaZipline* AttachedZipline() const { return Read<AFortAthenaZipline*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    bool debugOutput() const { return Read<bool>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x1, Type: BoolProperty)
    bool IsReversingMomentum() const { return Read<bool>(uintptr_t(this) + 0x361); } // 0x361 (Size: 0x1, Type: BoolProperty)
    bool bIsTravelingUphill() const { return Read<bool>(uintptr_t(this) + 0x362); } // 0x362 (Size: 0x1, Type: BoolProperty)
    bool bIsTravelingDownhill() const { return Read<bool>(uintptr_t(this) + 0x363); } // 0x363 (Size: 0x1, Type: BoolProperty)
    FGameplayTag GCNTag_Travel() const { return Read<FGameplayTag>(uintptr_t(this) + 0x364); } // 0x364 (Size: 0x4, Type: StructProperty)
    USoundBase* TravelSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag GCNTag_HighSpeed() const { return Read<FGameplayTag>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x4, Type: StructProperty)
    FGameplayTag GCNTag_ZiplineBraking() const { return Read<FGameplayTag>(uintptr_t(this) + 0x374); } // 0x374 (Size: 0x4, Type: StructProperty)
    bool bLoopingDownhillGCN() const { return Read<bool>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x1, Type: BoolProperty)
    FActiveGameplayEffectHandle DownhillTravelGE() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x37c); } // 0x37c (Size: 0x8, Type: StructProperty)
    bool UseMeshAttachment() const { return Read<bool>(uintptr_t(this) + 0x384); } // 0x384 (Size: 0x1, Type: BoolProperty)
    FVector CurrentDesired_Zipline_Offset() const { return Read<FVector>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x18, Type: StructProperty)
    APROTOTYPE_BP_Athena_Dynamic_ZipLine_Spline_C* DynamicZiplineSpline() const { return Read<APROTOTYPE_BP_Athena_Dynamic_ZipLine_Spline_C*>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    USplineComponent* NewVar_0() const { return Read<USplineComponent*>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    void SET_P_Zipline_AttachedToPlayer(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_SM_Zipline_Magnet(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_Arrow(const UArrowComponent*& Value) { Write<UArrowComponent*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    void SET_P_Zipline_Pulley_SpeedLines(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    void SET_SM_Zipline_Motor(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    void SET_Scene(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    void SET_SpawnFX(const UParticleSystem*& Value) { Write<UParticleSystem*>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    void SET_DestroyFX(const UParticleSystem*& Value) { Write<UParticleSystem*>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    void SET_CollideDestroyVFX(const UParticleSystem*& Value) { Write<UParticleSystem*>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    void SET_AttachSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    void SET_DetachSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    void SET_AttachedPlayer(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    void SET_HasHitAnotherPlayer(const bool& Value) { Write<bool>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x1, Type: BoolProperty)
    void SET_ZiplineChimeVisualUpdate(const double& Value) { Write<double>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x8, Type: DoubleProperty)
    void SET_ChimeTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: StructProperty)
    void SET_ZiplineDirection(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x18, Type: StructProperty)
    void SET_EnvZiplineSpline(const ABP_Athena_Environmental_ZipLine_Spline_C*& Value) { Write<ABP_Athena_Environmental_ZipLine_Spline_C*>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    void SET_SplineRotationUpdateSeconds(const double& Value) { Write<double>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: DoubleProperty)
    void SET_MotorUpdateTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: StructProperty)
    void SET_AttachedZipline(const AFortAthenaZipline*& Value) { Write<AFortAthenaZipline*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_debugOutput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x1, Type: BoolProperty)
    void SET_IsReversingMomentum(const bool& Value) { Write<bool>(uintptr_t(this) + 0x361, Value); } // 0x361 (Size: 0x1, Type: BoolProperty)
    void SET_bIsTravelingUphill(const bool& Value) { Write<bool>(uintptr_t(this) + 0x362, Value); } // 0x362 (Size: 0x1, Type: BoolProperty)
    void SET_bIsTravelingDownhill(const bool& Value) { Write<bool>(uintptr_t(this) + 0x363, Value); } // 0x363 (Size: 0x1, Type: BoolProperty)
    void SET_GCNTag_Travel(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x364, Value); } // 0x364 (Size: 0x4, Type: StructProperty)
    void SET_TravelSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_GCNTag_HighSpeed(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x4, Type: StructProperty)
    void SET_GCNTag_ZiplineBraking(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x374, Value); } // 0x374 (Size: 0x4, Type: StructProperty)
    void SET_bLoopingDownhillGCN(const bool& Value) { Write<bool>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x1, Type: BoolProperty)
    void SET_DownhillTravelGE(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x37c, Value); } // 0x37c (Size: 0x8, Type: StructProperty)
    void SET_UseMeshAttachment(const bool& Value) { Write<bool>(uintptr_t(this) + 0x384, Value); } // 0x384 (Size: 0x1, Type: BoolProperty)
    void SET_CurrentDesired_Zipline_Offset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x18, Type: StructProperty)
    void SET_DynamicZiplineSpline(const APROTOTYPE_BP_Athena_Dynamic_ZipLine_Spline_C*& Value) { Write<APROTOTYPE_BP_Athena_Dynamic_ZipLine_Spline_C*>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    void SET_NewVar_0(const USplineComponent*& Value) { Write<USplineComponent*>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
};

