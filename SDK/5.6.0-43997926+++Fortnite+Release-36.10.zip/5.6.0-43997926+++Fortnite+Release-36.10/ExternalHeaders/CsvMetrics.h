/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CsvMetrics
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x88
class UCsvActorCountMetric : public UWorldMetricInterface
{
public:
};

// Size: 0x60
class UCsvMetricsSubsystem : public UWorldSubsystem
{
public:
    TArray<UClass*> MetricClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_MetricClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

