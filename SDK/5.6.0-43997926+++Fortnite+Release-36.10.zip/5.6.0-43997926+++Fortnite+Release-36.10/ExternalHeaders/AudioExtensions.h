/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioExtensions
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"

// Size: 0x28
class UAudioPropertiesSheetAssetUserInterface : public UInterface
{
public:
};

// Size: 0x28
class UAudioPropertiesSheetAssetBase : public UObject
{
public:
};

// Size: 0x28
class USpatializationPluginSourceSettingsBase : public UObject
{
public:
};

// Size: 0x28
class USourceDataOverridePluginSourceSettingsBase : public UObject
{
public:
};

// Size: 0x28
class UOcclusionPluginSourceSettingsBase : public UObject
{
public:
};

// Size: 0x28
class UReverbPluginSourceSettingsBase : public UObject
{
public:
};

// Size: 0x28
class UAudioParameterControllerInterface : public UInterface
{
public:
};

// Size: 0x28
class UAudioEndpointSettingsBase : public UObject
{
public:
};

// Size: 0x28
class UDummyEndpointSettings : public UAudioEndpointSettingsBase
{
public:
};

// Size: 0x30
class USoundModulatorBase : public UObject
{
public:
};

// Size: 0x28
class USoundfieldEndpointSettingsBase : public UObject
{
public:
};

// Size: 0x28
class USoundfieldEncodingSettingsBase : public UObject
{
public:
};

// Size: 0x28
class USoundfieldEffectSettingsBase : public UObject
{
public:
};

// Size: 0x30
class USoundfieldEffectBase : public UObject
{
public:
    USoundfieldEffectSettingsBase* Settings() const { return Read<USoundfieldEffectSettingsBase*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_Settings(const USoundfieldEffectSettingsBase*& Value) { Write<USoundfieldEffectSettingsBase*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UWaveformTransformationBase : public UObject
{
public:
};

// Size: 0x38
class UWaveformTransformationChain : public UObject
{
public:
    TArray<UWaveformTransformationBase*> Transformations() const { return Read<TArray<UWaveformTransformationBase*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_Transformations(const TArray<UWaveformTransformationBase*>& Value) { Write<TArray<UWaveformTransformationBase*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x4
struct FSoundGeneratorOutput
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
};

// Size: 0x1
struct FSoundWaveCloudStreamingPlatformProjectSettings
{
public:
    uint8_t EnablementSetting() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)

    void SET_EnablementSetting(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x1
struct FSoundWaveCloudStreamingPlatformSettings
{
public:
    uint8_t EnablementSetting() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)

    void SET_EnablementSetting(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x90
struct FAudioParameter
{
public:
    FName ParamName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    float FloatParam() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    bool BoolParam() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    int32_t IntParam() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    UObject* ObjectParam() const { return Read<UObject*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    FString StringParam() const { return Read<FString>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StrProperty)
    TArray<float> ArrayFloatParam() const { return Read<TArray<float>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<bool> ArrayBoolParam() const { return Read<TArray<bool>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> ArrayIntParam() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<UObject*> ArrayObjectParam() const { return Read<TArray<UObject*>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> ArrayStringParam() const { return Read<TArray<FString>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    uint8_t ParamType() const { return Read<uint8_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: EnumProperty)
    FName TypeName() const { return Read<FName>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: NameProperty)

    void SET_ParamName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_FloatParam(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_BoolParam(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_IntParam(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_ObjectParam(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_StringParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StrProperty)
    void SET_ArrayFloatParam(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_ArrayBoolParam(const TArray<bool>& Value) { Write<TArray<bool>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_ArrayIntParam(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_ArrayObjectParam(const TArray<UObject*>& Value) { Write<TArray<UObject*>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_ArrayStringParam(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_ParamType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: EnumProperty)
    void SET_TypeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: NameProperty)
};

// Size: 0x30
struct FSoundWaveCuePoint
{
public:
    int32_t CuePointID() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    FString Label() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)
    int64_t FramePosition() const { return Read<int64_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: Int64Property)
    int64_t FrameLength() const { return Read<int64_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: Int64Property)
    bool bIsLoopRegion() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)

    void SET_CuePointID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Label(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
    void SET_FramePosition(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: Int64Property)
    void SET_FrameLength(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: Int64Property)
    void SET_bIsLoopRegion(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
};

