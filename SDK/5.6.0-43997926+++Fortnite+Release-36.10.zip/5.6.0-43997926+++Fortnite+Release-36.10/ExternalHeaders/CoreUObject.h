/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CoreUObject
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
// Size: 0x28
class UObject
{
public:
    void** VTable() const { return Read<void**>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FName NamePrivate() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    int32_t InternalIndex() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    UClass* ClassPrivate() const { return Read<UClass*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    EObjectFlags ObjectFlags() const { return Read<EObjectFlags>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: EnumProperty)
    int32_t ObjectListInternalIndex() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    UObject* OuterPrivate() const { return Read<UObject*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)

    void SET_VTable(const void**& Value) { Write<void**>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_NamePrivate(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_InternalIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_ClassPrivate(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_ObjectFlags(const EObjectFlags& Value) { Write<EObjectFlags>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: EnumProperty)
    void SET_ObjectListInternalIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_OuterPrivate(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UInterface : public UObject
{
public:
};

// Size: 0x108
class UUserDefinedStruct : public UScriptStruct
{
public:
    TEnumAsByte<EUserDefinedStructureStatus> Status() const { return Read<TEnumAsByte<EUserDefinedStructureStatus>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: ByteProperty)
    FGuid Guid() const { return Read<FGuid>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x10, Type: StructProperty)

    void SET_Status(const TEnumAsByte<EUserDefinedStructureStatus>& Value) { Write<TEnumAsByte<EUserDefinedStructureStatus>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: ByteProperty)
    void SET_Guid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x10, Type: StructProperty)
};

// Size: 0xc0
class UScriptStruct : public UStruct
{
public:
};

// Size: 0xb0
class UStruct : public UField
{
public:
    UStruct* SuperStruct() const { return Read<UStruct*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    FField* ChildProperties() const { return Read<FField*>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: ObjectProperty)

    void SET_SuperStruct(const UStruct*& Value) { Write<UStruct*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_ChildProperties(const FField*& Value) { Write<FField*>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
class UField : public UObject
{
public:
    UField* Next() const { return Read<UField*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_Next(const UField*& Value) { Write<UField*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UUserDefinedStructEditorDataBase : public UObject
{
public:
};

// Size: 0x78
class UVerseEnum : public UEnum
{
public:
};

// Size: 0x60
class UEnum : public UField
{
public:
};

// Size: 0xe8
class UVerseFunction : public UFunction
{
public:
};

// Size: 0x208
class UClass : public UStruct
{
public:
};

// Size: 0x48
class UPackage : public UObject
{
public:
};

// Size: 0xe0
class UFunction : public UStruct
{
public:
    EFunctionFlags FunctionFlags() const { return Read<EFunctionFlags>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: EnumProperty)
    void* Func() const { return Read<void*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)

    void SET_FunctionFlags(const EFunctionFlags& Value) { Write<EFunctionFlags>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: EnumProperty)
    void SET_Func(const void*& Value) { Write<void*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x110
class UVerseStruct : public UScriptStruct
{
public:
    uint32_t VerseClassFlags() const { return Read<uint32_t>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: UInt32Property)
    UFunction* InitFunction() const { return Read<UFunction*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    UVerseClass* ModuleClass() const { return Read<UVerseClass*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ClassProperty)
    FGuid Guid() const { return Read<FGuid>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x10, Type: StructProperty)
    UFunction* FactoryFunction() const { return Read<UFunction*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    UFunction* OverrideFactoryFunction() const { return Read<UFunction*>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: ObjectProperty)
    uint8_t ConstructorEffects() const { return Read<uint8_t>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x1, Type: EnumProperty)

    void SET_VerseClassFlags(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: UInt32Property)
    void SET_InitFunction(const UFunction*& Value) { Write<UFunction*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_ModuleClass(const UVerseClass*& Value) { Write<UVerseClass*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ClassProperty)
    void SET_Guid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x10, Type: StructProperty)
    void SET_FactoryFunction(const UFunction*& Value) { Write<UFunction*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    void SET_OverrideFactoryFunction(const UFunction*& Value) { Write<UFunction*>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: ObjectProperty)
    void SET_ConstructorEffects(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x28
class UEditorPathObjectInterface : public UInterface
{
public:
};

// Size: 0x38
class UGCObjectReferencer : public UObject
{
public:
};

// Size: 0x50
class UTextBuffer : public UObject
{
public:
};

// Size: 0x28
class UPropertyBagMissingObject : public UObject
{
public:
};

// Size: 0xd8
class UPropertyBag : public UScriptStruct
{
public:
    TArray<FPropertyBagPropertyDesc> PropertyDescs() const { return Read<TArray<FPropertyBagPropertyDesc>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: ArrayProperty)

    void SET_PropertyDescs(const TArray<FPropertyBagPropertyDesc>& Value) { Write<TArray<FPropertyBagPropertyDesc>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xe0
class UDelegateFunction : public UFunction
{
public:
};

// Size: 0xe8
class USparseDelegateFunction : public UDelegateFunction
{
public:
};

// Size: 0x78
class UEnumCookedMetaData : public UObject
{
public:
    FObjectCookedMetaDataStore EnumMetaData() const { return Read<FObjectCookedMetaDataStore>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: StructProperty)

    void SET_EnumMetaData(const FObjectCookedMetaDataStore& Value) { Write<FObjectCookedMetaDataStore>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: StructProperty)
};

// Size: 0xc8
class UStructCookedMetaData : public UObject
{
public:
    FStructCookedMetaDataStore StructMetaData() const { return Read<FStructCookedMetaDataStore>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0xa0, Type: StructProperty)

    void SET_StructMetaData(const FStructCookedMetaDataStore& Value) { Write<FStructCookedMetaDataStore>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0xa0, Type: StructProperty)
};

// Size: 0x118
class UClassCookedMetaData : public UObject
{
public:
    FStructCookedMetaDataStore ClassMetaData() const { return Read<FStructCookedMetaDataStore>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0xa0, Type: StructProperty)
    TMap<FStructCookedMetaDataStore, FName> FunctionsMetaData() const { return Read<TMap<FStructCookedMetaDataStore, FName>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x50, Type: MapProperty)

    void SET_ClassMetaData(const FStructCookedMetaDataStore& Value) { Write<FStructCookedMetaDataStore>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0xa0, Type: StructProperty)
    void SET_FunctionsMetaData(const TMap<FStructCookedMetaDataStore, FName>& Value) { Write<TMap<FStructCookedMetaDataStore, FName>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x50, Type: MapProperty)
};

// Size: 0xe0
class UPackageMap : public UObject
{
public:
};

// Size: 0x38
class UObjectReachabilityStressData : public UObject
{
public:
};

// Size: 0x3c8
class ULinkerPlaceholderClass : public UClass
{
public:
};

// Size: 0xf8
class ULinkerPlaceholderExportObject : public UObject
{
public:
};

// Size: 0x2a0
class ULinkerPlaceholderFunction : public UFunction
{
public:
};

// Size: 0xc8
class UMetaData : public UObject
{
public:
};

// Size: 0x30
class UObjectRedirector : public UObject
{
public:
};

// Size: 0x70
class UProperty : public UField
{
public:
};

// Size: 0x80
class UEnumProperty : public UProperty
{
public:
};

// Size: 0x78
class UArrayProperty : public UProperty
{
public:
};

// Size: 0x78
class UObjectPropertyBase : public UProperty
{
public:
};

// Size: 0x78
class UBoolProperty : public UProperty
{
public:
};

// Size: 0x78
class UByteProperty : public UNumericProperty
{
public:
};

// Size: 0x70
class UNumericProperty : public UProperty
{
public:
};

// Size: 0x80
class UClassProperty : public UObjectProperty
{
public:
};

// Size: 0x78
class UObjectProperty : public UObjectPropertyBase
{
public:
};

// Size: 0x78
class UDelegateProperty : public UProperty
{
public:
};

// Size: 0x70
class UDoubleProperty : public UNumericProperty
{
public:
};

// Size: 0x70
class UFloatProperty : public UNumericProperty
{
public:
};

// Size: 0x70
class UIntProperty : public UNumericProperty
{
public:
};

// Size: 0x70
class UInt8Property : public UNumericProperty
{
public:
};

// Size: 0x70
class UInt16Property : public UNumericProperty
{
public:
};

// Size: 0x70
class UInt64Property : public UNumericProperty
{
public:
};

// Size: 0x78
class UInterfaceProperty : public UProperty
{
public:
};

// Size: 0x78
class ULazyObjectProperty : public UObjectPropertyBase
{
public:
};

// Size: 0x98
class UMapProperty : public UProperty
{
public:
};

// Size: 0x78
class UMulticastDelegateProperty : public UProperty
{
public:
};

// Size: 0x78
class UMulticastInlineDelegateProperty : public UMulticastDelegateProperty
{
public:
};

// Size: 0x78
class UMulticastSparseDelegateProperty : public UMulticastDelegateProperty
{
public:
};

// Size: 0x70
class UNameProperty : public UProperty
{
public:
};

// Size: 0x90
class USetProperty : public UProperty
{
public:
};

// Size: 0x80
class USoftClassProperty : public USoftObjectProperty
{
public:
};

// Size: 0x78
class USoftObjectProperty : public UObjectPropertyBase
{
public:
};

// Size: 0x70
class UStrProperty : public UProperty
{
public:
};

// Size: 0x78
class UStructProperty : public UProperty
{
public:
};

// Size: 0x70
class UUInt16Property : public UNumericProperty
{
public:
};

// Size: 0x70
class UUInt32Property : public UNumericProperty
{
public:
};

// Size: 0x70
class UUInt64Property : public UNumericProperty
{
public:
};

// Size: 0x78
class UWeakObjectProperty : public UObjectPropertyBase
{
public:
};

// Size: 0x70
class UTextProperty : public UProperty
{
public:
};

// Size: 0x30
class UPropertyWrapper : public UObject
{
public:
};

// Size: 0x30
class UMulticastDelegatePropertyWrapper : public UPropertyWrapper
{
public:
};

// Size: 0x30
class UMulticastInlineDelegatePropertyWrapper : public UMulticastDelegatePropertyWrapper
{
public:
};

// Size: 0x388
class UVerseClass : public UClass
{
public:
    uint32_t SolClassFlags() const { return Read<uint32_t>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x4, Type: UInt32Property)
    TArray<UVerseClass*> TaskClasses() const { return Read<TArray<UVerseClass*>>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x10, Type: ArrayProperty)
    UFunction* InitInstanceFunction() const { return Read<UFunction*>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x8, Type: ObjectProperty)
    TArray<FVersePersistentVar> PersistentVars() const { return Read<TArray<FVersePersistentVar>>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x10, Type: ArrayProperty)
    TArray<FVerseSessionVar> SessionVars() const { return Read<TArray<FVerseSessionVar>>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x10, Type: ArrayProperty)
    TMap<FVerseClassVarAccessors, FName> VarAccessors() const { return Read<TMap<FVerseClassVarAccessors, FName>>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x50, Type: MapProperty)
    uint8_t ConstructorEffects() const { return Read<uint8_t>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x1, Type: EnumProperty)
    FName MangledPackageVersePath() const { return Read<FName>(uintptr_t(this) + 0x29c); } // 0x29c (Size: 0x4, Type: NameProperty)
    FString PackageRelativeVersePath() const { return Read<FString>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x10, Type: StrProperty)
    TMap<FName, FName> DisplayNameToUENameFunctionMap() const { return Read<TMap<FName, FName>>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x50, Type: MapProperty)
    TArray<UVerseClass*> DirectInterfaces() const { return Read<TArray<UVerseClass*>>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x10, Type: ArrayProperty)
    TArray<TFieldPath> PropertiesWrittenByInitCDO() const { return Read<TArray<TFieldPath>>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x10, Type: ArrayProperty)
    TMap<FName, FName> FunctionMangledNames() const { return Read<TMap<FName, FName>>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x50, Type: MapProperty)
    TArray<FName> PredictsFunctionNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x10, Type: ArrayProperty)

    void SET_SolClassFlags(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x4, Type: UInt32Property)
    void SET_TaskClasses(const TArray<UVerseClass*>& Value) { Write<TArray<UVerseClass*>>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x10, Type: ArrayProperty)
    void SET_InitInstanceFunction(const UFunction*& Value) { Write<UFunction*>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x8, Type: ObjectProperty)
    void SET_PersistentVars(const TArray<FVersePersistentVar>& Value) { Write<TArray<FVersePersistentVar>>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x10, Type: ArrayProperty)
    void SET_SessionVars(const TArray<FVerseSessionVar>& Value) { Write<TArray<FVerseSessionVar>>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x10, Type: ArrayProperty)
    void SET_VarAccessors(const TMap<FVerseClassVarAccessors, FName>& Value) { Write<TMap<FVerseClassVarAccessors, FName>>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x50, Type: MapProperty)
    void SET_ConstructorEffects(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x1, Type: EnumProperty)
    void SET_MangledPackageVersePath(const FName& Value) { Write<FName>(uintptr_t(this) + 0x29c, Value); } // 0x29c (Size: 0x4, Type: NameProperty)
    void SET_PackageRelativeVersePath(const FString& Value) { Write<FString>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x10, Type: StrProperty)
    void SET_DisplayNameToUENameFunctionMap(const TMap<FName, FName>& Value) { Write<TMap<FName, FName>>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x50, Type: MapProperty)
    void SET_DirectInterfaces(const TArray<UVerseClass*>& Value) { Write<TArray<UVerseClass*>>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x10, Type: ArrayProperty)
    void SET_PropertiesWrittenByInitCDO(const TArray<TFieldPath>& Value) { Write<TArray<TFieldPath>>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x10, Type: ArrayProperty)
    void SET_FunctionMangledNames(const TMap<FName, FName>& Value) { Write<TMap<FName, FName>>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x50, Type: MapProperty)
    void SET_PredictsFunctionNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x150
struct FARFilter
{
public:
    TArray<FName> PackageNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> PackagePaths() const { return Read<TArray<FName>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FSoftObjectPath> SoftObjectPaths() const { return Read<TArray<FSoftObjectPath>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> ClassNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FTopLevelAssetPath> ClassPaths() const { return Read<TArray<FTopLevelAssetPath>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    TSet<FName> RecursiveClassesExclusionSet() const { return Read<TSet<FName>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x50, Type: SetProperty)
    TSet<FTopLevelAssetPath> RecursiveClassPathsExclusionSet() const { return Read<TSet<FTopLevelAssetPath>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x50, Type: SetProperty)
    bool bRecursivePaths() const { return Read<bool>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x1, Type: BoolProperty)
    bool bRecursiveClasses() const { return Read<bool>(uintptr_t(this) + 0x141); } // 0x141 (Size: 0x1, Type: BoolProperty)
    bool bIncludeOnlyOnDiskAssets() const { return Read<bool>(uintptr_t(this) + 0x142); } // 0x142 (Size: 0x1, Type: BoolProperty)

    void SET_PackageNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_PackagePaths(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_SoftObjectPaths(const TArray<FSoftObjectPath>& Value) { Write<TArray<FSoftObjectPath>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_ClassNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_ClassPaths(const TArray<FTopLevelAssetPath>& Value) { Write<TArray<FTopLevelAssetPath>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_RecursiveClassesExclusionSet(const TSet<FName>& Value) { Write<TSet<FName>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x50, Type: SetProperty)
    void SET_RecursiveClassPathsExclusionSet(const TSet<FTopLevelAssetPath>& Value) { Write<TSet<FTopLevelAssetPath>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x50, Type: SetProperty)
    void SET_bRecursivePaths(const bool& Value) { Write<bool>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x1, Type: BoolProperty)
    void SET_bRecursiveClasses(const bool& Value) { Write<bool>(uintptr_t(this) + 0x141, Value); } // 0x141 (Size: 0x1, Type: BoolProperty)
    void SET_bIncludeOnlyOnDiskAssets(const bool& Value) { Write<bool>(uintptr_t(this) + 0x142, Value); } // 0x142 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x8
struct FTopLevelAssetPath
{
public:
    FName PackageName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName AssetName() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)

    void SET_PackageName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_AssetName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x18
struct FSoftObjectPath
{
public:
    FTopLevelAssetPath AssetPath() const { return Read<FTopLevelAssetPath>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)

    void SET_AssetPath(const FTopLevelAssetPath& Value) { Write<FTopLevelAssetPath>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
};

// Size: 0x10
struct FAssetBundleData
{
public:
    TArray<FAssetBundleEntry> Bundles() const { return Read<TArray<FAssetBundleEntry>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Bundles(const TArray<FAssetBundleEntry>& Value) { Write<TArray<FAssetBundleEntry>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FAssetBundleEntry
{
public:
    FName BundleName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    TArray<FTopLevelAssetPath> AssetPaths() const { return Read<TArray<FTopLevelAssetPath>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_BundleName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_AssetPaths(const TArray<FTopLevelAssetPath>& Value) { Write<TArray<FTopLevelAssetPath>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
struct FAssetData
{
public:
    FName PackageName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName PackagePath() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    FName AssetName() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    FName AssetClass() const { return Read<FName>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: NameProperty)
    FTopLevelAssetPath AssetClassPath() const { return Read<FTopLevelAssetPath>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)

    void SET_PackageName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_PackagePath(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_AssetName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_AssetClass(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: NameProperty)
    void SET_AssetClassPath(const FTopLevelAssetPath& Value) { Write<FTopLevelAssetPath>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
};

// Size: 0x38
struct FAutomationEvent
{
public:
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FString Message() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)
    FString Context() const { return Read<FString>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StrProperty)
    FGuid Artifact() const { return Read<FGuid>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)

    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_Message(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
    void SET_Context(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StrProperty)
    void SET_Artifact(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
};

// Size: 0x10
struct FGuid
{
public:
    int32_t A() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t B() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t C() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t D() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)

    void SET_A(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_B(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_C(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_D(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
};

// Size: 0x58
struct FAutomationExecutionEntry
{
public:
    FAutomationEvent Event() const { return Read<FAutomationEvent>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x38, Type: StructProperty)
    FString Filename() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)
    int32_t LineNumber() const { return Read<int32_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: IntProperty)
    FDateTime Timestamp() const { return Read<FDateTime>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: StructProperty)

    void SET_Event(const FAutomationEvent& Value) { Write<FAutomationEvent>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x38, Type: StructProperty)
    void SET_Filename(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
    void SET_LineNumber(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: IntProperty)
    void SET_Timestamp(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: StructProperty)
};

// Size: 0x8
struct FDateTime
{
public:
    int64_t Ticks() const { return Read<int64_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: Int64Property)

    void SET_Ticks(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: Int64Property)
};

// Size: 0x38
struct FBox
{
public:
    FVector Min() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Max() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    bool IsValid() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)

    void SET_Min(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Max(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_IsValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FVector
{
public:
    double X() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Y() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Z() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)

    void SET_X(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_Y(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_Z(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x28
struct FBox2D
{
public:
    FVector2D Min() const { return Read<FVector2D>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FVector2D Max() const { return Read<FVector2D>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    bool bIsValid() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_Min(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_Max(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_bIsValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FVector2D
{
public:
    double X() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Y() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)

    void SET_X(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_Y(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x14
struct FBox2f
{
public:
    FVector2f Min() const { return Read<FVector2f>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FVector2f Max() const { return Read<FVector2f>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool bIsValid() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_Min(const FVector2f& Value) { Write<FVector2f>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_Max(const FVector2f& Value) { Write<FVector2f>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_bIsValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x8
struct FVector2f
{
public:
    float X() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Y() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_X(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Y(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
struct FBox3d
{
public:
    FVector3d Min() const { return Read<FVector3d>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector3d Max() const { return Read<FVector3d>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    bool IsValid() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)

    void SET_Min(const FVector3d& Value) { Write<FVector3d>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Max(const FVector3d& Value) { Write<FVector3d>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_IsValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FVector3d
{
public:
    double X() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Y() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Z() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)

    void SET_X(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_Y(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_Z(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x1c
struct FBox3f
{
public:
    FVector3f Min() const { return Read<FVector3f>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FVector3f Max() const { return Read<FVector3f>(uintptr_t(this) + 0xc); } // 0xc (Size: 0xc, Type: StructProperty)
    bool IsValid() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)

    void SET_Min(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_Max(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0xc, Type: StructProperty)
    void SET_IsValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc
struct FVector3f
{
public:
    float X() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Y() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Z() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_X(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Y(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Z(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
struct FBoxSphereBounds
{
public:
    FVector origin() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector BoxExtent() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    double SphereRadius() const { return Read<double>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: DoubleProperty)

    void SET_origin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_BoxExtent(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_SphereRadius(const double& Value) { Write<double>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x38
struct FBoxSphereBounds3d
{
public:
    FVector3d origin() const { return Read<FVector3d>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector3d BoxExtent() const { return Read<FVector3d>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    double SphereRadius() const { return Read<double>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: DoubleProperty)

    void SET_origin(const FVector3d& Value) { Write<FVector3d>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_BoxExtent(const FVector3d& Value) { Write<FVector3d>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_SphereRadius(const double& Value) { Write<double>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x1c
struct FBoxSphereBounds3f
{
public:
    FVector3f origin() const { return Read<FVector3f>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FVector3f BoxExtent() const { return Read<FVector3f>(uintptr_t(this) + 0xc); } // 0xc (Size: 0xc, Type: StructProperty)
    float SphereRadius() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)

    void SET_origin(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_BoxExtent(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0xc, Type: StructProperty)
    void SET_SphereRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x4
struct FColor
{
public:
    char B() const { return Read<char>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    char G() const { return Read<char>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: ByteProperty)
    char R() const { return Read<char>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: ByteProperty)
    char A() const { return Read<char>(uintptr_t(this) + 0x3); } // 0x3 (Size: 0x1, Type: ByteProperty)

    void SET_B(const char& Value) { Write<char>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_G(const char& Value) { Write<char>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: ByteProperty)
    void SET_R(const char& Value) { Write<char>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: ByteProperty)
    void SET_A(const char& Value) { Write<char>(uintptr_t(this) + 0x3, Value); } // 0x3 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x10
struct FDirectoryPath
{
public:
    FString Path() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)

    void SET_Path(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x20
struct FDoubleRange
{
public:
    FDoubleRangeBound LowerBound() const { return Read<FDoubleRangeBound>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FDoubleRangeBound UpperBound() const { return Read<FDoubleRangeBound>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_LowerBound(const FDoubleRangeBound& Value) { Write<FDoubleRangeBound>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_UpperBound(const FDoubleRangeBound& Value) { Write<FDoubleRangeBound>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x10
struct FDoubleRangeBound
{
public:
    TEnumAsByte<ERangeBoundTypes> Type() const { return Read<TEnumAsByte<ERangeBoundTypes>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    double Value() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)

    void SET_Type(const TEnumAsByte<ERangeBoundTypes>& Value) { Write<TEnumAsByte<ERangeBoundTypes>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_Value(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x1
struct FFallbackStruct
{
public:
};

// Size: 0x10
struct FFilePath
{
public:
    FString FilePath() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)

    void SET_FilePath(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x8
struct FFloatInterval
{
public:
    float Min() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Max() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_Min(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Max(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FFloatRange
{
public:
    FFloatRangeBound LowerBound() const { return Read<FFloatRangeBound>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FFloatRangeBound UpperBound() const { return Read<FFloatRangeBound>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)

    void SET_LowerBound(const FFloatRangeBound& Value) { Write<FFloatRangeBound>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_UpperBound(const FFloatRangeBound& Value) { Write<FFloatRangeBound>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x8
struct FFloatRangeBound
{
public:
    TEnumAsByte<ERangeBoundTypes> Type() const { return Read<TEnumAsByte<ERangeBoundTypes>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    float Value() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_Type(const TEnumAsByte<ERangeBoundTypes>& Value) { Write<TEnumAsByte<ERangeBoundTypes>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x4
struct FFrameNumber
{
public:
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)

    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FFrameNumberRange
{
public:
    FFrameNumberRangeBound LowerBound() const { return Read<FFrameNumberRangeBound>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FFrameNumberRangeBound UpperBound() const { return Read<FFrameNumberRangeBound>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)

    void SET_LowerBound(const FFrameNumberRangeBound& Value) { Write<FFrameNumberRangeBound>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_UpperBound(const FFrameNumberRangeBound& Value) { Write<FFrameNumberRangeBound>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x8
struct FFrameNumberRangeBound
{
public:
    TEnumAsByte<ERangeBoundTypes> Type() const { return Read<TEnumAsByte<ERangeBoundTypes>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    FFrameNumber Value() const { return Read<FFrameNumber>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)

    void SET_Type(const TEnumAsByte<ERangeBoundTypes>& Value) { Write<TEnumAsByte<ERangeBoundTypes>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_Value(const FFrameNumber& Value) { Write<FFrameNumber>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
};

// Size: 0x8
struct FFrameRate
{
public:
    int32_t Numerator() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Denominator() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_Numerator(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Denominator(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x8
struct FFrameTime
{
public:
    FFrameNumber FrameNumber() const { return Read<FFrameNumber>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    float SubFrame() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_FrameNumber(const FFrameNumber& Value) { Write<FFrameNumber>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_SubFrame(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x4
struct FInputDeviceId
{
public:
    int32_t InternalId() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)

    void SET_InternalId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x8
struct FInt32Interval
{
public:
    int32_t Min() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Max() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_Min(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Max(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x8
struct FInt32Point
{
public:
    int32_t X() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_X(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Y(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FInt32Range
{
public:
    FInt32RangeBound LowerBound() const { return Read<FInt32RangeBound>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FInt32RangeBound UpperBound() const { return Read<FInt32RangeBound>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)

    void SET_LowerBound(const FInt32RangeBound& Value) { Write<FInt32RangeBound>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_UpperBound(const FInt32RangeBound& Value) { Write<FInt32RangeBound>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x8
struct FInt32RangeBound
{
public:
    TEnumAsByte<ERangeBoundTypes> Type() const { return Read<TEnumAsByte<ERangeBoundTypes>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_Type(const TEnumAsByte<ERangeBoundTypes>& Value) { Write<TEnumAsByte<ERangeBoundTypes>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FInt32Rect
{
public:
    FInt32Point Min() const { return Read<FInt32Point>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FInt32Point Max() const { return Read<FInt32Point>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)

    void SET_Min(const FInt32Point& Value) { Write<FInt32Point>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_Max(const FInt32Point& Value) { Write<FInt32Point>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
};

// Size: 0xc
struct FInt32Vector
{
public:
    int32_t X() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t Z() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)

    void SET_X(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Y(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_Z(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x8
struct FInt32Vector2
{
public:
    int32_t X() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_X(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Y(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FInt32Vector4
{
public:
    int32_t X() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t Z() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t W() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)

    void SET_X(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Y(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_Z(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_W(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FInt64Point
{
public:
    int64_t X() const { return Read<int64_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: Int64Property)
    int64_t Y() const { return Read<int64_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: Int64Property)

    void SET_X(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: Int64Property)
    void SET_Y(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: Int64Property)
};

// Size: 0x20
struct FInt64Rect
{
public:
    FInt64Point Min() const { return Read<FInt64Point>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FInt64Point Max() const { return Read<FInt64Point>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_Min(const FInt64Point& Value) { Write<FInt64Point>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_Max(const FInt64Point& Value) { Write<FInt64Point>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x18
struct FInt64Vector
{
public:
    int64_t X() const { return Read<int64_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: Int64Property)
    int64_t Y() const { return Read<int64_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: Int64Property)
    int64_t Z() const { return Read<int64_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: Int64Property)

    void SET_X(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: Int64Property)
    void SET_Y(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: Int64Property)
    void SET_Z(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: Int64Property)
};

// Size: 0x10
struct FInt64Vector2
{
public:
    int64_t X() const { return Read<int64_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: Int64Property)
    int64_t Y() const { return Read<int64_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: Int64Property)

    void SET_X(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: Int64Property)
    void SET_Y(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: Int64Property)
};

// Size: 0x20
struct FInt64Vector4
{
public:
    int64_t X() const { return Read<int64_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: Int64Property)
    int64_t Y() const { return Read<int64_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: Int64Property)
    int64_t Z() const { return Read<int64_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: Int64Property)
    int64_t W() const { return Read<int64_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: Int64Property)

    void SET_X(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: Int64Property)
    void SET_Y(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: Int64Property)
    void SET_Z(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: Int64Property)
    void SET_W(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: Int64Property)
};

// Size: 0x18
struct FInterpCurveFloat
{
public:
    TArray<FInterpCurvePointFloat> Points() const { return Read<TArray<FInterpCurvePointFloat>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    bool bIsLooped() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    float LoopKeyOffset() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)

    void SET_Points(const TArray<FInterpCurvePointFloat>& Value) { Write<TArray<FInterpCurvePointFloat>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsLooped(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_LoopKeyOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x14
struct FInterpCurvePointFloat
{
public:
    float InVal() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float OutVal() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float ArriveTangent() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float LeaveTangent() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EInterpCurveMode> InterpMode() const { return Read<TEnumAsByte<EInterpCurveMode>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: ByteProperty)

    void SET_InVal(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_OutVal(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_ArriveTangent(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_LeaveTangent(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_InterpMode(const TEnumAsByte<EInterpCurveMode>& Value) { Write<TEnumAsByte<EInterpCurveMode>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x18
struct FInterpCurveLinearColor
{
public:
    TArray<FInterpCurvePointLinearColor> Points() const { return Read<TArray<FInterpCurvePointLinearColor>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    bool bIsLooped() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    float LoopKeyOffset() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)

    void SET_Points(const TArray<FInterpCurvePointLinearColor>& Value) { Write<TArray<FInterpCurvePointLinearColor>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsLooped(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_LoopKeyOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
struct FInterpCurvePointLinearColor
{
public:
    float InVal() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FLinearColor OutVal() const { return Read<FLinearColor>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x10, Type: StructProperty)
    FLinearColor ArriveTangent() const { return Read<FLinearColor>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x10, Type: StructProperty)
    FLinearColor LeaveTangent() const { return Read<FLinearColor>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x10, Type: StructProperty)
    TEnumAsByte<EInterpCurveMode> InterpMode() const { return Read<TEnumAsByte<EInterpCurveMode>>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x1, Type: ByteProperty)

    void SET_InVal(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_OutVal(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x10, Type: StructProperty)
    void SET_ArriveTangent(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x10, Type: StructProperty)
    void SET_LeaveTangent(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x10, Type: StructProperty)
    void SET_InterpMode(const TEnumAsByte<EInterpCurveMode>& Value) { Write<TEnumAsByte<EInterpCurveMode>>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x10
struct FLinearColor
{
public:
    float R() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float G() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float B() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float A() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_R(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_G(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_B(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_A(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x80
struct FInterpCurvePointQuat
{
public:
    float InVal() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FQuat OutVal() const { return Read<FQuat>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    FQuat ArriveTangent() const { return Read<FQuat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)
    FQuat LeaveTangent() const { return Read<FQuat>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x20, Type: StructProperty)
    TEnumAsByte<EInterpCurveMode> InterpMode() const { return Read<TEnumAsByte<EInterpCurveMode>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: ByteProperty)

    void SET_InVal(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_OutVal(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_ArriveTangent(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
    void SET_LeaveTangent(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x20, Type: StructProperty)
    void SET_InterpMode(const TEnumAsByte<EInterpCurveMode>& Value) { Write<TEnumAsByte<EInterpCurveMode>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x20
struct FQuat
{
public:
    double X() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Y() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Z() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    double W() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)

    void SET_X(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_Y(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_Z(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    void SET_W(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0xa0
struct FInterpCurvePointTwoVectors
{
public:
    float InVal() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FTwoVectors OutVal() const { return Read<FTwoVectors>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x30, Type: StructProperty)
    FTwoVectors ArriveTangent() const { return Read<FTwoVectors>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x30, Type: StructProperty)
    FTwoVectors LeaveTangent() const { return Read<FTwoVectors>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x30, Type: StructProperty)
    TEnumAsByte<EInterpCurveMode> InterpMode() const { return Read<TEnumAsByte<EInterpCurveMode>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: ByteProperty)

    void SET_InVal(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_OutVal(const FTwoVectors& Value) { Write<FTwoVectors>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x30, Type: StructProperty)
    void SET_ArriveTangent(const FTwoVectors& Value) { Write<FTwoVectors>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x30, Type: StructProperty)
    void SET_LeaveTangent(const FTwoVectors& Value) { Write<FTwoVectors>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x30, Type: StructProperty)
    void SET_InterpMode(const TEnumAsByte<EInterpCurveMode>& Value) { Write<TEnumAsByte<EInterpCurveMode>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x30
struct FTwoVectors
{
public:
    FVector v1() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector v2() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_v1(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_v2(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x58
struct FInterpCurvePointVector
{
public:
    float InVal() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FVector OutVal() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector ArriveTangent() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector LeaveTangent() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<EInterpCurveMode> InterpMode() const { return Read<TEnumAsByte<EInterpCurveMode>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: ByteProperty)

    void SET_InVal(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_OutVal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_ArriveTangent(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_LeaveTangent(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_InterpMode(const TEnumAsByte<EInterpCurveMode>& Value) { Write<TEnumAsByte<EInterpCurveMode>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x40
struct FInterpCurvePointVector2D
{
public:
    float InVal() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FVector2D OutVal() const { return Read<FVector2D>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FVector2D ArriveTangent() const { return Read<FVector2D>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    FVector2D LeaveTangent() const { return Read<FVector2D>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    TEnumAsByte<EInterpCurveMode> InterpMode() const { return Read<TEnumAsByte<EInterpCurveMode>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: ByteProperty)

    void SET_InVal(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_OutVal(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_ArriveTangent(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_LeaveTangent(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_InterpMode(const TEnumAsByte<EInterpCurveMode>& Value) { Write<TEnumAsByte<EInterpCurveMode>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x18
struct FInterpCurveQuat
{
public:
    TArray<FInterpCurvePointQuat> Points() const { return Read<TArray<FInterpCurvePointQuat>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    bool bIsLooped() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    float LoopKeyOffset() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)

    void SET_Points(const TArray<FInterpCurvePointQuat>& Value) { Write<TArray<FInterpCurvePointQuat>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsLooped(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_LoopKeyOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FInterpCurveTwoVectors
{
public:
    TArray<FInterpCurvePointTwoVectors> Points() const { return Read<TArray<FInterpCurvePointTwoVectors>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    bool bIsLooped() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    float LoopKeyOffset() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)

    void SET_Points(const TArray<FInterpCurvePointTwoVectors>& Value) { Write<TArray<FInterpCurvePointTwoVectors>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsLooped(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_LoopKeyOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FInterpCurveVector
{
public:
    TArray<FInterpCurvePointVector> Points() const { return Read<TArray<FInterpCurvePointVector>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    bool bIsLooped() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    float LoopKeyOffset() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)

    void SET_Points(const TArray<FInterpCurvePointVector>& Value) { Write<TArray<FInterpCurvePointVector>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsLooped(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_LoopKeyOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FInterpCurveVector2D
{
public:
    TArray<FInterpCurvePointVector2D> Points() const { return Read<TArray<FInterpCurvePointVector2D>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    bool bIsLooped() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    float LoopKeyOffset() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)

    void SET_Points(const TArray<FInterpCurvePointVector2D>& Value) { Write<TArray<FInterpCurvePointVector2D>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsLooped(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_LoopKeyOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FIntPoint
{
public:
    int32_t X() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_X(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Y(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FIntRect
{
public:
    FIntPoint Min() const { return Read<FIntPoint>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FIntPoint Max() const { return Read<FIntPoint>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)

    void SET_Min(const FIntPoint& Value) { Write<FIntPoint>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_Max(const FIntPoint& Value) { Write<FIntPoint>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
};

// Size: 0xc
struct FIntVector
{
public:
    int32_t X() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t Z() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)

    void SET_X(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Y(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_Z(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x8
struct FIntVector2
{
public:
    int32_t X() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_X(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Y(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FIntVector4
{
public:
    int32_t X() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t Z() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t W() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)

    void SET_X(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Y(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_Z(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_W(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
};

// Size: 0x80
struct FMatrix
{
public:
    FPlane XPlane() const { return Read<FPlane>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    FPlane YPlane() const { return Read<FPlane>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)
    FPlane ZPlane() const { return Read<FPlane>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: StructProperty)
    FPlane WPlane() const { return Read<FPlane>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x20, Type: StructProperty)

    void SET_XPlane(const FPlane& Value) { Write<FPlane>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_YPlane(const FPlane& Value) { Write<FPlane>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
    void SET_ZPlane(const FPlane& Value) { Write<FPlane>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: StructProperty)
    void SET_WPlane(const FPlane& Value) { Write<FPlane>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x20, Type: StructProperty)
};

// Size: 0x20
struct FPlane : public FVector
{
public:
    double W() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)

    void SET_W(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x80
struct FMatrix44d
{
public:
    FPlane4d XPlane() const { return Read<FPlane4d>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    FPlane4d YPlane() const { return Read<FPlane4d>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)
    FPlane4d ZPlane() const { return Read<FPlane4d>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: StructProperty)
    FPlane4d WPlane() const { return Read<FPlane4d>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x20, Type: StructProperty)

    void SET_XPlane(const FPlane4d& Value) { Write<FPlane4d>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_YPlane(const FPlane4d& Value) { Write<FPlane4d>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
    void SET_ZPlane(const FPlane4d& Value) { Write<FPlane4d>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: StructProperty)
    void SET_WPlane(const FPlane4d& Value) { Write<FPlane4d>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x20, Type: StructProperty)
};

// Size: 0x20
struct FPlane4d : public FVector3d
{
public:
    double W() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)

    void SET_W(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x40
struct FMatrix44f
{
public:
    FPlane4f XPlane() const { return Read<FPlane4f>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FPlane4f YPlane() const { return Read<FPlane4f>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FPlane4f ZPlane() const { return Read<FPlane4f>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    FPlane4f WPlane() const { return Read<FPlane4f>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StructProperty)

    void SET_XPlane(const FPlane4f& Value) { Write<FPlane4f>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_YPlane(const FPlane4f& Value) { Write<FPlane4f>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_ZPlane(const FPlane4f& Value) { Write<FPlane4f>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_WPlane(const FPlane4f& Value) { Write<FPlane4f>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StructProperty)
};

// Size: 0x10
struct FPlane4f : public FVector3f
{
public:
    float W() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_W(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FMusicalTime
{
public:
    int32_t Bar() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t TickInBar() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t TicksPerBar() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t TicksPerBeat() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)

    void SET_Bar(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_TickInBar(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_TicksPerBar(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_TicksPerBeat(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
};

// Size: 0x78
struct FOrientedBox
{
public:
    FVector Center() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector AxisX() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FVector AxisY() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    FVector AxisZ() const { return Read<FVector>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    double ExtentX() const { return Read<double>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: DoubleProperty)
    double ExtentY() const { return Read<double>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: DoubleProperty)
    double ExtentZ() const { return Read<double>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: DoubleProperty)

    void SET_Center(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_AxisX(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_AxisY(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_AxisZ(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_ExtentX(const double& Value) { Write<double>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: DoubleProperty)
    void SET_ExtentY(const double& Value) { Write<double>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: DoubleProperty)
    void SET_ExtentZ(const double& Value) { Write<double>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x4
struct FPackedNormal
{
public:
    char X() const { return Read<char>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    char Y() const { return Read<char>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: ByteProperty)
    char Z() const { return Read<char>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: ByteProperty)
    char W() const { return Read<char>(uintptr_t(this) + 0x3); } // 0x3 (Size: 0x1, Type: ByteProperty)

    void SET_X(const char& Value) { Write<char>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_Y(const char& Value) { Write<char>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: ByteProperty)
    void SET_Z(const char& Value) { Write<char>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: ByteProperty)
    void SET_W(const char& Value) { Write<char>(uintptr_t(this) + 0x3, Value); } // 0x3 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x20
struct FPackedRemoteObjectPathName
{
public:
    TArray<uint16_t> RemoteIds() const { return Read<TArray<uint16_t>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<uint16_t> Names() const { return Read<TArray<uint16_t>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_RemoteIds(const TArray<uint16_t>& Value) { Write<TArray<uint16_t>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Names(const TArray<uint16_t>& Value) { Write<TArray<uint16_t>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x4
struct FPackedRGB10A2N
{
public:
    int32_t Packed() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)

    void SET_Packed(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x8
struct FPackedRGBA16N
{
public:
    int32_t XY() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t ZW() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_XY(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_ZW(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x8
struct FPlatformInputDeviceState
{
public:
    FPlatformUserId OwningPlatformUser() const { return Read<FPlatformUserId>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t ConnectionState() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)

    void SET_OwningPlatformUser(const FPlatformUserId& Value) { Write<FPlatformUserId>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_ConnectionState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x4
struct FPlatformUserId
{
public:
    int32_t InternalId() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)

    void SET_InternalId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
};

// Size: 0xb0
struct FPolyglotTextData
{
public:
    uint8_t Category() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FString NativeCulture() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)
    FString Namespace() const { return Read<FString>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StrProperty)
    FString Key() const { return Read<FString>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StrProperty)
    FString NativeString() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)
    TMap<FString, FString> LocalizedStrings() const { return Read<TMap<FString, FString>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x50, Type: MapProperty)
    bool bIsMinimalPatch() const { return Read<bool>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: BoolProperty)
    FText CachedText() const { return Read<FText>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: TextProperty)

    void SET_Category(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_NativeCulture(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
    void SET_Namespace(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StrProperty)
    void SET_Key(const FString& Value) { Write<FString>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StrProperty)
    void SET_NativeString(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
    void SET_LocalizedStrings(const TMap<FString, FString>& Value) { Write<TMap<FString, FString>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x50, Type: MapProperty)
    void SET_bIsMinimalPatch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: BoolProperty)
    void SET_CachedText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: TextProperty)
};

// Size: 0x8
struct FPrimaryAssetId
{
public:
    FPrimaryAssetType PrimaryAssetType() const { return Read<FPrimaryAssetType>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FName PrimaryAssetName() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)

    void SET_PrimaryAssetType(const FPrimaryAssetType& Value) { Write<FPrimaryAssetType>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_PrimaryAssetName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x4
struct FPrimaryAssetType
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
};

// Size: 0x10
struct FQualifiedFrameTime
{
public:
    FFrameTime time() const { return Read<FFrameTime>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FFrameRate Rate() const { return Read<FFrameRate>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)

    void SET_time(const FFrameTime& Value) { Write<FFrameTime>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_Rate(const FFrameRate& Value) { Write<FFrameRate>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x20
struct FQuat4d
{
public:
    double X() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Y() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Z() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    double W() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)

    void SET_X(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_Y(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_Z(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    void SET_W(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x10
struct FQuat4f
{
public:
    float X() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Y() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Z() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float W() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_X(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Y(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Z(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_W(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FRandomStream
{
public:
    int32_t InitialSeed() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Seed() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_InitialSeed(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Seed(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x30
struct FRay
{
public:
    FVector origin() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Direction() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_origin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Direction(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x30
struct FRay3d
{
public:
    FVector3d origin() const { return Read<FVector3d>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector3d Direction() const { return Read<FVector3d>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_origin(const FVector3d& Value) { Write<FVector3d>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Direction(const FVector3d& Value) { Write<FVector3d>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x18
struct FRay3f
{
public:
    FVector3f origin() const { return Read<FVector3f>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FVector3f Direction() const { return Read<FVector3f>(uintptr_t(this) + 0xc); } // 0xc (Size: 0xc, Type: StructProperty)

    void SET_origin(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_Direction(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0xc, Type: StructProperty)
};

// Size: 0x10
struct FRemoteObjectBytes
{
public:
    TArray<char> Bytes() const { return Read<TArray<char>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Bytes(const TArray<char>& Value) { Write<TArray<char>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FRemoteObjectData
{
public:
    FRemoteObjectTables Tables() const { return Read<FRemoteObjectTables>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    TArray<FPackedRemoteObjectPathName> PathNames() const { return Read<TArray<FPackedRemoteObjectPathName>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FRemoteObjectBytes> Bytes() const { return Read<TArray<FRemoteObjectBytes>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Tables(const FRemoteObjectTables& Value) { Write<FRemoteObjectTables>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_PathNames(const TArray<FPackedRemoteObjectPathName>& Value) { Write<TArray<FPackedRemoteObjectPathName>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_Bytes(const TArray<FRemoteObjectBytes>& Value) { Write<TArray<FRemoteObjectBytes>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FRemoteObjectTables
{
public:
    TArray<FName> Names() const { return Read<TArray<FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FRemoteObjectId> RemoteIds() const { return Read<TArray<FRemoteObjectId>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_Names(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_RemoteIds(const TArray<FRemoteObjectId>& Value) { Write<TArray<FRemoteObjectId>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FRemoteObjectId
{
public:
    uint64_t ID() const { return Read<uint64_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: UInt64Property)

    void SET_ID(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: UInt64Property)
};

// Size: 0x20
struct FRemoteObjectPathName : public FRemoteObjectTables
{
public:
};

// Size: 0x10
struct FRemoteObjectReference
{
public:
    FRemoteObjectId ObjectId() const { return Read<FRemoteObjectId>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FRemoteServerId ServerId() const { return Read<FRemoteServerId>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)

    void SET_ObjectId(const FRemoteObjectId& Value) { Write<FRemoteObjectId>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_ServerId(const FRemoteServerId& Value) { Write<FRemoteServerId>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
};

// Size: 0x4
struct FRemoteServerId
{
public:
    uint32_t ID() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)

    void SET_ID(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x4
struct FRemoteTransactionId
{
public:
    uint32_t ID() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)

    void SET_ID(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x8
struct FRemoteWorkPriority
{
public:
    uint64_t PackedData() const { return Read<uint64_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: UInt64Property)

    void SET_PackedData(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: UInt64Property)
};

// Size: 0x18
struct FRotator
{
public:
    double pitch() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Yaw() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Roll() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)

    void SET_pitch(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_Yaw(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_Roll(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x18
struct FRotator3d
{
public:
    double pitch() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Yaw() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Roll() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)

    void SET_pitch(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_Yaw(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_Roll(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0xc
struct FRotator3f
{
public:
    float pitch() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Yaw() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Roll() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_pitch(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Yaw(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Roll(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FSoftClassPath : public FSoftObjectPath
{
public:
};

// Size: 0x20
struct FSphere
{
public:
    FVector Center() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    double W() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)

    void SET_Center(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_W(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x20
struct FSphere3d
{
public:
    FVector3d Center() const { return Read<FVector3d>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    double W() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)

    void SET_Center(const FVector3d& Value) { Write<FVector3d>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_W(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x10
struct FSphere3f
{
public:
    FVector3f Center() const { return Read<FVector3f>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    float W() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_Center(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_W(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FTemplateString
{
public:
    FString Template() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FText Resolved() const { return Read<FText>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: TextProperty)

    void SET_Template(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Resolved(const FText& Value) { Write<FText>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: TextProperty)
};

// Size: 0x48
struct FTestUndeclaredScriptStructObjectReferencesTest
{
public:
    UObject* StrongObjectPointer() const { return Read<UObject*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UObject> SoftObjectPointer() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    FSoftObjectPath SoftObjectPath() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    TWeakObjectPtr<UObject*> WeakObjectPointer() const { return Read<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: WeakObjectProperty)

    void SET_StrongObjectPointer(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_SoftObjectPointer(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SoftObjectPath(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_WeakObjectPointer(const TWeakObjectPtr<UObject*>& Value) { Write<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x18
struct FTestUninitializedScriptStructMembersTest
{
public:
    UObject* UninitializedObjectReference() const { return Read<UObject*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UObject* InitializedObjectReference() const { return Read<UObject*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    float UnusedValue() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_UninitializedObjectReference(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_InitializedObjectReference(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_UnusedValue(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FTimecode
{
public:
    int32_t Hours() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Minutes() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t Seconds() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t Frames() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    float SubFrame() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    bool bDropFrameFormat() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)

    void SET_Hours(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Minutes(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_Seconds(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_Frames(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_SubFrame(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_bDropFrameFormat(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x8
struct FTimespan
{
public:
    int64_t Ticks() const { return Read<int64_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: Int64Property)

    void SET_Ticks(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: Int64Property)
};

// Size: 0x60
struct FTransform
{
public:
    FQuat Rotation() const { return Read<FQuat>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    FVector Translation() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector Scale3D() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)

    void SET_Rotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_Translation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Scale3D(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
};

// Size: 0x60
struct FTransform3d
{
public:
    FQuat4d Rotation() const { return Read<FQuat4d>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    FVector3d Translation() const { return Read<FVector3d>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector3d Scale3D() const { return Read<FVector3d>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)

    void SET_Rotation(const FQuat4d& Value) { Write<FQuat4d>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_Translation(const FVector3d& Value) { Write<FVector3d>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Scale3D(const FVector3d& Value) { Write<FVector3d>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
};

// Size: 0x30
struct FTransform3f
{
public:
    FQuat4f Rotation() const { return Read<FQuat4f>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FVector3f Translation() const { return Read<FVector3f>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    FVector3f Scale3D() const { return Read<FVector3f>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0xc, Type: StructProperty)

    void SET_Rotation(const FQuat4f& Value) { Write<FQuat4f>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_Translation(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_Scale3D(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0xc, Type: StructProperty)
};

// Size: 0x8
struct FUint32Point
{
public:
    int32_t X() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_X(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Y(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FUint32Rect
{
public:
    FUint32Point Min() const { return Read<FUint32Point>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FUint32Point Max() const { return Read<FUint32Point>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)

    void SET_Min(const FUint32Point& Value) { Write<FUint32Point>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_Max(const FUint32Point& Value) { Write<FUint32Point>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
};

// Size: 0xc
struct FUint32Vector
{
public:
    uint32_t X() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t Y() const { return Read<uint32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: UInt32Property)
    uint32_t Z() const { return Read<uint32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: UInt32Property)

    void SET_X(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
    void SET_Y(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: UInt32Property)
    void SET_Z(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x8
struct FUint32Vector2
{
public:
    uint32_t X() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t Y() const { return Read<uint32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: UInt32Property)

    void SET_X(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
    void SET_Y(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x10
struct FUint32Vector4
{
public:
    uint32_t X() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t Y() const { return Read<uint32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: UInt32Property)
    uint32_t Z() const { return Read<uint32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: UInt32Property)
    uint32_t W() const { return Read<uint32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: UInt32Property)

    void SET_X(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
    void SET_Y(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: UInt32Property)
    void SET_Z(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: UInt32Property)
    void SET_W(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: UInt32Property)
};

// Size: 0x10
struct FUint64Point
{
public:
    int64_t X() const { return Read<int64_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: Int64Property)
    int64_t Y() const { return Read<int64_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: Int64Property)

    void SET_X(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: Int64Property)
    void SET_Y(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: Int64Property)
};

// Size: 0x20
struct FUint64Rect
{
public:
    FUint64Point Min() const { return Read<FUint64Point>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FUint64Point Max() const { return Read<FUint64Point>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_Min(const FUint64Point& Value) { Write<FUint64Point>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_Max(const FUint64Point& Value) { Write<FUint64Point>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x18
struct FUint64Vector
{
public:
    uint64_t X() const { return Read<uint64_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: UInt64Property)
    uint64_t Y() const { return Read<uint64_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: UInt64Property)
    uint64_t Z() const { return Read<uint64_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: UInt64Property)

    void SET_X(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: UInt64Property)
    void SET_Y(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: UInt64Property)
    void SET_Z(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: UInt64Property)
};

// Size: 0x10
struct FUint64Vector2
{
public:
    uint64_t X() const { return Read<uint64_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: UInt64Property)
    uint64_t Y() const { return Read<uint64_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: UInt64Property)

    void SET_X(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: UInt64Property)
    void SET_Y(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: UInt64Property)
};

// Size: 0x20
struct FUint64Vector4
{
public:
    uint64_t X() const { return Read<uint64_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: UInt64Property)
    uint64_t Y() const { return Read<uint64_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: UInt64Property)
    uint64_t Z() const { return Read<uint64_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: UInt64Property)
    uint64_t W() const { return Read<uint64_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: UInt64Property)

    void SET_X(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: UInt64Property)
    void SET_Y(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: UInt64Property)
    void SET_Z(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: UInt64Property)
    void SET_W(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: UInt64Property)
};

// Size: 0x8
struct FUintPoint
{
public:
    int32_t X() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_X(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Y(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FUintRect
{
public:
    FUintPoint Min() const { return Read<FUintPoint>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FUintPoint Max() const { return Read<FUintPoint>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)

    void SET_Min(const FUintPoint& Value) { Write<FUintPoint>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_Max(const FUintPoint& Value) { Write<FUintPoint>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
};

// Size: 0xc
struct FUintVector
{
public:
    uint32_t X() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t Y() const { return Read<uint32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: UInt32Property)
    uint32_t Z() const { return Read<uint32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: UInt32Property)

    void SET_X(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
    void SET_Y(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: UInt32Property)
    void SET_Z(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x8
struct FUintVector2
{
public:
    uint32_t X() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t Y() const { return Read<uint32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: UInt32Property)

    void SET_X(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
    void SET_Y(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x10
struct FUintVector4
{
public:
    uint32_t X() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t Y() const { return Read<uint32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: UInt32Property)
    uint32_t Z() const { return Read<uint32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: UInt32Property)
    uint32_t W() const { return Read<uint32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: UInt32Property)

    void SET_X(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
    void SET_Y(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: UInt32Property)
    void SET_Z(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: UInt32Property)
    void SET_W(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: UInt32Property)
};

// Size: 0x20
struct FVector4
{
public:
    double X() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Y() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Z() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    double W() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)

    void SET_X(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_Y(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_Z(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    void SET_W(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x20
struct FVector4d
{
public:
    double X() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Y() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Z() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    double W() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)

    void SET_X(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_Y(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_Z(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    void SET_W(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x10
struct FVector4f
{
public:
    float X() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Y() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Z() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float W() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_X(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Y(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Z(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_W(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FInstancedStruct
{
public:
};

// Size: 0x10
struct FSharedStruct
{
public:
};

// Size: 0x10
struct FInstancedPropertyBag
{
public:
    FInstancedStruct Value() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)

    void SET_Value(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x10
struct FConstSharedStruct
{
public:
};

// Size: 0x10
struct FOverriddenPropertyNodeID
{
public:
    FName Path() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    UObject* Object() const { return Read<UObject*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Path(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Object(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x68
struct FOverriddenPropertyNode
{
public:
    FOverriddenPropertyNodeID NodeId() const { return Read<FOverriddenPropertyNodeID>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    uint8_t Operation() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    TMap<FOverriddenPropertyNodeID, FOverriddenPropertyNodeID> SubPropertyNodeKeys() const { return Read<TMap<FOverriddenPropertyNodeID, FOverriddenPropertyNodeID>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x50, Type: MapProperty)

    void SET_NodeId(const FOverriddenPropertyNodeID& Value) { Write<FOverriddenPropertyNodeID>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_Operation(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_SubPropertyNodeKeys(const TMap<FOverriddenPropertyNodeID, FOverriddenPropertyNodeID>& Value) { Write<TMap<FOverriddenPropertyNodeID, FOverriddenPropertyNodeID>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x50, Type: MapProperty)
};

// Size: 0x68
struct FOverriddenPropertySet
{
public:
    UObject* Owner() const { return Read<UObject*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bWasAdded() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    TSet<FOverriddenPropertyNode> OverriddenPropertyNodes() const { return Read<TSet<FOverriddenPropertyNode>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x50, Type: SetProperty)

    void SET_Owner(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_bWasAdded(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_OverriddenPropertyNodes(const TSet<FOverriddenPropertyNode>& Value) { Write<TSet<FOverriddenPropertyNode>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x50, Type: SetProperty)
};

// Size: 0x18
struct FPropertyTextFName
{
public:
};

// Size: 0x20
struct FPropertyTextString
{
public:
};

// Size: 0x30
struct FProfileLocus
{
public:
};

// Size: 0x38
struct FSolarisProfilingData
{
public:
};

// Size: 0x10
struct FInstancedStructContainer
{
public:
};

// Size: 0x3
struct FPropertyBagContainerTypes
{
public:
};

// Size: 0x18
struct FPropertyBagPropertyDescMetaData
{
public:
    FName Key() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FString Value() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)

    void SET_Key(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Value(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x38
struct FPropertyBagPropertyDesc
{
public:
    UObject* ValueTypeObject() const { return Read<UObject*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGuid ID() const { return Read<FGuid>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)
    uint8_t ValueType() const { return Read<uint8_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: EnumProperty)
    FPropertyBagContainerTypes ContainerTypes() const { return Read<FPropertyBagContainerTypes>(uintptr_t(this) + 0x1d); } // 0x1d (Size: 0x3, Type: StructProperty)
    uint64_t PropertyFlags() const { return Read<uint64_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: UInt64Property)

    void SET_ValueTypeObject(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
    void SET_ValueType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: EnumProperty)
    void SET_ContainerTypes(const FPropertyBagContainerTypes& Value) { Write<FPropertyBagContainerTypes>(uintptr_t(this) + 0x1d, Value); } // 0x1d (Size: 0x3, Type: StructProperty)
    void SET_PropertyFlags(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: UInt64Property)
};

// Size: 0x1
struct FPropertyBagMissingStruct
{
public:
};

// Size: 0x50
struct FObjectCookedMetaDataStore
{
public:
    TMap<FString, FName> ObjectMetaData() const { return Read<TMap<FString, FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_ObjectMetaData(const TMap<FString, FName>& Value) { Write<TMap<FString, FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x10
struct FFieldCookedMetaDataKey
{
public:
    TArray<FName> FieldPath() const { return Read<TArray<FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_FieldPath(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
struct FFieldCookedMetaDataValue
{
public:
    TMap<FString, FName> MetaData() const { return Read<TMap<FString, FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_MetaData(const TMap<FString, FName>& Value) { Write<TMap<FString, FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0xa0
struct FFieldCookedMetaDataStore
{
public:
    TMap<FString, FName> FieldMetaData() const { return Read<TMap<FString, FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)
    TMap<FFieldCookedMetaDataValue, FFieldCookedMetaDataKey> SubFieldMetaData() const { return Read<TMap<FFieldCookedMetaDataValue, FFieldCookedMetaDataKey>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x50, Type: MapProperty)

    void SET_FieldMetaData(const TMap<FString, FName>& Value) { Write<TMap<FString, FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
    void SET_SubFieldMetaData(const TMap<FFieldCookedMetaDataValue, FFieldCookedMetaDataKey>& Value) { Write<TMap<FFieldCookedMetaDataValue, FFieldCookedMetaDataKey>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x50, Type: MapProperty)
};

// Size: 0xa0
struct FStructCookedMetaDataStore
{
public:
    FObjectCookedMetaDataStore ObjectMetaData() const { return Read<FObjectCookedMetaDataStore>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: StructProperty)
    TMap<FFieldCookedMetaDataStore, FName> PropertiesMetaData() const { return Read<TMap<FFieldCookedMetaDataStore, FName>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x50, Type: MapProperty)

    void SET_ObjectMetaData(const FObjectCookedMetaDataStore& Value) { Write<FObjectCookedMetaDataStore>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: StructProperty)
    void SET_PropertiesMetaData(const TMap<FFieldCookedMetaDataStore, FName>& Value) { Write<TMap<FFieldCookedMetaDataStore, FName>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x50, Type: MapProperty)
};

// Size: 0x4
struct FPerPlatformInt
{
public:
    int32_t Default() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)

    void SET_Default(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x4
struct FFreezablePerPlatformInt
{
public:
};

// Size: 0x4
struct FPerPlatformFloat
{
public:
    float Default() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)

    void SET_Default(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x1
struct FPerPlatformBool
{
public:
    bool Default() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)

    void SET_Default(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x8
struct FPerPlatformFrameRate
{
public:
    FFrameRate Default() const { return Read<FFrameRate>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)

    void SET_Default(const FFrameRate& Value) { Write<FFrameRate>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
};

// Size: 0x30
struct FVersePersistentVar
{
public:
    FString Path() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)

    void SET_Path(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x20
struct FVerseSessionVar
{
public:
};

// Size: 0x10
struct FVerseClassVarAccessor
{
public:
    UFunction* Func() const { return Read<UFunction*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bIsInstanceMember() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bIsFallible() const { return Read<bool>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: BoolProperty)

    void SET_Func(const UFunction*& Value) { Write<UFunction*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsInstanceMember(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_bIsFallible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa0
struct FVerseClassVarAccessors
{
public:
    TMap<FVerseClassVarAccessor, int32_t> Getters() const { return Read<TMap<FVerseClassVarAccessor, int32_t>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)
    TMap<FVerseClassVarAccessor, int32_t> Setters() const { return Read<TMap<FVerseClassVarAccessor, int32_t>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x50, Type: MapProperty)

    void SET_Getters(const TMap<FVerseClassVarAccessor, int32_t>& Value) { Write<TMap<FVerseClassVarAccessor, int32_t>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
    void SET_Setters(const TMap<FVerseClassVarAccessor, int32_t>& Value) { Write<TMap<FVerseClassVarAccessor, int32_t>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x50, Type: MapProperty)
};

