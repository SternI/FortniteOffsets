/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FrontEnd
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "InputCore.h"
#include "FortniteGame.h"
#include "SubtitlesWidgets.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "MediaAssets.h"

// Size: 0xa98
class AVaultCamera_Blueprint_C : public AFortCameraBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xa90); } // 0xa90 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xa90, Value); } // 0xa90 (Size: 0x8, Type: StructProperty)
};

// Size: 0xb40
class AStoreCamera_Blueprint_C : public AFortCameraBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xa90); } // 0xa90 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* Mesh_DarkenBG() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0xa98); } // 0xa98 (Size: 0x8, Type: ObjectProperty)
    UCameraComponent* CameraPlaceholderGround() const { return Read<UCameraComponent*>(uintptr_t(this) + 0xaa0); } // 0xaa0 (Size: 0x8, Type: ObjectProperty)
    float ChoicePack_NewTrack_0_ACA3841D4D5084BE3482FA8EBB7CE9C0() const { return Read<float>(uintptr_t(this) + 0xaa8); } // 0xaa8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> ChoicePack__Direction_ACA3841D4D5084BE3482FA8EBB7CE9C0() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xaac); } // 0xaac (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* ChoicePack() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0xab0); } // 0xab0 (Size: 0x8, Type: ObjectProperty)
    float Timeline_0_NewTrack_0_6555812E4B246E6144D3C99FC49F7FE9() const { return Read<float>(uintptr_t(this) + 0xab8); } // 0xab8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_0__Direction_6555812E4B246E6144D3C99FC49F7FE9() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xabc); } // 0xabc (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Timeline_0() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0xac0); } // 0xac0 (Size: 0x8, Type: ObjectProperty)
    FVector CameraGroundLoc() const { return Read<FVector>(uintptr_t(this) + 0xac8); } // 0xac8 (Size: 0x18, Type: StructProperty)
    FRotator CameraGroundRot() const { return Read<FRotator>(uintptr_t(this) + 0xae0); } // 0xae0 (Size: 0x18, Type: StructProperty)
    FVector CameraOriginalLoc() const { return Read<FVector>(uintptr_t(this) + 0xaf8); } // 0xaf8 (Size: 0x18, Type: StructProperty)
    FRotator CameraOriginalRot() const { return Read<FRotator>(uintptr_t(this) + 0xb10); } // 0xb10 (Size: 0x18, Type: StructProperty)
    bool CameraInStartPos() const { return Read<bool>(uintptr_t(this) + 0xb28); } // 0xb28 (Size: 0x1, Type: BoolProperty)
    AStorePinataMaster_Parent_C* PinataInLevel() const { return Read<AStorePinataMaster_Parent_C*>(uintptr_t(this) + 0xb30); } // 0xb30 (Size: 0x8, Type: ObjectProperty)
    AStoreCardReveal_Parent_C* CardRevealInLevel() const { return Read<AStoreCardReveal_Parent_C*>(uintptr_t(this) + 0xb38); } // 0xb38 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xa90, Value); } // 0xa90 (Size: 0x8, Type: StructProperty)
    void SET_Mesh_DarkenBG(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0xa98, Value); } // 0xa98 (Size: 0x8, Type: ObjectProperty)
    void SET_CameraPlaceholderGround(const UCameraComponent*& Value) { Write<UCameraComponent*>(uintptr_t(this) + 0xaa0, Value); } // 0xaa0 (Size: 0x8, Type: ObjectProperty)
    void SET_ChoicePack_NewTrack_0_ACA3841D4D5084BE3482FA8EBB7CE9C0(const float& Value) { Write<float>(uintptr_t(this) + 0xaa8, Value); } // 0xaa8 (Size: 0x4, Type: FloatProperty)
    void SET_ChoicePack__Direction_ACA3841D4D5084BE3482FA8EBB7CE9C0(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xaac, Value); } // 0xaac (Size: 0x1, Type: ByteProperty)
    void SET_ChoicePack(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0xab0, Value); } // 0xab0 (Size: 0x8, Type: ObjectProperty)
    void SET_Timeline_0_NewTrack_0_6555812E4B246E6144D3C99FC49F7FE9(const float& Value) { Write<float>(uintptr_t(this) + 0xab8, Value); } // 0xab8 (Size: 0x4, Type: FloatProperty)
    void SET_Timeline_0__Direction_6555812E4B246E6144D3C99FC49F7FE9(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xabc, Value); } // 0xabc (Size: 0x1, Type: ByteProperty)
    void SET_Timeline_0(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0xac0, Value); } // 0xac0 (Size: 0x8, Type: ObjectProperty)
    void SET_CameraGroundLoc(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xac8, Value); } // 0xac8 (Size: 0x18, Type: StructProperty)
    void SET_CameraGroundRot(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0xae0, Value); } // 0xae0 (Size: 0x18, Type: StructProperty)
    void SET_CameraOriginalLoc(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xaf8, Value); } // 0xaf8 (Size: 0x18, Type: StructProperty)
    void SET_CameraOriginalRot(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0xb10, Value); } // 0xb10 (Size: 0x18, Type: StructProperty)
    void SET_CameraInStartPos(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb28, Value); } // 0xb28 (Size: 0x1, Type: BoolProperty)
    void SET_PinataInLevel(const AStorePinataMaster_Parent_C*& Value) { Write<AStorePinataMaster_Parent_C*>(uintptr_t(this) + 0xb30, Value); } // 0xb30 (Size: 0x8, Type: ObjectProperty)
    void SET_CardRevealInLevel(const AStoreCardReveal_Parent_C*& Value) { Write<AStoreCardReveal_Parent_C*>(uintptr_t(this) + 0xb38, Value); } // 0xb38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2b8
class AStoreCardReveal_Parent_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    USceneComponent* PinataSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    void SET_PinataSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2d0
class AFrontEndSettingsBP_C : public AFrontEndSettings
{
public:
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)

    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2e0
class AHBOnboardingFlow_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UFortQuestItemDefinition_Campaign* PlayPeriodicEventMovieQuest() const { return Read<UFortQuestItemDefinition_Campaign*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    bool bPlayedPeriodicEventMovie() const { return Read<bool>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x1, Type: BoolProperty)
    bool bHasRecheckedNeedToPlayPeriodicEventMovie() const { return Read<bool>(uintptr_t(this) + 0x2c1); } // 0x2c1 (Size: 0x1, Type: BoolProperty)
    FDataTableRowHandle PlayPeriodicEventCineObjective() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x10, Type: StructProperty)
    UClass* PeriodicEventMovieAnnouncementClass() const { return Read<UClass*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ClassProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayPeriodicEventMovieQuest(const UFortQuestItemDefinition_Campaign*& Value) { Write<UFortQuestItemDefinition_Campaign*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_bPlayedPeriodicEventMovie(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x1, Type: BoolProperty)
    void SET_bHasRecheckedNeedToPlayPeriodicEventMovie(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c1, Value); } // 0x2c1 (Size: 0x1, Type: BoolProperty)
    void SET_PlayPeriodicEventCineObjective(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x10, Type: StructProperty)
    void SET_PeriodicEventMovieAnnouncementClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x2b8
class AStorePinataMaster_Parent_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    USceneComponent* PinataSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    void SET_PinataSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x350
class AAnnounce_EventCine_C : public AFortClientAnnouncement_Cinematic
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: StructProperty)
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    UMediaSource* EventMediaSource() const { return Read<UMediaSource*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    bool AllowSkipping() const { return Read<bool>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x1, Type: BoolProperty)
    UFortMediaSubtitlesPlayer* EventSubtitlesPlayer() const { return Read<UFortMediaSubtitlesPlayer*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: StructProperty)
    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_EventMediaSource(const UMediaSource*& Value) { Write<UMediaSource*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_AllowSkipping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x1, Type: BoolProperty)
    void SET_EventSubtitlesPlayer(const UFortMediaSubtitlesPlayer*& Value) { Write<UFortMediaSubtitlesPlayer*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xaa8
class ALoginCamera_Blueprint_C : public AFortCameraBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xa90); } // 0xa90 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* StaticMesh() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0xa98); } // 0xa98 (Size: 0x8, Type: ObjectProperty)
    UCameraComponent* LoginCamera_0() const { return Read<UCameraComponent*>(uintptr_t(this) + 0xaa0); } // 0xaa0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xa90, Value); } // 0xa90 (Size: 0x8, Type: StructProperty)
    void SET_StaticMesh(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0xa98, Value); } // 0xa98 (Size: 0x8, Type: ObjectProperty)
    void SET_LoginCamera_0(const UCameraComponent*& Value) { Write<UCameraComponent*>(uintptr_t(this) + 0xaa0, Value); } // 0xaa0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x3890
class AFrontEnd_PlayerController_C : public AFortPlayerControllerFrontEnd
{
public:
};

// Size: 0xaa8
class AHeroesCamera_Blueprint_C : public AFortCameraBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xa90); } // 0xa90 (Size: 0x8, Type: StructProperty)
    bool MouseDown() const { return Read<bool>(uintptr_t(this) + 0xa98); } // 0xa98 (Size: 0x1, Type: BoolProperty)
    AFortPlayerPawn* Cached_Pawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xaa0); } // 0xaa0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xa90, Value); } // 0xa90 (Size: 0x8, Type: StructProperty)
    void SET_MouseDown(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa98, Value); } // 0xa98 (Size: 0x1, Type: BoolProperty)
    void SET_Cached_Pawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xaa0, Value); } // 0xaa0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x810
class AFrontEnd_GameMode_C : public AFortGameModeFrontEnd
{
public:
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x808); } // 0x808 (Size: 0x8, Type: ObjectProperty)

    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x808, Value); } // 0x808 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x350
class AAnnounce_Storm2018Cine_C : public AAnnounce_EventCine_C
{
public:
};

// Size: 0xa98
class ASpecialEventsCamera_Blueprint_C : public AFortCameraBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xa90); } // 0xa90 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xa90, Value); } // 0xa90 (Size: 0x8, Type: StructProperty)
};

