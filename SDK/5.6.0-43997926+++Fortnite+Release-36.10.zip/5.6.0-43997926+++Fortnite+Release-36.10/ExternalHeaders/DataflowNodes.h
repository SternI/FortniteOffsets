/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataflowNodes
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "DataflowEnginePlugin.h"
#include "Chaos.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x10
struct FDataflowFunctionProperty
{
public:
};

// Size: 0x280
struct FDataflowPrimitiveNode : public FDataflowNode
{
public:
};

// Size: 0x4
struct FScalarVertexPropertyGroup
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
};

// Size: 0x378
struct FDataflowCollectionAddScalarVertexPropertyNode : public FDataflowNode
{
public:
    FManagedArrayCollection Collection() const { return Read<FManagedArrayCollection>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0xb0, Type: StructProperty)
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x10, Type: StrProperty)
    FCollectionAttributeKey AttributeKey() const { return Read<FCollectionAttributeKey>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x20, Type: StructProperty)
    TArray<float> VertexWeights() const { return Read<TArray<float>>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x10, Type: ArrayProperty)
    FScalarVertexPropertyGroup TargetGroup() const { return Read<FScalarVertexPropertyGroup>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x4, Type: StructProperty)
    uint8_t OverrideType() const { return Read<uint8_t>(uintptr_t(this) + 0x374); } // 0x374 (Size: 0x1, Type: EnumProperty)

    void SET_Collection(const FManagedArrayCollection& Value) { Write<FManagedArrayCollection>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0xb0, Type: StructProperty)
    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x10, Type: StrProperty)
    void SET_AttributeKey(const FCollectionAttributeKey& Value) { Write<FCollectionAttributeKey>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x20, Type: StructProperty)
    void SET_VertexWeights(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x10, Type: ArrayProperty)
    void SET_TargetGroup(const FScalarVertexPropertyGroup& Value) { Write<FScalarVertexPropertyGroup>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x4, Type: StructProperty)
    void SET_OverrideType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x374, Value); } // 0x374 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x2c0
struct FMakeAttributeKeyDataflowNode : public FDataflowNode
{
public:
    FString GroupIn() const { return Read<FString>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: StrProperty)
    FString AttributeIn() const { return Read<FString>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x10, Type: StrProperty)
    FCollectionAttributeKey AttributeKeyOut() const { return Read<FCollectionAttributeKey>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x20, Type: StructProperty)

    void SET_GroupIn(const FString& Value) { Write<FString>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: StrProperty)
    void SET_AttributeIn(const FString& Value) { Write<FString>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x10, Type: StrProperty)
    void SET_AttributeKeyOut(const FCollectionAttributeKey& Value) { Write<FCollectionAttributeKey>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x2c0
struct FBreakAttributeKeyDataflowNode : public FDataflowNode
{
public:
    FCollectionAttributeKey AttributeKeyIn() const { return Read<FCollectionAttributeKey>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x20, Type: StructProperty)
    FString AttributeOut() const { return Read<FString>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x10, Type: StrProperty)
    FString GroupOut() const { return Read<FString>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x10, Type: StrProperty)

    void SET_AttributeKeyIn(const FCollectionAttributeKey& Value) { Write<FCollectionAttributeKey>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x20, Type: StructProperty)
    void SET_AttributeOut(const FString& Value) { Write<FString>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x10, Type: StrProperty)
    void SET_GroupOut(const FString& Value) { Write<FString>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x20
struct FDataflowSkinWeightData
{
public:
    TArray<float> BoneWeights() const { return Read<TArray<float>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> BoneIndices() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_BoneWeights(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_BoneIndices(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x3e8
struct FDataflowCollectionEditSkinWeightsNode : public FDataflowPrimitiveNode
{
public:
    FManagedArrayCollection Collection() const { return Read<FManagedArrayCollection>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0xb0, Type: StructProperty)
    FString BoneIndicesName() const { return Read<FString>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x10, Type: StrProperty)
    FString BoneWeightsName() const { return Read<FString>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x10, Type: StrProperty)
    FScalarVertexPropertyGroup VertexGroup() const { return Read<FScalarVertexPropertyGroup>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x4, Type: StructProperty)
    FCollectionAttributeKey BoneIndicesKey() const { return Read<FCollectionAttributeKey>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x20, Type: StructProperty)
    FCollectionAttributeKey BoneWeightsKey() const { return Read<FCollectionAttributeKey>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x20, Type: StructProperty)
    USkeleton* ObjectSkeleton() const { return Read<USkeleton*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    bool bCompressSkinWeights() const { return Read<bool>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x1, Type: BoolProperty)
    TArray<FDataflowSkinWeightData> SkinWeights() const { return Read<TArray<FDataflowSkinWeightData>>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x10, Type: ArrayProperty)
    TArray<USkeletalMesh*> SkeletalMeshes() const { return Read<TArray<USkeletalMesh*>>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x10, Type: ArrayProperty)

    void SET_Collection(const FManagedArrayCollection& Value) { Write<FManagedArrayCollection>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0xb0, Type: StructProperty)
    void SET_BoneIndicesName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x10, Type: StrProperty)
    void SET_BoneWeightsName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x10, Type: StrProperty)
    void SET_VertexGroup(const FScalarVertexPropertyGroup& Value) { Write<FScalarVertexPropertyGroup>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x4, Type: StructProperty)
    void SET_BoneIndicesKey(const FCollectionAttributeKey& Value) { Write<FCollectionAttributeKey>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x20, Type: StructProperty)
    void SET_BoneWeightsKey(const FCollectionAttributeKey& Value) { Write<FCollectionAttributeKey>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x20, Type: StructProperty)
    void SET_ObjectSkeleton(const USkeleton*& Value) { Write<USkeleton*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    void SET_bCompressSkinWeights(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x1, Type: BoolProperty)
    void SET_SkinWeights(const TArray<FDataflowSkinWeightData>& Value) { Write<TArray<FDataflowSkinWeightData>>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x10, Type: ArrayProperty)
    void SET_SkeletalMeshes(const TArray<USkeletalMesh*>& Value) { Write<TArray<USkeletalMesh*>>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x290
struct FFloatOverrideDataflowNode : public FDataflowNode
{
public:
    FName PropertyName() const { return Read<FName>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x4, Type: NameProperty)
    FName KeyName() const { return Read<FName>(uintptr_t(this) + 0x284); } // 0x284 (Size: 0x4, Type: NameProperty)
    float ValueOut() const { return Read<float>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x4, Type: FloatProperty)

    void SET_PropertyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x4, Type: NameProperty)
    void SET_KeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x284, Value); } // 0x284 (Size: 0x4, Type: NameProperty)
    void SET_ValueOut(const float& Value) { Write<float>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x2a0
struct FSelectionSetDataflowNode : public FDataflowNode
{
public:
    FString Indices() const { return Read<FString>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x10, Type: StrProperty)
    TArray<int32_t> IndicesOut() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x10, Type: ArrayProperty)

    void SET_Indices(const FString& Value) { Write<FString>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x10, Type: StrProperty)
    void SET_IndicesOut(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x290
struct FGetSkeletalMeshDataflowNode : public FDataflowNode
{
public:
    USkeletalMesh* SkeletalMesh() const { return Read<USkeletalMesh*>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x8, Type: ObjectProperty)
    FName PropertyName() const { return Read<FName>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x4, Type: NameProperty)

    void SET_SkeletalMesh(const USkeletalMesh*& Value) { Write<USkeletalMesh*>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x8, Type: ObjectProperty)
    void SET_PropertyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x4, Type: NameProperty)
};

// Size: 0x290
struct FGetSkeletonDataflowNode : public FDataflowNode
{
public:
    USkeleton* Skeleton() const { return Read<USkeleton*>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x8, Type: ObjectProperty)
    FName PropertyName() const { return Read<FName>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x4, Type: NameProperty)

    void SET_Skeleton(const USkeleton*& Value) { Write<USkeleton*>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x8, Type: ObjectProperty)
    void SET_PropertyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x4, Type: NameProperty)
};

// Size: 0x298
struct FSkeletalMeshBoneDataflowNode : public FDataflowNode
{
public:
    FName BoneName() const { return Read<FName>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x4, Type: NameProperty)
    USkeletalMesh* SkeletalMesh() const { return Read<USkeletalMesh*>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x8, Type: ObjectProperty)
    int32_t BoneIndexOut() const { return Read<int32_t>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x4, Type: IntProperty)
    FName PropertyName() const { return Read<FName>(uintptr_t(this) + 0x294); } // 0x294 (Size: 0x4, Type: NameProperty)

    void SET_BoneName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x4, Type: NameProperty)
    void SET_SkeletalMesh(const USkeletalMesh*& Value) { Write<USkeletalMesh*>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x8, Type: ObjectProperty)
    void SET_BoneIndexOut(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x4, Type: IntProperty)
    void SET_PropertyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x294, Value); } // 0x294 (Size: 0x4, Type: NameProperty)
};

// Size: 0x2f0
struct FSkeletalMeshReferenceTransformDataflowNode : public FDataflowNode
{
public:
    USkeletalMesh* SkeletalMeshIn() const { return Read<USkeletalMesh*>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x8, Type: ObjectProperty)
    int32_t BoneIndexIn() const { return Read<int32_t>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x4, Type: IntProperty)
    FTransform TransformOut() const { return Read<FTransform>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x60, Type: StructProperty)

    void SET_SkeletalMeshIn(const USkeletalMesh*& Value) { Write<USkeletalMesh*>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x8, Type: ObjectProperty)
    void SET_BoneIndexIn(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x4, Type: IntProperty)
    void SET_TransformOut(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x60, Type: StructProperty)
};

// Size: 0x290
struct FGetPhysicsAssetFromSkeletalMeshDataflowNode : public FDataflowNode
{
public:
    USkeletalMesh* SkeletalMesh() const { return Read<USkeletalMesh*>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x8, Type: ObjectProperty)
    UPhysicsAsset* PhysicsAsset() const { return Read<UPhysicsAsset*>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x8, Type: ObjectProperty)

    void SET_SkeletalMesh(const USkeletalMesh*& Value) { Write<USkeletalMesh*>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x8, Type: ObjectProperty)
    void SET_PhysicsAsset(const UPhysicsAsset*& Value) { Write<UPhysicsAsset*>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x290
struct FGetStaticMeshDataflowNode : public FDataflowNode
{
public:
    UStaticMesh* StaticMesh() const { return Read<UStaticMesh*>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x8, Type: ObjectProperty)
    FName PropertyName() const { return Read<FName>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x4, Type: NameProperty)

    void SET_StaticMesh(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x8, Type: ObjectProperty)
    void SET_PropertyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x4, Type: NameProperty)
};

