/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortGameplayStateMachine
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"

// Size: 0x88
class UFortGameplayState : public UGameplayState
{
public:
    FText StateDisplayName() const { return Read<FText>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: TextProperty)

    void SET_StateDisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: TextProperty)
};

// Size: 0xf0
class UFortGameplayStateMachine : public UGameplayStateMachine
{
public:
    FFortGameplayStateTransitionData RootTransitionData() const { return Read<FFortGameplayStateTransitionData>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x18, Type: StructProperty)

    void SET_RootTransitionData(const FFortGameplayStateTransitionData& Value) { Write<FFortGameplayStateTransitionData>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x1d8
class UFortGameplayStateMachineManager : public UGameplayStateMachineManager
{
public:
};

// Size: 0x10
struct FFortGameplayStateChanged
{
public:
    UFortGameplayStateMachine* StateMachine() const { return Read<UFortGameplayStateMachine*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag OldStateId() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    FGameplayTag NewStateId() const { return Read<FGameplayTag>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: StructProperty)

    void SET_StateMachine(const UFortGameplayStateMachine*& Value) { Write<UFortGameplayStateMachine*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_OldStateId(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_NewStateId(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: StructProperty)
};

// Size: 0x10
struct FFortLeafGameplayStateChanged
{
public:
    UFortGameplayStateMachine* RootStateMachine() const { return Read<UFortGameplayStateMachine*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag OldLeafStateId() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    FGameplayTag NewLeafStateId() const { return Read<FGameplayTag>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: StructProperty)

    void SET_RootStateMachine(const UFortGameplayStateMachine*& Value) { Write<UFortGameplayStateMachine*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_OldLeafStateId(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_NewLeafStateId(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: StructProperty)
};

// Size: 0x18
struct FFortGameplayStateTransitionData
{
public:
    UFortGameplayStateMachine* TargetStateMachine() const { return Read<UFortGameplayStateMachine*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag TargetStateId() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    float TransitionStartServerTime() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float TransitionEndServerTime() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_TargetStateMachine(const UFortGameplayStateMachine*& Value) { Write<UFortGameplayStateMachine*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetStateId(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_TransitionStartServerTime(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_TransitionEndServerTime(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FRootStateMachineData
{
public:
};

// Size: 0x18
struct FFortGameplayStateTransitionStarted : public FFortGameplayStateTransitionData
{
public:
};

// Size: 0x1
struct FFortGameplayStateTransitionEnded
{
public:
};

