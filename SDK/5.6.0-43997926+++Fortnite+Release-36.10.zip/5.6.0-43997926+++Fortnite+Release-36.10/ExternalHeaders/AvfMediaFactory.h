/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AvfMediaFactory
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
// Size: 0x30
class UAvfMediaSettings : public UObject
{
public:
    bool NativeAudioOut() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)

    void SET_NativeAudioOut(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
};

