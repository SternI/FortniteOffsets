/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_GameStreamRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"

// Size: 0xc8
class UCreativeGameStreamDeviceComponent : public UActorComponent
{
public:
    uint8_t OnTriggered() const { return Read<uint8_t>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: MulticastSparseDelegateProperty)
    TWeakObjectPtr<UFortMinigameLogicComponent*> MinigameLogicComponent() const { return Read<TWeakObjectPtr<UFortMinigameLogicComponent*>>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x8, Type: WeakObjectProperty)

    void SET_OnTriggered(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: MulticastSparseDelegateProperty)
    void SET_MinigameLogicComponent(const TWeakObjectPtr<UFortMinigameLogicComponent*>& Value) { Write<TWeakObjectPtr<UFortMinigameLogicComponent*>>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xd0
class UCreativeGameStreamDeviceCoordinatorComponent : public UPlayspaceComponent
{
public:
    TArray<TWeakObjectPtr<UCreativeGameStreamDeviceComponent*>> EndGameCreativeGameStreamDeviceComponentQueue() const { return Read<TArray<TWeakObjectPtr<UCreativeGameStreamDeviceComponent*>>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<AFortMinigame*> Minigame() const { return Read<TWeakObjectPtr<AFortMinigame*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_EndGameCreativeGameStreamDeviceComponentQueue(const TArray<TWeakObjectPtr<UCreativeGameStreamDeviceComponent*>>& Value) { Write<TArray<TWeakObjectPtr<UCreativeGameStreamDeviceComponent*>>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    void SET_Minigame(const TWeakObjectPtr<AFortMinigame*>& Value) { Write<TWeakObjectPtr<AFortMinigame*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
};

