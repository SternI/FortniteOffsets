/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ClothingSystemRuntimeInterface
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x38
class UClothingAssetBase : public UObject
{
public:
    FGuid AssetGuid() const { return Read<FGuid>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)

    void SET_AssetGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
};

// Size: 0x28
class UClothConfigBase : public UObject
{
public:
};

// Size: 0x28
class UClothSharedSimConfigBase : public UObject
{
public:
};

// Size: 0x28
class UClothingSimulationFactory : public UObject
{
public:
};

// Size: 0x30
class UClothingInteractor : public UObject
{
public:
};

// Size: 0x90
class UClothingSimulationInteractor : public UObject
{
public:
    TMap<UClothingInteractor*, FName> ClothingInteractors() const { return Read<TMap<UClothingInteractor*, FName>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: MapProperty)

    void SET_ClothingInteractors(const TMap<UClothingInteractor*, FName>& Value) { Write<TMap<UClothingInteractor*, FName>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: MapProperty)
};

// Size: 0xe0
class UClothPhysicalMeshDataBase_Legacy : public UObject
{
public:
    TArray<FVector3f> Vertices() const { return Read<TArray<FVector3f>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector3f> Normals() const { return Read<TArray<FVector3f>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<uint32_t> Indices() const { return Read<TArray<uint32_t>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<float> InverseMasses() const { return Read<TArray<float>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FClothVertBoneData> BoneData() const { return Read<TArray<FClothVertBoneData>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    int32_t NumFixedVerts() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)
    int32_t MaxBoneWeights() const { return Read<int32_t>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: IntProperty)
    TArray<uint32_t> SelfCollisionIndices() const { return Read<TArray<uint32_t>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)

    void SET_Vertices(const TArray<FVector3f>& Value) { Write<TArray<FVector3f>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_Normals(const TArray<FVector3f>& Value) { Write<TArray<FVector3f>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_Indices(const TArray<uint32_t>& Value) { Write<TArray<uint32_t>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_InverseMasses(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_BoneData(const TArray<FClothVertBoneData>& Value) { Write<TArray<FClothVertBoneData>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_NumFixedVerts(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
    void SET_MaxBoneWeights(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: IntProperty)
    void SET_SelfCollisionIndices(const TArray<uint32_t>& Value) { Write<TArray<uint32_t>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FClothCollisionPrim_Sphere
{
public:
    int32_t BoneIndex() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    FVector LocalPosition() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)

    void SET_BoneIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_LocalPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x20
struct FClothCollisionPrim_SphereConnection
{
public:
    int32_t SphereIndices() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: IntProperty)
    FVector OneSidedPlaneNormal() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)

    void SET_SphereIndices(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: IntProperty)
    void SET_OneSidedPlaneNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x30
struct FClothCollisionPrim_ConvexFace
{
public:
    FPlane Plane() const { return Read<FPlane>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    TArray<int32_t> Indices() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_Plane(const FPlane& Value) { Write<FPlane>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_Indices(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FClothCollisionPrim_Convex
{
public:
    TArray<FClothCollisionPrim_ConvexFace> Faces() const { return Read<TArray<FClothCollisionPrim_ConvexFace>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> SurfacePoints() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    int32_t BoneIndex() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)

    void SET_Faces(const TArray<FClothCollisionPrim_ConvexFace>& Value) { Write<TArray<FClothCollisionPrim_ConvexFace>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_SurfacePoints(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_BoneIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
};

// Size: 0x60
struct FClothCollisionPrim_Box
{
public:
    FVector LocalPosition() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FQuat LocalRotation() const { return Read<FQuat>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)
    FVector HalfExtents() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    int32_t BoneIndex() const { return Read<int32_t>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: IntProperty)

    void SET_LocalPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_LocalRotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
    void SET_HalfExtents(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_BoneIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: IntProperty)
};

// Size: 0x4c
struct FClothVertBoneData
{
public:
    int32_t NumInfluences() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    uint16_t BoneIndices() const { return Read<uint16_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x18, Type: UInt16Property)
    float BoneWeights() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x30, Type: FloatProperty)

    void SET_NumInfluences(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_BoneIndices(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x18, Type: UInt16Property)
    void SET_BoneWeights(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x30, Type: FloatProperty)
};

// Size: 0x40
struct FClothCollisionData
{
public:
    TArray<FClothCollisionPrim_Sphere> Spheres() const { return Read<TArray<FClothCollisionPrim_Sphere>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FClothCollisionPrim_SphereConnection> SphereConnections() const { return Read<TArray<FClothCollisionPrim_SphereConnection>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FClothCollisionPrim_Convex> Convexes() const { return Read<TArray<FClothCollisionPrim_Convex>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FClothCollisionPrim_Box> Boxes() const { return Read<TArray<FClothCollisionPrim_Box>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Spheres(const TArray<FClothCollisionPrim_Sphere>& Value) { Write<TArray<FClothCollisionPrim_Sphere>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_SphereConnections(const TArray<FClothCollisionPrim_SphereConnection>& Value) { Write<TArray<FClothCollisionPrim_SphereConnection>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Convexes(const TArray<FClothCollisionPrim_Convex>& Value) { Write<TArray<FClothCollisionPrim_Convex>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_Boxes(const TArray<FClothCollisionPrim_Box>& Value) { Write<TArray<FClothCollisionPrim_Box>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

