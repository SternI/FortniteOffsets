/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioGameplay
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayTags.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "AudioExtensions.h"

// Size: 0x48
class UAudioAssetUserData : public UAssetUserData
{
public:
    FGameplayTagContainer MetadataTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: StructProperty)

    void SET_MetadataTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: StructProperty)
};

// Size: 0x28
class UAudioComponentGroupExtension : public UInterface
{
public:
};

// Size: 0x28
class UAudioGameplayCondition : public UInterface
{
public:
};

// Size: 0x28
class UAudioGameplayVolumeInteraction : public UInterface
{
public:
};

// Size: 0xe0
class USoundHandleSubsystem : public UAudioEngineSubsystem
{
public:
};

// Size: 0x3f0
class UAudioComponentGroup : public USceneComponent
{
public:
    TArray<UAudioComponent*> Components() const { return Read<TArray<UAudioComponent*>>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x10, Type: ArrayProperty)
    TArray<FAudioParameter> ParamsToSet() const { return Read<TArray<FAudioParameter>>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x10, Type: ArrayProperty)
    TArray<FAudioParameter> PersistentParams() const { return Read<TArray<FAudioParameter>>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    TArray<TScriptInterface<Class>> Extensions() const { return Read<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x10, Type: ArrayProperty)

    void SET_Components(const TArray<UAudioComponent*>& Value) { Write<TArray<UAudioComponent*>>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x10, Type: ArrayProperty)
    void SET_ParamsToSet(const TArray<FAudioParameter>& Value) { Write<TArray<FAudioParameter>>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x10, Type: ArrayProperty)
    void SET_PersistentParams(const TArray<FAudioParameter>& Value) { Write<TArray<FAudioParameter>>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    void SET_Extensions(const TArray<TScriptInterface<Class>>& Value) { Write<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xc0
class UAudioGameplayComponent : public UActorComponent
{
public:
};

// Size: 0x78
class UAudioRequirementPreset : public UDataAsset
{
public:
    FGameplayTagQuery Query() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x48, Type: StructProperty)

    void SET_Query(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x48, Type: StructProperty)
};

// Size: 0x80
class UAudioGameplayTagCacheSubsystem : public UWorldSubsystem
{
public:
};

// Size: 0xf0
class UAudioParameterComponent : public UAudioGameplayComponent
{
public:
    TArray<TWeakObjectPtr<UAudioComponent*>> ActiveComponents() const { return Read<TArray<TWeakObjectPtr<UAudioComponent*>>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    TArray<FAudioParameter> Parameters() const { return Read<TArray<FAudioParameter>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: ArrayProperty)

    void SET_ActiveComponents(const TArray<TWeakObjectPtr<UAudioComponent*>>& Value) { Write<TArray<TWeakObjectPtr<UAudioComponent*>>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    void SET_Parameters(const TArray<FAudioParameter>& Value) { Write<TArray<FAudioParameter>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
struct FAudioGameplayRequirements
{
public:
    UAudioRequirementPreset* Preset() const { return Read<UAudioRequirementPreset*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery Custom() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x48, Type: StructProperty)

    void SET_Preset(const UAudioRequirementPreset*& Value) { Write<UAudioRequirementPreset*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Custom(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x48, Type: StructProperty)
};

