/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CubeSurfingRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Water.h"
#include "GameplayTags.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayAbilities.h"

// Size: 0x13f0
class UFortAnimInstanceProxy_CubeSurfing : public UFortPlayerAnimInstanceProxy
{
public:
    FGameplayTag BoostingTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1308); } // 0x1308 (Size: 0x4, Type: StructProperty)
    FGameplayTag CubeSurfingTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x130c); } // 0x130c (Size: 0x4, Type: StructProperty)
    FGameplayTag TacSprintTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1310); } // 0x1310 (Size: 0x4, Type: StructProperty)
    FGameplayTag WalkingTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1314); } // 0x1314 (Size: 0x4, Type: StructProperty)
    FGameplayTag ClamberingTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1318); } // 0x1318 (Size: 0x4, Type: StructProperty)
    FGameplayTag FallingTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x131c); } // 0x131c (Size: 0x4, Type: StructProperty)
    FGameplayTag AirborneTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1320); } // 0x1320 (Size: 0x4, Type: StructProperty)
    FGameplayTag PreBoostTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1324); } // 0x1324 (Size: 0x4, Type: StructProperty)
    UAnimMontage* ActivateMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x1328); } // 0x1328 (Size: 0x8, Type: ObjectProperty)
    float MaxHardTurnValue() const { return Read<float>(uintptr_t(this) + 0x1330); } // 0x1330 (Size: 0x4, Type: FloatProperty)
    float MinHardTurnValue() const { return Read<float>(uintptr_t(this) + 0x1334); } // 0x1334 (Size: 0x4, Type: FloatProperty)
    FVector AttachLocation() const { return Read<FVector>(uintptr_t(this) + 0x1338); } // 0x1338 (Size: 0x18, Type: StructProperty)
    float InputLeftRight() const { return Read<float>(uintptr_t(this) + 0x1350); } // 0x1350 (Size: 0x4, Type: FloatProperty)
    float InputFrontBack() const { return Read<float>(uintptr_t(this) + 0x1354); } // 0x1354 (Size: 0x4, Type: FloatProperty)
    float ZVelocity() const { return Read<float>(uintptr_t(this) + 0x1358); } // 0x1358 (Size: 0x4, Type: FloatProperty)
    float NoiseAlpha() const { return Read<float>(uintptr_t(this) + 0x135c); } // 0x135c (Size: 0x4, Type: FloatProperty)
    float NoiseRate() const { return Read<float>(uintptr_t(this) + 0x1360); } // 0x1360 (Size: 0x4, Type: FloatProperty)
    float StanceAdjustValue() const { return Read<float>(uintptr_t(this) + 0x1364); } // 0x1364 (Size: 0x4, Type: FloatProperty)
    float ReactAlpha() const { return Read<float>(uintptr_t(this) + 0x1368); } // 0x1368 (Size: 0x4, Type: FloatProperty)
    float SharpTurnAlphaFast() const { return Read<float>(uintptr_t(this) + 0x136c); } // 0x136c (Size: 0x4, Type: FloatProperty)
    float SharpTurnAlphaSlow() const { return Read<float>(uintptr_t(this) + 0x1370); } // 0x1370 (Size: 0x4, Type: FloatProperty)
    float SpringStiffnessXY() const { return Read<float>(uintptr_t(this) + 0x1374); } // 0x1374 (Size: 0x4, Type: FloatProperty)
    float SpringStiffnessZ() const { return Read<float>(uintptr_t(this) + 0x1378); } // 0x1378 (Size: 0x4, Type: FloatProperty)
    float SpringDampingXY() const { return Read<float>(uintptr_t(this) + 0x137c); } // 0x137c (Size: 0x4, Type: FloatProperty)
    float SpringDampingZ() const { return Read<float>(uintptr_t(this) + 0x1380); } // 0x1380 (Size: 0x4, Type: FloatProperty)
    bool bIsSurfing() const { return Read<bool>(uintptr_t(this) + 0x1384); } // 0x1384 (Size: 0x1, Type: BoolProperty)
    bool bIsBoost() const { return Read<bool>(uintptr_t(this) + 0x1385); } // 0x1385 (Size: 0x1, Type: BoolProperty)
    bool bIsTacSprint() const { return Read<bool>(uintptr_t(this) + 0x1386); } // 0x1386 (Size: 0x1, Type: BoolProperty)
    bool bIsPreBoost() const { return Read<bool>(uintptr_t(this) + 0x1387); } // 0x1387 (Size: 0x1, Type: BoolProperty)
    bool bIsActivateMontage() const { return Read<bool>(uintptr_t(this) + 0x1388); } // 0x1388 (Size: 0x1, Type: BoolProperty)
    bool bIsClambering() const { return Read<bool>(uintptr_t(this) + 0x1389); } // 0x1389 (Size: 0x1, Type: BoolProperty)
    bool bActorHiddenInGame() const { return Read<bool>(uintptr_t(this) + 0x138a); } // 0x138a (Size: 0x1, Type: BoolProperty)
    bool bIsPreLand() const { return Read<bool>(uintptr_t(this) + 0x138b); } // 0x138b (Size: 0x1, Type: BoolProperty)
    bool bIsLanding() const { return Read<bool>(uintptr_t(this) + 0x138c); } // 0x138c (Size: 0x1, Type: BoolProperty)
    bool bIsFall() const { return Read<bool>(uintptr_t(this) + 0x138d); } // 0x138d (Size: 0x1, Type: BoolProperty)
    FRotator RootRotInterp() const { return Read<FRotator>(uintptr_t(this) + 0x1390); } // 0x1390 (Size: 0x18, Type: StructProperty)
    float ChangeInDirection() const { return Read<float>(uintptr_t(this) + 0x13a8); } // 0x13a8 (Size: 0x4, Type: FloatProperty)
    float PreviousTurn() const { return Read<float>(uintptr_t(this) + 0x13ac); } // 0x13ac (Size: 0x4, Type: FloatProperty)
    float ZVelocityInterp() const { return Read<float>(uintptr_t(this) + 0x13b0); } // 0x13b0 (Size: 0x4, Type: FloatProperty)
    float SlopePitch() const { return Read<float>(uintptr_t(this) + 0x13b4); } // 0x13b4 (Size: 0x4, Type: FloatProperty)
    bool bIsTurn() const { return Read<bool>(uintptr_t(this) + 0x13b8); } // 0x13b8 (Size: 0x1, Type: BoolProperty)
    bool bIsTurnLeft() const { return Read<bool>(uintptr_t(this) + 0x13b9); } // 0x13b9 (Size: 0x1, Type: BoolProperty)
    bool bIsTurnLeft180() const { return Read<bool>(uintptr_t(this) + 0x13ba); } // 0x13ba (Size: 0x1, Type: BoolProperty)
    bool bIsTurnRight() const { return Read<bool>(uintptr_t(this) + 0x13bb); } // 0x13bb (Size: 0x1, Type: BoolProperty)
    bool bIsTurnRight180() const { return Read<bool>(uintptr_t(this) + 0x13bc); } // 0x13bc (Size: 0x1, Type: BoolProperty)
    bool bIsStanceAdjustGateOpen() const { return Read<bool>(uintptr_t(this) + 0x13bd); } // 0x13bd (Size: 0x1, Type: BoolProperty)
    bool bResetOpenStanceAdjustGateAftterDelayDoOnce() const { return Read<bool>(uintptr_t(this) + 0x13be); } // 0x13be (Size: 0x1, Type: BoolProperty)

    void SET_BoostingTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1308, Value); } // 0x1308 (Size: 0x4, Type: StructProperty)
    void SET_CubeSurfingTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x130c, Value); } // 0x130c (Size: 0x4, Type: StructProperty)
    void SET_TacSprintTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1310, Value); } // 0x1310 (Size: 0x4, Type: StructProperty)
    void SET_WalkingTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1314, Value); } // 0x1314 (Size: 0x4, Type: StructProperty)
    void SET_ClamberingTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1318, Value); } // 0x1318 (Size: 0x4, Type: StructProperty)
    void SET_FallingTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x131c, Value); } // 0x131c (Size: 0x4, Type: StructProperty)
    void SET_AirborneTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1320, Value); } // 0x1320 (Size: 0x4, Type: StructProperty)
    void SET_PreBoostTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1324, Value); } // 0x1324 (Size: 0x4, Type: StructProperty)
    void SET_ActivateMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x1328, Value); } // 0x1328 (Size: 0x8, Type: ObjectProperty)
    void SET_MaxHardTurnValue(const float& Value) { Write<float>(uintptr_t(this) + 0x1330, Value); } // 0x1330 (Size: 0x4, Type: FloatProperty)
    void SET_MinHardTurnValue(const float& Value) { Write<float>(uintptr_t(this) + 0x1334, Value); } // 0x1334 (Size: 0x4, Type: FloatProperty)
    void SET_AttachLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1338, Value); } // 0x1338 (Size: 0x18, Type: StructProperty)
    void SET_InputLeftRight(const float& Value) { Write<float>(uintptr_t(this) + 0x1350, Value); } // 0x1350 (Size: 0x4, Type: FloatProperty)
    void SET_InputFrontBack(const float& Value) { Write<float>(uintptr_t(this) + 0x1354, Value); } // 0x1354 (Size: 0x4, Type: FloatProperty)
    void SET_ZVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0x1358, Value); } // 0x1358 (Size: 0x4, Type: FloatProperty)
    void SET_NoiseAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x135c, Value); } // 0x135c (Size: 0x4, Type: FloatProperty)
    void SET_NoiseRate(const float& Value) { Write<float>(uintptr_t(this) + 0x1360, Value); } // 0x1360 (Size: 0x4, Type: FloatProperty)
    void SET_StanceAdjustValue(const float& Value) { Write<float>(uintptr_t(this) + 0x1364, Value); } // 0x1364 (Size: 0x4, Type: FloatProperty)
    void SET_ReactAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x1368, Value); } // 0x1368 (Size: 0x4, Type: FloatProperty)
    void SET_SharpTurnAlphaFast(const float& Value) { Write<float>(uintptr_t(this) + 0x136c, Value); } // 0x136c (Size: 0x4, Type: FloatProperty)
    void SET_SharpTurnAlphaSlow(const float& Value) { Write<float>(uintptr_t(this) + 0x1370, Value); } // 0x1370 (Size: 0x4, Type: FloatProperty)
    void SET_SpringStiffnessXY(const float& Value) { Write<float>(uintptr_t(this) + 0x1374, Value); } // 0x1374 (Size: 0x4, Type: FloatProperty)
    void SET_SpringStiffnessZ(const float& Value) { Write<float>(uintptr_t(this) + 0x1378, Value); } // 0x1378 (Size: 0x4, Type: FloatProperty)
    void SET_SpringDampingXY(const float& Value) { Write<float>(uintptr_t(this) + 0x137c, Value); } // 0x137c (Size: 0x4, Type: FloatProperty)
    void SET_SpringDampingZ(const float& Value) { Write<float>(uintptr_t(this) + 0x1380, Value); } // 0x1380 (Size: 0x4, Type: FloatProperty)
    void SET_bIsSurfing(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1384, Value); } // 0x1384 (Size: 0x1, Type: BoolProperty)
    void SET_bIsBoost(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1385, Value); } // 0x1385 (Size: 0x1, Type: BoolProperty)
    void SET_bIsTacSprint(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1386, Value); } // 0x1386 (Size: 0x1, Type: BoolProperty)
    void SET_bIsPreBoost(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1387, Value); } // 0x1387 (Size: 0x1, Type: BoolProperty)
    void SET_bIsActivateMontage(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1388, Value); } // 0x1388 (Size: 0x1, Type: BoolProperty)
    void SET_bIsClambering(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1389, Value); } // 0x1389 (Size: 0x1, Type: BoolProperty)
    void SET_bActorHiddenInGame(const bool& Value) { Write<bool>(uintptr_t(this) + 0x138a, Value); } // 0x138a (Size: 0x1, Type: BoolProperty)
    void SET_bIsPreLand(const bool& Value) { Write<bool>(uintptr_t(this) + 0x138b, Value); } // 0x138b (Size: 0x1, Type: BoolProperty)
    void SET_bIsLanding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x138c, Value); } // 0x138c (Size: 0x1, Type: BoolProperty)
    void SET_bIsFall(const bool& Value) { Write<bool>(uintptr_t(this) + 0x138d, Value); } // 0x138d (Size: 0x1, Type: BoolProperty)
    void SET_RootRotInterp(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x1390, Value); } // 0x1390 (Size: 0x18, Type: StructProperty)
    void SET_ChangeInDirection(const float& Value) { Write<float>(uintptr_t(this) + 0x13a8, Value); } // 0x13a8 (Size: 0x4, Type: FloatProperty)
    void SET_PreviousTurn(const float& Value) { Write<float>(uintptr_t(this) + 0x13ac, Value); } // 0x13ac (Size: 0x4, Type: FloatProperty)
    void SET_ZVelocityInterp(const float& Value) { Write<float>(uintptr_t(this) + 0x13b0, Value); } // 0x13b0 (Size: 0x4, Type: FloatProperty)
    void SET_SlopePitch(const float& Value) { Write<float>(uintptr_t(this) + 0x13b4, Value); } // 0x13b4 (Size: 0x4, Type: FloatProperty)
    void SET_bIsTurn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x13b8, Value); } // 0x13b8 (Size: 0x1, Type: BoolProperty)
    void SET_bIsTurnLeft(const bool& Value) { Write<bool>(uintptr_t(this) + 0x13b9, Value); } // 0x13b9 (Size: 0x1, Type: BoolProperty)
    void SET_bIsTurnLeft180(const bool& Value) { Write<bool>(uintptr_t(this) + 0x13ba, Value); } // 0x13ba (Size: 0x1, Type: BoolProperty)
    void SET_bIsTurnRight(const bool& Value) { Write<bool>(uintptr_t(this) + 0x13bb, Value); } // 0x13bb (Size: 0x1, Type: BoolProperty)
    void SET_bIsTurnRight180(const bool& Value) { Write<bool>(uintptr_t(this) + 0x13bc, Value); } // 0x13bc (Size: 0x1, Type: BoolProperty)
    void SET_bIsStanceAdjustGateOpen(const bool& Value) { Write<bool>(uintptr_t(this) + 0x13bd, Value); } // 0x13bd (Size: 0x1, Type: BoolProperty)
    void SET_bResetOpenStanceAdjustGateAftterDelayDoOnce(const bool& Value) { Write<bool>(uintptr_t(this) + 0x13be, Value); } // 0x13be (Size: 0x1, Type: BoolProperty)
};

// Size: 0xf0
class UFortMovementMode_RuntimeDataCubeSurfing : public UFortMovementMode_ItemActivatedRuntimeData
{
public:
    TWeakObjectPtr<AWaterBody*> PendingSimProxyWaterBody() const { return Read<TWeakObjectPtr<AWaterBody*>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AWaterBody*> WaterBody() const { return Read<TWeakObjectPtr<AWaterBody*>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_PendingSimProxyWaterBody(const TWeakObjectPtr<AWaterBody*>& Value) { Write<TWeakObjectPtr<AWaterBody*>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: WeakObjectProperty)
    void SET_WaterBody(const TWeakObjectPtr<AWaterBody*>& Value) { Write<TWeakObjectPtr<AWaterBody*>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x1420
class UFortMovementMode_ExtLogicCubeSurfing : public UFortMovementMode_ItemActivated
{
public:
    TMap<FGameplayTag, ECubeSurfingState> StateTags() const { return Read<TMap<FGameplayTag, ECubeSurfingState>>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x50, Type: MapProperty)
    FGameplayTag OverWaterTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x438); } // 0x438 (Size: 0x4, Type: StructProperty)
    FScalableFloat MovementRampUpTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x28, Type: StructProperty)
    FScalableFloat BoostReadyDelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x28, Type: StructProperty)
    FScalableFloat MovementInputRecoveryTimeStart() const { return Read<FScalableFloat>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x28, Type: StructProperty)
    FScalableFloat MovementInputRecoveryTimeEnd() const { return Read<FScalableFloat>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x28, Type: StructProperty)
    FScalableFloat GlobalSpeedLimit() const { return Read<FScalableFloat>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ApplyForcesRelativeToGroundNormal() const { return Read<FScalableFloat>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x28, Type: StructProperty)
    FScalableFloat DownwardVelocityCancelHeight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x530); } // 0x530 (Size: 0x28, Type: StructProperty)
    FCubeSurfingThrustData RampUpThrustData() const { return Read<FCubeSurfingThrustData>(uintptr_t(this) + 0x558); } // 0x558 (Size: 0xf0, Type: StructProperty)
    FCubeSurfingThrustData GroundedThrustData() const { return Read<FCubeSurfingThrustData>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0xf0, Type: StructProperty)
    FCubeSurfingThrustData GroundedNeutralThrustData() const { return Read<FCubeSurfingThrustData>(uintptr_t(this) + 0x738); } // 0x738 (Size: 0xf0, Type: StructProperty)
    FCubeSurfingThrustData GroundedBrakingThrustData() const { return Read<FCubeSurfingThrustData>(uintptr_t(this) + 0x828); } // 0x828 (Size: 0xf0, Type: StructProperty)
    FCubeSurfingThrustData CuttingThrustData() const { return Read<FCubeSurfingThrustData>(uintptr_t(this) + 0x918); } // 0x918 (Size: 0xf0, Type: StructProperty)
    FCubeSurfingThrustData PreBoostThrustData() const { return Read<FCubeSurfingThrustData>(uintptr_t(this) + 0xa08); } // 0xa08 (Size: 0xf0, Type: StructProperty)
    FCubeSurfingThrustData BoostingThrustData() const { return Read<FCubeSurfingThrustData>(uintptr_t(this) + 0xaf8); } // 0xaf8 (Size: 0xf0, Type: StructProperty)
    uint8_t TurnInputMode() const { return Read<uint8_t>(uintptr_t(this) + 0xbe8); } // 0xbe8 (Size: 0x1, Type: EnumProperty)
    FScalableFloat MaxStrafeAngleDegrees() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbf0); } // 0xbf0 (Size: 0x28, Type: StructProperty)
    FScalableFloat TurnDampeningMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc18); } // 0xc18 (Size: 0x28, Type: StructProperty)
    FScalableFloat TurnDampeningStartAngleDegrees() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc40); } // 0xc40 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinSlopeAngleDegrees() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc68); } // 0xc68 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxSlopeAngleDegrees() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc90); } // 0xc90 (Size: 0x28, Type: StructProperty)
    FScalableFloat ApplySlopeForceWhileMovingDownSlopes() const { return Read<FScalableFloat>(uintptr_t(this) + 0xcb8); } // 0xcb8 (Size: 0x28, Type: StructProperty)
    FScalableFloat SlopeForce() const { return Read<FScalableFloat>(uintptr_t(this) + 0xce0); } // 0xce0 (Size: 0x28, Type: StructProperty)
    FScalableFloat SlopeForceRight() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd08); } // 0xd08 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxTurnAroundForwardAngle() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd30); } // 0xd30 (Size: 0x28, Type: StructProperty)
    FCubeSurfingHoverData DefaultHoverData() const { return Read<FCubeSurfingHoverData>(uintptr_t(this) + 0xd58); } // 0xd58 (Size: 0x120, Type: StructProperty)
    FScalableFloat Gravity() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe78); } // 0xe78 (Size: 0x28, Type: StructProperty)
    FScalableFloat HoverMaxUpdateRate() const { return Read<FScalableFloat>(uintptr_t(this) + 0xea0); } // 0xea0 (Size: 0x28, Type: StructProperty)
    FScalableFloat HoverMaxUpwardVelocity() const { return Read<FScalableFloat>(uintptr_t(this) + 0xec8); } // 0xec8 (Size: 0x28, Type: StructProperty)
    uint8_t JumpMode() const { return Read<uint8_t>(uintptr_t(this) + 0xef0); } // 0xef0 (Size: 0x1, Type: EnumProperty)
    FScalableFloat DoubleJumpExitTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0xef8); } // 0xef8 (Size: 0x28, Type: StructProperty)
    FScalableFloat JumpSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf20); } // 0xf20 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxJumpSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf48); } // 0xf48 (Size: 0x28, Type: StructProperty)
    FScalableFloat JumpSpeedIsMinimum() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf70); } // 0xf70 (Size: 0x28, Type: StructProperty)
    FScalableFloat CanJumpOnSteepSlopes() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf98); } // 0xf98 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxSlopeJumpAngleDegrees() const { return Read<FScalableFloat>(uintptr_t(this) + 0xfc0); } // 0xfc0 (Size: 0x28, Type: StructProperty)
    FScalableFloat CanBoostWithSprint() const { return Read<FScalableFloat>(uintptr_t(this) + 0xfe8); } // 0xfe8 (Size: 0x28, Type: StructProperty)
    FScalableFloat CanBoostWithSecondary() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1010); } // 0x1010 (Size: 0x28, Type: StructProperty)
    uint8_t BoostActivationMode() const { return Read<uint8_t>(uintptr_t(this) + 0x1038); } // 0x1038 (Size: 0x1, Type: EnumProperty)
    uint8_t BoostMode() const { return Read<uint8_t>(uintptr_t(this) + 0x1039); } // 0x1039 (Size: 0x1, Type: EnumProperty)
    FScalableFloat BoostFullChargeTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1040); } // 0x1040 (Size: 0x28, Type: StructProperty)
    FScalableFloat BoostAutoChargeTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1068); } // 0x1068 (Size: 0x28, Type: StructProperty)
    FScalableFloat BoostRetentionTimeStart() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1090); } // 0x1090 (Size: 0x28, Type: StructProperty)
    FScalableFloat BoostRetentionTimeEnd() const { return Read<FScalableFloat>(uintptr_t(this) + 0x10b8); } // 0x10b8 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxBoostDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0x10e0); } // 0x10e0 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinBoostDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1108); } // 0x1108 (Size: 0x28, Type: StructProperty)
    FScalableFloat PreBoostDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1130); } // 0x1130 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinTimeBetweenBoosts() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1158); } // 0x1158 (Size: 0x28, Type: StructProperty)
    FScalableFloat BoostGrantsFlight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1180); } // 0x1180 (Size: 0x28, Type: StructProperty)
    FScalableFloat BoostImmediatelyToMaxSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0x11a8); } // 0x11a8 (Size: 0x28, Type: StructProperty)
    FScalableFloat BoostPopUpTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0x11d0); } // 0x11d0 (Size: 0x28, Type: StructProperty)
    FScalableFloat BoostPopUpMinUpDirection() const { return Read<FScalableFloat>(uintptr_t(this) + 0x11f8); } // 0x11f8 (Size: 0x28, Type: StructProperty)
    FScalableFloat FlyingCameraUpDirectionMagnification() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1220); } // 0x1220 (Size: 0x28, Type: StructProperty)
    FScalableFloat FlyingJumpMinUpDirection() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1248); } // 0x1248 (Size: 0x28, Type: StructProperty)
    FScalableFloat FlyingCrouchMaxUpDirection() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1270); } // 0x1270 (Size: 0x28, Type: StructProperty)

    void SET_StateTags(const TMap<FGameplayTag, ECubeSurfingState>& Value) { Write<TMap<FGameplayTag, ECubeSurfingState>>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x50, Type: MapProperty)
    void SET_OverWaterTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x438, Value); } // 0x438 (Size: 0x4, Type: StructProperty)
    void SET_MovementRampUpTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x28, Type: StructProperty)
    void SET_BoostReadyDelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x28, Type: StructProperty)
    void SET_MovementInputRecoveryTimeStart(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x28, Type: StructProperty)
    void SET_MovementInputRecoveryTimeEnd(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x28, Type: StructProperty)
    void SET_GlobalSpeedLimit(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x28, Type: StructProperty)
    void SET_ApplyForcesRelativeToGroundNormal(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x28, Type: StructProperty)
    void SET_DownwardVelocityCancelHeight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x530, Value); } // 0x530 (Size: 0x28, Type: StructProperty)
    void SET_RampUpThrustData(const FCubeSurfingThrustData& Value) { Write<FCubeSurfingThrustData>(uintptr_t(this) + 0x558, Value); } // 0x558 (Size: 0xf0, Type: StructProperty)
    void SET_GroundedThrustData(const FCubeSurfingThrustData& Value) { Write<FCubeSurfingThrustData>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0xf0, Type: StructProperty)
    void SET_GroundedNeutralThrustData(const FCubeSurfingThrustData& Value) { Write<FCubeSurfingThrustData>(uintptr_t(this) + 0x738, Value); } // 0x738 (Size: 0xf0, Type: StructProperty)
    void SET_GroundedBrakingThrustData(const FCubeSurfingThrustData& Value) { Write<FCubeSurfingThrustData>(uintptr_t(this) + 0x828, Value); } // 0x828 (Size: 0xf0, Type: StructProperty)
    void SET_CuttingThrustData(const FCubeSurfingThrustData& Value) { Write<FCubeSurfingThrustData>(uintptr_t(this) + 0x918, Value); } // 0x918 (Size: 0xf0, Type: StructProperty)
    void SET_PreBoostThrustData(const FCubeSurfingThrustData& Value) { Write<FCubeSurfingThrustData>(uintptr_t(this) + 0xa08, Value); } // 0xa08 (Size: 0xf0, Type: StructProperty)
    void SET_BoostingThrustData(const FCubeSurfingThrustData& Value) { Write<FCubeSurfingThrustData>(uintptr_t(this) + 0xaf8, Value); } // 0xaf8 (Size: 0xf0, Type: StructProperty)
    void SET_TurnInputMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xbe8, Value); } // 0xbe8 (Size: 0x1, Type: EnumProperty)
    void SET_MaxStrafeAngleDegrees(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbf0, Value); } // 0xbf0 (Size: 0x28, Type: StructProperty)
    void SET_TurnDampeningMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc18, Value); } // 0xc18 (Size: 0x28, Type: StructProperty)
    void SET_TurnDampeningStartAngleDegrees(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc40, Value); } // 0xc40 (Size: 0x28, Type: StructProperty)
    void SET_MinSlopeAngleDegrees(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc68, Value); } // 0xc68 (Size: 0x28, Type: StructProperty)
    void SET_MaxSlopeAngleDegrees(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc90, Value); } // 0xc90 (Size: 0x28, Type: StructProperty)
    void SET_ApplySlopeForceWhileMovingDownSlopes(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xcb8, Value); } // 0xcb8 (Size: 0x28, Type: StructProperty)
    void SET_SlopeForce(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xce0, Value); } // 0xce0 (Size: 0x28, Type: StructProperty)
    void SET_SlopeForceRight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd08, Value); } // 0xd08 (Size: 0x28, Type: StructProperty)
    void SET_MaxTurnAroundForwardAngle(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd30, Value); } // 0xd30 (Size: 0x28, Type: StructProperty)
    void SET_DefaultHoverData(const FCubeSurfingHoverData& Value) { Write<FCubeSurfingHoverData>(uintptr_t(this) + 0xd58, Value); } // 0xd58 (Size: 0x120, Type: StructProperty)
    void SET_Gravity(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe78, Value); } // 0xe78 (Size: 0x28, Type: StructProperty)
    void SET_HoverMaxUpdateRate(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xea0, Value); } // 0xea0 (Size: 0x28, Type: StructProperty)
    void SET_HoverMaxUpwardVelocity(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xec8, Value); } // 0xec8 (Size: 0x28, Type: StructProperty)
    void SET_JumpMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xef0, Value); } // 0xef0 (Size: 0x1, Type: EnumProperty)
    void SET_DoubleJumpExitTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xef8, Value); } // 0xef8 (Size: 0x28, Type: StructProperty)
    void SET_JumpSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf20, Value); } // 0xf20 (Size: 0x28, Type: StructProperty)
    void SET_MaxJumpSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf48, Value); } // 0xf48 (Size: 0x28, Type: StructProperty)
    void SET_JumpSpeedIsMinimum(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf70, Value); } // 0xf70 (Size: 0x28, Type: StructProperty)
    void SET_CanJumpOnSteepSlopes(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf98, Value); } // 0xf98 (Size: 0x28, Type: StructProperty)
    void SET_MaxSlopeJumpAngleDegrees(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xfc0, Value); } // 0xfc0 (Size: 0x28, Type: StructProperty)
    void SET_CanBoostWithSprint(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xfe8, Value); } // 0xfe8 (Size: 0x28, Type: StructProperty)
    void SET_CanBoostWithSecondary(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1010, Value); } // 0x1010 (Size: 0x28, Type: StructProperty)
    void SET_BoostActivationMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1038, Value); } // 0x1038 (Size: 0x1, Type: EnumProperty)
    void SET_BoostMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1039, Value); } // 0x1039 (Size: 0x1, Type: EnumProperty)
    void SET_BoostFullChargeTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1040, Value); } // 0x1040 (Size: 0x28, Type: StructProperty)
    void SET_BoostAutoChargeTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1068, Value); } // 0x1068 (Size: 0x28, Type: StructProperty)
    void SET_BoostRetentionTimeStart(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1090, Value); } // 0x1090 (Size: 0x28, Type: StructProperty)
    void SET_BoostRetentionTimeEnd(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x10b8, Value); } // 0x10b8 (Size: 0x28, Type: StructProperty)
    void SET_MaxBoostDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x10e0, Value); } // 0x10e0 (Size: 0x28, Type: StructProperty)
    void SET_MinBoostDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1108, Value); } // 0x1108 (Size: 0x28, Type: StructProperty)
    void SET_PreBoostDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1130, Value); } // 0x1130 (Size: 0x28, Type: StructProperty)
    void SET_MinTimeBetweenBoosts(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1158, Value); } // 0x1158 (Size: 0x28, Type: StructProperty)
    void SET_BoostGrantsFlight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1180, Value); } // 0x1180 (Size: 0x28, Type: StructProperty)
    void SET_BoostImmediatelyToMaxSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x11a8, Value); } // 0x11a8 (Size: 0x28, Type: StructProperty)
    void SET_BoostPopUpTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x11d0, Value); } // 0x11d0 (Size: 0x28, Type: StructProperty)
    void SET_BoostPopUpMinUpDirection(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x11f8, Value); } // 0x11f8 (Size: 0x28, Type: StructProperty)
    void SET_FlyingCameraUpDirectionMagnification(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1220, Value); } // 0x1220 (Size: 0x28, Type: StructProperty)
    void SET_FlyingJumpMinUpDirection(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1248, Value); } // 0x1248 (Size: 0x28, Type: StructProperty)
    void SET_FlyingCrouchMaxUpDirection(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1270, Value); } // 0x1270 (Size: 0x28, Type: StructProperty)
};

// Size: 0x4
struct FCubeSurfingEvent_BoostCooldown
{
public:
    float CooldownLength() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)

    void SET_CooldownLength(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x4
struct FCubeSurfingEvent_BoostDuration
{
public:
    float MaxDuration() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)

    void SET_MaxDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x1
struct FCubeSurfingEvent_BoostFailed
{
public:
};

// Size: 0x1
struct FCubeSurfingEvent_Jump
{
public:
};

// Size: 0x1
struct FCubeSurfingEvent_CrashLanding
{
public:
};

// Size: 0xf0
struct FCubeSurfingThrustData
{
public:
    FScalableFloat TargetSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x28, Type: StructProperty)
    FScalableFloat DragForward() const { return Read<FScalableFloat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x28, Type: StructProperty)
    FScalableFloat DragRight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x28, Type: StructProperty)
    FScalableFloat DragUp() const { return Read<FScalableFloat>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x28, Type: StructProperty)
    FScalableFloat TurnSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x28, Type: StructProperty)

    void SET_TargetSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x28, Type: StructProperty)
    void SET_DragForward(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x28, Type: StructProperty)
    void SET_DragRight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x28, Type: StructProperty)
    void SET_DragUp(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x28, Type: StructProperty)
    void SET_TurnSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x28, Type: StructProperty)
};

// Size: 0x120
struct FCubeSurfingHoverData
{
public:
    FScalableFloat TargetHeight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ThrustForce() const { return Read<FScalableFloat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x28, Type: StructProperty)
    FScalableFloat Dampening() const { return Read<FScalableFloat>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x28, Type: StructProperty)
    FScalableFloat DampeningMagnet() const { return Read<FScalableFloat>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x28, Type: StructProperty)
    FScalableFloat MagnetMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x28, Type: StructProperty)
    FScalableFloat MagnetMaxHeight() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x28, Type: StructProperty)

    void SET_TargetHeight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x28, Type: StructProperty)
    void SET_ThrustForce(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x28, Type: StructProperty)
    void SET_Dampening(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x28, Type: StructProperty)
    void SET_DampeningMagnet(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x28, Type: StructProperty)
    void SET_MagnetMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x28, Type: StructProperty)
    void SET_MagnetMaxHeight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x28, Type: StructProperty)
};

// Size: 0x10
struct FFortMovementMode_CreationDataCubeSurfing : public FFortMovementMode_BaseExtCreationData
{
public:
};

