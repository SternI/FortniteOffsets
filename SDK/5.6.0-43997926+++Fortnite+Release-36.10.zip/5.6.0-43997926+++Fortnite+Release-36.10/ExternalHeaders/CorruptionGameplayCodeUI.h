/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CorruptionGameplayCodeUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "../Enums.h"
// Size: 0x3c8
class UFortPowerupReticleExtensionWidget : public UFortWeaponReticleExtensionWidgetBase
{
public:
    uint8_t LastPowerupHeatState() const { return Read<uint8_t>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x1, Type: EnumProperty)

    void SET_LastPowerupHeatState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x1, Type: EnumProperty)
};

