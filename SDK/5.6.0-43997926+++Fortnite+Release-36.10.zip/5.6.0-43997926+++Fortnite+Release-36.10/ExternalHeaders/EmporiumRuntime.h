/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EmporiumRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x3c8
class UEmporiumAssetsPaths : public UObject
{
public:
    TSoftObjectPtr<UMaterialInstanceConstant> MR_MI_Opaque() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> MR_MI_Opaque_Clearcoat() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> MR_MI_Opaque_Sheen() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> MR_MI_Opaque_Unlit() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> MR_MI_Translucent() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> MR_MI_Translucent_Clearcoat() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> MR_MI_Transmission() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> MR_MI_Opaque_TS() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> MR_MI_Opaque_Clearcoat_TS() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> MR_MI_Opaque_Sheen_TS() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> MR_MI_Opaque_Unlit_TS() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> MR_MI_Translucent_TS() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> MR_MI_Translucent_Clearcoat_TS() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> MR_MI_Transmission_TS() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> SG_MI_Opaque() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> SG_MI_Opaque_Clearcoat() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> SG_MI_Opaque_Sheen() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> SG_MI_Translucent() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> SG_MI_Translucent_Clearcoat() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> SG_MI_Transmission() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> SG_MI_Opaque_TS() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> SG_MI_Opaque_Clearcoat_TS() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> SG_MI_Opaque_Sheen_TS() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> SG_MI_Translucent_TS() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> SG_MI_Translucent_Clearcoat_TS() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> SG_MI_Transmission_TS() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> SG_MI_Foliage_TS() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant> MR_MI_Foliage_TS() const { return Read<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh> PlaceholderSphere() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x20, Type: SoftObjectProperty)

    void SET_MR_MI_Opaque(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MR_MI_Opaque_Clearcoat(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MR_MI_Opaque_Sheen(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MR_MI_Opaque_Unlit(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MR_MI_Translucent(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MR_MI_Translucent_Clearcoat(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MR_MI_Transmission(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MR_MI_Opaque_TS(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MR_MI_Opaque_Clearcoat_TS(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MR_MI_Opaque_Sheen_TS(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MR_MI_Opaque_Unlit_TS(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MR_MI_Translucent_TS(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MR_MI_Translucent_Clearcoat_TS(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MR_MI_Transmission_TS(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SG_MI_Opaque(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SG_MI_Opaque_Clearcoat(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SG_MI_Opaque_Sheen(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SG_MI_Translucent(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SG_MI_Translucent_Clearcoat(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SG_MI_Transmission(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SG_MI_Opaque_TS(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SG_MI_Opaque_Clearcoat_TS(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SG_MI_Opaque_Sheen_TS(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SG_MI_Translucent_TS(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SG_MI_Translucent_Clearcoat_TS(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SG_MI_Transmission_TS(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SG_MI_Foliage_TS(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MR_MI_Foliage_TS(const TSoftObjectPtr<UMaterialInstanceConstant>& Value) { Write<TSoftObjectPtr<UMaterialInstanceConstant>>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x20, Type: SoftObjectProperty)
    void SET_PlaceholderSphere(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x20, Type: SoftObjectProperty)
};

