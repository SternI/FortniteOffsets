/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityDiscoverView_NEW_VM
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "UMG.h"
#include "ActivityBrowserDiscoverGridRowMax.h"
#include "Engine.h"
#include "FortniteUI.h"
#include "AudioModulation.h"
#include "UIKit.h"

// Size: 0x9d9
class UActivityDiscoverView_NEW_VM_C : public UFortActivityDiscoverViewV2
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x8a0); } // 0x8a0 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_Throbber_C* WBP_UIKit_Throbber() const { return Read<UWBP_UIKit_Throbber_C*>(uintptr_t(this) + 0x8a8); } // 0x8a8 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_Nav() const { return Read<UOverlay*>(uintptr_t(this) + 0x8b0); } // 0x8b0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Intro() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x8b8); } // 0x8b8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ShowAndHideRowLoadingSpinner() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x8c0); } // 0x8c0 (Size: 0x8, Type: ObjectProperty)
    UTexture* NextImage() const { return Read<UTexture*>(uintptr_t(this) + 0x8c8); } // 0x8c8 (Size: 0x8, Type: ObjectProperty)
    FName KeyArtParameter() const { return Read<FName>(uintptr_t(this) + 0x8d0); } // 0x8d0 (Size: 0x4, Type: NameProperty)
    UTexture* DefaultImage() const { return Read<UTexture*>(uintptr_t(this) + 0x8d8); } // 0x8d8 (Size: 0x8, Type: ObjectProperty)
    bool HasIntroPlayed() const { return Read<bool>(uintptr_t(this) + 0x8f0); } // 0x8f0 (Size: 0x1, Type: BoolProperty)
    double DetailsMaxHeight() const { return Read<double>(uintptr_t(this) + 0x8f8); } // 0x8f8 (Size: 0x8, Type: DoubleProperty)
    double DetailsMaxHeightMobile() const { return Read<double>(uintptr_t(this) + 0x900); } // 0x900 (Size: 0x8, Type: DoubleProperty)
    double KeyArtMaxWidth() const { return Read<double>(uintptr_t(this) + 0x908); } // 0x908 (Size: 0x8, Type: DoubleProperty)
    double KeyArtMaxWidthMobile() const { return Read<double>(uintptr_t(this) + 0x910); } // 0x910 (Size: 0x8, Type: DoubleProperty)
    TArray<UImage*> KeyArt_ImageWidgets() const { return Read<TArray<UImage*>>(uintptr_t(this) + 0x918); } // 0x918 (Size: 0x10, Type: ArrayProperty)
    bool IsPromotedContentDisplayed() const { return Read<bool>(uintptr_t(this) + 0x928); } // 0x928 (Size: 0x1, Type: BoolProperty)
    bool IsImageLoadingSpinnerActive() const { return Read<bool>(uintptr_t(this) + 0x940); } // 0x940 (Size: 0x1, Type: BoolProperty)
    int32_t RowIndex() const { return Read<int32_t>(uintptr_t(this) + 0x968); } // 0x968 (Size: 0x4, Type: IntProperty)
    USoundBase* AmbientBackgroundLoop() const { return Read<USoundBase*>(uintptr_t(this) + 0x980); } // 0x980 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* BackgroundAmbience() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x988); } // 0x988 (Size: 0x8, Type: ObjectProperty)
    USoundSubmix* MusicSubmix() const { return Read<USoundSubmix*>(uintptr_t(this) + 0x990); } // 0x990 (Size: 0x8, Type: ObjectProperty)
    USubmixEffectDynamicReverbPreset* ReverbSubmixEffect() const { return Read<USubmixEffectDynamicReverbPreset*>(uintptr_t(this) + 0x998); } // 0x998 (Size: 0x8, Type: ObjectProperty)
    USoundControlBusMix* ControlBusMix() const { return Read<USoundControlBusMix*>(uintptr_t(this) + 0x9a0); } // 0x9a0 (Size: 0x8, Type: ObjectProperty)
    UAthenaLobbyBase* Athena_Lobby() const { return Read<UAthenaLobbyBase*>(uintptr_t(this) + 0x9a8); } // 0x9a8 (Size: 0x8, Type: ObjectProperty)
    bool IsFullscreen() const { return Read<bool>(uintptr_t(this) + 0x9c0); } // 0x9c0 (Size: 0x1, Type: BoolProperty)
    bool WasViewAllSelected() const { return Read<bool>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x8a0, Value); } // 0x8a0 (Size: 0x8, Type: StructProperty)
    void SET_WBP_UIKit_Throbber(const UWBP_UIKit_Throbber_C*& Value) { Write<UWBP_UIKit_Throbber_C*>(uintptr_t(this) + 0x8a8, Value); } // 0x8a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_Nav(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x8b0, Value); } // 0x8b0 (Size: 0x8, Type: ObjectProperty)
    void SET_Intro(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x8b8, Value); } // 0x8b8 (Size: 0x8, Type: ObjectProperty)
    void SET_ShowAndHideRowLoadingSpinner(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x8c0, Value); } // 0x8c0 (Size: 0x8, Type: ObjectProperty)
    void SET_NextImage(const UTexture*& Value) { Write<UTexture*>(uintptr_t(this) + 0x8c8, Value); } // 0x8c8 (Size: 0x8, Type: ObjectProperty)
    void SET_KeyArtParameter(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8d0, Value); } // 0x8d0 (Size: 0x4, Type: NameProperty)
    void SET_DefaultImage(const UTexture*& Value) { Write<UTexture*>(uintptr_t(this) + 0x8d8, Value); } // 0x8d8 (Size: 0x8, Type: ObjectProperty)
    void SET_HasIntroPlayed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8f0, Value); } // 0x8f0 (Size: 0x1, Type: BoolProperty)
    void SET_DetailsMaxHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x8f8, Value); } // 0x8f8 (Size: 0x8, Type: DoubleProperty)
    void SET_DetailsMaxHeightMobile(const double& Value) { Write<double>(uintptr_t(this) + 0x900, Value); } // 0x900 (Size: 0x8, Type: DoubleProperty)
    void SET_KeyArtMaxWidth(const double& Value) { Write<double>(uintptr_t(this) + 0x908, Value); } // 0x908 (Size: 0x8, Type: DoubleProperty)
    void SET_KeyArtMaxWidthMobile(const double& Value) { Write<double>(uintptr_t(this) + 0x910, Value); } // 0x910 (Size: 0x8, Type: DoubleProperty)
    void SET_KeyArt_ImageWidgets(const TArray<UImage*>& Value) { Write<TArray<UImage*>>(uintptr_t(this) + 0x918, Value); } // 0x918 (Size: 0x10, Type: ArrayProperty)
    void SET_IsPromotedContentDisplayed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x928, Value); } // 0x928 (Size: 0x1, Type: BoolProperty)
    void SET_IsImageLoadingSpinnerActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x940, Value); } // 0x940 (Size: 0x1, Type: BoolProperty)
    void SET_RowIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x968, Value); } // 0x968 (Size: 0x4, Type: IntProperty)
    void SET_AmbientBackgroundLoop(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x980, Value); } // 0x980 (Size: 0x8, Type: ObjectProperty)
    void SET_BackgroundAmbience(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x988, Value); } // 0x988 (Size: 0x8, Type: ObjectProperty)
    void SET_MusicSubmix(const USoundSubmix*& Value) { Write<USoundSubmix*>(uintptr_t(this) + 0x990, Value); } // 0x990 (Size: 0x8, Type: ObjectProperty)
    void SET_ReverbSubmixEffect(const USubmixEffectDynamicReverbPreset*& Value) { Write<USubmixEffectDynamicReverbPreset*>(uintptr_t(this) + 0x998, Value); } // 0x998 (Size: 0x8, Type: ObjectProperty)
    void SET_ControlBusMix(const USoundControlBusMix*& Value) { Write<USoundControlBusMix*>(uintptr_t(this) + 0x9a0, Value); } // 0x9a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Athena_Lobby(const UAthenaLobbyBase*& Value) { Write<UAthenaLobbyBase*>(uintptr_t(this) + 0x9a8, Value); } // 0x9a8 (Size: 0x8, Type: ObjectProperty)
    void SET_IsFullscreen(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9c0, Value); } // 0x9c0 (Size: 0x1, Type: BoolProperty)
    void SET_WasViewAllSelected(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x1, Type: BoolProperty)
};

