/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamContentResolver
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x368
class UJamContentResolver : public UGameStateComponent
{
public:
};

// Size: 0x110
class UJamControllerComponent_ContentResolver : public UControllerComponent
{
public:
};

