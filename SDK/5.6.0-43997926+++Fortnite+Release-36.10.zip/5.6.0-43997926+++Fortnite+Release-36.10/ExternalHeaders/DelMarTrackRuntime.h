/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarTrackRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "Engine.h"

// Size: 0xce8
class ADelMarTrack : public ADelMarTrackBase
{
public:
    uint8_t TrackType() const { return Read<uint8_t>(uintptr_t(this) + 0xc90); } // 0xc90 (Size: 0x1, Type: EnumProperty)
    bool bIsIndependent() const { return Read<bool>(uintptr_t(this) + 0xc91); } // 0xc91 (Size: 0x1, Type: BoolProperty)
    bool bUserSelectedStartTrack() const { return Read<bool>(uintptr_t(this) + 0xc92); } // 0xc92 (Size: 0x1, Type: BoolProperty)
    ADelMarTrack* StartTrackConnection() const { return Read<ADelMarTrack*>(uintptr_t(this) + 0xc98); } // 0xc98 (Size: 0x8, Type: ObjectProperty)
    bool bUserSelectedEndTrack() const { return Read<bool>(uintptr_t(this) + 0xca0); } // 0xca0 (Size: 0x1, Type: BoolProperty)
    ADelMarTrack* EndTrackConnection() const { return Read<ADelMarTrack*>(uintptr_t(this) + 0xca8); } // 0xca8 (Size: 0x8, Type: ObjectProperty)
    float ParentStartDistance() const { return Read<float>(uintptr_t(this) + 0xcb0); } // 0xcb0 (Size: 0x4, Type: FloatProperty)
    float ParentEndDistance() const { return Read<float>(uintptr_t(this) + 0xcb4); } // 0xcb4 (Size: 0x4, Type: FloatProperty)
    float PrimaryStartDistance() const { return Read<float>(uintptr_t(this) + 0xcb8); } // 0xcb8 (Size: 0x4, Type: FloatProperty)
    float PrimaryEndDistance() const { return Read<float>(uintptr_t(this) + 0xcbc); } // 0xcbc (Size: 0x4, Type: FloatProperty)
    float PrimarySegmentLength() const { return Read<float>(uintptr_t(this) + 0xcc0); } // 0xcc0 (Size: 0x4, Type: FloatProperty)
    UClass* OobTubeClass() const { return Read<UClass*>(uintptr_t(this) + 0xcc8); } // 0xcc8 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<ADelMarTrackOobTube*> AttachedOobTube() const { return Read<TWeakObjectPtr<ADelMarTrackOobTube*>>(uintptr_t(this) + 0xcd0); } // 0xcd0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_TrackType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc90, Value); } // 0xc90 (Size: 0x1, Type: EnumProperty)
    void SET_bIsIndependent(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc91, Value); } // 0xc91 (Size: 0x1, Type: BoolProperty)
    void SET_bUserSelectedStartTrack(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc92, Value); } // 0xc92 (Size: 0x1, Type: BoolProperty)
    void SET_StartTrackConnection(const ADelMarTrack*& Value) { Write<ADelMarTrack*>(uintptr_t(this) + 0xc98, Value); } // 0xc98 (Size: 0x8, Type: ObjectProperty)
    void SET_bUserSelectedEndTrack(const bool& Value) { Write<bool>(uintptr_t(this) + 0xca0, Value); } // 0xca0 (Size: 0x1, Type: BoolProperty)
    void SET_EndTrackConnection(const ADelMarTrack*& Value) { Write<ADelMarTrack*>(uintptr_t(this) + 0xca8, Value); } // 0xca8 (Size: 0x8, Type: ObjectProperty)
    void SET_ParentStartDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xcb0, Value); } // 0xcb0 (Size: 0x4, Type: FloatProperty)
    void SET_ParentEndDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xcb4, Value); } // 0xcb4 (Size: 0x4, Type: FloatProperty)
    void SET_PrimaryStartDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xcb8, Value); } // 0xcb8 (Size: 0x4, Type: FloatProperty)
    void SET_PrimaryEndDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xcbc, Value); } // 0xcbc (Size: 0x4, Type: FloatProperty)
    void SET_PrimarySegmentLength(const float& Value) { Write<float>(uintptr_t(this) + 0xcc0, Value); } // 0xcc0 (Size: 0x4, Type: FloatProperty)
    void SET_OobTubeClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xcc8, Value); } // 0xcc8 (Size: 0x8, Type: ClassProperty)
    void SET_AttachedOobTube(const TWeakObjectPtr<ADelMarTrackOobTube*>& Value) { Write<TWeakObjectPtr<ADelMarTrackOobTube*>>(uintptr_t(this) + 0xcd0, Value); } // 0xcd0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xc90
class ADelMarTrackBase : public AFortCreativeDeviceProp
{
public:
    UDelMarTrackPaletteTheme* TrackPalette_V2() const { return Read<UDelMarTrackPaletteTheme*>(uintptr_t(this) + 0xc30); } // 0xc30 (Size: 0x8, Type: ObjectProperty)
    UDelMarTrackPointData* TrackSplinePointData() const { return Read<UDelMarTrackPointData*>(uintptr_t(this) + 0xc38); } // 0xc38 (Size: 0x8, Type: ObjectProperty)
    UDelMarTrackSplineComponent* Spline() const { return Read<UDelMarTrackSplineComponent*>(uintptr_t(this) + 0xc40); } // 0xc40 (Size: 0x8, Type: ObjectProperty)
    TArray<FDelMarTrackPropSection> TrackPropData() const { return Read<TArray<FDelMarTrackPropSection>>(uintptr_t(this) + 0xc48); } // 0xc48 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarSegmentActorCollection> SegmentCollections() const { return Read<TArray<FDelMarSegmentActorCollection>>(uintptr_t(this) + 0xc58); } // 0xc58 (Size: 0x10, Type: ArrayProperty)
    float DefaultMaxTrackWidth() const { return Read<float>(uintptr_t(this) + 0xc68); } // 0xc68 (Size: 0x4, Type: FloatProperty)
    int32_t TotalSegmentActors() const { return Read<int32_t>(uintptr_t(this) + 0xc6c); } // 0xc6c (Size: 0x4, Type: IntProperty)
    float TrackLength() const { return Read<float>(uintptr_t(this) + 0xc70); } // 0xc70 (Size: 0x4, Type: FloatProperty)
    UDelMarTrackPalette* TrackPalette() const { return Read<UDelMarTrackPalette*>(uintptr_t(this) + 0xc78); } // 0xc78 (Size: 0x8, Type: ObjectProperty)
    bool bEnableGlobalMaterialCollectionIndex() const { return Read<bool>(uintptr_t(this) + 0xc80); } // 0xc80 (Size: 0x1, Type: BoolProperty)
    uint32_t GlobalMaterialCollectionIndex() const { return Read<uint32_t>(uintptr_t(this) + 0xc84); } // 0xc84 (Size: 0x4, Type: UInt32Property)
    bool bForceValidOOBTube() const { return Read<bool>(uintptr_t(this) + 0xc88); } // 0xc88 (Size: 0x1, Type: BoolProperty)
    bool bForceValidTrack() const { return Read<bool>(uintptr_t(this) + 0xc89); } // 0xc89 (Size: 0x1, Type: BoolProperty)

    void SET_TrackPalette_V2(const UDelMarTrackPaletteTheme*& Value) { Write<UDelMarTrackPaletteTheme*>(uintptr_t(this) + 0xc30, Value); } // 0xc30 (Size: 0x8, Type: ObjectProperty)
    void SET_TrackSplinePointData(const UDelMarTrackPointData*& Value) { Write<UDelMarTrackPointData*>(uintptr_t(this) + 0xc38, Value); } // 0xc38 (Size: 0x8, Type: ObjectProperty)
    void SET_Spline(const UDelMarTrackSplineComponent*& Value) { Write<UDelMarTrackSplineComponent*>(uintptr_t(this) + 0xc40, Value); } // 0xc40 (Size: 0x8, Type: ObjectProperty)
    void SET_TrackPropData(const TArray<FDelMarTrackPropSection>& Value) { Write<TArray<FDelMarTrackPropSection>>(uintptr_t(this) + 0xc48, Value); } // 0xc48 (Size: 0x10, Type: ArrayProperty)
    void SET_SegmentCollections(const TArray<FDelMarSegmentActorCollection>& Value) { Write<TArray<FDelMarSegmentActorCollection>>(uintptr_t(this) + 0xc58, Value); } // 0xc58 (Size: 0x10, Type: ArrayProperty)
    void SET_DefaultMaxTrackWidth(const float& Value) { Write<float>(uintptr_t(this) + 0xc68, Value); } // 0xc68 (Size: 0x4, Type: FloatProperty)
    void SET_TotalSegmentActors(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc6c, Value); } // 0xc6c (Size: 0x4, Type: IntProperty)
    void SET_TrackLength(const float& Value) { Write<float>(uintptr_t(this) + 0xc70, Value); } // 0xc70 (Size: 0x4, Type: FloatProperty)
    void SET_TrackPalette(const UDelMarTrackPalette*& Value) { Write<UDelMarTrackPalette*>(uintptr_t(this) + 0xc78, Value); } // 0xc78 (Size: 0x8, Type: ObjectProperty)
    void SET_bEnableGlobalMaterialCollectionIndex(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc80, Value); } // 0xc80 (Size: 0x1, Type: BoolProperty)
    void SET_GlobalMaterialCollectionIndex(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0xc84, Value); } // 0xc84 (Size: 0x4, Type: UInt32Property)
    void SET_bForceValidOOBTube(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc88, Value); } // 0xc88 (Size: 0x1, Type: BoolProperty)
    void SET_bForceValidTrack(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc89, Value); } // 0xc89 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UDelMarTrackBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UDelMarTrackCustomizationInterface : public UInterface
{
public:
};

// Size: 0x2e0
class ADelMarTrackCustomSegment : public ADelMarTrackSegmentBase
{
public:
    float SegmentLength() const { return Read<float>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x4, Type: FloatProperty)

    void SET_SegmentLength(const float& Value) { Write<float>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x2d8
class ADelMarTrackSegmentBase : public AActor
{
public:
    bool bIgnoreSplineLength() const { return Read<bool>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<ADelMarTrackBase*> Track() const { return Read<TWeakObjectPtr<ADelMarTrackBase*>>(uintptr_t(this) + 0x2b4); } // 0x2b4 (Size: 0x8, Type: WeakObjectProperty)
    UDelMarTrackMatLayerComponent* MaterialLayerComponent() const { return Read<UDelMarTrackMatLayerComponent*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    float BeginDistanceAlongSpline() const { return Read<float>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x4, Type: FloatProperty)
    float EndDistanceAlongSpline() const { return Read<float>(uintptr_t(this) + 0x2cc); } // 0x2cc (Size: 0x4, Type: FloatProperty)
    int32_t TrackSegmentIndex() const { return Read<int32_t>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x4, Type: IntProperty)

    void SET_bIgnoreSplineLength(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x1, Type: BoolProperty)
    void SET_Track(const TWeakObjectPtr<ADelMarTrackBase*>& Value) { Write<TWeakObjectPtr<ADelMarTrackBase*>>(uintptr_t(this) + 0x2b4, Value); } // 0x2b4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_MaterialLayerComponent(const UDelMarTrackMatLayerComponent*& Value) { Write<UDelMarTrackMatLayerComponent*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    void SET_BeginDistanceAlongSpline(const float& Value) { Write<float>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x4, Type: FloatProperty)
    void SET_EndDistanceAlongSpline(const float& Value) { Write<float>(uintptr_t(this) + 0x2cc, Value); } // 0x2cc (Size: 0x4, Type: FloatProperty)
    void SET_TrackSegmentIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x60
class UDelMarTrackMaterialCollection : public UDataAsset
{
public:
    uint32_t SelectedIndex() const { return Read<uint32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: UInt32Property)
    TArray<FDelMarTrackMaterialCollectionEntry> Materials() const { return Read<TArray<FDelMarTrackMaterialCollectionEntry>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_SelectedIndex(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: UInt32Property)
    void SET_Materials(const TArray<FDelMarTrackMaterialCollectionEntry>& Value) { Write<TArray<FDelMarTrackMaterialCollectionEntry>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xd0
class UDelMarTrackMatLayerComponent : public UActorComponent
{
public:
    TWeakObjectPtr<UStaticMeshComponent*> RoadMesh() const { return Read<TWeakObjectPtr<UStaticMeshComponent*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarTrackBase*> Track() const { return Read<TWeakObjectPtr<ADelMarTrackBase*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    UDelMarTrackMaterialCollection* MaterialCollection() const { return Read<UDelMarTrackMaterialCollection*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)

    void SET_RoadMesh(const TWeakObjectPtr<UStaticMeshComponent*>& Value) { Write<TWeakObjectPtr<UStaticMeshComponent*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Track(const TWeakObjectPtr<ADelMarTrackBase*>& Value) { Write<TWeakObjectPtr<ADelMarTrackBase*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_MaterialCollection(const UDelMarTrackMaterialCollection*& Value) { Write<UDelMarTrackMaterialCollection*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x750
class UDelMarTrackMeshCustomization : public USplineMeshComponent
{
public:
    bool bIsADefaultCustomization() const { return Read<bool>(uintptr_t(this) + 0x741); } // 0x741 (Size: 0x1, Type: BoolProperty)

    void SET_bIsADefaultCustomization(const bool& Value) { Write<bool>(uintptr_t(this) + 0x741, Value); } // 0x741 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x388
class ADelMarTrackOobTube : public AActor
{
public:
    ADelMarTrack* AttachedTrack() const { return Read<ADelMarTrack*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    UDelMarTrackSplineComponent* Spline() const { return Read<UDelMarTrackSplineComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UDelMarTrackOobTubePointData* SplinePointData() const { return Read<UDelMarTrackOobTubePointData*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    TArray<FDelMarTrackOobTubeMeshSection> OobTubeMeshSections() const { return Read<TArray<FDelMarTrackOobTubeMeshSection>>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    TSoftObjectPtr<UStaticMesh> TubeMesh() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x20, Type: SoftObjectProperty)
    TMap<TSoftObjectPtr<UStaticMesh*>, EDelMarTrackOobTubeTransitionType> TransitionMeshes() const { return Read<TMap<TSoftObjectPtr<UStaticMesh*>, EDelMarTrackOobTubeTransitionType>>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x50, Type: MapProperty)
    float DefaultTransitionMeshLength() const { return Read<float>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x4, Type: FloatProperty)
    int32_t DefaultNumSubsections() const { return Read<int32_t>(uintptr_t(this) + 0x364); } // 0x364 (Size: 0x4, Type: IntProperty)
    float SmallestSubsectionLength() const { return Read<float>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x4, Type: FloatProperty)
    float MinimumMeshScale() const { return Read<float>(uintptr_t(this) + 0x36c); } // 0x36c (Size: 0x4, Type: FloatProperty)

    void SET_AttachedTrack(const ADelMarTrack*& Value) { Write<ADelMarTrack*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Spline(const UDelMarTrackSplineComponent*& Value) { Write<UDelMarTrackSplineComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_SplinePointData(const UDelMarTrackOobTubePointData*& Value) { Write<UDelMarTrackOobTubePointData*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_OobTubeMeshSections(const TArray<FDelMarTrackOobTubeMeshSection>& Value) { Write<TArray<FDelMarTrackOobTubeMeshSection>>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    void SET_TubeMesh(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_TransitionMeshes(const TMap<TSoftObjectPtr<UStaticMesh*>, EDelMarTrackOobTubeTransitionType>& Value) { Write<TMap<TSoftObjectPtr<UStaticMesh*>, EDelMarTrackOobTubeTransitionType>>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x50, Type: MapProperty)
    void SET_DefaultTransitionMeshLength(const float& Value) { Write<float>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x4, Type: FloatProperty)
    void SET_DefaultNumSubsections(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x364, Value); } // 0x364 (Size: 0x4, Type: IntProperty)
    void SET_SmallestSubsectionLength(const float& Value) { Write<float>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x4, Type: FloatProperty)
    void SET_MinimumMeshScale(const float& Value) { Write<float>(uintptr_t(this) + 0x36c, Value); } // 0x36c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
class UDelMarTrackOobTubePointData : public USplineMetadata
{
public:
    TArray<FDelMarTrackOobTubePointMetaData> MetaData() const { return Read<TArray<FDelMarTrackOobTubePointMetaData>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_MetaData(const TArray<FDelMarTrackOobTubePointMetaData>& Value) { Write<TArray<FDelMarTrackOobTubePointMetaData>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x128
class UDelMarTrackOobTubePositionalRenderingComponent : public UControllerComponent
{
public:
    TWeakObjectPtr<UDelMarTrackPositionComponent*> PlayerPositionComponent() const { return Read<TWeakObjectPtr<UDelMarTrackPositionComponent*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TSet<USplineMeshComponent*> ActiveOOBTubeMeshes() const { return Read<TSet<USplineMeshComponent*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x50, Type: SetProperty)
    ADelMarTrackOobTube* ActiveOOBTube() const { return Read<ADelMarTrackOobTube*>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: ObjectProperty)
    float RenderDistanceInFrontOfPlayer() const { return Read<float>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x4, Type: FloatProperty)
    float RenderDistanceBehindPlayer() const { return Read<float>(uintptr_t(this) + 0x11c); } // 0x11c (Size: 0x4, Type: FloatProperty)
    float UpdateIntervalInSeconds() const { return Read<float>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: FloatProperty)

    void SET_PlayerPositionComponent(const TWeakObjectPtr<UDelMarTrackPositionComponent*>& Value) { Write<TWeakObjectPtr<UDelMarTrackPositionComponent*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ActiveOOBTubeMeshes(const TSet<USplineMeshComponent*>& Value) { Write<TSet<USplineMeshComponent*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x50, Type: SetProperty)
    void SET_ActiveOOBTube(const ADelMarTrackOobTube*& Value) { Write<ADelMarTrackOobTube*>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: ObjectProperty)
    void SET_RenderDistanceInFrontOfPlayer(const float& Value) { Write<float>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x4, Type: FloatProperty)
    void SET_RenderDistanceBehindPlayer(const float& Value) { Write<float>(uintptr_t(this) + 0x11c, Value); } // 0x11c (Size: 0x4, Type: FloatProperty)
    void SET_UpdateIntervalInSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
class UDelMarTrackOobTubeProxy : public UObject
{
public:
};

// Size: 0x30
class UDelMarTrackOobTubeCollectionProxy : public UObject
{
public:
    UClass* OobTubeClass() const { return Read<UClass*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ClassProperty)

    void SET_OobTubeClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x50
class UDelMarTrackPaletteTrackType : public UDataAsset
{
public:
    TArray<FDelMarTrackPaletteTrackTypeEntry> StyleArray() const { return Read<TArray<FDelMarTrackPaletteTrackTypeEntry>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    bool bShouldOOBTubeFunnel() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)
    UStaticMesh* OOBTubeMeshOverride() const { return Read<UStaticMesh*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)

    void SET_StyleArray(const TArray<FDelMarTrackPaletteTrackTypeEntry>& Value) { Write<TArray<FDelMarTrackPaletteTrackTypeEntry>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_bShouldOOBTubeFunnel(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
    void SET_OOBTubeMeshOverride(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class UDelMarTrackPaletteTransitions : public UDataAsset
{
public:
    TArray<FDelMarTrackPaletteTransitionEntry_v2> TransitionArray() const { return Read<TArray<FDelMarTrackPaletteTransitionEntry_v2>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_TransitionArray(const TArray<FDelMarTrackPaletteTransitionEntry_v2>& Value) { Write<TArray<FDelMarTrackPaletteTransitionEntry_v2>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x70
class UDelMarTrackPaletteTheme : public UDataAsset
{
public:
    FName ThemeName() const { return Read<FName>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: NameProperty)
    FString ThemeDescription() const { return Read<FString>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StrProperty)
    TArray<UDelMarTrackPaletteTrackType*> Tracks() const { return Read<TArray<UDelMarTrackPaletteTrackType*>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    UDelMarTrackPaletteTransitions* Transitions() const { return Read<UDelMarTrackPaletteTransitions*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    UStaticMesh* OOBTubeMesh() const { return Read<UStaticMesh*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)

    void SET_ThemeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: NameProperty)
    void SET_ThemeDescription(const FString& Value) { Write<FString>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StrProperty)
    void SET_Tracks(const TArray<UDelMarTrackPaletteTrackType*>& Value) { Write<TArray<UDelMarTrackPaletteTrackType*>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_Transitions(const UDelMarTrackPaletteTransitions*& Value) { Write<UDelMarTrackPaletteTransitions*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_OOBTubeMesh(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x360
class ADelMarTrackPerformanceScrubber : public AActor
{
public:
    UCameraComponent* Camera() const { return Read<UCameraComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UDelMarTrackSplineComponent*> Spline() const { return Read<TWeakObjectPtr<UDelMarTrackSplineComponent*>>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: WeakObjectProperty)
    FString SplineSelection() const { return Read<FString>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x10, Type: StrProperty)
    int32_t ScrubUnits() const { return Read<int32_t>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x4, Type: IntProperty)
    float CameraHeightOffset() const { return Read<float>(uintptr_t(this) + 0x2cc); } // 0x2cc (Size: 0x4, Type: FloatProperty)
    UCurveFloat* FloatCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    int32_t RuntimeSpeed() const { return Read<int32_t>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x4, Type: IntProperty)
    bool bRunCsvProfilerDuringScrub() const { return (Read<uint8_t>(uintptr_t(this) + 0x2dc) >> 0x0) & 1; } // 0x2dc:0 (Size: 0x1, Type: BoolProperty)
    int32_t ScrubUnitMax() const { return Read<int32_t>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x4, Type: IntProperty)
    bool bRuntimeEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x2fc) >> 0x0) & 1; } // 0x2fc:0 (Size: 0x1, Type: BoolProperty)
    TMap<UDelMarTrackSplineComponent*, FString> StringToSplineMap() const { return Read<TMap<UDelMarTrackSplineComponent*, FString>>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x50, Type: MapProperty)
    UTimelineComponent* Timeline() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)

    void SET_Camera(const UCameraComponent*& Value) { Write<UCameraComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Spline(const TWeakObjectPtr<UDelMarTrackSplineComponent*>& Value) { Write<TWeakObjectPtr<UDelMarTrackSplineComponent*>>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_SplineSelection(const FString& Value) { Write<FString>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x10, Type: StrProperty)
    void SET_ScrubUnits(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x4, Type: IntProperty)
    void SET_CameraHeightOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x2cc, Value); } // 0x2cc (Size: 0x4, Type: FloatProperty)
    void SET_FloatCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    void SET_RuntimeSpeed(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x4, Type: IntProperty)
    void SET_bRunCsvProfilerDuringScrub(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2dc); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x2dc, B); } // 0x2dc:0 (Size: 0x1, Type: BoolProperty)
    void SET_ScrubUnitMax(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x4, Type: IntProperty)
    void SET_bRuntimeEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2fc); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x2fc, B); } // 0x2fc:0 (Size: 0x1, Type: BoolProperty)
    void SET_StringToSplineMap(const TMap<UDelMarTrackSplineComponent*, FString>& Value) { Write<TMap<UDelMarTrackSplineComponent*, FString>>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x50, Type: MapProperty)
    void SET_Timeline(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc10
class ADelMarTrackRoadProp : public ABuildingProp
{
public:
    uint8_t RoadPropType() const { return Read<uint8_t>(uintptr_t(this) + 0xc00); } // 0xc00 (Size: 0x1, Type: EnumProperty)
    UDelMarTrackSnapToComponent* SnapToComponent() const { return Read<UDelMarTrackSnapToComponent*>(uintptr_t(this) + 0xc08); } // 0xc08 (Size: 0x8, Type: ObjectProperty)

    void SET_RoadPropType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc00, Value); } // 0xc00 (Size: 0x1, Type: EnumProperty)
    void SET_SnapToComponent(const UDelMarTrackSnapToComponent*& Value) { Write<UDelMarTrackSnapToComponent*>(uintptr_t(this) + 0xc08, Value); } // 0xc08 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UDelMarTrackSegmentCollectionSpawnDataProvider : public UInterface
{
public:
};

// Size: 0x50
class UDelMarTrackSettings : public UDeveloperSettings
{
public:
    FGameplayTag RootTrackTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: StructProperty)
    TArray<FDelMarTrackTagConverterData> TagConverterData() const { return Read<TArray<FDelMarTrackTagConverterData>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    FGameplayTag DefaultConverterTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: StructProperty)
    FGameplayTag HiddenTrackTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: StructProperty)

    void SET_RootTrackTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: StructProperty)
    void SET_TagConverterData(const TArray<FDelMarTrackTagConverterData>& Value) { Write<TArray<FDelMarTrackTagConverterData>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_DefaultConverterTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: StructProperty)
    void SET_HiddenTrackTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: StructProperty)
};

// Size: 0x270
class UDelMarTrackSnapToComponent : public USceneComponent
{
public:
    FVector OffsetToOwnerActor() const { return Read<FVector>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x18, Type: StructProperty)

    void SET_OffsetToOwnerActor(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x18, Type: StructProperty)
};

// Size: 0x290
class UDelMarTrackSnapToSplinePointComponent : public UDelMarTrackSnapToComponent
{
public:
    USplineComponent* SplineToSnapTo() const { return Read<USplineComponent*>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x8, Type: ObjectProperty)
    uint8_t SplinePointSnapMode() const { return Read<uint8_t>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x1, Type: EnumProperty)
    int32_t SplinePointIndexToSnapTo() const { return Read<int32_t>(uintptr_t(this) + 0x27c); } // 0x27c (Size: 0x4, Type: IntProperty)

    void SET_SplineToSnapTo(const USplineComponent*& Value) { Write<USplineComponent*>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x8, Type: ObjectProperty)
    void SET_SplinePointSnapMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x1, Type: EnumProperty)
    void SET_SplinePointIndexToSnapTo(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x27c, Value); } // 0x27c (Size: 0x4, Type: IntProperty)
};

// Size: 0x2e0
class ADelMarTrackStaticMeshSegment : public ADelMarTrackSegmentBase
{
public:
    UStaticMeshComponent* StaticMeshComponent() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)

    void SET_StaticMeshComponent(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x360
class UDelMarTrackVehiclePositionComponent : public UDelMarTrackPositionComponent
{
public:
    AFortAthenaVehicle* Vehicle() const { return Read<AFortAthenaVehicle*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)

    void SET_Vehicle(const AFortAthenaVehicle*& Value) { Write<AFortAthenaVehicle*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x350
class UDelMarTrackPositionComponent : public USceneComponent
{
public:
    FTrackPosition ActiveTrackPosition() const { return Read<FTrackPosition>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x20, Type: StructProperty)
    float TrackRadius() const { return Read<float>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x4, Type: FloatProperty)

    void SET_ActiveTrackPosition(const FTrackPosition& Value) { Write<FTrackPosition>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x20, Type: StructProperty)
    void SET_TrackRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x88
class UDelMarTrackManager : public UWorldSubsystem
{
public:
    TArray<ADelMarTrackBase*> DelMarTracks() const { return Read<TArray<ADelMarTrackBase*>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    ADelMarTrackBase* PrimaryTrack() const { return Read<ADelMarTrackBase*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    ADelMarTrackBase* LowestTrack() const { return Read<ADelMarTrackBase*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)

    void SET_DelMarTracks(const TArray<ADelMarTrackBase*>& Value) { Write<TArray<ADelMarTrackBase*>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_PrimaryTrack(const ADelMarTrackBase*& Value) { Write<ADelMarTrackBase*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_LowestTrack(const ADelMarTrackBase*& Value) { Write<ADelMarTrackBase*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x60
class UDelMarTrackPalette : public UDataAsset
{
public:
    TArray<FDelMarTrackPaletteEntry> Palette() const { return Read<TArray<FDelMarTrackPaletteEntry>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarTrackPaletteTransitionEntry> Transitions() const { return Read<TArray<FDelMarTrackPaletteTransitionEntry>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarTrackCapEntry> Caps() const { return Read<TArray<FDelMarTrackCapEntry>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)

    void SET_Palette(const TArray<FDelMarTrackPaletteEntry>& Value) { Write<TArray<FDelMarTrackPaletteEntry>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_Transitions(const TArray<FDelMarTrackPaletteTransitionEntry>& Value) { Write<TArray<FDelMarTrackPaletteTransitionEntry>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_Caps(const TArray<FDelMarTrackCapEntry>& Value) { Write<TArray<FDelMarTrackCapEntry>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2f0
class ADelMarTrackPrefabSegment : public ADelMarTrackSegmentBase
{
public:
    float TangentLength() const { return Read<float>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x4, Type: FloatProperty)
    UStaticMeshComponent* PrefabStaticMesh() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    FName StartSocketName() const { return Read<FName>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x4, Type: NameProperty)
    FName EndSocketName() const { return Read<FName>(uintptr_t(this) + 0x2ec); } // 0x2ec (Size: 0x4, Type: NameProperty)

    void SET_TangentLength(const float& Value) { Write<float>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x4, Type: FloatProperty)
    void SET_PrefabStaticMesh(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    void SET_StartSocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x4, Type: NameProperty)
    void SET_EndSocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2ec, Value); } // 0x2ec (Size: 0x4, Type: NameProperty)
};

// Size: 0x28
class UDelMarTrackSegmentInterface : public UInterface
{
public:
};

// Size: 0x40
class UDelMarTrackPointData : public USplineMetadata
{
public:
    TArray<FDelMarSplinePointMetaData> MetaData() const { return Read<TArray<FDelMarSplinePointMetaData>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    UDelMarTrackSplineComponent* Spline() const { return Read<UDelMarTrackSplineComponent*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_MetaData(const TArray<FDelMarSplinePointMetaData>& Value) { Write<TArray<FDelMarSplinePointMetaData>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_Spline(const UDelMarTrackSplineComponent*& Value) { Write<UDelMarTrackSplineComponent*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x670
class UDelMarTrackSplineComponent : public USplineComponent
{
public:
    int32_t WorldPlaneLookupSubsteps() const { return Read<int32_t>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x4, Type: IntProperty)
    TArray<FDelMarRotationalMinimalFrame> RotationalMinimalFrameNormals() const { return Read<TArray<FDelMarRotationalMinimalFrame>>(uintptr_t(this) + 0x660); } // 0x660 (Size: 0x10, Type: ArrayProperty)

    void SET_WorldPlaneLookupSubsteps(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x4, Type: IntProperty)
    void SET_RotationalMinimalFrameNormals(const TArray<FDelMarRotationalMinimalFrame>& Value) { Write<TArray<FDelMarRotationalMinimalFrame>>(uintptr_t(this) + 0x660, Value); } // 0x660 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2e8
class ADelMarTrackSplineMeshSegment : public ADelMarTrackSegmentBase
{
public:
    USplineMeshComponent* SplineMesh() const { return Read<USplineMeshComponent*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    float SegmentLengthScaler() const { return Read<float>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x4, Type: FloatProperty)

    void SET_SplineMesh(const USplineMeshComponent*& Value) { Write<USplineMeshComponent*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    void SET_SegmentLengthScaler(const float& Value) { Write<float>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x338
class ADelMarTrackVariableSplineMeshSegment : public ADelMarTrackSplineMeshSegment
{
public:
    TMap<UStaticMesh*, int32_t> VariableStaticMeshes() const { return Read<TMap<UStaticMesh*, int32_t>>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x50, Type: MapProperty)

    void SET_VariableStaticMeshes(const TMap<UStaticMesh*, int32_t>& Value) { Write<TMap<UStaticMesh*, int32_t>>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x50, Type: MapProperty)
};

// Size: 0x270
class UDelMarTrackTubeAudioComponent : public UAudioShapePrimitiveComponent
{
public:
    float Radius() const { return Read<float>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x4, Type: FloatProperty)
    FBox SplineAABB() const { return Read<FBox>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x38, Type: StructProperty)
    USplineComponent* Spline() const { return Read<USplineComponent*>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x8, Type: ObjectProperty)
    ADelMarTrackOobTube* ParentOobTube() const { return Read<ADelMarTrackOobTube*>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x8, Type: ObjectProperty)

    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x4, Type: FloatProperty)
    void SET_SplineAABB(const FBox& Value) { Write<FBox>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x38, Type: StructProperty)
    void SET_Spline(const USplineComponent*& Value) { Write<USplineComponent*>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x8, Type: ObjectProperty)
    void SET_ParentOobTube(const ADelMarTrackOobTube*& Value) { Write<ADelMarTrackOobTube*>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x8
struct FDelMarTrackAddedEvent
{
public:
    TWeakObjectPtr<ADelMarTrackBase*> Track() const { return Read<TWeakObjectPtr<ADelMarTrackBase*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Track(const TWeakObjectPtr<ADelMarTrackBase*>& Value) { Write<TWeakObjectPtr<ADelMarTrackBase*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x10
struct FDelMarTrackMaterialCollectionEntry
{
public:
    TArray<UMaterialInstanceConstant*> MICs() const { return Read<TArray<UMaterialInstanceConstant*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_MICs(const TArray<UMaterialInstanceConstant*>& Value) { Write<TArray<UMaterialInstanceConstant*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FDelMarTrackOobTubeMeshSection
{
public:
    USplineMeshComponent* TubeMesh() const { return Read<USplineMeshComponent*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    int32_t PointIndex() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    float StartDistanceAlongSpline() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float EndDistanceAlongSpline() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_TubeMesh(const USplineMeshComponent*& Value) { Write<USplineMeshComponent*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_PointIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_StartDistanceAlongSpline(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_EndDistanceAlongSpline(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FDelMarTrackOobTubePointMetaData
{
public:
    FVector2D LocationOffset() const { return Read<FVector2D>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FVector2D ScaleOffset() const { return Read<FVector2D>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    int32_t NumSubsections() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)
    bool bShouldGenerateTube() const { return Read<bool>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: BoolProperty)
    bool bShouldMirrorAttachedTrackPoint() const { return Read<bool>(uintptr_t(this) + 0x25); } // 0x25 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreAutoTransitionScaling() const { return Read<bool>(uintptr_t(this) + 0x26); } // 0x26 (Size: 0x1, Type: BoolProperty)

    void SET_LocationOffset(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_ScaleOffset(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_NumSubsections(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
    void SET_bShouldGenerateTube(const bool& Value) { Write<bool>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldMirrorAttachedTrackPoint(const bool& Value) { Write<bool>(uintptr_t(this) + 0x25, Value); } // 0x25 (Size: 0x1, Type: BoolProperty)
    void SET_bIgnoreAutoTransitionScaling(const bool& Value) { Write<bool>(uintptr_t(this) + 0x26, Value); } // 0x26 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x40
struct FDelMarTrackPaletteTransitionEntry_v2
{
public:
    FGameplayTag TagA() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FGameplayTag TagB() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)
    UClass* TRANSITION() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)
    bool bUseReverse() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    UClass* Reverse() const { return Read<UClass*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ClassProperty)
    bool bEnableOOBTubeTransitions() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    UStaticMesh* OOBTubeTransitionMesh() const { return Read<UStaticMesh*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    bool bOverrideReverseOOBTubeMesh() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    UStaticMesh* ReverseOOBTubeTransitionMesh() const { return Read<UStaticMesh*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_TagA(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_TagB(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
    void SET_TRANSITION(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
    void SET_bUseReverse(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_Reverse(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ClassProperty)
    void SET_bEnableOOBTubeTransitions(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_OOBTubeTransitionMesh(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_bOverrideReverseOOBTubeMesh(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_ReverseOOBTubeTransitionMesh(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x38
struct FDelMarTrackPaletteTrackTypeEntry
{
public:
    FGameplayTag StyleTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    TArray<UClass*> SegmentActors() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    UClass* FrontEndcap() const { return Read<UClass*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ClassProperty)
    bool bIsFrontEndcapReversable() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    UClass* BackEndcap() const { return Read<UClass*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ClassProperty)
    UTexture* WidgetImage() const { return Read<UTexture*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_StyleTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_SegmentActors(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_FrontEndcap(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ClassProperty)
    void SET_bIsFrontEndcapReversable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_BackEndcap(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ClassProperty)
    void SET_WidgetImage(const UTexture*& Value) { Write<UTexture*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x8
struct FDelMarTrackPointDistanceRange
{
public:
    float BeginDistanceAlongSpline() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float EndDistanceAlongSpline() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_BeginDistanceAlongSpline(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_EndDistanceAlongSpline(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FDelMarTrackPointIndexRange
{
public:
    int32_t BeginPointIndex() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t EndPointIndex() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_BeginPointIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_EndPointIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x68
struct FDelMarTrackProp
{
public:
    TSoftObjectPtr<USkeletalMesh> SkeletalMesh() const { return Read<TSoftObjectPtr<USkeletalMesh>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh> StaticMesh() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    uint8_t PropType() const { return Read<uint8_t>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x1, Type: EnumProperty)

    void SET_SkeletalMesh(const TSoftObjectPtr<USkeletalMesh>& Value) { Write<TSoftObjectPtr<USkeletalMesh>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_StaticMesh(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    void SET_PropType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x1, Type: EnumProperty)
};

// Size: 0xf0
struct FDelMarTrackPropSection
{
public:
    TArray<FDelMarTrackPointIndexRange> RangesToApplyTo() const { return Read<TArray<FDelMarTrackPointIndexRange>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    FDelMarTrackProp PropToPlace() const { return Read<FDelMarTrackProp>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x68, Type: StructProperty)
    int32_t NumPropsToPlace() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)
    double DistanceBetweenProps() const { return Read<double>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: DoubleProperty)
    FName CustomizationPlacementBase() const { return Read<FName>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: NameProperty)
    double PlacementBeginPadding() const { return Read<double>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: DoubleProperty)
    double PlacementEndPadding() const { return Read<double>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: DoubleProperty)
    double PlacementDistanceOffset() const { return Read<double>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: DoubleProperty)
    FVector PlacementScale() const { return Read<FVector>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x18, Type: StructProperty)
    FRotator PlacementRotationOffset() const { return Read<FRotator>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x18, Type: StructProperty)
    uint8_t SupportedTrackSide() const { return Read<uint8_t>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x1, Type: EnumProperty)
    uint8_t PlacementPosition() const { return Read<uint8_t>(uintptr_t(this) + 0xd9); } // 0xd9 (Size: 0x1, Type: EnumProperty)
    uint8_t PlacementSpread() const { return Read<uint8_t>(uintptr_t(this) + 0xda); } // 0xda (Size: 0x1, Type: EnumProperty)
    FString RangesToApplyToEditorString() const { return Read<FString>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: StrProperty)

    void SET_RangesToApplyTo(const TArray<FDelMarTrackPointIndexRange>& Value) { Write<TArray<FDelMarTrackPointIndexRange>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_PropToPlace(const FDelMarTrackProp& Value) { Write<FDelMarTrackProp>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x68, Type: StructProperty)
    void SET_NumPropsToPlace(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
    void SET_DistanceBetweenProps(const double& Value) { Write<double>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: DoubleProperty)
    void SET_CustomizationPlacementBase(const FName& Value) { Write<FName>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: NameProperty)
    void SET_PlacementBeginPadding(const double& Value) { Write<double>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: DoubleProperty)
    void SET_PlacementEndPadding(const double& Value) { Write<double>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: DoubleProperty)
    void SET_PlacementDistanceOffset(const double& Value) { Write<double>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: DoubleProperty)
    void SET_PlacementScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x18, Type: StructProperty)
    void SET_PlacementRotationOffset(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x18, Type: StructProperty)
    void SET_SupportedTrackSide(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x1, Type: EnumProperty)
    void SET_PlacementPosition(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xd9, Value); } // 0xd9 (Size: 0x1, Type: EnumProperty)
    void SET_PlacementSpread(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xda, Value); } // 0xda (Size: 0x1, Type: EnumProperty)
    void SET_RangesToApplyToEditorString(const FString& Value) { Write<FString>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x18
struct FDelMarTrackSegmentSpawnInfo
{
public:
};

// Size: 0x30
struct FDelMarTrackSegmentCollectionProxyData
{
public:
};

// Size: 0x28
struct FDelMarSegmentActorCollection
{
public:
    TArray<ADelMarTrackSegmentBase*> Segments() const { return Read<TArray<ADelMarTrackSegmentBase*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    ADelMarTrackBase* Track() const { return Read<ADelMarTrackBase*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    TArray<UActorComponent*> PropComponents() const { return Read<TArray<UActorComponent*>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Segments(const TArray<ADelMarTrackSegmentBase*>& Value) { Write<TArray<ADelMarTrackSegmentBase*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Track(const ADelMarTrackBase*& Value) { Write<ADelMarTrackBase*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_PropComponents(const TArray<UActorComponent*>& Value) { Write<TArray<UActorComponent*>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xc
struct FDelMarTrackTagConverterData
{
public:
    FGameplayTag v1Tag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    bool bCheckCustomizations() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bNeedRightRail() const { return Read<bool>(uintptr_t(this) + 0x5); } // 0x5 (Size: 0x1, Type: BoolProperty)
    bool bNeedLeftRail() const { return Read<bool>(uintptr_t(this) + 0x6); } // 0x6 (Size: 0x1, Type: BoolProperty)
    FGameplayTag v2Tag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)

    void SET_v1Tag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_bCheckCustomizations(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_bNeedRightRail(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5, Value); } // 0x5 (Size: 0x1, Type: BoolProperty)
    void SET_bNeedLeftRail(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6, Value); } // 0x6 (Size: 0x1, Type: BoolProperty)
    void SET_v2Tag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
};

// Size: 0x70
struct FDelMarTrackTransformData
{
public:
    TWeakObjectPtr<ADelMarTrackBase*> Track() const { return Read<TWeakObjectPtr<ADelMarTrackBase*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FTransform TrackTransform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)

    void SET_Track(const TWeakObjectPtr<ADelMarTrackBase*>& Value) { Write<TWeakObjectPtr<ADelMarTrackBase*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_TrackTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
};

// Size: 0x58
struct FDelMarTrackPaletteTransitionEntry
{
public:
    FGameplayTag TypeA() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FGameplayTag TypeB() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)
    FString Title() const { return Read<FString>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StrProperty)

    void SET_TypeA(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_TypeB(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
    void SET_Title(const FString& Value) { Write<FString>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StrProperty)
};

// Size: 0x48
struct FDelMarTrackCapEntry
{
public:
    FGameplayTag Tag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)

    void SET_Tag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
};

// Size: 0x48
struct FDelMarTrackPaletteEntry
{
public:
    FGameplayTag TrackTypeTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    TArray<FString> MeshCustomizations() const { return Read<TArray<FString>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    FString Title() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)

    void SET_TrackTypeTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_MeshCustomizations(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_Title(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
};

// Size: 0x20
struct FTrackPosition
{
public:
    ADelMarTrackBase* Track() const { return Read<ADelMarTrackBase*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    float DistanceAlongSpline() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float RawDistanceAlongSpline() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float DistanceToVehicleSquared() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float LastKnownGoodDistance() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    int32_t SegmentIndex() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    bool bIsValid() const { return Read<bool>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: BoolProperty)

    void SET_Track(const ADelMarTrackBase*& Value) { Write<ADelMarTrackBase*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_DistanceAlongSpline(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_RawDistanceAlongSpline(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_DistanceToVehicleSquared(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_LastKnownGoodDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_SegmentIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_bIsValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc8
struct FDelMarSplineSegmentInfo
{
public:
};

// Size: 0x80
struct FDelMarSplinePointMetaData
{
public:
    FGameplayTag TrackTypeTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    float TrackRadius() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bForceValidTrack() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bUseStableRoll() const { return Read<bool>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: BoolProperty)
    bool bUseFrontEndcap() const { return Read<bool>(uintptr_t(this) + 0xa); } // 0xa (Size: 0x1, Type: BoolProperty)
    bool bUseBackEndcap() const { return Read<bool>(uintptr_t(this) + 0xb); } // 0xb (Size: 0x1, Type: BoolProperty)
    TMap<bool, FString> EnabledMeshCustomizations() const { return Read<TMap<bool, FString>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)

    void SET_TrackTypeTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_TrackRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_bForceValidTrack(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_bUseStableRoll(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: BoolProperty)
    void SET_bUseFrontEndcap(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa, Value); } // 0xa (Size: 0x1, Type: BoolProperty)
    void SET_bUseBackEndcap(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb, Value); } // 0xb (Size: 0x1, Type: BoolProperty)
    void SET_EnabledMeshCustomizations(const TMap<bool, FString>& Value) { Write<TMap<bool, FString>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
};

// Size: 0x20
struct FClosestLocationToWorldPlaneResult
{
public:
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    float Key() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float DistanceToPlane() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)

    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Key(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_DistanceToPlane(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x68
struct FDelMarRotationalMinimalFrame
{
public:
    float InputKey() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FVector origin() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Tangent() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector RotationAxis() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    FVector Normal() const { return Read<FVector>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)

    void SET_InputKey(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_origin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Tangent(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_RotationAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_Normal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
};

