/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CherrySmokeHeroRankingSystemRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayAbilities.h"

// Size: 0x108
class UCherrySmokeHeroRankingAnalyticsComponent : public UGameStateComponent
{
public:
};

// Size: 0x28
class UCherrySmokeHeroRankingCheatManager : public UChildCheatManager
{
public:
};

// Size: 0x210
class UCherrySmokeHeroRankingGlobalManager : public UGameStateComponent
{
public:
    FCherrySmokeHeroRankRuntimeDataArray PerTeamRuntimeRankData() const { return Read<FCherrySmokeHeroRankRuntimeDataArray>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x120, Type: StructProperty)
    TArray<FCherrySmokeHeroRankData> Ranks() const { return Read<TArray<FCherrySmokeHeroRankData>>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x10, Type: ArrayProperty)
    UClass* HeroRankingManagerComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ClassProperty)

    void SET_PerTeamRuntimeRankData(const FCherrySmokeHeroRankRuntimeDataArray& Value) { Write<FCherrySmokeHeroRankRuntimeDataArray>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x120, Type: StructProperty)
    void SET_Ranks(const TArray<FCherrySmokeHeroRankData>& Value) { Write<TArray<FCherrySmokeHeroRankData>>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x10, Type: ArrayProperty)
    void SET_HeroRankingManagerComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x240
class UCherrySmokeHeroRankingManager : public UFortGameFrameworkComponent_ContextualReactions
{
public:
    FScalableFloat MaxMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x28, Type: StructProperty)
    FHeroRankMultiplier ActiveMultiplier() const { return Read<FHeroRankMultiplier>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x8, Type: StructProperty)

    void SET_MaxMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x28, Type: StructProperty)
    void SET_ActiveMultiplier(const FHeroRankMultiplier& Value) { Write<FHeroRankMultiplier>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x8, Type: StructProperty)
};

// Size: 0x50
class UFortQueryGenerator_HeroRankingDiscoverables : public UEnvQueryGenerator
{
public:
};

// Size: 0x200
class UFortQueryTest_HeroRank : public UEnvQueryTest
{
public:
    UClass* ContextPlayer() const { return Read<UClass*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ClassProperty)

    void SET_ContextPlayer(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x28
class UHeroRankingUnlockableInterface : public UInterface
{
public:
};

// Size: 0x8
struct FHeroRankMultiplier
{
public:
    float Multiplier() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FHeroRankingMultiplierHandle Handle() const { return Read<FHeroRankingMultiplierHandle>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)

    void SET_Multiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Handle(const FHeroRankingMultiplierHandle& Value) { Write<FHeroRankingMultiplierHandle>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
};

// Size: 0x4
struct FHeroRankingMultiplierHandle
{
public:
    int32_t Handle() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)

    void SET_Handle(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x30
struct FCherrySmokeHeroRankData
{
public:
    FGameplayTag Rank() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FScalableFloat PointsRequirement() const { return Read<FScalableFloat>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x28, Type: StructProperty)

    void SET_Rank(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_PointsRequirement(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x20
struct FCherrySmokeHeroRankRuntimeData : public FFastArraySerializerItem
{
public:
    char TeamID() const { return Read<char>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: ByteProperty)
    float HeroPoints() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float OldHeroPoints() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    int32_t CurrentRankIndex() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t OldCurrentRankIndex() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)

    void SET_TeamID(const char& Value) { Write<char>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: ByteProperty)
    void SET_HeroPoints(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_OldHeroPoints(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_CurrentRankIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_OldCurrentRankIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
};

// Size: 0x120
struct FCherrySmokeHeroRankRuntimeDataArray : public FFastArraySerializer
{
public:
    TArray<FCherrySmokeHeroRankRuntimeData> Entries() const { return Read<TArray<FCherrySmokeHeroRankRuntimeData>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<UCherrySmokeHeroRankingGlobalManager*> WeakOwningComponent() const { return Read<TWeakObjectPtr<UCherrySmokeHeroRankingGlobalManager*>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Entries(const TArray<FCherrySmokeHeroRankRuntimeData>& Value) { Write<TArray<FCherrySmokeHeroRankRuntimeData>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    void SET_WeakOwningComponent(const TWeakObjectPtr<UCherrySmokeHeroRankingGlobalManager*>& Value) { Write<TWeakObjectPtr<UCherrySmokeHeroRankingGlobalManager*>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x10
struct FOnHeroRankChanged
{
public:
    FGameplayTag RankTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    AFortPlayerStateAthena* Player() const { return Read<AFortPlayerStateAthena*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_RankTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_Player(const AFortPlayerStateAthena*& Value) { Write<AFortPlayerStateAthena*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x18
struct FOnHeroPointsEarned
{
public:
    float PointsEarned() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    AFortPlayerStateAthena* Player() const { return Read<AFortPlayerStateAthena*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag ContextTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: StructProperty)
    uint8_t PointsSource() const { return Read<uint8_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: EnumProperty)

    void SET_PointsEarned(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Player(const AFortPlayerStateAthena*& Value) { Write<AFortPlayerStateAthena*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_ContextTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: StructProperty)
    void SET_PointsSource(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x10
struct FFortEventReaction_IncreaseCherrySmokeHeroPointsMultiplier : public FEventReactionBase
{
public:
    float MultiplierDelta() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_MultiplierDelta(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FFortEventReaction_IncreaseCherrySmokeHeroRank : public FEventReactionBase
{
public:
    FGameplayTag Context() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    float PointsAwarded() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    bool bIgnoreMultiplier() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_Context(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_PointsAwarded(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_bIgnoreMultiplier(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

