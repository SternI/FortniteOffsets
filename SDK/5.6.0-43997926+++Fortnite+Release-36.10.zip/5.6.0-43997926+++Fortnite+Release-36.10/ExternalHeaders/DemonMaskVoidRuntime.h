/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DemonMaskVoidRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "FortniteGame.h"

// Size: 0x820
class UDemonMaskVoidGadgetAnimInstance : public UMaskBaseCCPAnimInstance
{
public:
    FVector Floater() const { return Read<FVector>(uintptr_t(this) + 0x7f8); } // 0x7f8 (Size: 0x18, Type: StructProperty)
    double ElapsedTime() const { return Read<double>(uintptr_t(this) + 0x810); } // 0x810 (Size: 0x8, Type: DoubleProperty)

    void SET_Floater(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x7f8, Value); } // 0x7f8 (Size: 0x18, Type: StructProperty)
    void SET_ElapsedTime(const double& Value) { Write<double>(uintptr_t(this) + 0x810, Value); } // 0x810 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x1310
class UDemonMaskVoidLayerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    float IsCasting() const { return Read<float>(uintptr_t(this) + 0x1308); } // 0x1308 (Size: 0x4, Type: FloatProperty)

    void SET_IsCasting(const float& Value) { Write<float>(uintptr_t(this) + 0x1308, Value); } // 0x1308 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xb68
class UFortGA_DemonMask_Void_Teleport_Base : public UFortGameplayAbility
{
public:
};

// Size: 0xf8
class UFortPawnComponent_VoidTeleport : public UFortPawnComponent
{
public:
    UClass* TeleportHelperClassToSpawn() const { return Read<UClass*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    FGameplayTag DemonMaskVoidEquipmentTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: StructProperty)
    TWeakObjectPtr<ABuildingGameplayActor*> BGAToTeleport() const { return Read<TWeakObjectPtr<ABuildingGameplayActor*>>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortProjectileBase*> CurrentTrackedVoidProjectile() const { return Read<TWeakObjectPtr<AFortProjectileBase*>>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPawn*> OwnerFortPawn() const { return Read<TWeakObjectPtr<AFortPawn*>>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AVoidMaskTeleportHelperActor*> TeleportHelperActor() const { return Read<TWeakObjectPtr<AVoidMaskTeleportHelperActor*>>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x8, Type: WeakObjectProperty)
    bool bForceCrouch() const { return Read<bool>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x1, Type: BoolProperty)
    bool bForceCrouchPredicted() const { return Read<bool>(uintptr_t(this) + 0xed); } // 0xed (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<UFortMovementComp_Character*> OwnerFortMovementComp() const { return Read<TWeakObjectPtr<UFortMovementComp_Character*>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_TeleportHelperClassToSpawn(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    void SET_DemonMaskVoidEquipmentTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: StructProperty)
    void SET_BGAToTeleport(const TWeakObjectPtr<ABuildingGameplayActor*>& Value) { Write<TWeakObjectPtr<ABuildingGameplayActor*>>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x8, Type: WeakObjectProperty)
    void SET_CurrentTrackedVoidProjectile(const TWeakObjectPtr<AFortProjectileBase*>& Value) { Write<TWeakObjectPtr<AFortProjectileBase*>>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_OwnerFortPawn(const TWeakObjectPtr<AFortPawn*>& Value) { Write<TWeakObjectPtr<AFortPawn*>>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x8, Type: WeakObjectProperty)
    void SET_TeleportHelperActor(const TWeakObjectPtr<AVoidMaskTeleportHelperActor*>& Value) { Write<TWeakObjectPtr<AVoidMaskTeleportHelperActor*>>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_bForceCrouch(const bool& Value) { Write<bool>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x1, Type: BoolProperty)
    void SET_bForceCrouchPredicted(const bool& Value) { Write<bool>(uintptr_t(this) + 0xed, Value); } // 0xed (Size: 0x1, Type: BoolProperty)
    void SET_OwnerFortMovementComp(const TWeakObjectPtr<UFortMovementComp_Character*>& Value) { Write<TWeakObjectPtr<UFortMovementComp_Character*>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x2b0
class AVoidMaskTeleportHelperActor : public AActor
{
public:
    UCapsuleComponent* CapsuleComponent() const { return Read<UCapsuleComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)

    void SET_CapsuleComponent(const UCapsuleComponent*& Value) { Write<UCapsuleComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

