/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CurveExpression
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"

// Size: 0x50
class UCurveExpressionsDataAsset : public UDataAsset
{
public:
    TArray<FName> NamedConstants() const { return Read<TArray<FName>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_NamedConstants(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x110
struct FAnimNode_RemapCurvesBase : public FAnimNode_Base
{
public:
    FPoseLink SourcePose() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    uint8_t ExpressionSource() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)
    FCurveExpressionList ExpressionList() const { return Read<FCurveExpressionList>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    UCurveExpressionsDataAsset* CurveExpressionsDataAsset() const { return Read<UCurveExpressionsDataAsset*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    TMap<FString, FName> CurveExpressions() const { return Read<TMap<FString, FName>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x50, Type: MapProperty)
    bool bExpressionsImmutable() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)
    TArray<FName> CachedConstantNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: ArrayProperty)

    void SET_SourcePose(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_ExpressionSource(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
    void SET_ExpressionList(const FCurveExpressionList& Value) { Write<FCurveExpressionList>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_CurveExpressionsDataAsset(const UCurveExpressionsDataAsset*& Value) { Write<UCurveExpressionsDataAsset*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_CurveExpressions(const TMap<FString, FName>& Value) { Write<TMap<FString, FName>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x50, Type: MapProperty)
    void SET_bExpressionsImmutable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
    void SET_CachedConstantNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FCurveExpressionList
{
public:
    FString AssignmentExpressions() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)

    void SET_AssignmentExpressions(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x110
struct FAnimNode_RemapCurves : public FAnimNode_RemapCurvesBase
{
public:
};

// Size: 0x188
struct FAnimNode_RemapCurvesFromMesh : public FAnimNode_RemapCurvesBase
{
public:
    TWeakObjectPtr<USkeletalMeshComponent*> SourceMeshComponent() const { return Read<TWeakObjectPtr<USkeletalMeshComponent*>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: WeakObjectProperty)
    bool bUseAttachedParent() const { return Read<bool>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x1, Type: BoolProperty)

    void SET_SourceMeshComponent(const TWeakObjectPtr<USkeletalMeshComponent*>& Value) { Write<TWeakObjectPtr<USkeletalMeshComponent*>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: WeakObjectProperty)
    void SET_bUseAttachedParent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x1, Type: BoolProperty)
};

