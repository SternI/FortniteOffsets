/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DLSS
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
// Size: 0x30
class UDLSSOverrideSettings : public UObject
{
public:
    uint8_t EnableDLSSInEditorViewportsOverride() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t EnableDLSSInPlayInEditorViewportsOverride() const { return Read<uint8_t>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: EnumProperty)
    bool bShowDLSSIncompatiblePluginsToolsWarnings() const { return Read<bool>(uintptr_t(this) + 0x2a); } // 0x2a (Size: 0x1, Type: BoolProperty)
    uint8_t ShowDLSSSDebugOnScreenMessages() const { return Read<uint8_t>(uintptr_t(this) + 0x2b); } // 0x2b (Size: 0x1, Type: EnumProperty)

    void SET_EnableDLSSInEditorViewportsOverride(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_EnableDLSSInPlayInEditorViewportsOverride(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: EnumProperty)
    void SET_bShowDLSSIncompatiblePluginsToolsWarnings(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2a, Value); } // 0x2a (Size: 0x1, Type: BoolProperty)
    void SET_ShowDLSSSDebugOnScreenMessages(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2b, Value); } // 0x2b (Size: 0x1, Type: EnumProperty)
};

// Size: 0x60
class UDLSSSettings : public UObject
{
public:
    bool bEnableDLSSD3D12() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bEnableDLSSD3D11() const { return Read<bool>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: BoolProperty)
    bool bEnableDLSSVulkan() const { return Read<bool>(uintptr_t(this) + 0x2a); } // 0x2a (Size: 0x1, Type: BoolProperty)
    bool bEnableDLSSInEditorViewports() const { return Read<bool>(uintptr_t(this) + 0x2b); } // 0x2b (Size: 0x1, Type: BoolProperty)
    bool bEnableDLSSInPlayInEditorViewports() const { return Read<bool>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: BoolProperty)
    bool bShowDLSSSDebugOnScreenMessages() const { return Read<bool>(uintptr_t(this) + 0x2d); } // 0x2d (Size: 0x1, Type: BoolProperty)
    FString GenericDLSSBinaryPath() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    bool bGenericDLSSBinaryExists() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)
    uint32_t NVIDIANGXApplicationId() const { return Read<uint32_t>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: UInt32Property)
    FString CustomDLSSBinaryPath() const { return Read<FString>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StrProperty)
    bool bCustomDLSSBinaryExists() const { return Read<bool>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x1, Type: BoolProperty)

    void SET_bEnableDLSSD3D12(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableDLSSD3D11(const bool& Value) { Write<bool>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableDLSSVulkan(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2a, Value); } // 0x2a (Size: 0x1, Type: BoolProperty)
    void SET_bEnableDLSSInEditorViewports(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2b, Value); } // 0x2b (Size: 0x1, Type: BoolProperty)
    void SET_bEnableDLSSInPlayInEditorViewports(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: BoolProperty)
    void SET_bShowDLSSSDebugOnScreenMessages(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2d, Value); } // 0x2d (Size: 0x1, Type: BoolProperty)
    void SET_GenericDLSSBinaryPath(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_bGenericDLSSBinaryExists(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
    void SET_NVIDIANGXApplicationId(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: UInt32Property)
    void SET_CustomDLSSBinaryPath(const FString& Value) { Write<FString>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StrProperty)
    void SET_bCustomDLSSBinaryExists(const bool& Value) { Write<bool>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x1, Type: BoolProperty)
};

