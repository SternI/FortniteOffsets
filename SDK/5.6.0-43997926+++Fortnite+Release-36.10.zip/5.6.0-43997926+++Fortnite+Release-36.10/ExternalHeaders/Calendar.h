/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Calendar
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "UI.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "CommonUI.h"
#include "SlateCore.h"
#include "CompeteUI.h"
#include "FortniteUI.h"
#include "UMG.h"
#include "Systems.h"
#include "UIKit.h"
#include "Valkyrie.h"
#include "Blueprints.h"
#include "TournamentTile.h"

// Size: 0x3b1
class UWBP_Compete_Block_Image_C : public UWBP_UIKit_Block_Base_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: StructProperty)
    UFortMobileImage* Image() const { return Read<UFortMobileImage*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_Focused_Transition() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_Disabled_Transition() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_Selected_Transition() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_SelectedFocused_Transition() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_SelectedDisabled_Transition() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_Outline_Transition() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstance* ImageMaterial() const { return Read<UMaterialInstance*>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* ImageMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    bool Is_Marked() const { return Read<bool>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: StructProperty)
    void SET_Image(const UFortMobileImage*& Value) { Write<UFortMobileImage*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_Focused_Transition(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_Disabled_Transition(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_Selected_Transition(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_SelectedFocused_Transition(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_SelectedDisabled_Transition(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_Outline_Transition(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    void SET_ImageMaterial(const UMaterialInstance*& Value) { Write<UMaterialInstance*>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    void SET_ImageMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Is_Marked(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x390
class UWBP_IconHintsPanel_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: StructProperty)
    UWBP_IconHint_C* VictoryHint() const { return Read<UWBP_IconHint_C*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    UWBP_IconHint_C* RanckedHint() const { return Read<UWBP_IconHint_C*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    UWBP_IconHint_C* OtherHint() const { return Read<UWBP_IconHint_C*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    UWBP_IconHint_C* ItemShopHint() const { return Read<UWBP_IconHint_C*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Background() const { return Read<UImage*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    UWBP_IconHint_C* FNCSHint() const { return Read<UWBP_IconHint_C*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    UWBP_IconHint_C* CashHint() const { return Read<UWBP_IconHint_C*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Scrim_C* BackgroundBlur() const { return Read<UWBP_UIKit_Scrim_C*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: StructProperty)
    void SET_VictoryHint(const UWBP_IconHint_C*& Value) { Write<UWBP_IconHint_C*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_RanckedHint(const UWBP_IconHint_C*& Value) { Write<UWBP_IconHint_C*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_OtherHint(const UWBP_IconHint_C*& Value) { Write<UWBP_IconHint_C*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemShopHint(const UWBP_IconHint_C*& Value) { Write<UWBP_IconHint_C*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Background(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_FNCSHint(const UWBP_IconHint_C*& Value) { Write<UWBP_IconHint_C*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_CashHint(const UWBP_IconHint_C*& Value) { Write<UWBP_IconHint_C*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    void SET_BackgroundBlur(const UWBP_UIKit_Scrim_C*& Value) { Write<UWBP_UIKit_Scrim_C*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x378
class UWBP_IconHint_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* NameExplanation() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Explanation() const { return Read<UImage*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* IconMaterial() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    FText Name() const { return Read<FText>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x10, Type: TextProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: StructProperty)
    void SET_NameExplanation(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Explanation(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_IconMaterial(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_Name(const FText& Value) { Write<FText>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x10, Type: TextProperty)
};

// Size: 0x18f8
class UWBP_FilterButton_C : public UWBP_UIKit_Button_Generic_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x18f0); } // 0x18f0 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x18f0, Value); } // 0x18f0 (Size: 0x8, Type: StructProperty)
};

// Size: 0x390
class UWBP_CalendarWrapper_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_Month() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Generic_C* PreviousButton() const { return Read<UWBP_UIKit_Button_Generic_C*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Generic_C* NextButton() const { return Read<UWBP_UIKit_Button_Generic_C*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_ShowButtons() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: StructProperty)
    void SET_Text_Month(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_PreviousButton(const UWBP_UIKit_Button_Generic_C*& Value) { Write<UWBP_UIKit_Button_Generic_C*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_NextButton(const UWBP_UIKit_Button_Generic_C*& Value) { Write<UWBP_UIKit_Button_Generic_C*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_ShowButtons(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x350
class UWBP_EmptyTile_Entry_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: StructProperty)
};

// Size: 0x174a
class UWBP_CalendarTile_C : public UWBP_CompeteTileButton_Base_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1578); } // 0x1578 (Size: 0x8, Type: StructProperty)
    UGridPanel* TournamentIcons() const { return Read<UGridPanel*>(uintptr_t(this) + 0x1580); } // 0x1580 (Size: 0x8, Type: ObjectProperty)
    UImage* TotalTournamentsIcon() const { return Read<UImage*>(uintptr_t(this) + 0x1588); } // 0x1588 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Date() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1590); } // 0x1590 (Size: 0x8, Type: ObjectProperty)
    UStackBox* Stack_TotalTournaments() const { return Read<UStackBox*>(uintptr_t(this) + 0x1598); } // 0x1598 (Size: 0x8, Type: ObjectProperty)
    UCommonBorder* SelectionOutline() const { return Read<UCommonBorder*>(uintptr_t(this) + 0x15a0); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* Root() const { return Read<UGridPanel*>(uintptr_t(this) + 0x15a8); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* RichText_Tournaments() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x15b0); } // 0x15b0 (Size: 0x8, Type: ObjectProperty)
    UImage* Fade() const { return Read<UImage*>(uintptr_t(this) + 0x15b8); } // 0x15b8 (Size: 0x8, Type: ObjectProperty)
    UUEFN_TextBlock_C* DebugTxt() const { return Read<UUEFN_TextBlock_C*>(uintptr_t(this) + 0x15c0); } // 0x15c0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Date() const { return Read<UOverlay*>(uintptr_t(this) + 0x15c8); } // 0x15c8 (Size: 0x8, Type: ObjectProperty)
    UImage* Bookmarked() const { return Read<UImage*>(uintptr_t(this) + 0x15d0); } // 0x15d0 (Size: 0x8, Type: ObjectProperty)
    UWBP_Compete_Block_Image_C* Block_VictoryIcon() const { return Read<UWBP_Compete_Block_Image_C*>(uintptr_t(this) + 0x15d8); } // 0x15d8 (Size: 0x8, Type: ObjectProperty)
    UWBP_Compete_Block_Image_C* Block_RankedIcon() const { return Read<UWBP_Compete_Block_Image_C*>(uintptr_t(this) + 0x15e0); } // 0x15e0 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Block_Outline_C* Block_Outline() const { return Read<UWBP_UIKit_Block_Outline_C*>(uintptr_t(this) + 0x15e8); } // 0x15e8 (Size: 0x8, Type: ObjectProperty)
    UWBP_Compete_Block_Image_C* Block_OthersIcon() const { return Read<UWBP_Compete_Block_Image_C*>(uintptr_t(this) + 0x15f0); } // 0x15f0 (Size: 0x8, Type: ObjectProperty)
    UWBP_Compete_Block_Image_C* Block_ItemShopIcon() const { return Read<UWBP_Compete_Block_Image_C*>(uintptr_t(this) + 0x15f8); } // 0x15f8 (Size: 0x8, Type: ObjectProperty)
    UWBP_Compete_Block_Image_C* Block_FNCSIcon() const { return Read<UWBP_Compete_Block_Image_C*>(uintptr_t(this) + 0x1600); } // 0x1600 (Size: 0x8, Type: ObjectProperty)
    UWBP_Compete_Block_Image_C* Block_CashIcon() const { return Read<UWBP_Compete_Block_Image_C*>(uintptr_t(this) + 0x1608); } // 0x1608 (Size: 0x8, Type: ObjectProperty)
    UImage* Background_Date() const { return Read<UImage*>(uintptr_t(this) + 0x1610); } // 0x1610 (Size: 0x8, Type: ObjectProperty)
    UImage* Background() const { return Read<UImage*>(uintptr_t(this) + 0x1618); } // 0x1618 (Size: 0x8, Type: ObjectProperty)
    UCommonVisualAttachment* AttachmentBookmarked() const { return Read<UCommonVisualAttachment*>(uintptr_t(this) + 0x1620); } // 0x1620 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_ShowTournamentIcons() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1628); } // 0x1628 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_Locked() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1630); } // 0x1630 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_Selected() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1638); } // 0x1638 (Size: 0x8, Type: ObjectProperty)
    UFortPoblanoTournamentsCalendarDayTileVM* FortPoblanoTournamentsCalendarDayTileVM() const { return Read<UFortPoblanoTournamentsCalendarDayTileVM*>(uintptr_t(this) + 0x1640); } // 0x1640 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstance* Material_Cups() const { return Read<UMaterialInstance*>(uintptr_t(this) + 0x1648); } // 0x1648 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstance* Material_TotalTournaments() const { return Read<UMaterialInstance*>(uintptr_t(this) + 0x1650); } // 0x1650 (Size: 0x8, Type: ObjectProperty)
    FSlateFontInfo Font_TotalTournaments() const { return Read<FSlateFontInfo>(uintptr_t(this) + 0x1658); } // 0x1658 (Size: 0x58, Type: StructProperty)
    FSlateFontInfo Font_Date() const { return Read<FSlateFontInfo>(uintptr_t(this) + 0x16b0); } // 0x16b0 (Size: 0x58, Type: StructProperty)
    UMaterialInstance* BackgroundMaterial() const { return Read<UMaterialInstance*>(uintptr_t(this) + 0x1708); } // 0x1708 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstance* Material_FontDateToday() const { return Read<UMaterialInstance*>(uintptr_t(this) + 0x1710); } // 0x1710 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* Cash_Texture() const { return Read<UTexture2D*>(uintptr_t(this) + 0x1718); } // 0x1718 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* FNCS_Texture() const { return Read<UTexture2D*>(uintptr_t(this) + 0x1720); } // 0x1720 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* ItemShop_Texture() const { return Read<UTexture2D*>(uintptr_t(this) + 0x1728); } // 0x1728 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* Victory_Texture() const { return Read<UTexture2D*>(uintptr_t(this) + 0x1730); } // 0x1730 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* Others_Texture() const { return Read<UTexture2D*>(uintptr_t(this) + 0x1738); } // 0x1738 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* Ranked_Texture() const { return Read<UTexture2D*>(uintptr_t(this) + 0x1740); } // 0x1740 (Size: 0x8, Type: ObjectProperty)
    bool FakeLockedState() const { return Read<bool>(uintptr_t(this) + 0x1748); } // 0x1748 (Size: 0x1, Type: BoolProperty)
    bool IsCalendarOpened() const { return Read<bool>(uintptr_t(this) + 0x1749); } // 0x1749 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1578, Value); } // 0x1578 (Size: 0x8, Type: StructProperty)
    void SET_TournamentIcons(const UGridPanel*& Value) { Write<UGridPanel*>(uintptr_t(this) + 0x1580, Value); } // 0x1580 (Size: 0x8, Type: ObjectProperty)
    void SET_TotalTournamentsIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1588, Value); } // 0x1588 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_Date(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1590, Value); } // 0x1590 (Size: 0x8, Type: ObjectProperty)
    void SET_Stack_TotalTournaments(const UStackBox*& Value) { Write<UStackBox*>(uintptr_t(this) + 0x1598, Value); } // 0x1598 (Size: 0x8, Type: ObjectProperty)
    void SET_SelectionOutline(const UCommonBorder*& Value) { Write<UCommonBorder*>(uintptr_t(this) + 0x15a0, Value); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Root(const UGridPanel*& Value) { Write<UGridPanel*>(uintptr_t(this) + 0x15a8, Value); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    void SET_RichText_Tournaments(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x15b0, Value); } // 0x15b0 (Size: 0x8, Type: ObjectProperty)
    void SET_Fade(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x15b8, Value); } // 0x15b8 (Size: 0x8, Type: ObjectProperty)
    void SET_DebugTxt(const UUEFN_TextBlock_C*& Value) { Write<UUEFN_TextBlock_C*>(uintptr_t(this) + 0x15c0, Value); } // 0x15c0 (Size: 0x8, Type: ObjectProperty)
    void SET_Date(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x15c8, Value); } // 0x15c8 (Size: 0x8, Type: ObjectProperty)
    void SET_Bookmarked(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x15d0, Value); } // 0x15d0 (Size: 0x8, Type: ObjectProperty)
    void SET_Block_VictoryIcon(const UWBP_Compete_Block_Image_C*& Value) { Write<UWBP_Compete_Block_Image_C*>(uintptr_t(this) + 0x15d8, Value); } // 0x15d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Block_RankedIcon(const UWBP_Compete_Block_Image_C*& Value) { Write<UWBP_Compete_Block_Image_C*>(uintptr_t(this) + 0x15e0, Value); } // 0x15e0 (Size: 0x8, Type: ObjectProperty)
    void SET_Block_Outline(const UWBP_UIKit_Block_Outline_C*& Value) { Write<UWBP_UIKit_Block_Outline_C*>(uintptr_t(this) + 0x15e8, Value); } // 0x15e8 (Size: 0x8, Type: ObjectProperty)
    void SET_Block_OthersIcon(const UWBP_Compete_Block_Image_C*& Value) { Write<UWBP_Compete_Block_Image_C*>(uintptr_t(this) + 0x15f0, Value); } // 0x15f0 (Size: 0x8, Type: ObjectProperty)
    void SET_Block_ItemShopIcon(const UWBP_Compete_Block_Image_C*& Value) { Write<UWBP_Compete_Block_Image_C*>(uintptr_t(this) + 0x15f8, Value); } // 0x15f8 (Size: 0x8, Type: ObjectProperty)
    void SET_Block_FNCSIcon(const UWBP_Compete_Block_Image_C*& Value) { Write<UWBP_Compete_Block_Image_C*>(uintptr_t(this) + 0x1600, Value); } // 0x1600 (Size: 0x8, Type: ObjectProperty)
    void SET_Block_CashIcon(const UWBP_Compete_Block_Image_C*& Value) { Write<UWBP_Compete_Block_Image_C*>(uintptr_t(this) + 0x1608, Value); } // 0x1608 (Size: 0x8, Type: ObjectProperty)
    void SET_Background_Date(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1610, Value); } // 0x1610 (Size: 0x8, Type: ObjectProperty)
    void SET_Background(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1618, Value); } // 0x1618 (Size: 0x8, Type: ObjectProperty)
    void SET_AttachmentBookmarked(const UCommonVisualAttachment*& Value) { Write<UCommonVisualAttachment*>(uintptr_t(this) + 0x1620, Value); } // 0x1620 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_ShowTournamentIcons(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1628, Value); } // 0x1628 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_Locked(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1630, Value); } // 0x1630 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_Selected(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1638, Value); } // 0x1638 (Size: 0x8, Type: ObjectProperty)
    void SET_FortPoblanoTournamentsCalendarDayTileVM(const UFortPoblanoTournamentsCalendarDayTileVM*& Value) { Write<UFortPoblanoTournamentsCalendarDayTileVM*>(uintptr_t(this) + 0x1640, Value); } // 0x1640 (Size: 0x8, Type: ObjectProperty)
    void SET_Material_Cups(const UMaterialInstance*& Value) { Write<UMaterialInstance*>(uintptr_t(this) + 0x1648, Value); } // 0x1648 (Size: 0x8, Type: ObjectProperty)
    void SET_Material_TotalTournaments(const UMaterialInstance*& Value) { Write<UMaterialInstance*>(uintptr_t(this) + 0x1650, Value); } // 0x1650 (Size: 0x8, Type: ObjectProperty)
    void SET_Font_TotalTournaments(const FSlateFontInfo& Value) { Write<FSlateFontInfo>(uintptr_t(this) + 0x1658, Value); } // 0x1658 (Size: 0x58, Type: StructProperty)
    void SET_Font_Date(const FSlateFontInfo& Value) { Write<FSlateFontInfo>(uintptr_t(this) + 0x16b0, Value); } // 0x16b0 (Size: 0x58, Type: StructProperty)
    void SET_BackgroundMaterial(const UMaterialInstance*& Value) { Write<UMaterialInstance*>(uintptr_t(this) + 0x1708, Value); } // 0x1708 (Size: 0x8, Type: ObjectProperty)
    void SET_Material_FontDateToday(const UMaterialInstance*& Value) { Write<UMaterialInstance*>(uintptr_t(this) + 0x1710, Value); } // 0x1710 (Size: 0x8, Type: ObjectProperty)
    void SET_Cash_Texture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x1718, Value); } // 0x1718 (Size: 0x8, Type: ObjectProperty)
    void SET_FNCS_Texture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x1720, Value); } // 0x1720 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemShop_Texture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x1728, Value); } // 0x1728 (Size: 0x8, Type: ObjectProperty)
    void SET_Victory_Texture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x1730, Value); } // 0x1730 (Size: 0x8, Type: ObjectProperty)
    void SET_Others_Texture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x1738, Value); } // 0x1738 (Size: 0x8, Type: ObjectProperty)
    void SET_Ranked_Texture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x1740, Value); } // 0x1740 (Size: 0x8, Type: ObjectProperty)
    void SET_FakeLockedState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1748, Value); } // 0x1748 (Size: 0x1, Type: BoolProperty)
    void SET_IsCalendarOpened(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1749, Value); } // 0x1749 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x620
class UWBP_Calendar_C : public UCommonActivatableWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: StructProperty)
    UWBP_TournamentsCarousel_C* WBP_TournamentsCarousel() const { return Read<UWBP_TournamentsCarousel_C*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* VertBox_MobileCalendarContainer() const { return Read<UVerticalBox*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    UUniformGridPanel* UniformGridPanel() const { return Read<UUniformGridPanel*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    UCommonVisibilitySwitcher* TournamentsStateVisibilitySwitcher() const { return Read<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    UFortSwipePanel* SwipePanel() const { return Read<UFortSwipePanel*>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SizeBox_Month() const { return Read<USizeBox*>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SizeBox() const { return Read<USizeBox*>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    UScrollBox* ScrollBox_Month() const { return Read<UScrollBox*>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    USafeZone* SafeZone() const { return Read<USafeZone*>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Generic_C* PreviousButton() const { return Read<UWBP_UIKit_Button_Generic_C*>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Generic_C* NextButton() const { return Read<UWBP_UIKit_Button_Generic_C*>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* NavigationButtons() const { return Read<UGridPanel*>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x8, Type: ObjectProperty)
    UWBP_IconHintsPanel_C* IconHintsPanel() const { return Read<UWBP_IconHintsPanel_C*>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x8, Type: ObjectProperty)
    UWBP_FilterButton_C* FilterButton() const { return Read<UWBP_FilterButton_C*>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    UWBP_BottomBarDecoyButton_C* DecoyButton_Today() const { return Read<UWBP_BottomBarDecoyButton_C*>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x8, Type: ObjectProperty)
    UWBP_BottomBarDecoyButton_C* DecoyButton_FirstUpcoming() const { return Read<UWBP_BottomBarDecoyButton_C*>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)
    UWBP_BottomBarDecoyButton_C* DecoyButton_Bookmark() const { return Read<UWBP_BottomBarDecoyButton_C*>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x8, Type: ObjectProperty)
    UWBP_BottomBarDecoyButton_C* DecoyButton_Back() const { return Read<UWBP_BottomBarDecoyButton_C*>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x8, Type: ObjectProperty)
    UUniformGridPanel* Days() const { return Read<UUniformGridPanel*>(uintptr_t(this) + 0x510); } // 0x510 (Size: 0x8, Type: ObjectProperty)
    UWBP_CaptureForPostBufferUpdate_C* CaptureForPostBufferUpdate() const { return Read<UWBP_CaptureForPostBufferUpdate_C*>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x8, Type: ObjectProperty)
    UWBP_CalendarWrapper_C* CalendarWrapper() const { return Read<UWBP_CalendarWrapper_C*>(uintptr_t(this) + 0x520); } // 0x520 (Size: 0x8, Type: ObjectProperty)
    UImage* Background() const { return Read<UImage*>(uintptr_t(this) + 0x528); } // 0x528 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_OpenCalendar() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x530); } // 0x530 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_BackgroundColor() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x8, Type: ObjectProperty)
    UFortPoblanoTournamentsCalendarVM* FortPoblanoTournamentsCalendarVM() const { return Read<UFortPoblanoTournamentsCalendarVM*>(uintptr_t(this) + 0x540); } // 0x540 (Size: 0x8, Type: ObjectProperty)
    TArray<UWBP_CalendarTile_C*> CalendarDayTilesArray() const { return Read<TArray<UWBP_CalendarTile_C*>>(uintptr_t(this) + 0x548); } // 0x548 (Size: 0x10, Type: ArrayProperty)
    UCommonButtonBase* Selected_Calendar_Tile() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x558); } // 0x558 (Size: 0x8, Type: ObjectProperty)
    bool IsCalendarOpened() const { return Read<bool>(uintptr_t(this) + 0x560); } // 0x560 (Size: 0x1, Type: BoolProperty)
    int32_t Selected_Tournament_Tile() const { return Read<int32_t>(uintptr_t(this) + 0x564); } // 0x564 (Size: 0x4, Type: IntProperty)
    UMaterialInstanceDynamic* MID_Background() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x8, Type: ObjectProperty)
    FLinearColor NextColor1() const { return Read<FLinearColor>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x10, Type: StructProperty)
    TArray<UWBP_TournamentTile_C*> TournamentTilesArray() const { return Read<TArray<UWBP_TournamentTile_C*>>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x10, Type: ArrayProperty)
    FLinearColor NextColor2() const { return Read<FLinearColor>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x10, Type: StructProperty)
    bool B_Has_Init_Months() const { return Read<bool>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x1, Type: BoolProperty)
    double Max_Color_Luminance() const { return Read<double>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x8, Type: DoubleProperty)
    UMVVM_CompeteEmptyTile_Entry_C* FirstItem() const { return Read<UMVVM_CompeteEmptyTile_Entry_C*>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    UMVVM_CompeteEmptyTile_Entry_C* LastItem() const { return Read<UMVVM_CompeteEmptyTile_Entry_C*>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Input_Type() const { return Read<uint8_t>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x1, Type: EnumProperty)
    UFortPoblanoTournamentsCalendarTournamentTileVM* CurrentSelectedTileVM() const { return Read<UFortPoblanoTournamentsCalendarTournamentTileVM*>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x8, Type: ObjectProperty)
    FDataTableRowHandle AddBookmarkInputAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x5d0); } // 0x5d0 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle RemoveBookmarkInputAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x5e0); } // 0x5e0 (Size: 0x10, Type: StructProperty)
    bool IsCalendarScrollableForTouch() const { return Read<bool>(uintptr_t(this) + 0x5f0); } // 0x5f0 (Size: 0x1, Type: BoolProperty)
    bool IsTournamentCarouselSwiped() const { return Read<bool>(uintptr_t(this) + 0x5f1); } // 0x5f1 (Size: 0x1, Type: BoolProperty)
    FDataTableRowHandle TodayInputAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x5f8); } // 0x5f8 (Size: 0x10, Type: StructProperty)
    int32_t PreviouslySelectedCalendarTileIndex() const { return Read<int32_t>(uintptr_t(this) + 0x608); } // 0x608 (Size: 0x4, Type: IntProperty)
    bool IsLoadingTournaments() const { return Read<bool>(uintptr_t(this) + 0x60c); } // 0x60c (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: StructProperty)
    void SET_WBP_TournamentsCarousel(const UWBP_TournamentsCarousel_C*& Value) { Write<UWBP_TournamentsCarousel_C*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_VertBox_MobileCalendarContainer(const UVerticalBox*& Value) { Write<UVerticalBox*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    void SET_UniformGridPanel(const UUniformGridPanel*& Value) { Write<UUniformGridPanel*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_TournamentsStateVisibilitySwitcher(const UCommonVisibilitySwitcher*& Value) { Write<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    void SET_SwipePanel(const UFortSwipePanel*& Value) { Write<UFortSwipePanel*>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    void SET_SizeBox_Month(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    void SET_SizeBox(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    void SET_ScrollBox_Month(const UScrollBox*& Value) { Write<UScrollBox*>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    void SET_SafeZone(const USafeZone*& Value) { Write<USafeZone*>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    void SET_PreviousButton(const UWBP_UIKit_Button_Generic_C*& Value) { Write<UWBP_UIKit_Button_Generic_C*>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    void SET_NextButton(const UWBP_UIKit_Button_Generic_C*& Value) { Write<UWBP_UIKit_Button_Generic_C*>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    void SET_NavigationButtons(const UGridPanel*& Value) { Write<UGridPanel*>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x8, Type: ObjectProperty)
    void SET_IconHintsPanel(const UWBP_IconHintsPanel_C*& Value) { Write<UWBP_IconHintsPanel_C*>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x8, Type: ObjectProperty)
    void SET_FilterButton(const UWBP_FilterButton_C*& Value) { Write<UWBP_FilterButton_C*>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    void SET_DecoyButton_Today(const UWBP_BottomBarDecoyButton_C*& Value) { Write<UWBP_BottomBarDecoyButton_C*>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x8, Type: ObjectProperty)
    void SET_DecoyButton_FirstUpcoming(const UWBP_BottomBarDecoyButton_C*& Value) { Write<UWBP_BottomBarDecoyButton_C*>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)
    void SET_DecoyButton_Bookmark(const UWBP_BottomBarDecoyButton_C*& Value) { Write<UWBP_BottomBarDecoyButton_C*>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x8, Type: ObjectProperty)
    void SET_DecoyButton_Back(const UWBP_BottomBarDecoyButton_C*& Value) { Write<UWBP_BottomBarDecoyButton_C*>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x8, Type: ObjectProperty)
    void SET_Days(const UUniformGridPanel*& Value) { Write<UUniformGridPanel*>(uintptr_t(this) + 0x510, Value); } // 0x510 (Size: 0x8, Type: ObjectProperty)
    void SET_CaptureForPostBufferUpdate(const UWBP_CaptureForPostBufferUpdate_C*& Value) { Write<UWBP_CaptureForPostBufferUpdate_C*>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x8, Type: ObjectProperty)
    void SET_CalendarWrapper(const UWBP_CalendarWrapper_C*& Value) { Write<UWBP_CalendarWrapper_C*>(uintptr_t(this) + 0x520, Value); } // 0x520 (Size: 0x8, Type: ObjectProperty)
    void SET_Background(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x528, Value); } // 0x528 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_OpenCalendar(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x530, Value); } // 0x530 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_BackgroundColor(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x8, Type: ObjectProperty)
    void SET_FortPoblanoTournamentsCalendarVM(const UFortPoblanoTournamentsCalendarVM*& Value) { Write<UFortPoblanoTournamentsCalendarVM*>(uintptr_t(this) + 0x540, Value); } // 0x540 (Size: 0x8, Type: ObjectProperty)
    void SET_CalendarDayTilesArray(const TArray<UWBP_CalendarTile_C*>& Value) { Write<TArray<UWBP_CalendarTile_C*>>(uintptr_t(this) + 0x548, Value); } // 0x548 (Size: 0x10, Type: ArrayProperty)
    void SET_Selected_Calendar_Tile(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x558, Value); } // 0x558 (Size: 0x8, Type: ObjectProperty)
    void SET_IsCalendarOpened(const bool& Value) { Write<bool>(uintptr_t(this) + 0x560, Value); } // 0x560 (Size: 0x1, Type: BoolProperty)
    void SET_Selected_Tournament_Tile(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x564, Value); } // 0x564 (Size: 0x4, Type: IntProperty)
    void SET_MID_Background(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x8, Type: ObjectProperty)
    void SET_NextColor1(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x10, Type: StructProperty)
    void SET_TournamentTilesArray(const TArray<UWBP_TournamentTile_C*>& Value) { Write<TArray<UWBP_TournamentTile_C*>>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x10, Type: ArrayProperty)
    void SET_NextColor2(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x10, Type: StructProperty)
    void SET_B_Has_Init_Months(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x1, Type: BoolProperty)
    void SET_Max_Color_Luminance(const double& Value) { Write<double>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x8, Type: DoubleProperty)
    void SET_FirstItem(const UMVVM_CompeteEmptyTile_Entry_C*& Value) { Write<UMVVM_CompeteEmptyTile_Entry_C*>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    void SET_LastItem(const UMVVM_CompeteEmptyTile_Entry_C*& Value) { Write<UMVVM_CompeteEmptyTile_Entry_C*>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    void SET_Input_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x1, Type: EnumProperty)
    void SET_CurrentSelectedTileVM(const UFortPoblanoTournamentsCalendarTournamentTileVM*& Value) { Write<UFortPoblanoTournamentsCalendarTournamentTileVM*>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x8, Type: ObjectProperty)
    void SET_AddBookmarkInputAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x5d0, Value); } // 0x5d0 (Size: 0x10, Type: StructProperty)
    void SET_RemoveBookmarkInputAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x5e0, Value); } // 0x5e0 (Size: 0x10, Type: StructProperty)
    void SET_IsCalendarScrollableForTouch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5f0, Value); } // 0x5f0 (Size: 0x1, Type: BoolProperty)
    void SET_IsTournamentCarouselSwiped(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5f1, Value); } // 0x5f1 (Size: 0x1, Type: BoolProperty)
    void SET_TodayInputAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x5f8, Value); } // 0x5f8 (Size: 0x10, Type: StructProperty)
    void SET_PreviouslySelectedCalendarTileIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x608, Value); } // 0x608 (Size: 0x4, Type: IntProperty)
    void SET_IsLoadingTournaments(const bool& Value) { Write<bool>(uintptr_t(this) + 0x60c, Value); } // 0x60c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x360
class UWBP_TournamentsCarousel_C : public UFortPolymorphicListView
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: StructProperty)
    UFortPoblanoTournamentsCarouselVM* FortPoblanoTournamentsCarouselVM() const { return Read<UFortPoblanoTournamentsCarouselVM*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: StructProperty)
    void SET_FortPoblanoTournamentsCarouselVM(const UFortPoblanoTournamentsCarouselVM*& Value) { Write<UFortPoblanoTournamentsCarouselVM*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x69
class UMVVM_CompeteEmptyTile_Entry_C : public UMVVMViewModelBase
{
public:
    bool IsSelectable() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)

    void SET_IsSelectable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
};

