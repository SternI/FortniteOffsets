/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DryBoxRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "GameplayAbilities.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x1298
class UNyxGlassWeaponComponent_Swinging : public UFortWeaponComponent_Swinging
{
public:
    FScalableFloat SwingTargetRaycastDist() const { return Read<FScalableFloat>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x28, Type: StructProperty)
    FScalableFloat AttackTargetRaycastDist() const { return Read<FScalableFloat>(uintptr_t(this) + 0x6c8); } // 0x6c8 (Size: 0x28, Type: StructProperty)
    FScalableFloat CameraDistScale() const { return Read<FScalableFloat>(uintptr_t(this) + 0x6f0); } // 0x6f0 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetingSphereRadius() const { return Read<FScalableFloat>(uintptr_t(this) + 0x718); } // 0x718 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxAttachPointActorBoundsSize() const { return Read<FScalableFloat>(uintptr_t(this) + 0x740); } // 0x740 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxAttachPointActorExtent() const { return Read<FScalableFloat>(uintptr_t(this) + 0x768); } // 0x768 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinAttachPointDistFromCamera() const { return Read<FScalableFloat>(uintptr_t(this) + 0x790); } // 0x790 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinAttachPointAngleInRad() const { return Read<FScalableFloat>(uintptr_t(this) + 0x7b8); } // 0x7b8 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxSecondAttachPointDotProd() const { return Read<FScalableFloat>(uintptr_t(this) + 0x7e0); } // 0x7e0 (Size: 0x28, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> RayTraceTargetingCollisionChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x808); } // 0x808 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<ECollisionChannel> SphereOverlapTargetingCollisionChannel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x809); } // 0x809 (Size: 0x1, Type: ByteProperty)
    TArray<UClass*> DisallowedActorClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x810); } // 0x810 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> DirectRaycastDisallowedActorClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x820); } // 0x820 (Size: 0x10, Type: ArrayProperty)
    TArray<TEnumAsByte<EFortBuildingType>> AllowedBuildingTypes() const { return Read<TArray<TEnumAsByte<EFortBuildingType>>>(uintptr_t(this) + 0x830); } // 0x830 (Size: 0x10, Type: ArrayProperty)
    FScalableFloat SwingingAutoDetachDist() const { return Read<FScalableFloat>(uintptr_t(this) + 0x840); } // 0x840 (Size: 0x28, Type: StructProperty)
    FScalableFloat AttackStartSlashDist() const { return Read<FScalableFloat>(uintptr_t(this) + 0x868); } // 0x868 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxAcceleration() const { return Read<FScalableFloat>(uintptr_t(this) + 0x890); } // 0x890 (Size: 0x28, Type: StructProperty)
    FScalableFloat GasOrthogonalPowerWhileAttacking() const { return Read<FScalableFloat>(uintptr_t(this) + 0x8b8); } // 0x8b8 (Size: 0x28, Type: StructProperty)
    FScalableFloat GasOrthogonalPowerWhileSwinging() const { return Read<FScalableFloat>(uintptr_t(this) + 0x8e0); } // 0x8e0 (Size: 0x28, Type: StructProperty)
    FScalableFloat GasReelInPowerSwinging() const { return Read<FScalableFloat>(uintptr_t(this) + 0x908); } // 0x908 (Size: 0x28, Type: StructProperty)
    FScalableFloat GasReelInPowerAttacking() const { return Read<FScalableFloat>(uintptr_t(this) + 0x930); } // 0x930 (Size: 0x28, Type: StructProperty)
    FScalableFloat bShouldInterpolateCurGasToGoal() const { return Read<FScalableFloat>(uintptr_t(this) + 0x958); } // 0x958 (Size: 0x28, Type: StructProperty)
    FScalableFloat GasForceInterpSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0x980); } // 0x980 (Size: 0x28, Type: StructProperty)
    FScalableFloat bShouldAccelerateWhileAttached() const { return Read<FScalableFloat>(uintptr_t(this) + 0x9a8); } // 0x9a8 (Size: 0x28, Type: StructProperty)
    FScalableFloat UnattachedDeaccelerationMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x28, Type: StructProperty)
    FScalableFloat AttachedDeaccelerationMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0x9f8); } // 0x9f8 (Size: 0x28, Type: StructProperty)
    FScalableFloat TimeAttachedBeforeSpeedStartsIncreasing() const { return Read<FScalableFloat>(uintptr_t(this) + 0xa20); } // 0xa20 (Size: 0x28, Type: StructProperty)
    FScalableFloat TimeAttachedForMaxSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xa48); } // 0xa48 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinAttachedSpeedMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0xa70); } // 0xa70 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxAttachedSpeedMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0xa98); } // 0xa98 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinUnattachedSpeedMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0xac0); } // 0xac0 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxSpeedMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0xae8); } // 0xae8 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxSpeedDecreaseFromUpwardAngle() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb10); } // 0xb10 (Size: 0x28, Type: StructProperty)
    UCurveFloat* SpeedBasedOnHeightCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0xb38); } // 0xb38 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat BaseSwingSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb40); } // 0xb40 (Size: 0x28, Type: StructProperty)
    FScalableFloat InitialAccelerationStartSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x28, Type: StructProperty)
    FScalableFloat InitialAccelerationTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x28, Type: StructProperty)
    UCurveFloat* InitialAccelerationCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat SpeedSoftCapDrag() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbc0); } // 0xbc0 (Size: 0x28, Type: StructProperty)
    FScalableFloat SpeedHardCapFailsafe() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbe8); } // 0xbe8 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxHoverTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc10); } // 0xc10 (Size: 0x28, Type: StructProperty)
    FScalableFloat FullHoverRechargeTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc38); } // 0xc38 (Size: 0x28, Type: StructProperty)
    FScalableFloat DesiredHoverZSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc60); } // 0xc60 (Size: 0x28, Type: StructProperty)
    FScalableFloat HoverZMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc88); } // 0xc88 (Size: 0x28, Type: StructProperty)
    FScalableFloat HoverTimeWhileUnequipped() const { return Read<FScalableFloat>(uintptr_t(this) + 0xcb0); } // 0xcb0 (Size: 0x28, Type: StructProperty)
    FScalableFloat HoverZMultiplierWhileUnequipped() const { return Read<FScalableFloat>(uintptr_t(this) + 0xcd8); } // 0xcd8 (Size: 0x28, Type: StructProperty)
    FScalableFloat SpeedSoftCapDragWhenHovering() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd00); } // 0xd00 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxHoverSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd28); } // 0xd28 (Size: 0x28, Type: StructProperty)
    FScalableFloat OldAttackDistanceXRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd50); } // 0xd50 (Size: 0x28, Type: StructProperty)
    FScalableFloat OldAttackDistanceYRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd78); } // 0xd78 (Size: 0x28, Type: StructProperty)
    FScalableFloat NewAttackDistanceXRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0xda0); } // 0xda0 (Size: 0x28, Type: StructProperty)
    FScalableFloat NewAttackDistanceYRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0xdc8); } // 0xdc8 (Size: 0x28, Type: StructProperty)
    UCurveFloat* AttackAccelerationCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0xdf0); } // 0xdf0 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat ReelInForceAttackMinDist() const { return Read<FScalableFloat>(uintptr_t(this) + 0xdf8); } // 0xdf8 (Size: 0x28, Type: StructProperty)
    FScalableFloat ReelInForceAttackMaxDist() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe20); } // 0xe20 (Size: 0x28, Type: StructProperty)
    FScalableFloat ReelInForceAttackMinMult() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe48); } // 0xe48 (Size: 0x28, Type: StructProperty)
    FScalableFloat ReelInForceAttackMaxMult() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe70); } // 0xe70 (Size: 0x28, Type: StructProperty)
    FScalableFloat AttackStartSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe98); } // 0xe98 (Size: 0x28, Type: StructProperty)
    FScalableFloat AttackMaxSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xec0); } // 0xec0 (Size: 0x28, Type: StructProperty)
    FScalableFloat SpeedSoftCapDragWhenAttacking() const { return Read<FScalableFloat>(uintptr_t(this) + 0xee8); } // 0xee8 (Size: 0x28, Type: StructProperty)
    FScalableFloat SlashLockDistance() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf10); } // 0xf10 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinSlashDistToTarget() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf38); } // 0xf38 (Size: 0x28, Type: StructProperty)
    FScalableFloat SlashSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf60); } // 0xf60 (Size: 0x28, Type: StructProperty)
    FScalableFloat SlashLockTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf88); } // 0xf88 (Size: 0x28, Type: StructProperty)
    FScalableFloat SlashLeapBackTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0xfb0); } // 0xfb0 (Size: 0x28, Type: StructProperty)
    FScalableFloat SlashLeapBackHeightModifier() const { return Read<FScalableFloat>(uintptr_t(this) + 0xfd8); } // 0xfd8 (Size: 0x28, Type: StructProperty)
    FScalableFloat SlashLeapBackSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1000); } // 0x1000 (Size: 0x28, Type: StructProperty)
    FGameplayTag OverrideSwingingControlParamsTag_Swinging() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1028); } // 0x1028 (Size: 0x4, Type: StructProperty)
    FGameplayTag OverrideSwingingControlParamsTag_Hovering() const { return Read<FGameplayTag>(uintptr_t(this) + 0x102c); } // 0x102c (Size: 0x4, Type: StructProperty)
    FGameplayTag OverrideSwingingControlParamsTag_Attacking() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1030); } // 0x1030 (Size: 0x4, Type: StructProperty)
    FGameplayTag OverrideSwingingControlParamsTag_LeapingBack() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1034); } // 0x1034 (Size: 0x4, Type: StructProperty)
    FScalableFloat LeapingBack_OverrideTimer() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1038); } // 0x1038 (Size: 0x28, Type: StructProperty)
    FName ActorHasPreferredSwingMeshTag() const { return Read<FName>(uintptr_t(this) + 0x1060); } // 0x1060 (Size: 0x4, Type: NameProperty)
    FName ComponentIsPreferredSwingMeshTag() const { return Read<FName>(uintptr_t(this) + 0x1064); } // 0x1064 (Size: 0x4, Type: NameProperty)
    bool bUsingDirectRaycast() const { return Read<bool>(uintptr_t(this) + 0x1068); } // 0x1068 (Size: 0x1, Type: BoolProperty)
    FNyxGlassTargetingData CurTargetingData() const { return Read<FNyxGlassTargetingData>(uintptr_t(this) + 0x1070); } // 0x1070 (Size: 0x48, Type: StructProperty)

    void SET_SwingTargetRaycastDist(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x28, Type: StructProperty)
    void SET_AttackTargetRaycastDist(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x6c8, Value); } // 0x6c8 (Size: 0x28, Type: StructProperty)
    void SET_CameraDistScale(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x6f0, Value); } // 0x6f0 (Size: 0x28, Type: StructProperty)
    void SET_TargetingSphereRadius(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x718, Value); } // 0x718 (Size: 0x28, Type: StructProperty)
    void SET_MaxAttachPointActorBoundsSize(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x740, Value); } // 0x740 (Size: 0x28, Type: StructProperty)
    void SET_MaxAttachPointActorExtent(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x768, Value); } // 0x768 (Size: 0x28, Type: StructProperty)
    void SET_MinAttachPointDistFromCamera(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x790, Value); } // 0x790 (Size: 0x28, Type: StructProperty)
    void SET_MinAttachPointAngleInRad(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x7b8, Value); } // 0x7b8 (Size: 0x28, Type: StructProperty)
    void SET_MaxSecondAttachPointDotProd(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x7e0, Value); } // 0x7e0 (Size: 0x28, Type: StructProperty)
    void SET_RayTraceTargetingCollisionChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x808, Value); } // 0x808 (Size: 0x1, Type: ByteProperty)
    void SET_SphereOverlapTargetingCollisionChannel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x809, Value); } // 0x809 (Size: 0x1, Type: ByteProperty)
    void SET_DisallowedActorClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x810, Value); } // 0x810 (Size: 0x10, Type: ArrayProperty)
    void SET_DirectRaycastDisallowedActorClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x820, Value); } // 0x820 (Size: 0x10, Type: ArrayProperty)
    void SET_AllowedBuildingTypes(const TArray<TEnumAsByte<EFortBuildingType>>& Value) { Write<TArray<TEnumAsByte<EFortBuildingType>>>(uintptr_t(this) + 0x830, Value); } // 0x830 (Size: 0x10, Type: ArrayProperty)
    void SET_SwingingAutoDetachDist(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x840, Value); } // 0x840 (Size: 0x28, Type: StructProperty)
    void SET_AttackStartSlashDist(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x868, Value); } // 0x868 (Size: 0x28, Type: StructProperty)
    void SET_MaxAcceleration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x890, Value); } // 0x890 (Size: 0x28, Type: StructProperty)
    void SET_GasOrthogonalPowerWhileAttacking(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x8b8, Value); } // 0x8b8 (Size: 0x28, Type: StructProperty)
    void SET_GasOrthogonalPowerWhileSwinging(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x8e0, Value); } // 0x8e0 (Size: 0x28, Type: StructProperty)
    void SET_GasReelInPowerSwinging(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x908, Value); } // 0x908 (Size: 0x28, Type: StructProperty)
    void SET_GasReelInPowerAttacking(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x930, Value); } // 0x930 (Size: 0x28, Type: StructProperty)
    void SET_bShouldInterpolateCurGasToGoal(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x958, Value); } // 0x958 (Size: 0x28, Type: StructProperty)
    void SET_GasForceInterpSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x980, Value); } // 0x980 (Size: 0x28, Type: StructProperty)
    void SET_bShouldAccelerateWhileAttached(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x9a8, Value); } // 0x9a8 (Size: 0x28, Type: StructProperty)
    void SET_UnattachedDeaccelerationMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x28, Type: StructProperty)
    void SET_AttachedDeaccelerationMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x9f8, Value); } // 0x9f8 (Size: 0x28, Type: StructProperty)
    void SET_TimeAttachedBeforeSpeedStartsIncreasing(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xa20, Value); } // 0xa20 (Size: 0x28, Type: StructProperty)
    void SET_TimeAttachedForMaxSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xa48, Value); } // 0xa48 (Size: 0x28, Type: StructProperty)
    void SET_MinAttachedSpeedMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xa70, Value); } // 0xa70 (Size: 0x28, Type: StructProperty)
    void SET_MaxAttachedSpeedMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xa98, Value); } // 0xa98 (Size: 0x28, Type: StructProperty)
    void SET_MinUnattachedSpeedMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xac0, Value); } // 0xac0 (Size: 0x28, Type: StructProperty)
    void SET_MaxSpeedMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xae8, Value); } // 0xae8 (Size: 0x28, Type: StructProperty)
    void SET_MaxSpeedDecreaseFromUpwardAngle(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb10, Value); } // 0xb10 (Size: 0x28, Type: StructProperty)
    void SET_SpeedBasedOnHeightCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0xb38, Value); } // 0xb38 (Size: 0x8, Type: ObjectProperty)
    void SET_BaseSwingSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb40, Value); } // 0xb40 (Size: 0x28, Type: StructProperty)
    void SET_InitialAccelerationStartSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x28, Type: StructProperty)
    void SET_InitialAccelerationTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x28, Type: StructProperty)
    void SET_InitialAccelerationCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x8, Type: ObjectProperty)
    void SET_SpeedSoftCapDrag(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbc0, Value); } // 0xbc0 (Size: 0x28, Type: StructProperty)
    void SET_SpeedHardCapFailsafe(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbe8, Value); } // 0xbe8 (Size: 0x28, Type: StructProperty)
    void SET_MaxHoverTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc10, Value); } // 0xc10 (Size: 0x28, Type: StructProperty)
    void SET_FullHoverRechargeTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc38, Value); } // 0xc38 (Size: 0x28, Type: StructProperty)
    void SET_DesiredHoverZSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc60, Value); } // 0xc60 (Size: 0x28, Type: StructProperty)
    void SET_HoverZMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc88, Value); } // 0xc88 (Size: 0x28, Type: StructProperty)
    void SET_HoverTimeWhileUnequipped(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xcb0, Value); } // 0xcb0 (Size: 0x28, Type: StructProperty)
    void SET_HoverZMultiplierWhileUnequipped(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xcd8, Value); } // 0xcd8 (Size: 0x28, Type: StructProperty)
    void SET_SpeedSoftCapDragWhenHovering(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd00, Value); } // 0xd00 (Size: 0x28, Type: StructProperty)
    void SET_MaxHoverSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd28, Value); } // 0xd28 (Size: 0x28, Type: StructProperty)
    void SET_OldAttackDistanceXRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd50, Value); } // 0xd50 (Size: 0x28, Type: StructProperty)
    void SET_OldAttackDistanceYRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd78, Value); } // 0xd78 (Size: 0x28, Type: StructProperty)
    void SET_NewAttackDistanceXRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xda0, Value); } // 0xda0 (Size: 0x28, Type: StructProperty)
    void SET_NewAttackDistanceYRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xdc8, Value); } // 0xdc8 (Size: 0x28, Type: StructProperty)
    void SET_AttackAccelerationCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0xdf0, Value); } // 0xdf0 (Size: 0x8, Type: ObjectProperty)
    void SET_ReelInForceAttackMinDist(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xdf8, Value); } // 0xdf8 (Size: 0x28, Type: StructProperty)
    void SET_ReelInForceAttackMaxDist(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe20, Value); } // 0xe20 (Size: 0x28, Type: StructProperty)
    void SET_ReelInForceAttackMinMult(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe48, Value); } // 0xe48 (Size: 0x28, Type: StructProperty)
    void SET_ReelInForceAttackMaxMult(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe70, Value); } // 0xe70 (Size: 0x28, Type: StructProperty)
    void SET_AttackStartSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe98, Value); } // 0xe98 (Size: 0x28, Type: StructProperty)
    void SET_AttackMaxSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xec0, Value); } // 0xec0 (Size: 0x28, Type: StructProperty)
    void SET_SpeedSoftCapDragWhenAttacking(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xee8, Value); } // 0xee8 (Size: 0x28, Type: StructProperty)
    void SET_SlashLockDistance(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf10, Value); } // 0xf10 (Size: 0x28, Type: StructProperty)
    void SET_MinSlashDistToTarget(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf38, Value); } // 0xf38 (Size: 0x28, Type: StructProperty)
    void SET_SlashSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf60, Value); } // 0xf60 (Size: 0x28, Type: StructProperty)
    void SET_SlashLockTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf88, Value); } // 0xf88 (Size: 0x28, Type: StructProperty)
    void SET_SlashLeapBackTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xfb0, Value); } // 0xfb0 (Size: 0x28, Type: StructProperty)
    void SET_SlashLeapBackHeightModifier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xfd8, Value); } // 0xfd8 (Size: 0x28, Type: StructProperty)
    void SET_SlashLeapBackSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1000, Value); } // 0x1000 (Size: 0x28, Type: StructProperty)
    void SET_OverrideSwingingControlParamsTag_Swinging(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1028, Value); } // 0x1028 (Size: 0x4, Type: StructProperty)
    void SET_OverrideSwingingControlParamsTag_Hovering(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x102c, Value); } // 0x102c (Size: 0x4, Type: StructProperty)
    void SET_OverrideSwingingControlParamsTag_Attacking(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1030, Value); } // 0x1030 (Size: 0x4, Type: StructProperty)
    void SET_OverrideSwingingControlParamsTag_LeapingBack(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1034, Value); } // 0x1034 (Size: 0x4, Type: StructProperty)
    void SET_LeapingBack_OverrideTimer(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1038, Value); } // 0x1038 (Size: 0x28, Type: StructProperty)
    void SET_ActorHasPreferredSwingMeshTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1060, Value); } // 0x1060 (Size: 0x4, Type: NameProperty)
    void SET_ComponentIsPreferredSwingMeshTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1064, Value); } // 0x1064 (Size: 0x4, Type: NameProperty)
    void SET_bUsingDirectRaycast(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1068, Value); } // 0x1068 (Size: 0x1, Type: BoolProperty)
    void SET_CurTargetingData(const FNyxGlassTargetingData& Value) { Write<FNyxGlassTargetingData>(uintptr_t(this) + 0x1070, Value); } // 0x1070 (Size: 0x48, Type: StructProperty)
};

// Size: 0xb0
class UNyxGlassFuelAttributeSet : public UFortAttributeSet
{
public:
    FFortGameplayAttributeData MaxFuel() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData Fuel() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData LocalFuel() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x28, Type: StructProperty)

    void SET_MaxFuel(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x28, Type: StructProperty)
    void SET_Fuel(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x28, Type: StructProperty)
    void SET_LocalFuel(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x28, Type: StructProperty)
};

// Size: 0x30
class UNyxGlassSwingingMovementControls : public UFortMovementControls
{
public:
};

// Size: 0x48
struct FNyxGlassTargetingData
{
public:
    AActor* LeftActor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* RightActor() const { return Read<AActor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FVector LeftAttachPoint() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FVector RightAttachPoint() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    bool bFoundLeftAttachPoint() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)
    bool bFoundRightAttachPoint() const { return Read<bool>(uintptr_t(this) + 0x41); } // 0x41 (Size: 0x1, Type: BoolProperty)
    bool bUsingDirectRaycast() const { return Read<bool>(uintptr_t(this) + 0x42); } // 0x42 (Size: 0x1, Type: BoolProperty)

    void SET_LeftActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_RightActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_LeftAttachPoint(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_RightAttachPoint(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_bFoundLeftAttachPoint(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
    void SET_bFoundRightAttachPoint(const bool& Value) { Write<bool>(uintptr_t(this) + 0x41, Value); } // 0x41 (Size: 0x1, Type: BoolProperty)
    void SET_bUsingDirectRaycast(const bool& Value) { Write<bool>(uintptr_t(this) + 0x42, Value); } // 0x42 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x58
struct FNyxGlassVelocityMetadata
{
public:
    FVector OrigVelocity() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector FinalVelocity() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FVector FinalGasForce() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    float CalcMaxSpeedMultiplier() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    bool bCloseToAttachPoint() const { return Read<bool>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x1, Type: BoolProperty)
    bool bPerformedHoverCalculation() const { return Read<bool>(uintptr_t(this) + 0x4d); } // 0x4d (Size: 0x1, Type: BoolProperty)
    bool bReachedSlashTarget() const { return Read<bool>(uintptr_t(this) + 0x4e); } // 0x4e (Size: 0x1, Type: BoolProperty)
    bool bShouldApplySlashDamage() const { return Read<bool>(uintptr_t(this) + 0x4f); } // 0x4f (Size: 0x1, Type: BoolProperty)
    bool bShouldLeapBack() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    bool bFinishedLeapingBack() const { return Read<bool>(uintptr_t(this) + 0x51); } // 0x51 (Size: 0x1, Type: BoolProperty)
    bool bCancelAttackSequence() const { return Read<bool>(uintptr_t(this) + 0x52); } // 0x52 (Size: 0x1, Type: BoolProperty)

    void SET_OrigVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_FinalVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_FinalGasForce(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_CalcMaxSpeedMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_bCloseToAttachPoint(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x1, Type: BoolProperty)
    void SET_bPerformedHoverCalculation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4d, Value); } // 0x4d (Size: 0x1, Type: BoolProperty)
    void SET_bReachedSlashTarget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4e, Value); } // 0x4e (Size: 0x1, Type: BoolProperty)
    void SET_bShouldApplySlashDamage(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4f, Value); } // 0x4f (Size: 0x1, Type: BoolProperty)
    void SET_bShouldLeapBack(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_bFinishedLeapingBack(const bool& Value) { Write<bool>(uintptr_t(this) + 0x51, Value); } // 0x51 (Size: 0x1, Type: BoolProperty)
    void SET_bCancelAttackSequence(const bool& Value) { Write<bool>(uintptr_t(this) + 0x52, Value); } // 0x52 (Size: 0x1, Type: BoolProperty)
};

