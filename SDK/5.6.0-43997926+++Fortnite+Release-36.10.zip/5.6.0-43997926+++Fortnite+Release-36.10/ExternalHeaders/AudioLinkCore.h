/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioLinkCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x38
class UAudioLinkSettingsAbstract : public UObject
{
public:
};

