/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CharacterDynamicsControlCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "PhysicsControl.h"
#include "CoreUObject.h"
#include "AnimGraphRuntime.h"

// Size: 0xa0
class UFortCharacterDynamicsParameters : public UPrimaryDataAsset
{
public:
    TArray<FName> StateNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FClothParameters> ClothParameters() const { return Read<TArray<FClothParameters>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FWindGustParameters> WindGustParameters() const { return Read<TArray<FWindGustParameters>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FPhysicsControlControlAndModifierParameters> RBWCControlAndModifierParameters() const { return Read<TArray<FPhysicsControlControlAndModifierParameters>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortRigidBodyWithControlStateTransitionParameters> RBWCTransitionParameters() const { return Read<TArray<FFortRigidBodyWithControlStateTransitionParameters>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortGravityOverrideParameters> GravityOverrideParameters() const { return Read<TArray<FFortGravityOverrideParameters>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortRigidBodyAnimNodeParameters> RigidBodyAnimNodeParameters() const { return Read<TArray<FFortRigidBodyAnimNodeParameters>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)

    void SET_StateNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_ClothParameters(const TArray<FClothParameters>& Value) { Write<TArray<FClothParameters>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_WindGustParameters(const TArray<FWindGustParameters>& Value) { Write<TArray<FWindGustParameters>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_RBWCControlAndModifierParameters(const TArray<FPhysicsControlControlAndModifierParameters>& Value) { Write<TArray<FPhysicsControlControlAndModifierParameters>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_RBWCTransitionParameters(const TArray<FFortRigidBodyWithControlStateTransitionParameters>& Value) { Write<TArray<FFortRigidBodyWithControlStateTransitionParameters>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_GravityOverrideParameters(const TArray<FFortGravityOverrideParameters>& Value) { Write<TArray<FFortGravityOverrideParameters>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_RigidBodyAnimNodeParameters(const TArray<FFortRigidBodyAnimNodeParameters>& Value) { Write<TArray<FFortRigidBodyAnimNodeParameters>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x98
class UFortCharacterDynamicsStateLogic : public UPrimaryDataAsset
{
public:
    TArray<FName> BlueprintCharacterPropertyNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> ActivityStateNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    FBinaryDecisionTree ActivityStateBinaryDecisionTree() const { return Read<FBinaryDecisionTree>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: StructProperty)
    FBitArrayBinaryDecisionTree DecisionTree() const { return Read<FBitArrayBinaryDecisionTree>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: StructProperty)
    TArray<FProxyProperty> ProxyPropertyCollection() const { return Read<TArray<FProxyProperty>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    int32_t NativePropertyCount() const { return Read<int32_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: IntProperty)
    float MinMovementSpeed() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    float MinRidingMovementSpeed() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)
    float MinUpwardVelocityThreshold() const { return Read<float>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: FloatProperty)
    float MaxFallingThreshold() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    float HighRevolutionsPerSecondThreshold() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)

    void SET_BlueprintCharacterPropertyNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_ActivityStateNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_ActivityStateBinaryDecisionTree(const FBinaryDecisionTree& Value) { Write<FBinaryDecisionTree>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: StructProperty)
    void SET_DecisionTree(const FBitArrayBinaryDecisionTree& Value) { Write<FBitArrayBinaryDecisionTree>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: StructProperty)
    void SET_ProxyPropertyCollection(const TArray<FProxyProperty>& Value) { Write<TArray<FProxyProperty>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_NativePropertyCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: IntProperty)
    void SET_MinMovementSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_MinRidingMovementSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
    void SET_MinUpwardVelocityThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: FloatProperty)
    void SET_MaxFallingThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_HighRevolutionsPerSecondThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xb8
class UFortCharacterDynamicsComponentInterface : public UActorComponent
{
public:
};

// Size: 0x48
struct FBitArrayBinaryDecisionTreeElement
{
public:
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    FBitArrayWrapper BitArrayMask() const { return Read<FBitArrayWrapper>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)
    FBitArrayWrapper BitArraySet() const { return Read<FBitArrayWrapper>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: StructProperty)

    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_BitArrayMask(const FBitArrayWrapper& Value) { Write<FBitArrayWrapper>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
    void SET_BitArraySet(const FBitArrayWrapper& Value) { Write<FBitArrayWrapper>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: StructProperty)
};

// Size: 0x20
struct FBitArrayWrapper
{
public:
};

// Size: 0x10
struct FBitArrayBinaryDecisionTree
{
public:
    TArray<FBitArrayBinaryDecisionTreeElement> TreeStructure() const { return Read<TArray<FBitArrayBinaryDecisionTreeElement>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_TreeStructure(const TArray<FBitArrayBinaryDecisionTreeElement>& Value) { Write<TArray<FBitArrayBinaryDecisionTreeElement>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FBinaryDecisionTreeElement
{
public:
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int64_t BitMask() const { return Read<int64_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: Int64Property)
    int64_t BitSet() const { return Read<int64_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: Int64Property)

    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_BitMask(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: Int64Property)
    void SET_BitSet(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: Int64Property)
};

// Size: 0x10
struct FBinaryDecisionTree
{
public:
    TArray<FBinaryDecisionTreeElement> TreeStructure() const { return Read<TArray<FBinaryDecisionTreeElement>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_TreeStructure(const TArray<FBinaryDecisionTreeElement>& Value) { Write<TArray<FBinaryDecisionTreeElement>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xc
struct FPropertyStatePair
{
public:
    FName StateName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t BitSet() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t BitMask() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)

    void SET_StateName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_BitSet(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_BitMask(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x60
struct FClothStateLogicTree
{
public:
    TMap<int32_t, FName> PropertyNameToBitFlagMap() const { return Read<TMap<int32_t, FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)
    TArray<FPropertyStatePair> PropertyFlagsToStateNameTable() const { return Read<TArray<FPropertyStatePair>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)

    void SET_PropertyNameToBitFlagMap(const TMap<int32_t, FName>& Value) { Write<TMap<int32_t, FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
    void SET_PropertyFlagsToStateNameTable(const TArray<FPropertyStatePair>& Value) { Write<TArray<FPropertyStatePair>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x80
struct FClothCoreSettings
{
public:
    FVector2D EdgeStiffness() const { return Read<FVector2D>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FVector2D BendingStiffness() const { return Read<FVector2D>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FVector2D AreaStiffness() const { return Read<FVector2D>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    FVector2D TetherStiffness() const { return Read<FVector2D>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StructProperty)
    float CollisionThickness() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    float FrictionCoefficient() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)
    float SelfCollisionThickness() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float DampingCoefficient() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    float LocalDampingCoefficient() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    FVector2D AnimDriveStiffness() const { return Read<FVector2D>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    FVector2D AnimDriveDamping() const { return Read<FVector2D>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StructProperty)
    int32_t NumberIterations() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)
    int32_t NumberSubsteps() const { return Read<int32_t>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: IntProperty)

    void SET_EdgeStiffness(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_BendingStiffness(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_AreaStiffness(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_TetherStiffness(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StructProperty)
    void SET_CollisionThickness(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_FrictionCoefficient(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
    void SET_SelfCollisionThickness(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_DampingCoefficient(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_LocalDampingCoefficient(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_AnimDriveStiffness(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_AnimDriveDamping(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StructProperty)
    void SET_NumberIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
    void SET_NumberSubsteps(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: IntProperty)
};

// Size: 0xb8
struct FClothParameters
{
public:
    FVector LinearVelocityScale() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    float AngularVelocityScale() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float FictitiousAngularScale() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    FVector GravityOverride() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector2D DragCoefficient() const { return Read<FVector2D>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FVector2D LiftCoefficient() const { return Read<FVector2D>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    FVector2D OuterDrag() const { return Read<FVector2D>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    FVector2D OuterLift() const { return Read<FVector2D>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StructProperty)
    FVector MaxLinearVelocity() const { return Read<FVector>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x18, Type: StructProperty)
    FVector MaxLinearAcceleration() const { return Read<FVector>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x18, Type: StructProperty)
    float MaxAngularVelocity() const { return Read<float>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    float MaxAngularAcceleration() const { return Read<float>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: FloatProperty)
    bool bEnableLinearVelocityClamping() const { return Read<bool>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x1, Type: BoolProperty)
    bool bEnableLinearAccelerationClamping() const { return Read<bool>(uintptr_t(this) + 0xb1); } // 0xb1 (Size: 0x1, Type: BoolProperty)
    bool bEnableAngularVelocityClamping() const { return Read<bool>(uintptr_t(this) + 0xb2); } // 0xb2 (Size: 0x1, Type: BoolProperty)
    bool bEnableAngularAccelerationClamping() const { return Read<bool>(uintptr_t(this) + 0xb3); } // 0xb3 (Size: 0x1, Type: BoolProperty)
    FName JointName() const { return Read<FName>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: NameProperty)

    void SET_LinearVelocityScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_AngularVelocityScale(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_FictitiousAngularScale(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_GravityOverride(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_DragCoefficient(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_LiftCoefficient(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_OuterDrag(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_OuterLift(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StructProperty)
    void SET_MaxLinearVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x18, Type: StructProperty)
    void SET_MaxLinearAcceleration(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x18, Type: StructProperty)
    void SET_MaxAngularVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxAngularAcceleration(const float& Value) { Write<float>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: FloatProperty)
    void SET_bEnableLinearVelocityClamping(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableLinearAccelerationClamping(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb1, Value); } // 0xb1 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableAngularVelocityClamping(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb2, Value); } // 0xb2 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableAngularAccelerationClamping(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb3, Value); } // 0xb3 (Size: 0x1, Type: BoolProperty)
    void SET_JointName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x14
struct FWindGustSettings
{
public:
    float ElapsedTime() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float TimeBetweenGusts() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float GustStrength() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float GustDuration() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float FinalGustStrengthLocal() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_ElapsedTime(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_TimeBetweenGusts(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_GustStrength(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_GustDuration(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_FinalGustStrengthLocal(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x78
struct FWindGustParameters
{
public:
    float MinTimeBetweenGusts() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxTimeBetweenGusts() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinGustStrength() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaxGustStrength() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float MinGustDuration() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float MaxGustDuration() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float WindTurbulenceScalarA() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float WindTurbulenceScalarB() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float MinUpInterpSpeed() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float MaxUpInterpSpeed() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float MinDownInterpSpeed() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float MaxDownInterpSpeed() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    FVector WindFrequency() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    FVector WindAmplitude() const { return Read<FVector>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    FVector WindOffset() const { return Read<FVector>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x18, Type: StructProperty)

    void SET_MinTimeBetweenGusts(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxTimeBetweenGusts(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MinGustStrength(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxGustStrength(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_MinGustDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_MaxGustDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_WindTurbulenceScalarA(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_WindTurbulenceScalarB(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_MinUpInterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_MaxUpInterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_MinDownInterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_MaxDownInterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_WindFrequency(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_WindAmplitude(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_WindOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x18, Type: StructProperty)
};

// Size: 0x50
struct FClothControllerClothParameterMap
{
public:
    TMap<FClothParameters, FName> Map() const { return Read<TMap<FClothParameters, FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_Map(const TMap<FClothParameters, FName>& Value) { Write<TMap<FClothParameters, FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x50
struct FClothControllerWindParameterMap
{
public:
    TMap<FWindGustParameters, FName> Map() const { return Read<TMap<FWindGustParameters, FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_Map(const TMap<FWindGustParameters, FName>& Value) { Write<TMap<FWindGustParameters, FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x50
struct FClothControllerPropertiesMap
{
public:
    TMap<bool, FName> Map() const { return Read<TMap<bool, FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_Map(const TMap<bool, FName>& Value) { Write<TMap<bool, FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x10
struct FFortCharacterDynamicsControlParameterSet
{
public:
    TArray<FName> StateNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_StateNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FFortClothParameterSet : public FFortCharacterDynamicsControlParameterSet
{
public:
    TArray<FClothParameters> Parameters() const { return Read<TArray<FClothParameters>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_Parameters(const TArray<FClothParameters>& Value) { Write<TArray<FClothParameters>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FFortGravityOverrideParameterSet : public FFortCharacterDynamicsControlParameterSet
{
public:
    TArray<FFortGravityOverrideParameters> Parameters() const { return Read<TArray<FFortGravityOverrideParameters>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_Parameters(const TArray<FFortGravityOverrideParameters>& Value) { Write<TArray<FFortGravityOverrideParameters>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x68
struct FFortGravityOverrideParameters
{
public:
    FVector WindFrequency() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector WindAmplitude() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FVector WindOffset() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    FVector GravityOverride() const { return Read<FVector>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    FName JointName() const { return Read<FName>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: NameProperty)

    void SET_WindFrequency(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_WindAmplitude(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_WindOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_GravityOverride(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_JointName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: NameProperty)
};

// Size: 0x20
struct FFortRigidBodyAnimNodeParameterSet : public FFortCharacterDynamicsControlParameterSet
{
public:
    TArray<FFortRigidBodyAnimNodeParameters> Parameters() const { return Read<TArray<FFortRigidBodyAnimNodeParameters>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_Parameters(const TArray<FFortRigidBodyAnimNodeParameters>& Value) { Write<TArray<FFortRigidBodyAnimNodeParameters>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x98
struct FFortRigidBodyAnimNodeParameters
{
public:
    FVector ComponentLinearAccScale() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector ComponentLinearVelScale() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FSimSpaceSettings SimSpaceSettings() const { return Read<FSimSpaceSettings>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x68, Type: StructProperty)

    void SET_ComponentLinearAccScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_ComponentLinearVelScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_SimSpaceSettings(const FSimSpaceSettings& Value) { Write<FSimSpaceSettings>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x68, Type: StructProperty)
};

// Size: 0x20
struct FFortWindGustParameterSet : public FFortCharacterDynamicsControlParameterSet
{
public:
    TArray<FWindGustParameters> Parameters() const { return Read<TArray<FWindGustParameters>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_Parameters(const TArray<FWindGustParameters>& Value) { Write<TArray<FWindGustParameters>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
struct FFortRigidBodyWithControlStateTransitionParameters
{
public:
    FPhysicsControlControlAndModifierParameters ControlAndModifierParameters() const { return Read<FPhysicsControlControlAndModifierParameters>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x30, Type: StructProperty)
    float TransitionTimeSeconds() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)

    void SET_ControlAndModifierParameters(const FPhysicsControlControlAndModifierParameters& Value) { Write<FPhysicsControlControlAndModifierParameters>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x30, Type: StructProperty)
    void SET_TransitionTimeSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FProxyProperty
{
public:
    uint32_t Operator() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)
    FBitArrayWrapper BitArrayMask() const { return Read<FBitArrayWrapper>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)

    void SET_Operator(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
    void SET_BitArrayMask(const FBitArrayWrapper& Value) { Write<FBitArrayWrapper>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
};

// Size: 0x18
struct FProxyPropertyOrderingEditorData
{
public:
    TArray<int32_t> ReversePropertyOrder() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t ProxyPropertyIndex() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_ReversePropertyOrder(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_ProxyPropertyIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

