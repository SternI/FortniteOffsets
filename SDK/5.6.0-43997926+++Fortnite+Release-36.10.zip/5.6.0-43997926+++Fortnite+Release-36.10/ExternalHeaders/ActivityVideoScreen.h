/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityVideoScreen
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"
#include "CommonUI.h"
#include "UI.h"
#include "Engine.h"
#include "UMG.h"
#include "UIKit.h"

// Size: 0x498
class UActivityVideoScreen_C : public UCommonActivatableWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: StructProperty)
    USafeZone* SafeZone_SkipButton() const { return Read<USafeZone*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Quiet_C* Button_Skip() const { return Read<UWBP_UIKit_Button_Quiet_C*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    UActivityVideoCycleWidget_C* ActivityVideoCycleWidget() const { return Read<UActivityVideoCycleWidget_C*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: StructProperty)
    void SET_SafeZone_SkipButton(const USafeZone*& Value) { Write<USafeZone*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Skip(const UWBP_UIKit_Button_Quiet_C*& Value) { Write<UWBP_UIKit_Button_Quiet_C*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    void SET_ActivityVideoCycleWidget(const UActivityVideoCycleWidget_C*& Value) { Write<UActivityVideoCycleWidget_C*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
};

