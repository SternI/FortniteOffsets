/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataAssetDirectory
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"

// Size: 0x28
class UDataAssetDirectoryPatchableAsset : public UInterface
{
public:
};

// Size: 0x30
class UDataAssetDirectorySimpleObject : public UObject
{
public:
    int32_t IntProperty() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)

    void SET_IntProperty(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
};

// Size: 0x70
class UDataAssetDirectoryTestPODAsset : public UObject
{
public:
    FString AssetName() const { return Read<FString>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StrProperty)
    uint8_t EnumProperty() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)
    int32_t IntProperty() const { return Read<int32_t>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: IntProperty)
    float FloatProperty() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    bool BoolProperty() const { return Read<bool>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x1, Type: BoolProperty)
    FString StringProperty() const { return Read<FString>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StrProperty)
    FName NameProperty() const { return Read<FName>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: NameProperty)
    FText TextProperty() const { return Read<FText>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: TextProperty)

    void SET_AssetName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StrProperty)
    void SET_EnumProperty(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
    void SET_IntProperty(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: IntProperty)
    void SET_FloatProperty(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_BoolProperty(const bool& Value) { Write<bool>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x1, Type: BoolProperty)
    void SET_StringProperty(const FString& Value) { Write<FString>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StrProperty)
    void SET_NameProperty(const FName& Value) { Write<FName>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: NameProperty)
    void SET_TextProperty(const FText& Value) { Write<FText>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: TextProperty)
};

// Size: 0x60
class UDataAssetDirectoryTestStructAsset : public UObject
{
public:
    FDataAssetDirectoryTestPODStruct TestStruct() const { return Read<FDataAssetDirectoryTestPODStruct>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x38, Type: StructProperty)

    void SET_TestStruct(const FDataAssetDirectoryTestPODStruct& Value) { Write<FDataAssetDirectoryTestPODStruct>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x38, Type: StructProperty)
};

// Size: 0x48
class UDataAssetDirectoryTestArrayAsset : public UObject
{
public:
    TArray<int32_t> IntArray() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FDataAssetDirectoryTestSimpleStruct> SimpleStructArray() const { return Read<TArray<FDataAssetDirectoryTestSimpleStruct>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_IntArray(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_SimpleStructArray(const TArray<FDataAssetDirectoryTestSimpleStruct>& Value) { Write<TArray<FDataAssetDirectoryTestSimpleStruct>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
class UDataAssetDirectoryTestObjectAsset : public UObject
{
public:
    UDataAssetDirectorySimpleObject* SimpleObject() const { return Read<UDataAssetDirectorySimpleObject*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_SimpleObject(const UDataAssetDirectorySimpleObject*& Value) { Write<UDataAssetDirectorySimpleObject*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x168
class UDataAssetDirectoryTestMapAsset : public UObject
{
public:
    TMap<int32_t, FString> StringIntMap() const { return Read<TMap<int32_t, FString>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: MapProperty)
    TMap<int32_t, FString> ShrinkStringIntMap() const { return Read<TMap<int32_t, FString>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x50, Type: MapProperty)
    TMap<int32_t, FString> GrowStringIntMap() const { return Read<TMap<int32_t, FString>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x50, Type: MapProperty)
    TMap<FDataAssetDirectoryTestSimpleStruct, int32_t> IntStructMap() const { return Read<TMap<FDataAssetDirectoryTestSimpleStruct, int32_t>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x50, Type: MapProperty)

    void SET_StringIntMap(const TMap<int32_t, FString>& Value) { Write<TMap<int32_t, FString>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: MapProperty)
    void SET_ShrinkStringIntMap(const TMap<int32_t, FString>& Value) { Write<TMap<int32_t, FString>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x50, Type: MapProperty)
    void SET_GrowStringIntMap(const TMap<int32_t, FString>& Value) { Write<TMap<int32_t, FString>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x50, Type: MapProperty)
    void SET_IntStructMap(const TMap<FDataAssetDirectoryTestSimpleStruct, int32_t>& Value) { Write<TMap<FDataAssetDirectoryTestSimpleStruct, int32_t>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x50, Type: MapProperty)
};

// Size: 0x1d0
class UDataAssetDirectoryManager : public UObject
{
public:
    TArray<UObject*> PatchedAssets() const { return Read<TArray<UObject*>>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x10, Type: ArrayProperty)
    FDateTime LastUpdateCheck() const { return Read<FDateTime>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x8, Type: StructProperty)
    uint32_t UpdateCheckLimitSeconds() const { return Read<uint32_t>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: UInt32Property)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x1bc); } // 0x1bc (Size: 0x1, Type: BoolProperty)
    bool bFailOnError() const { return Read<bool>(uintptr_t(this) + 0x1bd); } // 0x1bd (Size: 0x1, Type: BoolProperty)
    bool bAnalyticsEnabled() const { return Read<bool>(uintptr_t(this) + 0x1be); } // 0x1be (Size: 0x1, Type: BoolProperty)

    void SET_PatchedAssets(const TArray<UObject*>& Value) { Write<TArray<UObject*>>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x10, Type: ArrayProperty)
    void SET_LastUpdateCheck(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x8, Type: StructProperty)
    void SET_UpdateCheckLimitSeconds(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: UInt32Property)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1bc, Value); } // 0x1bc (Size: 0x1, Type: BoolProperty)
    void SET_bFailOnError(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1bd, Value); } // 0x1bd (Size: 0x1, Type: BoolProperty)
    void SET_bAnalyticsEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1be, Value); } // 0x1be (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UDataAssetDirectoryPatcher : public UObject
{
public:
};

// Size: 0x38
struct FDataAssetDirectoryTestPODStruct
{
public:
    uint8_t EnumProperty() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    int32_t IntProperty() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    float FloatProperty() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    bool BoolProperty() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)
    FString StringProperty() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FName NameProperty() const { return Read<FName>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: NameProperty)
    FText TextProperty() const { return Read<FText>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: TextProperty)

    void SET_EnumProperty(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_IntProperty(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_FloatProperty(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_BoolProperty(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
    void SET_StringProperty(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_NameProperty(const FName& Value) { Write<FName>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: NameProperty)
    void SET_TextProperty(const FText& Value) { Write<FText>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: TextProperty)
};

// Size: 0x4
struct FDataAssetDirectoryTestSimpleStruct
{
public:
    int32_t IntProperty() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)

    void SET_IntProperty(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
};

