/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Banners
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x28
class UBannerLibrary_C : public UBlueprintFunctionLibrary
{
public:
};

