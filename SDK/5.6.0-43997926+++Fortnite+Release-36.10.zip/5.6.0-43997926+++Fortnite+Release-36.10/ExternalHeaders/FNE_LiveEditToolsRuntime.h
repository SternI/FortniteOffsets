/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FNE_LiveEditToolsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "FortniteGame.h"
#include "Engine.h"

// Size: 0x178
class UDeleteEntities : public UDeleteObjects
{
public:
};

// Size: 0x158
class UMoveEntitiesFreely : public UMoveObjectsFreely
{
public:
    APhoneToolEntityInteractionMode* OwningEntityInteractionMode() const { return Read<APhoneToolEntityInteractionMode*>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x8, Type: ObjectProperty)

    void SET_OwningEntityInteractionMode(const APhoneToolEntityInteractionMode*& Value) { Write<APhoneToolEntityInteractionMode*>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x9a0
class ACreativeMoveToolPreviewEntity : public ACreativeMoveToolBlueprintPreview
{
public:
    UObject* PreviewObject() const { return Read<UObject*>(uintptr_t(this) + 0x988); } // 0x988 (Size: 0x8, Type: ObjectProperty)

    void SET_PreviewObject(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x988, Value); } // 0x988 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class UUEFNEntityInteractionTargetDetection : public UInteractionTargetDetection
{
public:
};

// Size: 0x30
class UUEFNEntityInteractionTargetEvaluator : public UInteractionTargetEvaluator
{
public:
};

// Size: 0x5a0
class ULevelRecordSpawnerEntities : public ULevelRecordSpawner
{
public:
    TArray<UObject*> SpawnedEntities() const { return Read<TArray<UObject*>>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x10, Type: ArrayProperty)

    void SET_SpawnedEntities(const TArray<UObject*>& Value) { Write<TArray<UObject*>>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x7e8
class ULevelSaveRecordEntities : public ULevelSaveRecord
{
public:
    uint64_t LastEntityRecordID() const { return Read<uint64_t>(uintptr_t(this) + 0x780); } // 0x780 (Size: 0x8, Type: UInt64Property)
    TMap<FEntityTemplateRecord, int32_t> EntityTemplateRecords() const { return Read<TMap<FEntityTemplateRecord, int32_t>>(uintptr_t(this) + 0x788); } // 0x788 (Size: 0x50, Type: MapProperty)
    TArray<FEntityInstanceRecord> EntityInstanceRecords() const { return Read<TArray<FEntityInstanceRecord>>(uintptr_t(this) + 0x7d8); } // 0x7d8 (Size: 0x10, Type: ArrayProperty)

    void SET_LastEntityRecordID(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x780, Value); } // 0x780 (Size: 0x8, Type: UInt64Property)
    void SET_EntityTemplateRecords(const TMap<FEntityTemplateRecord, int32_t>& Value) { Write<TMap<FEntityTemplateRecord, int32_t>>(uintptr_t(this) + 0x788, Value); } // 0x788 (Size: 0x50, Type: MapProperty)
    void SET_EntityInstanceRecords(const TArray<FEntityInstanceRecord>& Value) { Write<TArray<FEntityInstanceRecord>>(uintptr_t(this) + 0x7d8, Value); } // 0x7d8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x180
class ULSRThumbnailGeneratorEntities : public ULevelSaveRecordThumbnailGenerator
{
public:
    TArray<UObject*> SpawnedEntities() const { return Read<TArray<UObject*>>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x10, Type: ArrayProperty)

    void SET_SpawnedEntities(const TArray<UObject*>& Value) { Write<TArray<UObject*>>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x5e0
class APhoneToolEntityInteractionMode : public AObjectInteractionMode
{
public:
    FTimerHandle DelayForMultiSelectHighlightTH() const { return Read<FTimerHandle>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x8, Type: StructProperty)
    UMoveEntitiesFreely* MoveEntitiesFreelyInteractionBehavior() const { return Read<UMoveEntitiesFreely*>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    TArray<FOriginalAndSpawnedEntityPair> NewlyPlacedEntities() const { return Read<TArray<FOriginalAndSpawnedEntityPair>>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x10, Type: ArrayProperty)
    UObjectInteractionBehavior* ActiveBoundBehaviorReplicateToRemoteClients() const { return Read<UObjectInteractionBehavior*>(uintptr_t(this) + 0x510); } // 0x510 (Size: 0x8, Type: ObjectProperty)
    TArray<FCreativeSelectedEntityInfo> PlacementModeEntitiesReplicateToRemoteClients() const { return Read<TArray<FCreativeSelectedEntityInfo>>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x10, Type: ArrayProperty)

    void SET_DelayForMultiSelectHighlightTH(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x8, Type: StructProperty)
    void SET_MoveEntitiesFreelyInteractionBehavior(const UMoveEntitiesFreely*& Value) { Write<UMoveEntitiesFreely*>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    void SET_NewlyPlacedEntities(const TArray<FOriginalAndSpawnedEntityPair>& Value) { Write<TArray<FOriginalAndSpawnedEntityPair>>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x10, Type: ArrayProperty)
    void SET_ActiveBoundBehaviorReplicateToRemoteClients(const UObjectInteractionBehavior*& Value) { Write<UObjectInteractionBehavior*>(uintptr_t(this) + 0x510, Value); } // 0x510 (Size: 0x8, Type: ObjectProperty)
    void SET_PlacementModeEntitiesReplicateToRemoteClients(const TArray<FCreativeSelectedEntityInfo>& Value) { Write<TArray<FCreativeSelectedEntityInfo>>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FEntityTemplateRecord
{
public:
    uint64_t TemplateRecordID() const { return Read<uint64_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: UInt64Property)
    int16_t LevelRecordSaveVersion() const { return Read<int16_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x2, Type: Int16Property)

    void SET_TemplateRecordID(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: UInt64Property)
    void SET_LevelRecordSaveVersion(const int16_t& Value) { Write<int16_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x2, Type: Int16Property)
};

// Size: 0x90
struct FEntityInstanceRecord
{
public:
    uint64_t RecordID() const { return Read<uint64_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: UInt64Property)
    uint64_t TemplateRecordID() const { return Read<uint64_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: UInt64Property)
    FName EntityID() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    TWeakObjectPtr<UObject*> EntityPtr() const { return Read<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: WeakObjectProperty)

    void SET_RecordID(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: UInt64Property)
    void SET_TemplateRecordID(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: UInt64Property)
    void SET_EntityID(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_EntityPtr(const TWeakObjectPtr<UObject*>& Value) { Write<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xf0
struct FCreativeSelectedEntityInfo : public FCreativeSelectedObjectInfo
{
public:
    TSoftObjectPtr<UObject> EntitySoftPath() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x20, Type: SoftObjectProperty)

    void SET_EntitySoftPath(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x38
struct FOriginalAndSpawnedEntityPair
{
public:
    TSoftObjectPtr<UObject> SpawnedEntitySoftPath() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)

    void SET_SpawnedEntitySoftPath(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
};

