/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_SkilledInteractionDevice
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x4b8
class UFortSkilledInteractContainerBase : public UCommonActivatableWidget
{
public:
    TArray<FActionIdentifier> TriggeringActions() const { return Read<TArray<FActionIdentifier>>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x10, Type: ArrayProperty)

    void SET_TriggeringActions(const TArray<FActionIdentifier>& Value) { Write<TArray<FActionIdentifier>>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xe0
class UFortSkilledInteractionPlayerComponent : public UPlayerStateComponent
{
public:
    UClass* ViewModelClass() const { return Read<UClass*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ClassProperty)
    UFortSkilledInteractionPlayerViewModel* ViewModel() const { return Read<UFortSkilledInteractionPlayerViewModel*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AActor*> InteractionDevice() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t InteractionState() const { return Read<uint8_t>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: EnumProperty)
    int32_t SuccessCount() const { return Read<int32_t>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: IntProperty)
    int32_t FailureCount() const { return Read<int32_t>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: IntProperty)

    void SET_ViewModelClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ClassProperty)
    void SET_ViewModel(const UFortSkilledInteractionPlayerViewModel*& Value) { Write<UFortSkilledInteractionPlayerViewModel*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_InteractionDevice(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_InteractionState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: EnumProperty)
    void SET_SuccessCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: IntProperty)
    void SET_FailureCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: IntProperty)
};

// Size: 0xd8
class UFortSkilledInteractionPlayerListComponent : public UActorComponent
{
public:
    UClass* ViewModelClass() const { return Read<UClass*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ClassProperty)
    UFortSkilledInteractionPlayerListViewModel* ViewModel() const { return Read<UFortSkilledInteractionPlayerListViewModel*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    int32_t SuccessTarget() const { return Read<int32_t>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: IntProperty)
    int32_t FailureLimit() const { return Read<int32_t>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: IntProperty)

    void SET_ViewModelClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ClassProperty)
    void SET_ViewModel(const UFortSkilledInteractionPlayerListViewModel*& Value) { Write<UFortSkilledInteractionPlayerListViewModel*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_SuccessTarget(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: IntProperty)
    void SET_FailureLimit(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: IntProperty)
};

// Size: 0x80
class UFortSkilledInteractionPlayerListViewModel : public UMVVMViewModelBase
{
public:
    TArray<UFortSkilledInteractionPlayerViewModel*> Players() const { return Read<TArray<UFortSkilledInteractionPlayerViewModel*>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    int32_t SuccessTarget() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)
    int32_t FailureLimit() const { return Read<int32_t>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: IntProperty)

    void SET_Players(const TArray<UFortSkilledInteractionPlayerViewModel*>& Value) { Write<TArray<UFortSkilledInteractionPlayerViewModel*>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_SuccessTarget(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
    void SET_FailureLimit(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: IntProperty)
};

// Size: 0xd8
class UFortSkilledInteractionPlayerQueueComponent : public UActorComponent
{
public:
    uint8_t QueueType() const { return Read<uint8_t>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: EnumProperty)
    int32_t SynchronousExecutionAmount() const { return Read<int32_t>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: IntProperty)
    bool bAllowDuplicateControllerEntries() const { return Read<bool>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    int32_t QueueSizeMax() const { return Read<int32_t>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: IntProperty)
    TArray<TSoftObjectPtr<AController*>> ControllerQueue() const { return Read<TArray<TSoftObjectPtr<AController*>>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)

    void SET_QueueType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: EnumProperty)
    void SET_SynchronousExecutionAmount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: IntProperty)
    void SET_bAllowDuplicateControllerEntries(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    void SET_QueueSizeMax(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: IntProperty)
    void SET_ControllerQueue(const TArray<TSoftObjectPtr<AController*>>& Value) { Write<TArray<TSoftObjectPtr<AController*>>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x90
class UFortSkilledInteractionPlayerViewModel : public UMVVMViewModelBase
{
public:
    APlayerState* PlayerState() const { return Read<APlayerState*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    uint8_t InteractionState() const { return Read<uint8_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: EnumProperty)
    int32_t SuccessCount() const { return Read<int32_t>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: IntProperty)
    int32_t FailureCount() const { return Read<int32_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: IntProperty)

    void SET_PlayerState(const APlayerState*& Value) { Write<APlayerState*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_InteractionState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: EnumProperty)
    void SET_SuccessCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: IntProperty)
    void SET_FailureCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: IntProperty)
};

// Size: 0x28
class UFortSkilledInteractionViewModelResolver : public UMVVMViewModelContextResolver
{
public:
};

// Size: 0x8
struct FActionIdentifier
{
public:
    uint8_t CommonInputType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FName ActionName() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)

    void SET_CommonInputType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_ActionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
};

