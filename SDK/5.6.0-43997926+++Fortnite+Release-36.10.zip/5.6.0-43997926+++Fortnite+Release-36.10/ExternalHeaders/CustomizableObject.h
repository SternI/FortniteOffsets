/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CustomizableObject
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "GameplayTags.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "ClothingSystemRuntimeCommon.h"

// Size: 0x28
class UCustomizableObjectExtension : public UObject
{
public:
};

// Size: 0x58
class UCustomizableObjectInstanceUserData : public UAssetUserData
{
public:
    FGameplayTagContainer AnimationGameplayTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: StructProperty)
    TArray<FCustomizableObjectAnimationSlot> AnimationSlots() const { return Read<TArray<FCustomizableObjectAnimationSlot>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)

    void SET_AnimationGameplayTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: StructProperty)
    void SET_AnimationSlots(const TArray<FCustomizableObjectAnimationSlot>& Value) { Write<TArray<FCustomizableObjectAnimationSlot>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x558
class UCustomizableInstancePrivate : public UObject
{
public:
    TMap<USkeletalMesh*, FName> SkeletalMeshes() const { return Read<TMap<USkeletalMesh*, FName>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: MapProperty)
    TArray<FGeneratedMaterial> GeneratedMaterials() const { return Read<TArray<FGeneratedMaterial>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    TArray<FGeneratedTexture> GeneratedTextures() const { return Read<TArray<FGeneratedTexture>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    TMap<TWeakObjectPtr<UTexture2D*>, FString> TextureReuseCache() const { return Read<TMap<TWeakObjectPtr<UTexture2D*>, FString>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x50, Type: MapProperty)
    TArray<FCustomizableInstanceComponentData> ComponentsData() const { return Read<TArray<FCustomizableInstanceComponentData>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInterface*> ReferencedMaterials() const { return Read<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x10, Type: ArrayProperty)
    TArray<UPhysicsAsset*> ClothingPhysicsAssets() const { return Read<TArray<UPhysicsAsset*>>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> GatheredAnimBPs() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer AnimBPGameplayTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x20, Type: StructProperty)
    TMap<FAnimBpGeneratedPhysicsAssets, UClass*> AnimBpPhysicsAssets() const { return Read<TMap<FAnimBpGeneratedPhysicsAssets, UClass*>>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x50, Type: MapProperty)
    TArray<FExtensionInstanceData> ExtensionInstanceData() const { return Read<TArray<FExtensionInstanceData>>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x10, Type: ArrayProperty)
    TArray<UTexture*> LoadedPassThroughTexturesPendingSetMaterial() const { return Read<TArray<UTexture*>>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x10, Type: ArrayProperty)
    TArray<UStreamableRenderAsset*> LoadedPassThroughMeshesPendingSetMaterial() const { return Read<TArray<UStreamableRenderAsset*>>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x10, Type: ArrayProperty)
    FCustomizableObjectInstanceDescriptor CommittedDescriptor() const { return Read<FCustomizableObjectInstanceDescriptor>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x180, Type: StructProperty)

    void SET_SkeletalMeshes(const TMap<USkeletalMesh*, FName>& Value) { Write<TMap<USkeletalMesh*, FName>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: MapProperty)
    void SET_GeneratedMaterials(const TArray<FGeneratedMaterial>& Value) { Write<TArray<FGeneratedMaterial>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    void SET_GeneratedTextures(const TArray<FGeneratedTexture>& Value) { Write<TArray<FGeneratedTexture>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    void SET_TextureReuseCache(const TMap<TWeakObjectPtr<UTexture2D*>, FString>& Value) { Write<TMap<TWeakObjectPtr<UTexture2D*>, FString>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x50, Type: MapProperty)
    void SET_ComponentsData(const TArray<FCustomizableInstanceComponentData>& Value) { Write<TArray<FCustomizableInstanceComponentData>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    void SET_ReferencedMaterials(const TArray<UMaterialInterface*>& Value) { Write<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x10, Type: ArrayProperty)
    void SET_ClothingPhysicsAssets(const TArray<UPhysicsAsset*>& Value) { Write<TArray<UPhysicsAsset*>>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x10, Type: ArrayProperty)
    void SET_GatheredAnimBPs(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x10, Type: ArrayProperty)
    void SET_AnimBPGameplayTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x20, Type: StructProperty)
    void SET_AnimBpPhysicsAssets(const TMap<FAnimBpGeneratedPhysicsAssets, UClass*>& Value) { Write<TMap<FAnimBpGeneratedPhysicsAssets, UClass*>>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x50, Type: MapProperty)
    void SET_ExtensionInstanceData(const TArray<FExtensionInstanceData>& Value) { Write<TArray<FExtensionInstanceData>>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x10, Type: ArrayProperty)
    void SET_LoadedPassThroughTexturesPendingSetMaterial(const TArray<UTexture*>& Value) { Write<TArray<UTexture*>>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x10, Type: ArrayProperty)
    void SET_LoadedPassThroughMeshesPendingSetMaterial(const TArray<UStreamableRenderAsset*>& Value) { Write<TArray<UStreamableRenderAsset*>>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x10, Type: ArrayProperty)
    void SET_CommittedDescriptor(const FCustomizableObjectInstanceDescriptor& Value) { Write<FCustomizableObjectInstanceDescriptor>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x180, Type: StructProperty)
};

// Size: 0x60
class UCustomizableObjectInstanceUsage : public UObject
{
public:
    TWeakObjectPtr<USkeletalMeshComponent*> UsedSkeletalMeshComponent() const { return Read<TWeakObjectPtr<USkeletalMeshComponent*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: WeakObjectProperty)
    UCustomizableObjectInstance* UsedCustomizableObjectInstance() const { return Read<UCustomizableObjectInstance*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    int32_t UsedComponentIndex() const { return Read<int32_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: IntProperty)
    FName UsedComponentName() const { return Read<FName>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: NameProperty)
    bool bUsedSkipSetReferenceSkeletalMesh() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    bool bUsedSkipSetSkeletalMeshOnAttach() const { return Read<bool>(uintptr_t(this) + 0x51); } // 0x51 (Size: 0x1, Type: BoolProperty)
    UCustomizableObjectInstanceUsagePrivate* Private() const { return Read<UCustomizableObjectInstanceUsagePrivate*>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: ObjectProperty)

    void SET_UsedSkeletalMeshComponent(const TWeakObjectPtr<USkeletalMeshComponent*>& Value) { Write<TWeakObjectPtr<USkeletalMeshComponent*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: WeakObjectProperty)
    void SET_UsedCustomizableObjectInstance(const UCustomizableObjectInstance*& Value) { Write<UCustomizableObjectInstance*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_UsedComponentIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: IntProperty)
    void SET_UsedComponentName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: NameProperty)
    void SET_bUsedSkipSetReferenceSkeletalMesh(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_bUsedSkipSetSkeletalMeshOnAttach(const bool& Value) { Write<bool>(uintptr_t(this) + 0x51, Value); } // 0x51 (Size: 0x1, Type: BoolProperty)
    void SET_Private(const UCustomizableObjectInstanceUsagePrivate*& Value) { Write<UCustomizableObjectInstanceUsagePrivate*>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
class UCustomizableObjectInstanceUsagePrivate : public UObject
{
public:
};

// Size: 0x38
class UModelStreamableData : public UObject
{
public:
};

// Size: 0x488
class UModelResources : public UObject
{
public:
    TArray<FMutableRefSkeletalMeshData> ReferenceSkeletalMeshesData() const { return Read<TArray<FMutableRefSkeletalMeshData>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftObjectPtr<USkeleton*>> Skeletons() const { return Read<TArray<TSoftObjectPtr<USkeleton*>>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftObjectPtr<UMaterialInterface*>> Materials() const { return Read<TArray<TSoftObjectPtr<UMaterialInterface*>>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftObjectPtr<UTexture*>> PassThroughTextures() const { return Read<TArray<TSoftObjectPtr<UTexture*>>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftObjectPtr<UStreamableRenderAsset*>> PassThroughMeshes() const { return Read<TArray<TSoftObjectPtr<UStreamableRenderAsset*>>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftObjectPtr<UPhysicsAsset*>> PhysicsAssets() const { return Read<TArray<TSoftObjectPtr<UPhysicsAsset*>>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftClassPtr> AnimBPs() const { return Read<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    TArray<FAnimBpOverridePhysicsAssetsInfo> AnimBpOverridePhysiscAssetsInfo() const { return Read<TArray<FAnimBpOverridePhysicsAssetsInfo>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> MaterialSlotNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    TMap<uint32_t, FString> BoneNamesMap() const { return Read<TMap<uint32_t, FString>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x50, Type: MapProperty)
    TArray<FMutableRefSocket> SocketArray() const { return Read<TArray<FMutableRefSocket>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    TArray<FMutableSkinWeightProfileInfo> SkinWeightProfilesInfo() const { return Read<TArray<FMutableSkinWeightProfileInfo>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x10, Type: ArrayProperty)
    TArray<FMutableModelImageProperties> ImageProperties() const { return Read<TArray<FMutableModelImageProperties>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x10, Type: ArrayProperty)
    TMap<FMutableMeshMetadata, uint32_t> MeshMetadata() const { return Read<TMap<FMutableMeshMetadata, uint32_t>>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x50, Type: MapProperty)
    TMap<FMutableSurfaceMetadata, uint32_t> SurfaceMetadata() const { return Read<TMap<FMutableSurfaceMetadata, uint32_t>>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x50, Type: MapProperty)
    TMap<FMutableParameterData, FString> ParameterUIDataMap() const { return Read<TMap<FMutableParameterData, FString>>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x50, Type: MapProperty)
    TMap<FMutableStateData, FString> StateUIDataMap() const { return Read<TMap<FMutableStateData, FString>>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x50, Type: MapProperty)
    TArray<FCustomizableObjectClothConfigData> ClothSharedConfigsData() const { return Read<TArray<FCustomizableObjectClothConfigData>>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectClothingAssetData> ClothingAssetsData() const { return Read<TArray<FCustomizableObjectClothingAssetData>>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x10, Type: ArrayProperty)
    bool bAllowClothingPhysicsEditsPropagation() const { return Read<bool>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x1, Type: BoolProperty)
    TArray<FCustomizableObjectStreamedResourceData> StreamedResourceData() const { return Read<TArray<FCustomizableObjectStreamedResourceData>>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectResourceData> AlwaysLoadedExtensionData() const { return Read<TArray<FCustomizableObjectResourceData>>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectStreamedResourceData> StreamedExtensionData() const { return Read<TArray<FCustomizableObjectStreamedResourceData>>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    TMap<char, FName> NumLODsAvailable() const { return Read<TMap<char, FName>>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x50, Type: MapProperty)
    TMap<char, FName> NumLODsToStream() const { return Read<TMap<char, FName>>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x50, Type: MapProperty)
    TMap<char, FName> FirstLODAvailable() const { return Read<TMap<char, FName>>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x50, Type: MapProperty)
    TArray<FName> ComponentNamesPerObjectComponent() const { return Read<TArray<FName>>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x10, Type: ArrayProperty)
    TMap<FPerPlatformInt, FName> MinLODPerComponent() const { return Read<TMap<FPerPlatformInt, FName>>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x50, Type: MapProperty)
    TMap<FPerQualityLevelInt, FName> MinQualityLevelLODPerComponent() const { return Read<TMap<FPerQualityLevelInt, FName>>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x50, Type: MapProperty)
    FString ReleaseVersion() const { return Read<FString>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x10, Type: StrProperty)
    int32_t CodeVersion() const { return Read<int32_t>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x4, Type: IntProperty)

    void SET_ReferenceSkeletalMeshesData(const TArray<FMutableRefSkeletalMeshData>& Value) { Write<TArray<FMutableRefSkeletalMeshData>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_Skeletons(const TArray<TSoftObjectPtr<USkeleton*>>& Value) { Write<TArray<TSoftObjectPtr<USkeleton*>>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_Materials(const TArray<TSoftObjectPtr<UMaterialInterface*>>& Value) { Write<TArray<TSoftObjectPtr<UMaterialInterface*>>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_PassThroughTextures(const TArray<TSoftObjectPtr<UTexture*>>& Value) { Write<TArray<TSoftObjectPtr<UTexture*>>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_PassThroughMeshes(const TArray<TSoftObjectPtr<UStreamableRenderAsset*>>& Value) { Write<TArray<TSoftObjectPtr<UStreamableRenderAsset*>>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_PhysicsAssets(const TArray<TSoftObjectPtr<UPhysicsAsset*>>& Value) { Write<TArray<TSoftObjectPtr<UPhysicsAsset*>>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    void SET_AnimBPs(const TArray<TSoftClassPtr>& Value) { Write<TArray<TSoftClassPtr>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    void SET_AnimBpOverridePhysiscAssetsInfo(const TArray<FAnimBpOverridePhysicsAssetsInfo>& Value) { Write<TArray<FAnimBpOverridePhysicsAssetsInfo>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    void SET_MaterialSlotNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    void SET_BoneNamesMap(const TMap<uint32_t, FString>& Value) { Write<TMap<uint32_t, FString>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x50, Type: MapProperty)
    void SET_SocketArray(const TArray<FMutableRefSocket>& Value) { Write<TArray<FMutableRefSocket>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    void SET_SkinWeightProfilesInfo(const TArray<FMutableSkinWeightProfileInfo>& Value) { Write<TArray<FMutableSkinWeightProfileInfo>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x10, Type: ArrayProperty)
    void SET_ImageProperties(const TArray<FMutableModelImageProperties>& Value) { Write<TArray<FMutableModelImageProperties>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x10, Type: ArrayProperty)
    void SET_MeshMetadata(const TMap<FMutableMeshMetadata, uint32_t>& Value) { Write<TMap<FMutableMeshMetadata, uint32_t>>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x50, Type: MapProperty)
    void SET_SurfaceMetadata(const TMap<FMutableSurfaceMetadata, uint32_t>& Value) { Write<TMap<FMutableSurfaceMetadata, uint32_t>>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x50, Type: MapProperty)
    void SET_ParameterUIDataMap(const TMap<FMutableParameterData, FString>& Value) { Write<TMap<FMutableParameterData, FString>>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x50, Type: MapProperty)
    void SET_StateUIDataMap(const TMap<FMutableStateData, FString>& Value) { Write<TMap<FMutableStateData, FString>>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x50, Type: MapProperty)
    void SET_ClothSharedConfigsData(const TArray<FCustomizableObjectClothConfigData>& Value) { Write<TArray<FCustomizableObjectClothConfigData>>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x10, Type: ArrayProperty)
    void SET_ClothingAssetsData(const TArray<FCustomizableObjectClothingAssetData>& Value) { Write<TArray<FCustomizableObjectClothingAssetData>>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x10, Type: ArrayProperty)
    void SET_bAllowClothingPhysicsEditsPropagation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x1, Type: BoolProperty)
    void SET_StreamedResourceData(const TArray<FCustomizableObjectStreamedResourceData>& Value) { Write<TArray<FCustomizableObjectStreamedResourceData>>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x10, Type: ArrayProperty)
    void SET_AlwaysLoadedExtensionData(const TArray<FCustomizableObjectResourceData>& Value) { Write<TArray<FCustomizableObjectResourceData>>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x10, Type: ArrayProperty)
    void SET_StreamedExtensionData(const TArray<FCustomizableObjectStreamedResourceData>& Value) { Write<TArray<FCustomizableObjectStreamedResourceData>>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    void SET_NumLODsAvailable(const TMap<char, FName>& Value) { Write<TMap<char, FName>>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x50, Type: MapProperty)
    void SET_NumLODsToStream(const TMap<char, FName>& Value) { Write<TMap<char, FName>>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x50, Type: MapProperty)
    void SET_FirstLODAvailable(const TMap<char, FName>& Value) { Write<TMap<char, FName>>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x50, Type: MapProperty)
    void SET_ComponentNamesPerObjectComponent(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x10, Type: ArrayProperty)
    void SET_MinLODPerComponent(const TMap<FPerPlatformInt, FName>& Value) { Write<TMap<FPerPlatformInt, FName>>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x50, Type: MapProperty)
    void SET_MinQualityLevelLODPerComponent(const TMap<FPerQualityLevelInt, FName>& Value) { Write<TMap<FPerQualityLevelInt, FName>>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x50, Type: MapProperty)
    void SET_ReleaseVersion(const FString& Value) { Write<FString>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x10, Type: StrProperty)
    void SET_CodeVersion(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x4, Type: IntProperty)
};

// Size: 0x38
class UCustomizableObjectBulk : public UObject
{
public:
};

// Size: 0x178
class UCustomizableObjectPrivate : public UObject
{
public:
    UModelStreamableData* ModelStreamableData() const { return Read<UModelStreamableData*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    UModelResources* ModelResources() const { return Read<UModelResources*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    TArray<FMutableModelParameterProperties> ParameterProperties() const { return Read<TArray<FMutableModelParameterProperties>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: ArrayProperty)
    UModelResources* ReferencedObjects() const { return Read<UModelResources*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)

    void SET_ModelStreamableData(const UModelStreamableData*& Value) { Write<UModelStreamableData*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_ModelResources(const UModelResources*& Value) { Write<UModelResources*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_ParameterProperties(const TArray<FMutableModelParameterProperties>& Value) { Write<TArray<FMutableModelParameterProperties>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: ArrayProperty)
    void SET_ReferencedObjects(const UModelResources*& Value) { Write<UModelResources*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x40
class UCustomizableObjectResourceDataContainer : public UObject
{
public:
    FCustomizableObjectResourceData Data() const { return Read<FCustomizableObjectResourceData>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_Data(const FCustomizableObjectResourceData& Value) { Write<FCustomizableObjectResourceData>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x5e0
class UCustomizableObjectSkeletalMesh : public USkeletalMesh
{
public:
};

// Size: 0x4a0
class UCustomizableObjectSystemPrivate : public UObject
{
public:
    UCustomizableObjectInstance* CurrentInstanceBeingUpdated() const { return Read<UCustomizableObjectInstance*>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    TArray<FPendingReleaseSkeletalMeshInfo> PendingReleaseSkeletalMesh() const { return Read<TArray<FPendingReleaseSkeletalMeshInfo>>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x10, Type: ArrayProperty)
    UCustomizableInstanceLODManagementBase* DefaultInstanceLODManagement() const { return Read<UCustomizableInstanceLODManagementBase*>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    UCustomizableInstanceLODManagementBase* CurrentInstanceLODManagement() const { return Read<UCustomizableInstanceLODManagementBase*>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    TArray<UTexture2D*> ProtectedCachedTextures() const { return Read<TArray<UTexture2D*>>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x10, Type: ArrayProperty)

    void SET_CurrentInstanceBeingUpdated(const UCustomizableObjectInstance*& Value) { Write<UCustomizableObjectInstance*>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    void SET_PendingReleaseSkeletalMesh(const TArray<FPendingReleaseSkeletalMeshInfo>& Value) { Write<TArray<FPendingReleaseSkeletalMeshInfo>>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x10, Type: ArrayProperty)
    void SET_DefaultInstanceLODManagement(const UCustomizableInstanceLODManagementBase*& Value) { Write<UCustomizableInstanceLODManagementBase*>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentInstanceLODManagement(const UCustomizableInstanceLODManagementBase*& Value) { Write<UCustomizableInstanceLODManagementBase*>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    void SET_ProtectedCachedTextures(const TArray<UTexture2D*>& Value) { Write<TArray<UTexture2D*>>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x280
class UCustomizableSkeletalComponent : public USceneComponent
{
public:
    UCustomizableObjectInstance* CustomizableObjectInstance() const { return Read<UCustomizableObjectInstance*>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x8, Type: ObjectProperty)
    int32_t ComponentIndex() const { return Read<int32_t>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x4, Type: IntProperty)
    FName ComponentName() const { return Read<FName>(uintptr_t(this) + 0x24c); } // 0x24c (Size: 0x4, Type: NameProperty)
    bool bSkipSetReferenceSkeletalMesh() const { return Read<bool>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x1, Type: BoolProperty)
    bool bSkipSkipSetSkeletalMeshOnAttach() const { return Read<bool>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x1, Type: BoolProperty)
    UCustomizableSkeletalComponentPrivate* Private() const { return Read<UCustomizableSkeletalComponentPrivate*>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x8, Type: ObjectProperty)

    void SET_CustomizableObjectInstance(const UCustomizableObjectInstance*& Value) { Write<UCustomizableObjectInstance*>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x8, Type: ObjectProperty)
    void SET_ComponentIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x4, Type: IntProperty)
    void SET_ComponentName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x24c, Value); } // 0x24c (Size: 0x4, Type: NameProperty)
    void SET_bSkipSetReferenceSkeletalMesh(const bool& Value) { Write<bool>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x1, Type: BoolProperty)
    void SET_bSkipSkipSetSkeletalMeshOnAttach(const bool& Value) { Write<bool>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x1, Type: BoolProperty)
    void SET_Private(const UCustomizableSkeletalComponentPrivate*& Value) { Write<UCustomizableSkeletalComponentPrivate*>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
class UCustomizableSkeletalComponentPrivate : public UObject
{
public:
    UCustomizableObjectInstanceUsage* InstanceUsage() const { return Read<UCustomizableObjectInstanceUsage*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_InstanceUsage(const UCustomizableObjectInstanceUsage*& Value) { Write<UCustomizableObjectInstanceUsage*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UCustomizableSkeletalMeshActorPrivate : public UObject
{
public:
};

// Size: 0x28
class UEditorImageProvider : public UCustomizableSystemImageProvider
{
public:
};

// Size: 0x28
class UCustomizableSystemImageProvider : public UObject
{
public:
};

// Size: 0x28
class UCustomizableInstanceLODManagementBase : public UObject
{
public:
};

// Size: 0x80
class UCustomizableInstanceLODManagement : public UCustomizableInstanceLODManagementBase
{
public:
};

// Size: 0x130
class UCustomizableObject : public UObject
{
public:
    FMutableLODSettings LODSettings() const { return Read<FMutableLODSettings>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x70, Type: StructProperty)
    bool bEnableUseRefSkeletalMeshAsPlaceholder() const { return Read<bool>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: BoolProperty)
    bool bPreserveUserLODsOnFirstGeneration() const { return Read<bool>(uintptr_t(this) + 0x99); } // 0x99 (Size: 0x1, Type: BoolProperty)
    bool bEnableMeshCache() const { return Read<bool>(uintptr_t(this) + 0x9a); } // 0x9a (Size: 0x1, Type: BoolProperty)
    bool bEnableMeshStreaming() const { return Read<bool>(uintptr_t(this) + 0x9b); } // 0x9b (Size: 0x1, Type: BoolProperty)
    TArray<FName> LowPriorityTextures() const { return Read<TArray<FName>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> CustomizableObjectClassTags() const { return Read<TArray<FString>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> PopulationClassTags() const { return Read<TArray<FString>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    TMap<FParameterTags, FString> CustomizableObjectParametersTags() const { return Read<TMap<FParameterTags, FString>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x50, Type: MapProperty)
    UCustomizableObjectBulk* BulkData() const { return Read<UCustomizableObjectBulk*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    UCustomizableObjectPrivate* Private() const { return Read<UCustomizableObjectPrivate*>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: ObjectProperty)

    void SET_LODSettings(const FMutableLODSettings& Value) { Write<FMutableLODSettings>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x70, Type: StructProperty)
    void SET_bEnableUseRefSkeletalMeshAsPlaceholder(const bool& Value) { Write<bool>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: BoolProperty)
    void SET_bPreserveUserLODsOnFirstGeneration(const bool& Value) { Write<bool>(uintptr_t(this) + 0x99, Value); } // 0x99 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableMeshCache(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9a, Value); } // 0x9a (Size: 0x1, Type: BoolProperty)
    void SET_bEnableMeshStreaming(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9b, Value); } // 0x9b (Size: 0x1, Type: BoolProperty)
    void SET_LowPriorityTextures(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
    void SET_CustomizableObjectClassTags(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    void SET_PopulationClassTags(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    void SET_CustomizableObjectParametersTags(const TMap<FParameterTags, FString>& Value) { Write<TMap<FParameterTags, FString>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x50, Type: MapProperty)
    void SET_BulkData(const UCustomizableObjectBulk*& Value) { Write<UCustomizableObjectBulk*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    void SET_Private(const UCustomizableObjectPrivate*& Value) { Write<UCustomizableObjectPrivate*>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x320
class UDGGUI : public UUserWidget
{
public:
};

// Size: 0x270
class UCustomizableObjectInstance : public UObject
{
public:
    FCustomizableObjectInstanceDescriptor Descriptor() const { return Read<FCustomizableObjectInstanceDescriptor>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x180, Type: StructProperty)
    UCustomizableInstancePrivate* PrivateData() const { return Read<UCustomizableInstancePrivate*>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x8, Type: ObjectProperty)
    UCustomizableObject* CustomizableObject() const { return Read<UCustomizableObject*>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x8, Type: ObjectProperty)
    TArray<FCustomizableObjectBoolParameterValue> BoolParameters() const { return Read<TArray<FCustomizableObjectBoolParameterValue>>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectIntParameterValue> IntParameters() const { return Read<TArray<FCustomizableObjectIntParameterValue>>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectFloatParameterValue> FloatParameters() const { return Read<TArray<FCustomizableObjectFloatParameterValue>>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectAssetParameterValue> TextureParameters() const { return Read<TArray<FCustomizableObjectAssetParameterValue>>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectVectorParameterValue> VectorParameters() const { return Read<TArray<FCustomizableObjectVectorParameterValue>>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectProjectorParameterValue> ProjectorParameters() const { return Read<TArray<FCustomizableObjectProjectorParameterValue>>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x10, Type: ArrayProperty)

    void SET_Descriptor(const FCustomizableObjectInstanceDescriptor& Value) { Write<FCustomizableObjectInstanceDescriptor>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x180, Type: StructProperty)
    void SET_PrivateData(const UCustomizableInstancePrivate*& Value) { Write<UCustomizableInstancePrivate*>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x8, Type: ObjectProperty)
    void SET_CustomizableObject(const UCustomizableObject*& Value) { Write<UCustomizableObject*>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x8, Type: ObjectProperty)
    void SET_BoolParameters(const TArray<FCustomizableObjectBoolParameterValue>& Value) { Write<TArray<FCustomizableObjectBoolParameterValue>>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x10, Type: ArrayProperty)
    void SET_IntParameters(const TArray<FCustomizableObjectIntParameterValue>& Value) { Write<TArray<FCustomizableObjectIntParameterValue>>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x10, Type: ArrayProperty)
    void SET_FloatParameters(const TArray<FCustomizableObjectFloatParameterValue>& Value) { Write<TArray<FCustomizableObjectFloatParameterValue>>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x10, Type: ArrayProperty)
    void SET_TextureParameters(const TArray<FCustomizableObjectAssetParameterValue>& Value) { Write<TArray<FCustomizableObjectAssetParameterValue>>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x10, Type: ArrayProperty)
    void SET_VectorParameters(const TArray<FCustomizableObjectVectorParameterValue>& Value) { Write<TArray<FCustomizableObjectVectorParameterValue>>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x10, Type: ArrayProperty)
    void SET_ProjectorParameters(const TArray<FCustomizableObjectProjectorParameterValue>& Value) { Write<TArray<FCustomizableObjectProjectorParameterValue>>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x60
class UMutableTextureMipDataProviderFactory : public UTextureMipDataProviderFactory
{
public:
    UCustomizableObjectInstance* CustomizableObjectInstance() const { return Read<UCustomizableObjectInstance*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_CustomizableObjectInstance(const UCustomizableObjectInstance*& Value) { Write<UCustomizableObjectInstance*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
class UCustomizableObjectSystem : public UObject
{
public:
    UCustomizableObjectSystemPrivate* Private() const { return Read<UCustomizableObjectSystemPrivate*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)

    void SET_Private(const UCustomizableObjectSystemPrivate*& Value) { Write<UCustomizableObjectSystemPrivate*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x360
class ACustomizableSkeletalMeshActor : public ASkeletalMeshActor
{
public:
    TArray<UCustomizableSkeletalComponent*> CustomizableSkeletalComponents() const { return Read<TArray<UCustomizableSkeletalComponent*>>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x10, Type: ArrayProperty)
    TArray<USkeletalMeshComponent*> SkeletalMeshComponents() const { return Read<TArray<USkeletalMeshComponent*>>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x10, Type: ArrayProperty)
    UMaterialInterface* DebugMaterial() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    UCustomizableSkeletalMeshActorPrivate* Private() const { return Read<UCustomizableSkeletalMeshActorPrivate*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)

    void SET_CustomizableSkeletalComponents(const TArray<UCustomizableSkeletalComponent*>& Value) { Write<TArray<UCustomizableSkeletalComponent*>>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x10, Type: ArrayProperty)
    void SET_SkeletalMeshComponents(const TArray<USkeletalMeshComponent*>& Value) { Write<TArray<USkeletalMeshComponent*>>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x10, Type: ArrayProperty)
    void SET_DebugMaterial(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_Private(const UCustomizableSkeletalMeshActorPrivate*& Value) { Write<UCustomizableSkeletalMeshActorPrivate*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x78
class UDefaultImageProvider : public UCustomizableSystemImageProvider
{
public:
    TMap<UTexture2D*, FName> Textures() const { return Read<TMap<UTexture2D*, FName>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: MapProperty)

    void SET_Textures(const TMap<UTexture2D*, FName>& Value) { Write<TMap<UTexture2D*, FName>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: MapProperty)
};

// Size: 0x18
struct FCustomizableObjectInstanceBakeOutput
{
public:
    bool bWasBakeSuccessful() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    TArray<FBakedResourceData> SavedPackages() const { return Read<TArray<FBakedResourceData>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_bWasBakeSuccessful(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_SavedPackages(const TArray<FBakedResourceData>& Value) { Write<TArray<FBakedResourceData>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FBakedResourceData
{
public:
    uint8_t SaveType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FString AssetPath() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)

    void SET_SaveType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_AssetPath(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x5
struct FCompileCallbackParams
{
public:
    bool bRequestFailed() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bWarnings() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bErrors() const { return Read<bool>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bSkipped() const { return Read<bool>(uintptr_t(this) + 0x3); } // 0x3 (Size: 0x1, Type: BoolProperty)
    bool bCompiled() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)

    void SET_bRequestFailed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bWarnings(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_bErrors(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: BoolProperty)
    void SET_bSkipped(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3, Value); } // 0x3 (Size: 0x1, Type: BoolProperty)
    void SET_bCompiled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1
struct FUpdateContext
{
public:
    uint8_t UpdateResult() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)

    void SET_UpdateResult(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x10
struct FPreSetSkeletalMeshParams
{
public:
    UCustomizableObjectInstance* Instance() const { return Read<UCustomizableObjectInstance*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    USkeletalMesh* SkeletalMesh() const { return Read<USkeletalMesh*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Instance(const UCustomizableObjectInstance*& Value) { Write<UCustomizableObjectInstance*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_SkeletalMesh(const USkeletalMesh*& Value) { Write<USkeletalMesh*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FCustomizableObjectClothConfigData
{
public:
    FString ClassPath() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FName ConfigName() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    TArray<char> ConfigBytes() const { return Read<TArray<char>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_ClassPath(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_ConfigName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_ConfigBytes(const TArray<char>& Value) { Write<TArray<char>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x70
struct FCustomizableObjectClothingAssetData
{
public:
    TArray<FClothLODDataCommon> LODData() const { return Read<TArray<FClothLODDataCommon>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> LodMap() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> UsedBoneNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> UsedBoneIndices() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    int32_t ReferenceBoneIndex() const { return Read<int32_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: IntProperty)
    TArray<FCustomizableObjectClothConfigData> ConfigsData() const { return Read<TArray<FCustomizableObjectClothConfigData>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: NameProperty)
    FGuid OriginalAssetGuid() const { return Read<FGuid>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x10, Type: StructProperty)

    void SET_LODData(const TArray<FClothLODDataCommon>& Value) { Write<TArray<FClothLODDataCommon>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_LodMap(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_UsedBoneNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_UsedBoneIndices(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_ReferenceBoneIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: IntProperty)
    void SET_ConfigsData(const TArray<FCustomizableObjectClothConfigData>& Value) { Write<TArray<FCustomizableObjectClothConfigData>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: NameProperty)
    void SET_OriginalAssetGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x10, Type: StructProperty)
};

// Size: 0x28
struct FCustomizableObjectAnimationSlot
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
};

// Size: 0x40
struct FReferencedPhysicsAssets
{
public:
    TArray<UPhysicsAsset*> PhysicsAssetsToMerge() const { return Read<TArray<UPhysicsAsset*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<UPhysicsAsset*> AdditionalPhysicsAssets() const { return Read<TArray<UPhysicsAsset*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_PhysicsAssetsToMerge(const TArray<UPhysicsAsset*>& Value) { Write<TArray<UPhysicsAsset*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_AdditionalPhysicsAssets(const TArray<UPhysicsAsset*>& Value) { Write<TArray<UPhysicsAsset*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FReferencedSkeletons
{
public:
    USkeleton* Skeleton() const { return Read<USkeleton*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<uint16_t> SkeletonIds() const { return Read<TArray<uint16_t>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<USkeleton*> SkeletonsToMerge() const { return Read<TArray<USkeleton*>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Skeleton(const USkeleton*& Value) { Write<USkeleton*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_SkeletonIds(const TArray<uint16_t>& Value) { Write<TArray<uint16_t>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_SkeletonsToMerge(const TArray<USkeleton*>& Value) { Write<TArray<USkeleton*>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x150
struct FCustomizableInstanceComponentData
{
public:
    TMap<TSoftClassPtr, FName> AnimSlotToBP() const { return Read<TMap<TSoftClassPtr, FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)
    TSet<UAssetUserData*> AssetUserDataArray() const { return Read<TSet<UAssetUserData*>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x50, Type: SetProperty)
    FReferencedSkeletons Skeletons() const { return Read<FReferencedSkeletons>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x28, Type: StructProperty)
    FReferencedPhysicsAssets PhysicsAssets() const { return Read<FReferencedPhysicsAssets>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x40, Type: StructProperty)
    TArray<UMaterialInterface*> OverrideMaterials() const { return Read<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x10, Type: ArrayProperty)
    UMaterialInterface* OverlayMaterial() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x8, Type: ObjectProperty)

    void SET_AnimSlotToBP(const TMap<TSoftClassPtr, FName>& Value) { Write<TMap<TSoftClassPtr, FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
    void SET_AssetUserDataArray(const TSet<UAssetUserData*>& Value) { Write<TSet<UAssetUserData*>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x50, Type: SetProperty)
    void SET_Skeletons(const FReferencedSkeletons& Value) { Write<FReferencedSkeletons>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x28, Type: StructProperty)
    void SET_PhysicsAssets(const FReferencedPhysicsAssets& Value) { Write<FReferencedPhysicsAssets>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x40, Type: StructProperty)
    void SET_OverrideMaterials(const TArray<UMaterialInterface*>& Value) { Write<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x10, Type: ArrayProperty)
    void SET_OverlayMaterial(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FAnimInstanceOverridePhysicsAsset
{
public:
    int32_t PropertyIndex() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    UPhysicsAsset* PhysicsAsset() const { return Read<UPhysicsAsset*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_PropertyIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_PhysicsAsset(const UPhysicsAsset*& Value) { Write<UPhysicsAsset*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FAnimBpGeneratedPhysicsAssets
{
public:
    TArray<FAnimInstanceOverridePhysicsAsset> AnimInstancePropertyIndexAndPhysicsAssets() const { return Read<TArray<FAnimInstanceOverridePhysicsAsset>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_AnimInstancePropertyIndexAndPhysicsAssets(const TArray<FAnimInstanceOverridePhysicsAsset>& Value) { Write<TArray<FAnimInstanceOverridePhysicsAsset>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FExtensionInstanceData
{
public:
    TWeakObjectPtr<UCustomizableObjectExtension*> Extension() const { return Read<TWeakObjectPtr<UCustomizableObjectExtension*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FInstancedStruct Data() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)

    void SET_Extension(const TWeakObjectPtr<UCustomizableObjectExtension*>& Value) { Write<TWeakObjectPtr<UCustomizableObjectExtension*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Data(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x28
struct FCustomizableObjectBoolParameterValue
{
public:
    FString ParameterName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    bool ParameterValue() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    FGuid ID() const { return Read<FGuid>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x10, Type: StructProperty)

    void SET_ParameterName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_ParameterValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_ID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x10, Type: StructProperty)
};

// Size: 0x40
struct FCustomizableObjectIntParameterValue
{
public:
    FString ParameterName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString ParameterValueName() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FGuid ID() const { return Read<FGuid>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    TArray<FString> ParameterRangeValueNames() const { return Read<TArray<FString>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_ParameterName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_ParameterValueName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_ID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_ParameterRangeValueNames(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
struct FCustomizableObjectFloatParameterValue
{
public:
    FString ParameterName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    float ParameterValue() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    FGuid ID() const { return Read<FGuid>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x10, Type: StructProperty)
    TArray<float> ParameterRangeValues() const { return Read<TArray<float>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_ParameterName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_ParameterValue(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_ID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x10, Type: StructProperty)
    void SET_ParameterRangeValues(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
struct FCustomizableObjectAssetParameterValue
{
public:
    FString ParameterName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FName ParameterValue() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FGuid ID() const { return Read<FGuid>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x10, Type: StructProperty)
    TArray<FName> ParameterRangeValues() const { return Read<TArray<FName>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_ParameterName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_ParameterValue(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_ID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x10, Type: StructProperty)
    void SET_ParameterRangeValues(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FCustomizableObjectVectorParameterValue
{
public:
    FString ParameterName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FLinearColor ParameterValue() const { return Read<FLinearColor>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FGuid ID() const { return Read<FGuid>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)

    void SET_ParameterName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_ParameterValue(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_ID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
};

// Size: 0x80
struct FCustomizableObjectTransformParameterValue
{
public:
    FString ParameterName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FTransform ParameterValue() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FGuid ID() const { return Read<FGuid>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: StructProperty)

    void SET_ParameterName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_ParameterValue(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_ID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: StructProperty)
};

// Size: 0x38
struct FCustomizableObjectProjector
{
public:
    FVector3f Position() const { return Read<FVector3f>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FVector3f Direction() const { return Read<FVector3f>(uintptr_t(this) + 0xc); } // 0xc (Size: 0xc, Type: StructProperty)
    FVector3f Up() const { return Read<FVector3f>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0xc, Type: StructProperty)
    FVector3f Scale() const { return Read<FVector3f>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0xc, Type: StructProperty)
    uint8_t ProjectionType() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)
    float Angle() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)

    void SET_Position(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_Direction(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0xc, Type: StructProperty)
    void SET_Up(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0xc, Type: StructProperty)
    void SET_Scale(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0xc, Type: StructProperty)
    void SET_ProjectionType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
    void SET_Angle(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x68
struct FCustomizableObjectProjectorParameterValue
{
public:
    FString ParameterName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FCustomizableObjectProjector Value() const { return Read<FCustomizableObjectProjector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x38, Type: StructProperty)
    FGuid ID() const { return Read<FGuid>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    TArray<FCustomizableObjectProjector> RangeValues() const { return Read<TArray<FCustomizableObjectProjector>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)

    void SET_ParameterName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Value(const FCustomizableObjectProjector& Value) { Write<FCustomizableObjectProjector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x38, Type: StructProperty)
    void SET_ID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_RangeValues(const TArray<FCustomizableObjectProjector>& Value) { Write<TArray<FCustomizableObjectProjector>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FCustomizableObjectMeshToMeshVertData
{
public:
    float PositionBaryCoordsAndDist() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: FloatProperty)
    float NormalBaryCoordsAndDist() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: FloatProperty)
    float TangentBaryCoordsAndDist() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: FloatProperty)
    uint16_t SourceMeshVertIndices() const { return Read<uint16_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: UInt16Property)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)

    void SET_PositionBaryCoordsAndDist(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: FloatProperty)
    void SET_NormalBaryCoordsAndDist(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: FloatProperty)
    void SET_TangentBaryCoordsAndDist(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: FloatProperty)
    void SET_SourceMeshVertIndices(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: UInt16Property)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FMutableRemappedBone
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    uint32_t Hash() const { return Read<uint32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: UInt32Property)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Hash(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x18
struct FMutableModelParameterValue
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x28
struct FMutableModelParameterProperties
{
public:
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    TArray<FMutableModelParameterValue> PossibleValues() const { return Read<TArray<FMutableModelParameterValue>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_PossibleValues(const TArray<FMutableModelParameterValue>& Value) { Write<TArray<FMutableModelParameterValue>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FMutableModelImageProperties
{
public:
    FString TextureParameterName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    TEnumAsByte<TextureFilter> Filter() const { return Read<TEnumAsByte<TextureFilter>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: ByteProperty)
    bool SRGB() const { return (Read<uint8_t>(uintptr_t(this) + 0x14) >> 0x0) & 1; } // 0x14:0 (Size: 0x1, Type: BoolProperty)
    bool FlipGreenChannel() const { return (Read<uint8_t>(uintptr_t(this) + 0x14) >> 0x1) & 1; } // 0x14:1 (Size: 0x1, Type: BoolProperty)
    bool IsPassThrough() const { return (Read<uint8_t>(uintptr_t(this) + 0x14) >> 0x2) & 1; } // 0x14:2 (Size: 0x1, Type: BoolProperty)
    int32_t LODBias() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    TEnumAsByte<TextureMipGenSettings> MipGenSettings() const { return Read<TEnumAsByte<TextureMipGenSettings>>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<TextureGroup> LODGroup() const { return Read<TEnumAsByte<TextureGroup>>(uintptr_t(this) + 0x1d); } // 0x1d (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<TextureAddress> AddressX() const { return Read<TEnumAsByte<TextureAddress>>(uintptr_t(this) + 0x1e); } // 0x1e (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<TextureAddress> AddressY() const { return Read<TEnumAsByte<TextureAddress>>(uintptr_t(this) + 0x1f); } // 0x1f (Size: 0x1, Type: ByteProperty)

    void SET_TextureParameterName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Filter(const TEnumAsByte<TextureFilter>& Value) { Write<TEnumAsByte<TextureFilter>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: ByteProperty)
    void SET_SRGB(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x14); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x14, B); } // 0x14:0 (Size: 0x1, Type: BoolProperty)
    void SET_FlipGreenChannel(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x14); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x14, B); } // 0x14:1 (Size: 0x1, Type: BoolProperty)
    void SET_IsPassThrough(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x14); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x14, B); } // 0x14:2 (Size: 0x1, Type: BoolProperty)
    void SET_LODBias(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_MipGenSettings(const TEnumAsByte<TextureMipGenSettings>& Value) { Write<TEnumAsByte<TextureMipGenSettings>>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: ByteProperty)
    void SET_LODGroup(const TEnumAsByte<TextureGroup>& Value) { Write<TEnumAsByte<TextureGroup>>(uintptr_t(this) + 0x1d, Value); } // 0x1d (Size: 0x1, Type: ByteProperty)
    void SET_AddressX(const TEnumAsByte<TextureAddress>& Value) { Write<TEnumAsByte<TextureAddress>>(uintptr_t(this) + 0x1e, Value); } // 0x1e (Size: 0x1, Type: ByteProperty)
    void SET_AddressY(const TEnumAsByte<TextureAddress>& Value) { Write<TEnumAsByte<TextureAddress>>(uintptr_t(this) + 0x1f, Value); } // 0x1f (Size: 0x1, Type: ByteProperty)
};

// Size: 0x58
struct FMutableRefSocket
{
public:
    FName SocketName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName BoneName() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    FVector RelativeLocation() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FRotator RelativeRotation() const { return Read<FRotator>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector RelativeScale() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    bool bForceAlwaysAnimated() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    int32_t Priority() const { return Read<int32_t>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: IntProperty)

    void SET_SocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_BoneName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_RelativeLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_RelativeRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_RelativeScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_bForceAlwaysAnimated(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_Priority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: IntProperty)
};

// Size: 0xc
struct FMutableRefLODInfo
{
public:
    float ScreenSize() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float LODHysteresis() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bSupportUniformlyDistributedSampling() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bAllowCPUAccess() const { return Read<bool>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: BoolProperty)

    void SET_ScreenSize(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_LODHysteresis(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_bSupportUniformlyDistributedSampling(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowCPUAccess(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x2
struct FMutableRefLODRenderData
{
public:
    bool bIsLODOptional() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bStreamedDataInlined() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)

    void SET_bIsLODOptional(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bStreamedDataInlined(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FMutableRefLODData
{
public:
    FMutableRefLODInfo LODInfo() const { return Read<FMutableRefLODInfo>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FMutableRefLODRenderData RenderData() const { return Read<FMutableRefLODRenderData>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x2, Type: StructProperty)

    void SET_LODInfo(const FMutableRefLODInfo& Value) { Write<FMutableRefLODInfo>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_RenderData(const FMutableRefLODRenderData& Value) { Write<FMutableRefLODRenderData>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x2, Type: StructProperty)
};

// Size: 0x8
struct FMutableRefSkeletalMeshSettings
{
public:
    bool bEnablePerPolyCollision() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float DefaultUVChannelDensity() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_bEnablePerPolyCollision(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_DefaultUVChannelDensity(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xd8
struct FMutableRefSkeletalMeshData
{
public:
    USkeletalMesh* SkeletalMesh() const { return Read<USkeletalMesh*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<USkeletalMesh> SoftSkeletalMesh() const { return Read<TSoftObjectPtr<USkeletalMesh>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    USkeletalMeshLODSettings* SkeletalMeshLODSettings() const { return Read<USkeletalMeshLODSettings*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    TArray<FMutableRefLODData> LODData() const { return Read<TArray<FMutableRefLODData>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FMutableRefSocket> Sockets() const { return Read<TArray<FMutableRefSocket>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    FBoxSphereBounds Bounds() const { return Read<FBoxSphereBounds>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x38, Type: StructProperty)
    FMutableRefSkeletalMeshSettings Settings() const { return Read<FMutableRefSkeletalMeshSettings>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: StructProperty)
    USkeleton* Skeleton() const { return Read<USkeleton*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    UPhysicsAsset* PhysicsAsset() const { return Read<UPhysicsAsset*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    UPhysicsAsset* ShadowPhysicsAsset() const { return Read<UPhysicsAsset*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    TArray<int32_t> AssetUserDataIndices() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)

    void SET_SkeletalMesh(const USkeletalMesh*& Value) { Write<USkeletalMesh*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_SoftSkeletalMesh(const TSoftObjectPtr<USkeletalMesh>& Value) { Write<TSoftObjectPtr<USkeletalMesh>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SkeletalMeshLODSettings(const USkeletalMeshLODSettings*& Value) { Write<USkeletalMeshLODSettings*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_LODData(const TArray<FMutableRefLODData>& Value) { Write<TArray<FMutableRefLODData>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_Sockets(const TArray<FMutableRefSocket>& Value) { Write<TArray<FMutableRefSocket>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_Bounds(const FBoxSphereBounds& Value) { Write<FBoxSphereBounds>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x38, Type: StructProperty)
    void SET_Settings(const FMutableRefSkeletalMeshSettings& Value) { Write<FMutableRefSkeletalMeshSettings>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: StructProperty)
    void SET_Skeleton(const USkeleton*& Value) { Write<USkeleton*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    void SET_PhysicsAsset(const UPhysicsAsset*& Value) { Write<UPhysicsAsset*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    void SET_ShadowPhysicsAsset(const UPhysicsAsset*& Value) { Write<UPhysicsAsset*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_AssetUserDataIndices(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x48
struct FAnimBpOverridePhysicsAssetsInfo
{
public:
    TSoftObjectPtr<UPhysicsAsset> SourceAsset() const { return Read<TSoftObjectPtr<UPhysicsAsset>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    int32_t PropertyIndex() const { return Read<int32_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: IntProperty)

    void SET_SourceAsset(const TSoftObjectPtr<UPhysicsAsset>& Value) { Write<TSoftObjectPtr<UPhysicsAsset>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    void SET_PropertyIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: IntProperty)
};

// Size: 0xc
struct FMutableSkinWeightProfileInfo
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    uint32_t NameId() const { return Read<uint32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: UInt32Property)
    bool DefaultProfile() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    int8_t DefaultProfileFromLODIndex() const { return Read<int8_t>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: Int8Property)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_NameId(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: UInt32Property)
    void SET_DefaultProfile(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_DefaultProfileFromLODIndex(const int8_t& Value) { Write<int8_t>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: Int8Property)
};

// Size: 0x10
struct FMutableStreamableBlock
{
public:
    uint32_t FileId() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)
    uint16_t Flags() const { return Read<uint16_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x2, Type: UInt16Property)
    uint64_t Offset() const { return Read<uint64_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: UInt64Property)

    void SET_FileId(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
    void SET_Flags(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x2, Type: UInt16Property)
    void SET_Offset(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: UInt64Property)
};

// Size: 0x28
struct FRealTimeMorphStreamable
{
public:
    TArray<FName> NameResolutionMap() const { return Read<TArray<FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    FMutableStreamableBlock bLock() const { return Read<FMutableStreamableBlock>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    uint32_t Size() const { return Read<uint32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: UInt32Property)
    uint32_t SourceId() const { return Read<uint32_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: UInt32Property)

    void SET_NameResolutionMap(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_bLock(const FMutableStreamableBlock& Value) { Write<FMutableStreamableBlock>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_Size(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: UInt32Property)
    void SET_SourceId(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: UInt32Property)
};

// Size: 0xc
struct FMutableMeshMetadata
{
public:
    uint32_t MorphMetadataId() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t ClothingMetadataId() const { return Read<uint32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: UInt32Property)
    uint32_t SurfaceMetadataId() const { return Read<uint32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: UInt32Property)

    void SET_MorphMetadataId(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
    void SET_ClothingMetadataId(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: UInt32Property)
    void SET_SurfaceMetadataId(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x8
struct FMutableSurfaceMetadata
{
public:
    FName MaterialSlotName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    bool bCastShadow() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)

    void SET_MaterialSlotName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_bCastShadow(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FClothingStreamable
{
public:
    int32_t ClothingAssetIndex() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t ClothingAssetLOD() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t PhysicsAssetIndex() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    uint32_t Size() const { return Read<uint32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: UInt32Property)
    FMutableStreamableBlock bLock() const { return Read<FMutableStreamableBlock>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    uint32_t SourceId() const { return Read<uint32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: UInt32Property)

    void SET_ClothingAssetIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_ClothingAssetLOD(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_PhysicsAssetIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_Size(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: UInt32Property)
    void SET_bLock(const FMutableStreamableBlock& Value) { Write<FMutableStreamableBlock>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_SourceId(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x1c
struct FMorphTargetVertexData
{
public:
    FVector3f PositionDelta() const { return Read<FVector3f>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FVector3f TangentZDelta() const { return Read<FVector3f>(uintptr_t(this) + 0xc); } // 0xc (Size: 0xc, Type: StructProperty)
    uint32_t MorphNameIndex() const { return Read<uint32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: UInt32Property)

    void SET_PositionDelta(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_TangentZDelta(const FVector3f& Value) { Write<FVector3f>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0xc, Type: StructProperty)
    void SET_MorphNameIndex(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x20
struct FIntegerParameterOptionKey
{
public:
    FString ParameterName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString ParameterOption() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_ParameterName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_ParameterOption(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x50
struct FIntegerParameterOptionDataTable
{
public:
    TSet<TSoftObjectPtr<UDataTable*>> DataTables() const { return Read<TSet<TSoftObjectPtr<UDataTable*>>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: SetProperty)

    void SET_DataTables(const TSet<TSoftObjectPtr<UDataTable*>>& Value) { Write<TSet<TSoftObjectPtr<UDataTable*>>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: SetProperty)
};

// Size: 0x110
struct FIntegerParameterUIData
{
public:
    FMutableParamUIMetadata ParamUIMetadata() const { return Read<FMutableParamUIMetadata>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x110, Type: StructProperty)

    void SET_ParamUIMetadata(const FMutableParamUIMetadata& Value) { Write<FMutableParamUIMetadata>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x110, Type: StructProperty)
};

// Size: 0xe8
struct FMutableUIMetadata
{
public:
    FString ObjectFriendlyName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString UISectionName() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t UIOrder() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)
    TSoftObjectPtr<UTexture2D> UIThumbnail() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
    TMap<FString, FString> ExtraInformation() const { return Read<TMap<FString, FString>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x50, Type: MapProperty)
    TMap<TSoftObjectPtr<UObject*>, FString> ExtraAssets() const { return Read<TMap<TSoftObjectPtr<UObject*>, FString>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x50, Type: MapProperty)

    void SET_ObjectFriendlyName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_UISectionName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_UIOrder(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
    void SET_UIThumbnail(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
    void SET_ExtraInformation(const TMap<FString, FString>& Value) { Write<TMap<FString, FString>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x50, Type: MapProperty)
    void SET_ExtraAssets(const TMap<TSoftObjectPtr<UObject*>, FString>& Value) { Write<TMap<TSoftObjectPtr<UObject*>, FString>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x50, Type: MapProperty)
};

// Size: 0x110
struct FMutableParamUIMetadata : public FMutableUIMetadata
{
public:
    float MinimumValue() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    float MaximumValue() const { return Read<float>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: FloatProperty)
    FGameplayTagContainer GameplayTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x20, Type: StructProperty)

    void SET_MinimumValue(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    void SET_MaximumValue(const float& Value) { Write<float>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: FloatProperty)
    void SET_GameplayTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x170
struct FMutableParameterData
{
public:
    FMutableParamUIMetadata ParamUIMetadata() const { return Read<FMutableParamUIMetadata>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x110, Type: StructProperty)
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x1, Type: EnumProperty)
    TMap<FIntegerParameterUIData, FString> ArrayIntegerParameterOption() const { return Read<TMap<FIntegerParameterUIData, FString>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x50, Type: MapProperty)
    uint8_t IntegerParameterGroupType() const { return Read<uint8_t>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x1, Type: EnumProperty)

    void SET_ParamUIMetadata(const FMutableParamUIMetadata& Value) { Write<FMutableParamUIMetadata>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x110, Type: StructProperty)
    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x1, Type: EnumProperty)
    void SET_ArrayIntegerParameterOption(const TMap<FIntegerParameterUIData, FString>& Value) { Write<TMap<FIntegerParameterUIData, FString>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x50, Type: MapProperty)
    void SET_IntegerParameterGroupType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x140
struct FMutableStateData
{
public:
    FMutableStateUIMetadata StateUIMetadata() const { return Read<FMutableStateUIMetadata>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xe8, Type: StructProperty)
    bool bLiveUpdateMode() const { return Read<bool>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: BoolProperty)
    bool bDisableTextureStreaming() const { return Read<bool>(uintptr_t(this) + 0xe9); } // 0xe9 (Size: 0x1, Type: BoolProperty)
    bool bReuseInstanceTextures() const { return Read<bool>(uintptr_t(this) + 0xea); } // 0xea (Size: 0x1, Type: BoolProperty)
    TMap<FString, FString> ForcedParameterValues() const { return Read<TMap<FString, FString>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x50, Type: MapProperty)

    void SET_StateUIMetadata(const FMutableStateUIMetadata& Value) { Write<FMutableStateUIMetadata>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xe8, Type: StructProperty)
    void SET_bLiveUpdateMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: BoolProperty)
    void SET_bDisableTextureStreaming(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe9, Value); } // 0xe9 (Size: 0x1, Type: BoolProperty)
    void SET_bReuseInstanceTextures(const bool& Value) { Write<bool>(uintptr_t(this) + 0xea, Value); } // 0xea (Size: 0x1, Type: BoolProperty)
    void SET_ForcedParameterValues(const TMap<FString, FString>& Value) { Write<TMap<FString, FString>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x50, Type: MapProperty)
};

// Size: 0xe8
struct FMutableStateUIMetadata : public FMutableUIMetadata
{
public:
};

// Size: 0x50
struct FMutableParamNameSet
{
public:
};

// Size: 0x10
struct FMutableMeshComponentData
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    USkeletalMesh* ReferenceSkeletalMesh() const { return Read<USkeletalMesh*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_ReferenceSkeletalMesh(const USkeletalMesh*& Value) { Write<USkeletalMesh*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4
struct FCustomizableObjectComponentIndex
{
public:
};

// Size: 0x18
struct FCustomizableObjectResourceData
{
public:
    FInstancedStruct Data() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)

    void SET_Data(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x8
struct FCustomizableObjectAssetUserData
{
public:
    UAssetUserData* AssetUserData() const { return Read<UAssetUserData*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_AssetUserData(const UAssetUserData*& Value) { Write<UAssetUserData*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FGeneratedTexture
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    UTexture* Texture() const { return Read<UTexture*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_Texture(const UTexture*& Value) { Write<UTexture*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x20
struct FGeneratedMaterial
{
public:
    UMaterialInterface* MaterialInterface() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<FGeneratedTexture> Textures() const { return Read<TArray<FGeneratedTexture>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_MaterialInterface(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Textures(const TArray<FGeneratedTexture>& Value) { Write<TArray<FGeneratedTexture>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FPendingReleaseSkeletalMeshInfo
{
public:
    USkeletalMesh* SkeletalMesh() const { return Read<USkeletalMesh*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    double Timestamp() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)

    void SET_SkeletalMesh(const USkeletalMesh*& Value) { Write<USkeletalMesh*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Timestamp(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x20
struct FCompilationOptions_DEPRECATED
{
public:
    uint8_t TextureCompression() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    int32_t OptimizationLevel() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    bool bUseDiskCompilation() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    uint64_t PackagedDataBytesLimit() const { return Read<uint64_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: UInt64Property)
    uint64_t EmbeddedDataBytesLimit() const { return Read<uint64_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: UInt64Property)

    void SET_TextureCompression(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_OptimizationLevel(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_bUseDiskCompilation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_PackagedDataBytesLimit(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: UInt64Property)
    void SET_EmbeddedDataBytesLimit(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: UInt64Property)
};

// Size: 0x10
struct FFParameterOptionsTags
{
public:
    TArray<FString> Tags() const { return Read<TArray<FString>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Tags(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x60
struct FParameterTags
{
public:
    TArray<FString> Tags() const { return Read<TArray<FString>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TMap<FFParameterOptionsTags, FString> ParameterOptions() const { return Read<TMap<FFParameterOptionsTags, FString>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x50, Type: MapProperty)

    void SET_Tags(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_ParameterOptions(const TMap<FFParameterOptionsTags, FString>& Value) { Write<TMap<FFParameterOptionsTags, FString>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x50, Type: MapProperty)
};

// Size: 0x90
struct FProfileParameterDat
{
public:
    FString ProfileName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    TArray<FCustomizableObjectBoolParameterValue> BoolParameters() const { return Read<TArray<FCustomizableObjectBoolParameterValue>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectIntParameterValue> IntParameters() const { return Read<TArray<FCustomizableObjectIntParameterValue>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectFloatParameterValue> FloatParameters() const { return Read<TArray<FCustomizableObjectFloatParameterValue>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectAssetParameterValue> TextureParameters() const { return Read<TArray<FCustomizableObjectAssetParameterValue>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectAssetParameterValue> MeshParameters() const { return Read<TArray<FCustomizableObjectAssetParameterValue>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectVectorParameterValue> VectorParameters() const { return Read<TArray<FCustomizableObjectVectorParameterValue>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectProjectorParameterValue> ProjectorParameters() const { return Read<TArray<FCustomizableObjectProjectorParameterValue>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectTransformParameterValue> TransformParameters() const { return Read<TArray<FCustomizableObjectTransformParameterValue>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)

    void SET_ProfileName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_BoolParameters(const TArray<FCustomizableObjectBoolParameterValue>& Value) { Write<TArray<FCustomizableObjectBoolParameterValue>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_IntParameters(const TArray<FCustomizableObjectIntParameterValue>& Value) { Write<TArray<FCustomizableObjectIntParameterValue>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_FloatParameters(const TArray<FCustomizableObjectFloatParameterValue>& Value) { Write<TArray<FCustomizableObjectFloatParameterValue>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_TextureParameters(const TArray<FCustomizableObjectAssetParameterValue>& Value) { Write<TArray<FCustomizableObjectAssetParameterValue>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_MeshParameters(const TArray<FCustomizableObjectAssetParameterValue>& Value) { Write<TArray<FCustomizableObjectAssetParameterValue>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_VectorParameters(const TArray<FCustomizableObjectVectorParameterValue>& Value) { Write<TArray<FCustomizableObjectVectorParameterValue>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_ProjectorParameters(const TArray<FCustomizableObjectProjectorParameterValue>& Value) { Write<TArray<FCustomizableObjectProjectorParameterValue>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_TransformParameters(const TArray<FCustomizableObjectTransformParameterValue>& Value) { Write<TArray<FCustomizableObjectTransformParameterValue>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x70
struct FMutableLODSettings
{
public:
    FPerPlatformInt MinLOD() const { return Read<FPerPlatformInt>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FPerQualityLevelInt MinQualityLevelLOD() const { return Read<FPerQualityLevelInt>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x68, Type: StructProperty)

    void SET_MinLOD(const FPerPlatformInt& Value) { Write<FPerPlatformInt>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_MinQualityLevelLOD(const FPerQualityLevelInt& Value) { Write<FPerQualityLevelInt>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x68, Type: StructProperty)
};

// Size: 0x30
struct FCompileParams
{
public:
    bool bSkipIfCompiled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bSkipIfOutOfDate() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bGatherReferneces() const { return Read<bool>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bAsync() const { return Read<bool>(uintptr_t(this) + 0x3); } // 0x3 (Size: 0x1, Type: BoolProperty)
    UCustomizableObjectInstance* CompileOnlySelectedInstance() const { return Read<UCustomizableObjectInstance*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    uint8_t OptimizationLevel() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t TextureCompression() const { return Read<uint8_t>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: EnumProperty)

    void SET_bSkipIfCompiled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bSkipIfOutOfDate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_bGatherReferneces(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: BoolProperty)
    void SET_bAsync(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3, Value); } // 0x3 (Size: 0x1, Type: BoolProperty)
    void SET_CompileOnlySelectedInstance(const UCustomizableObjectInstance*& Value) { Write<UCustomizableObjectInstance*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_OptimizationLevel(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_TextureCompression(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x20
struct FCustomizableObjectIdPair
{
public:
    FString CustomizableObjectGroupName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString CustomizableObjectName() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_CustomizableObjectGroupName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_CustomizableObjectName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x30
struct FBakingConfiguration
{
public:
    FString OutputPath() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString OutputFilesBaseName() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    bool bExportAllResourcesOnBake() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    bool bGenerateConstantMaterialInstancesOnBake() const { return Read<bool>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: BoolProperty)
    bool bAllowOverridingOfFiles() const { return Read<bool>(uintptr_t(this) + 0x22); } // 0x22 (Size: 0x1, Type: BoolProperty)

    void SET_OutputPath(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_OutputFilesBaseName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_bExportAllResourcesOnBake(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_bGenerateConstantMaterialInstancesOnBake(const bool& Value) { Write<bool>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowOverridingOfFiles(const bool& Value) { Write<bool>(uintptr_t(this) + 0x22, Value); } // 0x22 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x180
struct FCustomizableObjectInstanceDescriptor
{
public:
    UCustomizableObject* CustomizableObject() const { return Read<UCustomizableObject*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<FCustomizableObjectBoolParameterValue> BoolParameters() const { return Read<TArray<FCustomizableObjectBoolParameterValue>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectIntParameterValue> IntParameters() const { return Read<TArray<FCustomizableObjectIntParameterValue>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectFloatParameterValue> FloatParameters() const { return Read<TArray<FCustomizableObjectFloatParameterValue>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectAssetParameterValue> TextureParameters() const { return Read<TArray<FCustomizableObjectAssetParameterValue>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectAssetParameterValue> MeshParameters() const { return Read<TArray<FCustomizableObjectAssetParameterValue>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectVectorParameterValue> VectorParameters() const { return Read<TArray<FCustomizableObjectVectorParameterValue>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectProjectorParameterValue> ProjectorParameters() const { return Read<TArray<FCustomizableObjectProjectorParameterValue>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomizableObjectTransformParameterValue> TransformParameters() const { return Read<TArray<FCustomizableObjectTransformParameterValue>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    int32_t State() const { return Read<int32_t>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: IntProperty)

    void SET_CustomizableObject(const UCustomizableObject*& Value) { Write<UCustomizableObject*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_BoolParameters(const TArray<FCustomizableObjectBoolParameterValue>& Value) { Write<TArray<FCustomizableObjectBoolParameterValue>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_IntParameters(const TArray<FCustomizableObjectIntParameterValue>& Value) { Write<TArray<FCustomizableObjectIntParameterValue>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_FloatParameters(const TArray<FCustomizableObjectFloatParameterValue>& Value) { Write<TArray<FCustomizableObjectFloatParameterValue>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_TextureParameters(const TArray<FCustomizableObjectAssetParameterValue>& Value) { Write<TArray<FCustomizableObjectAssetParameterValue>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_MeshParameters(const TArray<FCustomizableObjectAssetParameterValue>& Value) { Write<TArray<FCustomizableObjectAssetParameterValue>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_VectorParameters(const TArray<FCustomizableObjectVectorParameterValue>& Value) { Write<TArray<FCustomizableObjectVectorParameterValue>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_ProjectorParameters(const TArray<FCustomizableObjectProjectorParameterValue>& Value) { Write<TArray<FCustomizableObjectProjectorParameterValue>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_TransformParameters(const TArray<FCustomizableObjectTransformParameterValue>& Value) { Write<TArray<FCustomizableObjectTransformParameterValue>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    void SET_State(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: IntProperty)
};

// Size: 0x28
struct FCustomizableObjectStreamedResourceData
{
public:
    TSoftObjectPtr<UCustomizableObjectResourceDataContainer> ContainerPath() const { return Read<TSoftObjectPtr<UCustomizableObjectResourceDataContainer>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    UCustomizableObjectResourceDataContainer* Container() const { return Read<UCustomizableObjectResourceDataContainer*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)

    void SET_ContainerPath(const TSoftObjectPtr<UCustomizableObjectResourceDataContainer>& Value) { Write<TSoftObjectPtr<UCustomizableObjectResourceDataContainer>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Container(const UCustomizableObjectResourceDataContainer*& Value) { Write<UCustomizableObjectResourceDataContainer*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x18
struct FPendingReleaseMaterialsInfo
{
public:
    TArray<UMaterialInterface*> Materials() const { return Read<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t TicksUntilRelease() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_Materials(const TArray<UMaterialInterface*>& Value) { Write<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_TicksUntilRelease(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x80
struct FMultilayerProjectorLayer
{
public:
};

