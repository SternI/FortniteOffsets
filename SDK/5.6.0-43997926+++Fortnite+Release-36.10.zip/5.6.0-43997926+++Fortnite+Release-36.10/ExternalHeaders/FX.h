/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FX
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"

// Size: 0x3e
class UAnimNotify_Irwin_Footfalls_C : public UAnimNotify
{
public:
    int32_t FootfallsIndex() const { return Read<int32_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: IntProperty)
    bool is_Running__() const { return Read<bool>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x1, Type: BoolProperty)
    bool is_Sprinting__() const { return Read<bool>(uintptr_t(this) + 0x3d); } // 0x3d (Size: 0x1, Type: BoolProperty)

    void SET_FootfallsIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: IntProperty)
    void SET_is_Running__(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x1, Type: BoolProperty)
    void SET_is_Sprinting__(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3d, Value); } // 0x3d (Size: 0x1, Type: BoolProperty)
};

