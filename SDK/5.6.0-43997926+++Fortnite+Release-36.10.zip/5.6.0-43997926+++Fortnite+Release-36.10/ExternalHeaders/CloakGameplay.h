/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CloakGameplay
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "GameplayAbilities.h"

// Size: 0xa40
class AFortGameCueNotifyLoop_Cloak : public AFortGameplayCueNotify_Loop
{
public:
    AFortPlayerPawn* TargetPlayer() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: ObjectProperty)
    float VisibilityLevel() const { return Read<float>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x4, Type: FloatProperty)
    float StationaryVisMult() const { return Read<float>(uintptr_t(this) + 0x9d4); } // 0x9d4 (Size: 0x4, Type: FloatProperty)
    float MaxSpeedVisMult() const { return Read<float>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x4, Type: FloatProperty)
    float SpeedForMaxVis() const { return Read<float>(uintptr_t(this) + 0x9dc); } // 0x9dc (Size: 0x4, Type: FloatProperty)
    float VisibilityMinFriendly() const { return Read<float>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x4, Type: FloatProperty)
    float VisibilityMinNonfriendly() const { return Read<float>(uintptr_t(this) + 0x9e4); } // 0x9e4 (Size: 0x4, Type: FloatProperty)
    float VisibilityLevelChangeRate() const { return Read<float>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x4, Type: FloatProperty)
    TMap<FFortGameCueCloakModifier, FName> CloakModifiersByNameMap() const { return Read<TMap<FFortGameCueCloakModifier, FName>>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x50, Type: MapProperty)

    void SET_TargetPlayer(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: ObjectProperty)
    void SET_VisibilityLevel(const float& Value) { Write<float>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x4, Type: FloatProperty)
    void SET_StationaryVisMult(const float& Value) { Write<float>(uintptr_t(this) + 0x9d4, Value); } // 0x9d4 (Size: 0x4, Type: FloatProperty)
    void SET_MaxSpeedVisMult(const float& Value) { Write<float>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x4, Type: FloatProperty)
    void SET_SpeedForMaxVis(const float& Value) { Write<float>(uintptr_t(this) + 0x9dc, Value); } // 0x9dc (Size: 0x4, Type: FloatProperty)
    void SET_VisibilityMinFriendly(const float& Value) { Write<float>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x4, Type: FloatProperty)
    void SET_VisibilityMinNonfriendly(const float& Value) { Write<float>(uintptr_t(this) + 0x9e4, Value); } // 0x9e4 (Size: 0x4, Type: FloatProperty)
    void SET_VisibilityLevelChangeRate(const float& Value) { Write<float>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x4, Type: FloatProperty)
    void SET_CloakModifiersByNameMap(const TMap<FFortGameCueCloakModifier, FName>& Value) { Write<TMap<FFortGameCueCloakModifier, FName>>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x50, Type: MapProperty)
};

// Size: 0xd0
struct FFortGameCueCloakModifier
{
public:
    FScalableFloat bCanBeEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x28, Type: StructProperty)
    FScalableFloat VisibilityModifierMultiplicative() const { return Read<FScalableFloat>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x28, Type: StructProperty)
    FScalableFloat VisibilityModifierAdditive() const { return Read<FScalableFloat>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x28, Type: StructProperty)
    FScalableFloat AlphaTimeToEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x28, Type: StructProperty)
    FScalableFloat AlphaTimeToDisabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x28, Type: StructProperty)
    bool bCurrentlyEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0xc8) >> 0x0) & 1; } // 0xc8:0 (Size: 0x1, Type: BoolProperty)
    float CurrentAlpha() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)

    void SET_bCanBeEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x28, Type: StructProperty)
    void SET_VisibilityModifierMultiplicative(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x28, Type: StructProperty)
    void SET_VisibilityModifierAdditive(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x28, Type: StructProperty)
    void SET_AlphaTimeToEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x28, Type: StructProperty)
    void SET_AlphaTimeToDisabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x28, Type: StructProperty)
    void SET_bCurrentlyEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xc8, B); } // 0xc8:0 (Size: 0x1, Type: BoolProperty)
    void SET_CurrentAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
};

