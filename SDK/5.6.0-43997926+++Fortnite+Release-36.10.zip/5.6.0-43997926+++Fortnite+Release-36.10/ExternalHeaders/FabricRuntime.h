/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "FabricFramework.h"
#include "Niagara.h"
#include "HarmonixMidi.h"
#include "MetasoundFrontend.h"
#include "Engine.h"
#include "FabricUI.h"
#include "PlayspaceSystem.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "EnhancedInput.h"
#include "HarmonixMetasound.h"
#include "FortniteGame.h"
#include "GameplayMessages.h"
#include "MetasoundEngine.h"
#include "FabricMetasoundDataTypes.h"
#include "HarmonixDsp.h"
#include "GameplayAbilities.h"
#include "TargetingSystem.h"

// Size: 0x28
class UFabricAnimatableButtonInterface : public UInterface
{
public:
};

// Size: 0x100
class UFabricAudioBridgeComponent : public UActorComponent
{
public:
    UClass* FabricAudioPatchWrapperClass() const { return Read<UClass*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ClassProperty)
    UFabricMetaSoundAudioPatchWrapper* FabricAudioPatchWrapperInstance() const { return Read<UFabricMetaSoundAudioPatchWrapper*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UFabricMetaSoundManagerComponent*> FabricMetasoundManager() const { return Read<TWeakObjectPtr<UFabricMetaSoundManagerComponent*>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_FabricAudioPatchWrapperClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ClassProperty)
    void SET_FabricAudioPatchWrapperInstance(const UFabricMetaSoundAudioPatchWrapper*& Value) { Write<UFabricMetaSoundAudioPatchWrapper*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_FabricMetasoundManager(const TWeakObjectPtr<UFabricMetaSoundManagerComponent*>& Value) { Write<TWeakObjectPtr<UFabricMetaSoundManagerComponent*>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x350
class AFabricButtonBase : public AActor
{
public:
    double OpenTimeSeconds() const { return Read<double>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: DoubleProperty)
    double CloseTimeSeconds() const { return Read<double>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: DoubleProperty)
    bool bHasToggle() const { return Read<bool>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EButtonPressMethod> ClickMethod() const { return Read<TEnumAsByte<EButtonPressMethod>>(uintptr_t(this) + 0x2e1); } // 0x2e1 (Size: 0x1, Type: ByteProperty)
    APlayerController* InteractingController() const { return Read<APlayerController*>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    FString ButtonId() const { return Read<FString>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x10, Type: StrProperty)
    FText ButtonLabel() const { return Read<FText>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x10, Type: TextProperty)
    FText ButtonDescription() const { return Read<FText>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x10, Type: TextProperty)
    FGameplayTagContainer GameplayTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x20, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x1, Type: BoolProperty)
    bool bHovered() const { return Read<bool>(uintptr_t(this) + 0x341); } // 0x341 (Size: 0x1, Type: BoolProperty)
    bool bPressed() const { return Read<bool>(uintptr_t(this) + 0x342); } // 0x342 (Size: 0x1, Type: BoolProperty)
    uint8_t ToggleState() const { return Read<uint8_t>(uintptr_t(this) + 0x343); } // 0x343 (Size: 0x1, Type: EnumProperty)
    UFabricInteractableViewModel* WidgetViewModel() const { return Read<UFabricInteractableViewModel*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)

    void SET_OpenTimeSeconds(const double& Value) { Write<double>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: DoubleProperty)
    void SET_CloseTimeSeconds(const double& Value) { Write<double>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: DoubleProperty)
    void SET_bHasToggle(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x1, Type: BoolProperty)
    void SET_ClickMethod(const TEnumAsByte<EButtonPressMethod>& Value) { Write<TEnumAsByte<EButtonPressMethod>>(uintptr_t(this) + 0x2e1, Value); } // 0x2e1 (Size: 0x1, Type: ByteProperty)
    void SET_InteractingController(const APlayerController*& Value) { Write<APlayerController*>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    void SET_ButtonId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x10, Type: StrProperty)
    void SET_ButtonLabel(const FText& Value) { Write<FText>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x10, Type: TextProperty)
    void SET_ButtonDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x10, Type: TextProperty)
    void SET_GameplayTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x20, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x1, Type: BoolProperty)
    void SET_bHovered(const bool& Value) { Write<bool>(uintptr_t(this) + 0x341, Value); } // 0x341 (Size: 0x1, Type: BoolProperty)
    void SET_bPressed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x342, Value); } // 0x342 (Size: 0x1, Type: BoolProperty)
    void SET_ToggleState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x343, Value); } // 0x343 (Size: 0x1, Type: EnumProperty)
    void SET_WidgetViewModel(const UFabricInteractableViewModel*& Value) { Write<UFabricInteractableViewModel*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x6c0
class UFabricButtonComponentBase : public UStaticMeshComponent
{
public:
    double OpenTimeSeconds() const { return Read<double>(uintptr_t(this) + 0x628); } // 0x628 (Size: 0x8, Type: DoubleProperty)
    double CloseTimeSeconds() const { return Read<double>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0x8, Type: DoubleProperty)
    bool bHasToggle() const { return Read<bool>(uintptr_t(this) + 0x638); } // 0x638 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EButtonPressMethod> ClickMethod() const { return Read<TEnumAsByte<EButtonPressMethod>>(uintptr_t(this) + 0x639); } // 0x639 (Size: 0x1, Type: ByteProperty)
    APlayerController* InteractingController() const { return Read<APlayerController*>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    FString ButtonId() const { return Read<FString>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x10, Type: StrProperty)
    FText ButtonLabel() const { return Read<FText>(uintptr_t(this) + 0x658); } // 0x658 (Size: 0x10, Type: TextProperty)
    FText ButtonDescription() const { return Read<FText>(uintptr_t(this) + 0x668); } // 0x668 (Size: 0x10, Type: TextProperty)
    FGameplayTagContainer GameplayTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x678); } // 0x678 (Size: 0x20, Type: StructProperty)
    bool bUseScreenGrid() const { return Read<bool>(uintptr_t(this) + 0x698); } // 0x698 (Size: 0x1, Type: BoolProperty)
    FVector2D ScreenGridPosition() const { return Read<FVector2D>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x10, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x6b0); } // 0x6b0 (Size: 0x1, Type: BoolProperty)
    bool bHovered() const { return Read<bool>(uintptr_t(this) + 0x6b1); } // 0x6b1 (Size: 0x1, Type: BoolProperty)
    bool bPressed() const { return Read<bool>(uintptr_t(this) + 0x6b2); } // 0x6b2 (Size: 0x1, Type: BoolProperty)
    uint8_t ToggleState() const { return Read<uint8_t>(uintptr_t(this) + 0x6b3); } // 0x6b3 (Size: 0x1, Type: EnumProperty)
    UFabricInteractableViewModel* WidgetViewModel() const { return Read<UFabricInteractableViewModel*>(uintptr_t(this) + 0x6b8); } // 0x6b8 (Size: 0x8, Type: ObjectProperty)

    void SET_OpenTimeSeconds(const double& Value) { Write<double>(uintptr_t(this) + 0x628, Value); } // 0x628 (Size: 0x8, Type: DoubleProperty)
    void SET_CloseTimeSeconds(const double& Value) { Write<double>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0x8, Type: DoubleProperty)
    void SET_bHasToggle(const bool& Value) { Write<bool>(uintptr_t(this) + 0x638, Value); } // 0x638 (Size: 0x1, Type: BoolProperty)
    void SET_ClickMethod(const TEnumAsByte<EButtonPressMethod>& Value) { Write<TEnumAsByte<EButtonPressMethod>>(uintptr_t(this) + 0x639, Value); } // 0x639 (Size: 0x1, Type: ByteProperty)
    void SET_InteractingController(const APlayerController*& Value) { Write<APlayerController*>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    void SET_ButtonId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x10, Type: StrProperty)
    void SET_ButtonLabel(const FText& Value) { Write<FText>(uintptr_t(this) + 0x658, Value); } // 0x658 (Size: 0x10, Type: TextProperty)
    void SET_ButtonDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x668, Value); } // 0x668 (Size: 0x10, Type: TextProperty)
    void SET_GameplayTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x678, Value); } // 0x678 (Size: 0x20, Type: StructProperty)
    void SET_bUseScreenGrid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x698, Value); } // 0x698 (Size: 0x1, Type: BoolProperty)
    void SET_ScreenGridPosition(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x10, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6b0, Value); } // 0x6b0 (Size: 0x1, Type: BoolProperty)
    void SET_bHovered(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6b1, Value); } // 0x6b1 (Size: 0x1, Type: BoolProperty)
    void SET_bPressed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6b2, Value); } // 0x6b2 (Size: 0x1, Type: BoolProperty)
    void SET_ToggleState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x6b3, Value); } // 0x6b3 (Size: 0x1, Type: EnumProperty)
    void SET_WidgetViewModel(const UFabricInteractableViewModel*& Value) { Write<UFabricInteractableViewModel*>(uintptr_t(this) + 0x6b8, Value); } // 0x6b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x150
class UFabricDeviceCustomInteractionManager : public UFMPlayerMonitorComponent
{
public:
    UClass* CustomInteractionComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x8, Type: ClassProperty)

    void SET_CustomInteractionComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x28
class UFabricDevice : public UInterface
{
public:
};

// Size: 0x28
class UFabricMetaSoundPatchOwner : public UInterface
{
public:
};

// Size: 0x28
class UFabricAudioGenerator : public UInterface
{
public:
};

// Size: 0x28
class UFabricAudioModifier : public UInterface
{
public:
};

// Size: 0x28
class UFabricAudioReceiver : public UInterface
{
public:
};

// Size: 0x28
class UFabricFloatGenerator : public UInterface
{
public:
};

// Size: 0x28
class UFabricFloatReceiver : public UInterface
{
public:
};

// Size: 0x28
class UFabricTextureGenerator : public UInterface
{
public:
};

// Size: 0x28
class UFabricTextureModifier : public UInterface
{
public:
};

// Size: 0x28
class UFabricTextureReceiver : public UInterface
{
public:
};

// Size: 0x28
class UFabricMeshGenerator : public UInterface
{
public:
};

// Size: 0x28
class UFabricMeshModifier : public UInterface
{
public:
};

// Size: 0x28
class UFabricMeshReceiver : public UInterface
{
public:
};

// Size: 0x48
class UFabricModulationNode : public UObject
{
public:
    TArray<UFabricFloatProviderBase*> FloatProviders() const { return Read<TArray<UFabricFloatProviderBase*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_FloatProviders(const TArray<UFabricFloatProviderBase*>& Value) { Write<TArray<UFabricFloatProviderBase*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x390
class UFabricFloatProviderBase : public UFabricModulatable
{
public:
    float CurrentFloat() const { return Read<float>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UMusicClockComponent*> MusicClock() const { return Read<TWeakObjectPtr<UMusicClockComponent*>>(uintptr_t(this) + 0x364); } // 0x364 (Size: 0x8, Type: WeakObjectProperty)
    UFabricMetaSoundModulatorPatchWrapper* AssociatedPatchWrapper() const { return Read<UFabricMetaSoundModulatorPatchWrapper*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    FString EnabledParam() const { return Read<FString>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x10, Type: StrProperty)
    bool bAlwaysModulates() const { return Read<bool>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x1, Type: BoolProperty)
    bool bBindBlueprintOnFloatChanged() const { return Read<bool>(uintptr_t(this) + 0x389); } // 0x389 (Size: 0x1, Type: BoolProperty)
    bool bIsEnabled() const { return Read<bool>(uintptr_t(this) + 0x38a); } // 0x38a (Size: 0x1, Type: BoolProperty)
    bool bModulatorValueChanged() const { return Read<bool>(uintptr_t(this) + 0x38b); } // 0x38b (Size: 0x1, Type: BoolProperty)

    void SET_CurrentFloat(const float& Value) { Write<float>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x4, Type: FloatProperty)
    void SET_MusicClock(const TWeakObjectPtr<UMusicClockComponent*>& Value) { Write<TWeakObjectPtr<UMusicClockComponent*>>(uintptr_t(this) + 0x364, Value); } // 0x364 (Size: 0x8, Type: WeakObjectProperty)
    void SET_AssociatedPatchWrapper(const UFabricMetaSoundModulatorPatchWrapper*& Value) { Write<UFabricMetaSoundModulatorPatchWrapper*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_EnabledParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x10, Type: StrProperty)
    void SET_bAlwaysModulates(const bool& Value) { Write<bool>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x1, Type: BoolProperty)
    void SET_bBindBlueprintOnFloatChanged(const bool& Value) { Write<bool>(uintptr_t(this) + 0x389, Value); } // 0x389 (Size: 0x1, Type: BoolProperty)
    void SET_bIsEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38a, Value); } // 0x38a (Size: 0x1, Type: BoolProperty)
    void SET_bModulatorValueChanged(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38b, Value); } // 0x38b (Size: 0x1, Type: BoolProperty)
};

// Size: 0x328
class UFabricModulatable : public UObject
{
public:
    TWeakObjectPtr<AActor*> ModulatedActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x8, Type: WeakObjectProperty)
    TArray<FString> ModulatorParams() const { return Read<TArray<FString>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TSet<FName> NonModulatedParamsWithCallbacks() const { return Read<TSet<FName>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x50, Type: SetProperty)
    TMap<TWeakObjectPtr<UObject*>, FString> Modulators() const { return Read<TMap<TWeakObjectPtr<UObject*>, FString>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x50, Type: MapProperty)
    TMap<FName, FName> LastBroadcastedValues() const { return Read<TMap<FName, FName>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x50, Type: MapProperty)
    TArray<TWeakObjectPtr<UObject*>> ModulatorSources() const { return Read<TArray<TWeakObjectPtr<UObject*>>>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x10, Type: ArrayProperty)

    void SET_ModulatedActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x8, Type: WeakObjectProperty)
    void SET_ModulatorParams(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_NonModulatedParamsWithCallbacks(const TSet<FName>& Value) { Write<TSet<FName>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x50, Type: SetProperty)
    void SET_Modulators(const TMap<TWeakObjectPtr<UObject*>, FString>& Value) { Write<TMap<TWeakObjectPtr<UObject*>, FString>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x50, Type: MapProperty)
    void SET_LastBroadcastedValues(const TMap<FName, FName>& Value) { Write<TMap<FName, FName>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x50, Type: MapProperty)
    void SET_ModulatorSources(const TArray<TWeakObjectPtr<UObject*>>& Value) { Write<TArray<TWeakObjectPtr<UObject*>>>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x4e8
class UFabricFloatProviderWave : public UFabricFloatProviderBase
{
public:
    FString WaveShapeParam() const { return Read<FString>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x10, Type: StrProperty)
    FString FreeHzParam() const { return Read<FString>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x10, Type: StrProperty)
    FString MinParam() const { return Read<FString>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x10, Type: StrProperty)
    FString MaxParam() const { return Read<FString>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x10, Type: StrProperty)
    FString BeatDurationParam() const { return Read<FString>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x10, Type: StrProperty)
    FString BeatOffsetParam() const { return Read<FString>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x10, Type: StrProperty)
    FString ShapeParam() const { return Read<FString>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x10, Type: StrProperty)
    FString StyleParam() const { return Read<FString>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x10, Type: StrProperty)
    int32_t PhaseCPDIndex() const { return Read<int32_t>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x4, Type: IntProperty)
    int32_t ValueCPDIndex() const { return Read<int32_t>(uintptr_t(this) + 0x414); } // 0x414 (Size: 0x4, Type: IntProperty)
    TSet<TWeakObjectPtr<UStaticMeshComponent*>> PreviewDisplayMeshes() const { return Read<TSet<TWeakObjectPtr<UStaticMeshComponent*>>>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x50, Type: SetProperty)

    void SET_WaveShapeParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x10, Type: StrProperty)
    void SET_FreeHzParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x10, Type: StrProperty)
    void SET_MinParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x10, Type: StrProperty)
    void SET_MaxParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x10, Type: StrProperty)
    void SET_BeatDurationParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x10, Type: StrProperty)
    void SET_BeatOffsetParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x10, Type: StrProperty)
    void SET_ShapeParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x10, Type: StrProperty)
    void SET_StyleParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x10, Type: StrProperty)
    void SET_PhaseCPDIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x4, Type: IntProperty)
    void SET_ValueCPDIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x414, Value); } // 0x414 (Size: 0x4, Type: IntProperty)
    void SET_PreviewDisplayMeshes(const TSet<TWeakObjectPtr<UStaticMeshComponent*>>& Value) { Write<TSet<TWeakObjectPtr<UStaticMeshComponent*>>>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x50, Type: SetProperty)
};

// Size: 0x418
class UFabricFloatProviderStep : public UFabricFloatProviderBase
{
public:
    FString StepRateParam() const { return Read<FString>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x10, Type: StrProperty)
    FString ActiveStepsParam() const { return Read<FString>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x10, Type: StrProperty)
    FString StepParamBase() const { return Read<FString>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x10, Type: StrProperty)
    int32_t MaxSteps() const { return Read<int32_t>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x4, Type: IntProperty)
    FFabricStepGenerator RuntimeGenerator() const { return Read<FFabricStepGenerator>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x20, Type: StructProperty)

    void SET_StepRateParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x10, Type: StrProperty)
    void SET_ActiveStepsParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x10, Type: StrProperty)
    void SET_StepParamBase(const FString& Value) { Write<FString>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x10, Type: StrProperty)
    void SET_MaxSteps(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x4, Type: IntProperty)
    void SET_RuntimeGenerator(const FFabricStepGenerator& Value) { Write<FFabricStepGenerator>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x20, Type: StructProperty)
};

// Size: 0x430
class UFabricFloatProviderValueSetter : public UFabricFloatProviderBase
{
public:
    FString ValueParam() const { return Read<FString>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x10, Type: StrProperty)
    FString TransitionTimingParam() const { return Read<FString>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x10, Type: StrProperty)
    FString BlendParam() const { return Read<FString>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x10, Type: StrProperty)

    void SET_ValueParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x10, Type: StrProperty)
    void SET_TransitionTimingParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x10, Type: StrProperty)
    void SET_BlendParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x28
class UFabricHoldable : public UInterface
{
public:
};

// Size: 0x138
class UFabricIndicatorComponent : public UGameFrameworkComponent
{
public:
    UClass* FabricTooltipWidgetType() const { return Read<UClass*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ClassProperty)
    FGameplayTag TargetsChangedTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer HUDTagsToHide() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x20, Type: StructProperty)
    UFortInputMappingContext* IndicatorShowingInputContext() const { return Read<UFortInputMappingContext*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    int32_t IndicatorShowingPriority() const { return Read<int32_t>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: IntProperty)
    UInputAction* ShowMoreAction() const { return Read<UInputAction*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ObjectProperty)

    void SET_FabricTooltipWidgetType(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ClassProperty)
    void SET_TargetsChangedTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: StructProperty)
    void SET_HUDTagsToHide(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x20, Type: StructProperty)
    void SET_IndicatorShowingInputContext(const UFortInputMappingContext*& Value) { Write<UFortInputMappingContext*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    void SET_IndicatorShowingPriority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: IntProperty)
    void SET_ShowMoreAction(const UInputAction*& Value) { Write<UInputAction*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x178
class UFabricInteractableControllerComponent : public UActorComponent
{
public:
    AFortPlayerController* PlayerController() const { return Read<AFortPlayerController*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UFortGadgetItemDefinition> FabricInteractionToolItemDefSoftPtr() const { return Read<TSoftObjectPtr<UFortGadgetItemDefinition>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UFortGadgetItemDefinition> OverriddenFabricInteractionToolItemDefSoftPtr() const { return Read<TSoftObjectPtr<UFortGadgetItemDefinition>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x20, Type: SoftObjectProperty)
    UFortGadgetItemDefinition* FabricInteractionToolItemDef() const { return Read<UFortGadgetItemDefinition*>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    float EnsurePlayerHasInteractionToolRetryDelay() const { return Read<float>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: FloatProperty)
    FGameplayTagContainer StreamingMusicGameplayTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x20, Type: StructProperty)

    void SET_PlayerController(const AFortPlayerController*& Value) { Write<AFortPlayerController*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    void SET_FabricInteractionToolItemDefSoftPtr(const TSoftObjectPtr<UFortGadgetItemDefinition>& Value) { Write<TSoftObjectPtr<UFortGadgetItemDefinition>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_OverriddenFabricInteractionToolItemDefSoftPtr(const TSoftObjectPtr<UFortGadgetItemDefinition>& Value) { Write<TSoftObjectPtr<UFortGadgetItemDefinition>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_FabricInteractionToolItemDef(const UFortGadgetItemDefinition*& Value) { Write<UFortGadgetItemDefinition*>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    void SET_EnsurePlayerHasInteractionToolRetryDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: FloatProperty)
    void SET_StreamingMusicGameplayTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x20, Type: StructProperty)
};

// Size: 0x28
class UFabricInteractable : public UInterface
{
public:
};

// Size: 0x108
class UFabricInteractablePlayspaceComponent : public UPlayspaceComponent
{
public:
};

// Size: 0x2828
class AFabricInteractionTool : public AFortWeaponRanged
{
public:
    UClass* FITSplineMeshComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0x2678); } // 0x2678 (Size: 0x8, Type: ClassProperty)
    USplineComponent* SplineComponent() const { return Read<USplineComponent*>(uintptr_t(this) + 0x2680); } // 0x2680 (Size: 0x8, Type: ObjectProperty)
    TArray<USplineMeshComponent*> SplineMeshComponentArray() const { return Read<TArray<USplineMeshComponent*>>(uintptr_t(this) + 0x2688); } // 0x2688 (Size: 0x10, Type: ArrayProperty)
    UMaterialInstanceDynamic* SplineMeshMaterialInstance() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x2698); } // 0x2698 (Size: 0x8, Type: ObjectProperty)
    float MaxRange() const { return Read<float>(uintptr_t(this) + 0x26a0); } // 0x26a0 (Size: 0x4, Type: FloatProperty)
    float MinDragAndDropTriggerTime() const { return Read<float>(uintptr_t(this) + 0x26a4); } // 0x26a4 (Size: 0x4, Type: FloatProperty)
    float FiringRate() const { return Read<float>(uintptr_t(this) + 0x26a8); } // 0x26a8 (Size: 0x4, Type: FloatProperty)
    float WipeAnim() const { return Read<float>(uintptr_t(this) + 0x26ac); } // 0x26ac (Size: 0x4, Type: FloatProperty)
    float UseWipe() const { return Read<float>(uintptr_t(this) + 0x26b0); } // 0x26b0 (Size: 0x4, Type: FloatProperty)
    int32_t SplineMeshMaterialIndex() const { return Read<int32_t>(uintptr_t(this) + 0x26b4); } // 0x26b4 (Size: 0x4, Type: IntProperty)
    int32_t CPDUVScale() const { return Read<int32_t>(uintptr_t(this) + 0x26b8); } // 0x26b8 (Size: 0x4, Type: IntProperty)
    int32_t CPDUVPosition() const { return Read<int32_t>(uintptr_t(this) + 0x26bc); } // 0x26bc (Size: 0x4, Type: IntProperty)
    int32_t CPDWipeAnim() const { return Read<int32_t>(uintptr_t(this) + 0x26c0); } // 0x26c0 (Size: 0x4, Type: IntProperty)
    int32_t CPDUseWipe() const { return Read<int32_t>(uintptr_t(this) + 0x26c4); } // 0x26c4 (Size: 0x4, Type: IntProperty)
    int32_t CPDIndex_DeviceType() const { return Read<int32_t>(uintptr_t(this) + 0x26c8); } // 0x26c8 (Size: 0x4, Type: IntProperty)
    float SplineSectionLength() const { return Read<float>(uintptr_t(this) + 0x26cc); } // 0x26cc (Size: 0x4, Type: FloatProperty)
    int32_t MaxSplineSpawnedInAFrame() const { return Read<int32_t>(uintptr_t(this) + 0x26d0); } // 0x26d0 (Size: 0x4, Type: IntProperty)
    float DeviceTypeValue() const { return Read<float>(uintptr_t(this) + 0x26d4); } // 0x26d4 (Size: 0x4, Type: FloatProperty)
    float FITTargetingAudioPitchMultiplier() const { return Read<float>(uintptr_t(this) + 0x26d8); } // 0x26d8 (Size: 0x4, Type: FloatProperty)
    float FITZoomAudioPitchMultiplier() const { return Read<float>(uintptr_t(this) + 0x26dc); } // 0x26dc (Size: 0x4, Type: FloatProperty)
    float SplineEndForwardMultiplier() const { return Read<float>(uintptr_t(this) + 0x26e0); } // 0x26e0 (Size: 0x4, Type: FloatProperty)
    float SplineStartForwardMultiplier() const { return Read<float>(uintptr_t(this) + 0x26e4); } // 0x26e4 (Size: 0x4, Type: FloatProperty)
    UObject* HoveredInteractable() const { return Read<UObject*>(uintptr_t(this) + 0x26e8); } // 0x26e8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* HoveredInteractableHitComponent() const { return Read<USceneComponent*>(uintptr_t(this) + 0x26f0); } // 0x26f0 (Size: 0x8, Type: ObjectProperty)
    UObject* PressedInteractable() const { return Read<UObject*>(uintptr_t(this) + 0x26f8); } // 0x26f8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UObject*> LastPressedInteractable() const { return Read<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x2700); } // 0x2700 (Size: 0x8, Type: WeakObjectProperty)
    USceneComponent* PressedInteractableHitComponent() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2708); } // 0x2708 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AFortCreativeDeviceProp*> InteractableOwnerDevice() const { return Read<TWeakObjectPtr<AFortCreativeDeviceProp*>>(uintptr_t(this) + 0x2710); } // 0x2710 (Size: 0x8, Type: WeakObjectProperty)
    float AccumulatedDragAndDropTriggerTime() const { return Read<float>(uintptr_t(this) + 0x2718); } // 0x2718 (Size: 0x4, Type: FloatProperty)
    FInteractionData ServerInteractionData() const { return Read<FInteractionData>(uintptr_t(this) + 0x271c); } // 0x271c (Size: 0xc, Type: StructProperty)
    bool bServerTriggerPressed() const { return Read<bool>(uintptr_t(this) + 0x2739); } // 0x2739 (Size: 0x1, Type: BoolProperty)
    bool bServerIsHoldingCable() const { return Read<bool>(uintptr_t(this) + 0x273b); } // 0x273b (Size: 0x1, Type: BoolProperty)
    FInteractionSplinePoints ServerSplinePoints() const { return Read<FInteractionSplinePoints>(uintptr_t(this) + 0x2750); } // 0x2750 (Size: 0x60, Type: StructProperty)
    float ServerContinuousInteractableValue() const { return Read<float>(uintptr_t(this) + 0x27b0); } // 0x27b0 (Size: 0x4, Type: FloatProperty)

    void SET_FITSplineMeshComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x2678, Value); } // 0x2678 (Size: 0x8, Type: ClassProperty)
    void SET_SplineComponent(const USplineComponent*& Value) { Write<USplineComponent*>(uintptr_t(this) + 0x2680, Value); } // 0x2680 (Size: 0x8, Type: ObjectProperty)
    void SET_SplineMeshComponentArray(const TArray<USplineMeshComponent*>& Value) { Write<TArray<USplineMeshComponent*>>(uintptr_t(this) + 0x2688, Value); } // 0x2688 (Size: 0x10, Type: ArrayProperty)
    void SET_SplineMeshMaterialInstance(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x2698, Value); } // 0x2698 (Size: 0x8, Type: ObjectProperty)
    void SET_MaxRange(const float& Value) { Write<float>(uintptr_t(this) + 0x26a0, Value); } // 0x26a0 (Size: 0x4, Type: FloatProperty)
    void SET_MinDragAndDropTriggerTime(const float& Value) { Write<float>(uintptr_t(this) + 0x26a4, Value); } // 0x26a4 (Size: 0x4, Type: FloatProperty)
    void SET_FiringRate(const float& Value) { Write<float>(uintptr_t(this) + 0x26a8, Value); } // 0x26a8 (Size: 0x4, Type: FloatProperty)
    void SET_WipeAnim(const float& Value) { Write<float>(uintptr_t(this) + 0x26ac, Value); } // 0x26ac (Size: 0x4, Type: FloatProperty)
    void SET_UseWipe(const float& Value) { Write<float>(uintptr_t(this) + 0x26b0, Value); } // 0x26b0 (Size: 0x4, Type: FloatProperty)
    void SET_SplineMeshMaterialIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x26b4, Value); } // 0x26b4 (Size: 0x4, Type: IntProperty)
    void SET_CPDUVScale(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x26b8, Value); } // 0x26b8 (Size: 0x4, Type: IntProperty)
    void SET_CPDUVPosition(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x26bc, Value); } // 0x26bc (Size: 0x4, Type: IntProperty)
    void SET_CPDWipeAnim(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x26c0, Value); } // 0x26c0 (Size: 0x4, Type: IntProperty)
    void SET_CPDUseWipe(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x26c4, Value); } // 0x26c4 (Size: 0x4, Type: IntProperty)
    void SET_CPDIndex_DeviceType(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x26c8, Value); } // 0x26c8 (Size: 0x4, Type: IntProperty)
    void SET_SplineSectionLength(const float& Value) { Write<float>(uintptr_t(this) + 0x26cc, Value); } // 0x26cc (Size: 0x4, Type: FloatProperty)
    void SET_MaxSplineSpawnedInAFrame(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x26d0, Value); } // 0x26d0 (Size: 0x4, Type: IntProperty)
    void SET_DeviceTypeValue(const float& Value) { Write<float>(uintptr_t(this) + 0x26d4, Value); } // 0x26d4 (Size: 0x4, Type: FloatProperty)
    void SET_FITTargetingAudioPitchMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x26d8, Value); } // 0x26d8 (Size: 0x4, Type: FloatProperty)
    void SET_FITZoomAudioPitchMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x26dc, Value); } // 0x26dc (Size: 0x4, Type: FloatProperty)
    void SET_SplineEndForwardMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x26e0, Value); } // 0x26e0 (Size: 0x4, Type: FloatProperty)
    void SET_SplineStartForwardMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x26e4, Value); } // 0x26e4 (Size: 0x4, Type: FloatProperty)
    void SET_HoveredInteractable(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x26e8, Value); } // 0x26e8 (Size: 0x8, Type: ObjectProperty)
    void SET_HoveredInteractableHitComponent(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x26f0, Value); } // 0x26f0 (Size: 0x8, Type: ObjectProperty)
    void SET_PressedInteractable(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x26f8, Value); } // 0x26f8 (Size: 0x8, Type: ObjectProperty)
    void SET_LastPressedInteractable(const TWeakObjectPtr<UObject*>& Value) { Write<TWeakObjectPtr<UObject*>>(uintptr_t(this) + 0x2700, Value); } // 0x2700 (Size: 0x8, Type: WeakObjectProperty)
    void SET_PressedInteractableHitComponent(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2708, Value); } // 0x2708 (Size: 0x8, Type: ObjectProperty)
    void SET_InteractableOwnerDevice(const TWeakObjectPtr<AFortCreativeDeviceProp*>& Value) { Write<TWeakObjectPtr<AFortCreativeDeviceProp*>>(uintptr_t(this) + 0x2710, Value); } // 0x2710 (Size: 0x8, Type: WeakObjectProperty)
    void SET_AccumulatedDragAndDropTriggerTime(const float& Value) { Write<float>(uintptr_t(this) + 0x2718, Value); } // 0x2718 (Size: 0x4, Type: FloatProperty)
    void SET_ServerInteractionData(const FInteractionData& Value) { Write<FInteractionData>(uintptr_t(this) + 0x271c, Value); } // 0x271c (Size: 0xc, Type: StructProperty)
    void SET_bServerTriggerPressed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2739, Value); } // 0x2739 (Size: 0x1, Type: BoolProperty)
    void SET_bServerIsHoldingCable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x273b, Value); } // 0x273b (Size: 0x1, Type: BoolProperty)
    void SET_ServerSplinePoints(const FInteractionSplinePoints& Value) { Write<FInteractionSplinePoints>(uintptr_t(this) + 0x2750, Value); } // 0x2750 (Size: 0x60, Type: StructProperty)
    void SET_ServerContinuousInteractableValue(const float& Value) { Write<float>(uintptr_t(this) + 0x27b0, Value); } // 0x27b0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
class UFabricIslandSettingsInitializedInterface : public UInterface
{
public:
};

// Size: 0x330
class UFabricMeshModifierBase : public UFabricModulatable
{
public:
    uint8_t CloneBehavior() const { return Read<uint8_t>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x1, Type: EnumProperty)

    void SET_CloneBehavior(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x348
class UFabricMeshModifierTranslate : public UFabricMeshModifierBase
{
public:
    FVector PositionOffset() const { return Read<FVector>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x18, Type: StructProperty)

    void SET_PositionOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x18, Type: StructProperty)
};

// Size: 0x348
class UFabricMeshModifierRotate : public UFabricMeshModifierBase
{
public:
    FRotator RotationAmount() const { return Read<FRotator>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x18, Type: StructProperty)

    void SET_RotationAmount(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x18, Type: StructProperty)
};

// Size: 0x348
class UFabricMeshModifierScale : public UFabricMeshModifierBase
{
public:
    FVector ScaleFactor() const { return Read<FVector>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x18, Type: StructProperty)

    void SET_ScaleFactor(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x18, Type: StructProperty)
};

// Size: 0x358
class UFabricMeshModifierClone : public UFabricMeshModifierBase
{
public:
    int32_t CloneCount() const { return Read<int32_t>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x4, Type: IntProperty)
    FVector PerCloneTranslation() const { return Read<FVector>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x18, Type: StructProperty)
    bool bCentered() const { return Read<bool>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x1, Type: BoolProperty)

    void SET_CloneCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x4, Type: IntProperty)
    void SET_PerCloneTranslation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x18, Type: StructProperty)
    void SET_bCentered(const bool& Value) { Write<bool>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x398
class UFabricMeshModifierRandomize : public UFabricMeshModifierBase
{
public:
    float LocationRandLimit() const { return Read<float>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x4, Type: FloatProperty)
    float RotationRandLimit() const { return Read<float>(uintptr_t(this) + 0x334); } // 0x334 (Size: 0x4, Type: FloatProperty)
    float ScaleRandLimit() const { return Read<float>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x4, Type: FloatProperty)
    FVector LocationRandRange() const { return Read<FVector>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x18, Type: StructProperty)
    FVector RotationRandRange() const { return Read<FVector>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x18, Type: StructProperty)
    FVector ScaleRandRangeAdditive() const { return Read<FVector>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x18, Type: StructProperty)
    float ScaleRandRangeRangeBase() const { return Read<float>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x4, Type: FloatProperty)
    bool bUniformScale() const { return Read<bool>(uintptr_t(this) + 0x38c); } // 0x38c (Size: 0x1, Type: BoolProperty)
    FRandomStream RandomStream() const { return Read<FRandomStream>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: StructProperty)

    void SET_LocationRandLimit(const float& Value) { Write<float>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x4, Type: FloatProperty)
    void SET_RotationRandLimit(const float& Value) { Write<float>(uintptr_t(this) + 0x334, Value); } // 0x334 (Size: 0x4, Type: FloatProperty)
    void SET_ScaleRandLimit(const float& Value) { Write<float>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x4, Type: FloatProperty)
    void SET_LocationRandRange(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x18, Type: StructProperty)
    void SET_RotationRandRange(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x18, Type: StructProperty)
    void SET_ScaleRandRangeAdditive(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x18, Type: StructProperty)
    void SET_ScaleRandRangeRangeBase(const float& Value) { Write<float>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x4, Type: FloatProperty)
    void SET_bUniformScale(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38c, Value); } // 0x38c (Size: 0x1, Type: BoolProperty)
    void SET_RandomStream(const FRandomStream& Value) { Write<FRandomStream>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: StructProperty)
};

// Size: 0xa8
class UFabricMeshTreeNode : public UObject
{
public:
    UFabricMeshModifierBase* MeshModifier() const { return Read<UFabricMeshModifierBase*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    FFabricMeshProviderMeshReferenceParams Params() const { return Read<FFabricMeshProviderMeshReferenceParams>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x28, Type: StructProperty)
    FFabricMeshProviderMeshReference MeshProviderReference() const { return Read<FFabricMeshProviderMeshReference>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x38, Type: StructProperty)
    TArray<UFabricMeshTreeNode*> Children() const { return Read<TArray<UFabricMeshTreeNode*>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    uint32_t LastCalculatedChecksum() const { return Read<uint32_t>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: UInt32Property)
    bool bAllowChecksumCalculation() const { return Read<bool>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x1, Type: BoolProperty)

    void SET_MeshModifier(const UFabricMeshModifierBase*& Value) { Write<UFabricMeshModifierBase*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_Params(const FFabricMeshProviderMeshReferenceParams& Value) { Write<FFabricMeshProviderMeshReferenceParams>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x28, Type: StructProperty)
    void SET_MeshProviderReference(const FFabricMeshProviderMeshReference& Value) { Write<FFabricMeshProviderMeshReference>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x38, Type: StructProperty)
    void SET_Children(const TArray<UFabricMeshTreeNode*>& Value) { Write<TArray<UFabricMeshTreeNode*>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    void SET_LastCalculatedChecksum(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: UInt32Property)
    void SET_bAllowChecksumCalculation(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
class UFabricMeshProviderBase : public UObject
{
public:
    FFabricMeshProviderMeshReference ReferenceMesh() const { return Read<FFabricMeshProviderMeshReference>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x38, Type: StructProperty)
    TArray<FTransform> InstanceMeshes() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    float CurrentCableFloatValue() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    float CurrentCableFloatDirection() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)
    bool bCurrentCableFloatDirty() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)

    void SET_ReferenceMesh(const FFabricMeshProviderMeshReference& Value) { Write<FFabricMeshProviderMeshReference>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x38, Type: StructProperty)
    void SET_InstanceMeshes(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentCableFloatValue(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_CurrentCableFloatDirection(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
    void SET_bCurrentCableFloatDirty(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x828
class UFabricMetaSoundAudioPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
    TSoftObjectPtr<UMetaSoundPatch> FromStartPatch() const { return Read<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x7a0); } // 0x7a0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMetaSoundPatch> FromCurrentPatch() const { return Read<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x7c0); } // 0x7c0 (Size: 0x20, Type: SoftObjectProperty)
    UMetaSoundPatch* LoadedFromStartPatch() const { return Read<UMetaSoundPatch*>(uintptr_t(this) + 0x7e0); } // 0x7e0 (Size: 0x8, Type: ObjectProperty)
    UMetaSoundPatch* LoadedFromCurrentPatch() const { return Read<UMetaSoundPatch*>(uintptr_t(this) + 0x7e8); } // 0x7e8 (Size: 0x8, Type: ObjectProperty)
    FName VolumeInputName() const { return Read<FName>(uintptr_t(this) + 0x7f0); } // 0x7f0 (Size: 0x4, Type: NameProperty)
    FName LoopAudioInputName() const { return Read<FName>(uintptr_t(this) + 0x7f4); } // 0x7f4 (Size: 0x4, Type: NameProperty)
    FName StartTimeInputName() const { return Read<FName>(uintptr_t(this) + 0x7f8); } // 0x7f8 (Size: 0x4, Type: NameProperty)
    FName StartTimestampInputName() const { return Read<FName>(uintptr_t(this) + 0x7fc); } // 0x7fc (Size: 0x4, Type: NameProperty)

    void SET_FromStartPatch(const TSoftObjectPtr<UMetaSoundPatch>& Value) { Write<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x7a0, Value); } // 0x7a0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_FromCurrentPatch(const TSoftObjectPtr<UMetaSoundPatch>& Value) { Write<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x7c0, Value); } // 0x7c0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_LoadedFromStartPatch(const UMetaSoundPatch*& Value) { Write<UMetaSoundPatch*>(uintptr_t(this) + 0x7e0, Value); } // 0x7e0 (Size: 0x8, Type: ObjectProperty)
    void SET_LoadedFromCurrentPatch(const UMetaSoundPatch*& Value) { Write<UMetaSoundPatch*>(uintptr_t(this) + 0x7e8, Value); } // 0x7e8 (Size: 0x8, Type: ObjectProperty)
    void SET_VolumeInputName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7f0, Value); } // 0x7f0 (Size: 0x4, Type: NameProperty)
    void SET_LoopAudioInputName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7f4, Value); } // 0x7f4 (Size: 0x4, Type: NameProperty)
    void SET_StartTimeInputName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7f8, Value); } // 0x7f8 (Size: 0x4, Type: NameProperty)
    void SET_StartTimestampInputName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7fc, Value); } // 0x7fc (Size: 0x4, Type: NameProperty)
};

// Size: 0x798
class UFabricMetaSoundPatchWrapper : public UFabricModulatable
{
public:
    FName EnabledStateInputName() const { return Read<FName>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x4, Type: NameProperty)
    TSoftObjectPtr<UMetaSoundPatch> MetaSoundPatch() const { return Read<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x20, Type: SoftObjectProperty)
    TMap<FName, FString> UserOptionsToNodeInputs() const { return Read<TMap<FName, FString>>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x50, Type: MapProperty)
    TArray<FFabricMetaSoundPatchWrapper_PerPlatformBoolInputTuning> PerPlatformInputBools() const { return Read<TArray<FFabricMetaSoundPatchWrapper_PerPlatformBoolInputTuning>>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x10, Type: ArrayProperty)
    TArray<FFabricMetaSoundPatchWrapper_PerPlatformIntInputTuning> PerPlatformInputInts() const { return Read<TArray<FFabricMetaSoundPatchWrapper_PerPlatformIntInputTuning>>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x10, Type: ArrayProperty)
    TArray<FFabricMetaSoundPatchWrapper_PerPlatformFloatInputTuning> PerPlatformInputFloats() const { return Read<TArray<FFabricMetaSoundPatchWrapper_PerPlatformFloatInputTuning>>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x10, Type: ArrayProperty)
    TArray<FFabricMetaSoundDirectInputInfo> DirectInputs() const { return Read<TArray<FFabricMetaSoundDirectInputInfo>>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x10, Type: ArrayProperty)
    FFabricMetaSoundPatchWrapperBinding SimpleSignalOutputBinding() const { return Read<FFabricMetaSoundPatchWrapperBinding>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x50, Type: StructProperty)
    FName VisibleInputParamName() const { return Read<FName>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x4, Type: NameProperty)
    FName AudibleInputParamName() const { return Read<FName>(uintptr_t(this) + 0x444); } // 0x444 (Size: 0x4, Type: NameProperty)
    bool bCanConsumeVisibleFlag() const { return Read<bool>(uintptr_t(this) + 0x448); } // 0x448 (Size: 0x1, Type: BoolProperty)
    bool bCanConsumeAudibleFlag() const { return Read<bool>(uintptr_t(this) + 0x449); } // 0x449 (Size: 0x1, Type: BoolProperty)
    bool bIsVisible() const { return Read<bool>(uintptr_t(this) + 0x44a); } // 0x44a (Size: 0x1, Type: BoolProperty)
    bool bIsAudible() const { return Read<bool>(uintptr_t(this) + 0x44b); } // 0x44b (Size: 0x1, Type: BoolProperty)
    UFabricMetaSoundManagerComponent* CurrentManager() const { return Read<UFabricMetaSoundManagerComponent*>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UFabricMetaSoundTickSubsystem*> TickSubsystem() const { return Read<TWeakObjectPtr<UFabricMetaSoundTickSubsystem*>>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x8, Type: WeakObjectProperty)
    FFabricMetaSoundNodeInfo CurrentNode() const { return Read<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0xf0, Type: StructProperty)
    TWeakObjectPtr<AActor*> PositionalProxyActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UAudioComponent*> CurrentAudioComponent() const { return Read<TWeakObjectPtr<UAudioComponent*>>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UAudioComponent*> NewAudioComponent() const { return Read<TWeakObjectPtr<UAudioComponent*>>(uintptr_t(this) + 0x5d0); } // 0x5d0 (Size: 0x8, Type: WeakObjectProperty)
    FName CombinerMetaSoundType() const { return Read<FName>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x4, Type: NameProperty)
    FName AnalyzerMetaSoundType() const { return Read<FName>(uintptr_t(this) + 0x5ec); } // 0x5ec (Size: 0x4, Type: NameProperty)
    TArray<FFabricMetaSoundRuntimeInputInfo> MetaSoundRuntimeInputInfos() const { return Read<TArray<FFabricMetaSoundRuntimeInputInfo>>(uintptr_t(this) + 0x5f0); } // 0x5f0 (Size: 0x10, Type: ArrayProperty)
    TArray<UFabricMetaSoundPatchWrapper*> ConnectedInputWrappers() const { return Read<TArray<UFabricMetaSoundPatchWrapper*>>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x10, Type: ArrayProperty)
    TArray<UFabricMetaSoundPatchWrapper*> PendingInputWrappers() const { return Read<TArray<UFabricMetaSoundPatchWrapper*>>(uintptr_t(this) + 0x610); } // 0x610 (Size: 0x10, Type: ArrayProperty)
    TArray<UFabricMetaSoundPatchWrapper*> PendingOutputWrappers() const { return Read<TArray<UFabricMetaSoundPatchWrapper*>>(uintptr_t(this) + 0x620); } // 0x620 (Size: 0x10, Type: ArrayProperty)
    FFabricMetaSoundConnectionBuilder ConnectionBuilder() const { return Read<FFabricMetaSoundConnectionBuilder>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0xc0, Type: StructProperty)
    TArray<FMetaSoundCombinerNodeHandle> CombinersInUse() const { return Read<TArray<FMetaSoundCombinerNodeHandle>>(uintptr_t(this) + 0x740); } // 0x740 (Size: 0x10, Type: ArrayProperty)
    TArray<UFabricMetaSoundPatchWrapper*> ConnectedOutputWrappers() const { return Read<TArray<UFabricMetaSoundPatchWrapper*>>(uintptr_t(this) + 0x750); } // 0x750 (Size: 0x10, Type: ArrayProperty)
    uint8_t PatchWrapperQuality() const { return Read<uint8_t>(uintptr_t(this) + 0x760); } // 0x760 (Size: 0x1, Type: EnumProperty)
    uint8_t MaxAttenuation() const { return Read<uint8_t>(uintptr_t(this) + 0x761); } // 0x761 (Size: 0x1, Type: EnumProperty)
    UMetaSoundPatch* LoadedMetaSoundPatch() const { return Read<UMetaSoundPatch*>(uintptr_t(this) + 0x778); } // 0x778 (Size: 0x8, Type: ObjectProperty)

    void SET_EnabledStateInputName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x4, Type: NameProperty)
    void SET_MetaSoundPatch(const TSoftObjectPtr<UMetaSoundPatch>& Value) { Write<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x20, Type: SoftObjectProperty)
    void SET_UserOptionsToNodeInputs(const TMap<FName, FString>& Value) { Write<TMap<FName, FString>>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x50, Type: MapProperty)
    void SET_PerPlatformInputBools(const TArray<FFabricMetaSoundPatchWrapper_PerPlatformBoolInputTuning>& Value) { Write<TArray<FFabricMetaSoundPatchWrapper_PerPlatformBoolInputTuning>>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x10, Type: ArrayProperty)
    void SET_PerPlatformInputInts(const TArray<FFabricMetaSoundPatchWrapper_PerPlatformIntInputTuning>& Value) { Write<TArray<FFabricMetaSoundPatchWrapper_PerPlatformIntInputTuning>>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x10, Type: ArrayProperty)
    void SET_PerPlatformInputFloats(const TArray<FFabricMetaSoundPatchWrapper_PerPlatformFloatInputTuning>& Value) { Write<TArray<FFabricMetaSoundPatchWrapper_PerPlatformFloatInputTuning>>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x10, Type: ArrayProperty)
    void SET_DirectInputs(const TArray<FFabricMetaSoundDirectInputInfo>& Value) { Write<TArray<FFabricMetaSoundDirectInputInfo>>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x10, Type: ArrayProperty)
    void SET_SimpleSignalOutputBinding(const FFabricMetaSoundPatchWrapperBinding& Value) { Write<FFabricMetaSoundPatchWrapperBinding>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x50, Type: StructProperty)
    void SET_VisibleInputParamName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x4, Type: NameProperty)
    void SET_AudibleInputParamName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x444, Value); } // 0x444 (Size: 0x4, Type: NameProperty)
    void SET_bCanConsumeVisibleFlag(const bool& Value) { Write<bool>(uintptr_t(this) + 0x448, Value); } // 0x448 (Size: 0x1, Type: BoolProperty)
    void SET_bCanConsumeAudibleFlag(const bool& Value) { Write<bool>(uintptr_t(this) + 0x449, Value); } // 0x449 (Size: 0x1, Type: BoolProperty)
    void SET_bIsVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x44a, Value); } // 0x44a (Size: 0x1, Type: BoolProperty)
    void SET_bIsAudible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x44b, Value); } // 0x44b (Size: 0x1, Type: BoolProperty)
    void SET_CurrentManager(const UFabricMetaSoundManagerComponent*& Value) { Write<UFabricMetaSoundManagerComponent*>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    void SET_TickSubsystem(const TWeakObjectPtr<UFabricMetaSoundTickSubsystem*>& Value) { Write<TWeakObjectPtr<UFabricMetaSoundTickSubsystem*>>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CurrentNode(const FFabricMetaSoundNodeInfo& Value) { Write<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0xf0, Type: StructProperty)
    void SET_PositionalProxyActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CurrentAudioComponent(const TWeakObjectPtr<UAudioComponent*>& Value) { Write<TWeakObjectPtr<UAudioComponent*>>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_NewAudioComponent(const TWeakObjectPtr<UAudioComponent*>& Value) { Write<TWeakObjectPtr<UAudioComponent*>>(uintptr_t(this) + 0x5d0, Value); } // 0x5d0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CombinerMetaSoundType(const FName& Value) { Write<FName>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x4, Type: NameProperty)
    void SET_AnalyzerMetaSoundType(const FName& Value) { Write<FName>(uintptr_t(this) + 0x5ec, Value); } // 0x5ec (Size: 0x4, Type: NameProperty)
    void SET_MetaSoundRuntimeInputInfos(const TArray<FFabricMetaSoundRuntimeInputInfo>& Value) { Write<TArray<FFabricMetaSoundRuntimeInputInfo>>(uintptr_t(this) + 0x5f0, Value); } // 0x5f0 (Size: 0x10, Type: ArrayProperty)
    void SET_ConnectedInputWrappers(const TArray<UFabricMetaSoundPatchWrapper*>& Value) { Write<TArray<UFabricMetaSoundPatchWrapper*>>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x10, Type: ArrayProperty)
    void SET_PendingInputWrappers(const TArray<UFabricMetaSoundPatchWrapper*>& Value) { Write<TArray<UFabricMetaSoundPatchWrapper*>>(uintptr_t(this) + 0x610, Value); } // 0x610 (Size: 0x10, Type: ArrayProperty)
    void SET_PendingOutputWrappers(const TArray<UFabricMetaSoundPatchWrapper*>& Value) { Write<TArray<UFabricMetaSoundPatchWrapper*>>(uintptr_t(this) + 0x620, Value); } // 0x620 (Size: 0x10, Type: ArrayProperty)
    void SET_ConnectionBuilder(const FFabricMetaSoundConnectionBuilder& Value) { Write<FFabricMetaSoundConnectionBuilder>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0xc0, Type: StructProperty)
    void SET_CombinersInUse(const TArray<FMetaSoundCombinerNodeHandle>& Value) { Write<TArray<FMetaSoundCombinerNodeHandle>>(uintptr_t(this) + 0x740, Value); } // 0x740 (Size: 0x10, Type: ArrayProperty)
    void SET_ConnectedOutputWrappers(const TArray<UFabricMetaSoundPatchWrapper*>& Value) { Write<TArray<UFabricMetaSoundPatchWrapper*>>(uintptr_t(this) + 0x750, Value); } // 0x750 (Size: 0x10, Type: ArrayProperty)
    void SET_PatchWrapperQuality(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x760, Value); } // 0x760 (Size: 0x1, Type: EnumProperty)
    void SET_MaxAttenuation(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x761, Value); } // 0x761 (Size: 0x1, Type: EnumProperty)
    void SET_LoadedMetaSoundPatch(const UMetaSoundPatch*& Value) { Write<UMetaSoundPatch*>(uintptr_t(this) + 0x778, Value); } // 0x778 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x798
class UFabricMetaSoundBigKnobPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
};

// Size: 0x868
class UFabricMetaSoundDrumPlayerPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
    FName PitchSampleInputName() const { return Read<FName>(uintptr_t(this) + 0x7a0); } // 0x7a0 (Size: 0x4, Type: NameProperty)
    FName SlotKitInputName() const { return Read<FName>(uintptr_t(this) + 0x7a4); } // 0x7a4 (Size: 0x4, Type: NameProperty)
    TArray<FString> PitchSampleParams() const { return Read<TArray<FString>>(uintptr_t(this) + 0x7a8); } // 0x7a8 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> SlotLinkParams() const { return Read<TArray<FString>>(uintptr_t(this) + 0x7b8); } // 0x7b8 (Size: 0x10, Type: ArrayProperty)
    FString CurrentKitParam() const { return Read<FString>(uintptr_t(this) + 0x7c8); } // 0x7c8 (Size: 0x10, Type: StrProperty)
    int32_t NumSamplesPerKit() const { return Read<int32_t>(uintptr_t(this) + 0x7d8); } // 0x7d8 (Size: 0x4, Type: IntProperty)
    TArray<FFabricMetaSoundPatchWrapperBinding> DrumAmplitudes() const { return Read<TArray<FFabricMetaSoundPatchWrapperBinding>>(uintptr_t(this) + 0x7e0); } // 0x7e0 (Size: 0x10, Type: ArrayProperty)
    TArray<UObject*> CurrentKitSamples() const { return Read<TArray<UObject*>>(uintptr_t(this) + 0x858); } // 0x858 (Size: 0x10, Type: ArrayProperty)

    void SET_PitchSampleInputName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7a0, Value); } // 0x7a0 (Size: 0x4, Type: NameProperty)
    void SET_SlotKitInputName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7a4, Value); } // 0x7a4 (Size: 0x4, Type: NameProperty)
    void SET_PitchSampleParams(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x7a8, Value); } // 0x7a8 (Size: 0x10, Type: ArrayProperty)
    void SET_SlotLinkParams(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x7b8, Value); } // 0x7b8 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentKitParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x7c8, Value); } // 0x7c8 (Size: 0x10, Type: StrProperty)
    void SET_NumSamplesPerKit(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x7d8, Value); } // 0x7d8 (Size: 0x4, Type: IntProperty)
    void SET_DrumAmplitudes(const TArray<FFabricMetaSoundPatchWrapperBinding>& Value) { Write<TArray<FFabricMetaSoundPatchWrapperBinding>>(uintptr_t(this) + 0x7e0, Value); } // 0x7e0 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentKitSamples(const TArray<UObject*>& Value) { Write<TArray<UObject*>>(uintptr_t(this) + 0x858, Value); } // 0x858 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x860
class UFabricMetaSoundEchoPatchWrapper : public UFabricMetaSoundWetDryPatchWrapper
{
public:
    bool bAllowWetSignalWaveformTexture() const { return Read<bool>(uintptr_t(this) + 0x848); } // 0x848 (Size: 0x1, Type: BoolProperty)
    bool bAllowDrySignalWaveformTexture() const { return Read<bool>(uintptr_t(this) + 0x849); } // 0x849 (Size: 0x1, Type: BoolProperty)
    UFabricWaveformTexture* WetSignalWaveformTexture() const { return Read<UFabricWaveformTexture*>(uintptr_t(this) + 0x850); } // 0x850 (Size: 0x8, Type: ObjectProperty)
    UFabricWaveformTexture* DrySignalWaveformTexture() const { return Read<UFabricWaveformTexture*>(uintptr_t(this) + 0x858); } // 0x858 (Size: 0x8, Type: ObjectProperty)

    void SET_bAllowWetSignalWaveformTexture(const bool& Value) { Write<bool>(uintptr_t(this) + 0x848, Value); } // 0x848 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowDrySignalWaveformTexture(const bool& Value) { Write<bool>(uintptr_t(this) + 0x849, Value); } // 0x849 (Size: 0x1, Type: BoolProperty)
    void SET_WetSignalWaveformTexture(const UFabricWaveformTexture*& Value) { Write<UFabricWaveformTexture*>(uintptr_t(this) + 0x850, Value); } // 0x850 (Size: 0x8, Type: ObjectProperty)
    void SET_DrySignalWaveformTexture(const UFabricWaveformTexture*& Value) { Write<UFabricWaveformTexture*>(uintptr_t(this) + 0x858, Value); } // 0x858 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x848
class UFabricMetaSoundWetDryPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
    FFabricMetaSoundPatchWrapperWetDryOutputBinding WetDryOutputBinding() const { return Read<FFabricMetaSoundPatchWrapperWetDryOutputBinding>(uintptr_t(this) + 0x798); } // 0x798 (Size: 0xa0, Type: StructProperty)

    void SET_WetDryOutputBinding(const FFabricMetaSoundPatchWrapperWetDryOutputBinding& Value) { Write<FFabricMetaSoundPatchWrapperWetDryOutputBinding>(uintptr_t(this) + 0x798, Value); } // 0x798 (Size: 0xa0, Type: StructProperty)
};

// Size: 0x880
class UFabricMetaSoundInstrumentPlayerPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
    FFabricMetaSoundPatchWrapperBinding FFTAnalysisOutputBinding() const { return Read<FFabricMetaSoundPatchWrapperBinding>(uintptr_t(this) + 0x7a8); } // 0x7a8 (Size: 0x50, Type: StructProperty)
    int32_t FFTCPDStartIndex() const { return Read<int32_t>(uintptr_t(this) + 0x7f8); } // 0x7f8 (Size: 0x4, Type: IntProperty)
    int32_t FFTLength() const { return Read<int32_t>(uintptr_t(this) + 0x7fc); } // 0x7fc (Size: 0x4, Type: IntProperty)
    UFusionPatch* CurrentFusionPatch() const { return Read<UFusionPatch*>(uintptr_t(this) + 0x878); } // 0x878 (Size: 0x8, Type: ObjectProperty)

    void SET_FFTAnalysisOutputBinding(const FFabricMetaSoundPatchWrapperBinding& Value) { Write<FFabricMetaSoundPatchWrapperBinding>(uintptr_t(this) + 0x7a8, Value); } // 0x7a8 (Size: 0x50, Type: StructProperty)
    void SET_FFTCPDStartIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x7f8, Value); } // 0x7f8 (Size: 0x4, Type: IntProperty)
    void SET_FFTLength(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x7fc, Value); } // 0x7fc (Size: 0x4, Type: IntProperty)
    void SET_CurrentFusionPatch(const UFusionPatch*& Value) { Write<UFusionPatch*>(uintptr_t(this) + 0x878, Value); } // 0x878 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x7d0
class UFabricMetaSoundLFOPatchWrapper : public UFabricMetaSoundModulatorPatchWrapper
{
public:
    UFabricFloatProviderWave* LFOFloatProvider() const { return Read<UFabricFloatProviderWave*>(uintptr_t(this) + 0x7b8); } // 0x7b8 (Size: 0x8, Type: ObjectProperty)
    FName FreePhaseStartName() const { return Read<FName>(uintptr_t(this) + 0x7c0); } // 0x7c0 (Size: 0x4, Type: NameProperty)
    FName RandomSeedInputName() const { return Read<FName>(uintptr_t(this) + 0x7c4); } // 0x7c4 (Size: 0x4, Type: NameProperty)

    void SET_LFOFloatProvider(const UFabricFloatProviderWave*& Value) { Write<UFabricFloatProviderWave*>(uintptr_t(this) + 0x7b8, Value); } // 0x7b8 (Size: 0x8, Type: ObjectProperty)
    void SET_FreePhaseStartName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7c0, Value); } // 0x7c0 (Size: 0x4, Type: NameProperty)
    void SET_RandomSeedInputName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7c4, Value); } // 0x7c4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x7b8
class UFabricMetaSoundModulatorPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
    UPlaylistUserOptionBase* CurrentUserOption() const { return Read<UPlaylistUserOptionBase*>(uintptr_t(this) + 0x7a8); } // 0x7a8 (Size: 0x8, Type: ObjectProperty)
    UFabricMetaSoundUserOption* MetaSoundUserOption() const { return Read<UFabricMetaSoundUserOption*>(uintptr_t(this) + 0x7b0); } // 0x7b0 (Size: 0x8, Type: ObjectProperty)

    void SET_CurrentUserOption(const UPlaylistUserOptionBase*& Value) { Write<UPlaylistUserOptionBase*>(uintptr_t(this) + 0x7a8, Value); } // 0x7a8 (Size: 0x8, Type: ObjectProperty)
    void SET_MetaSoundUserOption(const UFabricMetaSoundUserOption*& Value) { Write<UFabricMetaSoundUserOption*>(uintptr_t(this) + 0x7b0, Value); } // 0x7b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xab0
class UFabricMetaSoundManagerComponent : public UActorComponent
{
public:
    TSoftObjectPtr<UMetaSoundPatch> HarmonixMusicProviderPatch() const { return Read<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMetaSoundPatch> HarmonixMetronomeClockPatch() const { return Read<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMetaSoundPatch> HarmonixTempoClockPatch() const { return Read<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMetaSoundPatch> HarmonixTransportPatch() const { return Read<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMetaSoundPatch> UserOptionConverterNode() const { return Read<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x20, Type: SoftObjectProperty)
    FFabricMetaSoundUtilityPatches MidiStreamUtilityPatches() const { return Read<FFabricMetaSoundUtilityPatches>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x88, Type: StructProperty)
    FFabricMetaSoundUtilityPatches AudioUtilityPatches() const { return Read<FFabricMetaSoundUtilityPatches>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x88, Type: StructProperty)
    FFabricMetaSoundUtilityPatches FloatUtilityPatches() const { return Read<FFabricMetaSoundUtilityPatches>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x88, Type: StructProperty)
    FName MusicProviderVolumeName() const { return Read<FName>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x4, Type: NameProperty)
    FName MusicProviderRootNoteName() const { return Read<FName>(uintptr_t(this) + 0x304); } // 0x304 (Size: 0x4, Type: NameProperty)
    FName MusicProviderScaleName() const { return Read<FName>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x4, Type: NameProperty)
    FName TransportProviderPlayTriggerName() const { return Read<FName>(uintptr_t(this) + 0x30c); } // 0x30c (Size: 0x4, Type: NameProperty)
    FName TransportProviderDelayedRestartTriggerName() const { return Read<FName>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x4, Type: NameProperty)
    FName TransportProviderRestartTriggerName() const { return Read<FName>(uintptr_t(this) + 0x314); } // 0x314 (Size: 0x4, Type: NameProperty)
    FName TransportProviderSeekTriggerName() const { return Read<FName>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x4, Type: NameProperty)
    FName TransportProviderPauseTriggerName() const { return Read<FName>(uintptr_t(this) + 0x31c); } // 0x31c (Size: 0x4, Type: NameProperty)
    FName TransportProviderContinueTriggerName() const { return Read<FName>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x4, Type: NameProperty)
    FName TransportProviderStopTriggerName() const { return Read<FName>(uintptr_t(this) + 0x324); } // 0x324 (Size: 0x4, Type: NameProperty)
    FName TransportProviderSeekTargetName() const { return Read<FName>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x4, Type: NameProperty)
    FName ClockProviderTempoName() const { return Read<FName>(uintptr_t(this) + 0x32c); } // 0x32c (Size: 0x4, Type: NameProperty)
    FName ClockProviderSpeedName() const { return Read<FName>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x4, Type: NameProperty)
    FName ClockProviderTimeSigNumName() const { return Read<FName>(uintptr_t(this) + 0x334); } // 0x334 (Size: 0x4, Type: NameProperty)
    FName ClockProviderTimeSignDenomName() const { return Read<FName>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x4, Type: NameProperty)
    FName ClockProviderMidiFileInName() const { return Read<FName>(uintptr_t(this) + 0x33c); } // 0x33c (Size: 0x4, Type: NameProperty)
    FName ClockProviderLoopName() const { return Read<FName>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x4, Type: NameProperty)
    FName UserOptionConverterCountInName() const { return Read<FName>(uintptr_t(this) + 0x344); } // 0x344 (Size: 0x4, Type: NameProperty)
    float CrossfadeSeconds() const { return Read<float>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x4, Type: FloatProperty)
    float RebuildTimeOutSeconds() const { return Read<float>(uintptr_t(this) + 0x34c); } // 0x34c (Size: 0x4, Type: FloatProperty)
    float BlockRateOverride() const { return Read<float>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x4, Type: FloatProperty)
    FName QualityOverride() const { return Read<FName>(uintptr_t(this) + 0x354); } // 0x354 (Size: 0x4, Type: NameProperty)
    UMidiFile* DefaultMidiFile() const { return Read<UMidiFile*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    TArray<FFabricSignificanceBasedUpdateBucketRuntime> SignificanceRuntimeBuckets() const { return Read<TArray<FFabricSignificanceBasedUpdateBucketRuntime>>(uintptr_t(this) + 0x428); } // 0x428 (Size: 0x10, Type: ArrayProperty)
    UFabricSignificanceAsset* SignificanceBasedUpdate() const { return Read<UFabricSignificanceAsset*>(uintptr_t(this) + 0x438); } // 0x438 (Size: 0x8, Type: ObjectProperty)
    float InitialCooldownTimeInSeconds() const { return Read<float>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x4, Type: FloatProperty)
    UMetaSoundSourceBuilder* SourceBuilder() const { return Read<UMetaSoundSourceBuilder*>(uintptr_t(this) + 0x448); } // 0x448 (Size: 0x8, Type: ObjectProperty)
    UMusicClockComponent* MusicClock() const { return Read<UMusicClockComponent*>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x8, Type: ObjectProperty)
    TArray<UAudioComponent*> PlaybackAudioComponents() const { return Read<TArray<UAudioComponent*>>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x10, Type: ArrayProperty)
    TArray<UMetasoundOfflinePlayerComponent*> ServerPlaybackComponents() const { return Read<TArray<UMetasoundOfflinePlayerComponent*>>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x10, Type: ArrayProperty)
    FFabricTransportRequestConfig CurrentTransportRequestLock() const { return Read<FFabricTransportRequestConfig>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x8, Type: StructProperty)
    TArray<UFabricMetaSoundUtilityProviderPatchWrapper*> SortedRegisteredUtilityProviderAuthorities() const { return Read<TArray<UFabricMetaSoundUtilityProviderPatchWrapper*>>(uintptr_t(this) + 0x528); } // 0x528 (Size: 0x10, Type: ArrayProperty)
    FMusicTimestamp ClockAuthorityLoopLength() const { return Read<FMusicTimestamp>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x8, Type: StructProperty)
    TWeakObjectPtr<UMidiFile*> TempoMapMidiFile() const { return Read<TWeakObjectPtr<UMidiFile*>>(uintptr_t(this) + 0x540); } // 0x540 (Size: 0x8, Type: WeakObjectProperty)
    FFabricMetaSoundNodeInfo HarmonixMusicProviderNode() const { return Read<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x548); } // 0x548 (Size: 0xf0, Type: StructProperty)
    FFabricMetaSoundNodeInfo HarmonixMetronomeClockNode() const { return Read<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x638); } // 0x638 (Size: 0xf0, Type: StructProperty)
    FFabricMetaSoundNodeInfo HarmonixMidiTempoClockNode() const { return Read<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x728); } // 0x728 (Size: 0xf0, Type: StructProperty)
    FFabricMetaSoundNodeInfo HarmonixTransportNode() const { return Read<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x818); } // 0x818 (Size: 0xf0, Type: StructProperty)
    FMetaSoundBuilderNodeOutputHandle OnPlayNodeOutput() const { return Read<FMetaSoundBuilderNodeOutputHandle>(uintptr_t(this) + 0x908); } // 0x908 (Size: 0x20, Type: StructProperty)
    FMetaSoundBuilderNodeInputHandle OnFinishedNodeInput() const { return Read<FMetaSoundBuilderNodeInputHandle>(uintptr_t(this) + 0x928); } // 0x928 (Size: 0x20, Type: StructProperty)
    TArray<FMetaSoundBuilderNodeInputHandle> AudioOutNodeInputs() const { return Read<TArray<FMetaSoundBuilderNodeInputHandle>>(uintptr_t(this) + 0x948); } // 0x948 (Size: 0x10, Type: ArrayProperty)
    TMap<FFabricMetaSoundNodePool, UMetaSoundPatch*> FreeMetaSoundNodes() const { return Read<TMap<FFabricMetaSoundNodePool, UMetaSoundPatch*>>(uintptr_t(this) + 0x9a0); } // 0x9a0 (Size: 0x50, Type: MapProperty)
    TMap<FFabricLoadedUtilityPatches, FName> UtilityNodeTypesToPatches() const { return Read<TMap<FFabricLoadedUtilityPatches, FName>>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x50, Type: MapProperty)
    TMap<UFabricMetaSoundUtilityProviderPatchWrapper*, UClass*> UtilityProviderNodesInGraph() const { return Read<TMap<UFabricMetaSoundUtilityProviderPatchWrapper*, UClass*>>(uintptr_t(this) + 0xa40); } // 0xa40 (Size: 0x50, Type: MapProperty)
    bool bGraphDirty() const { return Read<bool>(uintptr_t(this) + 0xaa0); } // 0xaa0 (Size: 0x1, Type: BoolProperty)
    bool bIsAudioless() const { return Read<bool>(uintptr_t(this) + 0xaa1); } // 0xaa1 (Size: 0x1, Type: BoolProperty)
    bool bHasCompletedInitialCooldown() const { return Read<bool>(uintptr_t(this) + 0xaa2); } // 0xaa2 (Size: 0x1, Type: BoolProperty)
    uint8_t CurrentClockType() const { return Read<uint8_t>(uintptr_t(this) + 0xaa3); } // 0xaa3 (Size: 0x1, Type: EnumProperty)
    uint8_t DefaultClockType() const { return Read<uint8_t>(uintptr_t(this) + 0xaa4); } // 0xaa4 (Size: 0x1, Type: EnumProperty)
    uint8_t CurrentPlayState() const { return Read<uint8_t>(uintptr_t(this) + 0xaa5); } // 0xaa5 (Size: 0x1, Type: EnumProperty)
    uint8_t PlayStateAfterRebuild() const { return Read<uint8_t>(uintptr_t(this) + 0xaa6); } // 0xaa6 (Size: 0x1, Type: EnumProperty)
    uint8_t JamSyncType() const { return Read<uint8_t>(uintptr_t(this) + 0xaa7); } // 0xaa7 (Size: 0x1, Type: EnumProperty)
    uint8_t LastBroadcastBy() const { return Read<uint8_t>(uintptr_t(this) + 0xaaa); } // 0xaaa (Size: 0x1, Type: EnumProperty)

    void SET_HarmonixMusicProviderPatch(const TSoftObjectPtr<UMetaSoundPatch>& Value) { Write<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_HarmonixMetronomeClockPatch(const TSoftObjectPtr<UMetaSoundPatch>& Value) { Write<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_HarmonixTempoClockPatch(const TSoftObjectPtr<UMetaSoundPatch>& Value) { Write<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x20, Type: SoftObjectProperty)
    void SET_HarmonixTransportPatch(const TSoftObjectPtr<UMetaSoundPatch>& Value) { Write<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x20, Type: SoftObjectProperty)
    void SET_UserOptionConverterNode(const TSoftObjectPtr<UMetaSoundPatch>& Value) { Write<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MidiStreamUtilityPatches(const FFabricMetaSoundUtilityPatches& Value) { Write<FFabricMetaSoundUtilityPatches>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x88, Type: StructProperty)
    void SET_AudioUtilityPatches(const FFabricMetaSoundUtilityPatches& Value) { Write<FFabricMetaSoundUtilityPatches>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x88, Type: StructProperty)
    void SET_FloatUtilityPatches(const FFabricMetaSoundUtilityPatches& Value) { Write<FFabricMetaSoundUtilityPatches>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x88, Type: StructProperty)
    void SET_MusicProviderVolumeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x4, Type: NameProperty)
    void SET_MusicProviderRootNoteName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x304, Value); } // 0x304 (Size: 0x4, Type: NameProperty)
    void SET_MusicProviderScaleName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x4, Type: NameProperty)
    void SET_TransportProviderPlayTriggerName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x30c, Value); } // 0x30c (Size: 0x4, Type: NameProperty)
    void SET_TransportProviderDelayedRestartTriggerName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x4, Type: NameProperty)
    void SET_TransportProviderRestartTriggerName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x314, Value); } // 0x314 (Size: 0x4, Type: NameProperty)
    void SET_TransportProviderSeekTriggerName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x4, Type: NameProperty)
    void SET_TransportProviderPauseTriggerName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x31c, Value); } // 0x31c (Size: 0x4, Type: NameProperty)
    void SET_TransportProviderContinueTriggerName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x4, Type: NameProperty)
    void SET_TransportProviderStopTriggerName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x324, Value); } // 0x324 (Size: 0x4, Type: NameProperty)
    void SET_TransportProviderSeekTargetName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x4, Type: NameProperty)
    void SET_ClockProviderTempoName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x32c, Value); } // 0x32c (Size: 0x4, Type: NameProperty)
    void SET_ClockProviderSpeedName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x4, Type: NameProperty)
    void SET_ClockProviderTimeSigNumName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x334, Value); } // 0x334 (Size: 0x4, Type: NameProperty)
    void SET_ClockProviderTimeSignDenomName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x4, Type: NameProperty)
    void SET_ClockProviderMidiFileInName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x33c, Value); } // 0x33c (Size: 0x4, Type: NameProperty)
    void SET_ClockProviderLoopName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x4, Type: NameProperty)
    void SET_UserOptionConverterCountInName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x344, Value); } // 0x344 (Size: 0x4, Type: NameProperty)
    void SET_CrossfadeSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x4, Type: FloatProperty)
    void SET_RebuildTimeOutSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x34c, Value); } // 0x34c (Size: 0x4, Type: FloatProperty)
    void SET_BlockRateOverride(const float& Value) { Write<float>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x4, Type: FloatProperty)
    void SET_QualityOverride(const FName& Value) { Write<FName>(uintptr_t(this) + 0x354, Value); } // 0x354 (Size: 0x4, Type: NameProperty)
    void SET_DefaultMidiFile(const UMidiFile*& Value) { Write<UMidiFile*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_SignificanceRuntimeBuckets(const TArray<FFabricSignificanceBasedUpdateBucketRuntime>& Value) { Write<TArray<FFabricSignificanceBasedUpdateBucketRuntime>>(uintptr_t(this) + 0x428, Value); } // 0x428 (Size: 0x10, Type: ArrayProperty)
    void SET_SignificanceBasedUpdate(const UFabricSignificanceAsset*& Value) { Write<UFabricSignificanceAsset*>(uintptr_t(this) + 0x438, Value); } // 0x438 (Size: 0x8, Type: ObjectProperty)
    void SET_InitialCooldownTimeInSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x4, Type: FloatProperty)
    void SET_SourceBuilder(const UMetaSoundSourceBuilder*& Value) { Write<UMetaSoundSourceBuilder*>(uintptr_t(this) + 0x448, Value); } // 0x448 (Size: 0x8, Type: ObjectProperty)
    void SET_MusicClock(const UMusicClockComponent*& Value) { Write<UMusicClockComponent*>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x8, Type: ObjectProperty)
    void SET_PlaybackAudioComponents(const TArray<UAudioComponent*>& Value) { Write<TArray<UAudioComponent*>>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x10, Type: ArrayProperty)
    void SET_ServerPlaybackComponents(const TArray<UMetasoundOfflinePlayerComponent*>& Value) { Write<TArray<UMetasoundOfflinePlayerComponent*>>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentTransportRequestLock(const FFabricTransportRequestConfig& Value) { Write<FFabricTransportRequestConfig>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x8, Type: StructProperty)
    void SET_SortedRegisteredUtilityProviderAuthorities(const TArray<UFabricMetaSoundUtilityProviderPatchWrapper*>& Value) { Write<TArray<UFabricMetaSoundUtilityProviderPatchWrapper*>>(uintptr_t(this) + 0x528, Value); } // 0x528 (Size: 0x10, Type: ArrayProperty)
    void SET_ClockAuthorityLoopLength(const FMusicTimestamp& Value) { Write<FMusicTimestamp>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x8, Type: StructProperty)
    void SET_TempoMapMidiFile(const TWeakObjectPtr<UMidiFile*>& Value) { Write<TWeakObjectPtr<UMidiFile*>>(uintptr_t(this) + 0x540, Value); } // 0x540 (Size: 0x8, Type: WeakObjectProperty)
    void SET_HarmonixMusicProviderNode(const FFabricMetaSoundNodeInfo& Value) { Write<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x548, Value); } // 0x548 (Size: 0xf0, Type: StructProperty)
    void SET_HarmonixMetronomeClockNode(const FFabricMetaSoundNodeInfo& Value) { Write<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x638, Value); } // 0x638 (Size: 0xf0, Type: StructProperty)
    void SET_HarmonixMidiTempoClockNode(const FFabricMetaSoundNodeInfo& Value) { Write<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x728, Value); } // 0x728 (Size: 0xf0, Type: StructProperty)
    void SET_HarmonixTransportNode(const FFabricMetaSoundNodeInfo& Value) { Write<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x818, Value); } // 0x818 (Size: 0xf0, Type: StructProperty)
    void SET_OnPlayNodeOutput(const FMetaSoundBuilderNodeOutputHandle& Value) { Write<FMetaSoundBuilderNodeOutputHandle>(uintptr_t(this) + 0x908, Value); } // 0x908 (Size: 0x20, Type: StructProperty)
    void SET_OnFinishedNodeInput(const FMetaSoundBuilderNodeInputHandle& Value) { Write<FMetaSoundBuilderNodeInputHandle>(uintptr_t(this) + 0x928, Value); } // 0x928 (Size: 0x20, Type: StructProperty)
    void SET_AudioOutNodeInputs(const TArray<FMetaSoundBuilderNodeInputHandle>& Value) { Write<TArray<FMetaSoundBuilderNodeInputHandle>>(uintptr_t(this) + 0x948, Value); } // 0x948 (Size: 0x10, Type: ArrayProperty)
    void SET_FreeMetaSoundNodes(const TMap<FFabricMetaSoundNodePool, UMetaSoundPatch*>& Value) { Write<TMap<FFabricMetaSoundNodePool, UMetaSoundPatch*>>(uintptr_t(this) + 0x9a0, Value); } // 0x9a0 (Size: 0x50, Type: MapProperty)
    void SET_UtilityNodeTypesToPatches(const TMap<FFabricLoadedUtilityPatches, FName>& Value) { Write<TMap<FFabricLoadedUtilityPatches, FName>>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x50, Type: MapProperty)
    void SET_UtilityProviderNodesInGraph(const TMap<UFabricMetaSoundUtilityProviderPatchWrapper*, UClass*>& Value) { Write<TMap<UFabricMetaSoundUtilityProviderPatchWrapper*, UClass*>>(uintptr_t(this) + 0xa40, Value); } // 0xa40 (Size: 0x50, Type: MapProperty)
    void SET_bGraphDirty(const bool& Value) { Write<bool>(uintptr_t(this) + 0xaa0, Value); } // 0xaa0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsAudioless(const bool& Value) { Write<bool>(uintptr_t(this) + 0xaa1, Value); } // 0xaa1 (Size: 0x1, Type: BoolProperty)
    void SET_bHasCompletedInitialCooldown(const bool& Value) { Write<bool>(uintptr_t(this) + 0xaa2, Value); } // 0xaa2 (Size: 0x1, Type: BoolProperty)
    void SET_CurrentClockType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xaa3, Value); } // 0xaa3 (Size: 0x1, Type: EnumProperty)
    void SET_DefaultClockType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xaa4, Value); } // 0xaa4 (Size: 0x1, Type: EnumProperty)
    void SET_CurrentPlayState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xaa5, Value); } // 0xaa5 (Size: 0x1, Type: EnumProperty)
    void SET_PlayStateAfterRebuild(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xaa6, Value); } // 0xaa6 (Size: 0x1, Type: EnumProperty)
    void SET_JamSyncType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xaa7, Value); } // 0xaa7 (Size: 0x1, Type: EnumProperty)
    void SET_LastBroadcastBy(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xaaa, Value); } // 0xaaa (Size: 0x1, Type: EnumProperty)
};

// Size: 0x800
class UFabricNoteReceivedPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
    FName NoteOutputName() const { return Read<FName>(uintptr_t(this) + 0x798); } // 0x798 (Size: 0x4, Type: NameProperty)
    TArray<FString> TriggerNoteParams() const { return Read<TArray<FString>>(uintptr_t(this) + 0x7a0); } // 0x7a0 (Size: 0x10, Type: ArrayProperty)

    void SET_NoteOutputName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x798, Value); } // 0x798 (Size: 0x4, Type: NameProperty)
    void SET_TriggerNoteParams(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x7a0, Value); } // 0x7a0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x830
class UFabricNoteTriggerPatchWrapper : public UFabricNoteReceivedPatchWrapper
{
public:
    FString OctaveParam() const { return Read<FString>(uintptr_t(this) + 0x800); } // 0x800 (Size: 0x10, Type: StrProperty)
    int32_t MaxOctave() const { return Read<int32_t>(uintptr_t(this) + 0x810); } // 0x810 (Size: 0x4, Type: IntProperty)

    void SET_OctaveParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x800, Value); } // 0x800 (Size: 0x10, Type: StrProperty)
    void SET_MaxOctave(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x810, Value); } // 0x810 (Size: 0x4, Type: IntProperty)
};

// Size: 0x50
class UFabricMetaSoundTreeNode : public UObject
{
public:
    uint8_t PinDirection() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    UFabricMetaSoundPatchWrapper* AssociatedPatchWrapper() const { return Read<UFabricMetaSoundPatchWrapper*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    TArray<UFabricMetaSoundTreeNode*> Children() const { return Read<TArray<UFabricMetaSoundTreeNode*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    uint8_t MaxAttenuation() const { return Read<uint8_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: EnumProperty)

    void SET_PinDirection(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_AssociatedPatchWrapper(const UFabricMetaSoundPatchWrapper*& Value) { Write<UFabricMetaSoundPatchWrapper*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_Children(const TArray<UFabricMetaSoundTreeNode*>& Value) { Write<TArray<UFabricMetaSoundTreeNode*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_MaxAttenuation(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x7a0
class UFabricMetaSoundSequencerPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
    UMidiStepSequence* CurrentStepSequence() const { return Read<UMidiStepSequence*>(uintptr_t(this) + 0x798); } // 0x798 (Size: 0x8, Type: ObjectProperty)

    void SET_CurrentStepSequence(const UMidiStepSequence*& Value) { Write<UMidiStepSequence*>(uintptr_t(this) + 0x798, Value); } // 0x798 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x830
class UFabricMetaSoundSpeakerPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
    TArray<FFabricMetaSoundSpeakerPatchWrapperEqBandsBinding> EqBands() const { return Read<TArray<FFabricMetaSoundSpeakerPatchWrapperEqBandsBinding>>(uintptr_t(this) + 0x798); } // 0x798 (Size: 0x10, Type: ArrayProperty)
    FFabricMetaSoundPatchWrapperBinding AudioPeak() const { return Read<FFabricMetaSoundPatchWrapperBinding>(uintptr_t(this) + 0x7a8); } // 0x7a8 (Size: 0x50, Type: StructProperty)

    void SET_EqBands(const TArray<FFabricMetaSoundSpeakerPatchWrapperEqBandsBinding>& Value) { Write<TArray<FFabricMetaSoundSpeakerPatchWrapperEqBandsBinding>>(uintptr_t(this) + 0x798, Value); } // 0x798 (Size: 0x10, Type: ArrayProperty)
    void SET_AudioPeak(const FFabricMetaSoundPatchWrapperBinding& Value) { Write<FFabricMetaSoundPatchWrapperBinding>(uintptr_t(this) + 0x7a8, Value); } // 0x7a8 (Size: 0x50, Type: StructProperty)
};

// Size: 0x7f0
class UFabricMetaSoundSplitterPatchWrapper : public UFabricMetaSoundPatchWrapper
{
public:
    TMap<FFabricMetaSoundNodeInfo, FName> SplitterNodes() const { return Read<TMap<FFabricMetaSoundNodeInfo, FName>>(uintptr_t(this) + 0x7a0); } // 0x7a0 (Size: 0x50, Type: MapProperty)

    void SET_SplitterNodes(const TMap<FFabricMetaSoundNodeInfo, FName>& Value) { Write<TMap<FFabricMetaSoundNodeInfo, FName>>(uintptr_t(this) + 0x7a0, Value); } // 0x7a0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x2b0
class UFabricMetaSoundTickSubsystem : public UFortManagedTickSubsystem
{
public:
};

// Size: 0x1a8
class UFabricMetaSoundUtilityProviderPatchWrapper : public UObject
{
public:
    TSoftObjectPtr<UMetaSoundPatch> MetaSoundPatch() const { return Read<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    bool bUseAsMusicProvider() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    bool bUseAsClockProvider() const { return Read<bool>(uintptr_t(this) + 0x51); } // 0x51 (Size: 0x1, Type: BoolProperty)
    bool bUseAsTransportProvider() const { return Read<bool>(uintptr_t(this) + 0x52); } // 0x52 (Size: 0x1, Type: BoolProperty)
    bool bManagesOwnMusicState() const { return Read<bool>(uintptr_t(this) + 0x53); } // 0x53 (Size: 0x1, Type: BoolProperty)
    int32_t Priority() const { return Read<int32_t>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: IntProperty)
    bool bRunsOnServer() const { return Read<bool>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x1, Type: BoolProperty)
    UFabricMetaSoundManagerComponent* CurrentManager() const { return Read<UFabricMetaSoundManagerComponent*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    FFabricMetaSoundNodeInfo CurrentNode() const { return Read<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0xf0, Type: StructProperty)
    TWeakObjectPtr<UAudioComponent*> CurrentAudioComponent() const { return Read<TWeakObjectPtr<UAudioComponent*>>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x8, Type: WeakObjectProperty)
    FFabricTransportRequestConfig TransportRequestConfig() const { return Read<FFabricTransportRequestConfig>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x8, Type: StructProperty)
    UMetaSoundPatch* LoadedMetaSoundPatch() const { return Read<UMetaSoundPatch*>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x8, Type: ObjectProperty)

    void SET_MetaSoundPatch(const TSoftObjectPtr<UMetaSoundPatch>& Value) { Write<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    void SET_bUseAsMusicProvider(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_bUseAsClockProvider(const bool& Value) { Write<bool>(uintptr_t(this) + 0x51, Value); } // 0x51 (Size: 0x1, Type: BoolProperty)
    void SET_bUseAsTransportProvider(const bool& Value) { Write<bool>(uintptr_t(this) + 0x52, Value); } // 0x52 (Size: 0x1, Type: BoolProperty)
    void SET_bManagesOwnMusicState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x53, Value); } // 0x53 (Size: 0x1, Type: BoolProperty)
    void SET_Priority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: IntProperty)
    void SET_bRunsOnServer(const bool& Value) { Write<bool>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x1, Type: BoolProperty)
    void SET_CurrentManager(const UFabricMetaSoundManagerComponent*& Value) { Write<UFabricMetaSoundManagerComponent*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentNode(const FFabricMetaSoundNodeInfo& Value) { Write<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0xf0, Type: StructProperty)
    void SET_CurrentAudioComponent(const TWeakObjectPtr<UAudioComponent*>& Value) { Write<TWeakObjectPtr<UAudioComponent*>>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x8, Type: WeakObjectProperty)
    void SET_TransportRequestConfig(const FFabricTransportRequestConfig& Value) { Write<FFabricTransportRequestConfig>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x8, Type: StructProperty)
    void SET_LoadedMetaSoundPatch(const UMetaSoundPatch*& Value) { Write<UMetaSoundPatch*>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x160
class UFabricMidiFollowComponent : public UActorComponent
{
public:
    FMusicTimestamp SelectedMidiTrackStartTimestamp() const { return Read<FMusicTimestamp>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: StructProperty)
    FMusicTimestamp ExternalSourceStartTimestamp() const { return Read<FMusicTimestamp>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: StructProperty)
    FMusicTimestamp SelectedMidiTrackEndTimestamp() const { return Read<FMusicTimestamp>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x8, Type: StructProperty)
    FMusicTimestamp ExternalSourceEndTimestamp() const { return Read<FMusicTimestamp>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x8, Type: StructProperty)
    FMidiFollowData MidiFollowData() const { return Read<FMidiFollowData>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: StructProperty)
    uint8_t DesiredLoopBehaviour() const { return Read<uint8_t>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x1, Type: EnumProperty)

    void SET_SelectedMidiTrackStartTimestamp(const FMusicTimestamp& Value) { Write<FMusicTimestamp>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: StructProperty)
    void SET_ExternalSourceStartTimestamp(const FMusicTimestamp& Value) { Write<FMusicTimestamp>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: StructProperty)
    void SET_SelectedMidiTrackEndTimestamp(const FMusicTimestamp& Value) { Write<FMusicTimestamp>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x8, Type: StructProperty)
    void SET_ExternalSourceEndTimestamp(const FMusicTimestamp& Value) { Write<FMusicTimestamp>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x8, Type: StructProperty)
    void SET_MidiFollowData(const FMidiFollowData& Value) { Write<FMidiFollowData>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: StructProperty)
    void SET_DesiredLoopBehaviour(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x830
class UFabricMIDIPlayerPatchWrapper : public UFabricNoteReceivedPatchWrapper
{
public:
    FName MidiTrackIndexUserOptionName() const { return Read<FName>(uintptr_t(this) + 0x800); } // 0x800 (Size: 0x4, Type: NameProperty)
    FName EnableMidiOutputName() const { return Read<FName>(uintptr_t(this) + 0x804); } // 0x804 (Size: 0x4, Type: NameProperty)
    FName TempoMapMidiOutName() const { return Read<FName>(uintptr_t(this) + 0x808); } // 0x808 (Size: 0x4, Type: NameProperty)
    UMidiFile* CurrentMidiFile() const { return Read<UMidiFile*>(uintptr_t(this) + 0x810); } // 0x810 (Size: 0x8, Type: ObjectProperty)
    FName MidiTrackName() const { return Read<FName>(uintptr_t(this) + 0x818); } // 0x818 (Size: 0x4, Type: NameProperty)

    void SET_MidiTrackIndexUserOptionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x800, Value); } // 0x800 (Size: 0x4, Type: NameProperty)
    void SET_EnableMidiOutputName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x804, Value); } // 0x804 (Size: 0x4, Type: NameProperty)
    void SET_TempoMapMidiOutName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x808, Value); } // 0x808 (Size: 0x4, Type: NameProperty)
    void SET_CurrentMidiFile(const UMidiFile*& Value) { Write<UMidiFile*>(uintptr_t(this) + 0x810, Value); } // 0x810 (Size: 0x8, Type: ObjectProperty)
    void SET_MidiTrackName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x818, Value); } // 0x818 (Size: 0x4, Type: NameProperty)
};

// Size: 0x28
class UFabricMidiProvider : public UInterface
{
public:
};

// Size: 0x28
class UFabricModulator : public UInterface
{
public:
};

// Size: 0x28
class UFabricModulatorSource : public UInterface
{
public:
};

// Size: 0x28
class UFabricModulatorDevice : public UInterface
{
public:
};

// Size: 0x118
class UFabricProgressorManager : public UActorComponent
{
public:
    bool bHasActiveGlobalProgression() const { return Read<bool>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    bool bInPlayMode() const { return Read<bool>(uintptr_t(this) + 0xd1); } // 0xd1 (Size: 0x1, Type: BoolProperty)
    int32_t GlobalPresetNumber() const { return Read<int32_t>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: IntProperty)
    FFabricProgressionPreset GlobalProgression() const { return Read<FFabricProgressionPreset>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x20, Type: StructProperty)
    FFabricProgressionPreset StoredGlobalProgression() const { return Read<FFabricProgressionPreset>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x20, Type: StructProperty)

    void SET_bHasActiveGlobalProgression(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    void SET_bInPlayMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd1, Value); } // 0xd1 (Size: 0x1, Type: BoolProperty)
    void SET_GlobalPresetNumber(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: IntProperty)
    void SET_GlobalProgression(const FFabricProgressionPreset& Value) { Write<FFabricProgressionPreset>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x20, Type: StructProperty)
    void SET_StoredGlobalProgression(const FFabricProgressionPreset& Value) { Write<FFabricProgressionPreset>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x20, Type: StructProperty)
};

// Size: 0xa40
class UFabricSequencerPreviewFXComponent : public UFabricSteppedPreviewFXComponent
{
public:
    TWeakObjectPtr<UFabricStepSequencerComponent*> StepSequencer() const { return Read<TWeakObjectPtr<UFabricStepSequencerComponent*>>(uintptr_t(this) + 0xa28); } // 0xa28 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFabricStepSequencerGridComponent*> StepSequencerGrid() const { return Read<TWeakObjectPtr<UFabricStepSequencerGridComponent*>>(uintptr_t(this) + 0xa30); } // 0xa30 (Size: 0x8, Type: WeakObjectProperty)

    void SET_StepSequencer(const TWeakObjectPtr<UFabricStepSequencerComponent*>& Value) { Write<TWeakObjectPtr<UFabricStepSequencerComponent*>>(uintptr_t(this) + 0xa28, Value); } // 0xa28 (Size: 0x8, Type: WeakObjectProperty)
    void SET_StepSequencerGrid(const TWeakObjectPtr<UFabricStepSequencerGridComponent*>& Value) { Write<TWeakObjectPtr<UFabricStepSequencerGridComponent*>>(uintptr_t(this) + 0xa30, Value); } // 0xa30 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xa30
class UFabricSteppedPreviewFXComponent : public UInstancedStaticMeshComponent
{
public:
    int32_t NumberOfSteps() const { return Read<int32_t>(uintptr_t(this) + 0x9a0); } // 0x9a0 (Size: 0x4, Type: IntProperty)
    bool bManuallySpaceMeshInstances() const { return Read<bool>(uintptr_t(this) + 0x9a4); } // 0x9a4 (Size: 0x1, Type: BoolProperty)
    bool bAllowMultipleRows() const { return Read<bool>(uintptr_t(this) + 0x9a5); } // 0x9a5 (Size: 0x1, Type: BoolProperty)
    int32_t InstanceCountPerRow() const { return Read<int32_t>(uintptr_t(this) + 0x9a8); } // 0x9a8 (Size: 0x4, Type: IntProperty)
    float SpaceBetweenInstanceRows() const { return Read<float>(uintptr_t(this) + 0x9ac); } // 0x9ac (Size: 0x4, Type: FloatProperty)
    bool bAlignToTransformCenter() const { return Read<bool>(uintptr_t(this) + 0x9b0); } // 0x9b0 (Size: 0x1, Type: BoolProperty)
    float CenterAlignmentBounds() const { return Read<float>(uintptr_t(this) + 0x9b4); } // 0x9b4 (Size: 0x4, Type: FloatProperty)
    float DistanceBetweenInstances() const { return Read<float>(uintptr_t(this) + 0x9b8); } // 0x9b8 (Size: 0x4, Type: FloatProperty)
    float DistanceBetweenTripletInstances() const { return Read<float>(uintptr_t(this) + 0x9bc); } // 0x9bc (Size: 0x4, Type: FloatProperty)
    float DistanceBetweenInstanceSets() const { return Read<float>(uintptr_t(this) + 0x9c0); } // 0x9c0 (Size: 0x4, Type: FloatProperty)
    float DistanceBetweenTripletInstanceSets() const { return Read<float>(uintptr_t(this) + 0x9c4); } // 0x9c4 (Size: 0x4, Type: FloatProperty)
    uint8_t NoteStyle() const { return Read<uint8_t>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x1, Type: EnumProperty)
    int32_t CPDDeviceEnabled() const { return Read<int32_t>(uintptr_t(this) + 0x9cc); } // 0x9cc (Size: 0x4, Type: IntProperty)
    int32_t CPDNumSteps() const { return Read<int32_t>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x4, Type: IntProperty)
    int32_t PICDNoteOn() const { return Read<int32_t>(uintptr_t(this) + 0x9d4); } // 0x9d4 (Size: 0x4, Type: IntProperty)
    int32_t PICDNoteLength() const { return Read<int32_t>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x4, Type: IntProperty)
    int32_t PICDSpanLength() const { return Read<int32_t>(uintptr_t(this) + 0x9dc); } // 0x9dc (Size: 0x4, Type: IntProperty)
    int32_t PICDNoteTime() const { return Read<int32_t>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x4, Type: IntProperty)
    int32_t PICDGenericFloatIndex() const { return Read<int32_t>(uintptr_t(this) + 0x9e4); } // 0x9e4 (Size: 0x4, Type: IntProperty)
    float LengthStepBeats() const { return Read<float>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x4, Type: FloatProperty)
    float StepRate() const { return Read<float>(uintptr_t(this) + 0x9ec); } // 0x9ec (Size: 0x4, Type: FloatProperty)
    float StepBeatScale() const { return Read<float>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x4, Type: FloatProperty)
    float StepBeatOffset() const { return Read<float>(uintptr_t(this) + 0x9f4); } // 0x9f4 (Size: 0x4, Type: FloatProperty)
    int32_t TimeSignatureNumerator() const { return Read<int32_t>(uintptr_t(this) + 0x9f8); } // 0x9f8 (Size: 0x4, Type: IntProperty)
    int32_t TimeSignatureDenominator() const { return Read<int32_t>(uintptr_t(this) + 0x9fc); } // 0x9fc (Size: 0x4, Type: IntProperty)
    float LengthTrackBeats() const { return Read<float>(uintptr_t(this) + 0xa00); } // 0xa00 (Size: 0x4, Type: FloatProperty)
    double InstanceSpace() const { return Read<double>(uintptr_t(this) + 0xa08); } // 0xa08 (Size: 0x8, Type: DoubleProperty)
    double InstanceSetSpace() const { return Read<double>(uintptr_t(this) + 0xa10); } // 0xa10 (Size: 0x8, Type: DoubleProperty)

    void SET_NumberOfSteps(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9a0, Value); } // 0x9a0 (Size: 0x4, Type: IntProperty)
    void SET_bManuallySpaceMeshInstances(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9a4, Value); } // 0x9a4 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowMultipleRows(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9a5, Value); } // 0x9a5 (Size: 0x1, Type: BoolProperty)
    void SET_InstanceCountPerRow(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9a8, Value); } // 0x9a8 (Size: 0x4, Type: IntProperty)
    void SET_SpaceBetweenInstanceRows(const float& Value) { Write<float>(uintptr_t(this) + 0x9ac, Value); } // 0x9ac (Size: 0x4, Type: FloatProperty)
    void SET_bAlignToTransformCenter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9b0, Value); } // 0x9b0 (Size: 0x1, Type: BoolProperty)
    void SET_CenterAlignmentBounds(const float& Value) { Write<float>(uintptr_t(this) + 0x9b4, Value); } // 0x9b4 (Size: 0x4, Type: FloatProperty)
    void SET_DistanceBetweenInstances(const float& Value) { Write<float>(uintptr_t(this) + 0x9b8, Value); } // 0x9b8 (Size: 0x4, Type: FloatProperty)
    void SET_DistanceBetweenTripletInstances(const float& Value) { Write<float>(uintptr_t(this) + 0x9bc, Value); } // 0x9bc (Size: 0x4, Type: FloatProperty)
    void SET_DistanceBetweenInstanceSets(const float& Value) { Write<float>(uintptr_t(this) + 0x9c0, Value); } // 0x9c0 (Size: 0x4, Type: FloatProperty)
    void SET_DistanceBetweenTripletInstanceSets(const float& Value) { Write<float>(uintptr_t(this) + 0x9c4, Value); } // 0x9c4 (Size: 0x4, Type: FloatProperty)
    void SET_NoteStyle(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x1, Type: EnumProperty)
    void SET_CPDDeviceEnabled(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9cc, Value); } // 0x9cc (Size: 0x4, Type: IntProperty)
    void SET_CPDNumSteps(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x4, Type: IntProperty)
    void SET_PICDNoteOn(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9d4, Value); } // 0x9d4 (Size: 0x4, Type: IntProperty)
    void SET_PICDNoteLength(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x4, Type: IntProperty)
    void SET_PICDSpanLength(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9dc, Value); } // 0x9dc (Size: 0x4, Type: IntProperty)
    void SET_PICDNoteTime(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x4, Type: IntProperty)
    void SET_PICDGenericFloatIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9e4, Value); } // 0x9e4 (Size: 0x4, Type: IntProperty)
    void SET_LengthStepBeats(const float& Value) { Write<float>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x4, Type: FloatProperty)
    void SET_StepRate(const float& Value) { Write<float>(uintptr_t(this) + 0x9ec, Value); } // 0x9ec (Size: 0x4, Type: FloatProperty)
    void SET_StepBeatScale(const float& Value) { Write<float>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x4, Type: FloatProperty)
    void SET_StepBeatOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x9f4, Value); } // 0x9f4 (Size: 0x4, Type: FloatProperty)
    void SET_TimeSignatureNumerator(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9f8, Value); } // 0x9f8 (Size: 0x4, Type: IntProperty)
    void SET_TimeSignatureDenominator(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9fc, Value); } // 0x9fc (Size: 0x4, Type: IntProperty)
    void SET_LengthTrackBeats(const float& Value) { Write<float>(uintptr_t(this) + 0xa00, Value); } // 0xa00 (Size: 0x4, Type: FloatProperty)
    void SET_InstanceSpace(const double& Value) { Write<double>(uintptr_t(this) + 0xa08, Value); } // 0xa08 (Size: 0x8, Type: DoubleProperty)
    void SET_InstanceSetSpace(const double& Value) { Write<double>(uintptr_t(this) + 0xa10, Value); } // 0xa10 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0xa20
class UFabricSequencerSustainComponent : public UInstancedStaticMeshComponent
{
public:
    TMap<int32_t, FIntVector2> StepToInstanceMapping() const { return Read<TMap<int32_t, FIntVector2>>(uintptr_t(this) + 0x9a0); } // 0x9a0 (Size: 0x50, Type: MapProperty)
    int32_t PICDStartBeat() const { return Read<int32_t>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x4, Type: IntProperty)
    int32_t PICDEndBeat() const { return Read<int32_t>(uintptr_t(this) + 0x9f4); } // 0x9f4 (Size: 0x4, Type: IntProperty)
    int32_t PICDLoopBeat() const { return Read<int32_t>(uintptr_t(this) + 0x9f8); } // 0x9f8 (Size: 0x4, Type: IntProperty)
    int32_t CPDDeviceEnabled() const { return Read<int32_t>(uintptr_t(this) + 0x9fc); } // 0x9fc (Size: 0x4, Type: IntProperty)
    float GridSquareExtents() const { return Read<float>(uintptr_t(this) + 0xa00); } // 0xa00 (Size: 0x4, Type: FloatProperty)
    float SustainInstanceYLocation() const { return Read<float>(uintptr_t(this) + 0xa04); } // 0xa04 (Size: 0x4, Type: FloatProperty)
    float SustainInstanceYScale() const { return Read<float>(uintptr_t(this) + 0xa08); } // 0xa08 (Size: 0x4, Type: FloatProperty)
    float SustainInstanceZScale() const { return Read<float>(uintptr_t(this) + 0xa0c); } // 0xa0c (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UFabricStepSequencerComponent*> StepSequencer() const { return Read<TWeakObjectPtr<UFabricStepSequencerComponent*>>(uintptr_t(this) + 0xa10); } // 0xa10 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFabricStepSequencerGridComponent*> StepSequencerGrid() const { return Read<TWeakObjectPtr<UFabricStepSequencerGridComponent*>>(uintptr_t(this) + 0xa18); } // 0xa18 (Size: 0x8, Type: WeakObjectProperty)

    void SET_StepToInstanceMapping(const TMap<int32_t, FIntVector2>& Value) { Write<TMap<int32_t, FIntVector2>>(uintptr_t(this) + 0x9a0, Value); } // 0x9a0 (Size: 0x50, Type: MapProperty)
    void SET_PICDStartBeat(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x4, Type: IntProperty)
    void SET_PICDEndBeat(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9f4, Value); } // 0x9f4 (Size: 0x4, Type: IntProperty)
    void SET_PICDLoopBeat(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9f8, Value); } // 0x9f8 (Size: 0x4, Type: IntProperty)
    void SET_CPDDeviceEnabled(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9fc, Value); } // 0x9fc (Size: 0x4, Type: IntProperty)
    void SET_GridSquareExtents(const float& Value) { Write<float>(uintptr_t(this) + 0xa00, Value); } // 0xa00 (Size: 0x4, Type: FloatProperty)
    void SET_SustainInstanceYLocation(const float& Value) { Write<float>(uintptr_t(this) + 0xa04, Value); } // 0xa04 (Size: 0x4, Type: FloatProperty)
    void SET_SustainInstanceYScale(const float& Value) { Write<float>(uintptr_t(this) + 0xa08, Value); } // 0xa08 (Size: 0x4, Type: FloatProperty)
    void SET_SustainInstanceZScale(const float& Value) { Write<float>(uintptr_t(this) + 0xa0c, Value); } // 0xa0c (Size: 0x4, Type: FloatProperty)
    void SET_StepSequencer(const TWeakObjectPtr<UFabricStepSequencerComponent*>& Value) { Write<TWeakObjectPtr<UFabricStepSequencerComponent*>>(uintptr_t(this) + 0xa10, Value); } // 0xa10 (Size: 0x8, Type: WeakObjectProperty)
    void SET_StepSequencerGrid(const TWeakObjectPtr<UFabricStepSequencerGridComponent*>& Value) { Write<TWeakObjectPtr<UFabricStepSequencerGridComponent*>>(uintptr_t(this) + 0xa18, Value); } // 0xa18 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x40
class UFabricSignificanceAsset : public UDataAsset
{
public:
    TArray<FFabricSignificanceBasedUpdateBucket> UpdateBuckets() const { return Read<TArray<FFabricSignificanceBasedUpdateBucket>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_UpdateBuckets(const TArray<FFabricSignificanceBasedUpdateBucket>& Value) { Write<TArray<FFabricSignificanceBasedUpdateBucket>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x110
class UFabricSpeakerManagerComponent : public UActorComponent
{
public:
    uint8_t MusicEventPriority() const { return Read<uint8_t>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x1, Type: EnumProperty)
    FName ClientCurrentAudibleMusicEventGroup() const { return Read<FName>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x4, Type: NameProperty)
    FGameplayTag AboveEmotesTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: StructProperty)
    FGameplayTag BelowEmotesTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: StructProperty)
    float ReplicatedReceivedSignalBufferDuration() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)

    void SET_MusicEventPriority(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x1, Type: EnumProperty)
    void SET_ClientCurrentAudibleMusicEventGroup(const FName& Value) { Write<FName>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x4, Type: NameProperty)
    void SET_AboveEmotesTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: StructProperty)
    void SET_BelowEmotesTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: StructProperty)
    void SET_ReplicatedReceivedSignalBufferDuration(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x3b0
class UFabricStepSequencerModulatable : public UFabricModulatable
{
public:
    bool bIsChromatic() const { return Read<bool>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x1, Type: BoolProperty)
    bool bModulationValueChanged() const { return Read<bool>(uintptr_t(this) + 0x3a9); } // 0x3a9 (Size: 0x1, Type: BoolProperty)

    void SET_bIsChromatic(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x1, Type: BoolProperty)
    void SET_bModulationValueChanged(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3a9, Value); } // 0x3a9 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x368
class UFabricStepSequencerComponent : public UActorComponent
{
public:
    FString LengthParam() const { return Read<FString>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x10, Type: StrProperty)
    FString DurationParam() const { return Read<FString>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x10, Type: StrProperty)
    FString PageParam() const { return Read<FString>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x10, Type: StrProperty)
    FString AutoPageParam() const { return Read<FString>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x10, Type: StrProperty)
    FString OctaveParam() const { return Read<FString>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x10, Type: StrProperty)
    FString NoteStyleParam() const { return Read<FString>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x10, Type: StrProperty)
    FString LoopParam() const { return Read<FString>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x10, Type: StrProperty)
    FString AutoPagePlaysBlankPagesParam() const { return Read<FString>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x10, Type: StrProperty)
    bool bMonophonic() const { return Read<bool>(uintptr_t(this) + 0x208); } // 0x208 (Size: 0x1, Type: BoolProperty)
    bool bSupportsContinuation() const { return Read<bool>(uintptr_t(this) + 0x209); } // 0x209 (Size: 0x1, Type: BoolProperty)
    float StepRate() const { return Read<float>(uintptr_t(this) + 0x20c); } // 0x20c (Size: 0x4, Type: FloatProperty)
    float StepBeatScale() const { return Read<float>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x4, Type: FloatProperty)
    bool bSkipFourthStepInTriplet() const { return Read<bool>(uintptr_t(this) + 0x214); } // 0x214 (Size: 0x1, Type: BoolProperty)
    uint8_t NoteStyle() const { return Read<uint8_t>(uintptr_t(this) + 0x215); } // 0x215 (Size: 0x1, Type: EnumProperty)
    int32_t MaxSteps() const { return Read<int32_t>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x4, Type: IntProperty)
    int32_t CurrentSteps() const { return Read<int32_t>(uintptr_t(this) + 0x21c); } // 0x21c (Size: 0x4, Type: IntProperty)
    bool bMatchStepsToTimeSignature() const { return Read<bool>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x1, Type: BoolProperty)
    int32_t MaxPages() const { return Read<int32_t>(uintptr_t(this) + 0x224); } // 0x224 (Size: 0x4, Type: IntProperty)
    int32_t CurrentPage() const { return Read<int32_t>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x4, Type: IntProperty)
    int32_t MaxTracks() const { return Read<int32_t>(uintptr_t(this) + 0x22c); } // 0x22c (Size: 0x4, Type: IntProperty)
    int32_t CurrentTracks() const { return Read<int32_t>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x4, Type: IntProperty)
    int32_t LocalInteractionStartTrackIndex() const { return Read<int32_t>(uintptr_t(this) + 0x234); } // 0x234 (Size: 0x4, Type: IntProperty)
    int32_t LocalInteractionStartStepIndex() const { return Read<int32_t>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x4, Type: IntProperty)
    bool bAutoPage() const { return Read<bool>(uintptr_t(this) + 0x23c); } // 0x23c (Size: 0x1, Type: BoolProperty)
    bool bAutoPagePlaysBlankPages() const { return Read<bool>(uintptr_t(this) + 0x23d); } // 0x23d (Size: 0x1, Type: BoolProperty)
    bool bLoop() const { return Read<bool>(uintptr_t(this) + 0x23e); } // 0x23e (Size: 0x1, Type: BoolProperty)
    char RandomizationCommonSampleSize() const { return Read<char>(uintptr_t(this) + 0x23f); } // 0x23f (Size: 0x1, Type: ByteProperty)
    float RandomizationRestSelectionMaxPct() const { return Read<float>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x4, Type: FloatProperty)
    float RandomizationCommonPitchSelectionMaxPct() const { return Read<float>(uintptr_t(this) + 0x244); } // 0x244 (Size: 0x4, Type: FloatProperty)
    UClass* ContinuationControlClass() const { return Read<UClass*>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x8, Type: ClassProperty)
    FStepSequenceTable LocalStepTable() const { return Read<FStepSequenceTable>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x28, Type: StructProperty)
    FFabricStepTablePacked PackedStepTable() const { return Read<FFabricStepTablePacked>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x28, Type: StructProperty)
    UFabricStepSequencerModulatable* StepSequencerModulatable() const { return Read<UFabricStepSequencerModulatable*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    AActor* CachedContinuationControl() const { return Read<AActor*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    int32_t ContinuationRowIndex() const { return Read<int32_t>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x4, Type: IntProperty)
    int32_t ContinuationStepIndex() const { return Read<int32_t>(uintptr_t(this) + 0x2dc); } // 0x2dc (Size: 0x4, Type: IntProperty)
    UMidiStepSequence* MetaSoundMidiStepSequence() const { return Read<UMidiStepSequence*>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)

    void SET_LengthParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x10, Type: StrProperty)
    void SET_DurationParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x10, Type: StrProperty)
    void SET_PageParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x10, Type: StrProperty)
    void SET_AutoPageParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x10, Type: StrProperty)
    void SET_OctaveParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x10, Type: StrProperty)
    void SET_NoteStyleParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x10, Type: StrProperty)
    void SET_LoopParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x10, Type: StrProperty)
    void SET_AutoPagePlaysBlankPagesParam(const FString& Value) { Write<FString>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x10, Type: StrProperty)
    void SET_bMonophonic(const bool& Value) { Write<bool>(uintptr_t(this) + 0x208, Value); } // 0x208 (Size: 0x1, Type: BoolProperty)
    void SET_bSupportsContinuation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x209, Value); } // 0x209 (Size: 0x1, Type: BoolProperty)
    void SET_StepRate(const float& Value) { Write<float>(uintptr_t(this) + 0x20c, Value); } // 0x20c (Size: 0x4, Type: FloatProperty)
    void SET_StepBeatScale(const float& Value) { Write<float>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x4, Type: FloatProperty)
    void SET_bSkipFourthStepInTriplet(const bool& Value) { Write<bool>(uintptr_t(this) + 0x214, Value); } // 0x214 (Size: 0x1, Type: BoolProperty)
    void SET_NoteStyle(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x215, Value); } // 0x215 (Size: 0x1, Type: EnumProperty)
    void SET_MaxSteps(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x4, Type: IntProperty)
    void SET_CurrentSteps(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x21c, Value); } // 0x21c (Size: 0x4, Type: IntProperty)
    void SET_bMatchStepsToTimeSignature(const bool& Value) { Write<bool>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x1, Type: BoolProperty)
    void SET_MaxPages(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x224, Value); } // 0x224 (Size: 0x4, Type: IntProperty)
    void SET_CurrentPage(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x4, Type: IntProperty)
    void SET_MaxTracks(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x22c, Value); } // 0x22c (Size: 0x4, Type: IntProperty)
    void SET_CurrentTracks(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x4, Type: IntProperty)
    void SET_LocalInteractionStartTrackIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x234, Value); } // 0x234 (Size: 0x4, Type: IntProperty)
    void SET_LocalInteractionStartStepIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x4, Type: IntProperty)
    void SET_bAutoPage(const bool& Value) { Write<bool>(uintptr_t(this) + 0x23c, Value); } // 0x23c (Size: 0x1, Type: BoolProperty)
    void SET_bAutoPagePlaysBlankPages(const bool& Value) { Write<bool>(uintptr_t(this) + 0x23d, Value); } // 0x23d (Size: 0x1, Type: BoolProperty)
    void SET_bLoop(const bool& Value) { Write<bool>(uintptr_t(this) + 0x23e, Value); } // 0x23e (Size: 0x1, Type: BoolProperty)
    void SET_RandomizationCommonSampleSize(const char& Value) { Write<char>(uintptr_t(this) + 0x23f, Value); } // 0x23f (Size: 0x1, Type: ByteProperty)
    void SET_RandomizationRestSelectionMaxPct(const float& Value) { Write<float>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x4, Type: FloatProperty)
    void SET_RandomizationCommonPitchSelectionMaxPct(const float& Value) { Write<float>(uintptr_t(this) + 0x244, Value); } // 0x244 (Size: 0x4, Type: FloatProperty)
    void SET_ContinuationControlClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x8, Type: ClassProperty)
    void SET_LocalStepTable(const FStepSequenceTable& Value) { Write<FStepSequenceTable>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x28, Type: StructProperty)
    void SET_PackedStepTable(const FFabricStepTablePacked& Value) { Write<FFabricStepTablePacked>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x28, Type: StructProperty)
    void SET_StepSequencerModulatable(const UFabricStepSequencerModulatable*& Value) { Write<UFabricStepSequencerModulatable*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedContinuationControl(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    void SET_ContinuationRowIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x4, Type: IntProperty)
    void SET_ContinuationStepIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2dc, Value); } // 0x2dc (Size: 0x4, Type: IntProperty)
    void SET_MetaSoundMidiStepSequence(const UMidiStepSequence*& Value) { Write<UMidiStepSequence*>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x340
class UFabricStepSequencerGridComponent : public USceneComponent
{
public:
    FVector2D GridExtents() const { return Read<FVector2D>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x10, Type: StructProperty)
    FVector2D GridSpacing() const { return Read<FVector2D>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x10, Type: StructProperty)
    int32_t SingleTrackNumItemsPerRow() const { return Read<int32_t>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x4, Type: IntProperty)
    FVector2D EditorPreviewGridSize() const { return Read<FVector2D>(uintptr_t(this) + 0x278); } // 0x278 (Size: 0x10, Type: StructProperty)
    UClass* GridSquareClassPtr() const { return Read<UClass*>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<ESequencerType> SequencerType() const { return Read<TEnumAsByte<ESequencerType>>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x1, Type: ByteProperty)
    int32_t ActiveTrack() const { return Read<int32_t>(uintptr_t(this) + 0x2b4); } // 0x2b4 (Size: 0x4, Type: IntProperty)
    UFabricStepSequencerComponent* StepSequencer() const { return Read<UFabricStepSequencerComponent*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    TArray<FTrackRow> GridRows() const { return Read<TArray<FTrackRow>>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    int32_t MaxTrackIndexToLoadSquares() const { return Read<int32_t>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x4, Type: IntProperty)

    void SET_GridExtents(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x10, Type: StructProperty)
    void SET_GridSpacing(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x10, Type: StructProperty)
    void SET_SingleTrackNumItemsPerRow(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x4, Type: IntProperty)
    void SET_EditorPreviewGridSize(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x278, Value); } // 0x278 (Size: 0x10, Type: StructProperty)
    void SET_GridSquareClassPtr(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x8, Type: ClassProperty)
    void SET_SequencerType(const TEnumAsByte<ESequencerType>& Value) { Write<TEnumAsByte<ESequencerType>>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x1, Type: ByteProperty)
    void SET_ActiveTrack(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2b4, Value); } // 0x2b4 (Size: 0x4, Type: IntProperty)
    void SET_StepSequencer(const UFabricStepSequencerComponent*& Value) { Write<UFabricStepSequencerComponent*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_GridRows(const TArray<FTrackRow>& Value) { Write<TArray<FTrackRow>>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    void SET_MaxTrackIndexToLoadSquares(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x4, Type: IntProperty)
};

// Size: 0x670
class UFabricStepSequencerGridSquareComponent : public UStaticMeshComponent
{
public:
    float ContinuationControlInteractionDelay() const { return Read<float>(uintptr_t(this) + 0x618); } // 0x618 (Size: 0x4, Type: FloatProperty)
    UFabricStepSequencerComponent* AssignedStepSequencer() const { return Read<UFabricStepSequencerComponent*>(uintptr_t(this) + 0x620); } // 0x620 (Size: 0x8, Type: ObjectProperty)
    int32_t ActiveTrack() const { return Read<int32_t>(uintptr_t(this) + 0x628); } // 0x628 (Size: 0x4, Type: IntProperty)
    int32_t AssignedStep() const { return Read<int32_t>(uintptr_t(this) + 0x62c); } // 0x62c (Size: 0x4, Type: IntProperty)
    int32_t PreviousFocusStepIndex() const { return Read<int32_t>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0x4, Type: IntProperty)

    void SET_ContinuationControlInteractionDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x618, Value); } // 0x618 (Size: 0x4, Type: FloatProperty)
    void SET_AssignedStepSequencer(const UFabricStepSequencerComponent*& Value) { Write<UFabricStepSequencerComponent*>(uintptr_t(this) + 0x620, Value); } // 0x620 (Size: 0x8, Type: ObjectProperty)
    void SET_ActiveTrack(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x628, Value); } // 0x628 (Size: 0x4, Type: IntProperty)
    void SET_AssignedStep(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x62c, Value); } // 0x62c (Size: 0x4, Type: IntProperty)
    void SET_PreviousFocusStepIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0x4, Type: IntProperty)
};

// Size: 0x340
class UFabricTextureModifierBase : public UFabricModulatable
{
public:
    UTexture* ModifiedTexture() const { return Read<UTexture*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)

    void SET_ModifiedTexture(const UTexture*& Value) { Write<UTexture*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x50
class UFabricTextureTreeNode : public UObject
{
public:
    TArray<UFabricTextureTreeNode*> Children() const { return Read<TArray<UFabricTextureTreeNode*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    FFabricTextureProviderTexture Texture() const { return Read<FFabricTextureProviderTexture>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)

    void SET_Children(const TArray<UFabricTextureTreeNode*>& Value) { Write<TArray<UFabricTextureTreeNode*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_Texture(const FFabricTextureProviderTexture& Value) { Write<FFabricTextureProviderTexture>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
};

// Size: 0x60
class UFabricTextureProviderBase : public UObject
{
public:
    FFabricTextureProviderTexture SourceTexture() const { return Read<FFabricTextureProviderTexture>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    float CurrentCableFloatValue() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    float CurrentCableFloatDirection() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    float TimeElapsedSinceLastCableFloatDirty() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    bool bCurrentCableFloatDirty() const { return Read<bool>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x1, Type: BoolProperty)

    void SET_SourceTexture(const FFabricTextureProviderTexture& Value) { Write<FFabricTextureProviderTexture>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_CurrentCableFloatValue(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_CurrentCableFloatDirection(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_TimeElapsedSinceLastCableFloatDirty(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_bCurrentCableFloatDirty(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x1, Type: BoolProperty)
};

// Size: 0xd0
class UFabricTimelinePreviewComponent : public UActorComponent
{
public:
    UTimelineComponent* CurrentTimeline() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)

    void SET_CurrentTimeline(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x178
class UFabricTimelineSyncComponent : public UActorComponent
{
public:
    float ThresholdForSeekMS() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    float ThresholdForSeekWhenSpeedSyncDisallowedMS() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    float ThresholdForStartSpeedAdjustMS() const { return Read<float>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    float ThresholdForEndOfSpeedAdjustMS() const { return Read<float>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    float SpeedAdjustFactor() const { return Read<float>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    bool bPrintToScreen() const { return Read<bool>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x1, Type: BoolProperty)
    bool bLogCorrectedServerTimeDelta() const { return Read<bool>(uintptr_t(this) + 0xdd); } // 0xdd (Size: 0x1, Type: BoolProperty)
    float SpeedSyncTimeoutLength() const { return Read<float>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: FloatProperty)
    float TempoDeltaThrottleSeconds() const { return Read<float>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    float MassiveSyncErrorTimeThresholdMin() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    float MassiveSyncErrorTimeThresholdMax() const { return Read<float>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: FloatProperty)
    float MassiveSyncErrorTimeThresholdMultiplier() const { return Read<float>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    UFabricMetaSoundManagerComponent* MetaSoundManager() const { return Read<UFabricMetaSoundManagerComponent*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    UMusicClockComponent* MusicClock() const { return Read<UMusicClockComponent*>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: ObjectProperty)
    FFabricTimelineSyncServerSongPosition ServerTimelineSyncServerSongPosition() const { return Read<FFabricTimelineSyncServerSongPosition>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x1c, Type: StructProperty)

    void SET_ThresholdForSeekMS(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_ThresholdForSeekWhenSpeedSyncDisallowedMS(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_ThresholdForStartSpeedAdjustMS(const float& Value) { Write<float>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    void SET_ThresholdForEndOfSpeedAdjustMS(const float& Value) { Write<float>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    void SET_SpeedAdjustFactor(const float& Value) { Write<float>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    void SET_bPrintToScreen(const bool& Value) { Write<bool>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x1, Type: BoolProperty)
    void SET_bLogCorrectedServerTimeDelta(const bool& Value) { Write<bool>(uintptr_t(this) + 0xdd, Value); } // 0xdd (Size: 0x1, Type: BoolProperty)
    void SET_SpeedSyncTimeoutLength(const float& Value) { Write<float>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: FloatProperty)
    void SET_TempoDeltaThrottleSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    void SET_MassiveSyncErrorTimeThresholdMin(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    void SET_MassiveSyncErrorTimeThresholdMax(const float& Value) { Write<float>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: FloatProperty)
    void SET_MassiveSyncErrorTimeThresholdMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    void SET_MetaSoundManager(const UFabricMetaSoundManagerComponent*& Value) { Write<UFabricMetaSoundManagerComponent*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    void SET_MusicClock(const UMusicClockComponent*& Value) { Write<UMusicClockComponent*>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: ObjectProperty)
    void SET_ServerTimelineSyncServerSongPosition(const FFabricTimelineSyncServerSongPosition& Value) { Write<FFabricTimelineSyncServerSongPosition>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x1c, Type: StructProperty)
};

// Size: 0x28
class UFabricTimelineSyncTargetInterface : public UInterface
{
public:
};

// Size: 0x40
class UFabricVFXTopperDataAsset : public UDataAsset
{
public:
    TArray<FFabricVFXTopperDataEntry> VFXTopperDataEntries() const { return Read<TArray<FFabricVFXTopperDataEntry>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_VFXTopperDataEntries(const TArray<FFabricVFXTopperDataEntry>& Value) { Write<TArray<FFabricVFXTopperDataEntry>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x78
class UFabricWaveformTexture : public UObject
{
public:
    int32_t WaveformNumSamplesHeld() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    int32_t WaveformSmoothingDistance() const { return Read<int32_t>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: IntProperty)
    float WaveformSmoothingFactor() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float WaveformDecayPerSecond() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    UTexture2D* WaveformTexture() const { return Read<UTexture2D*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    bool bEnableTextureRequests() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)

    void SET_WaveformNumSamplesHeld(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_WaveformSmoothingDistance(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: IntProperty)
    void SET_WaveformSmoothingFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_WaveformDecayPerSecond(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_WaveformTexture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_bEnableTextureRequests(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x38
class UFabricInteractableTargetPayload : public UObject
{
public:
    TWeakObjectPtr<AActor*> TargetedActor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UPrimitiveComponent*> TargetedComponent() const { return Read<TWeakObjectPtr<UPrimitiveComponent*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)

    void SET_TargetedActor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    void SET_TargetedComponent(const TWeakObjectPtr<UPrimitiveComponent*>& Value) { Write<TWeakObjectPtr<UPrimitiveComponent*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0xbb8
class UFortGameplayAbility_FabricInteractableTargeting : public UFortGameplayAbility
{
public:
    UTargetingPreset* TargetingPreset() const { return Read<UTargetingPreset*>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag TargetsChangedTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x4, Type: StructProperty)
    FScalableFloat TargetingInterval() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x28, Type: StructProperty)
    UFabricInteractableTargetPayload* PayloadCache() const { return Read<UFabricInteractableTargetPayload*>(uintptr_t(this) + 0xba0); } // 0xba0 (Size: 0x8, Type: ObjectProperty)
    FTargetingRequestHandle AsyncTargetingHandle() const { return Read<FTargetingRequestHandle>(uintptr_t(this) + 0xba8); } // 0xba8 (Size: 0x4, Type: StructProperty)
    FTimerHandle TargetingTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0xbb0); } // 0xbb0 (Size: 0x8, Type: StructProperty)

    void SET_TargetingPreset(const UTargetingPreset*& Value) { Write<UTargetingPreset*>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetsChangedTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x4, Type: StructProperty)
    void SET_TargetingInterval(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x28, Type: StructProperty)
    void SET_PayloadCache(const UFabricInteractableTargetPayload*& Value) { Write<UFabricInteractableTargetPayload*>(uintptr_t(this) + 0xba0, Value); } // 0xba0 (Size: 0x8, Type: ObjectProperty)
    void SET_AsyncTargetingHandle(const FTargetingRequestHandle& Value) { Write<FTargetingRequestHandle>(uintptr_t(this) + 0xba8, Value); } // 0xba8 (Size: 0x4, Type: StructProperty)
    void SET_TargetingTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xbb0, Value); } // 0xbb0 (Size: 0x8, Type: StructProperty)
};

// Size: 0x48
class UFabricGameFeatureAction_OverrideFabricInteractionTool : public UGameFeatureAction
{
public:
    TSoftObjectPtr<UFortGadgetItemDefinition> OverriddenPatchworkInteractionTool() const { return Read<TSoftObjectPtr<UFortGadgetItemDefinition>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)

    void SET_OverriddenPatchworkInteractionTool(const TSoftObjectPtr<UFortGadgetItemDefinition>& Value) { Write<TSoftObjectPtr<UFortGadgetItemDefinition>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0xa0
class UFabricGlobalRestrictionsWorldSubsystem : public UWorldSubsystem
{
public:
    FGameplayTagContainer FabricInteractionToolRestrictionGameplayTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)

    void SET_FabricInteractionToolRestrictionGameplayTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
};

// Size: 0xf8
class UFabricIslandSettingsWorldSubsystem : public UWorldSubsystem
{
public:
    FScalableFloat UseMemoryMode() const { return Read<FScalableFloat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x28, Type: StructProperty)
    float CheckMinigameSettingsIntervalSeconds() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)

    void SET_UseMemoryMode(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x28, Type: StructProperty)
    void SET_CheckMinigameSettingsIntervalSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc
struct FInteractionData
{
public:
    uint8_t InteractionState() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    TWeakObjectPtr<AFortCreativeDeviceProp*> InteractableOwnerDevice() const { return Read<TWeakObjectPtr<AFortCreativeDeviceProp*>>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x8, Type: WeakObjectProperty)

    void SET_InteractionState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_InteractableOwnerDevice(const TWeakObjectPtr<AFortCreativeDeviceProp*>& Value) { Write<TWeakObjectPtr<AFortCreativeDeviceProp*>>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x60
struct FInteractionSplinePoints
{
public:
    FVector_NetQuantize10 SplineStartLocation() const { return Read<FVector_NetQuantize10>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FVector_NetQuantize10 SplineStartForward() const { return Read<FVector_NetQuantize10>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FVector_NetQuantize10 SplineEndLocation() const { return Read<FVector_NetQuantize10>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    FVector_NetQuantize10 SplineEndForward() const { return Read<FVector_NetQuantize10>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)

    void SET_SplineStartLocation(const FVector_NetQuantize10& Value) { Write<FVector_NetQuantize10>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_SplineStartForward(const FVector_NetQuantize10& Value) { Write<FVector_NetQuantize10>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_SplineEndLocation(const FVector_NetQuantize10& Value) { Write<FVector_NetQuantize10>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_SplineEndForward(const FVector_NetQuantize10& Value) { Write<FVector_NetQuantize10>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
};

// Size: 0x50
struct FFabricMetaSoundPatchWrapperBinding
{
public:
    FName FriendlyName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    bool bAllowOnDedicatedServer() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    FFabricMetaSoundPatchWrapperPeakTamer PeakTamer() const { return Read<FFabricMetaSoundPatchWrapperPeakTamer>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x24, Type: StructProperty)
    FName MetaSoundNodeName() const { return Read<FName>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: NameProperty)
    TArray<float> Signals() const { return Read<TArray<float>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    bool bBoundToWatchEvents() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)

    void SET_FriendlyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_bAllowOnDedicatedServer(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_PeakTamer(const FFabricMetaSoundPatchWrapperPeakTamer& Value) { Write<FFabricMetaSoundPatchWrapperPeakTamer>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x24, Type: StructProperty)
    void SET_MetaSoundNodeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: NameProperty)
    void SET_Signals(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_bBoundToWatchEvents(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x24
struct FFabricMetaSoundPatchWrapperPeakTamer
{
public:
    bool bUseGameplaySmoothing() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bSortSignals() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    int32_t MaxSignalsToTame() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_bUseGameplaySmoothing(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bSortSignals(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_MaxSignalsToTame(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0xa0
struct FFabricMetaSoundPatchWrapperWetDryOutputBinding
{
public:
    FFabricMetaSoundPatchWrapperBinding WetOutputSignalBinding() const { return Read<FFabricMetaSoundPatchWrapperBinding>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: StructProperty)
    FFabricMetaSoundPatchWrapperBinding DryOutputSignalBinding() const { return Read<FFabricMetaSoundPatchWrapperBinding>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x50, Type: StructProperty)

    void SET_WetOutputSignalBinding(const FFabricMetaSoundPatchWrapperBinding& Value) { Write<FFabricMetaSoundPatchWrapperBinding>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: StructProperty)
    void SET_DryOutputSignalBinding(const FFabricMetaSoundPatchWrapperBinding& Value) { Write<FFabricMetaSoundPatchWrapperBinding>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x50, Type: StructProperty)
};

// Size: 0x58
struct FFabricMetaSoundSpeakerPatchWrapperEqBandsBinding : public FFabricMetaSoundPatchWrapperBinding
{
public:
    int32_t PrimitiveDataIndex() const { return Read<int32_t>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: IntProperty)

    void SET_PrimitiveDataIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FFabricSequencerStepChangedInfo
{
public:
    int32_t Page() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Row() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t Step() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    FStepSequenceCell Cell() const { return Read<FStepSequenceCell>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x2, Type: StructProperty)

    void SET_Page(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Row(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_Step(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_Cell(const FStepSequenceCell& Value) { Write<FStepSequenceCell>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x2, Type: StructProperty)
};

// Size: 0x20
struct FFabricProgressionPreset : public FTableRowBase
{
public:
    FText ProgressionName() const { return Read<FText>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: TextProperty)
    uint8_t Interval0() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t Interval1() const { return Read<uint8_t>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: EnumProperty)
    uint8_t Interval2() const { return Read<uint8_t>(uintptr_t(this) + 0x1a); } // 0x1a (Size: 0x1, Type: EnumProperty)
    uint8_t Interval3() const { return Read<uint8_t>(uintptr_t(this) + 0x1b); } // 0x1b (Size: 0x1, Type: EnumProperty)

    void SET_ProgressionName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: TextProperty)
    void SET_Interval0(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_Interval1(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: EnumProperty)
    void SET_Interval2(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1a, Value); } // 0x1a (Size: 0x1, Type: EnumProperty)
    void SET_Interval3(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1b, Value); } // 0x1b (Size: 0x1, Type: EnumProperty)
};

// Size: 0x18
struct FFabricTextureProviderTexture
{
public:
    UTexture* Texture() const { return Read<UTexture*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FLinearColor Tint() const { return Read<FLinearColor>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)

    void SET_Texture(const UTexture*& Value) { Write<UTexture*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Tint(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x80
struct FFabricLFOGenerator
{
public:
    uint8_t WaveShape() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    float Minimum() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Maximum() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float Shape() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    int32_t InitialSeed() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_WaveShape(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_Minimum(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Maximum(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Shape(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_InitialSeed(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x20
struct FFabricStepGenerator
{
public:
    TArray<float> Values() const { return Read<TArray<float>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    float Blend() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)

    void SET_Values(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_Blend(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x68
struct FFabricValueSetterGenerator
{
public:
    int32_t PhraseLengthInBars() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)

    void SET_PhraseLengthInBars(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
};

// Size: 0xc
struct FFabricMeshProviderMeshReferenceParamInfo
{
public:
    FMaterialParameterInfo MaterialParameterInfo() const { return Read<FMaterialParameterInfo>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)

    void SET_MaterialParameterInfo(const FMaterialParameterInfo& Value) { Write<FMaterialParameterInfo>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
};

// Size: 0x10
struct FFabricMeshProviderMeshReferenceParamInfo_Scalar : public FFabricMeshProviderMeshReferenceParamInfo
{
public:
    float Scalar() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_Scalar(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x1c
struct FFabricMeshProviderMeshReferenceParamInfo_Color : public FFabricMeshProviderMeshReferenceParamInfo
{
public:
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x10, Type: StructProperty)

    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x10, Type: StructProperty)
};

// Size: 0x28
struct FFabricMeshProviderMeshReferenceParams
{
public:
    double UniformScale() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    TArray<FFabricMeshProviderMeshReferenceParamInfo_Scalar> ScalarParams() const { return Read<TArray<FFabricMeshProviderMeshReferenceParamInfo_Scalar>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FFabricMeshProviderMeshReferenceParamInfo_Color> ColorParams() const { return Read<TArray<FFabricMeshProviderMeshReferenceParamInfo_Color>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_UniformScale(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_ScalarParams(const TArray<FFabricMeshProviderMeshReferenceParamInfo_Scalar>& Value) { Write<TArray<FFabricMeshProviderMeshReferenceParamInfo_Scalar>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_ColorParams(const TArray<FFabricMeshProviderMeshReferenceParamInfo_Color>& Value) { Write<TArray<FFabricMeshProviderMeshReferenceParamInfo_Color>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
struct FFabricMeshProviderMeshReference
{
public:
    UStreamableRenderAsset* Mesh() const { return Read<UStreamableRenderAsset*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UTexture* Texture() const { return Read<UTexture*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FFabricMeshProviderMeshReferenceParams Params() const { return Read<FFabricMeshProviderMeshReferenceParams>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x28, Type: StructProperty)

    void SET_Mesh(const UStreamableRenderAsset*& Value) { Write<UStreamableRenderAsset*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Texture(const UTexture*& Value) { Write<UTexture*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Params(const FFabricMeshProviderMeshReferenceParams& Value) { Write<FFabricMeshProviderMeshReferenceParams>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x28, Type: StructProperty)
};

// Size: 0x48
struct FFabricMeshInstanceReference
{
public:
    FFabricMeshProviderMeshReference MeshReference() const { return Read<FFabricMeshProviderMeshReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x38, Type: StructProperty)
    TArray<FTransform> InstanceTransforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_MeshReference(const FFabricMeshProviderMeshReference& Value) { Write<FFabricMeshProviderMeshReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x38, Type: StructProperty)
    void SET_InstanceTransforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x158
struct FFabricMetaSoundMergeNode
{
public:
    FMetaSoundCombinerNodeHandle CombinerNode() const { return Read<FMetaSoundCombinerNodeHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x150, Type: StructProperty)

    void SET_CombinerNode(const FMetaSoundCombinerNodeHandle& Value) { Write<FMetaSoundCombinerNodeHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x150, Type: StructProperty)
};

// Size: 0x150
struct FMetaSoundCombinerNodeHandle
{
public:
    FFabricMetaSoundNodeInfo NodeInfo() const { return Read<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xf0, Type: StructProperty)
    FMetaSoundBuilderNodeInputHandle CombinerInput1() const { return Read<FMetaSoundBuilderNodeInputHandle>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x20, Type: StructProperty)
    FMetaSoundBuilderNodeInputHandle CombinerInput2() const { return Read<FMetaSoundBuilderNodeInputHandle>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x20, Type: StructProperty)
    FMetaSoundBuilderNodeOutputHandle CombinedOutput() const { return Read<FMetaSoundBuilderNodeOutputHandle>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x20, Type: StructProperty)

    void SET_NodeInfo(const FFabricMetaSoundNodeInfo& Value) { Write<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xf0, Type: StructProperty)
    void SET_CombinerInput1(const FMetaSoundBuilderNodeInputHandle& Value) { Write<FMetaSoundBuilderNodeInputHandle>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x20, Type: StructProperty)
    void SET_CombinerInput2(const FMetaSoundBuilderNodeInputHandle& Value) { Write<FMetaSoundBuilderNodeInputHandle>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x20, Type: StructProperty)
    void SET_CombinedOutput(const FMetaSoundBuilderNodeOutputHandle& Value) { Write<FMetaSoundBuilderNodeOutputHandle>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x20, Type: StructProperty)
};

// Size: 0xf0
struct FFabricMetaSoundNodeInfo
{
public:
    FMetaSoundNodeHandle NodeHandle() const { return Read<FMetaSoundNodeHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FMetaSoundNodeHandle OutputConnectionHandle() const { return Read<FMetaSoundNodeHandle>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FMetaSoundNodeHandle InputConnectionHandle() const { return Read<FMetaSoundNodeHandle>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: NameProperty)
    TMap<FMetaSoundBuilderNodeOutputHandle, FName> InputNodeNamesToHandles() const { return Read<TMap<FMetaSoundBuilderNodeOutputHandle, FName>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x50, Type: MapProperty)
    FMetaSoundNodeHandle AnalyzerHandle() const { return Read<FMetaSoundNodeHandle>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: StructProperty)
    UMetasoundParameterPack* AnalyzerParameterPack() const { return Read<UMetasoundParameterPack*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    FName AnalyzerName() const { return Read<FName>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: NameProperty)
    FMetaSoundNodeHandle SwitcherHandle() const { return Read<FMetaSoundNodeHandle>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x10, Type: StructProperty)
    FMetaSoundNodeHandle SelectHandle() const { return Read<FMetaSoundNodeHandle>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x10, Type: StructProperty)
    FName NodeEnabledInput() const { return Read<FName>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: NameProperty)
    FName AnalyzerNodeVisibleInput() const { return Read<FName>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: NameProperty)
    TArray<FName> AnalyzerOutputNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    UMetaSoundPatch* PatchSpawnedFrom() const { return Read<UMetaSoundPatch*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    UMetasoundParameterPack* ParameterPack() const { return Read<UMetasoundParameterPack*>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: ObjectProperty)

    void SET_NodeHandle(const FMetaSoundNodeHandle& Value) { Write<FMetaSoundNodeHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_OutputConnectionHandle(const FMetaSoundNodeHandle& Value) { Write<FMetaSoundNodeHandle>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_InputConnectionHandle(const FMetaSoundNodeHandle& Value) { Write<FMetaSoundNodeHandle>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: NameProperty)
    void SET_InputNodeNamesToHandles(const TMap<FMetaSoundBuilderNodeOutputHandle, FName>& Value) { Write<TMap<FMetaSoundBuilderNodeOutputHandle, FName>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x50, Type: MapProperty)
    void SET_AnalyzerHandle(const FMetaSoundNodeHandle& Value) { Write<FMetaSoundNodeHandle>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: StructProperty)
    void SET_AnalyzerParameterPack(const UMetasoundParameterPack*& Value) { Write<UMetasoundParameterPack*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    void SET_AnalyzerName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: NameProperty)
    void SET_SwitcherHandle(const FMetaSoundNodeHandle& Value) { Write<FMetaSoundNodeHandle>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x10, Type: StructProperty)
    void SET_SelectHandle(const FMetaSoundNodeHandle& Value) { Write<FMetaSoundNodeHandle>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x10, Type: StructProperty)
    void SET_NodeEnabledInput(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: NameProperty)
    void SET_AnalyzerNodeVisibleInput(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: NameProperty)
    void SET_AnalyzerOutputNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    void SET_PatchSpawnedFrom(const UMetaSoundPatch*& Value) { Write<UMetaSoundPatch*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    void SET_ParameterPack(const UMetasoundParameterPack*& Value) { Write<UMetasoundParameterPack*>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc0
struct FFabricMetaSoundConnectionBuilder
{
public:
    TArray<FFabricMetaSoundMergeNode> MergeList() const { return Read<TArray<FFabricMetaSoundMergeNode>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: ArrayProperty)

    void SET_MergeList(const TArray<FFabricMetaSoundMergeNode>& Value) { Write<TArray<FFabricMetaSoundMergeNode>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FFabricMetaSoundNodePool
{
public:
    int32_t NumberAdded() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    TArray<FFabricMetaSoundNodeInfo> FreeNodes() const { return Read<TArray<FFabricMetaSoundNodeInfo>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    UMetaSoundPatch* PatchSpawnedFrom() const { return Read<UMetaSoundPatch*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)

    void SET_NumberAdded(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_FreeNodes(const TArray<FFabricMetaSoundNodeInfo>& Value) { Write<TArray<FFabricMetaSoundNodeInfo>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_PatchSpawnedFrom(const UMetaSoundPatch*& Value) { Write<UMetaSoundPatch*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x8
struct FFabricMetaSoundUtilityParams
{
public:
    FName SwitcherEnabledParam() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName SelectEnabledParam() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)

    void SET_SwitcherEnabledParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_SelectEnabledParam(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x88
struct FFabricMetaSoundUtilityPatches
{
public:
    TSoftObjectPtr<UMetaSoundPatch> CombinerNode() const { return Read<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMetaSoundPatch> SwitcherNode() const { return Read<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMetaSoundPatch> SelectNode() const { return Read<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMetaSoundPatch> AnalyzerNode() const { return Read<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x20, Type: SoftObjectProperty)
    FFabricMetaSoundUtilityParams UtilityNodeParams() const { return Read<FFabricMetaSoundUtilityParams>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: StructProperty)

    void SET_CombinerNode(const TSoftObjectPtr<UMetaSoundPatch>& Value) { Write<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SwitcherNode(const TSoftObjectPtr<UMetaSoundPatch>& Value) { Write<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SelectNode(const TSoftObjectPtr<UMetaSoundPatch>& Value) { Write<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: SoftObjectProperty)
    void SET_AnalyzerNode(const TSoftObjectPtr<UMetaSoundPatch>& Value) { Write<TSoftObjectPtr<UMetaSoundPatch>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x20, Type: SoftObjectProperty)
    void SET_UtilityNodeParams(const FFabricMetaSoundUtilityParams& Value) { Write<FFabricMetaSoundUtilityParams>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: StructProperty)
};

// Size: 0x28
struct FFabricLoadedUtilityPatches
{
public:
    UMetaSoundPatch* CombinerNode() const { return Read<UMetaSoundPatch*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UMetaSoundPatch* SwitcherNode() const { return Read<UMetaSoundPatch*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UMetaSoundPatch* SelectNode() const { return Read<UMetaSoundPatch*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    UMetaSoundPatch* AnalyzerNode() const { return Read<UMetaSoundPatch*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    FFabricMetaSoundUtilityParams UtilityNodeParams() const { return Read<FFabricMetaSoundUtilityParams>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: StructProperty)

    void SET_CombinerNode(const UMetaSoundPatch*& Value) { Write<UMetaSoundPatch*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_SwitcherNode(const UMetaSoundPatch*& Value) { Write<UMetaSoundPatch*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_SelectNode(const UMetaSoundPatch*& Value) { Write<UMetaSoundPatch*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_AnalyzerNode(const UMetaSoundPatch*& Value) { Write<UMetaSoundPatch*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET_UtilityNodeParams(const FFabricMetaSoundUtilityParams& Value) { Write<FFabricMetaSoundUtilityParams>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: StructProperty)
};

// Size: 0x8
struct FFabricTransportRequestConfig
{
public:
    uint8_t PlayStrategy() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t PlayPriority() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)
    FName LockingAuthorityName() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)

    void SET_PlayStrategy(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_PlayPriority(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
    void SET_LockingAuthorityName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x8
struct FFabricMetaSoundDirectInputInfo
{
public:
    FName MetaSoundInputName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t InputType() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)

    void SET_MetaSoundInputName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_InputType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x18
struct FFabricMetaSoundUserOptionInputInfo
{
public:
    FString UserOption() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FName MetaSoundInputName() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)

    void SET_UserOption(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_MetaSoundInputName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
};

// Size: 0x240
struct FFabricMetaSoundRuntimeInputInfo
{
public:
    FFabricMetaSoundUserOptionInputInfo InputInfo() const { return Read<FFabricMetaSoundUserOptionInputInfo>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    uint8_t InputType() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t FabricKnobType() const { return Read<uint8_t>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: EnumProperty)
    FName DataType() const { return Read<FName>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: NameProperty)
    FName MetaSoundInputNodeName() const { return Read<FName>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: NameProperty)
    UFabricMetaSoundUserOption* MetaSoundUserOption() const { return Read<UFabricMetaSoundUserOption*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ObjectProperty)
    FFabricMetaSoundNodeInfo UserOptionConverterNode() const { return Read<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0xf0, Type: StructProperty)
    FFabricMetaSoundConnectionBuilder InputBuilder() const { return Read<FFabricMetaSoundConnectionBuilder>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0xc0, Type: StructProperty)

    void SET_InputInfo(const FFabricMetaSoundUserOptionInputInfo& Value) { Write<FFabricMetaSoundUserOptionInputInfo>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_InputType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_FabricKnobType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: EnumProperty)
    void SET_DataType(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: NameProperty)
    void SET_MetaSoundInputNodeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: NameProperty)
    void SET_MetaSoundUserOption(const UFabricMetaSoundUserOption*& Value) { Write<UFabricMetaSoundUserOption*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ObjectProperty)
    void SET_UserOptionConverterNode(const FFabricMetaSoundNodeInfo& Value) { Write<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0xf0, Type: StructProperty)
    void SET_InputBuilder(const FFabricMetaSoundConnectionBuilder& Value) { Write<FFabricMetaSoundConnectionBuilder>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0xc0, Type: StructProperty)
};

// Size: 0x230
struct FFabricConnectedInputWrapperInfo
{
public:
    bool bDirectlyConnected() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    UFabricMetaSoundPatchWrapper* Wrapper() const { return Read<UFabricMetaSoundPatchWrapper*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FFabricMetaSoundNodeInfo OutputNode() const { return Read<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xf0, Type: StructProperty)
    FMetaSoundBuilderNodeOutputHandle ConnectedNodeOutput() const { return Read<FMetaSoundBuilderNodeOutputHandle>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x20, Type: StructProperty)
    FFabricMetaSoundNodeInfo InputNode() const { return Read<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0xf0, Type: StructProperty)
    FMetaSoundBuilderNodeInputHandle CombinerNodeInput() const { return Read<FMetaSoundBuilderNodeInputHandle>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x20, Type: StructProperty)

    void SET_bDirectlyConnected(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_Wrapper(const UFabricMetaSoundPatchWrapper*& Value) { Write<UFabricMetaSoundPatchWrapper*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_OutputNode(const FFabricMetaSoundNodeInfo& Value) { Write<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xf0, Type: StructProperty)
    void SET_ConnectedNodeOutput(const FMetaSoundBuilderNodeOutputHandle& Value) { Write<FMetaSoundBuilderNodeOutputHandle>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x20, Type: StructProperty)
    void SET_InputNode(const FFabricMetaSoundNodeInfo& Value) { Write<FFabricMetaSoundNodeInfo>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0xf0, Type: StructProperty)
    void SET_CombinerNodeInput(const FMetaSoundBuilderNodeInputHandle& Value) { Write<FMetaSoundBuilderNodeInputHandle>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x20, Type: StructProperty)
};

// Size: 0x8
struct FFabricMetaSoundPatchWrapper_PerPlatformInputTuning
{
public:
    FName NodeInputName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    bool bUseDefaultValues() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)

    void SET_NodeInputName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_bUseDefaultValues(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x60
struct FFabricMetaSoundPatchWrapper_PerPlatformBoolInputTuning : public FFabricMetaSoundPatchWrapper_PerPlatformInputTuning
{
public:
    bool bDefaultValue() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    TMap<bool, FName> PerPlatformTuning() const { return Read<TMap<bool, FName>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x50, Type: MapProperty)

    void SET_bDefaultValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_PerPlatformTuning(const TMap<bool, FName>& Value) { Write<TMap<bool, FName>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x50, Type: MapProperty)
};

// Size: 0x60
struct FFabricMetaSoundPatchWrapper_PerPlatformIntInputTuning : public FFabricMetaSoundPatchWrapper_PerPlatformInputTuning
{
public:
    int32_t DefaultValue() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    TMap<int32_t, FName> PerPlatformTuning() const { return Read<TMap<int32_t, FName>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x50, Type: MapProperty)

    void SET_DefaultValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_PerPlatformTuning(const TMap<int32_t, FName>& Value) { Write<TMap<int32_t, FName>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x50, Type: MapProperty)
};

// Size: 0x60
struct FFabricMetaSoundPatchWrapper_PerPlatformFloatInputTuning : public FFabricMetaSoundPatchWrapper_PerPlatformInputTuning
{
public:
    float DefaultValue() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    TMap<float, FName> PerPlatformTuning() const { return Read<TMap<float, FName>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x50, Type: MapProperty)

    void SET_DefaultValue(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_PerPlatformTuning(const TMap<float, FName>& Value) { Write<TMap<float, FName>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x50, Type: MapProperty)
};

// Size: 0x8
struct FMusicalPosition
{
public:
};

// Size: 0x8
struct FMidiFollowData
{
public:
    float BeatOffset() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MSOffset() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_BeatOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MSOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FFabricSignificanceBasedUpdateBucket
{
public:
    float MinDistanceFromPlayer() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxDistanceFromPlayer() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float FramesPerUpdate() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    int32_t MaxObjectsInBucket() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)

    void SET_MinDistanceFromPlayer(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxDistanceFromPlayer(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_FramesPerUpdate(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxObjectsInBucket(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
};

// Size: 0x18
struct FFabricSignificanceBasedUpdateBucketRuntimeGroup
{
public:
    TArray<TWeakObjectPtr<UObject*>> ObjectsInGroup() const { return Read<TArray<TWeakObjectPtr<UObject*>>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_ObjectsInGroup(const TArray<TWeakObjectPtr<UObject*>>& Value) { Write<TArray<TWeakObjectPtr<UObject*>>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FFabricSignificanceBasedUpdateBucketRuntime
{
public:
    float ActualMinSignificance() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float ActualMaxSignificance() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    int32_t ActualMaxObjectsInBucket() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t ActualFramesPerUpdate() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    int32_t TotalObjectsInBucketCount() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    TArray<FFabricSignificanceBasedUpdateBucketRuntimeGroup> UpdateGroups() const { return Read<TArray<FFabricSignificanceBasedUpdateBucketRuntimeGroup>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_ActualMinSignificance(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_ActualMaxSignificance(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_ActualMaxObjectsInBucket(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_ActualFramesPerUpdate(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_TotalObjectsInBucketCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_UpdateGroups(const TArray<FFabricSignificanceBasedUpdateBucketRuntimeGroup>& Value) { Write<TArray<FFabricSignificanceBasedUpdateBucketRuntimeGroup>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FFabricStepTrackPacked
{
public:
    TArray<int32_t> PackedEnabledSquares() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> PackedContinuationSquares() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    int32_t TrackIndex() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)

    void SET_PackedEnabledSquares(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_PackedContinuationSquares(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_TrackIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
};

// Size: 0x18
struct FFabricStepPagePacked
{
public:
    TArray<FFabricStepTrackPacked> PackedTracks() const { return Read<TArray<FFabricStepTrackPacked>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t PageNumber() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_PackedTracks(const TArray<FFabricStepTrackPacked>& Value) { Write<TArray<FFabricStepTrackPacked>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_PageNumber(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x28
struct FFabricStepTablePacked
{
public:
    TArray<FFabricStepPagePacked> PackedPages() const { return Read<TArray<FFabricStepPagePacked>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FStepSequenceNote> Notes() const { return Read<TArray<FStepSequenceNote>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    int32_t StepSkipIndex() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)
    bool bHasRepDelayApplied() const { return Read<bool>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: BoolProperty)

    void SET_PackedPages(const TArray<FFabricStepPagePacked>& Value) { Write<TArray<FFabricStepPagePacked>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Notes(const TArray<FStepSequenceNote>& Value) { Write<TArray<FStepSequenceNote>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_StepSkipIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
    void SET_bHasRepDelayApplied(const bool& Value) { Write<bool>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x90
struct FFabricStepSequencerComponentBaseInstanceData : public FActorComponentInstanceData
{
public:
    FFabricStepTablePacked PackedStepTable() const { return Read<FFabricStepTablePacked>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x28, Type: StructProperty)

    void SET_PackedStepTable(const FFabricStepTablePacked& Value) { Write<FFabricStepTablePacked>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x28, Type: StructProperty)
};

// Size: 0x10
struct FTrackRow
{
public:
    TArray<UFabricStepSequencerGridSquareComponent*> GridSquares() const { return Read<TArray<UFabricStepSequencerGridSquareComponent*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_GridSquares(const TArray<UFabricStepSequencerGridSquareComponent*>& Value) { Write<TArray<UFabricStepSequencerGridSquareComponent*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1c
struct FFabricTimelineSyncServerSongPosition
{
public:
    FMusicTimestamp Timestamp() const { return Read<FMusicTimestamp>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    float SecondsIncludingCountIn() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float Tempo() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float BeatsIncludingCountIn() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float NetServerTimeWhenSent() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float TimeSigDenominator() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)

    void SET_Timestamp(const FMusicTimestamp& Value) { Write<FMusicTimestamp>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_SecondsIncludingCountIn(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Tempo(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_BeatsIncludingCountIn(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_NetServerTimeWhenSent(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_TimeSigDenominator(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FFabricVFXTopperDataEntry
{
public:
    UStaticMesh* StaticMesh() const { return Read<UStaticMesh*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<UMaterialInstance*> MaterialInstance() const { return Read<TArray<UMaterialInstance*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    UNiagaraSystem* NiagaraSystem() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)

    void SET_StaticMesh(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_MaterialInstance(const TArray<UMaterialInstance*>& Value) { Write<TArray<UMaterialInstance*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_NiagaraSystem(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
};

