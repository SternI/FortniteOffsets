/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_BeanCosmeticMaterialsLibrary
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "BeanstalkCosmeticsRuntime.h"
#include "Engine.h"
#include "Cosmetics.h"

// Size: 0x28
class UBP_BeanCosmeticMaterialsLibrary_C : public UBlueprintFunctionLibrary
{
public:
};

