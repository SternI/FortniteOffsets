/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Dialogs
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0xe0
class UDialogVM_DiscoTileDisclaimer_RecentlyPlayed_C : public UUIKitDialogViewModel
{
public:
};

// Size: 0xe0
class UDialogVM_DiscoTileDisclaimer_Recommended_C : public UUIKitDialogViewModel
{
public:
};

// Size: 0xe0
class UDialogVM_DiscoTileDisclaimer_C : public UUIKitDialogViewModel
{
public:
};

