/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicMediaUtilities
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"

// Size: 0x2c0
class AEpicMediaServerTime : public AActor
{
public:
};

// Size: 0x30
struct FEpicMediaImageDataExt
{
public:
    FString URL() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString FullUrl() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t Width() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)
    int32_t Height() const { return Read<int32_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: IntProperty)
    float AspectRatio() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)

    void SET_URL(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_FullUrl(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_Width(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
    void SET_Height(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: IntProperty)
    void SET_AspectRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FEpicMediaAudioOnlyPeriodDataExt
{
public:
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    bool bColorSet() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    double StartFrame() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    double EndFrame() const { return Read<double>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: DoubleProperty)

    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_bColorSet(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_StartFrame(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    void SET_EndFrame(const double& Value) { Write<double>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x28
struct FEpicMediaVolumeChangeDataExt
{
public:
    double Frame() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Level() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Lerp() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)

    void SET_Frame(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_Level(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_Lerp(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0xa0
struct FEpicMediaPlaylistExt
{
public:
    FString Language() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString Type() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FString URL() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)
    FString RelUrl() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    FString Data() const { return Read<FString>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StrProperty)
    double duration() const { return Read<double>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: DoubleProperty)
    double FPS() const { return Read<double>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: DoubleProperty)
    TArray<FEpicMediaImageDataExt> Images() const { return Read<TArray<FEpicMediaImageDataExt>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<FEpicMediaAudioOnlyPeriodDataExt> AudioOnlyPeriods() const { return Read<TArray<FEpicMediaAudioOnlyPeriodDataExt>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<FEpicMediaVolumeChangeDataExt> VolumeChanges() const { return Read<TArray<FEpicMediaVolumeChangeDataExt>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    double SkipBoundaryTime() const { return Read<double>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: DoubleProperty)
    double PreEndEventTime() const { return Read<double>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: DoubleProperty)

    void SET_Language(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Type(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_URL(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
    void SET_RelUrl(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_Data(const FString& Value) { Write<FString>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StrProperty)
    void SET_duration(const double& Value) { Write<double>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: DoubleProperty)
    void SET_FPS(const double& Value) { Write<double>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: DoubleProperty)
    void SET_Images(const TArray<FEpicMediaImageDataExt>& Value) { Write<TArray<FEpicMediaImageDataExt>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_AudioOnlyPeriods(const TArray<FEpicMediaAudioOnlyPeriodDataExt>& Value) { Write<TArray<FEpicMediaAudioOnlyPeriodDataExt>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_VolumeChanges(const TArray<FEpicMediaVolumeChangeDataExt>& Value) { Write<TArray<FEpicMediaVolumeChangeDataExt>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_SkipBoundaryTime(const double& Value) { Write<double>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: DoubleProperty)
    void SET_PreEndEventTime(const double& Value) { Write<double>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0xa8
struct FEpicMediaRegionLockExt
{
public:
    bool AllowOnError() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    FString Type() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)
    TArray<FString> AllowList() const { return Read<TArray<FString>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> DenyList() const { return Read<TArray<FString>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TMap<FString, FString> Limits() const { return Read<TMap<FString, FString>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x50, Type: MapProperty)
    FString ContentId() const { return Read<FString>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: StrProperty)

    void SET_AllowOnError(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_Type(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
    void SET_AllowList(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_DenyList(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_Limits(const TMap<FString, FString>& Value) { Write<TMap<FString, FString>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x50, Type: MapProperty)
    void SET_ContentId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: StrProperty)
};

// Size: 0x10
struct FEpicMediaAudioMetadataTrackIndicesExt
{
public:
    TArray<int32_t> Indices() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Indices(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
struct FEpicMediaAudioMetadataTrackExt
{
public:
    TMap<FEpicMediaAudioMetadataTrackIndicesExt, FString> TrackData() const { return Read<TMap<FEpicMediaAudioMetadataTrackIndicesExt, FString>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_TrackData(const TMap<FEpicMediaAudioMetadataTrackIndicesExt, FString>& Value) { Write<TMap<FEpicMediaAudioMetadataTrackIndicesExt, FString>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0xb0
struct FEpicMediaAudioMetadataDataExt
{
public:
    FString ShortName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    int32_t SongID() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    FString Title() const { return Read<FString>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StrProperty)
    FString Artist() const { return Read<FString>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StrProperty)
    FString Album() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)
    FString Genre() const { return Read<FString>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StrProperty)
    int32_t Year() const { return Read<int32_t>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: IntProperty)
    TMap<int32_t, FString> Difficulty() const { return Read<TMap<int32_t, FString>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x50, Type: MapProperty)

    void SET_ShortName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_SongID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_Title(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StrProperty)
    void SET_Artist(const FString& Value) { Write<FString>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StrProperty)
    void SET_Album(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
    void SET_Genre(const FString& Value) { Write<FString>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StrProperty)
    void SET_Year(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: IntProperty)
    void SET_Difficulty(const TMap<int32_t, FString>& Value) { Write<TMap<int32_t, FString>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x50, Type: MapProperty)
};

// Size: 0x130
struct FEpicMediaAudioMetadataExt
{
public:
    TMap<FEpicMediaAudioMetadataTrackIndicesExt, FString> Tracks() const { return Read<TMap<FEpicMediaAudioMetadataTrackIndicesExt, FString>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)
    TArray<float> Pans() const { return Read<TArray<float>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<float> Volumes() const { return Read<TArray<float>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<char> Midi() const { return Read<TArray<char>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    FEpicMediaAudioMetadataDataExt MetadataData() const { return Read<FEpicMediaAudioMetadataDataExt>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0xb0, Type: StructProperty)

    void SET_Tracks(const TMap<FEpicMediaAudioMetadataTrackIndicesExt, FString>& Value) { Write<TMap<FEpicMediaAudioMetadataTrackIndicesExt, FString>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
    void SET_Pans(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_Volumes(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_Midi(const TArray<char>& Value) { Write<TArray<char>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_MetadataData(const FEpicMediaAudioMetadataDataExt& Value) { Write<FEpicMediaAudioMetadataDataExt>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0xb0, Type: StructProperty)
};

// Size: 0x68
struct FEpicMediaExtraMetadataExt
{
public:
    FString AssetId() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    TArray<FString> BaseURLs() const { return Read<TArray<FString>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FString BaseUrl() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)
    int64_t Version() const { return Read<int64_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: Int64Property)
    int64_t ExpiresAt() const { return Read<int64_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: Int64Property)
    bool bSupportsCaching() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)
    bool bSharelock() const { return Read<bool>(uintptr_t(this) + 0x41); } // 0x41 (Size: 0x1, Type: BoolProperty)
    FString UserContentProtection() const { return Read<FString>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StrProperty)
    FString Limits() const { return Read<FString>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StrProperty)

    void SET_AssetId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_BaseURLs(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_BaseUrl(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
    void SET_Version(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: Int64Property)
    void SET_ExpiresAt(const int64_t& Value) { Write<int64_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: Int64Property)
    void SET_bSupportsCaching(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
    void SET_bSharelock(const bool& Value) { Write<bool>(uintptr_t(this) + 0x41, Value); } // 0x41 (Size: 0x1, Type: BoolProperty)
    void SET_UserContentProtection(const FString& Value) { Write<FString>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StrProperty)
    void SET_Limits(const FString& Value) { Write<FString>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StrProperty)
};

// Size: 0x308
struct FEpicMediaMetadataExt
{
public:
    TArray<FEpicMediaPlaylistExt> Playlists() const { return Read<TArray<FEpicMediaPlaylistExt>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FEpicMediaPlaylistExt> StateStreamPlaylists() const { return Read<TArray<FEpicMediaPlaylistExt>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FEpicMediaPlaylistExt> SelectedPlaylists() const { return Read<TArray<FEpicMediaPlaylistExt>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    FString Type() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    FString Envelope() const { return Read<FString>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StrProperty)
    FString Limits() const { return Read<FString>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: StrProperty)
    FString Subtitles() const { return Read<FString>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: StrProperty)
    FString UserContentProtection() const { return Read<FString>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: StrProperty)
    bool Sharelock() const { return Read<bool>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: BoolProperty)
    bool AudioOnly() const { return Read<bool>(uintptr_t(this) + 0x81); } // 0x81 (Size: 0x1, Type: BoolProperty)
    float AspectRatio() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    bool PartySync() const { return Read<bool>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: BoolProperty)
    bool Live() const { return Read<bool>(uintptr_t(this) + 0x89); } // 0x89 (Size: 0x1, Type: BoolProperty)
    FString DenyHTTPCode() const { return Read<FString>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: StrProperty)
    int32_t ResponseHTTPCode() const { return Read<int32_t>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: IntProperty)
    bool bTreatCDNSwitchAsFatal() const { return Read<bool>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x1, Type: BoolProperty)
    FEpicMediaRegionLockExt RegionLockData() const { return Read<FEpicMediaRegionLockExt>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0xa8, Type: StructProperty)
    FEpicMediaAudioMetadataExt AudioMetadata() const { return Read<FEpicMediaAudioMetadataExt>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x130, Type: StructProperty)
    bool bQuicksilverEP() const { return Read<bool>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x1, Type: BoolProperty)
    FEpicMediaExtraMetadataExt ExtraMetadata() const { return Read<FEpicMediaExtraMetadataExt>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x68, Type: StructProperty)
    uint8_t RequestType() const { return Read<uint8_t>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x1, Type: EnumProperty)

    void SET_Playlists(const TArray<FEpicMediaPlaylistExt>& Value) { Write<TArray<FEpicMediaPlaylistExt>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_StateStreamPlaylists(const TArray<FEpicMediaPlaylistExt>& Value) { Write<TArray<FEpicMediaPlaylistExt>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_SelectedPlaylists(const TArray<FEpicMediaPlaylistExt>& Value) { Write<TArray<FEpicMediaPlaylistExt>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_Type(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_Envelope(const FString& Value) { Write<FString>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StrProperty)
    void SET_Limits(const FString& Value) { Write<FString>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: StrProperty)
    void SET_Subtitles(const FString& Value) { Write<FString>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: StrProperty)
    void SET_UserContentProtection(const FString& Value) { Write<FString>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: StrProperty)
    void SET_Sharelock(const bool& Value) { Write<bool>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: BoolProperty)
    void SET_AudioOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x81, Value); } // 0x81 (Size: 0x1, Type: BoolProperty)
    void SET_AspectRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_PartySync(const bool& Value) { Write<bool>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: BoolProperty)
    void SET_Live(const bool& Value) { Write<bool>(uintptr_t(this) + 0x89, Value); } // 0x89 (Size: 0x1, Type: BoolProperty)
    void SET_DenyHTTPCode(const FString& Value) { Write<FString>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: StrProperty)
    void SET_ResponseHTTPCode(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: IntProperty)
    void SET_bTreatCDNSwitchAsFatal(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x1, Type: BoolProperty)
    void SET_RegionLockData(const FEpicMediaRegionLockExt& Value) { Write<FEpicMediaRegionLockExt>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0xa8, Type: StructProperty)
    void SET_AudioMetadata(const FEpicMediaAudioMetadataExt& Value) { Write<FEpicMediaAudioMetadataExt>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x130, Type: StructProperty)
    void SET_bQuicksilverEP(const bool& Value) { Write<bool>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x1, Type: BoolProperty)
    void SET_ExtraMetadata(const FEpicMediaExtraMetadataExt& Value) { Write<FEpicMediaExtraMetadataExt>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x68, Type: StructProperty)
    void SET_RequestType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x1, Type: EnumProperty)
};

