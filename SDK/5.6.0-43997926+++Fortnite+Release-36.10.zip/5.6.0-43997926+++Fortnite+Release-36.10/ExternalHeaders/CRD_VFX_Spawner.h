/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_VFX_Spawner
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "Niagara.h"
#include "Engine.h"

// Size: 0x28
class UCRD_VFX_SpawnerFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

