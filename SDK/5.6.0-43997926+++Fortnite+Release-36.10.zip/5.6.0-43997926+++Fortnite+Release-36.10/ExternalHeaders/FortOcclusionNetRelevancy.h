/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortOcclusionNetRelevancy
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0xe0
class UFortOcclusionClientStatsComponent : public UActorComponent
{
public:
    int32_t NumPawnsWithinRelevancyRange() const { return Read<int32_t>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: IntProperty)
    int32_t NumPawnsCulled() const { return Read<int32_t>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: IntProperty)
    bool bServerSystemEnabled() const { return Read<bool>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    bool bServerUsingOcclusionFilter() const { return Read<bool>(uintptr_t(this) + 0xc1); } // 0xc1 (Size: 0x1, Type: BoolProperty)
    TArray<FVector> OccludedLocations() const { return Read<TArray<FVector>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)

    void SET_NumPawnsWithinRelevancyRange(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: IntProperty)
    void SET_NumPawnsCulled(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: IntProperty)
    void SET_bServerSystemEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    void SET_bServerUsingOcclusionFilter(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc1, Value); } // 0xc1 (Size: 0x1, Type: BoolProperty)
    void SET_OccludedLocations(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x300
class AFortOcclusionNetRelevancyServerDebug : public AActor
{
public:
    FFortOcclusionNetRelevancyStats ServerCurrentStats() const { return Read<FFortOcclusionNetRelevancyStats>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x50, Type: StructProperty)

    void SET_ServerCurrentStats(const FFortOcclusionNetRelevancyStats& Value) { Write<FFortOcclusionNetRelevancyStats>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x50, Type: StructProperty)
};

// Size: 0x168
class UFortOcclusionNetRelevancyWorldSubsystem : public UTickableWorldSubsystem
{
public:
    TArray<APawn*> AllPawns() const { return Read<TArray<APawn*>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
    UClass* PawnClassLoaded() const { return Read<UClass*>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<ECollisionChannel> CollisionChannelForOcclusionTraces() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x1, Type: ByteProperty)
    AFortOcclusionNetRelevancyServerDebug* ServerDebugActor() const { return Read<AFortOcclusionNetRelevancyServerDebug*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)

    void SET_AllPawns(const TArray<APawn*>& Value) { Write<TArray<APawn*>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x10, Type: ArrayProperty)
    void SET_PawnClassLoaded(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: ClassProperty)
    void SET_CollisionChannelForOcclusionTraces(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x1, Type: ByteProperty)
    void SET_ServerDebugActor(const AFortOcclusionNetRelevancyServerDebug*& Value) { Write<AFortOcclusionNetRelevancyServerDebug*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1b8
class UNetObjectGridOcclusionFilter : public UNetObjectGridWorldLocFilter
{
public:
};

// Size: 0x50
struct FFortOcclusionNetRelevancyStats
{
public:
    int32_t PlayerControllerCount() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t PlayerPawnCount() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t PawnsTestedForOcclusion() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t NumTraces() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    int32_t NumBlockedTraces() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t NumEarlyOutTraces() const { return Read<int32_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: IntProperty)
    int32_t NumTracesHitLandscape() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t NumTracesHitNonLandscape() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    int32_t OccludedPawns() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)
    int32_t PlayersBenefitingFromOcclusionCulling() const { return Read<int32_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: IntProperty)
    int32_t PlayerWithMostOccludedPawns() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    int32_t PlayerWithLeastOccludedPawns() const { return Read<int32_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: IntProperty)
    int32_t PawnsSkippingTraces() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    int32_t PawnsOutsideNetCullDist() const { return Read<int32_t>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: IntProperty)
    int32_t PawnsWithinFootStepRadius() const { return Read<int32_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: IntProperty)
    int32_t NumProcessedPawns() const { return Read<int32_t>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: IntProperty)
    int32_t NumPawnsReusingLastSeenResult() const { return Read<int32_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: IntProperty)
    float TotalServerTickTimeMS() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)

    void SET_PlayerControllerCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_PlayerPawnCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_PawnsTestedForOcclusion(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_NumTraces(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_NumBlockedTraces(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_NumEarlyOutTraces(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: IntProperty)
    void SET_NumTracesHitLandscape(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_NumTracesHitNonLandscape(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_OccludedPawns(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
    void SET_PlayersBenefitingFromOcclusionCulling(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: IntProperty)
    void SET_PlayerWithMostOccludedPawns(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_PlayerWithLeastOccludedPawns(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: IntProperty)
    void SET_PawnsSkippingTraces(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_PawnsOutsideNetCullDist(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: IntProperty)
    void SET_PawnsWithinFootStepRadius(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: IntProperty)
    void SET_NumProcessedPawns(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: IntProperty)
    void SET_NumPawnsReusingLastSeenResult(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: IntProperty)
    void SET_TotalServerTickTimeMS(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
};

