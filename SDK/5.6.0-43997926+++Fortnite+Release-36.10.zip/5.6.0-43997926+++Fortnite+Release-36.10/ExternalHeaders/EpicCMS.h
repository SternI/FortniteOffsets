/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicCMS
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x30
struct FDownloadCacheEntry
{
public:
    FString FilePath() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString SourceUrl() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FDateTime LastAccessTime() const { return Read<FDateTime>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: StructProperty)
    int32_t LifetimeInDays() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)

    void SET_FilePath(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_SourceUrl(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_LastAccessTime(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: StructProperty)
    void SET_LifetimeInDays(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
};

// Size: 0x58
struct FDownloadCache
{
public:
    int32_t Version() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    TMap<FDownloadCacheEntry, FString> Cache() const { return Read<TMap<FDownloadCacheEntry, FString>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x50, Type: MapProperty)

    void SET_Version(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_Cache(const TMap<FDownloadCacheEntry, FString>& Value) { Write<TMap<FDownloadCacheEntry, FString>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x50, Type: MapProperty)
};

