/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Accessories
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayTags.h"
#include "FortniteGame.h"

// Size: 0x28
class UVariantScript_Backpack_SquidGlisten_C : public UFortLoadoutTagDrivenVariantScript
{
public:
};

// Size: 0x28
class UVariantScript_Backpack_AnglePatch_Style_C : public UFortLoadoutTagDrivenVariantScript
{
public:
};

// Size: 0x28
class UVariantScript_Backpack_WealthLamb_Style_C : public UFortLoadoutTagDrivenVariantScript
{
public:
};

// Size: 0x28
class UVariantScript_Backpack_BistroAstronaut_Color_C : public UFortLoadoutTagDrivenVariantScript
{
public:
};

// Size: 0x28
class UVariantScript_Backpack_BistroAstronaut_Style_C : public UFortLoadoutTagDrivenVariantScript
{
public:
};

