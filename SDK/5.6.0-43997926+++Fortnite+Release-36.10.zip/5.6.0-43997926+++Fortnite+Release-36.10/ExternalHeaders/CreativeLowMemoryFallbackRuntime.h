/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeLowMemoryFallbackRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "CoreUObject.h"

// Size: 0x120
class UCreativeLowMemoryFallbackSettings : public UDeveloperSettings
{
public:
    TSoftObjectPtr<UObject> WarningToastIcon() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    FCreativeLowMemoryFallbackUserFacingText DefaultText() const { return Read<FCreativeLowMemoryFallbackUserFacingText>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x30, Type: StructProperty)
    TMap<FCreativeLowMemoryFallbackFreeMemoryThresholds, TSoftObjectPtr<UFortPlaylist*>> PlaylistOverrideThresholds() const { return Read<TMap<FCreativeLowMemoryFallbackFreeMemoryThresholds, TSoftObjectPtr<UFortPlaylist*>>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x50, Type: MapProperty)
    TMap<FCreativeLowMemoryFallbackUserFacingText, TSoftObjectPtr<UFortPlaylist*>> PlaylistOverrideText() const { return Read<TMap<FCreativeLowMemoryFallbackUserFacingText, TSoftObjectPtr<UFortPlaylist*>>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x50, Type: MapProperty)

    void SET_WarningToastIcon(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    void SET_DefaultText(const FCreativeLowMemoryFallbackUserFacingText& Value) { Write<FCreativeLowMemoryFallbackUserFacingText>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x30, Type: StructProperty)
    void SET_PlaylistOverrideThresholds(const TMap<FCreativeLowMemoryFallbackFreeMemoryThresholds, TSoftObjectPtr<UFortPlaylist*>>& Value) { Write<TMap<FCreativeLowMemoryFallbackFreeMemoryThresholds, TSoftObjectPtr<UFortPlaylist*>>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x50, Type: MapProperty)
    void SET_PlaylistOverrideText(const TMap<FCreativeLowMemoryFallbackUserFacingText, TSoftObjectPtr<UFortPlaylist*>>& Value) { Write<TMap<FCreativeLowMemoryFallbackUserFacingText, TSoftObjectPtr<UFortPlaylist*>>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x68
class UCreativeLowMemoryFallbackWorldSubsystem : public UWorldSubsystem
{
public:
    FCreativeLowMemoryFallbackFreeMemoryThresholds CurrentThresholds() const { return Read<FCreativeLowMemoryFallbackFreeMemoryThresholds>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0xc, Type: StructProperty)

    void SET_CurrentThresholds(const FCreativeLowMemoryFallbackFreeMemoryThresholds& Value) { Write<FCreativeLowMemoryFallbackFreeMemoryThresholds>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0xc, Type: StructProperty)
};

// Size: 0x30
struct FCreativeLowMemoryFallbackUserFacingText
{
public:
    FText ExitToMainMenuReasonText() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    FText WarningToastTitle() const { return Read<FText>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: TextProperty)
    FText WarningToastDescription() const { return Read<FText>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: TextProperty)

    void SET_ExitToMainMenuReasonText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_WarningToastTitle(const FText& Value) { Write<FText>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: TextProperty)
    void SET_WarningToastDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: TextProperty)
};

// Size: 0xc
struct FCreativeLowMemoryFallbackFreeMemoryThresholds
{
public:
    float FallbackMB() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float WarningMB() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float RecoveryMB() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_FallbackMB(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_WarningMB(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_RecoveryMB(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

