/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BeanstalkDevicesCoreRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x28
class UBeanDeviceFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x148
class UBeanObstacleImpactComponent : public UActorComponent
{
public:
    bool bApplyDefaultKnockback() const { return Read<bool>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    bool bApplyRagdoll() const { return Read<bool>(uintptr_t(this) + 0xd1); } // 0xd1 (Size: 0x1, Type: BoolProperty)
    TArray<FComponentReference> AffectedColliders() const { return Read<TArray<FComponentReference>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    FBeanKnockbackForceCalculator KnockbackForce() const { return Read<FBeanKnockbackForceCalculator>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x30, Type: StructProperty)
    bool bApplyImpactLocally() const { return Read<bool>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x1, Type: BoolProperty)
    double MaxExpectedComponentVelocityForServerValidation() const { return Read<double>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: DoubleProperty)
    TArray<TWeakObjectPtr<UPrimitiveComponent*>> CachedColliders() const { return Read<TArray<TWeakObjectPtr<UPrimitiveComponent*>>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x10, Type: ArrayProperty)
    TArray<FBeanComponentTransformDelta> CachedColliderDeltas() const { return Read<TArray<FBeanComponentTransformDelta>>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x10, Type: ArrayProperty)

    void SET_bApplyDefaultKnockback(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    void SET_bApplyRagdoll(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd1, Value); } // 0xd1 (Size: 0x1, Type: BoolProperty)
    void SET_AffectedColliders(const TArray<FComponentReference>& Value) { Write<TArray<FComponentReference>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    void SET_KnockbackForce(const FBeanKnockbackForceCalculator& Value) { Write<FBeanKnockbackForceCalculator>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x30, Type: StructProperty)
    void SET_bApplyImpactLocally(const bool& Value) { Write<bool>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x1, Type: BoolProperty)
    void SET_MaxExpectedComponentVelocityForServerValidation(const double& Value) { Write<double>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: DoubleProperty)
    void SET_CachedColliders(const TArray<TWeakObjectPtr<UPrimitiveComponent*>>& Value) { Write<TArray<TWeakObjectPtr<UPrimitiveComponent*>>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedColliderDeltas(const TArray<FBeanComponentTransformDelta>& Value) { Write<TArray<FBeanComponentTransformDelta>>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x108
class UBeanObstacleMeshSelectorComponent : public UActorComponent
{
public:
    FComponentReference TargetStaticMeshComponentRef() const { return Read<FComponentReference>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x28, Type: StructProperty)
    TArray<FSelectableMeshData> SelectableMeshes() const { return Read<TArray<FSelectableMeshData>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
    UStaticMeshComponent* TargetStaticMeshComponent() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: ObjectProperty)

    void SET_TargetStaticMeshComponentRef(const FComponentReference& Value) { Write<FComponentReference>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x28, Type: StructProperty)
    void SET_SelectableMeshes(const TArray<FSelectableMeshData>& Value) { Write<TArray<FSelectableMeshData>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
    void SET_TargetStaticMeshComponent(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UBeanObstacleMotion : public UObject
{
public:
};

// Size: 0x38
class UBeanObstacleMotion_Rotational : public UBeanObstacleMotion
{
public:
    TEnumAsByte<EAxis> RotationAxis() const { return Read<TEnumAsByte<EAxis>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: ByteProperty)
    float RotationSpeed() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float StartRotation() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)

    void SET_RotationAxis(const TEnumAsByte<EAxis>& Value) { Write<TEnumAsByte<EAxis>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: ByteProperty)
    void SET_RotationSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_StartRotation(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x58
class UBeanObstacleMotion_Punch : public UBeanObstacleMotion
{
public:
    FVector MovementVector() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    float StartDelay() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    float MoveOutDuration() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)
    float OutPauseDuration() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float MoveInDuration() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    float InPauseDuration() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)

    void SET_MovementVector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_StartDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_MoveOutDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
    void SET_OutPauseDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_MoveInDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_InPauseDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x1e0
class UBeanObstacleMovementComponent : public UActorComponent
{
public:
    bool bRegisterWithBeanTickManager() const { return (Read<uint8_t>(uintptr_t(this) + 0xb8) >> 0x0) & 1; } // 0xb8:0 (Size: 0x1, Type: BoolProperty)
    FComponentReference TargetComponentRef() const { return Read<FComponentReference>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x28, Type: StructProperty)
    UBeanObstacleMotion* ObstacleMotion() const { return Read<UBeanObstacleMotion*>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    bool bShouldSweep() const { return Read<bool>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x1, Type: BoolProperty)
    float ReconciliationInterpSpeed() const { return Read<float>(uintptr_t(this) + 0x124); } // 0x124 (Size: 0x4, Type: FloatProperty)
    bool bEnableEventSleeping() const { return Read<bool>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x1, Type: BoolProperty)
    double EventSleepDistanceThreshold() const { return Read<double>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x8, Type: DoubleProperty)
    double EventSleepPollInterval() const { return Read<double>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x8, Type: DoubleProperty)
    FVector TargetComponentOriginalRelativeLocation() const { return Read<FVector>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x18, Type: StructProperty)
    FQuat TargetComponentOriginalRelativeRotation() const { return Read<FQuat>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x20, Type: StructProperty)
    TWeakObjectPtr<USceneComponent*> TargetComponent() const { return Read<TWeakObjectPtr<USceneComponent*>>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x8, Type: WeakObjectProperty)
    double LastEventSleepPollTime() const { return Read<double>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x8, Type: DoubleProperty)
    bool bLastFiredEventWasStart() const { return (Read<uint8_t>(uintptr_t(this) + 0x190) >> 0x0) & 1; } // 0x190:0 (Size: 0x1, Type: BoolProperty)
    bool bAreEventsAsleep() const { return (Read<uint8_t>(uintptr_t(this) + 0x190) >> 0x1) & 1; } // 0x190:1 (Size: 0x1, Type: BoolProperty)
    bool bIsUsingTickManager() const { return (Read<uint8_t>(uintptr_t(this) + 0x190) >> 0x2) & 1; } // 0x190:2 (Size: 0x1, Type: BoolProperty)
    bool bIsObstacleTickSleeping() const { return (Read<uint8_t>(uintptr_t(this) + 0x190) >> 0x3) & 1; } // 0x190:3 (Size: 0x1, Type: BoolProperty)
    bool bStartWithMotionEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x190) >> 0x4) & 1; } // 0x190:4 (Size: 0x1, Type: BoolProperty)
    FBeanObstacleMotionRuntimeState ObstacleMotionRuntimeState() const { return Read<FBeanObstacleMotionRuntimeState>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x30, Type: StructProperty)
    double CurrentEvalTime() const { return Read<double>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x8, Type: DoubleProperty)
    uint8_t LastObstacleMovementState() const { return Read<uint8_t>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x1, Type: EnumProperty)

    void SET_bRegisterWithBeanTickManager(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xb8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xb8, B); } // 0xb8:0 (Size: 0x1, Type: BoolProperty)
    void SET_TargetComponentRef(const FComponentReference& Value) { Write<FComponentReference>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x28, Type: StructProperty)
    void SET_ObstacleMotion(const UBeanObstacleMotion*& Value) { Write<UBeanObstacleMotion*>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    void SET_bShouldSweep(const bool& Value) { Write<bool>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x1, Type: BoolProperty)
    void SET_ReconciliationInterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x124, Value); } // 0x124 (Size: 0x4, Type: FloatProperty)
    void SET_bEnableEventSleeping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x1, Type: BoolProperty)
    void SET_EventSleepDistanceThreshold(const double& Value) { Write<double>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x8, Type: DoubleProperty)
    void SET_EventSleepPollInterval(const double& Value) { Write<double>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x8, Type: DoubleProperty)
    void SET_TargetComponentOriginalRelativeLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x18, Type: StructProperty)
    void SET_TargetComponentOriginalRelativeRotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x20, Type: StructProperty)
    void SET_TargetComponent(const TWeakObjectPtr<USceneComponent*>& Value) { Write<TWeakObjectPtr<USceneComponent*>>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x8, Type: WeakObjectProperty)
    void SET_LastEventSleepPollTime(const double& Value) { Write<double>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x8, Type: DoubleProperty)
    void SET_bLastFiredEventWasStart(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x190); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x190, B); } // 0x190:0 (Size: 0x1, Type: BoolProperty)
    void SET_bAreEventsAsleep(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x190); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x190, B); } // 0x190:1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsUsingTickManager(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x190); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x190, B); } // 0x190:2 (Size: 0x1, Type: BoolProperty)
    void SET_bIsObstacleTickSleeping(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x190); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x190, B); } // 0x190:3 (Size: 0x1, Type: BoolProperty)
    void SET_bStartWithMotionEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x190); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x190, B); } // 0x190:4 (Size: 0x1, Type: BoolProperty)
    void SET_ObstacleMotionRuntimeState(const FBeanObstacleMotionRuntimeState& Value) { Write<FBeanObstacleMotionRuntimeState>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x30, Type: StructProperty)
    void SET_CurrentEvalTime(const double& Value) { Write<double>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x8, Type: DoubleProperty)
    void SET_LastObstacleMovementState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x5e0
class UBeanObstacleOptimizerComponent : public UBoxComponent
{
public:
    float ExtraMarginSize() const { return Read<float>(uintptr_t(this) + 0x550); } // 0x550 (Size: 0x4, Type: FloatProperty)
    bool bDisableCollidersWhenSleeping() const { return Read<bool>(uintptr_t(this) + 0x554); } // 0x554 (Size: 0x1, Type: BoolProperty)
    bool bDetachFromParentAndAttachToOptimizerActor() const { return Read<bool>(uintptr_t(this) + 0x555); } // 0x555 (Size: 0x1, Type: BoolProperty)
    bool bIsSleeping() const { return Read<bool>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x1, Type: BoolProperty)
    int32_t NumPawnsOverlapping() const { return Read<int32_t>(uintptr_t(this) + 0x56c); } // 0x56c (Size: 0x4, Type: IntProperty)
    TArray<TWeakObjectPtr<UPrimitiveComponent*>> OptimizableColliders() const { return Read<TArray<TWeakObjectPtr<UPrimitiveComponent*>>>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x10, Type: ArrayProperty)
    TMap<TEnumAsByte<ECollisionEnabled>, UPrimitiveComponent*> OptimizableCollidersOriginalCollisionEnabled() const { return Read<TMap<TEnumAsByte<ECollisionEnabled>, UPrimitiveComponent*>>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x50, Type: MapProperty)

    void SET_ExtraMarginSize(const float& Value) { Write<float>(uintptr_t(this) + 0x550, Value); } // 0x550 (Size: 0x4, Type: FloatProperty)
    void SET_bDisableCollidersWhenSleeping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x554, Value); } // 0x554 (Size: 0x1, Type: BoolProperty)
    void SET_bDetachFromParentAndAttachToOptimizerActor(const bool& Value) { Write<bool>(uintptr_t(this) + 0x555, Value); } // 0x555 (Size: 0x1, Type: BoolProperty)
    void SET_bIsSleeping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x1, Type: BoolProperty)
    void SET_NumPawnsOverlapping(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x56c, Value); } // 0x56c (Size: 0x4, Type: IntProperty)
    void SET_OptimizableColliders(const TArray<TWeakObjectPtr<UPrimitiveComponent*>>& Value) { Write<TArray<TWeakObjectPtr<UPrimitiveComponent*>>>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x10, Type: ArrayProperty)
    void SET_OptimizableCollidersOriginalCollisionEnabled(const TMap<TEnumAsByte<ECollisionEnabled>, UPrimitiveComponent*>& Value) { Write<TMap<TEnumAsByte<ECollisionEnabled>, UPrimitiveComponent*>>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x50, Type: MapProperty)
};

// Size: 0x2c0
class ABeanObstacleTickManager : public AActor
{
public:
};

// Size: 0x30
struct FBeanKnockbackForceCalculator
{
public:
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t ForceApplicationType() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)
    double Strength() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    double HorizontalStrength() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    double VerticalStrength() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    double Angle() const { return Read<double>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    bool bAddSourceColliderVelocity() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    float SourceColliderVelocityMultiplier() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)

    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_ForceApplicationType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
    void SET_Strength(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_HorizontalStrength(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    void SET_VerticalStrength(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    void SET_Angle(const double& Value) { Write<double>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    void SET_bAddSourceColliderVelocity(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_SourceColliderVelocityMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
};

// Size: 0xd0
struct FBeanComponentTransformDelta
{
public:
};

// Size: 0x20
struct FSelectableMeshData
{
public:
    TSoftObjectPtr<UStaticMesh> Mesh() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)

    void SET_Mesh(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x30
struct FBeanObstacleMotionRuntimeState
{
public:
    double MotionLockedChangedTime() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    bool bRewinding() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    double RewindChangedTime() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    double AccumulatedTimeOffset() const { return Read<double>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    double LocalAccumulatedTimeOffset() const { return Read<double>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: DoubleProperty)

    void SET_MotionLockedChangedTime(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_bRewinding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_RewindChangedTime(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
    void SET_AccumulatedTimeOffset(const double& Value) { Write<double>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: DoubleProperty)
    void SET_LocalAccumulatedTimeOffset(const double& Value) { Write<double>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: DoubleProperty)
};

