/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamSystemRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "CommonUI.h"
#include "FortniteGame.h"
#include "SparksCoreCosmeticsRuntime.h"
#include "GameplayTags.h"
#include "FMJamPlayspaceRuntime.h"
#include "GameplayAbilities.h"
#include "GameplayEventRouter.h"

// Size: 0xe0
class UJamControllerComponent : public UControllerComponent
{
public:
    FGameplayTagContainer AdditionalTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x20, Type: StructProperty)

    void SET_AdditionalTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x138
class UJamControllerComponent_LoopOptions : public UControllerComponent
{
public:
    FName CategoryNameLocker() const { return Read<FName>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: NameProperty)
    FName CategoryNameAll() const { return Read<FName>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: NameProperty)
    FText CategoryTitleLocker() const { return Read<FText>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: TextProperty)
    FText CategoryTitleAll() const { return Read<FText>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: TextProperty)
    FGameplayTag CategoryTagLocker() const { return Read<FGameplayTag>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: StructProperty)
    FGameplayTag CategoryTagAll() const { return Read<FGameplayTag>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: StructProperty)
    TArray<FJamControllerComponent_LoopOptions_TypeToIndexMappingEntry> LoopTypeToIndexMapping() const { return Read<TArray<FJamControllerComponent_LoopOptions_TypeToIndexMappingEntry>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    TArray<USparksJamEmoteItemDefinition*> LoadedItemDefs() const { return Read<TArray<USparksJamEmoteItemDefinition*>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x10, Type: ArrayProperty)

    void SET_CategoryNameLocker(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: NameProperty)
    void SET_CategoryNameAll(const FName& Value) { Write<FName>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: NameProperty)
    void SET_CategoryTitleLocker(const FText& Value) { Write<FText>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: TextProperty)
    void SET_CategoryTitleAll(const FText& Value) { Write<FText>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: TextProperty)
    void SET_CategoryTagLocker(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: StructProperty)
    void SET_CategoryTagAll(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: StructProperty)
    void SET_LoopTypeToIndexMapping(const TArray<FJamControllerComponent_LoopOptions_TypeToIndexMappingEntry>& Value) { Write<TArray<FJamControllerComponent_LoopOptions_TypeToIndexMappingEntry>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    void SET_LoadedItemDefs(const TArray<USparksJamEmoteItemDefinition*>& Value) { Write<TArray<USparksJamEmoteItemDefinition*>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x110
class UJamControllerComponent_LoopPreloader : public UControllerComponent
{
public:
    bool bHaveRegisteredForOnLoadoutFilled() const { return Read<bool>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: BoolProperty)

    void SET_bHaveRegisteredForOnLoadoutFilled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x4b0
class UJamGlobalControlsWidget : public UCommonActivatableWidget
{
public:
    UCommonButtonBase* Button_Close() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AJamPlayspace*> JamPlayspace() const { return Read<TWeakObjectPtr<AJamPlayspace*>>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: WeakObjectProperty)
    UGameplayAbility* GameplayAbility() const { return Read<UGameplayAbility*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)

    void SET_Button_Close(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    void SET_JamPlayspace(const TWeakObjectPtr<AJamPlayspace*>& Value) { Write<TWeakObjectPtr<AJamPlayspace*>>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: WeakObjectProperty)
    void SET_GameplayAbility(const UGameplayAbility*& Value) { Write<UGameplayAbility*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1c8
class UJamOnOffSwitchComponent : public UPlayerStateComponent
{
public:
    FScalableFloat bEnableJam() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x28, Type: StructProperty)
    UClass* JamBlockerEffect() const { return Read<UClass*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ClassProperty)
    FActiveGameplayEffectHandle JamBlockerEffectHandle() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: StructProperty)
    FGameplayEventListenerHandle GamePhaseUpdatedEventHandle() const { return Read<FGameplayEventListenerHandle>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x1c, Type: StructProperty)
    FGameplayEventListenerHandle GamePhaseStepUpdatedEventHandle() const { return Read<FGameplayEventListenerHandle>(uintptr_t(this) + 0x10c); } // 0x10c (Size: 0x1c, Type: StructProperty)
    FGlobalMemoryRequestHandle GlobalMemoryRequestHandle() const { return Read<FGlobalMemoryRequestHandle>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: StructProperty)

    void SET_bEnableJam(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x28, Type: StructProperty)
    void SET_JamBlockerEffect(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ClassProperty)
    void SET_JamBlockerEffectHandle(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: StructProperty)
    void SET_GamePhaseUpdatedEventHandle(const FGameplayEventListenerHandle& Value) { Write<FGameplayEventListenerHandle>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x1c, Type: StructProperty)
    void SET_GamePhaseStepUpdatedEventHandle(const FGameplayEventListenerHandle& Value) { Write<FGameplayEventListenerHandle>(uintptr_t(this) + 0x10c, Value); } // 0x10c (Size: 0x1c, Type: StructProperty)
    void SET_GlobalMemoryRequestHandle(const FGlobalMemoryRequestHandle& Value) { Write<FGlobalMemoryRequestHandle>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: StructProperty)
};

// Size: 0xe0
class UJamPlayerPawnComponent : public UPawnComponent
{
public:
    FGameplayTagContainer AdditionalTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x20, Type: StructProperty)

    void SET_AdditionalTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x100
class UJamQuestComponent : public UPlayspaceComponent
{
public:
};

// Size: 0x28
class UJamSystemBPFL : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UJamSystemEmoteBPFL : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x8
struct FJamControllerComponent_LoopOptions_TypeToIndexMappingEntry
{
public:
    uint8_t LoopType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    int32_t MultiEmoteIndex() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_LoopType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_MultiEmoteIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

