/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DynamicAthenaHUD
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "DynamicUI.h"
#include "FortniteGame.h"

// Size: 0x320
class ADynamicAthenaHUDDirector : public ADynamicUIDirectorBase
{
public:
    UDynamicUIScene* VehicleHUDScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* CreativeQuickbarScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* PlayerMessagesScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* TournamentScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* ArenaTournamentScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* BuildWatermarkScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* LoadingMessageScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* LocalPlayerInfoScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* BusReticleScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    TArray<UDynamicUIScene*> AddedScenes() const { return Read<TArray<UDynamicUIScene*>>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x10, Type: ArrayProperty)

    void SET_VehicleHUDScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    void SET_CreativeQuickbarScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerMessagesScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    void SET_TournamentScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    void SET_ArenaTournamentScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    void SET_BuildWatermarkScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    void SET_LoadingMessageScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    void SET_LocalPlayerInfoScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    void SET_BusReticleScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    void SET_AddedScenes(const TArray<UDynamicUIScene*>& Value) { Write<TArray<UDynamicUIScene*>>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x10, Type: ArrayProperty)
};

