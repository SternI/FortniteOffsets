/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamDecksUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FMJamDecksRuntime.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "UMG.h"
#include "DynamicUI.h"
#include "FMJamUI.h"
#include "CoreUObject.h"
#include "FortniteUI.h"

// Size: 0x438
class UJamDeckEmitterIndicatorBase : public UFortActorIndicatorWidget
{
public:
};

// Size: 0xc8
class UJamDecksControllerComponent_IndicatorsManager : public UControllerComponent
{
public:
    UDynamicUIScene* DynamicUISceneToAdd() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)

    void SET_DynamicUISceneToAdd(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x108
class UJamDecksEmitterComponent_IndicatorsProvider : public UActorComponent
{
public:
    TArray<UClass*> WithinPlayspaceIndicators() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> WhileFocusedIndicators() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    TArray<FJamDecksEmitterComponent_IndicatorsProviderPlayerDetails> PerPlayerData() const { return Read<TArray<FJamDecksEmitterComponent_IndicatorsProviderPlayerDetails>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
    UJamDeckViewModel* JamDeckViewModel() const { return Read<UJamDeckViewModel*>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: ObjectProperty)

    void SET_WithinPlayspaceIndicators(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    void SET_WhileFocusedIndicators(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    void SET_PerPlayerData(const TArray<FJamDecksEmitterComponent_IndicatorsProviderPlayerDetails>& Value) { Write<TArray<FJamDecksEmitterComponent_IndicatorsProviderPlayerDetails>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
    void SET_JamDeckViewModel(const UJamDeckViewModel*& Value) { Write<UJamDeckViewModel*>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x140
class UJamDecksGameStateComponent_IndicatorCache : public UActorComponent
{
public:
    FUserWidgetPool WidgetPool() const { return Read<FUserWidgetPool>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x88, Type: StructProperty)

    void SET_WidgetPool(const FUserWidgetPool& Value) { Write<FUserWidgetPool>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x88, Type: StructProperty)
};

// Size: 0x390
class UJamDecksIndicatorLayerBase : public UFortHUDElementWidget
{
public:
    UFortActorCanvas* EmitterIndicators() const { return Read<UFortActorCanvas*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)

    void SET_EmitterIndicators(const UFortActorCanvas*& Value) { Write<UFortActorCanvas*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xf8
class UJamDecksMusicSlotSelectorComponent : public UActorComponent
{
public:
};

// Size: 0x118
class UJamDecksPickerOverriderComponent : public UControllerComponent
{
public:
};

// Size: 0xc0
class UJamDeckViewModel : public UMVVMViewModelBase
{
public:
    UJamMusicSlotVM* MusicSlotVM() const { return Read<UJamMusicSlotVM*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    FText OwnerName() const { return Read<FText>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: TextProperty)
    TArray<APlayerController*> FocusingPlayers() const { return Read<TArray<APlayerController*>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)

    void SET_MusicSlotVM(const UJamMusicSlotVM*& Value) { Write<UJamMusicSlotVM*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_OwnerName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: TextProperty)
    void SET_FocusingPlayers(const TArray<APlayerController*>& Value) { Write<TArray<APlayerController*>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xc8
class UQuickJoinButtonBehaviorExtension : public UFortMobileActionButtonBehaviorExtension
{
public:
    FGameplayTagQuery QuickJoinTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x48, Type: StructProperty)

    void SET_QuickJoinTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x48, Type: StructProperty)
};

// Size: 0x20
struct FJamDecksEmitterComponent_IndicatorsProviderPlayerDetails
{
public:
    APlayerController* Player() const { return Read<APlayerController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<UJamDeckEmitterIndicatorBase*> IndicatorsInUse() const { return Read<TArray<UJamDeckEmitterIndicatorBase*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Player(const APlayerController*& Value) { Write<APlayerController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_IndicatorsInUse(const TArray<UJamDeckEmitterIndicatorBase*>& Value) { Write<TArray<UJamDeckEmitterIndicatorBase*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

