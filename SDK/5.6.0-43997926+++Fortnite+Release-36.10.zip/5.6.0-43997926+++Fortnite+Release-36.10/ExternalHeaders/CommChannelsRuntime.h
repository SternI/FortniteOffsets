/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CommChannelsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x68
struct FCommChannelNode
{
public:
};

