/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarModerator
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "DelMarCore.h"
#include "DynamicUI.h"

// Size: 0xd0
class UDelMarModeratorModeComponent : public UControllerComponent
{
public:
    UDynamicUIScene* ModeratorScene() const { return Read<UDynamicUIScene*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    ADelMarVehicle* CachedVehicle() const { return Read<ADelMarVehicle*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)

    void SET_ModeratorScene(const UDynamicUIScene*& Value) { Write<UDynamicUIScene*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedVehicle(const ADelMarVehicle*& Value) { Write<ADelMarVehicle*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
};

