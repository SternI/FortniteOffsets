/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Cosmetics
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "AnimGraphRuntime.h"

// Size: 0x20
struct FBeanstalkCosmetics_MaterialTypeInfo
{
public:
    FName Name_5_2545F8D141FCEFF4E1C26E95718DB478() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    double Metallic_17_26B17D57490B8DE99FD6AD85D810F3EB() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Roughness_10_EF64094F4DFFACDF1F733FA3C3858409() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    double Emissive_19_4467043B429E4D5BECF743BAE9E8BF3B() const { return Read<double>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: DoubleProperty)

    void SET_Name_5_2545F8D141FCEFF4E1C26E95718DB478(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Metallic_17_26B17D57490B8DE99FD6AD85D810F3EB(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_Roughness_10_EF64094F4DFFACDF1F733FA3C3858409(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
    void SET_Emissive_19_4467043B429E4D5BECF743BAE9E8BF3B(const double& Value) { Write<double>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x10
struct FBeanstalkCosmetics_RoughnessValuesInfo
{
public:
    FName Name_5_2545F8D141FCEFF4E1C26E95718DB478() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    double Roughness_10_EF64094F4DFFACDF1F733FA3C3858409() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)

    void SET_Name_5_2545F8D141FCEFF4E1C26E95718DB478(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Roughness_10_EF64094F4DFFACDF1F733FA3C3858409(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x28
struct FBeanstalkCosmetics_PatternAtlasTextureSlotsInfo
{
public:
    FString Name_15_2545F8D141FCEFF4E1C26E95718DB478() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FVector UV_Values_20_EF64094F4DFFACDF1F733FA3C3858409() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)

    void SET_Name_15_2545F8D141FCEFF4E1C26E95718DB478(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_UV_Values_20_EF64094F4DFFACDF1F733FA3C3858409(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
};

// Size: 0x1b8
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
public:
    FName __NameProperty_10() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_11() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    bool __BoolProperty_12() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)
    float __FloatProperty_13() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    FInputScaleBiasClampConstants __StructProperty_14() const { return Read<FInputScaleBiasClampConstants>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x2c, Type: StructProperty)
    float __FloatProperty_15() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    uint8_t __EnumProperty_16() const { return Read<uint8_t>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x1, Type: EnumProperty)
    bool __BoolProperty_17() const { return Read<bool>(uintptr_t(this) + 0x45); } // 0x45 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EAnimGroupRole> __ByteProperty_18() const { return Read<TEnumAsByte<EAnimGroupRole>>(uintptr_t(this) + 0x46); } // 0x46 (Size: 0x1, Type: ByteProperty)
    FName __NameProperty_19() const { return Read<FName>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: NameProperty)
    FAnimNodeFunctionRef __StructProperty_20() const { return Read<FAnimNodeFunctionRef>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess() const { return Read<FAnimSubsystem_PropertyAccess>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x80, Type: StructProperty)
    FAnimSubsystem_Base AnimBlueprintExtension_Base() const { return Read<FAnimSubsystem_Base>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x40, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Slot() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x30, Type: StructProperty)

    void SET___NameProperty_10(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_11(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET___BoolProperty_12(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
    void SET___FloatProperty_13(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET___StructProperty_14(const FInputScaleBiasClampConstants& Value) { Write<FInputScaleBiasClampConstants>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x2c, Type: StructProperty)
    void SET___FloatProperty_15(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET___EnumProperty_16(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x1, Type: EnumProperty)
    void SET___BoolProperty_17(const bool& Value) { Write<bool>(uintptr_t(this) + 0x45, Value); } // 0x45 (Size: 0x1, Type: BoolProperty)
    void SET___ByteProperty_18(const TEnumAsByte<EAnimGroupRole>& Value) { Write<TEnumAsByte<EAnimGroupRole>>(uintptr_t(this) + 0x46, Value); } // 0x46 (Size: 0x1, Type: ByteProperty)
    void SET___NameProperty_19(const FName& Value) { Write<FName>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: NameProperty)
    void SET___StructProperty_20(const FAnimNodeFunctionRef& Value) { Write<FAnimNodeFunctionRef>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
    void SET_AnimBlueprintExtension_PropertyAccess(const FAnimSubsystem_PropertyAccess& Value) { Write<FAnimSubsystem_PropertyAccess>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x80, Type: StructProperty)
    void SET_AnimBlueprintExtension_Base(const FAnimSubsystem_Base& Value) { Write<FAnimSubsystem_Base>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x40, Type: StructProperty)
    void SET_AnimGraphNode_Root(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_Slot(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x30, Type: StructProperty)
};

// Size: 0xab0
class UABP_BeanChar_Frontend_C : public UFrontendAnimInstance
{
public:
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess() const { return Read<FAnimSubsystemInstance>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x8, Type: StructProperty)
    FAnimSubsystemInstance AnimBlueprintExtension_Base() const { return Read<FAnimSubsystemInstance>(uintptr_t(this) + 0x9f8); } // 0x9f8 (Size: 0x8, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root() const { return Read<FAnimNode_Root>(uintptr_t(this) + 0xa00); } // 0xa00 (Size: 0x20, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xa20); } // 0xa20 (Size: 0x48, Type: StructProperty)
    FAnimNode_Slot AnimGraphNode_Slot() const { return Read<FAnimNode_Slot>(uintptr_t(this) + 0xa68); } // 0xa68 (Size: 0x48, Type: StructProperty)

    void SET_AnimBlueprintExtension_PropertyAccess(const FAnimSubsystemInstance& Value) { Write<FAnimSubsystemInstance>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x8, Type: StructProperty)
    void SET_AnimBlueprintExtension_Base(const FAnimSubsystemInstance& Value) { Write<FAnimSubsystemInstance>(uintptr_t(this) + 0x9f8, Value); } // 0x9f8 (Size: 0x8, Type: StructProperty)
    void SET_AnimGraphNode_Root(const FAnimNode_Root& Value) { Write<FAnimNode_Root>(uintptr_t(this) + 0xa00, Value); } // 0xa00 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xa20, Value); } // 0xa20 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_Slot(const FAnimNode_Slot& Value) { Write<FAnimNode_Slot>(uintptr_t(this) + 0xa68, Value); } // 0xa68 (Size: 0x48, Type: StructProperty)
};

