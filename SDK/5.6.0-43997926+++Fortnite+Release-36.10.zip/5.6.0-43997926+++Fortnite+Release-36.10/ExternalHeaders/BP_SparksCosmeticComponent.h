/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_SparksCosmeticComponent
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayEventRouter.h"
#include "UMG.h"

// Size: 0x500
class UBP_SparksCosmeticComponent_C : public USparksCosmeticComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x8, Type: StructProperty)
    UGameplayEventRouterComponent* Event_Router() const { return Read<UGameplayEventRouterComponent*>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    UUserWidget* DebugWidget() const { return Read<UUserWidget*>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x8, Type: StructProperty)
    void SET_Event_Router(const UGameplayEventRouterComponent*& Value) { Write<UGameplayEventRouterComponent*>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    void SET_DebugWidget(const UUserWidget*& Value) { Write<UUserWidget*>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x8, Type: ObjectProperty)
};

