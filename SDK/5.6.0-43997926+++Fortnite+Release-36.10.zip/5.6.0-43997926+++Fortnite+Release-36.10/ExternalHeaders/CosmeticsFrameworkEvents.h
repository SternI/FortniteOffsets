/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CosmeticsFrameworkEvents
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x28
class UCosmeticsEventRegistrar : public UInterface
{
public:
};

// Size: 0x28
class UCosmeticsFinishable : public UInterface
{
public:
};

// Size: 0x28
class UCosmeticsMeshTarget : public UInterface
{
public:
};

// Size: 0x28
class UCosmeticsStreaming : public UInterface
{
public:
};

// Size: 0x1
struct FCosmeticsEventHandle
{
public:
};

