/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DiscoveryBrowserUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "FortniteUI.h"
#include "CoreUObject.h"
#include "CommonUI.h"
#include "FortniteGame.h"
#include "UMG.h"
#include "Engine.h"
#include "Party.h"

// Size: 0x98
class UDiscoverSelectedActivityViewModel : public UMVVMViewModelBase
{
public:
    bool bLoading() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)
    bool bHasPartyData() const { return Read<bool>(uintptr_t(this) + 0x69); } // 0x69 (Size: 0x1, Type: BoolProperty)
    bool bIsLibrary() const { return Read<bool>(uintptr_t(this) + 0x6a); } // 0x6a (Size: 0x1, Type: BoolProperty)
    bool bIsActiveInvite() const { return Read<bool>(uintptr_t(this) + 0x6b); } // 0x6b (Size: 0x1, Type: BoolProperty)
    bool bIsPartyPrivate() const { return Read<bool>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x1, Type: BoolProperty)
    int32_t CurrentPartySize() const { return Read<int32_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: IntProperty)
    FText RichPresenceText() const { return Read<FText>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: TextProperty)
    UFortActivityViewModel* ActivityVM() const { return Read<UFortActivityViewModel*>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: ObjectProperty)

    void SET_bLoading(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
    void SET_bHasPartyData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x69, Value); } // 0x69 (Size: 0x1, Type: BoolProperty)
    void SET_bIsLibrary(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6a, Value); } // 0x6a (Size: 0x1, Type: BoolProperty)
    void SET_bIsActiveInvite(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6b, Value); } // 0x6b (Size: 0x1, Type: BoolProperty)
    void SET_bIsPartyPrivate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x1, Type: BoolProperty)
    void SET_CurrentPartySize(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: IntProperty)
    void SET_RichPresenceText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: TextProperty)
    void SET_ActivityVM(const UFortActivityViewModel*& Value) { Write<UFortActivityViewModel*>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x15c0
class UFortActivityBrowserLibraryTile : public UFortActivityBrowserTileBase
{
public:
    UFortSidebarOnboardTooltipWidget* OnboardingTooltip() const { return Read<UFortSidebarOnboardTooltipWidget*>(uintptr_t(this) + 0x1580); } // 0x1580 (Size: 0x8, Type: ObjectProperty)

    void SET_OnboardingTooltip(const UFortSidebarOnboardTooltipWidget*& Value) { Write<UFortSidebarOnboardTooltipWidget*>(uintptr_t(this) + 0x1580, Value); } // 0x1580 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1570
class UFortActivityBrowserTileBase : public UCommonButtonBase
{
public:
};

// Size: 0x38
class UFortActivityListItemWrapper : public UObject
{
public:
};

// Size: 0x460
class UFortDiscoverBrowserGridRow : public UFortActivityBrowserRow
{
public:
    int32_t ItemIndexRepresented() const { return Read<int32_t>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x4, Type: IntProperty)
    bool bSupportLessThanMaxVisibleSubRows() const { return Read<bool>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x1, Type: BoolProperty)
    bool bUseSizeShiftedFocusOffset() const { return Read<bool>(uintptr_t(this) + 0x459); } // 0x459 (Size: 0x1, Type: BoolProperty)

    void SET_ItemIndexRepresented(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x4, Type: IntProperty)
    void SET_bSupportLessThanMaxVisibleSubRows(const bool& Value) { Write<bool>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x1, Type: BoolProperty)
    void SET_bUseSizeShiftedFocusOffset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x459, Value); } // 0x459 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x448
class UFortActivityBrowserRow : public UCommonUserWidget
{
public:
    int32_t MinimumVisibilityPercentageForRowActivation() const { return Read<int32_t>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x4, Type: IntProperty)
    UFortDiscoverItemSelectorBase* OverrideItemSelector() const { return Read<UFortDiscoverItemSelectorBase*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    UFortDiscoverSurfaceViewModel* SurfaceViewModel() const { return Read<UFortDiscoverSurfaceViewModel*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    uint8_t PanelViewModelSource() const { return Read<uint8_t>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x1, Type: EnumProperty)
    UFortNestedButtonGroupSelectionVM* NestedButtonGroupSelectionVM() const { return Read<UFortNestedButtonGroupSelectionVM*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_CategoryName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x438); } // 0x438 (Size: 0x8, Type: ObjectProperty)

    void SET_MinimumVisibilityPercentageForRowActivation(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x4, Type: IntProperty)
    void SET_OverrideItemSelector(const UFortDiscoverItemSelectorBase*& Value) { Write<UFortDiscoverItemSelectorBase*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_SurfaceViewModel(const UFortDiscoverSurfaceViewModel*& Value) { Write<UFortDiscoverSurfaceViewModel*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_PanelViewModelSource(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x1, Type: EnumProperty)
    void SET_NestedButtonGroupSelectionVM(const UFortNestedButtonGroupSelectionVM*& Value) { Write<UFortNestedButtonGroupSelectionVM*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_CategoryName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x438, Value); } // 0x438 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4a8
class UFortDiscoverHomespace : public UScrollableActivatableWidget
{
public:
    UWidget* HomebarWidget() const { return Read<UWidget*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)

    void SET_HomebarWidget(const UWidget*& Value) { Write<UWidget*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x108
class UFortDiscoverPreviewManager : public UObject
{
public:
};

// Size: 0x80
class UFortActivityBrowserColorSchemeAsset : public UDataAsset
{
public:
    TMap<FColorSchemeParamaterValues, UMaterialParameterCollection*> MaterialCollectionOverrides() const { return Read<TMap<FColorSchemeParamaterValues, UMaterialParameterCollection*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)

    void SET_MaterialCollectionOverrides(const TMap<FColorSchemeParamaterValues, UMaterialParameterCollection*>& Value) { Write<TMap<FColorSchemeParamaterValues, UMaterialParameterCollection*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
};

// Size: 0x500
class UFortActivityBrowserListView : public UListViewBase
{
public:
    float DirectionalNavigationTimeThreshold() const { return Read<float>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x4, Type: FloatProperty)
    UClass* DiscoverItemRowClass() const { return Read<UClass*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ClassProperty)
    UClass* HomebarItemRowClass() const { return Read<UClass*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ClassProperty)
    UClass* BannerItemRowClass() const { return Read<UClass*>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: ClassProperty)
    UClass* NonScrollingItemRowClass() const { return Read<UClass*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ClassProperty)
    UClass* ScrollingViewModelItemRowClass() const { return Read<UClass*>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x8, Type: ClassProperty)
    TMap<UClass*, FName> RowTypes() const { return Read<TMap<UClass*, FName>>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x50, Type: MapProperty)
    UFortDiscoverItemSelectorBase* OverrideItemSelector() const { return Read<UFortDiscoverItemSelectorBase*>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    UFortDiscoverSurfaceViewModel* SurfaceViewModel() const { return Read<UFortDiscoverSurfaceViewModel*>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x8, Type: ObjectProperty)
    bool bAllowNonFullGridRows() const { return Read<bool>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x1, Type: BoolProperty)
    bool bUseTinyOffsetWhenScrollingIntoView() const { return Read<bool>(uintptr_t(this) + 0x409); } // 0x409 (Size: 0x1, Type: BoolProperty)
    bool bAllowInternalRowSelection() const { return Read<bool>(uintptr_t(this) + 0x40a); } // 0x40a (Size: 0x1, Type: BoolProperty)

    void SET_DirectionalNavigationTimeThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x4, Type: FloatProperty)
    void SET_DiscoverItemRowClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ClassProperty)
    void SET_HomebarItemRowClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ClassProperty)
    void SET_BannerItemRowClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: ClassProperty)
    void SET_NonScrollingItemRowClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ClassProperty)
    void SET_ScrollingViewModelItemRowClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x8, Type: ClassProperty)
    void SET_RowTypes(const TMap<UClass*, FName>& Value) { Write<TMap<UClass*, FName>>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x50, Type: MapProperty)
    void SET_OverrideItemSelector(const UFortDiscoverItemSelectorBase*& Value) { Write<UFortDiscoverItemSelectorBase*>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    void SET_SurfaceViewModel(const UFortDiscoverSurfaceViewModel*& Value) { Write<UFortDiscoverSurfaceViewModel*>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x8, Type: ObjectProperty)
    void SET_bAllowNonFullGridRows(const bool& Value) { Write<bool>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x1, Type: BoolProperty)
    void SET_bUseTinyOffsetWhenScrollingIntoView(const bool& Value) { Write<bool>(uintptr_t(this) + 0x409, Value); } // 0x409 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowInternalRowSelection(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40a, Value); } // 0x40a (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1640
class UFortActivityBrowserPlayWithFriendsTile : public UFortActivityBrowserTileBase
{
public:
    int32_t MaxNamesToDisplay() const { return Read<int32_t>(uintptr_t(this) + 0x1578); } // 0x1578 (Size: 0x4, Type: IntProperty)
    int32_t MaxPortraitsToDisplay() const { return Read<int32_t>(uintptr_t(this) + 0x157c); } // 0x157c (Size: 0x4, Type: IntProperty)
    UFortJoinablePartyPortraitsDisplay* PartyMembersAvatarsDisplay() const { return Read<UFortJoinablePartyPortraitsDisplay*>(uintptr_t(this) + 0x1590); } // 0x1590 (Size: 0x8, Type: ObjectProperty)
    bool bIsActiveInvite() const { return Read<bool>(uintptr_t(this) + 0x1598); } // 0x1598 (Size: 0x1, Type: BoolProperty)
    int32_t CurrentPartySize() const { return Read<int32_t>(uintptr_t(this) + 0x159c); } // 0x159c (Size: 0x4, Type: IntProperty)
    bool bIsPartyPrivate() const { return Read<bool>(uintptr_t(this) + 0x15a0); } // 0x15a0 (Size: 0x1, Type: BoolProperty)
    UFortGameActivity* CachedGameActivity() const { return Read<UFortGameActivity*>(uintptr_t(this) + 0x15a8); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<USocialUser*> CachedTargetSocialUser() const { return Read<TWeakObjectPtr<USocialUser*>>(uintptr_t(this) + 0x15c0); } // 0x15c0 (Size: 0x8, Type: WeakObjectProperty)
    FText CurrentCTAButtonText() const { return Read<FText>(uintptr_t(this) + 0x15c8); } // 0x15c8 (Size: 0x10, Type: TextProperty)
    FText JoinPartyText() const { return Read<FText>(uintptr_t(this) + 0x15d8); } // 0x15d8 (Size: 0x10, Type: TextProperty)
    FText RequestToJoinText() const { return Read<FText>(uintptr_t(this) + 0x15e8); } // 0x15e8 (Size: 0x10, Type: TextProperty)
    FDataTableRowHandle JoinFriendInputAction_Touch() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x15f8); } // 0x15f8 (Size: 0x10, Type: StructProperty)

    void SET_MaxNamesToDisplay(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1578, Value); } // 0x1578 (Size: 0x4, Type: IntProperty)
    void SET_MaxPortraitsToDisplay(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x157c, Value); } // 0x157c (Size: 0x4, Type: IntProperty)
    void SET_PartyMembersAvatarsDisplay(const UFortJoinablePartyPortraitsDisplay*& Value) { Write<UFortJoinablePartyPortraitsDisplay*>(uintptr_t(this) + 0x1590, Value); } // 0x1590 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsActiveInvite(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1598, Value); } // 0x1598 (Size: 0x1, Type: BoolProperty)
    void SET_CurrentPartySize(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x159c, Value); } // 0x159c (Size: 0x4, Type: IntProperty)
    void SET_bIsPartyPrivate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15a0, Value); } // 0x15a0 (Size: 0x1, Type: BoolProperty)
    void SET_CachedGameActivity(const UFortGameActivity*& Value) { Write<UFortGameActivity*>(uintptr_t(this) + 0x15a8, Value); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedTargetSocialUser(const TWeakObjectPtr<USocialUser*>& Value) { Write<TWeakObjectPtr<USocialUser*>>(uintptr_t(this) + 0x15c0, Value); } // 0x15c0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_CurrentCTAButtonText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x15c8, Value); } // 0x15c8 (Size: 0x10, Type: TextProperty)
    void SET_JoinPartyText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x15d8, Value); } // 0x15d8 (Size: 0x10, Type: TextProperty)
    void SET_RequestToJoinText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x15e8, Value); } // 0x15e8 (Size: 0x10, Type: TextProperty)
    void SET_JoinFriendInputAction_Touch(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x15f8, Value); } // 0x15f8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x468
class UFortActivityBrowserRowList : public UFortActivityBrowserRow
{
public:
    UFortActivityListView* ListView_Activities() const { return Read<UFortActivityListView*>(uintptr_t(this) + 0x448); } // 0x448 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_PageLeft() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_PageRight() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x8, Type: ObjectProperty)

    void SET_ListView_Activities(const UFortActivityListView*& Value) { Write<UFortActivityListView*>(uintptr_t(this) + 0x448, Value); } // 0x448 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_PageLeft(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_PageRight(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x740
class UFortActivityBrowserRowView : public UFortActivityBrowserView
{
public:
    float MouseWheelScrollTimeThreshold() const { return Read<float>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x4, Type: FloatProperty)
    UFortActivityBrowserListView* BrowserList_Activities() const { return Read<UFortActivityBrowserListView*>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    FName TabNameID() const { return Read<FName>(uintptr_t(this) + 0x618); } // 0x618 (Size: 0x4, Type: NameProperty)
    FFortTabButtonLabelInfo TabButtonLabelInfo() const { return Read<FFortTabButtonLabelInfo>(uintptr_t(this) + 0x620); } // 0x620 (Size: 0xf0, Type: StructProperty)
    UFortSwipePanel* SwipePanel_Navigation() const { return Read<UFortSwipePanel*>(uintptr_t(this) + 0x710); } // 0x710 (Size: 0x8, Type: ObjectProperty)
    TArray<FName> ActivityProviderFilter() const { return Read<TArray<FName>>(uintptr_t(this) + 0x718); } // 0x718 (Size: 0x10, Type: ArrayProperty)
    uint8_t ActivityProviderFilterType() const { return Read<uint8_t>(uintptr_t(this) + 0x728); } // 0x728 (Size: 0x1, Type: EnumProperty)

    void SET_MouseWheelScrollTimeThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x4, Type: FloatProperty)
    void SET_BrowserList_Activities(const UFortActivityBrowserListView*& Value) { Write<UFortActivityBrowserListView*>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    void SET_TabNameID(const FName& Value) { Write<FName>(uintptr_t(this) + 0x618, Value); } // 0x618 (Size: 0x4, Type: NameProperty)
    void SET_TabButtonLabelInfo(const FFortTabButtonLabelInfo& Value) { Write<FFortTabButtonLabelInfo>(uintptr_t(this) + 0x620, Value); } // 0x620 (Size: 0xf0, Type: StructProperty)
    void SET_SwipePanel_Navigation(const UFortSwipePanel*& Value) { Write<UFortSwipePanel*>(uintptr_t(this) + 0x710, Value); } // 0x710 (Size: 0x8, Type: ObjectProperty)
    void SET_ActivityProviderFilter(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x718, Value); } // 0x718 (Size: 0x10, Type: ArrayProperty)
    void SET_ActivityProviderFilterType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x728, Value); } // 0x728 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x598
class UFortActivityBrowserView : public UFortActivityView
{
public:
    bool bShowCustomMatchmakingModalButton() const { return Read<bool>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x1, Type: BoolProperty)
    bool bShowSpectateMatchModalButton() const { return Read<bool>(uintptr_t(this) + 0x4c9); } // 0x4c9 (Size: 0x1, Type: BoolProperty)
    bool bShowMobileGameDetailsButton() const { return Read<bool>(uintptr_t(this) + 0x4ca); } // 0x4ca (Size: 0x1, Type: BoolProperty)
    bool bShowMobileAcceptButton() const { return Read<bool>(uintptr_t(this) + 0x4cb); } // 0x4cb (Size: 0x1, Type: BoolProperty)
    bool bShowBackToTopButton() const { return Read<bool>(uintptr_t(this) + 0x4cc); } // 0x4cc (Size: 0x1, Type: BoolProperty)
    FName DiscoverySurfaceName() const { return Read<FName>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x4, Type: NameProperty)

    void SET_bShowCustomMatchmakingModalButton(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x1, Type: BoolProperty)
    void SET_bShowSpectateMatchModalButton(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4c9, Value); } // 0x4c9 (Size: 0x1, Type: BoolProperty)
    void SET_bShowMobileGameDetailsButton(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4ca, Value); } // 0x4ca (Size: 0x1, Type: BoolProperty)
    void SET_bShowMobileAcceptButton(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4cb, Value); } // 0x4cb (Size: 0x1, Type: BoolProperty)
    void SET_bShowBackToTopButton(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4cc, Value); } // 0x4cc (Size: 0x1, Type: BoolProperty)
    void SET_DiscoverySurfaceName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x4, Type: NameProperty)
};

// Size: 0x15d0
class UFortActivityBrowserTile : public UFortActivityBrowserTileBase
{
public:
    UFortActivityTileDetailsDisplay* Display_TileDetails() const { return Read<UFortActivityTileDetailsDisplay*>(uintptr_t(this) + 0x1578); } // 0x1578 (Size: 0x8, Type: ObjectProperty)

    void SET_Display_TileDetails(const UFortActivityTileDetailsDisplay*& Value) { Write<UFortActivityTileDetailsDisplay*>(uintptr_t(this) + 0x1578, Value); } // 0x1578 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x710
class UFortActivityCategoryPageView : public UFortActivityPlayerBrowserView
{
public:
    UCommonRichTextBlock* Text_CategoryTitle() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x6d8); } // 0x6d8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_BackToTop() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x6e0); } // 0x6e0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CloseTouch() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x6e8); } // 0x6e8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Back() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x6f0); } // 0x6f0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_MobileAccept() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x6f8); } // 0x6f8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_MobileShowGameDetails() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x700); } // 0x700 (Size: 0x8, Type: ObjectProperty)

    void SET_Text_CategoryTitle(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x6d8, Value); } // 0x6d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_BackToTop(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x6e0, Value); } // 0x6e0 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_CloseTouch(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x6e8, Value); } // 0x6e8 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Back(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x6f0, Value); } // 0x6f0 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_MobileAccept(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x6f8, Value); } // 0x6f8 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_MobileShowGameDetails(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x700, Value); } // 0x700 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x6d0
class UFortActivityPlayerBrowserView : public UFortActivityBrowserView
{
public:
    UFortGameActivityProvider* ActivityProvider() const { return Read<UFortGameActivityProvider*>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    UFortActivityTileView* TileView_PlayerActivities() const { return Read<UFortActivityTileView*>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    FName TabNameID() const { return Read<FName>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x4, Type: NameProperty)
    FFortTabButtonLabelInfo TabButtonLabelInfo() const { return Read<FFortTabButtonLabelInfo>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0xf0, Type: StructProperty)
    uint8_t PlayHistoryProviderType() const { return Read<uint8_t>(uintptr_t(this) + 0x6b0); } // 0x6b0 (Size: 0x1, Type: EnumProperty)

    void SET_ActivityProvider(const UFortGameActivityProvider*& Value) { Write<UFortGameActivityProvider*>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    void SET_TileView_PlayerActivities(const UFortActivityTileView*& Value) { Write<UFortActivityTileView*>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    void SET_TabNameID(const FName& Value) { Write<FName>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x4, Type: NameProperty)
    void SET_TabButtonLabelInfo(const FFortTabButtonLabelInfo& Value) { Write<FFortTabButtonLabelInfo>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0xf0, Type: StructProperty)
    void SET_PlayHistoryProviderType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x6b0, Value); } // 0x6b0 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x15b0
class UFortActivityCategoryTile : public UFortActivityTileViewTileBase
{
public:
    UCommonTextBlock* Text_CategoryTitle() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x15a0); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)

    void SET_Text_CategoryTitle(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x15a0, Value); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x15a0
class UFortActivityTileViewTileBase : public UCommonButtonBase
{
public:
};

// Size: 0x3b8
class UFortActivityCategoryTilePanel : public UCommonUserWidget
{
public:
    UFortActivityTileView* TileView_Categories() const { return Read<UFortActivityTileView*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Title() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    int32_t TileViewQueryThreshold() const { return Read<int32_t>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x4, Type: IntProperty)
    UFortCreativeDiscoveryActivityProvider* CachedActivityProvider() const { return Read<UFortCreativeDiscoveryActivityProvider*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)

    void SET_TileView_Categories(const UFortActivityTileView*& Value) { Write<UFortActivityTileView*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_Title(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_TileViewQueryThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x4, Type: IntProperty)
    void SET_CachedActivityProvider(const UFortCreativeDiscoveryActivityProvider*& Value) { Write<UFortCreativeDiscoveryActivityProvider*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x6c0
class UFortActivityCategoryView : public UFortActivityBrowserView
{
public:
    FName TabNameID() const { return Read<FName>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x4, Type: NameProperty)
    FFortTabButtonLabelInfo TabButtonLabelInfo() const { return Read<FFortTabButtonLabelInfo>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0xf0, Type: StructProperty)
    UFortActivityCategoryTilePanel* TilePanel_Featured() const { return Read<UFortActivityCategoryTilePanel*>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    UFortActivityCategoryTilePanel* TilePanel_All() const { return Read<UFortActivityCategoryTilePanel*>(uintptr_t(this) + 0x6a8); } // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    UFortActivityCategoryTilePanel* CurrentSelectedPanel() const { return Read<UFortActivityCategoryTilePanel*>(uintptr_t(this) + 0x6b0); } // 0x6b0 (Size: 0x8, Type: ObjectProperty)

    void SET_TabNameID(const FName& Value) { Write<FName>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x4, Type: NameProperty)
    void SET_TabButtonLabelInfo(const FFortTabButtonLabelInfo& Value) { Write<FFortTabButtonLabelInfo>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0xf0, Type: StructProperty)
    void SET_TilePanel_Featured(const UFortActivityCategoryTilePanel*& Value) { Write<UFortActivityCategoryTilePanel*>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    void SET_TilePanel_All(const UFortActivityCategoryTilePanel*& Value) { Write<UFortActivityCategoryTilePanel*>(uintptr_t(this) + 0x6a8, Value); } // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentSelectedPanel(const UFortActivityCategoryTilePanel*& Value) { Write<UFortActivityCategoryTilePanel*>(uintptr_t(this) + 0x6b0, Value); } // 0x6b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x860
class UFortActivityCreatorPageView : public UFortActivityCategoryPageView
{
public:
    int32_t AmountOfCreatorLinkEntriesQueried() const { return Read<int32_t>(uintptr_t(this) + 0x808); } // 0x808 (Size: 0x4, Type: IntProperty)
    int32_t ProcessedCreatorLinkEntries() const { return Read<int32_t>(uintptr_t(this) + 0x80c); } // 0x80c (Size: 0x4, Type: IntProperty)
    int32_t AmountOfEntriesQueried() const { return Read<int32_t>(uintptr_t(this) + 0x810); } // 0x810 (Size: 0x4, Type: IntProperty)

    void SET_AmountOfCreatorLinkEntriesQueried(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x808, Value); } // 0x808 (Size: 0x4, Type: IntProperty)
    void SET_ProcessedCreatorLinkEntries(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x80c, Value); } // 0x80c (Size: 0x4, Type: IntProperty)
    void SET_AmountOfEntriesQueried(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x810, Value); } // 0x810 (Size: 0x4, Type: IntProperty)
};

// Size: 0x7e0
class UFortActivityDiscoverView : public UFortActivityBrowserRowView
{
public:
    bool bPlayDetailsAnimationOnScreenOpen() const { return Read<bool>(uintptr_t(this) + 0x740); } // 0x740 (Size: 0x1, Type: BoolProperty)
    float DetailsDisplayUpdateDelay() const { return Read<float>(uintptr_t(this) + 0x744); } // 0x744 (Size: 0x4, Type: FloatProperty)
    UClass* MovieWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x748); } // 0x748 (Size: 0x8, Type: ClassProperty)
    UFortActivityDetailsDisplay* DetailsDisplay_SelectedActivity() const { return Read<UFortActivityDetailsDisplay*>(uintptr_t(this) + 0x750); } // 0x750 (Size: 0x8, Type: ObjectProperty)
    UFortActivityDetailsDisplay* DetailsDisplay_PromotedActivity() const { return Read<UFortActivityDetailsDisplay*>(uintptr_t(this) + 0x758); } // 0x758 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* Panel_VideoSlot() const { return Read<UPanelWidget*>(uintptr_t(this) + 0x760); } // 0x760 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* Panel_PromotedVideoSlot() const { return Read<UPanelWidget*>(uintptr_t(this) + 0x768); } // 0x768 (Size: 0x8, Type: ObjectProperty)
    UFortActivatableMovieWidget* ActivityMovieWidget() const { return Read<UFortActivatableMovieWidget*>(uintptr_t(this) + 0x770); } // 0x770 (Size: 0x8, Type: ObjectProperty)
    UFortActivatableMovieWidget* PromotedActivityMovieWidget() const { return Read<UFortActivatableMovieWidget*>(uintptr_t(this) + 0x778); } // 0x778 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* BoundKeyArtOutroAnimation() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x7c8); } // 0x7c8 (Size: 0x8, Type: ObjectProperty)

    void SET_bPlayDetailsAnimationOnScreenOpen(const bool& Value) { Write<bool>(uintptr_t(this) + 0x740, Value); } // 0x740 (Size: 0x1, Type: BoolProperty)
    void SET_DetailsDisplayUpdateDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x744, Value); } // 0x744 (Size: 0x4, Type: FloatProperty)
    void SET_MovieWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x748, Value); } // 0x748 (Size: 0x8, Type: ClassProperty)
    void SET_DetailsDisplay_SelectedActivity(const UFortActivityDetailsDisplay*& Value) { Write<UFortActivityDetailsDisplay*>(uintptr_t(this) + 0x750, Value); } // 0x750 (Size: 0x8, Type: ObjectProperty)
    void SET_DetailsDisplay_PromotedActivity(const UFortActivityDetailsDisplay*& Value) { Write<UFortActivityDetailsDisplay*>(uintptr_t(this) + 0x758, Value); } // 0x758 (Size: 0x8, Type: ObjectProperty)
    void SET_Panel_VideoSlot(const UPanelWidget*& Value) { Write<UPanelWidget*>(uintptr_t(this) + 0x760, Value); } // 0x760 (Size: 0x8, Type: ObjectProperty)
    void SET_Panel_PromotedVideoSlot(const UPanelWidget*& Value) { Write<UPanelWidget*>(uintptr_t(this) + 0x768, Value); } // 0x768 (Size: 0x8, Type: ObjectProperty)
    void SET_ActivityMovieWidget(const UFortActivatableMovieWidget*& Value) { Write<UFortActivatableMovieWidget*>(uintptr_t(this) + 0x770, Value); } // 0x770 (Size: 0x8, Type: ObjectProperty)
    void SET_PromotedActivityMovieWidget(const UFortActivatableMovieWidget*& Value) { Write<UFortActivatableMovieWidget*>(uintptr_t(this) + 0x778, Value); } // 0x778 (Size: 0x8, Type: ObjectProperty)
    void SET_BoundKeyArtOutroAnimation(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x7c8, Value); } // 0x7c8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x8a0
class UFortActivityDiscoverViewV2 : public UFortActivityBrowserRowView
{
public:
    UFortDiscoverPreviewManager* DiscoverPreviewManager() const { return Read<UFortDiscoverPreviewManager*>(uintptr_t(this) + 0x750); } // 0x750 (Size: 0x8, Type: ObjectProperty)
    UDiscoverSelectedActivityViewModel* SelectedActivityVM() const { return Read<UDiscoverSelectedActivityViewModel*>(uintptr_t(this) + 0x780); } // 0x780 (Size: 0x8, Type: ObjectProperty)
    FDataTableRowHandle BackToTopInputAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x7d0); } // 0x7d0 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle CustomKeyInputAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x7e8); } // 0x7e8 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle ShowSpectateMatchModalInputAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x800); } // 0x800 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle JoinAsSpectatorInputAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x818); } // 0x818 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle JoinAsPlayerInputAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x830); } // 0x830 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle SelectActivityInputAction_Touch() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x848); } // 0x848 (Size: 0x10, Type: StructProperty)
    UFortNestedButtonGroupSelectionVM* NestedButtonGroupSelectionVM() const { return Read<UFortNestedButtonGroupSelectionVM*>(uintptr_t(this) + 0x898); } // 0x898 (Size: 0x8, Type: ObjectProperty)

    void SET_DiscoverPreviewManager(const UFortDiscoverPreviewManager*& Value) { Write<UFortDiscoverPreviewManager*>(uintptr_t(this) + 0x750, Value); } // 0x750 (Size: 0x8, Type: ObjectProperty)
    void SET_SelectedActivityVM(const UDiscoverSelectedActivityViewModel*& Value) { Write<UDiscoverSelectedActivityViewModel*>(uintptr_t(this) + 0x780, Value); } // 0x780 (Size: 0x8, Type: ObjectProperty)
    void SET_BackToTopInputAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x7d0, Value); } // 0x7d0 (Size: 0x10, Type: StructProperty)
    void SET_CustomKeyInputAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x7e8, Value); } // 0x7e8 (Size: 0x10, Type: StructProperty)
    void SET_ShowSpectateMatchModalInputAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x800, Value); } // 0x800 (Size: 0x10, Type: StructProperty)
    void SET_JoinAsSpectatorInputAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x818, Value); } // 0x818 (Size: 0x10, Type: StructProperty)
    void SET_JoinAsPlayerInputAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x830, Value); } // 0x830 (Size: 0x10, Type: StructProperty)
    void SET_SelectActivityInputAction_Touch(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x848, Value); } // 0x848 (Size: 0x10, Type: StructProperty)
    void SET_NestedButtonGroupSelectionVM(const UFortNestedButtonGroupSelectionVM*& Value) { Write<UFortNestedButtonGroupSelectionVM*>(uintptr_t(this) + 0x898, Value); } // 0x898 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x438
class UFortActivityListView : public UListViewBase
{
public:
    float DirectionalNavigationTimeThreshold() const { return Read<float>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EOrientation> orientation() const { return Read<TEnumAsByte<EOrientation>>(uintptr_t(this) + 0x37c); } // 0x37c (Size: 0x1, Type: ByteProperty)
    float EntrySpacing() const { return Read<float>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x4, Type: FloatProperty)
    bool bCircularNavigationEnabled() const { return Read<bool>(uintptr_t(this) + 0x384); } // 0x384 (Size: 0x1, Type: BoolProperty)
    TMap<UClass*, EActivityBrowserTileStyle> TileTypes() const { return Read<TMap<UClass*, EActivityBrowserTileStyle>>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x50, Type: MapProperty)

    void SET_DirectionalNavigationTimeThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x4, Type: FloatProperty)
    void SET_orientation(const TEnumAsByte<EOrientation>& Value) { Write<TEnumAsByte<EOrientation>>(uintptr_t(this) + 0x37c, Value); } // 0x37c (Size: 0x1, Type: ByteProperty)
    void SET_EntrySpacing(const float& Value) { Write<float>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x4, Type: FloatProperty)
    void SET_bCircularNavigationEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x384, Value); } // 0x384 (Size: 0x1, Type: BoolProperty)
    void SET_TileTypes(const TMap<UClass*, EActivityBrowserTileStyle>& Value) { Write<TMap<UClass*, EActivityBrowserTileStyle>>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x50, Type: MapProperty)
};

// Size: 0x1610
class UFortActivityLobbyTile : public UCommonButtonLegacy
{
public:
    UCommonTextBlock* Text_ActivityName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1560); } // 0x1560 (Size: 0x8, Type: ObjectProperty)
    UFortActivityBrowserTag* ActivityBrowserTag_EpicOriginal() const { return Read<UFortActivityBrowserTag*>(uintptr_t(this) + 0x1568); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
    UFortGameActivityProvider* ActivityProvider() const { return Read<UFortGameActivityProvider*>(uintptr_t(this) + 0x1570); } // 0x1570 (Size: 0x8, Type: ObjectProperty)

    void SET_Text_ActivityName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1560, Value); } // 0x1560 (Size: 0x8, Type: ObjectProperty)
    void SET_ActivityBrowserTag_EpicOriginal(const UFortActivityBrowserTag*& Value) { Write<UFortActivityBrowserTag*>(uintptr_t(this) + 0x1568, Value); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
    void SET_ActivityProvider(const UFortGameActivityProvider*& Value) { Write<UFortGameActivityProvider*>(uintptr_t(this) + 0x1570, Value); } // 0x1570 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4f8
class UFortActivityModeSetSelectionModal : public UFortActivityModeSetSelectionModalBase
{
public:
    UCommonTextBlock* Text_ActivityName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Back() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_BackBoard() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    UFortActivityModeSetSelection* List_SubModeList() const { return Read<UFortActivityModeSetSelection*>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    UFortActivitySquadFillButton* Button_ActivitySquadFill() const { return Read<UFortActivitySquadFillButton*>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x8, Type: ObjectProperty)
    UFortActivityPrivacyButton* Button_ActivityPrivacy() const { return Read<UFortActivityPrivacyButton*>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x8, Type: ObjectProperty)
    UFortActivityHabaneroButton* Button_Activity_Habanero() const { return Read<UFortActivityHabaneroButton*>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)

    void SET_Text_ActivityName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Back(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_BackBoard(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    void SET_List_SubModeList(const UFortActivityModeSetSelection*& Value) { Write<UFortActivityModeSetSelection*>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_ActivitySquadFill(const UFortActivitySquadFillButton*& Value) { Write<UFortActivitySquadFillButton*>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_ActivityPrivacy(const UFortActivityPrivacyButton*& Value) { Write<UFortActivityPrivacyButton*>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Activity_Habanero(const UFortActivityHabaneroButton*& Value) { Write<UFortActivityHabaneroButton*>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1600
class UFortActivityPlayerBrowserTile : public UFortActivityTileViewTileBase
{
public:
    UFortActivityTileDetailsDisplay* Display_TileDetails() const { return Read<UFortActivityTileDetailsDisplay*>(uintptr_t(this) + 0x15a0); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_LastPlayedDate() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x15a8); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)

    void SET_Display_TileDetails(const UFortActivityTileDetailsDisplay*& Value) { Write<UFortActivityTileDetailsDisplay*>(uintptr_t(this) + 0x15a0, Value); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_LastPlayedDate(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x15a8, Value); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x340
class UFortActivitySelector : public UFortLocalPlayerSubsystem
{
public:
    TMap<UFortActivityBrowserColorSchemeAsset*, FName> ColorSchemes() const { return Read<TMap<UFortActivityBrowserColorSchemeAsset*, FName>>(uintptr_t(this) + 0x288); } // 0x288 (Size: 0x50, Type: MapProperty)

    void SET_ColorSchemes(const TMap<UFortActivityBrowserColorSchemeAsset*, FName>& Value) { Write<TMap<UFortActivityBrowserColorSchemeAsset*, FName>>(uintptr_t(this) + 0x288, Value); } // 0x288 (Size: 0x50, Type: MapProperty)
};

// Size: 0x17d0
class UFortActivityTileDetailsDisplay : public UUIKitHoldableModularButton
{
public:
    bool bShowDetailsButton() const { return Read<bool>(uintptr_t(this) + 0x1640); } // 0x1640 (Size: 0x1, Type: BoolProperty)
    int32_t DefaultColumnSize() const { return Read<int32_t>(uintptr_t(this) + 0x1644); } // 0x1644 (Size: 0x4, Type: IntProperty)
    UCommonTextBlock* Text_ActivityName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1648); } // 0x1648 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_PlayerCount() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1650); } // 0x1650 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Favorite() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x1658); } // 0x1658 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Details() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x1660); } // 0x1660 (Size: 0x8, Type: ObjectProperty)
    UFortActivityBrowserTag* ActivityBrowserTag_EpicOriginal() const { return Read<UFortActivityBrowserTag*>(uintptr_t(this) + 0x1668); } // 0x1668 (Size: 0x8, Type: ObjectProperty)
    UTextBlock* Text_DebugId() const { return Read<UTextBlock*>(uintptr_t(this) + 0x1670); } // 0x1670 (Size: 0x8, Type: ObjectProperty)
    UFortActivityVideoCycle* ActivityVideoCycleWidget() const { return Read<UFortActivityVideoCycle*>(uintptr_t(this) + 0x1678); } // 0x1678 (Size: 0x8, Type: ObjectProperty)
    TMap<ECreativeLinkPreviewSize, uint32_t> MinColumnSizeToImageSize() const { return Read<TMap<ECreativeLinkPreviewSize, uint32_t>>(uintptr_t(this) + 0x1680); } // 0x1680 (Size: 0x50, Type: MapProperty)
    UClass* ActivityDetailsModalClass() const { return Read<UClass*>(uintptr_t(this) + 0x16d0); } // 0x16d0 (Size: 0x8, Type: ClassProperty)
    UClass* PlayerPageViewClass() const { return Read<UClass*>(uintptr_t(this) + 0x16d8); } // 0x16d8 (Size: 0x8, Type: ClassProperty)
    UClass* ActivityCampaignPurchaseScreenClass() const { return Read<UClass*>(uintptr_t(this) + 0x16e0); } // 0x16e0 (Size: 0x8, Type: ClassProperty)
    UClass* ActivityAttributionsClass() const { return Read<UClass*>(uintptr_t(this) + 0x16e8); } // 0x16e8 (Size: 0x8, Type: ClassProperty)

    void SET_bShowDetailsButton(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1640, Value); } // 0x1640 (Size: 0x1, Type: BoolProperty)
    void SET_DefaultColumnSize(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1644, Value); } // 0x1644 (Size: 0x4, Type: IntProperty)
    void SET_Text_ActivityName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1648, Value); } // 0x1648 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_PlayerCount(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1650, Value); } // 0x1650 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Favorite(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x1658, Value); } // 0x1658 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Details(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x1660, Value); } // 0x1660 (Size: 0x8, Type: ObjectProperty)
    void SET_ActivityBrowserTag_EpicOriginal(const UFortActivityBrowserTag*& Value) { Write<UFortActivityBrowserTag*>(uintptr_t(this) + 0x1668, Value); } // 0x1668 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_DebugId(const UTextBlock*& Value) { Write<UTextBlock*>(uintptr_t(this) + 0x1670, Value); } // 0x1670 (Size: 0x8, Type: ObjectProperty)
    void SET_ActivityVideoCycleWidget(const UFortActivityVideoCycle*& Value) { Write<UFortActivityVideoCycle*>(uintptr_t(this) + 0x1678, Value); } // 0x1678 (Size: 0x8, Type: ObjectProperty)
    void SET_MinColumnSizeToImageSize(const TMap<ECreativeLinkPreviewSize, uint32_t>& Value) { Write<TMap<ECreativeLinkPreviewSize, uint32_t>>(uintptr_t(this) + 0x1680, Value); } // 0x1680 (Size: 0x50, Type: MapProperty)
    void SET_ActivityDetailsModalClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x16d0, Value); } // 0x16d0 (Size: 0x8, Type: ClassProperty)
    void SET_PlayerPageViewClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x16d8, Value); } // 0x16d8 (Size: 0x8, Type: ClassProperty)
    void SET_ActivityCampaignPurchaseScreenClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x16e0, Value); } // 0x16e0 (Size: 0x8, Type: ClassProperty)
    void SET_ActivityAttributionsClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x16e8, Value); } // 0x16e8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0xb90
class UFortActivityTileView : public UFortTileView
{
public:
};

// Size: 0x4b0
class UFortDiscoverItemBrowserRow : public UFortActivityBrowserRow
{
public:
    UFortDiscoverItemListView* ListView_Tiles() const { return Read<UFortDiscoverItemListView*>(uintptr_t(this) + 0x448); } // 0x448 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_PageLeft() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_PageRight() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x8, Type: ObjectProperty)

    void SET_ListView_Tiles(const UFortDiscoverItemListView*& Value) { Write<UFortDiscoverItemListView*>(uintptr_t(this) + 0x448, Value); } // 0x448 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_PageLeft(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_PageRight(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x3e8
class UFortDiscoverItemListView : public UListViewBase
{
public:
    float DirectionalNavigationTimeThreshold() const { return Read<float>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x4, Type: FloatProperty)
    UClass* PlayWithFriendsEntryWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ClassProperty)
    UClass* ActivityEntryWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ClassProperty)
    UClass* LibraryEntryWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EOrientation> orientation() const { return Read<TEnumAsByte<EOrientation>>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x1, Type: ByteProperty)
    float EntrySpacing() const { return Read<float>(uintptr_t(this) + 0x39c); } // 0x39c (Size: 0x4, Type: FloatProperty)
    bool bCircularNavigationEnabled() const { return Read<bool>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x1, Type: BoolProperty)

    void SET_DirectionalNavigationTimeThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x4, Type: FloatProperty)
    void SET_PlayWithFriendsEntryWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ClassProperty)
    void SET_ActivityEntryWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ClassProperty)
    void SET_LibraryEntryWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: ClassProperty)
    void SET_orientation(const TEnumAsByte<EOrientation>& Value) { Write<TEnumAsByte<EOrientation>>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x1, Type: ByteProperty)
    void SET_EntrySpacing(const float& Value) { Write<float>(uintptr_t(this) + 0x39c, Value); } // 0x39c (Size: 0x4, Type: FloatProperty)
    void SET_bCircularNavigationEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xe8
class UActivityLibraryComponent : public UActorComponent
{
public:
};

// Size: 0x48
class UFortActivityBrowserContext : public UGameInstanceSubsystem
{
public:
};

// Size: 0x100
class UOverrideMatchmakingUIComponent : public UActorComponent
{
public:
    FMatchmakingUIOverride MatchmakingUIOverride() const { return Read<FMatchmakingUIOverride>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x40, Type: StructProperty)

    void SET_MatchmakingUIOverride(const FMatchmakingUIOverride& Value) { Write<FMatchmakingUIOverride>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x40, Type: StructProperty)
};

// Size: 0xa8
struct FColorSchemeParamaterValues
{
public:
    UMaterialParameterCollection* AlternateMaterialCollection() const { return Read<UMaterialParameterCollection*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    TMap<float, FName> ScalarParameterValues() const { return Read<TMap<float, FName>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x50, Type: MapProperty)
    TMap<FLinearColor, FName> VectorParameterValues() const { return Read<TMap<FLinearColor, FName>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x50, Type: MapProperty)

    void SET_AlternateMaterialCollection(const UMaterialParameterCollection*& Value) { Write<UMaterialParameterCollection*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ScalarParameterValues(const TMap<float, FName>& Value) { Write<TMap<float, FName>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x50, Type: MapProperty)
    void SET_VectorParameterValues(const TMap<FLinearColor, FName>& Value) { Write<TMap<FLinearColor, FName>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x50, Type: MapProperty)
};

