/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FieldNotification
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x28
class UNotifyFieldValueChanged : public UInterface
{
public:
};

// Size: 0x4
struct FFieldNotificationId
{
public:
    FName FieldName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)

    void SET_FieldName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
};

