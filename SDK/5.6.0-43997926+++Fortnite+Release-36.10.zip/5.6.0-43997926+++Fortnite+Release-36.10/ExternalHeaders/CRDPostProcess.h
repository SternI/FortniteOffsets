/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRDPostProcess
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "FortniteGame.h"

// Size: 0x110
class UCRDPostProcessDeviceComponent : public UActorComponent
{
public:
    UPostProcessComponent* PostProcessComponent() const { return Read<UPostProcessComponent*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    APlayerController* BlendInstigator() const { return Read<APlayerController*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)

    void SET_PostProcessComponent(const UPostProcessComponent*& Value) { Write<UPostProcessComponent*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_BlendInstigator(const APlayerController*& Value) { Write<APlayerController*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc8
class UCRDPostProcessDevicePriorityControllerComponent : public UActorComponent
{
public:
    TArray<UCRDPostProcessDeviceComponent*> CachedAppliedEffects() const { return Read<TArray<UCRDPostProcessDeviceComponent*>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)

    void SET_CachedAppliedEffects(const TArray<UCRDPostProcessDeviceComponent*>& Value) { Write<TArray<UCRDPostProcessDeviceComponent*>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x248
class UCRDPostProcessDeviceControllerComponent : public UActorComponent
{
public:
    FPostProcessDeviceMessageRingBuffer PostProcessDeviceMessageBatch() const { return Read<FPostProcessDeviceMessageRingBuffer>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x130, Type: StructProperty)
    TArray<FPostProcessDeviceMessage> PostProcessDeviceMessageQueue() const { return Read<TArray<FPostProcessDeviceMessage>>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x10, Type: ArrayProperty)

    void SET_PostProcessDeviceMessageBatch(const FPostProcessDeviceMessageRingBuffer& Value) { Write<FPostProcessDeviceMessageRingBuffer>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x130, Type: StructProperty)
    void SET_PostProcessDeviceMessageQueue(const TArray<FPostProcessDeviceMessage>& Value) { Write<TArray<FPostProcessDeviceMessage>>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FPostProcessDeviceMessage
{
public:
    AFortCreativeDeviceProp* PostProcessDevice() const { return Read<AFortCreativeDeviceProp*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerState* PlayerStateMessage() const { return Read<AFortPlayerState*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    uint8_t EndState() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)

    void SET_PostProcessDevice(const AFortCreativeDeviceProp*& Value) { Write<AFortCreativeDeviceProp*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerStateMessage(const AFortPlayerState*& Value) { Write<AFortPlayerState*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_EndState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x28
struct FPostProcessDeviceMessageRepl : public FFastArraySerializerItem
{
public:
    int32_t MessageIndex() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    AFortCreativeDeviceProp* PostProcessDevice() const { return Read<AFortCreativeDeviceProp*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerState* PlayerStateMessage() const { return Read<AFortPlayerState*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    uint8_t EndState() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)

    void SET_MessageIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_PostProcessDevice(const AFortCreativeDeviceProp*& Value) { Write<AFortCreativeDeviceProp*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerStateMessage(const AFortPlayerState*& Value) { Write<AFortPlayerState*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET_EndState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x130
struct FPostProcessDeviceMessageRingBuffer : public FFastArraySerializer
{
public:
    TArray<FPostProcessDeviceMessageRepl> Items() const { return Read<TArray<FPostProcessDeviceMessageRepl>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)

    void SET_Items(const TArray<FPostProcessDeviceMessageRepl>& Value) { Write<TArray<FPostProcessDeviceMessageRepl>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
};

