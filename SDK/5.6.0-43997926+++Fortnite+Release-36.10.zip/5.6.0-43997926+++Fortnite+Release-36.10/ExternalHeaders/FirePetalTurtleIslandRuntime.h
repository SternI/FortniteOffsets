/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FirePetalTurtleIslandRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayAbilities.h"
#include "CoreUObject.h"

// Size: 0x2e0
class AFirePetalTurtleHeadActor : public AActor
{
public:
    FScalableFloat DistanceToAlwaysTickPose() const { return Read<FScalableFloat>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x28, Type: StructProperty)

    void SET_DistanceToAlwaysTickPose(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x28
class UTurtleHeadActorInterface : public UInterface
{
public:
};

// Size: 0x490
class UTurtleIslandHeadCreatureAnimInstance : public UAnimInstance
{
public:
    bool bShould_Blink() const { return Read<bool>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x1, Type: BoolProperty)
    bool bIsChewing() const { return Read<bool>(uintptr_t(this) + 0x3d9); } // 0x3d9 (Size: 0x1, Type: BoolProperty)
    bool bIsChewingAlt() const { return Read<bool>(uintptr_t(this) + 0x3da); } // 0x3da (Size: 0x1, Type: BoolProperty)
    double ChewingAlphaInterp() const { return Read<double>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: DoubleProperty)
    double RandomChewingAlpha() const { return Read<double>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x8, Type: DoubleProperty)
    int32_t BlinkPicker() const { return Read<int32_t>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x4, Type: IntProperty)
    bool bIsForceBlink() const { return Read<bool>(uintptr_t(this) + 0x3f4); } // 0x3f4 (Size: 0x1, Type: BoolProperty)
    bool bIsStillChewingCheck() const { return Read<bool>(uintptr_t(this) + 0x3f5); } // 0x3f5 (Size: 0x1, Type: BoolProperty)
    double LookVertical() const { return Read<double>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x8, Type: DoubleProperty)
    double LookHorizontal() const { return Read<double>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x8, Type: DoubleProperty)
    float LookHorizontalHead() const { return Read<float>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x4, Type: FloatProperty)
    float LookVerticalHead() const { return Read<float>(uintptr_t(this) + 0x40c); } // 0x40c (Size: 0x4, Type: FloatProperty)
    FVector PawnLookAtWorldPosition() const { return Read<FVector>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x18, Type: StructProperty)
    bool bIsValidLookAtTarget() const { return Read<bool>(uintptr_t(this) + 0x428); } // 0x428 (Size: 0x1, Type: BoolProperty)
    bool bIsLookAway() const { return Read<bool>(uintptr_t(this) + 0x429); } // 0x429 (Size: 0x1, Type: BoolProperty)
    bool bEyeGateOpen() const { return Read<bool>(uintptr_t(this) + 0x42a); } // 0x42a (Size: 0x1, Type: BoolProperty)

    void SET_bShould_Blink(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x1, Type: BoolProperty)
    void SET_bIsChewing(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3d9, Value); } // 0x3d9 (Size: 0x1, Type: BoolProperty)
    void SET_bIsChewingAlt(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3da, Value); } // 0x3da (Size: 0x1, Type: BoolProperty)
    void SET_ChewingAlphaInterp(const double& Value) { Write<double>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: DoubleProperty)
    void SET_RandomChewingAlpha(const double& Value) { Write<double>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x8, Type: DoubleProperty)
    void SET_BlinkPicker(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x4, Type: IntProperty)
    void SET_bIsForceBlink(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3f4, Value); } // 0x3f4 (Size: 0x1, Type: BoolProperty)
    void SET_bIsStillChewingCheck(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3f5, Value); } // 0x3f5 (Size: 0x1, Type: BoolProperty)
    void SET_LookVertical(const double& Value) { Write<double>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x8, Type: DoubleProperty)
    void SET_LookHorizontal(const double& Value) { Write<double>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x8, Type: DoubleProperty)
    void SET_LookHorizontalHead(const float& Value) { Write<float>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x4, Type: FloatProperty)
    void SET_LookVerticalHead(const float& Value) { Write<float>(uintptr_t(this) + 0x40c, Value); } // 0x40c (Size: 0x4, Type: FloatProperty)
    void SET_PawnLookAtWorldPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x18, Type: StructProperty)
    void SET_bIsValidLookAtTarget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x428, Value); } // 0x428 (Size: 0x1, Type: BoolProperty)
    void SET_bIsLookAway(const bool& Value) { Write<bool>(uintptr_t(this) + 0x429, Value); } // 0x429 (Size: 0x1, Type: BoolProperty)
    void SET_bEyeGateOpen(const bool& Value) { Write<bool>(uintptr_t(this) + 0x42a, Value); } // 0x42a (Size: 0x1, Type: BoolProperty)
};

