/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricSettingsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x30
class UFortGameSettingRegistryExtension_Fabric : public UFortGameSettingRegistryExtension
{
public:
};

// Size: 0x40
class UFortSettingEditCondition_FabricEnabledForLinkEntry : public UFortSettingEditCondition
{
public:
};

