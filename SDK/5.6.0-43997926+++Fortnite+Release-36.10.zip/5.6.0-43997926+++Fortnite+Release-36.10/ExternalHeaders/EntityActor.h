/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EntityActor
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "EntityCore.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x28
class UEntityAbilityInterface : public UInterface
{
public:
};

// Size: 0x60
class UEntityActorCustomReplicationComponent : public UEntityComponent
{
public:
    TEnumAsByte<EEntityActorReplicationOverrideType> ReplicationOverride() const { return Read<TEnumAsByte<EEntityActorReplicationOverrideType>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EEntityActorReplicationRelevancyBucketType> ReplicationRelevancyBucketType() const { return Read<TEnumAsByte<EEntityActorReplicationRelevancyBucketType>>(uintptr_t(this) + 0x59); } // 0x59 (Size: 0x1, Type: ByteProperty)
    float CustomReplicationRelevancyRange() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)

    void SET_ReplicationOverride(const TEnumAsByte<EEntityActorReplicationOverrideType>& Value) { Write<TEnumAsByte<EEntityActorReplicationOverrideType>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x1, Type: ByteProperty)
    void SET_ReplicationRelevancyBucketType(const TEnumAsByte<EEntityActorReplicationRelevancyBucketType>& Value) { Write<TEnumAsByte<EEntityActorReplicationRelevancyBucketType>>(uintptr_t(this) + 0x59, Value); } // 0x59 (Size: 0x1, Type: ByteProperty)
    void SET_CustomReplicationRelevancyRange(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x2b0
class ASimObject : public AActor
{
public:
};

// Size: 0xd8
class UActorToEntityAdapterComponent : public UActorComponent
{
public:
    TArray<UEntityComponent*> SerializedComponents() const { return Read<TArray<UEntityComponent*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    bool bForceOwnerReplication() const { return (Read<uint8_t>(uintptr_t(this) + 0xd0) >> 0x0) & 1; } // 0xd0:0 (Size: 0x1, Type: BoolProperty)

    void SET_SerializedComponents(const TArray<UEntityComponent*>& Value) { Write<TArray<UEntityComponent*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    void SET_bForceOwnerReplication(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xd0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xd0, B); } // 0xd0:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x88
class UEntityActorComponent : public UEntityComponent
{
public:
    UActorComponent* ActorComponent() const { return Read<UActorComponent*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    bool bCreatedActorComponent() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)

    void SET_ActorComponent(const UActorComponent*& Value) { Write<UActorComponent*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_bCreatedActorComponent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x68
class UEntityActorSubsystem : public UWorldSubsystem
{
public:
};

// Size: 0xb0
class UEntityDynamicActivationComponent : public UEntityEnableableComponent
{
public:
    float TransitionTargetTime() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    bool bTargetState() const { return Read<bool>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x1, Type: BoolProperty)
    TArray<UEntityComponent*> LinkedComponents() const { return Read<TArray<UEntityComponent*>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)

    void SET_TransitionTargetTime(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_bTargetState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x1, Type: BoolProperty)
    void SET_LinkedComponents(const TArray<UEntityComponent*>& Value) { Write<TArray<UEntityComponent*>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x60
class UEntityToActorAdapterComponent : public UEntityComponent
{
public:
};

// Size: 0x60
class UEntityActorLocalInputComponent : public UEntityComponent
{
public:
    TEnumAsByte<EAutoReceiveInput> AutoReceiveControllerInput() const { return Read<TEnumAsByte<EAutoReceiveInput>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x1, Type: ByteProperty)

    void SET_AutoReceiveControllerInput(const TEnumAsByte<EAutoReceiveInput>& Value) { Write<TEnumAsByte<EAutoReceiveInput>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x1, Type: ByteProperty)
};

// Size: 0xf0
class UEntityActorCollisionComponent : public UEntityEnableableComponent
{
public:
    FName ShadowVar_CollisionProfileName() const { return Read<FName>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: NameProperty)
    TSoftObjectPtr<UPrimitiveComponent> PrimitiveComponentCache() const { return Read<TSoftObjectPtr<UPrimitiveComponent>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x20, Type: SoftObjectProperty)
    TEnumAsByte<ECollisionShapeMode> CollisionShapeMode() const { return Read<TEnumAsByte<ECollisionShapeMode>>(uintptr_t(this) + 0xea); } // 0xea (Size: 0x1, Type: ByteProperty)

    void SET_ShadowVar_CollisionProfileName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: NameProperty)
    void SET_PrimitiveComponentCache(const TSoftObjectPtr<UPrimitiveComponent>& Value) { Write<TSoftObjectPtr<UPrimitiveComponent>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_CollisionShapeMode(const TEnumAsByte<ECollisionShapeMode>& Value) { Write<TEnumAsByte<ECollisionShapeMode>>(uintptr_t(this) + 0xea, Value); } // 0xea (Size: 0x1, Type: ByteProperty)
};

// Size: 0xd0
class UEntityActorPlayerComponent : public UEntityDataBackedComponent
{
public:
    FUniqueNetIdRepl PlayerId() const { return Read<FUniqueNetIdRepl>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x30, Type: StructProperty)
    TSoftObjectPtr<APlayerController> PlayerControllerCache() const { return Read<TSoftObjectPtr<APlayerController>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<APlayerState> PlayerStateCache() const { return Read<TSoftObjectPtr<APlayerState>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x20, Type: SoftObjectProperty)

    void SET_PlayerId(const FUniqueNetIdRepl& Value) { Write<FUniqueNetIdRepl>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x30, Type: StructProperty)
    void SET_PlayerControllerCache(const TSoftObjectPtr<APlayerController>& Value) { Write<TSoftObjectPtr<APlayerController>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x20, Type: SoftObjectProperty)
    void SET_PlayerStateCache(const TSoftObjectPtr<APlayerState>& Value) { Write<TSoftObjectPtr<APlayerState>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x78
class UEntityActorSkeletalMeshRenderComponent : public UEntityComponent
{
public:
    bool bAddedMeshRenderComponent() const { return Read<bool>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x1, Type: BoolProperty)
    USkeletalMesh* ShadowVar_SkeletalMesh() const { return Read<USkeletalMesh*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<ECollisionEnabled> ShadowVar_EnableCollision() const { return Read<TEnumAsByte<ECollisionEnabled>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: ByteProperty)

    void SET_bAddedMeshRenderComponent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x1, Type: BoolProperty)
    void SET_ShadowVar_SkeletalMesh(const USkeletalMesh*& Value) { Write<USkeletalMesh*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_ShadowVar_EnableCollision(const TEnumAsByte<ECollisionEnabled>& Value) { Write<TEnumAsByte<ECollisionEnabled>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: ByteProperty)
};

// Size: 0xa0
class UEntityActorStaticMeshRenderComponent : public UEntityActorComponent
{
public:
    TArray<UMaterialInterface*> ShadowVar_MeshMaterials() const { return Read<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    TEnumAsByte<ECollisionEnabled> ShadowVar_EnableCollision() const { return Read<TEnumAsByte<ECollisionEnabled>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: ByteProperty)
    float ShadowVar_MaxDrawDistance() const { return Read<float>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: FloatProperty)

    void SET_ShadowVar_MeshMaterials(const TArray<UMaterialInterface*>& Value) { Write<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    void SET_ShadowVar_EnableCollision(const TEnumAsByte<ECollisionEnabled>& Value) { Write<TEnumAsByte<ECollisionEnabled>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: ByteProperty)
    void SET_ShadowVar_MaxDrawDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: FloatProperty)
};

// Size: 0xa8
class UEntityActorTextDisplayComponent : public UEntityActorComponent
{
public:
    FText DisplayText() const { return Read<FText>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: TextProperty)
    float ShadowVar_WorldSize() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    FColor ShadowVar_TextRenderColor() const { return Read<FColor>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: StructProperty)
    bool bAddedTextRenderComponent() const { return Read<bool>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: BoolProperty)

    void SET_DisplayText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: TextProperty)
    void SET_ShadowVar_WorldSize(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_ShadowVar_TextRenderColor(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: StructProperty)
    void SET_bAddedTextRenderComponent(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
class UEntityActorPositionComponent : public UEntityPositionComponent
{
public:
    FVector ShadowVar_Location() const { return Read<FVector>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x18, Type: StructProperty)

    void SET_ShadowVar_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x18, Type: StructProperty)
};

// Size: 0x88
class UEntityActorRotationComponent : public UEntityRotationComponent
{
public:
    FRotator ShadowVar_Rotation() const { return Read<FRotator>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x18, Type: StructProperty)

    void SET_ShadowVar_Rotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x18, Type: StructProperty)
};

// Size: 0x80
class UEntityActorScaleComponent : public UEntityScaleComponent
{
public:
    FVector ShadowVar_Scale() const { return Read<FVector>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x18, Type: StructProperty)

    void SET_ShadowVar_Scale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x18, Type: StructProperty)
};

