/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CoachMarks
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Blueprints.h"
#include "SlateCore.h"
#include "Engine.h"
#include "UIKit.h"
#include "CoreUObject.h"
#include "CommonUI.h"
#include "UMG.h"

// Size: 0x4f0
class UWBP_Locker_MusicMoments_CoachMark_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_CoachMark_C* WBP_UIKit_CoachMark() const { return Read<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x8, Type: StructProperty)
    void SET_WBP_UIKit_CoachMark(const UWBP_UIKit_CoachMark_C*& Value) { Write<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4f0
class UWBP_Locker_PresetAccess_CoachMark_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_CoachMark_C* WBP_UIKit_CoachMark() const { return Read<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x8, Type: StructProperty)
    void SET_WBP_UIKit_CoachMark(const UWBP_UIKit_CoachMark_C*& Value) { Write<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x500
class UWBP_Locker_PCB_CoachMark_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_CoachMark_C* WBP_UIKit_CoachMark() const { return Read<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x8, Type: StructProperty)
    void SET_WBP_UIKit_CoachMark(const UWBP_UIKit_CoachMark_C*& Value) { Write<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x6b8
class UWBP_ChangeFlag_CoachMark_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: StructProperty)
    USizeBox* WidgetSize() const { return Read<USizeBox*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    UWBP_CaptureForPostBufferUpdate_C* WBP_CaptureForPostBufferUpdate() const { return Read<UWBP_CaptureForPostBufferUpdate_C*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* TopGrid() const { return Read<UGridPanel*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* RichText_Header() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* RichText_Description() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Background() const { return Read<UImage*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Arrow() const { return Read<UImage*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* Description() const { return Read<UVerticalBox*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* Content() const { return Read<UGridPanel*>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* Buttons() const { return Read<UHorizontalBox*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_Outro() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<E_UI_OutBoardPosition> ArrowPosition() const { return Read<TEnumAsByte<E_UI_OutBoardPosition>>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x1, Type: ByteProperty)
    double OutsideOffset() const { return Read<double>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x8, Type: DoubleProperty)
    FSlateBrush Brush_Icon() const { return Read<FSlateBrush>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0xb0, Type: StructProperty)
    float Angle_Icon() const { return Read<float>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<E_UI_DirectionLeftRightNone> IconPosition() const { return Read<TEnumAsByte<E_UI_DirectionLeftRightNone>>(uintptr_t(this) + 0x474); } // 0x474 (Size: 0x1, Type: ByteProperty)
    FText TextHeader() const { return Read<FText>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x10, Type: TextProperty)
    TEnumAsByte<ETextJustify> JustificationHeader() const { return Read<TEnumAsByte<ETextJustify>>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x1, Type: ByteProperty)
    FText TextDescription() const { return Read<FText>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x10, Type: TextProperty)
    FSlateColor DefaultDescriptoinColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x14, Type: StructProperty)
    TEnumAsByte<ETextJustify> JustificationDescription() const { return Read<TEnumAsByte<ETextJustify>>(uintptr_t(this) + 0x4b4); } // 0x4b4 (Size: 0x1, Type: ByteProperty)
    FText TextDismissButton() const { return Read<FText>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x10, Type: TextProperty)
    bool IsShowDismissButton() const { return Read<bool>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x1, Type: BoolProperty)
    FText TextOtherActionButton() const { return Read<FText>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x10, Type: TextProperty)
    bool IsShowOtherActionButton() const { return Read<bool>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x1, Type: BoolProperty)
    FSlateBrush BackgroundBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0xb0, Type: StructProperty)
    float Widget_Width() const { return Read<float>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x4, Type: FloatProperty)
    double SafeZone() const { return Read<double>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x8, Type: DoubleProperty)
    TArray<UClass*> In_Decorator_Classes() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x5f0); } // 0x5f0 (Size: 0x10, Type: ArrayProperty)
    FDataTableRowHandle Input_Action_Other() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle Input_Action_Dismiss() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x610); } // 0x610 (Size: 0x10, Type: StructProperty)
    UMaterialInstanceDynamic* BackgroundDynamicMaterial() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x620); } // 0x620 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Regular_C* DismissButton() const { return Read<UWBP_UIKit_Button_Regular_C*>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Regular_C* OtherActionButton() const { return Read<UWBP_UIKit_Button_Regular_C*>(uintptr_t(this) + 0x670); } // 0x670 (Size: 0x8, Type: ObjectProperty)
    UClass* HoldDataOther() const { return Read<UClass*>(uintptr_t(this) + 0x678); } // 0x678 (Size: 0x8, Type: ClassProperty)
    bool RequiresHoldOther() const { return Read<bool>(uintptr_t(this) + 0x680); } // 0x680 (Size: 0x1, Type: BoolProperty)
    UClass* HoldDataDismiss() const { return Read<UClass*>(uintptr_t(this) + 0x688); } // 0x688 (Size: 0x8, Type: ClassProperty)
    bool RequiresHoldDismiss() const { return Read<bool>(uintptr_t(this) + 0x690); } // 0x690 (Size: 0x1, Type: BoolProperty)
    UImage* Image_Icon() const { return Read<UImage*>(uintptr_t(this) + 0x698); } // 0x698 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<ESlateSizeRule> ButtonFillRule() const { return Read<TEnumAsByte<ESlateSizeRule>>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x1, Type: ByteProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: StructProperty)
    void SET_WidgetSize(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_WBP_CaptureForPostBufferUpdate(const UWBP_CaptureForPostBufferUpdate_C*& Value) { Write<UWBP_CaptureForPostBufferUpdate_C*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_TopGrid(const UGridPanel*& Value) { Write<UGridPanel*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_RichText_Header(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_RichText_Description(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Background(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Arrow(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    void SET_Description(const UVerticalBox*& Value) { Write<UVerticalBox*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    void SET_Content(const UGridPanel*& Value) { Write<UGridPanel*>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    void SET_Buttons(const UHorizontalBox*& Value) { Write<UHorizontalBox*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_Outro(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    void SET_ArrowPosition(const TEnumAsByte<E_UI_OutBoardPosition>& Value) { Write<TEnumAsByte<E_UI_OutBoardPosition>>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x1, Type: ByteProperty)
    void SET_OutsideOffset(const double& Value) { Write<double>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x8, Type: DoubleProperty)
    void SET_Brush_Icon(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0xb0, Type: StructProperty)
    void SET_Angle_Icon(const float& Value) { Write<float>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x4, Type: FloatProperty)
    void SET_IconPosition(const TEnumAsByte<E_UI_DirectionLeftRightNone>& Value) { Write<TEnumAsByte<E_UI_DirectionLeftRightNone>>(uintptr_t(this) + 0x474, Value); } // 0x474 (Size: 0x1, Type: ByteProperty)
    void SET_TextHeader(const FText& Value) { Write<FText>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x10, Type: TextProperty)
    void SET_JustificationHeader(const TEnumAsByte<ETextJustify>& Value) { Write<TEnumAsByte<ETextJustify>>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x1, Type: ByteProperty)
    void SET_TextDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x10, Type: TextProperty)
    void SET_DefaultDescriptoinColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x14, Type: StructProperty)
    void SET_JustificationDescription(const TEnumAsByte<ETextJustify>& Value) { Write<TEnumAsByte<ETextJustify>>(uintptr_t(this) + 0x4b4, Value); } // 0x4b4 (Size: 0x1, Type: ByteProperty)
    void SET_TextDismissButton(const FText& Value) { Write<FText>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x10, Type: TextProperty)
    void SET_IsShowDismissButton(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x1, Type: BoolProperty)
    void SET_TextOtherActionButton(const FText& Value) { Write<FText>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x10, Type: TextProperty)
    void SET_IsShowOtherActionButton(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x1, Type: BoolProperty)
    void SET_BackgroundBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0xb0, Type: StructProperty)
    void SET_Widget_Width(const float& Value) { Write<float>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x4, Type: FloatProperty)
    void SET_SafeZone(const double& Value) { Write<double>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x8, Type: DoubleProperty)
    void SET_In_Decorator_Classes(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x5f0, Value); } // 0x5f0 (Size: 0x10, Type: ArrayProperty)
    void SET_Input_Action_Other(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x10, Type: StructProperty)
    void SET_Input_Action_Dismiss(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x610, Value); } // 0x610 (Size: 0x10, Type: StructProperty)
    void SET_BackgroundDynamicMaterial(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x620, Value); } // 0x620 (Size: 0x8, Type: ObjectProperty)
    void SET_DismissButton(const UWBP_UIKit_Button_Regular_C*& Value) { Write<UWBP_UIKit_Button_Regular_C*>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x8, Type: ObjectProperty)
    void SET_OtherActionButton(const UWBP_UIKit_Button_Regular_C*& Value) { Write<UWBP_UIKit_Button_Regular_C*>(uintptr_t(this) + 0x670, Value); } // 0x670 (Size: 0x8, Type: ObjectProperty)
    void SET_HoldDataOther(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x678, Value); } // 0x678 (Size: 0x8, Type: ClassProperty)
    void SET_RequiresHoldOther(const bool& Value) { Write<bool>(uintptr_t(this) + 0x680, Value); } // 0x680 (Size: 0x1, Type: BoolProperty)
    void SET_HoldDataDismiss(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x688, Value); } // 0x688 (Size: 0x8, Type: ClassProperty)
    void SET_RequiresHoldDismiss(const bool& Value) { Write<bool>(uintptr_t(this) + 0x690, Value); } // 0x690 (Size: 0x1, Type: BoolProperty)
    void SET_Image_Icon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x698, Value); } // 0x698 (Size: 0x8, Type: ObjectProperty)
    void SET_ButtonFillRule(const TEnumAsByte<ESlateSizeRule>& Value) { Write<TEnumAsByte<ESlateSizeRule>>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x4f0
class UWBP_Locker_PresetCap_CoachMark_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_CoachMark_C* WBP_UIKit_CoachMark() const { return Read<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x8, Type: StructProperty)
    void SET_WBP_UIKit_CoachMark(const UWBP_UIKit_CoachMark_C*& Value) { Write<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x510
class UWBP_Locker_SaveLoadout_CoachMark_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_CoachMark_C* WBP_UIKit_CoachMark() const { return Read<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x8, Type: StructProperty)
    void SET_WBP_UIKit_CoachMark(const UWBP_UIKit_CoachMark_C*& Value) { Write<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
};

