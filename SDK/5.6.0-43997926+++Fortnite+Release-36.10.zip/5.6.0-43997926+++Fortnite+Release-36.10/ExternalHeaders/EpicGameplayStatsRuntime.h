/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicGameplayStatsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "GameplayTags.h"
#include "Engine.h"

// Size: 0x28
class UBlueprintGameplayStatsLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x98
class UGameplayTagTableManager : public UDataAsset
{
public:
    TArray<FManagedGameplayTagDataTableItem> Tables() const { return Read<TArray<FManagedGameplayTagDataTableItem>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Tables(const TArray<FManagedGameplayTagDataTableItem>& Value) { Write<TArray<FManagedGameplayTagDataTableItem>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1
struct FTagTableManagerHelper
{
public:
};

// Size: 0x48
struct FGameplayStatMetadataTableRow : public FTableRowBase
{
public:
    FString BackendName() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)
    FText DisplayName() const { return Read<FText>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: TextProperty)
    TArray<EEpicLeaderboardTimeWindow> Windows() const { return Read<TArray<EEpicLeaderboardTimeWindow>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    uint8_t Metric() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t DataType() const { return Read<uint8_t>(uintptr_t(this) + 0x39); } // 0x39 (Size: 0x1, Type: EnumProperty)
    bool bPublish() const { return Read<bool>(uintptr_t(this) + 0x3a); } // 0x3a (Size: 0x1, Type: BoolProperty)
    int32_t WeeklyRefreshInterval() const { return Read<int32_t>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: IntProperty)
    bool bExportToBackEnd() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)
    bool bShowInFrontEnd() const { return Read<bool>(uintptr_t(this) + 0x41); } // 0x41 (Size: 0x1, Type: BoolProperty)

    void SET_BackendName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
    void SET_DisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: TextProperty)
    void SET_Windows(const TArray<EEpicLeaderboardTimeWindow>& Value) { Write<TArray<EEpicLeaderboardTimeWindow>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_Metric(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
    void SET_DataType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x39, Value); } // 0x39 (Size: 0x1, Type: EnumProperty)
    void SET_bPublish(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3a, Value); } // 0x3a (Size: 0x1, Type: BoolProperty)
    void SET_WeeklyRefreshInterval(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: IntProperty)
    void SET_bExportToBackEnd(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
    void SET_bShowInFrontEnd(const bool& Value) { Write<bool>(uintptr_t(this) + 0x41, Value); } // 0x41 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x8
struct FGameplayStatTag : public FGameplayTag
{
public:
    FGameplayTag Tag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)

    void SET_Tag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
};

// Size: 0x10
struct FManagedGameplayTagDataTableItem
{
public:
    FGameplayTag RootTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    UDataTable* DataTable() const { return Read<UDataTable*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_RootTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_DataTable(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

