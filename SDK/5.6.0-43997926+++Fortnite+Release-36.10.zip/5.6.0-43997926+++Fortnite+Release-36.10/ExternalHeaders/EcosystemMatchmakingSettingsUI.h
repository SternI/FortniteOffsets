/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EcosystemMatchmakingSettingsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x68
class UEcosystemMatchmakingSettingsUI : public UMatchmakingSettingsUI
{
public:
};

