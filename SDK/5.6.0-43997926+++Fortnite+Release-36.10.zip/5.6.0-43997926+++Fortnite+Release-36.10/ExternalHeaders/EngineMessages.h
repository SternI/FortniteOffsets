/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EngineMessages
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x1
struct FEngineServicePing
{
public:
};

// Size: 0x50
struct FEngineServicePong
{
public:
    FString CurrentLevel() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    int32_t EngineVersion() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    bool HasBegunPlay() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)
    FGuid InstanceID() const { return Read<FGuid>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    FString InstanceType() const { return Read<FString>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StrProperty)
    FGuid SessionId() const { return Read<FGuid>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    float WorldTimeSeconds() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)

    void SET_CurrentLevel(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_EngineVersion(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_HasBegunPlay(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
    void SET_InstanceID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_InstanceType(const FString& Value) { Write<FString>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StrProperty)
    void SET_SessionId(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_WorldTimeSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FEngineServiceAuthDeny
{
public:
    FString UserName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString UserToDeny() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_UserName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_UserToDeny(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x20
struct FEngineServiceAuthGrant
{
public:
    FString UserName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString UserToGrant() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_UserName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_UserToGrant(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x20
struct FEngineServiceExecuteCommand
{
public:
    FString Command() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString UserName() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_Command(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_UserName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x10
struct FEngineServiceTerminate
{
public:
    FString UserName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)

    void SET_UserName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x18
struct FEngineServiceNotification
{
public:
    FString Text() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    double TimeSeconds() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)

    void SET_Text(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_TimeSeconds(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x1
struct FTraceControlStatusPing
{
public:
};

// Size: 0x68
struct FTraceControlStatus
{
public:
    FString Endpoint() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FGuid SessionGuid() const { return Read<FGuid>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FGuid TraceGuid() const { return Read<FGuid>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    uint64_t BytesSent() const { return Read<uint64_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: UInt64Property)
    uint64_t BytesTraced() const { return Read<uint64_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: UInt64Property)
    uint64_t MemoryUsed() const { return Read<uint64_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: UInt64Property)
    uint32_t CacheAllocated() const { return Read<uint32_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: UInt32Property)
    uint32_t CacheUsed() const { return Read<uint32_t>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: UInt32Property)
    uint32_t CacheWaste() const { return Read<uint32_t>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: UInt32Property)
    bool bAreStatNamedEventsEnabled() const { return Read<bool>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x1, Type: BoolProperty)
    bool bIsPaused() const { return Read<bool>(uintptr_t(this) + 0x55); } // 0x55 (Size: 0x1, Type: BoolProperty)
    bool bIsTracing() const { return Read<bool>(uintptr_t(this) + 0x56); } // 0x56 (Size: 0x1, Type: BoolProperty)
    FDateTime StatusTimestamp() const { return Read<FDateTime>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: StructProperty)
    char TraceSystemStatus() const { return Read<char>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x1, Type: ByteProperty)

    void SET_Endpoint(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_SessionGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_TraceGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_BytesSent(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: UInt64Property)
    void SET_BytesTraced(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: UInt64Property)
    void SET_MemoryUsed(const uint64_t& Value) { Write<uint64_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: UInt64Property)
    void SET_CacheAllocated(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: UInt32Property)
    void SET_CacheUsed(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: UInt32Property)
    void SET_CacheWaste(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: UInt32Property)
    void SET_bAreStatNamedEventsEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x1, Type: BoolProperty)
    void SET_bIsPaused(const bool& Value) { Write<bool>(uintptr_t(this) + 0x55, Value); } // 0x55 (Size: 0x1, Type: BoolProperty)
    void SET_bIsTracing(const bool& Value) { Write<bool>(uintptr_t(this) + 0x56, Value); } // 0x56 (Size: 0x1, Type: BoolProperty)
    void SET_StatusTimestamp(const FDateTime& Value) { Write<FDateTime>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: StructProperty)
    void SET_TraceSystemStatus(const char& Value) { Write<char>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x1
struct FTraceControlSettingsPing
{
public:
};

// Size: 0x28
struct FTraceChannelPreset
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString ChannelList() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    bool bIsReadOnly() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_ChannelList(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_bIsReadOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FTraceControlSettings
{
public:
    bool bUseWorkerThread() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bUseImportantCache() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    uint32_t TailSizeBytes() const { return Read<uint32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: UInt32Property)
    TArray<FTraceChannelPreset> ChannelPresets() const { return Read<TArray<FTraceChannelPreset>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_bUseWorkerThread(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bUseImportantCache(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_TailSizeBytes(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: UInt32Property)
    void SET_ChannelPresets(const TArray<FTraceChannelPreset>& Value) { Write<TArray<FTraceChannelPreset>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x4
struct FTraceControlChannelsPing
{
public:
    uint32_t KnownChannelCount() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)

    void SET_KnownChannelCount(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x40
struct FTraceControlChannelsDesc
{
public:
    TArray<FString> Channels() const { return Read<TArray<FString>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<uint32_t> Ids() const { return Read<TArray<uint32_t>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> Descriptions() const { return Read<TArray<FString>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<uint32_t> ReadOnlyIds() const { return Read<TArray<uint32_t>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Channels(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Ids(const TArray<uint32_t>& Value) { Write<TArray<uint32_t>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Descriptions(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_ReadOnlyIds(const TArray<uint32_t>& Value) { Write<TArray<uint32_t>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FTraceControlChannelsStatus
{
public:
    TArray<uint32_t> EnabledIds() const { return Read<TArray<uint32_t>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_EnabledIds(const TArray<uint32_t>& Value) { Write<TArray<uint32_t>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FTraceControlChannelsSet
{
public:
    TArray<uint32_t> ChannelIdsToEnable() const { return Read<TArray<uint32_t>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<uint32_t> ChannelIdsToDisable() const { return Read<TArray<uint32_t>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_ChannelIdsToEnable(const TArray<uint32_t>& Value) { Write<TArray<uint32_t>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_ChannelIdsToDisable(const TArray<uint32_t>& Value) { Write<TArray<uint32_t>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FTraceControlDiscoveryPing
{
public:
    FGuid SessionId() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FGuid InstanceID() const { return Read<FGuid>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_SessionId(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_InstanceID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x88
struct FTraceControlDiscovery : public FTraceControlStatus
{
public:
    FGuid SessionId() const { return Read<FGuid>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StructProperty)
    FGuid InstanceID() const { return Read<FGuid>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StructProperty)

    void SET_SessionId(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StructProperty)
    void SET_InstanceID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StructProperty)
};

// Size: 0x1
struct FTraceControlStop
{
public:
};

// Size: 0x18
struct FTraceControlStartCommon
{
public:
    FString Channels() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    bool bExcludeTail() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_Channels(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_bExcludeTail(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FTraceControlSend : public FTraceControlStartCommon
{
public:
    FString Host() const { return Read<FString>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StrProperty)

    void SET_Host(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StrProperty)
};

// Size: 0x30
struct FTraceControlFile : public FTraceControlStartCommon
{
public:
    FString File() const { return Read<FString>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StrProperty)
    bool bTruncateFile() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)

    void SET_File(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StrProperty)
    void SET_bTruncateFile(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1
struct FTraceControlPause
{
public:
};

// Size: 0x1
struct FTraceControlResume
{
public:
};

// Size: 0x10
struct FTraceControlSnapshotSend
{
public:
    FString Host() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)

    void SET_Host(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x10
struct FTraceControlSnapshotFile
{
public:
    FString File() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)

    void SET_File(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x10
struct FTraceControlBookmark
{
public:
    FString Label() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)

    void SET_Label(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x18
struct FTraceControlScreenshot
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    bool bShowUI() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_bShowUI(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1
struct FTraceControlSetStatNamedEvents
{
public:
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)

    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
};

