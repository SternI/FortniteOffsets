/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Buoyancy
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Water.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x28
class UBuoyancyEventInterface : public UInterface
{
public:
};

// Size: 0x60
class UBuoyancyRuntimeSettings : public UDeveloperSettings
{
public:
    bool bBuoyancyEnabled() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bKeepFloatingObjectsAwake() const { return Read<bool>(uintptr_t(this) + 0x31); } // 0x31 (Size: 0x1, Type: BoolProperty)
    float WaterDensity() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float WaterDrag() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ECollisionChannel> CollisionChannelForWaterObjects() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x1, Type: ByteProperty)
    int32_t MaxNumBoundsSubdivisions() const { return Read<int32_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: IntProperty)
    float MinBoundsSubdivisionVol() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)
    char SurfaceTouchCallbackFlags() const { return Read<char>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: ByteProperty)
    float MinVelocityForSurfaceTouchCallback() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    bool bEnableSplineKeyCacheGrid() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    float SplineKeyCacheGridSize() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    uint32_t SplineKeyCacheLimit() const { return Read<uint32_t>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: UInt32Property)

    void SET_bBuoyancyEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_bKeepFloatingObjectsAwake(const bool& Value) { Write<bool>(uintptr_t(this) + 0x31, Value); } // 0x31 (Size: 0x1, Type: BoolProperty)
    void SET_WaterDensity(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_WaterDrag(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_CollisionChannelForWaterObjects(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x1, Type: ByteProperty)
    void SET_MaxNumBoundsSubdivisions(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: IntProperty)
    void SET_MinBoundsSubdivisionVol(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
    void SET_SurfaceTouchCallbackFlags(const char& Value) { Write<char>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: ByteProperty)
    void SET_MinVelocityForSurfaceTouchCallback(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_bEnableSplineKeyCacheGrid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_SplineKeyCacheGridSize(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_SplineKeyCacheLimit(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x90
class UBuoyancySubsystem : public UTickableWorldSubsystem
{
public:
};

