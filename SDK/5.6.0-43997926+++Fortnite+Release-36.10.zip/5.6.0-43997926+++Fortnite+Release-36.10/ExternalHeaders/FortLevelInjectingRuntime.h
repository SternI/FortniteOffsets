/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortLevelInjectingRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "AIModule.h"
#include "Engine.h"
#include "GameplayAbilities.h"
#include "TargetingSystem.h"
#include "LagerRuntime.h"

// Size: 0x220
class UFortDynamicPOIInjectionManager : public UFortLevelInjectionManager
{
public:
    FScalableFloat LevelRevealDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x28, Type: StructProperty)
    FScalableFloat LevelPreInjectionDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x28, Type: StructProperty)
    FScalableFloat TeleportLocationUpOffset() const { return Read<FScalableFloat>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x28, Type: StructProperty)
    UDataTable* LocationMetadataTable() const { return Read<UDataTable*>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x8, Type: ObjectProperty)
    FVector GeoOffsetFromSpawnPoint() const { return Read<FVector>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x18, Type: StructProperty)
    UTargetingPreset* ObstaclePreset() const { return Read<UTargetingPreset*>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    FTransform ChosenInjectTransform() const { return Read<FTransform>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x60, Type: StructProperty)

    void SET_LevelRevealDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x28, Type: StructProperty)
    void SET_LevelPreInjectionDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x28, Type: StructProperty)
    void SET_TeleportLocationUpOffset(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x28, Type: StructProperty)
    void SET_LocationMetadataTable(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x8, Type: ObjectProperty)
    void SET_GeoOffsetFromSpawnPoint(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x18, Type: StructProperty)
    void SET_ObstaclePreset(const UTargetingPreset*& Value) { Write<UTargetingPreset*>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    void SET_ChosenInjectTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x60, Type: StructProperty)
};

// Size: 0x108
class UFortLevelInjectionManager : public UGameStateComponent
{
public:
    UFortLevelInjectionData* InjectionData() const { return Read<UFortLevelInjectionData*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    TArray<FFortAthenaLivingWorldEventTagDensityRegistration> EventTagDensityData() const { return Read<TArray<FFortAthenaLivingWorldEventTagDensityRegistration>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortLevelInjectionRuntimeData> InjectedLevels() const { return Read<TArray<FFortLevelInjectionRuntimeData>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    int32_t EQSHandle() const { return Read<int32_t>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: IntProperty)
    bool bPendingRequest() const { return Read<bool>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    bool bReadyToInject() const { return Read<bool>(uintptr_t(this) + 0xf1); } // 0xf1 (Size: 0x1, Type: BoolProperty)
    TArray<TWeakObjectPtr<AFortLevelInjectionLocation*>> ReservedInjectionLocations() const { return Read<TArray<TWeakObjectPtr<AFortLevelInjectionLocation*>>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x10, Type: ArrayProperty)

    void SET_InjectionData(const UFortLevelInjectionData*& Value) { Write<UFortLevelInjectionData*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_EventTagDensityData(const TArray<FFortAthenaLivingWorldEventTagDensityRegistration>& Value) { Write<TArray<FFortAthenaLivingWorldEventTagDensityRegistration>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    void SET_InjectedLevels(const TArray<FFortLevelInjectionRuntimeData>& Value) { Write<TArray<FFortLevelInjectionRuntimeData>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    void SET_EQSHandle(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: IntProperty)
    void SET_bPendingRequest(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    void SET_bReadyToInject(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf1, Value); } // 0xf1 (Size: 0x1, Type: BoolProperty)
    void SET_ReservedInjectionLocations(const TArray<TWeakObjectPtr<AFortLevelInjectionLocation*>>& Value) { Write<TArray<TWeakObjectPtr<AFortLevelInjectionLocation*>>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UFortLevelInjectionCheatManager : public UChildCheatManager
{
public:
};

// Size: 0x828
class AFortLevelInjectionLocation : public ABuildingLevelInstance
{
public:
    FGameplayTagContainer InstanceTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x7d8); } // 0x7d8 (Size: 0x20, Type: StructProperty)
    FDataTableRowHandle LocationMetadata() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x7f8); } // 0x7f8 (Size: 0x10, Type: StructProperty)
    TSoftObjectPtr<UWorld> NoWorldAsset() const { return Read<TSoftObjectPtr<UWorld>>(uintptr_t(this) + 0x808); } // 0x808 (Size: 0x20, Type: SoftObjectProperty)

    void SET_InstanceTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x7d8, Value); } // 0x7d8 (Size: 0x20, Type: StructProperty)
    void SET_LocationMetadata(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x7f8, Value); } // 0x7f8 (Size: 0x10, Type: StructProperty)
    void SET_NoWorldAsset(const TSoftObjectPtr<UWorld>& Value) { Write<TSoftObjectPtr<UWorld>>(uintptr_t(this) + 0x808, Value); } // 0x808 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x110
class UFortLevelInjectionData : public UFortLevelInjectionDataBase
{
public:
    UEnvQuery* LimitedInjectableLocationsEQS() const { return Read<UEnvQuery*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    TArray<FFortHotfixableInjectionEQSFloatParam> QueryParams() const { return Read<TArray<FFortHotfixableInjectionEQSFloatParam>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    FScalableFloat InjectableLocationsLimit() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x28, Type: StructProperty)

    void SET_LimitedInjectableLocationsEQS(const UEnvQuery*& Value) { Write<UEnvQuery*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
    void SET_QueryParams(const TArray<FFortHotfixableInjectionEQSFloatParam>& Value) { Write<TArray<FFortHotfixableInjectionEQSFloatParam>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    void SET_InjectableLocationsLimit(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x28, Type: StructProperty)
};

// Size: 0xd0
class UFortLevelInjectionDataBase : public UDataAsset
{
public:
    FFortLevelInjectionWorldAssetData BaseLevelAssetData() const { return Read<FFortLevelInjectionWorldAssetData>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x28, Type: StructProperty)
    TArray<FFortLevelInjectionWorldAssetData> HLODData() const { return Read<TArray<FFortLevelInjectionWorldAssetData>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    FVector BoundsExtent() const { return Read<FVector>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x18, Type: StructProperty)
    FString InjectedLevelCellSuffix() const { return Read<FString>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StrProperty)
    int32_t InjectionRequestPriority() const { return Read<int32_t>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: IntProperty)
    FScalableFloat Enabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x28, Type: StructProperty)
    FString DebugName() const { return Read<FString>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: StrProperty)

    void SET_BaseLevelAssetData(const FFortLevelInjectionWorldAssetData& Value) { Write<FFortLevelInjectionWorldAssetData>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x28, Type: StructProperty)
    void SET_HLODData(const TArray<FFortLevelInjectionWorldAssetData>& Value) { Write<TArray<FFortLevelInjectionWorldAssetData>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_BoundsExtent(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x18, Type: StructProperty)
    void SET_InjectedLevelCellSuffix(const FString& Value) { Write<FString>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StrProperty)
    void SET_InjectionRequestPriority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: IntProperty)
    void SET_Enabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x28, Type: StructProperty)
    void SET_DebugName(const FString& Value) { Write<FString>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: StrProperty)
};

// Size: 0xc8
class UFortLevelInjectionManagerBase : public UGameStateComponent
{
public:
    TArray<FFortLevelInjectionRuntimeDataBase> InjectedLevels() const { return Read<TArray<FFortLevelInjectionRuntimeDataBase>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)

    void SET_InjectedLevels(const TArray<FFortLevelInjectionRuntimeDataBase>& Value) { Write<TArray<FFortLevelInjectionRuntimeDataBase>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FFortLevelInjectionLocationMetadata : public FTableRowBase
{
public:
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FFortHotfixableInjectionEQSFloatParam
{
public:
    FName ParamName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FScalableFloat Value() const { return Read<FScalableFloat>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x28, Type: StructProperty)

    void SET_ParamName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Value(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x70
struct FFortLevelInjectionRuntimeData
{
public:
    FGuid LevelGUID() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FTransform LevelTransform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)

    void SET_LevelGUID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_LevelTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
};

// Size: 0x28
struct FFortLevelInjectionWorldAssetData
{
public:
    TSoftObjectPtr<UWorld> WorldAsset() const { return Read<TSoftObjectPtr<UWorld>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    FName TargetGridName() const { return Read<FName>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: NameProperty)

    void SET_WorldAsset(const TSoftObjectPtr<UWorld>& Value) { Write<TSoftObjectPtr<UWorld>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_TargetGridName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: NameProperty)
};

// Size: 0x90
struct FFortLevelInjectionRuntimeDataBase
{
public:
    TSoftObjectPtr<UFortLevelInjectionDataBase> InjectionData() const { return Read<TSoftObjectPtr<UFortLevelInjectionDataBase>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    FGuid LevelGUID() const { return Read<FGuid>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    FTransform LevelTransform() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)

    void SET_InjectionData(const TSoftObjectPtr<UFortLevelInjectionDataBase>& Value) { Write<TSoftObjectPtr<UFortLevelInjectionDataBase>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_LevelGUID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_LevelTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
};

