/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_DelMarProductModeUserFacingData
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x78
class UBP_DelMarProductModeUserFacingData_C : public UProductModeUserFacingData
{
public:
};

