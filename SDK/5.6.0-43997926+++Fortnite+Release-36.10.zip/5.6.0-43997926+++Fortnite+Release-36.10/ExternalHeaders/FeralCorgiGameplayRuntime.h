/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FeralCorgiGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "FortniteGame.h"
#include "GameplayTags.h"

// Size: 0x28
class UApparatusBridge : public UObject
{
public:
};

// Size: 0x28
class UCheatBridge : public UObject
{
public:
};

// Size: 0x28
class UFeralCorgiGameStateComponentBridge : public UObject
{
public:
};

// Size: 0xd0
class UFortControllerComponent_FeralCorgi : public UFortControllerComponent
{
public:
    UClass* DamageCameraShakeClassOverride() const { return Read<UClass*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    UClass* DynamicDamageZoneComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ClassProperty)

    void SET_DamageCameraShakeClassOverride(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ClassProperty)
    void SET_DynamicDamageZoneComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x148
class UFortPlayspaceComponent_Apparatus : public UFortPlayspaceComponent
{
public:
};

// Size: 0x1a0
class UFortUserOptionComponent_TickRate : public UFortUserOptionContainerComponent
{
public:
    uint8_t DesiredTickRate() const { return Read<uint8_t>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x1, Type: EnumProperty)

    void SET_DesiredTickRate(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x1aa8
class AFeralCorgiPlayerState : public AFortPlayerStateAthena
{
public:
    TArray<FLinearColor> PinColorForPlayer() const { return Read<TArray<FLinearColor>>(uintptr_t(this) + 0x1a98); } // 0x1a98 (Size: 0x10, Type: ArrayProperty)

    void SET_PinColorForPlayer(const TArray<FLinearColor>& Value) { Write<TArray<FLinearColor>>(uintptr_t(this) + 0x1a98, Value); } // 0x1a98 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x6e8
class AFeralCorgiRootPlayspace : public AFortPlayspace
{
public:
    UClass* FeralCorgiStateMachineClass() const { return Read<UClass*>(uintptr_t(this) + 0x6e0); } // 0x6e0 (Size: 0x8, Type: ClassProperty)

    void SET_FeralCorgiStateMachineClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x6e0, Value); } // 0x6e0 (Size: 0x8, Type: ClassProperty)
};

// Size: 0xd0
class UFortGameStateComponent_FeralCorgiManager : public UFortGameStateComponent
{
public:
    char TeamOneTeamId() const { return Read<char>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: ByteProperty)
    char TeamTwoTeamId() const { return Read<char>(uintptr_t(this) + 0xc9); } // 0xc9 (Size: 0x1, Type: ByteProperty)
    uint8_t CurrentAttackingTeam() const { return Read<uint8_t>(uintptr_t(this) + 0xca); } // 0xca (Size: 0x1, Type: EnumProperty)
    uint8_t RoundWinningTeam() const { return Read<uint8_t>(uintptr_t(this) + 0xcb); } // 0xcb (Size: 0x1, Type: EnumProperty)
    uint8_t RoundWinningTeamRole() const { return Read<uint8_t>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x1, Type: EnumProperty)

    void SET_TeamOneTeamId(const char& Value) { Write<char>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: ByteProperty)
    void SET_TeamTwoTeamId(const char& Value) { Write<char>(uintptr_t(this) + 0xc9, Value); } // 0xc9 (Size: 0x1, Type: ByteProperty)
    void SET_CurrentAttackingTeam(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xca, Value); } // 0xca (Size: 0x1, Type: EnumProperty)
    void SET_RoundWinningTeam(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xcb, Value); } // 0xcb (Size: 0x1, Type: EnumProperty)
    void SET_RoundWinningTeamRole(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x1, Type: EnumProperty)
};

// Size: 0x88
class UFeralCorgiState : public UFortGameplayState
{
public:
};

// Size: 0xf0
class UFeralCorgiStateMachine : public UFortGameplayStateMachine
{
public:
};

// Size: 0x88
class UFeralCorgiState_ClassSelection : public UFeralCorgiState
{
public:
};

// Size: 0xf0
class UFeralCorgiState_MainLoopSM : public UFeralCorgiStateMachine
{
public:
};

// Size: 0x88
class UFeralCorgiState_MainLoop_BuyPhase : public UFeralCorgiState
{
public:
};

// Size: 0x88
class UFeralCorgiState_MainLoop_End : public UFeralCorgiState
{
public:
};

// Size: 0x88
class UFeralCorgiState_MainLoop_Gameplay : public UFeralCorgiState
{
public:
};

// Size: 0x88
class UFeralCorgiState_MainLoop_Reset : public UFeralCorgiState
{
public:
};

// Size: 0xf0
class UFeralCorgiState_MasterSM : public UFortGameplayStateMachine
{
public:
};

// Size: 0x88
class UFeralCorgiState_MatchFinished : public UFeralCorgiState
{
public:
};

// Size: 0x88
class UFeralCorgiState_Setup : public UFeralCorgiState
{
public:
};

// Size: 0x2e0
class AFeralCorgiTeamStart : public AFortSquadStart
{
public:
    uint8_t StartType() const { return Read<uint8_t>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x1, Type: EnumProperty)

    void SET_StartType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x4f8
class AFortAthenaMutator_FeralCorgi : public AFortAthenaMutator_GameModeBase
{
public:
    TArray<UFortWorldItemDefinition*> DoNotDropItemDefs() const { return Read<TArray<UFortWorldItemDefinition*>>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x10, Type: ArrayProperty)
    TArray<UFortWorldItemDefinition*> DoNotDestroyItemDefs() const { return Read<TArray<UFortWorldItemDefinition*>>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x10, Type: ArrayProperty)
    TArray<UFortWorldItemDefinition*> AutoPickupItemDefs() const { return Read<TArray<UFortWorldItemDefinition*>>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x10, Type: ArrayProperty)
    TArray<UFortWorldItemDefinition*> BuyPhaseRestrictedItemDefs() const { return Read<TArray<UFortWorldItemDefinition*>>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x10, Type: ArrayProperty)
    TEnumAsByte<EVerticalAlignment> HUDMenuBottomBarVerticalAligment() const { return Read<TEnumAsByte<EVerticalAlignment>>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EHorizontalAlignment> HUDMenuBottomBarHorizontalAligment() const { return Read<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x4f1); } // 0x4f1 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EVerticalAlignment> HUDEliminatorSpectatingPlayernameVerticalAligment() const { return Read<TEnumAsByte<EVerticalAlignment>>(uintptr_t(this) + 0x4f2); } // 0x4f2 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EHorizontalAlignment> HUDEliminatorSpectatingPlayernameHorinzontalAligment() const { return Read<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x4f3); } // 0x4f3 (Size: 0x1, Type: ByteProperty)
    bool bUseTeamForSpectating() const { return Read<bool>(uintptr_t(this) + 0x4f4); } // 0x4f4 (Size: 0x1, Type: BoolProperty)

    void SET_DoNotDropItemDefs(const TArray<UFortWorldItemDefinition*>& Value) { Write<TArray<UFortWorldItemDefinition*>>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x10, Type: ArrayProperty)
    void SET_DoNotDestroyItemDefs(const TArray<UFortWorldItemDefinition*>& Value) { Write<TArray<UFortWorldItemDefinition*>>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x10, Type: ArrayProperty)
    void SET_AutoPickupItemDefs(const TArray<UFortWorldItemDefinition*>& Value) { Write<TArray<UFortWorldItemDefinition*>>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x10, Type: ArrayProperty)
    void SET_BuyPhaseRestrictedItemDefs(const TArray<UFortWorldItemDefinition*>& Value) { Write<TArray<UFortWorldItemDefinition*>>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x10, Type: ArrayProperty)
    void SET_HUDMenuBottomBarVerticalAligment(const TEnumAsByte<EVerticalAlignment>& Value) { Write<TEnumAsByte<EVerticalAlignment>>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x1, Type: ByteProperty)
    void SET_HUDMenuBottomBarHorizontalAligment(const TEnumAsByte<EHorizontalAlignment>& Value) { Write<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x4f1, Value); } // 0x4f1 (Size: 0x1, Type: ByteProperty)
    void SET_HUDEliminatorSpectatingPlayernameVerticalAligment(const TEnumAsByte<EVerticalAlignment>& Value) { Write<TEnumAsByte<EVerticalAlignment>>(uintptr_t(this) + 0x4f2, Value); } // 0x4f2 (Size: 0x1, Type: ByteProperty)
    void SET_HUDEliminatorSpectatingPlayernameHorinzontalAligment(const TEnumAsByte<EHorizontalAlignment>& Value) { Write<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x4f3, Value); } // 0x4f3 (Size: 0x1, Type: ByteProperty)
    void SET_bUseTeamForSpectating(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4f4, Value); } // 0x4f4 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UFortCheatManager_FeralCorgi : public UChildCheatManager
{
public:
};

// Size: 0xd0
class UFortGameStateComponent_FeralCorgiVerseCommonBridge : public UFortGameStateComponent
{
public:
    FString CurrentPhaseName() const { return Read<FString>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: StrProperty)

    void SET_CurrentPhaseName(const FString& Value) { Write<FString>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x4
struct FFeralCorgiCheatEvent
{
public:
    FGameplayTag Tag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)

    void SET_Tag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
};

