/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FallTeleportationRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "GameplayAbilities.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x180
class UFortFallTeleportSpawnerComponent : public UActorComponent
{
public:
    UClass* ComponentToAddClass() const { return Read<UClass*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ClassProperty)
    FScalableFloat TeleportEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x28, Type: StructProperty)
    FScalableFloat RemoveComponentRequestTimeOffset() const { return Read<FScalableFloat>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x28, Type: StructProperty)

    void SET_ComponentToAddClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ClassProperty)
    void SET_TeleportEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x28, Type: StructProperty)
    void SET_RemoveComponentRequestTimeOffset(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x28, Type: StructProperty)
};

// Size: 0x28
class UFortFallTeleportCheatManager : public UChildCheatManager
{
public:
};

// Size: 0x208
class UFortFallTeleportComponentBase : public UActorComponent
{
public:
    FScalableFloat TeleportEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x28, Type: StructProperty)
    FScalableFloat ContinuousTeleportUpdateEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ForceTeleportZHeight() const { return Read<FScalableFloat>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x28, Type: StructProperty)
    FScalableFloat SphereTraceRadius() const { return Read<FScalableFloat>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x28, Type: StructProperty)
    float WalkingLocationUpdateRate() const { return Read<float>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x4, Type: FloatProperty)
    float ZHeightThresholdCheckRate() const { return Read<float>(uintptr_t(this) + 0x15c); } // 0x15c (Size: 0x4, Type: FloatProperty)
    float TeleportZModifier() const { return Read<float>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x4, Type: FloatProperty)
    float DistanceFromPawnToTraceLocation() const { return Read<float>(uintptr_t(this) + 0x164); } // 0x164 (Size: 0x4, Type: FloatProperty)
    TArray<UClass*> TeleportOnBlocklist() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x10, Type: ArrayProperty)
    FName NoTeleportActorTag() const { return Read<FName>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x4, Type: NameProperty)
    FVector SafeManualLocation() const { return Read<FVector>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x18, Type: StructProperty)
    UClass* TeleportGEClass() const { return Read<UClass*>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x8, Type: ClassProperty)
    FVector TeleportLocation() const { return Read<FVector>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x18, Type: StructProperty)
    FVector FallbackLocation() const { return Read<FVector>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x18, Type: StructProperty)
    bool bValidFallbackLocation() const { return Read<bool>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x1, Type: BoolProperty)
    bool bTeleporting() const { return Read<bool>(uintptr_t(this) + 0x1d1); } // 0x1d1 (Size: 0x1, Type: BoolProperty)
    int32_t TeleportLimitBeforeFail() const { return Read<int32_t>(uintptr_t(this) + 0x1d4); } // 0x1d4 (Size: 0x4, Type: IntProperty)
    int32_t TeleportCount() const { return Read<int32_t>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x4, Type: IntProperty)
    AFortPlayerPawnAthena* OwningPawn() const { return Read<AFortPlayerPawnAthena*>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x8, Type: ObjectProperty)

    void SET_TeleportEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x28, Type: StructProperty)
    void SET_ContinuousTeleportUpdateEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x28, Type: StructProperty)
    void SET_ForceTeleportZHeight(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x28, Type: StructProperty)
    void SET_SphereTraceRadius(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x28, Type: StructProperty)
    void SET_WalkingLocationUpdateRate(const float& Value) { Write<float>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x4, Type: FloatProperty)
    void SET_ZHeightThresholdCheckRate(const float& Value) { Write<float>(uintptr_t(this) + 0x15c, Value); } // 0x15c (Size: 0x4, Type: FloatProperty)
    void SET_TeleportZModifier(const float& Value) { Write<float>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x4, Type: FloatProperty)
    void SET_DistanceFromPawnToTraceLocation(const float& Value) { Write<float>(uintptr_t(this) + 0x164, Value); } // 0x164 (Size: 0x4, Type: FloatProperty)
    void SET_TeleportOnBlocklist(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x10, Type: ArrayProperty)
    void SET_NoTeleportActorTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x4, Type: NameProperty)
    void SET_SafeManualLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x18, Type: StructProperty)
    void SET_TeleportGEClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x8, Type: ClassProperty)
    void SET_TeleportLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x18, Type: StructProperty)
    void SET_FallbackLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x18, Type: StructProperty)
    void SET_bValidFallbackLocation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x1, Type: BoolProperty)
    void SET_bTeleporting(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d1, Value); } // 0x1d1 (Size: 0x1, Type: BoolProperty)
    void SET_TeleportLimitBeforeFail(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1d4, Value); } // 0x1d4 (Size: 0x4, Type: IntProperty)
    void SET_TeleportCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x4, Type: IntProperty)
    void SET_OwningPawn(const AFortPlayerPawnAthena*& Value) { Write<AFortPlayerPawnAthena*>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x8, Type: ObjectProperty)
};

