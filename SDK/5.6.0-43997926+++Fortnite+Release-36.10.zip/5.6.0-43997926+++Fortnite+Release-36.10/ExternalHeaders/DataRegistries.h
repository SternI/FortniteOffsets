/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataRegistries
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayTags.h"
#include "FortniteGame.h"

// Size: 0xf8
struct FStatCreatorRegistryRow
{
public:
    FText DisplayName_9_F5EC2D0F4BEE61DAA7FD9CAE57322EC9() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    FStatEventFilter Value_5_0C712CA14D04EE76CE65A4B898BD94D5() const { return Read<FStatEventFilter>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x88, Type: StructProperty)
    FCreativeIconOption DisplayIcon_8_36F66E1B428226432A8D488CF9AE1027() const { return Read<FCreativeIconOption>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x40, Type: StructProperty)
    FGameplayTagContainer ValueFilterTags_12_8A08AD2E4D36355DDEF81AB5CC48ECE4() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x20, Type: StructProperty)

    void SET_DisplayName_9_F5EC2D0F4BEE61DAA7FD9CAE57322EC9(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_Value_5_0C712CA14D04EE76CE65A4B898BD94D5(const FStatEventFilter& Value) { Write<FStatEventFilter>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x88, Type: StructProperty)
    void SET_DisplayIcon_8_36F66E1B428226432A8D488CF9AE1027(const FCreativeIconOption& Value) { Write<FCreativeIconOption>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x40, Type: StructProperty)
    void SET_ValueFilterTags_12_8A08AD2E4D36355DDEF81AB5CC48ECE4(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x20, Type: StructProperty)
};

