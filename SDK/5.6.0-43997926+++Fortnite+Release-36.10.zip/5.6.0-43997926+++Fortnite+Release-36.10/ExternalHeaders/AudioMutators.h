/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioMutators
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "AudioExtensions.h"

// Size: 0x48
class UAudioMutator : public UAudioMutatorBase
{
public:
    TArray<FInstancedStruct> Selectors() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> Actions() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_Selectors(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_Actions(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UAudioMutatorBase : public UObject
{
public:
};

// Size: 0x58
class UAudioMutatorsSubsystem : public UAudioEngineSubsystem
{
public:
};

// Size: 0x98
class UAudioOwnerRegistry : public UAudioEngineSubsystem
{
public:
};

// Size: 0x50
class UAudioMutatorBespoke : public UAudioMutatorBase
{
public:
    TWeakObjectPtr<AActor*> Actor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    FGameplayTag Tag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: StructProperty)
    TArray<FSourceEffectChainEntry> EffectChain() const { return Read<TArray<FSourceEffectChainEntry>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    float PitchMultiplier() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float VolumeMultiplier() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)

    void SET_Actor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Tag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: StructProperty)
    void SET_EffectChain(const TArray<FSourceEffectChainEntry>& Value) { Write<TArray<FSourceEffectChainEntry>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_PitchMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_VolumeMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x78
class UAudioMutatorReusingParts : public UAudioMutatorBase
{
public:
    FSoundSelectorActorInstance SelectorActorInstance() const { return Read<FSoundSelectorActorInstance>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    FSoundSelectorTag SelectorTag() const { return Read<FSoundSelectorTag>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FSoundActionPitch ActionPitch() const { return Read<FSoundActionPitch>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    FSoundActionSourceEffect ActionSourceEffect() const { return Read<FSoundActionSourceEffect>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    FSoundActionVolume ActionVolume() const { return Read<FSoundActionVolume>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StructProperty)

    void SET_SelectorActorInstance(const FSoundSelectorActorInstance& Value) { Write<FSoundSelectorActorInstance>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_SelectorTag(const FSoundSelectorTag& Value) { Write<FSoundSelectorTag>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_ActionPitch(const FSoundActionPitch& Value) { Write<FSoundActionPitch>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_ActionSourceEffect(const FSoundActionSourceEffect& Value) { Write<FSoundActionSourceEffect>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_ActionVolume(const FSoundActionVolume& Value) { Write<FSoundActionVolume>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StructProperty)
};

// Size: 0x48
class UGameFeatureAction_AddAudioMutators : public UGameFeatureAction_AudioActionBase
{
public:
    TArray<UAudioMutatorBase*> Mutators() const { return Read<TArray<UAudioMutatorBase*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_Mutators(const TArray<UAudioMutatorBase*>& Value) { Write<TArray<UAudioMutatorBase*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FAudioMutatorAction
{
public:
};

// Size: 0x8
struct FAudioMutatorSelector
{
public:
};

// Size: 0x18
struct FSoundActionModulator : public FAudioMutatorAction
{
public:
    USoundModulatorBase* Modulator() const { return Read<USoundModulatorBase*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Destination() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)

    void SET_Modulator(const USoundModulatorBase*& Value) { Write<USoundModulatorBase*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Destination(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x10
struct FSoundActionPitch : public FAudioMutatorAction
{
public:
    float PitchMultiplier() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_PitchMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FSoundActionSourceEffect : public FAudioMutatorAction
{
public:
    USoundEffectSourcePresetChain* PresetChain() const { return Read<USoundEffectSourcePresetChain*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_PresetChain(const USoundEffectSourcePresetChain*& Value) { Write<USoundEffectSourcePresetChain*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x18
struct FSoundActionSubmixSend : public FAudioMutatorAction
{
public:
    TArray<FSoundSubmixSendInfo> SubmixSends() const { return Read<TArray<FSoundSubmixSendInfo>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_SubmixSends(const TArray<FSoundSubmixSendInfo>& Value) { Write<TArray<FSoundSubmixSendInfo>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FSoundActionVolume : public FAudioMutatorAction
{
public:
    float VolumeMultiplier() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_VolumeMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FSoundSelectorActorClass : public FAudioMutatorSelector
{
public:
    UClass* ActorClass() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)
    bool bExactClass() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_ActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
    void SET_bExactClass(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FSoundSelectorActorInstance : public FAudioMutatorSelector
{
public:
    TWeakObjectPtr<AActor*> Actor() const { return Read<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Actor(const TWeakObjectPtr<AActor*>& Value) { Write<TWeakObjectPtr<AActor*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x18
struct FSoundSelectorConditionalNone : public FAudioMutatorSelector
{
public:
    TArray<FInstancedStruct> Selectors() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Selectors(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FSoundSelectorConditionalAny : public FAudioMutatorSelector
{
public:
    TArray<FInstancedStruct> Selectors() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Selectors(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FSoundSelectorConditionalAll : public FAudioMutatorSelector
{
public:
    TArray<FInstancedStruct> Selectors() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Selectors(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FSoundSelectorSoundBaseSubclass : public FAudioMutatorSelector
{
public:
    UClass* SoundBaseSubclass() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)
    bool bExactClass() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_SoundBaseSubclass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
    void SET_bExactClass(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FSoundSelectorSoundClass : public FAudioMutatorSelector
{
public:
    USoundClass* SoundClass() const { return Read<USoundClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    bool bExactClass() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_SoundClass(const USoundClass*& Value) { Write<USoundClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_bExactClass(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FSoundSelectorTag : public FAudioMutatorSelector
{
public:
    FGameplayTag Tag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    bool bExactMatch() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)

    void SET_Tag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_bExactMatch(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
};

