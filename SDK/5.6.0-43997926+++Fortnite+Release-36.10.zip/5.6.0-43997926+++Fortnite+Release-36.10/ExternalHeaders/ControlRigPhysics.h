/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ControlRigPhysics
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "PhysicsControl.h"
#include "ControlRig.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x180
struct FRigPhysicsBodyComponent : public FRigBaseComponent
{
public:
    FRigPhysicsBodySolverSettings BodySolverSettings() const { return Read<FRigPhysicsBodySolverSettings>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x20, Type: StructProperty)
    FRigPhysicsDynamics Dynamics() const { return Read<FRigPhysicsDynamics>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x50, Type: StructProperty)
    FRigPhysicsCollision Collision() const { return Read<FRigPhysicsCollision>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x40, Type: StructProperty)
    FPhysicsControlModifierData BodyData() const { return Read<FPhysicsControlModifierData>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: StructProperty)
    FTransform KinematicTarget() const { return Read<FTransform>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x60, Type: StructProperty)
    uint8_t KinematicTargetSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x1, Type: EnumProperty)
    TArray<FRigComponentKey> NoCollisionBodies() const { return Read<TArray<FRigComponentKey>>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x10, Type: ArrayProperty)

    void SET_BodySolverSettings(const FRigPhysicsBodySolverSettings& Value) { Write<FRigPhysicsBodySolverSettings>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x20, Type: StructProperty)
    void SET_Dynamics(const FRigPhysicsDynamics& Value) { Write<FRigPhysicsDynamics>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x50, Type: StructProperty)
    void SET_Collision(const FRigPhysicsCollision& Value) { Write<FRigPhysicsCollision>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x40, Type: StructProperty)
    void SET_BodyData(const FPhysicsControlModifierData& Value) { Write<FPhysicsControlModifierData>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: StructProperty)
    void SET_KinematicTarget(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x60, Type: StructProperty)
    void SET_KinematicTargetSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x1, Type: EnumProperty)
    void SET_NoCollisionBodies(const TArray<FRigComponentKey>& Value) { Write<TArray<FRigComponentKey>>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FRigPhysicsCollision
{
public:
    TArray<FRigPhysicsCollisionBox> Boxes() const { return Read<TArray<FRigPhysicsCollisionBox>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigPhysicsCollisionSphere> Spheres() const { return Read<TArray<FRigPhysicsCollisionSphere>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigPhysicsCollisionCapsule> Capsules() const { return Read<TArray<FRigPhysicsCollisionCapsule>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    FRigPhysicsMaterial Material() const { return Read<FRigPhysicsMaterial>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0xc, Type: StructProperty)

    void SET_Boxes(const TArray<FRigPhysicsCollisionBox>& Value) { Write<TArray<FRigPhysicsCollisionBox>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Spheres(const TArray<FRigPhysicsCollisionSphere>& Value) { Write<TArray<FRigPhysicsCollisionSphere>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Capsules(const TArray<FRigPhysicsCollisionCapsule>& Value) { Write<TArray<FRigPhysicsCollisionCapsule>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_Material(const FRigPhysicsMaterial& Value) { Write<FRigPhysicsMaterial>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0xc, Type: StructProperty)
};

// Size: 0xc
struct FRigPhysicsMaterial
{
public:
    float Friction() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Restitution() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t FrictionCombineMode() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t RestitutionCombineMode() const { return Read<uint8_t>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: EnumProperty)

    void SET_Friction(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Restitution(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_FrictionCombineMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_RestitutionCombineMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: EnumProperty)
};

// Size: 0xc
struct FRigPhysicsCollisionShape
{
public:
    float RestOffset() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    bool bContributeToMass() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_RestOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_bContributeToMass(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
struct FRigPhysicsCollisionCapsule : public FRigPhysicsCollisionShape
{
public:
    FTransform TM() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    float Length() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)

    void SET_TM(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_Length(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x80
struct FRigPhysicsCollisionSphere : public FRigPhysicsCollisionShape
{
public:
    FTransform TM() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)

    void SET_TM(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x90
struct FRigPhysicsCollisionBox : public FRigPhysicsCollisionShape
{
public:
    FTransform TM() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FVector Extents() const { return Read<FVector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)

    void SET_TM(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_Extents(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
};

// Size: 0x50
struct FRigPhysicsDynamics
{
public:
    float Density() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MassOverride() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bOverrideCentreOfMass() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    FVector CentreOfMassOverride() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    bool bOverrideMomentsOfInertia() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    FVector MomentsOfInertiaOverride() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    float LinearDamping() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float AngularDamping() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)

    void SET_Density(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MassOverride(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_bOverrideCentreOfMass(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_CentreOfMassOverride(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_bOverrideMomentsOfInertia(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_MomentsOfInertiaOverride(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_LinearDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_AngularDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FRigPhysicsBodySolverSettings
{
public:
    FRigComponentKey PhysicsSolverComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    bool bUseAutomaticSolver() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)
    FRigElementKey SourceBone() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FRigElementKey TargetBone() const { return Read<FRigElementKey>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: StructProperty)

    void SET_PhysicsSolverComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_bUseAutomaticSolver(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
    void SET_SourceBone(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_TargetBone(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: StructProperty)
};

// Size: 0x188
struct FRigPhysicsControlComponent : public FRigBaseComponent
{
public:
    FRigComponentKey ParentBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0xc, Type: StructProperty)
    bool bUseParentBodyAsDefault() const { return Read<bool>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x1, Type: BoolProperty)
    FRigComponentKey ChildBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0xc, Type: StructProperty)
    FPhysicsControlData ControlData() const { return Read<FPhysicsControlData>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x50, Type: StructProperty)
    FPhysicsControlMultiplier ControlMultiplier() const { return Read<FPhysicsControlMultiplier>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x70, Type: StructProperty)
    FPhysicsControlTarget ControlTarget() const { return Read<FPhysicsControlTarget>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x68, Type: StructProperty)

    void SET_ParentBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0xc, Type: StructProperty)
    void SET_bUseParentBodyAsDefault(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x1, Type: BoolProperty)
    void SET_ChildBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0xc, Type: StructProperty)
    void SET_ControlData(const FPhysicsControlData& Value) { Write<FPhysicsControlData>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x50, Type: StructProperty)
    void SET_ControlMultiplier(const FPhysicsControlMultiplier& Value) { Write<FPhysicsControlMultiplier>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x70, Type: StructProperty)
    void SET_ControlTarget(const FPhysicsControlTarget& Value) { Write<FPhysicsControlTarget>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x68, Type: StructProperty)
};

// Size: 0x14
struct FRigPhysicsVisualizationSettings
{
public:
    bool bEnableVisualization() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float LineThickness() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    int32_t ShapeSize() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t ShapeDetail() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    bool bShowActiveContacts() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bShowInactiveContacts() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)

    void SET_bEnableVisualization(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_LineThickness(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_ShapeSize(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_ShapeDetail(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_bShowActiveContacts(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_bShowInactiveContacts(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x88
struct FRigPhysicsSimulationSpaceSettings
{
public:
    float SpaceMovementAmount() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float VelocityScaleZ() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bClampLinearVelocity() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    float MaxLinearVelocity() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    bool bClampAngularVelocity() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    float MaxAngularVelocity() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    bool bClampLinearAcceleration() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    float MaxLinearAcceleration() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    bool bClampAngularAcceleration() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    float MaxAngularAcceleration() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float LinearAccelerationThresholdForTeleport() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float AngularAccelerationThresholdForTeleport() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float PositionChangeThresholdForTeleport() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float OrientationChangeThresholdForTeleport() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float LinearDragMultiplier() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float AngularDragMultiplier() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    FVector ExternalLinearDrag() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    FVector ExternalLinearVelocity() const { return Read<FVector>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)
    FVector ExternalAngularVelocity() const { return Read<FVector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)

    void SET_SpaceMovementAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_VelocityScaleZ(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_bClampLinearVelocity(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_MaxLinearVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_bClampAngularVelocity(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_MaxAngularVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_bClampLinearAcceleration(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_MaxLinearAcceleration(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_bClampAngularAcceleration(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_MaxAngularAcceleration(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_LinearAccelerationThresholdForTeleport(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_AngularAccelerationThresholdForTeleport(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_PositionChangeThresholdForTeleport(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_OrientationChangeThresholdForTeleport(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_LinearDragMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_AngularDragMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_ExternalLinearDrag(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_ExternalLinearVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
    void SET_ExternalAngularVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
};

// Size: 0xa8
struct FRigPhysicsSolverSettings
{
public:
    bool bAutomaticallyAddPhysicsComponents() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t SimulationSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t CollisionSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: EnumProperty)
    FRigElementKey SpaceBone() const { return Read<FRigElementKey>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x8, Type: StructProperty)
    FRigPhysicsCollision Collision() const { return Read<FRigPhysicsCollision>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x40, Type: StructProperty)
    FVector Gravity() const { return Read<FVector>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)
    int32_t PositionIterations() const { return Read<int32_t>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: IntProperty)
    int32_t VelocityIterations() const { return Read<int32_t>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: IntProperty)
    int32_t ProjectionIterations() const { return Read<int32_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: IntProperty)
    int32_t MaxNumRollingAverageStepTimes() const { return Read<int32_t>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: IntProperty)
    float CollisionBoundsExpansion() const { return Read<float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: FloatProperty)
    float BoundsVelocityMultiplier() const { return Read<float>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: FloatProperty)
    float MaxVelocityBoundsExpansion() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    float MaxDepenetrationVelocity() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    float FixedTimeStep() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)
    int32_t MaxTimeSteps() const { return Read<int32_t>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: IntProperty)
    float MaxDeltaTime() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    bool bUseLinearJointSolver() const { return Read<bool>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x1, Type: BoolProperty)
    bool bSolveJointPositionsLast() const { return Read<bool>(uintptr_t(this) + 0x95); } // 0x95 (Size: 0x1, Type: BoolProperty)
    bool bUseManifolds() const { return Read<bool>(uintptr_t(this) + 0x96); } // 0x96 (Size: 0x1, Type: BoolProperty)
    float PositionThresholdForReset() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    float KinematicSpeedThresholdForReset() const { return Read<float>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: FloatProperty)
    float KinematicAccelerationThresholdForReset() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)

    void SET_bAutomaticallyAddPhysicsComponents(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_SimulationSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
    void SET_CollisionSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: EnumProperty)
    void SET_SpaceBone(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x8, Type: StructProperty)
    void SET_Collision(const FRigPhysicsCollision& Value) { Write<FRigPhysicsCollision>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x40, Type: StructProperty)
    void SET_Gravity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
    void SET_PositionIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: IntProperty)
    void SET_VelocityIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: IntProperty)
    void SET_ProjectionIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: IntProperty)
    void SET_MaxNumRollingAverageStepTimes(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: IntProperty)
    void SET_CollisionBoundsExpansion(const float& Value) { Write<float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: FloatProperty)
    void SET_BoundsVelocityMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: FloatProperty)
    void SET_MaxVelocityBoundsExpansion(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_MaxDepenetrationVelocity(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_FixedTimeStep(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
    void SET_MaxTimeSteps(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: IntProperty)
    void SET_MaxDeltaTime(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_bUseLinearJointSolver(const bool& Value) { Write<bool>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x1, Type: BoolProperty)
    void SET_bSolveJointPositionsLast(const bool& Value) { Write<bool>(uintptr_t(this) + 0x95, Value); } // 0x95 (Size: 0x1, Type: BoolProperty)
    void SET_bUseManifolds(const bool& Value) { Write<bool>(uintptr_t(this) + 0x96, Value); } // 0x96 (Size: 0x1, Type: BoolProperty)
    void SET_PositionThresholdForReset(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_KinematicSpeedThresholdForReset(const float& Value) { Write<float>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: FloatProperty)
    void SET_KinematicAccelerationThresholdForReset(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xd8
struct FRigPhysicsDriveData
{
public:
    FLinearDriveConstraint LinearDriveConstraint() const { return Read<FLinearDriveConstraint>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x68, Type: StructProperty)
    FAngularDriveConstraint AngularDriveConstraint() const { return Read<FAngularDriveConstraint>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x68, Type: StructProperty)
    float SkeletalAnimationVelocityMultiplier() const { return Read<float>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: FloatProperty)

    void SET_LinearDriveConstraint(const FLinearDriveConstraint& Value) { Write<FLinearDriveConstraint>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x68, Type: StructProperty)
    void SET_AngularDriveConstraint(const FAngularDriveConstraint& Value) { Write<FAngularDriveConstraint>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x68, Type: StructProperty)
    void SET_SkeletalAnimationVelocityMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x150
struct FRigPhysicsJointData
{
public:
    bool bAutoCalculateParentOffset() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    FTransform ExtraParentOffset() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    bool bAutoCalculateChildOffset() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    FTransform ExtraChildOffset() const { return Read<FTransform>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x60, Type: StructProperty)
    FLinearConstraint LinearConstraint() const { return Read<FLinearConstraint>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1c, Type: StructProperty)
    FConeConstraint ConeConstraint() const { return Read<FConeConstraint>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x20, Type: StructProperty)
    FTwistConstraint TwistConstraint() const { return Read<FTwistConstraint>(uintptr_t(this) + 0x11c); } // 0x11c (Size: 0x1c, Type: StructProperty)
    bool bDisableCollision() const { return Read<bool>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x1, Type: BoolProperty)
    float LinearProjectionAmount() const { return Read<float>(uintptr_t(this) + 0x13c); } // 0x13c (Size: 0x4, Type: FloatProperty)
    float AngularProjectionAmount() const { return Read<float>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x4, Type: FloatProperty)
    float ParentInverseMassScale() const { return Read<float>(uintptr_t(this) + 0x144); } // 0x144 (Size: 0x4, Type: FloatProperty)

    void SET_bAutoCalculateParentOffset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_ExtraParentOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_bAutoCalculateChildOffset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_ExtraChildOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x60, Type: StructProperty)
    void SET_LinearConstraint(const FLinearConstraint& Value) { Write<FLinearConstraint>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1c, Type: StructProperty)
    void SET_ConeConstraint(const FConeConstraint& Value) { Write<FConeConstraint>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x20, Type: StructProperty)
    void SET_TwistConstraint(const FTwistConstraint& Value) { Write<FTwistConstraint>(uintptr_t(this) + 0x11c, Value); } // 0x11c (Size: 0x1c, Type: StructProperty)
    void SET_bDisableCollision(const bool& Value) { Write<bool>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x1, Type: BoolProperty)
    void SET_LinearProjectionAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x13c, Value); } // 0x13c (Size: 0x4, Type: FloatProperty)
    void SET_AngularProjectionAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x4, Type: FloatProperty)
    void SET_ParentInverseMassScale(const float& Value) { Write<float>(uintptr_t(this) + 0x144, Value); } // 0x144 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x290
struct FRigPhysicsJointComponent : public FRigBaseComponent
{
public:
    FRigComponentKey ParentBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0xc, Type: StructProperty)
    FRigComponentKey ChildBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0xc, Type: StructProperty)
    FRigPhysicsJointData JointData() const { return Read<FRigPhysicsJointData>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x150, Type: StructProperty)
    FRigPhysicsDriveData DriveData() const { return Read<FRigPhysicsDriveData>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0xd8, Type: StructProperty)

    void SET_ParentBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0xc, Type: StructProperty)
    void SET_ChildBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0xc, Type: StructProperty)
    void SET_JointData(const FRigPhysicsJointData& Value) { Write<FRigPhysicsJointData>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x150, Type: StructProperty)
    void SET_DriveData(const FRigPhysicsDriveData& Value) { Write<FRigPhysicsDriveData>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0xd8, Type: StructProperty)
};

// Size: 0x150
struct FRigBodyRecord
{
public:
};

// Size: 0x70
struct FRigJointRecord
{
public:
};

// Size: 0x90
struct FRigControlRecord
{
public:
};

// Size: 0x4a0
struct FRigPhysicsSimulation : public FRigPhysicsSimulationBase
{
public:
};

// Size: 0x178
struct FRigPhysicsSolverComponent : public FRigBaseComponent
{
public:
    FRigPhysicsSolverSettings SolverSettings() const { return Read<FRigPhysicsSolverSettings>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0xa8, Type: StructProperty)
    FRigPhysicsSimulationSpaceSettings SimulationSpaceSettings() const { return Read<FRigPhysicsSimulationSpaceSettings>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x88, Type: StructProperty)

    void SET_SolverSettings(const FRigPhysicsSolverSettings& Value) { Write<FRigPhysicsSolverSettings>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0xa8, Type: StructProperty)
    void SET_SimulationSpaceSettings(const FRigPhysicsSimulationSpaceSettings& Value) { Write<FRigPhysicsSimulationSpaceSettings>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x88, Type: StructProperty)
};

// Size: 0x10
struct FRigUnit_PhysicsBaseMutable : public FRigUnitMutable
{
public:
};

// Size: 0xe8
struct FRigUnit_AddPhysicsBody : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigElementKey Owner() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FRigComponentKey PhysicsBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0xc, Type: StructProperty)
    FRigPhysicsBodySolverSettings Solver() const { return Read<FRigPhysicsBodySolverSettings>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x20, Type: StructProperty)
    FRigPhysicsDynamics Dynamics() const { return Read<FRigPhysicsDynamics>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x50, Type: StructProperty)
    FRigPhysicsCollision Collision() const { return Read<FRigPhysicsCollision>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x40, Type: StructProperty)
    FPhysicsControlModifierData BodyData() const { return Read<FPhysicsControlModifierData>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: StructProperty)

    void SET_Owner(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_PhysicsBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0xc, Type: StructProperty)
    void SET_Solver(const FRigPhysicsBodySolverSettings& Value) { Write<FRigPhysicsBodySolverSettings>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x20, Type: StructProperty)
    void SET_Dynamics(const FRigPhysicsDynamics& Value) { Write<FRigPhysicsDynamics>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x50, Type: StructProperty)
    void SET_Collision(const FRigPhysicsCollision& Value) { Write<FRigPhysicsCollision>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x40, Type: StructProperty)
    void SET_BodyData(const FPhysicsControlModifierData& Value) { Write<FPhysicsControlModifierData>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x28
struct FRigUnit_HierarchyAutoCalculateCollision : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    float MinAspectRatio() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float MinSize() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)

    void SET_PhysicsBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_MinAspectRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_MinSize(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x70
struct FRigUnit_HierarchySetDynamics : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    FRigPhysicsDynamics Dynamics() const { return Read<FRigPhysicsDynamics>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x50, Type: StructProperty)

    void SET_PhysicsBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_Dynamics(const FRigPhysicsDynamics& Value) { Write<FRigPhysicsDynamics>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x50, Type: StructProperty)
};

// Size: 0x60
struct FRigUnit_HierarchySetCollision : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    FRigPhysicsCollision Collision() const { return Read<FRigPhysicsCollision>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x40, Type: StructProperty)

    void SET_PhysicsBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_Collision(const FRigPhysicsCollision& Value) { Write<FRigPhysicsCollision>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x40, Type: StructProperty)
};

// Size: 0x28
struct FRigUnit_HierarchyDisableCollisionBetween : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsBodyComponentKey1() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    FRigComponentKey PhysicsBodyComponentKey2() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0xc, Type: StructProperty)

    void SET_PhysicsBodyComponentKey1(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_PhysicsBodyComponentKey2(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0xc, Type: StructProperty)
};

// Size: 0x28
struct FRigUnit_HierarchySetPhysicsBodySourceBone : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    FRigElementKey SourceBone() const { return Read<FRigElementKey>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x8, Type: StructProperty)

    void SET_PhysicsBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_SourceBone(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x8, Type: StructProperty)
};

// Size: 0x28
struct FRigUnit_HierarchySetPhysicsBodyTargetBone : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    FRigElementKey TargetBone() const { return Read<FRigElementKey>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x8, Type: StructProperty)

    void SET_PhysicsBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_TargetBone(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x8, Type: StructProperty)
};

// Size: 0x30
struct FRigUnit_HierarchySetPhysicsBodySparseData : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    FPhysicsControlModifierSparseData Data() const { return Read<FPhysicsControlModifierSparseData>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x10, Type: StructProperty)

    void SET_PhysicsBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_Data(const FPhysicsControlModifierSparseData& Value) { Write<FPhysicsControlModifierSparseData>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x10, Type: StructProperty)
};

// Size: 0x80
struct FRigUnit_HierarchySetPhysicsBodyKinematicTarget : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    uint8_t KinematicTargetSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: EnumProperty)
    FTransform KinematicTarget() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)

    void SET_PhysicsBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_KinematicTargetSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: EnumProperty)
    void SET_KinematicTarget(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
};

// Size: 0x20
struct FRigUnit_HierarchySetPhysicsBodyMovementType : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    uint8_t MovementType() const { return Read<uint8_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: EnumProperty)

    void SET_PhysicsBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_MovementType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: EnumProperty)
};

// Size: 0x20
struct FRigUnit_HierarchySetPhysicsBodyCollisionType : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    TEnumAsByte<ECollisionEnabled> CollisionType() const { return Read<TEnumAsByte<ECollisionEnabled>>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: ByteProperty)

    void SET_PhysicsBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_CollisionType(const TEnumAsByte<ECollisionEnabled>& Value) { Write<TEnumAsByte<ECollisionEnabled>>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: ByteProperty)
};

// Size: 0x20
struct FRigUnit_HierarchySetPhysicsBodyGravityMultiplier : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    float GravityMultiplier() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)

    void SET_PhysicsBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_GravityMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FRigUnit_HierarchySetPhysicsBodyPhysicsBlendWeight : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    float PhysicsBlendWeight() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)

    void SET_PhysicsBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_PhysicsBlendWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FRigUnit_HierarchySetPhysicsBodyUseSkeletalAnimation : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    bool bUseSkeletalAnimation() const { return Read<bool>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: BoolProperty)

    void SET_PhysicsBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_bUseSkeletalAnimation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FRigUnit_HierarchySetPhysicsBodyUpdateKinematicFromSimulation : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    bool bUpdateKinematicFromSimulation() const { return Read<bool>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: BoolProperty)

    void SET_PhysicsBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_bUpdateKinematicFromSimulation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FRigUnit_HierarchySetPhysicsBodyDamping : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    float LinearDamping() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float AngularDamping() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)

    void SET_PhysicsBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_LinearDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_AngularDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x168
struct FRigUnit_AddPhysicsControl : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigElementKey Owner() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FRigComponentKey ControlComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0xc, Type: StructProperty)
    FRigComponentKey ParentBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0xc, Type: StructProperty)
    FRigComponentKey ChildBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0xc, Type: StructProperty)
    FPhysicsControlData ControlData() const { return Read<FPhysicsControlData>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x50, Type: StructProperty)
    FPhysicsControlMultiplier ControlMultiplier() const { return Read<FPhysicsControlMultiplier>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x70, Type: StructProperty)
    FPhysicsControlTarget ControlTarget() const { return Read<FPhysicsControlTarget>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x68, Type: StructProperty)

    void SET_Owner(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_ControlComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0xc, Type: StructProperty)
    void SET_ParentBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0xc, Type: StructProperty)
    void SET_ChildBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0xc, Type: StructProperty)
    void SET_ControlData(const FPhysicsControlData& Value) { Write<FPhysicsControlData>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x50, Type: StructProperty)
    void SET_ControlMultiplier(const FPhysicsControlMultiplier& Value) { Write<FPhysicsControlMultiplier>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x70, Type: StructProperty)
    void SET_ControlTarget(const FPhysicsControlTarget& Value) { Write<FPhysicsControlTarget>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x68, Type: StructProperty)
};

// Size: 0x70
struct FRigUnit_HierarchySetControlData : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsControlComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    FPhysicsControlData ControlData() const { return Read<FPhysicsControlData>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x50, Type: StructProperty)

    void SET_PhysicsControlComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_ControlData(const FPhysicsControlData& Value) { Write<FPhysicsControlData>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x50, Type: StructProperty)
};

// Size: 0x88
struct FRigUnit_HierarchySetControlTarget : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsControlComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    FPhysicsControlTarget ControlTarget() const { return Read<FPhysicsControlTarget>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x68, Type: StructProperty)

    void SET_PhysicsControlComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_ControlTarget(const FPhysicsControlTarget& Value) { Write<FPhysicsControlTarget>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x68, Type: StructProperty)
};

// Size: 0x90
struct FRigUnit_HierarchySetControlMultiplier : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsControlComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    FPhysicsControlMultiplier ControlMultiplier() const { return Read<FPhysicsControlMultiplier>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x70, Type: StructProperty)

    void SET_PhysicsControlComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_ControlMultiplier(const FPhysicsControlMultiplier& Value) { Write<FPhysicsControlMultiplier>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x70, Type: StructProperty)
};

// Size: 0x8
struct FRigUnit_PhysicsBase : public FRigUnit
{
public:
};

// Size: 0x158
struct FRigUnit_AddPhysicsSolver : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigElementKey Owner() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FRigComponentKey PhysicsSolverComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0xc, Type: StructProperty)
    FRigPhysicsSolverSettings SolverSettings() const { return Read<FRigPhysicsSolverSettings>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0xa8, Type: StructProperty)
    FRigPhysicsSimulationSpaceSettings SimulationSpaceSettings() const { return Read<FRigPhysicsSimulationSpaceSettings>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x88, Type: StructProperty)

    void SET_Owner(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_PhysicsSolverComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0xc, Type: StructProperty)
    void SET_SolverSettings(const FRigPhysicsSolverSettings& Value) { Write<FRigPhysicsSolverSettings>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0xa8, Type: StructProperty)
    void SET_SimulationSpaceSettings(const FRigPhysicsSimulationSpaceSettings& Value) { Write<FRigPhysicsSimulationSpaceSettings>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x88, Type: StructProperty)
};

// Size: 0x20
struct FRigUnit_InstantiatePhysics : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsSolverComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)

    void SET_PhysicsSolverComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_StepPhysicsSolver : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsSolverComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    float DeltaTimeOverride() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float SimulationSpaceDeltaTimeOverride() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float Alpha() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    FRigPhysicsVisualizationSettings VisualizationSettings() const { return Read<FRigPhysicsVisualizationSettings>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x14, Type: StructProperty)

    void SET_PhysicsSolverComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_DeltaTimeOverride(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_SimulationSpaceDeltaTimeOverride(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_Alpha(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_VisualizationSettings(const FRigPhysicsVisualizationSettings& Value) { Write<FRigPhysicsVisualizationSettings>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x14, Type: StructProperty)
};

// Size: 0x28
struct FRigUnit_TrackInputPose : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsSolverComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    int32_t NumberOfFrames() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    bool bForceNumberOfFrames() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_PhysicsSolverComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_NumberOfFrames(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_bForceNumberOfFrames(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x3e0
struct FRigUnit_AddPhysicsComponents : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigElementKey Owner() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    bool bAddJoint() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    bool bAddSimSpaceControl() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    bool bAddParentSpaceControl() const { return Read<bool>(uintptr_t(this) + 0x1a); } // 0x1a (Size: 0x1, Type: BoolProperty)
    FRigComponentKey PhysicsBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0xc, Type: StructProperty)
    FRigComponentKey PhysicsJointComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0xc, Type: StructProperty)
    FRigComponentKey SimSpaceControlComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0xc, Type: StructProperty)
    FRigComponentKey ParentSpaceControlComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0xc, Type: StructProperty)
    FRigPhysicsBodySolverSettings Solver() const { return Read<FRigPhysicsBodySolverSettings>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x20, Type: StructProperty)
    FRigPhysicsDynamics Dynamics() const { return Read<FRigPhysicsDynamics>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x50, Type: StructProperty)
    FRigPhysicsCollision Collision() const { return Read<FRigPhysicsCollision>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x40, Type: StructProperty)
    FPhysicsControlModifierData BodyData() const { return Read<FPhysicsControlModifierData>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: StructProperty)
    FRigPhysicsJointData JointData() const { return Read<FRigPhysicsJointData>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x150, Type: StructProperty)
    FRigPhysicsDriveData DriveData() const { return Read<FRigPhysicsDriveData>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0xd8, Type: StructProperty)
    FPhysicsControlData SimSpaceControlData() const { return Read<FPhysicsControlData>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x50, Type: StructProperty)
    FPhysicsControlData ParentSpaceControlData() const { return Read<FPhysicsControlData>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x50, Type: StructProperty)

    void SET_Owner(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_bAddJoint(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_bAddSimSpaceControl(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET_bAddParentSpaceControl(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1a, Value); } // 0x1a (Size: 0x1, Type: BoolProperty)
    void SET_PhysicsBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0xc, Type: StructProperty)
    void SET_PhysicsJointComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0xc, Type: StructProperty)
    void SET_SimSpaceControlComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0xc, Type: StructProperty)
    void SET_ParentSpaceControlComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0xc, Type: StructProperty)
    void SET_Solver(const FRigPhysicsBodySolverSettings& Value) { Write<FRigPhysicsBodySolverSettings>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x20, Type: StructProperty)
    void SET_Dynamics(const FRigPhysicsDynamics& Value) { Write<FRigPhysicsDynamics>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x50, Type: StructProperty)
    void SET_Collision(const FRigPhysicsCollision& Value) { Write<FRigPhysicsCollision>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x40, Type: StructProperty)
    void SET_BodyData(const FPhysicsControlModifierData& Value) { Write<FPhysicsControlModifierData>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: StructProperty)
    void SET_JointData(const FRigPhysicsJointData& Value) { Write<FRigPhysicsJointData>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x150, Type: StructProperty)
    void SET_DriveData(const FRigPhysicsDriveData& Value) { Write<FRigPhysicsDriveData>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0xd8, Type: StructProperty)
    void SET_SimSpaceControlData(const FPhysicsControlData& Value) { Write<FPhysicsControlData>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x50, Type: StructProperty)
    void SET_ParentSpaceControlData(const FPhysicsControlData& Value) { Write<FPhysicsControlData>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x50, Type: StructProperty)
};

// Size: 0x138
struct FRigUnit_HierarchyInstantiateFromPhysicsAsset : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigPhysicsBodySolverSettings Solver() const { return Read<FRigPhysicsBodySolverSettings>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    UPhysicsAsset* PhysicsAsset() const { return Read<UPhysicsAsset*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    FName ConstraintProfileName() const { return Read<FName>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: NameProperty)
    TArray<FRigElementKey> BonesToUse() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    bool bEnableJoints() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    bool bEnableDrives() const { return Read<bool>(uintptr_t(this) + 0x51); } // 0x51 (Size: 0x1, Type: BoolProperty)
    bool bAddSimSpaceControl() const { return Read<bool>(uintptr_t(this) + 0x52); } // 0x52 (Size: 0x1, Type: BoolProperty)
    bool bAddParentSpaceControl() const { return Read<bool>(uintptr_t(this) + 0x53); } // 0x53 (Size: 0x1, Type: BoolProperty)
    FPhysicsControlData SimSpaceControlData() const { return Read<FPhysicsControlData>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x50, Type: StructProperty)
    FPhysicsControlData ParentSpaceControlData() const { return Read<FPhysicsControlData>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x50, Type: StructProperty)
    TArray<FRigComponentKey> PhysicsBodyComponentKeys() const { return Read<TArray<FRigComponentKey>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigComponentKey> PhysicsJointComponentKeys() const { return Read<TArray<FRigComponentKey>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigComponentKey> SimSpaceControlComponentKeys() const { return Read<TArray<FRigComponentKey>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigComponentKey> ParentSpaceControlComponentKeys() const { return Read<TArray<FRigComponentKey>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x10, Type: ArrayProperty)

    void SET_Solver(const FRigPhysicsBodySolverSettings& Value) { Write<FRigPhysicsBodySolverSettings>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_PhysicsAsset(const UPhysicsAsset*& Value) { Write<UPhysicsAsset*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_ConstraintProfileName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: NameProperty)
    void SET_BonesToUse(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_bEnableJoints(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableDrives(const bool& Value) { Write<bool>(uintptr_t(this) + 0x51, Value); } // 0x51 (Size: 0x1, Type: BoolProperty)
    void SET_bAddSimSpaceControl(const bool& Value) { Write<bool>(uintptr_t(this) + 0x52, Value); } // 0x52 (Size: 0x1, Type: BoolProperty)
    void SET_bAddParentSpaceControl(const bool& Value) { Write<bool>(uintptr_t(this) + 0x53, Value); } // 0x53 (Size: 0x1, Type: BoolProperty)
    void SET_SimSpaceControlData(const FPhysicsControlData& Value) { Write<FPhysicsControlData>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x50, Type: StructProperty)
    void SET_ParentSpaceControlData(const FPhysicsControlData& Value) { Write<FPhysicsControlData>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x50, Type: StructProperty)
    void SET_PhysicsBodyComponentKeys(const TArray<FRigComponentKey>& Value) { Write<TArray<FRigComponentKey>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    void SET_PhysicsJointComponentKeys(const TArray<FRigComponentKey>& Value) { Write<TArray<FRigComponentKey>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    void SET_SimSpaceControlComponentKeys(const TArray<FRigComponentKey>& Value) { Write<TArray<FRigComponentKey>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x10, Type: ArrayProperty)
    void SET_ParentSpaceControlComponentKeys(const TArray<FRigComponentKey>& Value) { Write<TArray<FRigComponentKey>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x90
struct FRigUnit_GetPhysicsSolverSpaceData : public FRigUnit_PhysicsBase
{
public:
    FRigComponentKey PhysicsSolverComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0xc, Type: StructProperty)
    FVector LinearVelocity() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    FVector LinearAcceleration() const { return Read<FVector>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    FVector AngularAcceleration() const { return Read<FVector>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x18, Type: StructProperty)
    FVector Gravity() const { return Read<FVector>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x18, Type: StructProperty)

    void SET_PhysicsSolverComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0xc, Type: StructProperty)
    void SET_LinearVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_AngularVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_LinearAcceleration(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_AngularAcceleration(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x18, Type: StructProperty)
    void SET_Gravity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x18, Type: StructProperty)
};

// Size: 0x270
struct FRigUnit_AddPhysicsJoint : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigElementKey Owner() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FRigComponentKey PhysicsJointComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0xc, Type: StructProperty)
    FRigComponentKey ParentBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0xc, Type: StructProperty)
    FRigComponentKey ChildBodyComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0xc, Type: StructProperty)
    FRigPhysicsJointData JointData() const { return Read<FRigPhysicsJointData>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x150, Type: StructProperty)
    FRigPhysicsDriveData DriveData() const { return Read<FRigPhysicsDriveData>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0xd8, Type: StructProperty)

    void SET_Owner(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_PhysicsJointComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0xc, Type: StructProperty)
    void SET_ParentBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0xc, Type: StructProperty)
    void SET_ChildBodyComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0xc, Type: StructProperty)
    void SET_JointData(const FRigPhysicsJointData& Value) { Write<FRigPhysicsJointData>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x150, Type: StructProperty)
    void SET_DriveData(const FRigPhysicsDriveData& Value) { Write<FRigPhysicsDriveData>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0xd8, Type: StructProperty)
};

// Size: 0x170
struct FRigUnit_HierarchySetJointData : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsJointComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    FRigPhysicsJointData JointData() const { return Read<FRigPhysicsJointData>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x150, Type: StructProperty)

    void SET_PhysicsJointComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_JointData(const FRigPhysicsJointData& Value) { Write<FRigPhysicsJointData>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x150, Type: StructProperty)
};

// Size: 0xf8
struct FRigUnit_HierarchySetJointDriveData : public FRigUnit_PhysicsBaseMutable
{
public:
    FRigComponentKey PhysicsJointComponentKey() const { return Read<FRigComponentKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xc, Type: StructProperty)
    FRigPhysicsDriveData DriveData() const { return Read<FRigPhysicsDriveData>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0xd8, Type: StructProperty)

    void SET_PhysicsJointComponentKey(const FRigComponentKey& Value) { Write<FRigComponentKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xc, Type: StructProperty)
    void SET_DriveData(const FRigPhysicsDriveData& Value) { Write<FRigPhysicsDriveData>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0xd8, Type: StructProperty)
};

// Size: 0x1a0
struct FRigUnit_MakeArticulationJointData : public FRigUnit_PhysicsBase
{
public:
    FVector AngularLimit() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector SoftStrength() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector SoftDampingRatio() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    FRigPhysicsJointData JointData() const { return Read<FRigPhysicsJointData>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x150, Type: StructProperty)

    void SET_AngularLimit(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_SoftStrength(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_SoftDampingRatio(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_JointData(const FRigPhysicsJointData& Value) { Write<FRigPhysicsJointData>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x150, Type: StructProperty)
};

// Size: 0xf8
struct FRigUnit_MakeArticulationDriveData : public FRigUnit_PhysicsBase
{
public:
    bool bEnableAngularDrive() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EAngularDriveMode> AngularDriveMode() const { return Read<TEnumAsByte<EAngularDriveMode>>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: ByteProperty)
    float AngularStrength() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float AngularDampingRatio() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float AngularExtraDamping() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float SkeletalAnimationVelocityMultiplier() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    FRigPhysicsDriveData DriveData() const { return Read<FRigPhysicsDriveData>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0xd8, Type: StructProperty)

    void SET_bEnableAngularDrive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_AngularDriveMode(const TEnumAsByte<EAngularDriveMode>& Value) { Write<TEnumAsByte<EAngularDriveMode>>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: ByteProperty)
    void SET_AngularStrength(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_AngularDampingRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_AngularExtraDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_SkeletalAnimationVelocityMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_DriveData(const FRigPhysicsDriveData& Value) { Write<FRigPhysicsDriveData>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0xd8, Type: StructProperty)
};

// Size: 0x108
struct FRigUnit_MakeDriveData : public FRigUnit_PhysicsBase
{
public:
    bool bEnableLinearDrive() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    float LinearStrength() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float LinearDampingRatio() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float LinearExtraDamping() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    bool bEnableAngularDrive() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EAngularDriveMode> AngularDriveMode() const { return Read<TEnumAsByte<EAngularDriveMode>>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: ByteProperty)
    float AngularStrength() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float AngularDampingRatio() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float AngularExtraDamping() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float SkeletalAnimationVelocityMultiplier() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    FRigPhysicsDriveData DriveData() const { return Read<FRigPhysicsDriveData>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0xd8, Type: StructProperty)

    void SET_bEnableLinearDrive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_LinearStrength(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_LinearDampingRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_LinearExtraDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_bEnableAngularDrive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_AngularDriveMode(const TEnumAsByte<EAngularDriveMode>& Value) { Write<TEnumAsByte<EAngularDriveMode>>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: ByteProperty)
    void SET_AngularStrength(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_AngularDampingRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_AngularExtraDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_SkeletalAnimationVelocityMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_DriveData(const FRigPhysicsDriveData& Value) { Write<FRigPhysicsDriveData>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0xd8, Type: StructProperty)
};

