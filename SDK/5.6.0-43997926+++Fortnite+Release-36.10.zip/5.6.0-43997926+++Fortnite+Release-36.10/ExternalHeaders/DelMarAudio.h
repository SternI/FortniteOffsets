/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarAudio
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "DelMarCore.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "AudioModulation.h"

// Size: 0x28
class UDelMarAudioCheatManager : public UChildCheatManager
{
public:
};

// Size: 0x160
class UDelMarAudioPassbyComponent : public UDelMarAudioProximityComponent
{
public:
    USoundBase* PassBySound() const { return Read<USoundBase*>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* PassbyComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    float MinRelativeSpeed() const { return Read<float>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x4, Type: FloatProperty)
    float MinSpeedStopThresholdOffset() const { return Read<float>(uintptr_t(this) + 0x144); } // 0x144 (Size: 0x4, Type: FloatProperty)
    float PassbyStartRadiusMax() const { return Read<float>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x4, Type: FloatProperty)
    float PassbyStartRadiusMin() const { return Read<float>(uintptr_t(this) + 0x14c); } // 0x14c (Size: 0x4, Type: FloatProperty)
    float MinRelativeDirection() const { return Read<float>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x4, Type: FloatProperty)
    float PassbyCooldown() const { return Read<float>(uintptr_t(this) + 0x154); } // 0x154 (Size: 0x4, Type: FloatProperty)

    void SET_PassBySound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x8, Type: ObjectProperty)
    void SET_PassbyComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    void SET_MinRelativeSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x4, Type: FloatProperty)
    void SET_MinSpeedStopThresholdOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x144, Value); } // 0x144 (Size: 0x4, Type: FloatProperty)
    void SET_PassbyStartRadiusMax(const float& Value) { Write<float>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x4, Type: FloatProperty)
    void SET_PassbyStartRadiusMin(const float& Value) { Write<float>(uintptr_t(this) + 0x14c, Value); } // 0x14c (Size: 0x4, Type: FloatProperty)
    void SET_MinRelativeDirection(const float& Value) { Write<float>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x4, Type: FloatProperty)
    void SET_PassbyCooldown(const float& Value) { Write<float>(uintptr_t(this) + 0x154, Value); } // 0x154 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x110
class UDelMarAudioProximityComponent : public UDelMarAudioProximityComponentBase
{
public:
    USoundBase* ProximitySound() const { return Read<USoundBase*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* ProximityComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    float ObjectScaleAttenuationModifier() const { return Read<float>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: FloatProperty)
    float FadeOutDuration() const { return Read<float>(uintptr_t(this) + 0x104); } // 0x104 (Size: 0x4, Type: FloatProperty)

    void SET_ProximitySound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    void SET_ProximityComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    void SET_ObjectScaleAttenuationModifier(const float& Value) { Write<float>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: FloatProperty)
    void SET_FadeOutDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x104, Value); } // 0x104 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xf0
class UDelMarAudioProximityComponentBase : public UActorComponent
{
public:
    bool bProximityActive() const { return Read<bool>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x1, Type: BoolProperty)
    UDelMarAudioProximitySubsystem* Subsystem() const { return Read<UDelMarAudioProximitySubsystem*>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: ObjectProperty)

    void SET_bProximityActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x1, Type: BoolProperty)
    void SET_Subsystem(const UDelMarAudioProximitySubsystem*& Value) { Write<UDelMarAudioProximitySubsystem*>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xe0
class UDelMarAudioProximitySubsystem : public UTickableWorldSubsystem
{
public:
};

// Size: 0x50
class UDelMarAudioAudioCookSettings : public UObject
{
public:
    int32_t SoundWaveChannelThreshold() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    TArray<FString> PathsToScan() const { return Read<TArray<FString>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> PlatformQualitySettingsToExclude() const { return Read<TArray<FString>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_SoundWaveChannelThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_PathsToScan(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_PlatformQualitySettingsToExclude(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xf0
class UDelMarAudioStateMixerSubsystem : public UTickableWorldSubsystem
{
public:
    TArray<FDelMarStateMixCollection> AvailableMixes() const { return Read<TArray<FDelMarStateMixCollection>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    TMap<FDelMarStateMix, FGameplayTag> ActiveMixes() const { return Read<TMap<FDelMarStateMix, FGameplayTag>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x50, Type: MapProperty)
    TMap<FDelMarStateMix, FGameplayTag> TemporaryMixes() const { return Read<TMap<FDelMarStateMix, FGameplayTag>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x50, Type: MapProperty)

    void SET_AvailableMixes(const TArray<FDelMarStateMixCollection>& Value) { Write<TArray<FDelMarStateMixCollection>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_ActiveMixes(const TMap<FDelMarStateMix, FGameplayTag>& Value) { Write<TMap<FDelMarStateMix, FGameplayTag>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x50, Type: MapProperty)
    void SET_TemporaryMixes(const TMap<FDelMarStateMix, FGameplayTag>& Value) { Write<TMap<FDelMarStateMix, FGameplayTag>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x50, Type: MapProperty)
};

// Size: 0xc8
class UDelMarCrowdAudioManager : public UPlayspaceComponent
{
public:
    UDelMarAudioStatePlayspaceComponent* CachedStateComponent() const { return Read<UDelMarAudioStatePlayspaceComponent*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag RaceModeTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: StructProperty)

    void SET_CachedStateComponent(const UDelMarAudioStatePlayspaceComponent*& Value) { Write<UDelMarAudioStatePlayspaceComponent*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_RaceModeTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: StructProperty)
};

// Size: 0x190
class UDelMarRaceMusicManager : public UPlayspaceComponent
{
public:
    FGameplayTag RaceModeTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: StructProperty)
    USoundBase* MusicPlayer() const { return Read<USoundBase*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* MusicPlayer_LowSpec() const { return Read<USoundBase*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag MusicEventSystemTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: StructProperty)
    float FadeInDuration() const { return Read<float>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    float FadeOutDuration() const { return Read<float>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    float StartLineFadeOutDurtation() const { return Read<float>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x4, Type: FloatProperty)
    USoundBase* PreRaceMusic() const { return Read<USoundBase*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* PostRaceMusic() const { return Read<USoundBase*>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* MainMusicComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* StartLineComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UDelMarRaceMusicPlaylist> DefaultPlaylist() const { return Read<TSoftObjectPtr<UDelMarRaceMusicPlaylist>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x20, Type: SoftObjectProperty)
    UDelMarRaceMusicPlaylist* Playlist() const { return Read<UDelMarRaceMusicPlaylist*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    TArray<FDelMarMusicTrack> Songs() const { return Read<TArray<FDelMarMusicTrack>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x10, Type: ArrayProperty)
    FDelMarMusicTrack PlayingSong() const { return Read<FDelMarMusicTrack>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x20, Type: StructProperty)
    UDelMarAudioStatePlayspaceComponent* CachedStateComponent() const { return Read<UDelMarAudioStatePlayspaceComponent*>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x8, Type: ObjectProperty)

    void SET_RaceModeTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: StructProperty)
    void SET_MusicPlayer(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_MusicPlayer_LowSpec(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_MusicEventSystemTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: StructProperty)
    void SET_FadeInDuration(const float& Value) { Write<float>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    void SET_FadeOutDuration(const float& Value) { Write<float>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    void SET_StartLineFadeOutDurtation(const float& Value) { Write<float>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x4, Type: FloatProperty)
    void SET_PreRaceMusic(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
    void SET_PostRaceMusic(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    void SET_MainMusicComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x8, Type: ObjectProperty)
    void SET_StartLineComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultPlaylist(const TSoftObjectPtr<UDelMarRaceMusicPlaylist>& Value) { Write<TSoftObjectPtr<UDelMarRaceMusicPlaylist>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Playlist(const UDelMarRaceMusicPlaylist*& Value) { Write<UDelMarRaceMusicPlaylist*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    void SET_Songs(const TArray<FDelMarMusicTrack>& Value) { Write<TArray<FDelMarMusicTrack>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x10, Type: ArrayProperty)
    void SET_PlayingSong(const FDelMarMusicTrack& Value) { Write<FDelMarMusicTrack>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x20, Type: StructProperty)
    void SET_CachedStateComponent(const UDelMarAudioStatePlayspaceComponent*& Value) { Write<UDelMarAudioStatePlayspaceComponent*>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2c8
class ADelMarRaceMusicSettingsActor : public AActor
{
public:
    UDelMarRaceMusicPlaylist* Playlist() const { return Read<UDelMarRaceMusicPlaylist*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* PreRaceMusic() const { return Read<USoundBase*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* PostRaceMusic() const { return Read<USoundBase*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    bool bEnableMusic() const { return Read<bool>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x1, Type: BoolProperty)
    bool bEnableAudioAnalysis() const { return Read<bool>(uintptr_t(this) + 0x2c1); } // 0x2c1 (Size: 0x1, Type: BoolProperty)

    void SET_Playlist(const UDelMarRaceMusicPlaylist*& Value) { Write<UDelMarRaceMusicPlaylist*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_PreRaceMusic(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_PostRaceMusic(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_bEnableMusic(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableAudioAnalysis(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c1, Value); } // 0x2c1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1f8
class UDelMarAudioStatePlayspaceComponent : public UPlayspaceComponent
{
public:
    FName MixGroupName() const { return Read<FName>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x4, Type: NameProperty)
    TArray<FDelMarStateMix> Mixes() const { return Read<TArray<FDelMarStateMix>>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x10, Type: ArrayProperty)
    float CloseVehicleDistanceThreshold() const { return Read<float>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x4, Type: FloatProperty)
    int32_t CloseVehiclesPackRacingThreshold() const { return Read<int32_t>(uintptr_t(this) + 0x194); } // 0x194 (Size: 0x4, Type: IntProperty)
    USoundControlBus* UserMusicSettingBus() const { return Read<USoundControlBus*>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x8, Type: ObjectProperty)
    USoundControlBusMix* UserMusicMix() const { return Read<USoundControlBusMix*>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    UDelMarAudioStateMixerSubsystem* MixSubsystem() const { return Read<UDelMarAudioStateMixerSubsystem*>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    UDelMarVehicleManager* VehicleManager() const { return Read<UDelMarVehicleManager*>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)

    void SET_MixGroupName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x4, Type: NameProperty)
    void SET_Mixes(const TArray<FDelMarStateMix>& Value) { Write<TArray<FDelMarStateMix>>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x10, Type: ArrayProperty)
    void SET_CloseVehicleDistanceThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x4, Type: FloatProperty)
    void SET_CloseVehiclesPackRacingThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x194, Value); } // 0x194 (Size: 0x4, Type: IntProperty)
    void SET_UserMusicSettingBus(const USoundControlBus*& Value) { Write<USoundControlBus*>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x8, Type: ObjectProperty)
    void SET_UserMusicMix(const USoundControlBusMix*& Value) { Write<USoundControlBusMix*>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    void SET_MixSubsystem(const UDelMarAudioStateMixerSubsystem*& Value) { Write<UDelMarAudioStateMixerSubsystem*>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    void SET_VehicleManager(const UDelMarVehicleManager*& Value) { Write<UDelMarVehicleManager*>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xb8
class UDelMarAudioVirtualizationSubsystem : public UTickableWorldSubsystem
{
public:
    TMap<FDelmarAudioVirtualizationSettings, FGameplayTag> PlayerNumMap() const { return Read<TMap<FDelmarAudioVirtualizationSettings, FGameplayTag>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x50, Type: MapProperty)
    int32_t MaxNumPlayers() const { return Read<int32_t>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: IntProperty)
    int32_t MaxDistantPlayers() const { return Read<int32_t>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: IntProperty)
    int32_t DistantPlayerThreshold() const { return Read<int32_t>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: IntProperty)
    UDelMarVehicleManager* VehicleManager() const { return Read<UDelMarVehicleManager*>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x8, Type: ObjectProperty)

    void SET_PlayerNumMap(const TMap<FDelmarAudioVirtualizationSettings, FGameplayTag>& Value) { Write<TMap<FDelmarAudioVirtualizationSettings, FGameplayTag>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x50, Type: MapProperty)
    void SET_MaxNumPlayers(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: IntProperty)
    void SET_MaxDistantPlayers(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: IntProperty)
    void SET_DistantPlayerThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: IntProperty)
    void SET_VehicleManager(const UDelMarVehicleManager*& Value) { Write<UDelMarVehicleManager*>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x38
struct FDelMarStateMix
{
public:
    FGameplayTag MixStateTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FAudioMixModifierGroup ActorMixModifiers() const { return Read<FAudioMixModifierGroup>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    USoundControlBusMix* ControlBusMix() const { return Read<USoundControlBusMix*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    bool bAutoDeactivate() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    float duration() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    FGameplayTag FallbackState() const { return Read<FGameplayTag>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: StructProperty)

    void SET_MixStateTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_ActorMixModifiers(const FAudioMixModifierGroup& Value) { Write<FAudioMixModifierGroup>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_ControlBusMix(const USoundControlBusMix*& Value) { Write<USoundControlBusMix*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    void SET_bAutoDeactivate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_duration(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_FallbackState(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: StructProperty)
};

// Size: 0x18
struct FDelMarStateMixCollection
{
public:
    FName Group() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    TArray<FDelMarStateMix> Mixes() const { return Read<TArray<FDelMarStateMix>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Group(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Mixes(const TArray<FDelMarStateMix>& Value) { Write<TArray<FDelMarStateMix>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FDelMarEvent_AudioStateComponent
{
public:
    UDelMarAudioStatePlayspaceComponent* StateComponent() const { return Read<UDelMarAudioStatePlayspaceComponent*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_StateComponent(const UDelMarAudioStatePlayspaceComponent*& Value) { Write<UDelMarAudioStatePlayspaceComponent*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc
struct FDelmarAudioVirtualizationSettings
{
public:
    int32_t MaxNumPlayers() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t MaxNumDistantPlayers() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    float DistantPlayerThreshold() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_MaxNumPlayers(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_MaxNumDistantPlayers(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_DistantPlayerThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

