/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Effects
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"
#include "FortniteGame.h"
#include "Niagara.h"
#include "FieldSystemEngine.h"

// Size: 0x44
struct FStruc_NiagaraParameters
{
public:
    TEnumAsByte<ENUM_NiagaraParameterSetup> ParameterSelection_14_A6D4854946F722970AD7D0AEC96E4705() const { return Read<TEnumAsByte<ENUM_NiagaraParameterSetup>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    FName FloatParameterName_17_6AFBA48F43B44BD1ED9841983BEFA202() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    float FloatParameterValue_28_AC98B6464E1CD803B50B47AEC91741EC() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    FName VectorParameterName_20_71917CFB490B3D5D3E0864A3EE90C666() const { return Read<FName>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: NameProperty)
    FVector VectorParameterValue_27_248856604659F589FF5D4FA5FF52E013() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FName LinearColorparameterName_22_69C61F8D45C74F98203920856CAD5ADE() const { return Read<FName>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: NameProperty)
    FLinearColor LinearColorParameterValue_29_861B08ED408F0F612BF509A2A94F377F() const { return Read<FLinearColor>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x10, Type: StructProperty)
    FName IntegerParameterName_24_98306BA7452D90289F6EE9954C4F2B1D() const { return Read<FName>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: NameProperty)
    int32_t IntegerParameterValue_25_BB84ADEA4515AABD3B9AC6A04453D826() const { return Read<int32_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: IntProperty)

    void SET_ParameterSelection_14_A6D4854946F722970AD7D0AEC96E4705(const TEnumAsByte<ENUM_NiagaraParameterSetup>& Value) { Write<TEnumAsByte<ENUM_NiagaraParameterSetup>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_FloatParameterName_17_6AFBA48F43B44BD1ED9841983BEFA202(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_FloatParameterValue_28_AC98B6464E1CD803B50B47AEC91741EC(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_VectorParameterName_20_71917CFB490B3D5D3E0864A3EE90C666(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: NameProperty)
    void SET_VectorParameterValue_27_248856604659F589FF5D4FA5FF52E013(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_LinearColorparameterName_22_69C61F8D45C74F98203920856CAD5ADE(const FName& Value) { Write<FName>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: NameProperty)
    void SET_LinearColorParameterValue_29_861B08ED408F0F612BF509A2A94F377F(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x10, Type: StructProperty)
    void SET_IntegerParameterName_24_98306BA7452D90289F6EE9954C4F2B1D(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: NameProperty)
    void SET_IntegerParameterValue_25_BB84ADEA4515AABD3B9AC6A04453D826(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: IntProperty)
};

// Size: 0x390
class ABP_SpeedLines_Looping_Camera_Lens_Vehicle_C : public AEmitterCameraLensEffectBase
{
public:
};

// Size: 0xd6
class UFN_NiagaraNotify_C : public UAnimNotify_PlayNiagaraEffect
{
public:
    bool Set_in_Water_Niagara_Variable() const { return Read<bool>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    bool Print_Debug() const { return Read<bool>(uintptr_t(this) + 0xd1); } // 0xd1 (Size: 0x1, Type: BoolProperty)
    bool is_Glider_Deploy_Notify() const { return Read<bool>(uintptr_t(this) + 0xd2); } // 0xd2 (Size: 0x1, Type: BoolProperty)
    bool IsLargeBodyPawn() const { return Read<bool>(uintptr_t(this) + 0xd3); } // 0xd3 (Size: 0x1, Type: BoolProperty)
    bool Include_in_Pawn_Highlight_Set() const { return Read<bool>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x1, Type: BoolProperty)
    bool Absolute_Rotation() const { return Read<bool>(uintptr_t(this) + 0xd5); } // 0xd5 (Size: 0x1, Type: BoolProperty)

    void SET_Set_in_Water_Niagara_Variable(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    void SET_Print_Debug(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd1, Value); } // 0xd1 (Size: 0x1, Type: BoolProperty)
    void SET_is_Glider_Deploy_Notify(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd2, Value); } // 0xd2 (Size: 0x1, Type: BoolProperty)
    void SET_IsLargeBodyPawn(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd3, Value); } // 0xd3 (Size: 0x1, Type: BoolProperty)
    void SET_Include_in_Pawn_Highlight_Set(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x1, Type: BoolProperty)
    void SET_Absolute_Rotation(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd5, Value); } // 0xd5 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class USSI_BpLib_BpTools_C : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x5bc
class AB_Pickups_Parent_C : public AFortPickupsParent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: StructProperty)
    USceneComponent* Root() const { return Read<USceneComponent*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    float MobileSelectedTL_LerpInteactoIcon_FF208F9641BE589B76EF698B94309EA7() const { return Read<float>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x4, Type: FloatProperty)
    float MobileSelectedTL_LerpObject_FF208F9641BE589B76EF698B94309EA7() const { return Read<float>(uintptr_t(this) + 0x48c); } // 0x48c (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> MobileSelectedTL__Direction_FF208F9641BE589B76EF698B94309EA7() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* MobileSelectedTL() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* Static_Mesh_Pickup() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* Skeletal_Mesh_Pickup() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    UPrimitiveComponent* SkeletalOrStaticMeshAssetPrimitive() const { return Read<UPrimitiveComponent*>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    int32_t CurrentElementIndex() const { return Read<int32_t>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x4, Type: IntProperty)
    double Component_Radius__Scaled_() const { return Read<double>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x8, Type: DoubleProperty)
    double Component_Radius_Multiplier() const { return Read<double>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x8, Type: DoubleProperty)
    TArray<FLinearColor> Outline_Rarity_Colors() const { return Read<TArray<FLinearColor>>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x10, Type: ArrayProperty)
    double Component_Radius() const { return Read<double>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x8, Type: DoubleProperty)
    UParticleSystem* Picked_Up_Trail_PS_Old() const { return Read<UParticleSystem*>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    TArray<double> Sparkle_Spawn_Rate__Picked_Up_() const { return Read<TArray<double>>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x10, Type: ArrayProperty)
    TArray<double> Lifetime__Picked_Up_() const { return Read<TArray<double>>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x10, Type: ArrayProperty)
    UForceFeedbackEffect* PickupForceFeedback_Old() const { return Read<UForceFeedbackEffect*>(uintptr_t(this) + 0x510); } // 0x510 (Size: 0x8, Type: ObjectProperty)
    bool HasUniqueMaterialIds() const { return Read<bool>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x1, Type: BoolProperty)
    TArray<FLinearColor> BackgroundRarityColors() const { return Read<TArray<FLinearColor>>(uintptr_t(this) + 0x520); } // 0x520 (Size: 0x10, Type: ArrayProperty)
    double Random_Rotation() const { return Read<double>(uintptr_t(this) + 0x530); } // 0x530 (Size: 0x8, Type: DoubleProperty)
    FVector MobileSelectedOffset() const { return Read<FVector>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x18, Type: StructProperty)
    FVector MobileSelectedScale() const { return Read<FVector>(uintptr_t(this) + 0x550); } // 0x550 (Size: 0x18, Type: StructProperty)
    UStaticMeshComponent* MobileInteractIcon() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x8, Type: ObjectProperty)
    FVector MobileInteractIconLocation() const { return Read<FVector>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x18, Type: StructProperty)
    FVector MobileInteractIconScale() const { return Read<FVector>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x18, Type: StructProperty)
    UMaterialInterface* MobileInteractionMaterial() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    bool PickedUp() const { return Read<bool>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x1, Type: BoolProperty)
    FLinearColor MissionItemOutlineColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x5ac); } // 0x5ac (Size: 0x10, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: StructProperty)
    void SET_Root(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_MobileSelectedTL_LerpInteactoIcon_FF208F9641BE589B76EF698B94309EA7(const float& Value) { Write<float>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x4, Type: FloatProperty)
    void SET_MobileSelectedTL_LerpObject_FF208F9641BE589B76EF698B94309EA7(const float& Value) { Write<float>(uintptr_t(this) + 0x48c, Value); } // 0x48c (Size: 0x4, Type: FloatProperty)
    void SET_MobileSelectedTL__Direction_FF208F9641BE589B76EF698B94309EA7(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x1, Type: ByteProperty)
    void SET_MobileSelectedTL(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    void SET_Static_Mesh_Pickup(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Skeletal_Mesh_Pickup(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    void SET_SkeletalOrStaticMeshAssetPrimitive(const UPrimitiveComponent*& Value) { Write<UPrimitiveComponent*>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentElementIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x4, Type: IntProperty)
    void SET_Component_Radius__Scaled_(const double& Value) { Write<double>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x8, Type: DoubleProperty)
    void SET_Component_Radius_Multiplier(const double& Value) { Write<double>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x8, Type: DoubleProperty)
    void SET_Outline_Rarity_Colors(const TArray<FLinearColor>& Value) { Write<TArray<FLinearColor>>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x10, Type: ArrayProperty)
    void SET_Component_Radius(const double& Value) { Write<double>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x8, Type: DoubleProperty)
    void SET_Picked_Up_Trail_PS_Old(const UParticleSystem*& Value) { Write<UParticleSystem*>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    void SET_Sparkle_Spawn_Rate__Picked_Up_(const TArray<double>& Value) { Write<TArray<double>>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x10, Type: ArrayProperty)
    void SET_Lifetime__Picked_Up_(const TArray<double>& Value) { Write<TArray<double>>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x10, Type: ArrayProperty)
    void SET_PickupForceFeedback_Old(const UForceFeedbackEffect*& Value) { Write<UForceFeedbackEffect*>(uintptr_t(this) + 0x510, Value); } // 0x510 (Size: 0x8, Type: ObjectProperty)
    void SET_HasUniqueMaterialIds(const bool& Value) { Write<bool>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x1, Type: BoolProperty)
    void SET_BackgroundRarityColors(const TArray<FLinearColor>& Value) { Write<TArray<FLinearColor>>(uintptr_t(this) + 0x520, Value); } // 0x520 (Size: 0x10, Type: ArrayProperty)
    void SET_Random_Rotation(const double& Value) { Write<double>(uintptr_t(this) + 0x530, Value); } // 0x530 (Size: 0x8, Type: DoubleProperty)
    void SET_MobileSelectedOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x18, Type: StructProperty)
    void SET_MobileSelectedScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x550, Value); } // 0x550 (Size: 0x18, Type: StructProperty)
    void SET_MobileInteractIcon(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x8, Type: ObjectProperty)
    void SET_MobileInteractIconLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x18, Type: StructProperty)
    void SET_MobileInteractIconScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x18, Type: StructProperty)
    void SET_MobileInteractionMaterial(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    void SET_PickedUp(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x1, Type: BoolProperty)
    void SET_MissionItemOutlineColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x5ac, Value); } // 0x5ac (Size: 0x10, Type: StructProperty)
};

// Size: 0x1f0
class UBP_Camera_Shake_Pulse_Zoom_C : public ULegacyCameraShake
{
public:
};

// Size: 0x1f0
class UBP_Camera_Shake_Pulse_Flash_C : public ULegacyCameraShake
{
public:
};

// Size: 0x398
class AB_CameraLens_Shadow_Bomb_End_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: StructProperty)
};

// Size: 0x398
class AB_CameraLens_Shadow_Bomb_Loop_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: StructProperty)
};

// Size: 0x398
class AB_CameraLens_Drown_Damage_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: StructProperty)
};

// Size: 0xc2
class UFN_TimedNiagaraNotify_C : public UFortAnimNotifyState_TimedNiagaraEffectVariant
{
public:
    bool Print_Debug() const { return Read<bool>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: BoolProperty)
    bool is_Glider_Deploy_Notify() const { return Read<bool>(uintptr_t(this) + 0xa1); } // 0xa1 (Size: 0x1, Type: BoolProperty)
    bool Set_in_Water_Niagara_Variable() const { return Read<bool>(uintptr_t(this) + 0xa2); } // 0xa2 (Size: 0x1, Type: BoolProperty)
    TArray<FAnimCurveParameterPair> AnimCurveParameterPair() const { return Read<TArray<FAnimCurveParameterPair>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    bool IsLargeBodyPawn() const { return Read<bool>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    bool Absolute_Scale() const { return Read<bool>(uintptr_t(this) + 0xb9); } // 0xb9 (Size: 0x1, Type: BoolProperty)
    bool Cast_Shadow() const { return Read<bool>(uintptr_t(this) + 0xba); } // 0xba (Size: 0x1, Type: BoolProperty)
    float Translucency_Sort_Distance_Offset() const { return Read<float>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: FloatProperty)
    bool Absolute_Rotation() const { return Read<bool>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    bool Set_Niagara_OwnerLocalVelocity() const { return Read<bool>(uintptr_t(this) + 0xc1); } // 0xc1 (Size: 0x1, Type: BoolProperty)

    void SET_Print_Debug(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: BoolProperty)
    void SET_is_Glider_Deploy_Notify(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa1, Value); } // 0xa1 (Size: 0x1, Type: BoolProperty)
    void SET_Set_in_Water_Niagara_Variable(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa2, Value); } // 0xa2 (Size: 0x1, Type: BoolProperty)
    void SET_AnimCurveParameterPair(const TArray<FAnimCurveParameterPair>& Value) { Write<TArray<FAnimCurveParameterPair>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: ArrayProperty)
    void SET_IsLargeBodyPawn(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    void SET_Absolute_Scale(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb9, Value); } // 0xb9 (Size: 0x1, Type: BoolProperty)
    void SET_Cast_Shadow(const bool& Value) { Write<bool>(uintptr_t(this) + 0xba, Value); } // 0xba (Size: 0x1, Type: BoolProperty)
    void SET_Translucency_Sort_Distance_Offset(const float& Value) { Write<float>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: FloatProperty)
    void SET_Absolute_Rotation(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    void SET_Set_Niagara_OwnerLocalVelocity(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc1, Value); } // 0xc1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x390
class AB_CameraLens_Victory_Direct_C : public AEmitterCameraLensEffectBase
{
public:
};

// Size: 0x390
class AB_CameraLens_Victory_Ally_C : public AEmitterCameraLensEffectBase
{
public:
};

// Size: 0x1f0
class UBP_Camera_Shake_Pulse_Only_C : public ULegacyCameraShake
{
public:
};

// Size: 0x848
class AB_SoundIndicator_01_C : public AFortSoundCameraLensEffect
{
public:
    FRuntimeFloatCurve Gunshot_Falloff_Long_Range() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve Chest_Falloff() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve Footsteps_Falloff() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve Gunshot_Falloff_Mid_Range() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x628); } // 0x628 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve Gunshot_Falloff_Melee() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x6b0); } // 0x6b0 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve Glider_Falloff() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x738); } // 0x738 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve Plane_Falloff() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x7c0); } // 0x7c0 (Size: 0x88, Type: StructProperty)

    void SET_Gunshot_Falloff_Long_Range(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x88, Type: StructProperty)
    void SET_Chest_Falloff(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x88, Type: StructProperty)
    void SET_Footsteps_Falloff(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x88, Type: StructProperty)
    void SET_Gunshot_Falloff_Mid_Range(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x628, Value); } // 0x628 (Size: 0x88, Type: StructProperty)
    void SET_Gunshot_Falloff_Melee(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x6b0, Value); } // 0x6b0 (Size: 0x88, Type: StructProperty)
    void SET_Glider_Falloff(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x738, Value); } // 0x738 (Size: 0x88, Type: StructProperty)
    void SET_Plane_Falloff(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x7c0, Value); } // 0x7c0 (Size: 0x88, Type: StructProperty)
};

// Size: 0x3d0
class AB_PlayerShieldDamage_LensEffect_Direction_C : public AFortEmitterCameraLensEffectDirectional
{
public:
};

// Size: 0x3d0
class AB_PlayerHealthDamage_LensEffect_Direction_C : public AFortEmitterCameraLensEffectDirectional
{
public:
};

// Size: 0x3a0
class AB_PlayerShieldDamage_CameraLensEffect_C : public AB_PlayerHealthDamage_CameraLensEffect_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: StructProperty)
};

// Size: 0xa0
class UAnimNotifyState_NiagaraNotify_SetParameters_C : public UAnimNotifyState_TimedNiagaraEffect
{
public:
    TArray<FStruc_NiagaraParameters> Parameter_Setup() const { return Read<TArray<FStruc_NiagaraParameters>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)

    void SET_Parameter_Setup(const TArray<FStruc_NiagaraParameters>& Value) { Write<TArray<FStruc_NiagaraParameters>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FAnimCurveParameterPair
{
public:
    FName UserVariableName_5_C3E793D64B2060301331AC805C0B1026() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName AnimCurveName_6_457883094DB38A3EF423919EDE4D33C1() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)

    void SET_UserVariableName_5_C3E793D64B2060301331AC805C0B1026(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_AnimCurveName_6_457883094DB38A3EF423919EDE4D33C1(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x1f0
class UBP_CamShake_BlurPulse_C : public ULegacyCameraShake
{
public:
};

// Size: 0x1f0
class UBP_CameraShake_PortalWarp_C : public ULegacyCameraShake
{
public:
};

// Size: 0x398
class AB_CameraLens_SpookyMist_End_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: StructProperty)
};

// Size: 0x398
class AB_CameraLens_SpookyMist_Loop_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: StructProperty)
};

// Size: 0x398
class AB_CameraLens_SwimBoost_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: StructProperty)
};

// Size: 0x5fc
class AB_Pickups_Default_C : public AB_Pickups_Parent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* BG_Dark() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* BG() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x5d0); } // 0x5d0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* rarePickupFXMesh() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* SpotLightComp() const { return Read<USpotLightComponent*>(uintptr_t(this) + 0x5e0); } // 0x5e0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* rareAmbientEmitter() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Pickup_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0x5f0); } // 0x5f0 (Size: 0x8, Type: ObjectProperty)
    float Spotlight_Inverse_Exposure_Blend() const { return Read<float>(uintptr_t(this) + 0x5f8); } // 0x5f8 (Size: 0x4, Type: FloatProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x8, Type: StructProperty)
    void SET_BG_Dark(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x8, Type: ObjectProperty)
    void SET_BG(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x5d0, Value); } // 0x5d0 (Size: 0x8, Type: ObjectProperty)
    void SET_rarePickupFXMesh(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x8, Type: ObjectProperty)
    void SET_SpotLightComp(const USpotLightComponent*& Value) { Write<USpotLightComponent*>(uintptr_t(this) + 0x5e0, Value); } // 0x5e0 (Size: 0x8, Type: ObjectProperty)
    void SET_rareAmbientEmitter(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x8, Type: ObjectProperty)
    void SET_Pickup_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x5f0, Value); } // 0x5f0 (Size: 0x8, Type: ObjectProperty)
    void SET_Spotlight_Inverse_Exposure_Blend(const float& Value) { Write<float>(uintptr_t(this) + 0x5f8, Value); } // 0x5f8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x3a8
class AB_CameraLens_Geyser_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: StructProperty)
    float Timeline_0_Alpha_3D5AA2144E9B8D6D3B409B845315B143() const { return Read<float>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_0__Direction_3D5AA2144E9B8D6D3B409B845315B143() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x39c); } // 0x39c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Timeline_0() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: StructProperty)
    void SET_Timeline_0_Alpha_3D5AA2144E9B8D6D3B409B845315B143(const float& Value) { Write<float>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x4, Type: FloatProperty)
    void SET_Timeline_0__Direction_3D5AA2144E9B8D6D3B409B845315B143(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x39c, Value); } // 0x39c (Size: 0x1, Type: ByteProperty)
    void SET_Timeline_0(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2e8
class AFN_WashForce_C : public AFieldSystemActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: StructProperty)
    URadialFalloff* RadialFalloff() const { return Read<URadialFalloff*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UOperatorField* Multiply() const { return Read<UOperatorField*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    URadialVector* RadialVector() const { return Read<URadialVector*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    double Radius() const { return Read<double>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: DoubleProperty)
    double Strength() const { return Read<double>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: DoubleProperty)
    double Stop_TIme() const { return Read<double>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: StructProperty)
    void SET_RadialFalloff(const URadialFalloff*& Value) { Write<URadialFalloff*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_Multiply(const UOperatorField*& Value) { Write<UOperatorField*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    void SET_RadialVector(const URadialVector*& Value) { Write<URadialVector*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    void SET_Radius(const double& Value) { Write<double>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: DoubleProperty)
    void SET_Strength(const double& Value) { Write<double>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: DoubleProperty)
    void SET_Stop_TIme(const double& Value) { Write<double>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x3a8
class AB_CameraLens_Boat_Droplets_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: StructProperty)
    float Timeline_0_Alpha_0C9ACFAF463718824428D0A86CC5D789() const { return Read<float>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_0__Direction_0C9ACFAF463718824428D0A86CC5D789() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x39c); } // 0x39c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Timeline_0() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: StructProperty)
    void SET_Timeline_0_Alpha_0C9ACFAF463718824428D0A86CC5D789(const float& Value) { Write<float>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x4, Type: FloatProperty)
    void SET_Timeline_0__Direction_0C9ACFAF463718824428D0A86CC5D789(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x39c, Value); } // 0x39c (Size: 0x1, Type: ByteProperty)
    void SET_Timeline_0(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x398
class AB_CameraLens_Splash_Water_Droplets_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: StructProperty)
};

// Size: 0x398
class AB_PlayerHealthDamage_CameraLensEffect_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: StructProperty)
};

// Size: 0x1f0
class UB_Large_Explosion_CameraShake_C : public ULegacyCameraShake
{
public:
};

// Size: 0x364
class AFN_RadialForce_C : public AFieldSystemActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: StructProperty)
    UOperatorField* DistanceFadMult() const { return Read<UOperatorField*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    URadialFalloff* DistanceFalloff() const { return Read<URadialFalloff*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UWaveScalar* DecayScalar() const { return Read<UWaveScalar*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UOperatorField* DecayMult() const { return Read<UOperatorField*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UWaveScalar* RadialFalloffWave() const { return Read<UWaveScalar*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UOperatorField* RadialVecMultiplyRadialFallOff() const { return Read<UOperatorField*>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    URadialVector* RadialVector() const { return Read<URadialVector*>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    double Wave_Period() const { return Read<double>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x8, Type: DoubleProperty)
    double Force_Duration() const { return Read<double>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: DoubleProperty)
    double Radius() const { return Read<double>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: DoubleProperty)
    double Magnitude() const { return Read<double>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: DoubleProperty)
    double PlayRate() const { return Read<double>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x8, Type: DoubleProperty)
    double Scale() const { return Read<double>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x8, Type: DoubleProperty)
    double Impact_Time() const { return Read<double>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: DoubleProperty)
    double Period() const { return Read<double>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: DoubleProperty)
    double WaveLength() const { return Read<double>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: DoubleProperty)
    double Time_Decay() const { return Read<double>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: DoubleProperty)
    TEnumAsByte<EFieldFalloffType> Falloff_Type() const { return Read<TEnumAsByte<EFieldFalloffType>>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x1, Type: ByteProperty)
    double Expansion() const { return Read<double>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: DoubleProperty)
    double Impact_Radius() const { return Read<double>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: DoubleProperty)
    double Strength() const { return Read<double>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: DoubleProperty)
    float DelayTime() const { return Read<float>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x4, Type: FloatProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: StructProperty)
    void SET_DistanceFadMult(const UOperatorField*& Value) { Write<UOperatorField*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_DistanceFalloff(const URadialFalloff*& Value) { Write<URadialFalloff*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    void SET_DecayScalar(const UWaveScalar*& Value) { Write<UWaveScalar*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    void SET_DecayMult(const UOperatorField*& Value) { Write<UOperatorField*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    void SET_RadialFalloffWave(const UWaveScalar*& Value) { Write<UWaveScalar*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    void SET_RadialVecMultiplyRadialFallOff(const UOperatorField*& Value) { Write<UOperatorField*>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    void SET_RadialVector(const URadialVector*& Value) { Write<URadialVector*>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    void SET_Wave_Period(const double& Value) { Write<double>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x8, Type: DoubleProperty)
    void SET_Force_Duration(const double& Value) { Write<double>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: DoubleProperty)
    void SET_Radius(const double& Value) { Write<double>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: DoubleProperty)
    void SET_Magnitude(const double& Value) { Write<double>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: DoubleProperty)
    void SET_PlayRate(const double& Value) { Write<double>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x8, Type: DoubleProperty)
    void SET_Scale(const double& Value) { Write<double>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x8, Type: DoubleProperty)
    void SET_Impact_Time(const double& Value) { Write<double>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: DoubleProperty)
    void SET_Period(const double& Value) { Write<double>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: DoubleProperty)
    void SET_WaveLength(const double& Value) { Write<double>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: DoubleProperty)
    void SET_Time_Decay(const double& Value) { Write<double>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: DoubleProperty)
    void SET_Falloff_Type(const TEnumAsByte<EFieldFalloffType>& Value) { Write<TEnumAsByte<EFieldFalloffType>>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x1, Type: ByteProperty)
    void SET_Expansion(const double& Value) { Write<double>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: DoubleProperty)
    void SET_Impact_Radius(const double& Value) { Write<double>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: DoubleProperty)
    void SET_Strength(const double& Value) { Write<double>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: DoubleProperty)
    void SET_DelayTime(const float& Value) { Write<float>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x3a0
class AB_CameraLens_Lava_Bouncing_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: StructProperty)
    UParticleSystemComponent* P_Camera_Lava_Bouncing() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: StructProperty)
    void SET_P_Camera_Lava_Bouncing(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1f0
class UB_Medium_Explosion_CameraShake_C : public ULegacyCameraShake
{
public:
};

// Size: 0x1f0
class UB_Small_Explosion_CameraShake_C : public ULegacyCameraShake
{
public:
};

// Size: 0x1f0
class UB_Small_Vertical_Jolt_CameraShake_C : public ULegacyCameraShake
{
public:
};

// Size: 0x1f0
class UBP_CameraShake_Lava_Bounce_C : public ULegacyCameraShake
{
public:
};

// Size: 0x390
class ABP_CameraLens_HidingProp_Teleporting_Looping_WilliePete_C : public AEmitterCameraLensEffectBase
{
public:
};

// Size: 0x390
class ABP_CameraLens_HidingProp_Teleporting_Looping_C : public AEmitterCameraLensEffectBase
{
public:
};

// Size: 0x3f8
class AWeakSpot_C : public ABuildingWeakSpot
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* ConnectTheDotsComponent() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UCapsuleComponent* CollisionComponent() const { return Read<UCapsuleComponent*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    float ScaleDownParticleTL_ScaleDown_544AE05F40294D09C3C361AB7BCF6C4E() const { return Read<float>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> ScaleDownParticleTL__Direction_544AE05F40294D09C3C361AB7BCF6C4E() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x33c); } // 0x33c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* ScaleDownParticleTL() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SpawnSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    FVector Particle_Location() const { return Read<FVector>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x18, Type: StructProperty)
    TArray<USoundBase*> Crack_sounds() const { return Read<TArray<USoundBase*>>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x10, Type: ArrayProperty)
    double ConnectTheDotsWidth() const { return Read<double>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: DoubleProperty)
    double ConnectTheDotsDuration() const { return Read<double>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: DoubleProperty)
    double ConnectTheDotsTimeoutFromPreviousHit() const { return Read<double>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: DoubleProperty)
    double ConnectTheDotsDurationScale() const { return Read<double>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: DoubleProperty)
    double ConnectTheDotsMaxDuration() const { return Read<double>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: DoubleProperty)
    double ConnectTheDotsTileScale() const { return Read<double>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x8, Type: DoubleProperty)
    double ConnectTheDotsMinLength() const { return Read<double>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x8, Type: DoubleProperty)
    double ConnectTheDotsMaxLength() const { return Read<double>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x8, Type: DoubleProperty)
    UParticleSystem* DamageTemplateCascade() const { return Read<UParticleSystem*>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* IdleTemplateCascade() const { return Read<UParticleSystem*>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* ConnectMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle HideMeshTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x8, Type: StructProperty)
    UFXSystemComponent* FXComponent() const { return Read<UFXSystemComponent*>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* IdleTemplateNiagara() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* DamageTemplateNiagara() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    double FXSpriteScale() const { return Read<double>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: StructProperty)
    void SET_ConnectTheDotsComponent(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_CollisionComponent(const UCapsuleComponent*& Value) { Write<UCapsuleComponent*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_ScaleDownParticleTL_ScaleDown_544AE05F40294D09C3C361AB7BCF6C4E(const float& Value) { Write<float>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x4, Type: FloatProperty)
    void SET_ScaleDownParticleTL__Direction_544AE05F40294D09C3C361AB7BCF6C4E(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x33c, Value); } // 0x33c (Size: 0x1, Type: ByteProperty)
    void SET_ScaleDownParticleTL(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    void SET_SpawnSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_Particle_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x18, Type: StructProperty)
    void SET_Crack_sounds(const TArray<USoundBase*>& Value) { Write<TArray<USoundBase*>>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x10, Type: ArrayProperty)
    void SET_ConnectTheDotsWidth(const double& Value) { Write<double>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: DoubleProperty)
    void SET_ConnectTheDotsDuration(const double& Value) { Write<double>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: DoubleProperty)
    void SET_ConnectTheDotsTimeoutFromPreviousHit(const double& Value) { Write<double>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: DoubleProperty)
    void SET_ConnectTheDotsDurationScale(const double& Value) { Write<double>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: DoubleProperty)
    void SET_ConnectTheDotsMaxDuration(const double& Value) { Write<double>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: DoubleProperty)
    void SET_ConnectTheDotsTileScale(const double& Value) { Write<double>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x8, Type: DoubleProperty)
    void SET_ConnectTheDotsMinLength(const double& Value) { Write<double>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x8, Type: DoubleProperty)
    void SET_ConnectTheDotsMaxLength(const double& Value) { Write<double>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x8, Type: DoubleProperty)
    void SET_DamageTemplateCascade(const UParticleSystem*& Value) { Write<UParticleSystem*>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)
    void SET_IdleTemplateCascade(const UParticleSystem*& Value) { Write<UParticleSystem*>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    void SET_ConnectMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    void SET_HideMeshTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x8, Type: StructProperty)
    void SET_FXComponent(const UFXSystemComponent*& Value) { Write<UFXSystemComponent*>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    void SET_IdleTemplateNiagara(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    void SET_DamageTemplateNiagara(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    void SET_FXSpriteScale(const double& Value) { Write<double>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x434
class ADuplicateResOutMesh_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    float CharacterSpawnInTimeline_FirstPassComplete_2AB89084476E64255664E9B2D45E14C1() const { return Read<float>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x4, Type: FloatProperty)
    float CharacterSpawnInTimeline_LightIntensity_2AB89084476E64255664E9B2D45E14C1() const { return Read<float>(uintptr_t(this) + 0x2bc); } // 0x2bc (Size: 0x4, Type: FloatProperty)
    float CharacterSpawnInTimeline_zHieght_2AB89084476E64255664E9B2D45E14C1() const { return Read<float>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> CharacterSpawnInTimeline__Direction_2AB89084476E64255664E9B2D45E14C1() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x2c4); } // 0x2c4 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* CharacterSpawnInTimeline() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* Skeletal_Mesh_Duplicate() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    bool Gun_True() const { return Read<bool>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x1, Type: BoolProperty)
    double BoundsRadius() const { return Read<double>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: DoubleProperty)
    TArray<UMaterialInstanceDynamic*> MIDArray() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x10, Type: ArrayProperty)
    FVector World_location_for_the_dissolve_location() const { return Read<FVector>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x18, Type: StructProperty)
    UMaterialInstanceDynamic* Current_MID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x8, Type: ObjectProperty)
    double Head_Space() const { return Read<double>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x8, Type: DoubleProperty)
    double Leg_Space() const { return Read<double>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: DoubleProperty)
    UPointLightComponent* Spawn_Light() const { return Read<UPointLightComponent*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    double light_intensity() const { return Read<double>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: DoubleProperty)
    int32_t Number_of_Base_skeletal_mesh_materials() const { return Read<int32_t>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x4, Type: IntProperty)
    double FirstPassComplete() const { return Read<double>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: DoubleProperty)
    TArray<USkeletalMeshComponent*> ExternalSkeletalMeshComponent() const { return Read<TArray<USkeletalMeshComponent*>>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x10, Type: ArrayProperty)
    FTransform Box_Local_Transform() const { return Read<FTransform>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x60, Type: StructProperty)
    double Timeline_Play_Length() const { return Read<double>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: DoubleProperty)
    bool TeleportOut_() const { return Read<bool>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x1, Type: BoolProperty)
    AActor* ExternalActor() const { return Read<AActor*>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    TArray<USkeletalMeshComponent*> InternalSkeletalMeshComponents() const { return Read<TArray<USkeletalMeshComponent*>>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x10, Type: ArrayProperty)
    int32_t CurrentMeshMidIndex() const { return Read<int32_t>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x4, Type: IntProperty)
    USkeletalMeshComponent* External_Base_Mesh_Component() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x8, Type: ObjectProperty)
    TArray<UMaterialInstanceDynamic*> ExternalMidArray() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x10, Type: ArrayProperty)
    USkeletalMeshComponent* ExternalRootMeshComponent() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x8, Type: ObjectProperty)
    TArray<UMaterialInterface*> ListOfMaterialsExemptFromReparenting() const { return Read<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> Original_MIDs() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x10, Type: ArrayProperty)
    int32_t Increment_End() const { return Read<int32_t>(uintptr_t(this) + 0x430); } // 0x430 (Size: 0x4, Type: IntProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_CharacterSpawnInTimeline_FirstPassComplete_2AB89084476E64255664E9B2D45E14C1(const float& Value) { Write<float>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x4, Type: FloatProperty)
    void SET_CharacterSpawnInTimeline_LightIntensity_2AB89084476E64255664E9B2D45E14C1(const float& Value) { Write<float>(uintptr_t(this) + 0x2bc, Value); } // 0x2bc (Size: 0x4, Type: FloatProperty)
    void SET_CharacterSpawnInTimeline_zHieght_2AB89084476E64255664E9B2D45E14C1(const float& Value) { Write<float>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x4, Type: FloatProperty)
    void SET_CharacterSpawnInTimeline__Direction_2AB89084476E64255664E9B2D45E14C1(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x2c4, Value); } // 0x2c4 (Size: 0x1, Type: ByteProperty)
    void SET_CharacterSpawnInTimeline(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    void SET_Skeletal_Mesh_Duplicate(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    void SET_Gun_True(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x1, Type: BoolProperty)
    void SET_BoundsRadius(const double& Value) { Write<double>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: DoubleProperty)
    void SET_MIDArray(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x10, Type: ArrayProperty)
    void SET_World_location_for_the_dissolve_location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x18, Type: StructProperty)
    void SET_Current_MID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x8, Type: ObjectProperty)
    void SET_Head_Space(const double& Value) { Write<double>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x8, Type: DoubleProperty)
    void SET_Leg_Space(const double& Value) { Write<double>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: DoubleProperty)
    void SET_Spawn_Light(const UPointLightComponent*& Value) { Write<UPointLightComponent*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_light_intensity(const double& Value) { Write<double>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: DoubleProperty)
    void SET_Number_of_Base_skeletal_mesh_materials(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x4, Type: IntProperty)
    void SET_FirstPassComplete(const double& Value) { Write<double>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: DoubleProperty)
    void SET_ExternalSkeletalMeshComponent(const TArray<USkeletalMeshComponent*>& Value) { Write<TArray<USkeletalMeshComponent*>>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x10, Type: ArrayProperty)
    void SET_Box_Local_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x60, Type: StructProperty)
    void SET_Timeline_Play_Length(const double& Value) { Write<double>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: DoubleProperty)
    void SET_TeleportOut_(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x1, Type: BoolProperty)
    void SET_ExternalActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    void SET_InternalSkeletalMeshComponents(const TArray<USkeletalMeshComponent*>& Value) { Write<TArray<USkeletalMeshComponent*>>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentMeshMidIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x4, Type: IntProperty)
    void SET_External_Base_Mesh_Component(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x8, Type: ObjectProperty)
    void SET_ExternalMidArray(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x10, Type: ArrayProperty)
    void SET_ExternalRootMeshComponent(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x8, Type: ObjectProperty)
    void SET_ListOfMaterialsExemptFromReparenting(const TArray<UMaterialInterface*>& Value) { Write<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x10, Type: ArrayProperty)
    void SET_Original_MIDs(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x10, Type: ArrayProperty)
    void SET_Increment_End(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x430, Value); } // 0x430 (Size: 0x4, Type: IntProperty)
};

