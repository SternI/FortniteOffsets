/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteConversationUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CommonUI.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "UMG.h"
#include "FortniteGame.h"
#include "CommonConversationRuntime.h"
#include "FortniteUI.h"
#include "DynamicUI.h"

// Size: 0x4b8
class UFortConversation_CommActiveBase : public UCommonActivatableWidget
{
public:
    UInputComponent* ConversationInputComponent() const { return Read<UInputComponent*>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    FName FireInputActionName() const { return Read<FName>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x4, Type: NameProperty)
    FDataTableRowHandle ADS_DataTableRowHandle() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle BackAction_DataTableRowHandle() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x10, Type: StructProperty)
    FName ADSInputActionName() const { return Read<FName>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x4, Type: NameProperty)
    FName InventoryKBMInputActionName() const { return Read<FName>(uintptr_t(this) + 0x4ac); } // 0x4ac (Size: 0x4, Type: NameProperty)
    FName InventoryGamepadInputActionName() const { return Read<FName>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x4, Type: NameProperty)
    FName PlaceMapMarkerInputActionName() const { return Read<FName>(uintptr_t(this) + 0x4b4); } // 0x4b4 (Size: 0x4, Type: NameProperty)

    void SET_ConversationInputComponent(const UInputComponent*& Value) { Write<UInputComponent*>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    void SET_FireInputActionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x4, Type: NameProperty)
    void SET_ADS_DataTableRowHandle(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x10, Type: StructProperty)
    void SET_BackAction_DataTableRowHandle(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x10, Type: StructProperty)
    void SET_ADSInputActionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x4, Type: NameProperty)
    void SET_InventoryKBMInputActionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4ac, Value); } // 0x4ac (Size: 0x4, Type: NameProperty)
    void SET_InventoryGamepadInputActionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x4, Type: NameProperty)
    void SET_PlaceMapMarkerInputActionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4b4, Value); } // 0x4b4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x378
class UFortApplyAbilityBrief : public UFortItemTransactionBrief
{
public:
    FText PurchaseServiceText() const { return Read<FText>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x10, Type: TextProperty)
    UCommonRichTextBlock* Text_Display() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)

    void SET_PurchaseServiceText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x10, Type: TextProperty)
    void SET_Text_Display(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x360
class UFortItemTransactionBrief : public UFortConversationOptionBrief
{
public:
    UFortTransactionStrip* TransactionStrip_Main() const { return Read<UFortTransactionStrip*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    UFortItem* DisplayItem() const { return Read<UFortItem*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)

    void SET_TransactionStrip_Main(const UFortTransactionStrip*& Value) { Write<UFortTransactionStrip*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_DisplayItem(const UFortItem*& Value) { Write<UFortItem*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x348
class UFortConversationOptionBrief : public UCommonUserWidget
{
public:
};

// Size: 0x348
class UFortBasicBrief : public UFortConversationOptionBrief
{
public:
};

// Size: 0x3b8
class UFortBasicItemBrief : public UFortConversationOptionBrief
{
public:
    UCommonTextBlock* Text_TitleBar() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    UFortTransactionStrip* TransactionStrip_Main() const { return Read<UFortTransactionStrip*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    UFortItem* DisplayItem() const { return Read<UFortItem*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    TMap<FDataDrivenServiceBriefConfig, FName> ServiceConfigs() const { return Read<TMap<FDataDrivenServiceBriefConfig, FName>>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x50, Type: MapProperty)

    void SET_Text_TitleBar(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_TransactionStrip_Main(const UFortTransactionStrip*& Value) { Write<UFortTransactionStrip*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_DisplayItem(const UFortItem*& Value) { Write<UFortItem*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_ServiceConfigs(const TMap<FDataDrivenServiceBriefConfig, FName>& Value) { Write<TMap<FDataDrivenServiceBriefConfig, FName>>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x50, Type: MapProperty)
};

// Size: 0x370
class UFortBuyBrief : public UFortItemTransactionBrief
{
public:
    FString RemainingForSaleKey() const { return Read<FString>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x10, Type: StrProperty)

    void SET_RemainingForSaleKey(const FString& Value) { Write<FString>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x10, Type: StrProperty)
};

// Size: 0x540
class UFortConversationMarker : public UFortActorIndicatorWidget
{
public:
    bool bShowConversationLimitHit() const { return Read<bool>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x1, Type: BoolProperty)
    FVector InitialOffset() const { return Read<FVector>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x18, Type: StructProperty)
    FVector ManualOffset() const { return Read<FVector>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x18, Type: StructProperty)
    float MessageBubbleDuration() const { return Read<float>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x4, Type: FloatProperty)
    float LastTextBubbleDuration() const { return Read<float>(uintptr_t(this) + 0x49c); } // 0x49c (Size: 0x4, Type: FloatProperty)
    bool bSetCustomInteractionWidgetOnlyWhenNeeded() const { return Read<bool>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x1, Type: BoolProperty)
    UCommonVisibilitySwitcher* Switcher_States() const { return Read<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    UWidget* Overlay_PreviewState() const { return Read<UWidget*>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    UFortConversationMessageWidget* ConversationMessage_Main() const { return Read<UFortConversationMessageWidget*>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ParticipantName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    UFortKeybindWidget* Keybind_Nameplate() const { return Read<UFortKeybindWidget*>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x8, Type: ObjectProperty)
    UImage* NPCIcon() const { return Read<UImage*>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* CustomDialogMarkerIndicatorIcon() const { return Read<UTexture2D*>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* DefaultDialogMarkerIndicatorIcon() const { return Read<UTexture2D*>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UTexture2D> DefaultMaxParticipantIconTexture() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x20, Type: SoftObjectProperty)

    void SET_bShowConversationLimitHit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x1, Type: BoolProperty)
    void SET_InitialOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x18, Type: StructProperty)
    void SET_ManualOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x18, Type: StructProperty)
    void SET_MessageBubbleDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x4, Type: FloatProperty)
    void SET_LastTextBubbleDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x49c, Value); } // 0x49c (Size: 0x4, Type: FloatProperty)
    void SET_bSetCustomInteractionWidgetOnlyWhenNeeded(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x1, Type: BoolProperty)
    void SET_Switcher_States(const UCommonVisibilitySwitcher*& Value) { Write<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_PreviewState(const UWidget*& Value) { Write<UWidget*>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    void SET_ConversationMessage_Main(const UFortConversationMessageWidget*& Value) { Write<UFortConversationMessageWidget*>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_ParticipantName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    void SET_Keybind_Nameplate(const UFortKeybindWidget*& Value) { Write<UFortKeybindWidget*>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x8, Type: ObjectProperty)
    void SET_NPCIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    void SET_CustomDialogMarkerIndicatorIcon(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultDialogMarkerIndicatorIcon(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultMaxParticipantIconTexture(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x388
class UFortConversationMessageWidget : public UFortHUDElementWidget
{
public:
};

// Size: 0x1670
class UFortConversationOption : public UFortRadialPickerEntry
{
public:
    USoundBase* OnOptionConfirmedSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x15d0); } // 0x15d0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* OnOptionHoveredSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x15d8); } // 0x15d8 (Size: 0x8, Type: ObjectProperty)
    UCommonVisibilitySwitcher* Switcher_DisplayAsset() const { return Read<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0x15e0); } // 0x15e0 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UObject> DefaultSoftTaskIcon() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x15e8); } // 0x15e8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<USoundBase> DefaultConfirmChoiceSound() const { return Read<TSoftObjectPtr<USoundBase>>(uintptr_t(this) + 0x1608); } // 0x1608 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<USoundBase> DefaultHoverChoiceSound() const { return Read<TSoftObjectPtr<USoundBase>>(uintptr_t(this) + 0x1628); } // 0x1628 (Size: 0x20, Type: SoftObjectProperty)

    void SET_OnOptionConfirmedSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x15d0, Value); } // 0x15d0 (Size: 0x8, Type: ObjectProperty)
    void SET_OnOptionHoveredSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x15d8, Value); } // 0x15d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Switcher_DisplayAsset(const UCommonVisibilitySwitcher*& Value) { Write<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0x15e0, Value); } // 0x15e0 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultSoftTaskIcon(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x15e8, Value); } // 0x15e8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_DefaultConfirmChoiceSound(const TSoftObjectPtr<USoundBase>& Value) { Write<TSoftObjectPtr<USoundBase>>(uintptr_t(this) + 0x1608, Value); } // 0x1608 (Size: 0x20, Type: SoftObjectProperty)
    void SET_DefaultHoverChoiceSound(const TSoftObjectPtr<USoundBase>& Value) { Write<TSoftObjectPtr<USoundBase>>(uintptr_t(this) + 0x1628, Value); } // 0x1628 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x188
class UFortConversationOptionsPanel : public UPanelWidget
{
public:
    int32_t MaxRows() const { return Read<int32_t>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x4, Type: IntProperty)
    int32_t MiddleColumnWidth() const { return Read<int32_t>(uintptr_t(this) + 0x184); } // 0x184 (Size: 0x4, Type: IntProperty)

    void SET_MaxRows(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x4, Type: IntProperty)
    void SET_MiddleColumnWidth(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x184, Value); } // 0x184 (Size: 0x4, Type: IntProperty)
};

// Size: 0x650
class UFortConversationScreen : public UCommonActivatableWidget
{
public:
    UCommonVisibilitySwitcher* Switcher_Details() const { return Read<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    UInputComponent* ConversationInputComp() const { return Read<UInputComponent*>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x8, Type: ObjectProperty)
    int32_t CurrentlySelectedIndex() const { return Read<int32_t>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x4, Type: IntProperty)
    bool bBlockOptionIntroAnimation() const { return Read<bool>(uintptr_t(this) + 0x4ec); } // 0x4ec (Size: 0x1, Type: BoolProperty)
    FName RadialSelectionMaterialParameterName() const { return Read<FName>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x4, Type: NameProperty)
    TArray<FGameplayTag> TagPriorities() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x10, Type: ArrayProperty)
    FName InteractActionNameKBM() const { return Read<FName>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x4, Type: NameProperty)
    FName ADSInputAction() const { return Read<FName>(uintptr_t(this) + 0x50c); } // 0x50c (Size: 0x4, Type: NameProperty)
    FName InteractActionNameGamepad() const { return Read<FName>(uintptr_t(this) + 0x510); } // 0x510 (Size: 0x4, Type: NameProperty)
    FDataTableRowHandle ConfirmBinding() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle MakeSelectionBinding() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x528); } // 0x528 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle ADSMouseBinding() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle CancelActionBinding() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x548); } // 0x548 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle RightTriggerBinding() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x558); } // 0x558 (Size: 0x10, Type: StructProperty)
    TMap<TSoftClassPtr, FString> DetailsNodeTypeToBrief() const { return Read<TMap<TSoftClassPtr, FString>>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x50, Type: MapProperty)
    FString DataDrivenBriefPrefix() const { return Read<FString>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x10, Type: StrProperty)
    UFortSlottedRadialMenu* RadialMenu_DialogOptions() const { return Read<UFortSlottedRadialMenu*>(uintptr_t(this) + 0x608); } // 0x608 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_RadialHighlight() const { return Read<UImage*>(uintptr_t(this) + 0x610); } // 0x610 (Size: 0x8, Type: ObjectProperty)
    UFortKeybindWidget* Keybind_Confirm() const { return Read<UFortKeybindWidget*>(uintptr_t(this) + 0x618); } // 0x618 (Size: 0x8, Type: ObjectProperty)
    UFortBasicBrief* BasicBrief_Main() const { return Read<UFortBasicBrief*>(uintptr_t(this) + 0x620); } // 0x620 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SizeBox_RadialMenu() const { return Read<USizeBox*>(uintptr_t(this) + 0x628); } // 0x628 (Size: 0x8, Type: ObjectProperty)
    UWidget* Overlay_Details() const { return Read<UWidget*>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0x8, Type: ObjectProperty)
    UWidget* Overlay_WheelContainer() const { return Read<UWidget*>(uintptr_t(this) + 0x638); } // 0x638 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Background() const { return Read<UImage*>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_LoadingSpinner() const { return Read<UImage*>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x8, Type: ObjectProperty)

    void SET_Switcher_Details(const UCommonVisibilitySwitcher*& Value) { Write<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    void SET_ConversationInputComp(const UInputComponent*& Value) { Write<UInputComponent*>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentlySelectedIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x4, Type: IntProperty)
    void SET_bBlockOptionIntroAnimation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4ec, Value); } // 0x4ec (Size: 0x1, Type: BoolProperty)
    void SET_RadialSelectionMaterialParameterName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x4, Type: NameProperty)
    void SET_TagPriorities(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x10, Type: ArrayProperty)
    void SET_InteractActionNameKBM(const FName& Value) { Write<FName>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x4, Type: NameProperty)
    void SET_ADSInputAction(const FName& Value) { Write<FName>(uintptr_t(this) + 0x50c, Value); } // 0x50c (Size: 0x4, Type: NameProperty)
    void SET_InteractActionNameGamepad(const FName& Value) { Write<FName>(uintptr_t(this) + 0x510, Value); } // 0x510 (Size: 0x4, Type: NameProperty)
    void SET_ConfirmBinding(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x10, Type: StructProperty)
    void SET_MakeSelectionBinding(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x528, Value); } // 0x528 (Size: 0x10, Type: StructProperty)
    void SET_ADSMouseBinding(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x10, Type: StructProperty)
    void SET_CancelActionBinding(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x548, Value); } // 0x548 (Size: 0x10, Type: StructProperty)
    void SET_RightTriggerBinding(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x558, Value); } // 0x558 (Size: 0x10, Type: StructProperty)
    void SET_DetailsNodeTypeToBrief(const TMap<TSoftClassPtr, FString>& Value) { Write<TMap<TSoftClassPtr, FString>>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x50, Type: MapProperty)
    void SET_DataDrivenBriefPrefix(const FString& Value) { Write<FString>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x10, Type: StrProperty)
    void SET_RadialMenu_DialogOptions(const UFortSlottedRadialMenu*& Value) { Write<UFortSlottedRadialMenu*>(uintptr_t(this) + 0x608, Value); } // 0x608 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_RadialHighlight(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x610, Value); } // 0x610 (Size: 0x8, Type: ObjectProperty)
    void SET_Keybind_Confirm(const UFortKeybindWidget*& Value) { Write<UFortKeybindWidget*>(uintptr_t(this) + 0x618, Value); } // 0x618 (Size: 0x8, Type: ObjectProperty)
    void SET_BasicBrief_Main(const UFortBasicBrief*& Value) { Write<UFortBasicBrief*>(uintptr_t(this) + 0x620, Value); } // 0x620 (Size: 0x8, Type: ObjectProperty)
    void SET_SizeBox_RadialMenu(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x628, Value); } // 0x628 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_Details(const UWidget*& Value) { Write<UWidget*>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_WheelContainer(const UWidget*& Value) { Write<UWidget*>(uintptr_t(this) + 0x638, Value); } // 0x638 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Background(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_LoadingSpinner(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x3c0
class UFortDataDrivenServiceBrief : public UFortConversationOptionBrief
{
public:
    UCommonTextBlock* Text_TitleBar() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* RichText_Description() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_StockRemaining() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    UFortTransactionStrip* TransactionStrip_Main() const { return Read<UFortTransactionStrip*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    TMap<FDataDrivenServiceBriefConfig, FName> ServiceConfigs() const { return Read<TMap<FDataDrivenServiceBriefConfig, FName>>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x50, Type: MapProperty)

    void SET_Text_TitleBar(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_RichText_Description(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_StockRemaining(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_TransactionStrip_Main(const UFortTransactionStrip*& Value) { Write<UFortTransactionStrip*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_ServiceConfigs(const TMap<FDataDrivenServiceBriefConfig, FName>& Value) { Write<TMap<FDataDrivenServiceBriefConfig, FName>>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x50, Type: MapProperty)
};

// Size: 0x380
class UFortDuelBrief : public UFortItemTransactionBrief
{
public:
    FText TextTemplate() const { return Read<FText>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x10, Type: TextProperty)
    UCommonRichTextBlock* Text_Objective() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    UCommonTileView* TileView() const { return Read<UCommonTileView*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)

    void SET_TextTemplate(const FText& Value) { Write<FText>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x10, Type: TextProperty)
    void SET_Text_Objective(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_TileView(const UCommonTileView*& Value) { Write<UCommonTileView*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x380
class UFortHireBrief : public UFortItemTransactionBrief
{
public:
    FText TextTemplate() const { return Read<FText>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x10, Type: TextProperty)
    UCommonRichTextBlock* Text_Objective() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    UDataTable* SpecializationsVisualDataTable() const { return Read<UDataTable*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)

    void SET_TextTemplate(const FText& Value) { Write<FText>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x10, Type: TextProperty)
    void SET_Text_Objective(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_SpecializationsVisualDataTable(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x378
class UFortIntelBrief : public UFortItemTransactionBrief
{
public:
    FText TextTemplate() const { return Read<FText>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x10, Type: TextProperty)
    UCommonRichTextBlock* Text_Objective() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)

    void SET_TextTemplate(const FText& Value) { Write<FText>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x10, Type: TextProperty)
    void SET_Text_Objective(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x470
class UFortItemFundBrief : public UCommonUserWidget
{
public:
    UCommonTextBlock* Text_TitleBar() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ProgressPercent() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ProgressCount() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x8, Type: ObjectProperty)
    UFortSimpleMaterialProgressBar* Progress_Funding() const { return Read<UFortSimpleMaterialProgressBar*>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x8, Type: ObjectProperty)
    UFortLazyImage* LazyImage_Icon() const { return Read<UFortLazyImage*>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x8, Type: ObjectProperty)
    UFortTransactionStrip* TransactionStrip_Main() const { return Read<UFortTransactionStrip*>(uintptr_t(this) + 0x418); } // 0x418 (Size: 0x8, Type: ObjectProperty)
    TMap<FDataDrivenServiceBriefConfig, FName> ServiceConfigs() const { return Read<TMap<FDataDrivenServiceBriefConfig, FName>>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x50, Type: MapProperty)

    void SET_Text_TitleBar(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_ProgressPercent(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_ProgressCount(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x8, Type: ObjectProperty)
    void SET_Progress_Funding(const UFortSimpleMaterialProgressBar*& Value) { Write<UFortSimpleMaterialProgressBar*>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x8, Type: ObjectProperty)
    void SET_LazyImage_Icon(const UFortLazyImage*& Value) { Write<UFortLazyImage*>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x8, Type: ObjectProperty)
    void SET_TransactionStrip_Main(const UFortTransactionStrip*& Value) { Write<UFortTransactionStrip*>(uintptr_t(this) + 0x418, Value); } // 0x418 (Size: 0x8, Type: ObjectProperty)
    void SET_ServiceConfigs(const TMap<FDataDrivenServiceBriefConfig, FName>& Value) { Write<TMap<FDataDrivenServiceBriefConfig, FName>>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x50, Type: MapProperty)
};

// Size: 0x3c0
class UFortMultiItemFundBrief : public UFortSingleItemFundBrief
{
public:
    UFortItemFundBrief* Item_EntrySecondary() const { return Read<UFortItemFundBrief*>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x8, Type: ObjectProperty)
    UFortItemFundBrief* Item_EntryTertiary() const { return Read<UFortItemFundBrief*>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)

    void SET_Item_EntrySecondary(const UFortItemFundBrief*& Value) { Write<UFortItemFundBrief*>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x8, Type: ObjectProperty)
    void SET_Item_EntryTertiary(const UFortItemFundBrief*& Value) { Write<UFortItemFundBrief*>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x3b0
class UFortSingleItemFundBrief : public UFortConversationOptionBrief
{
public:
    UFortItemFundBrief* Item_Entry() const { return Read<UFortItemFundBrief*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    UFortNPCTextDisplay* NPCTextDisplay() const { return Read<UFortNPCTextDisplay*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    TMap<FDataDrivenServiceBriefConfig, FName> ServiceConfigs() const { return Read<TMap<FDataDrivenServiceBriefConfig, FName>>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x50, Type: MapProperty)

    void SET_Item_Entry(const UFortItemFundBrief*& Value) { Write<UFortItemFundBrief*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_NPCTextDisplay(const UFortNPCTextDisplay*& Value) { Write<UFortNPCTextDisplay*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_ServiceConfigs(const TMap<FDataDrivenServiceBriefConfig, FName>& Value) { Write<TMap<FDataDrivenServiceBriefConfig, FName>>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x50, Type: MapProperty)
};

// Size: 0x330
class UFortNPCTextDisplay : public UUserWidget
{
public:
    UCommonRichTextBlock* Text_Message() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: ObjectProperty)
    UFortLazyImage* LazyImage_NPCImage() const { return Read<UFortLazyImage*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)

    void SET_Text_Message(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: ObjectProperty)
    void SET_LazyImage_NPCImage(const UFortLazyImage*& Value) { Write<UFortLazyImage*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x200
class UFortPlayerConversationUIComponent : public UActorComponent
{
public:
    bool bBlockUISpawning() const { return Read<bool>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    TArray<UDynamicUIScene*> SpectatorConversationScenes() const { return Read<TArray<UDynamicUIScene*>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x10, Type: ArrayProperty)
    TArray<UDynamicUIScene*> SpectatorMobileConversationScenes() const { return Read<TArray<UDynamicUIScene*>>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x10, Type: ArrayProperty)
    UClass* DialogWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x8, Type: ClassProperty)
    UClass* DialogMarkerClass() const { return Read<UClass*>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x8, Type: ClassProperty)
    FUserWidgetPool DialogWidgetPool() const { return Read<FUserWidgetPool>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x88, Type: StructProperty)

    void SET_bBlockUISpawning(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    void SET_SpectatorConversationScenes(const TArray<UDynamicUIScene*>& Value) { Write<TArray<UDynamicUIScene*>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x10, Type: ArrayProperty)
    void SET_SpectatorMobileConversationScenes(const TArray<UDynamicUIScene*>& Value) { Write<TArray<UDynamicUIScene*>>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x10, Type: ArrayProperty)
    void SET_DialogWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x8, Type: ClassProperty)
    void SET_DialogMarkerClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x8, Type: ClassProperty)
    void SET_DialogWidgetPool(const FUserWidgetPool& Value) { Write<FUserWidgetPool>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x88, Type: StructProperty)
};

// Size: 0x390
class UFortQuestBrief : public UFortConversationOptionBrief
{
public:
    FText ThisMatchOnlyQuestText() const { return Read<FText>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x10, Type: TextProperty)
    UCommonRichTextBlock* Text_Objective() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_MoneyReward() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_XpReward() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ExpirationTime() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    UCommonLazyImage* LazyImage_QuestProviderImage() const { return Read<UCommonLazyImage*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_QuestProvider() const { return Read<UOverlay*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)

    void SET_ThisMatchOnlyQuestText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x10, Type: TextProperty)
    void SET_Text_Objective(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_MoneyReward(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_XpReward(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_ExpirationTime(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_LazyImage_QuestProviderImage(const UCommonLazyImage*& Value) { Write<UCommonLazyImage*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_QuestProvider(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x378
class UFortShowFutureStormCircleBrief : public UFortItemTransactionBrief
{
public:
    FText PurchaseServiceText() const { return Read<FText>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x10, Type: TextProperty)
    UCommonRichTextBlock* Text_Display() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)

    void SET_PurchaseServiceText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x10, Type: TextProperty)
    void SET_Text_Display(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x398
class UFortSingleOrMultiItemFundBrief : public UFortConversationOptionBrief
{
public:
    UOverlay* Overlay_Brief() const { return Read<UOverlay*>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: ObjectProperty)

    void SET_Overlay_Brief(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x3a8
class UFortTransactionStrip : public UUserWidget
{
public:
    UCommonTextBlock* Text_CostDescription() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UFortWorldItemDefinition*> CachedGlobalCurrency() const { return Read<TWeakObjectPtr<UFortWorldItemDefinition*>>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: WeakObjectProperty)
    UFortWorldItemDefinition* ResourceCurrency() const { return Read<UFortWorldItemDefinition*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)

    void SET_Text_CostDescription(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedGlobalCurrency(const TWeakObjectPtr<UFortWorldItemDefinition*>& Value) { Write<TWeakObjectPtr<UFortWorldItemDefinition*>>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ResourceCurrency(const UFortWorldItemDefinition*& Value) { Write<UFortWorldItemDefinition*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x360
class UFortUpgradeBrief : public UFortItemTransactionBrief
{
public:
};

// Size: 0x678
class UMobileConversationScreen : public UFortConversationScreen
{
public:
    UButton* MobileButtonConfirm() const { return Read<UButton*>(uintptr_t(this) + 0x650); } // 0x650 (Size: 0x8, Type: ObjectProperty)
    UButton* MobileButtonTouchInformation() const { return Read<UButton*>(uintptr_t(this) + 0x658); } // 0x658 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* MobileCloseButton() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x668); } // 0x668 (Size: 0x8, Type: ObjectProperty)
    UCommonVisibilitySwitcher* Switcher_CenteredDetails() const { return Read<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0x670); } // 0x670 (Size: 0x8, Type: ObjectProperty)

    void SET_MobileButtonConfirm(const UButton*& Value) { Write<UButton*>(uintptr_t(this) + 0x650, Value); } // 0x650 (Size: 0x8, Type: ObjectProperty)
    void SET_MobileButtonTouchInformation(const UButton*& Value) { Write<UButton*>(uintptr_t(this) + 0x658, Value); } // 0x658 (Size: 0x8, Type: ObjectProperty)
    void SET_MobileCloseButton(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x668, Value); } // 0x668 (Size: 0x8, Type: ObjectProperty)
    void SET_Switcher_CenteredDetails(const UCommonVisibilitySwitcher*& Value) { Write<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0x670, Value); } // 0x670 (Size: 0x8, Type: ObjectProperty)
};

