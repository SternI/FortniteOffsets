/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayGraph
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"

// Size: 0x48
class UGraphElement : public UObject
{
public:
    FGraphUniqueIndex UniqueIndex() const { return Read<FGraphUniqueIndex>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x14, Type: StructProperty)
    TWeakObjectPtr<UGraph*> ParentGraph() const { return Read<TWeakObjectPtr<UGraph*>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: WeakObjectProperty)

    void SET_UniqueIndex(const FGraphUniqueIndex& Value) { Write<FGraphUniqueIndex>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x14, Type: StructProperty)
    void SET_ParentGraph(const TWeakObjectPtr<UGraph*>& Value) { Write<TWeakObjectPtr<UGraph*>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x130
class UGraph : public UObject
{
public:
    TMap<UGraphVertex*, FGraphVertexHandle> Vertices() const { return Read<TMap<UGraphVertex*, FGraphVertexHandle>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x50, Type: MapProperty)
    TMap<UGraphIsland*, FGraphIslandHandle> Islands() const { return Read<TMap<UGraphIsland*, FGraphIslandHandle>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x50, Type: MapProperty)

    void SET_Vertices(const TMap<UGraphVertex*, FGraphVertexHandle>& Value) { Write<TMap<UGraphVertex*, FGraphVertexHandle>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x50, Type: MapProperty)
    void SET_Islands(const TMap<UGraphIsland*, FGraphIslandHandle>& Value) { Write<TMap<UGraphIsland*, FGraphIslandHandle>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x50, Type: MapProperty)
};

// Size: 0x100
class UGraphIsland : public UGraphElement
{
public:
    TSet<FGraphVertexHandle> Vertices() const { return Read<TSet<FGraphVertexHandle>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x50, Type: SetProperty)

    void SET_Vertices(const TSet<FGraphVertexHandle>& Value) { Write<TSet<FGraphVertexHandle>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x50, Type: SetProperty)
};

// Size: 0xf0
class UGraphVertex : public UGraphElement
{
public:
    TSet<FGraphVertexHandle> Edges() const { return Read<TSet<FGraphVertexHandle>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x50, Type: SetProperty)
    FGraphIslandHandle ParentIsland() const { return Read<FGraphIslandHandle>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x28, Type: StructProperty)

    void SET_Edges(const TSet<FGraphVertexHandle>& Value) { Write<TSet<FGraphVertexHandle>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x50, Type: SetProperty)
    void SET_ParentIsland(const FGraphIslandHandle& Value) { Write<FGraphIslandHandle>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x1
struct FGraphProperties
{
public:
    bool bGenerateIslands() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)

    void SET_bGenerateIslands(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x50
struct FSerializedEdgeData
{
public:
    FGraphVertexHandle Node1() const { return Read<FGraphVertexHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x28, Type: StructProperty)
    FGraphVertexHandle Node2() const { return Read<FGraphVertexHandle>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x28, Type: StructProperty)

    void SET_Node1(const FGraphVertexHandle& Value) { Write<FGraphVertexHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x28, Type: StructProperty)
    void SET_Node2(const FGraphVertexHandle& Value) { Write<FGraphVertexHandle>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x28, Type: StructProperty)
};

// Size: 0x28
struct FGraphHandle
{
public:
    FGraphUniqueIndex UniqueIndex() const { return Read<FGraphUniqueIndex>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x14, Type: StructProperty)
    TWeakObjectPtr<UGraph*> WeakGraph() const { return Read<TWeakObjectPtr<UGraph*>>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x8, Type: WeakObjectProperty)

    void SET_UniqueIndex(const FGraphUniqueIndex& Value) { Write<FGraphUniqueIndex>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x14, Type: StructProperty)
    void SET_WeakGraph(const TWeakObjectPtr<UGraph*>& Value) { Write<TWeakObjectPtr<UGraph*>>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x14
struct FGraphUniqueIndex
{
public:
    FGuid UniqueIndex() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    bool bIsTemporary() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_UniqueIndex(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_bIsTemporary(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FGraphVertexHandle : public FGraphHandle
{
public:
};

// Size: 0x10
struct FSerializedIslandData
{
public:
    TArray<FGraphVertexHandle> Vertices() const { return Read<TArray<FGraphVertexHandle>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Vertices(const TArray<FGraphVertexHandle>& Value) { Write<TArray<FGraphVertexHandle>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x78
struct FSerializableGraph
{
public:
    FGraphProperties Properties() const { return Read<FGraphProperties>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: StructProperty)
    TArray<FGraphVertexHandle> Vertices() const { return Read<TArray<FGraphVertexHandle>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FSerializedEdgeData> Edges() const { return Read<TArray<FSerializedEdgeData>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TMap<FSerializedIslandData, FGraphIslandHandle> Islands() const { return Read<TMap<FSerializedIslandData, FGraphIslandHandle>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: MapProperty)

    void SET_Properties(const FGraphProperties& Value) { Write<FGraphProperties>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: StructProperty)
    void SET_Vertices(const TArray<FGraphVertexHandle>& Value) { Write<TArray<FGraphVertexHandle>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_Edges(const TArray<FSerializedEdgeData>& Value) { Write<TArray<FSerializedEdgeData>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_Islands(const TMap<FSerializedIslandData, FGraphIslandHandle>& Value) { Write<TMap<FSerializedIslandData, FGraphIslandHandle>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: MapProperty)
};

// Size: 0x28
struct FGraphIslandHandle : public FGraphHandle
{
public:
};

