/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Foliage
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0xb70
class UFoliageInstancedStaticMeshComponent : public UHierarchicalInstancedStaticMeshComponent
{
public:
    bool bEnableDiscardOnLoad() const { return Read<bool>(uintptr_t(this) + 0xb58); } // 0xb58 (Size: 0x1, Type: BoolProperty)
    FGuid GenerationGuid() const { return Read<FGuid>(uintptr_t(this) + 0xb5c); } // 0xb5c (Size: 0x10, Type: StructProperty)

    void SET_bEnableDiscardOnLoad(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb58, Value); } // 0xb58 (Size: 0x1, Type: BoolProperty)
    void SET_GenerationGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0xb5c, Value); } // 0xb5c (Size: 0x10, Type: StructProperty)
};

// Size: 0x4a8
class UFoliageType : public UObject
{
public:
    FGuid UpdateGuid() const { return Read<FGuid>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    float Density() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float DensityAdjustmentFactor() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    bool bSingleInstanceModeOverrideRadius() const { return Read<bool>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x1, Type: BoolProperty)
    float SingleInstanceModeRadius() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    uint8_t Scaling() const { return Read<uint8_t>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x1, Type: EnumProperty)
    FFloatInterval ScaleX() const { return Read<FFloatInterval>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: StructProperty)
    FFloatInterval ScaleY() const { return Read<FFloatInterval>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: StructProperty)
    FFloatInterval ScaleZ() const { return Read<FFloatInterval>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: StructProperty)
    FFoliageVertexColorChannelMask VertexColorMaskByChannel() const { return Read<FFoliageVertexColorChannelMask>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x30, Type: StructProperty)
    TEnumAsByte<FoliageVertexColorMask> VertexColorMask() const { return Read<TEnumAsByte<FoliageVertexColorMask>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: ByteProperty)
    float VertexColorMaskThreshold() const { return Read<float>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: FloatProperty)
    bool VertexColorMaskInvert() const { return (Read<uint8_t>(uintptr_t(this) + 0xa0) >> 0x0) & 1; } // 0xa0:0 (Size: 0x1, Type: BoolProperty)
    FFloatInterval ZOffset() const { return Read<FFloatInterval>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x8, Type: StructProperty)
    bool AlignToNormal() const { return (Read<uint8_t>(uintptr_t(this) + 0xac) >> 0x0) & 1; } // 0xac:0 (Size: 0x1, Type: BoolProperty)
    bool AverageNormal() const { return (Read<uint8_t>(uintptr_t(this) + 0xac) >> 0x1) & 1; } // 0xac:1 (Size: 0x1, Type: BoolProperty)
    bool AverageNormalSingleComponent() const { return (Read<uint8_t>(uintptr_t(this) + 0xac) >> 0x2) & 1; } // 0xac:2 (Size: 0x1, Type: BoolProperty)
    float AlignMaxAngle() const { return Read<float>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    bool RandomYaw() const { return (Read<uint8_t>(uintptr_t(this) + 0xb4) >> 0x0) & 1; } // 0xb4:0 (Size: 0x1, Type: BoolProperty)
    float RandomPitchAngle() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    FFloatInterval GroundSlopeAngle() const { return Read<FFloatInterval>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x8, Type: StructProperty)
    FFloatInterval Height() const { return Read<FFloatInterval>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x8, Type: StructProperty)
    TArray<FName> LandscapeLayers() const { return Read<TArray<FName>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    float MinimumLayerWeight() const { return Read<float>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: FloatProperty)
    TArray<FName> ExclusionLandscapeLayers() const { return Read<TArray<FName>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
    float MinimumExclusionLayerWeight() const { return Read<float>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    FName LandscapeLayer() const { return Read<FName>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x4, Type: NameProperty)
    bool CollisionWithWorld() const { return (Read<uint8_t>(uintptr_t(this) + 0x100) >> 0x0) & 1; } // 0x100:0 (Size: 0x1, Type: BoolProperty)
    FVector CollisionScale() const { return Read<FVector>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x18, Type: StructProperty)
    int32_t AverageNormalSampleCount() const { return Read<int32_t>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: IntProperty)
    FBoxSphereBounds MeshBounds() const { return Read<FBoxSphereBounds>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x38, Type: StructProperty)
    FVector LowBoundOriginRadius() const { return Read<FVector>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<EComponentMobility> Mobility() const { return Read<TEnumAsByte<EComponentMobility>>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x1, Type: ByteProperty)
    FInt32Interval CullDistance() const { return Read<FInt32Interval>(uintptr_t(this) + 0x17c); } // 0x17c (Size: 0x8, Type: StructProperty)
    bool bEnableStaticLighting() const { return (Read<uint8_t>(uintptr_t(this) + 0x184) >> 0x0) & 1; } // 0x184:0 (Size: 0x1, Type: BoolProperty)
    bool CastShadow() const { return (Read<uint8_t>(uintptr_t(this) + 0x184) >> 0x1) & 1; } // 0x184:1 (Size: 0x1, Type: BoolProperty)
    bool bAffectDynamicIndirectLighting() const { return (Read<uint8_t>(uintptr_t(this) + 0x184) >> 0x2) & 1; } // 0x184:2 (Size: 0x1, Type: BoolProperty)
    bool bAffectDistanceFieldLighting() const { return (Read<uint8_t>(uintptr_t(this) + 0x184) >> 0x3) & 1; } // 0x184:3 (Size: 0x1, Type: BoolProperty)
    bool bCastDynamicShadow() const { return (Read<uint8_t>(uintptr_t(this) + 0x184) >> 0x4) & 1; } // 0x184:4 (Size: 0x1, Type: BoolProperty)
    bool bCastStaticShadow() const { return (Read<uint8_t>(uintptr_t(this) + 0x184) >> 0x5) & 1; } // 0x184:5 (Size: 0x1, Type: BoolProperty)
    bool bCastContactShadow() const { return (Read<uint8_t>(uintptr_t(this) + 0x188) >> 0x0) & 1; } // 0x188:0 (Size: 0x1, Type: BoolProperty)
    bool bCastShadowAsTwoSided() const { return (Read<uint8_t>(uintptr_t(this) + 0x18c) >> 0x0) & 1; } // 0x18c:0 (Size: 0x1, Type: BoolProperty)
    bool bReceivesDecals() const { return (Read<uint8_t>(uintptr_t(this) + 0x18c) >> 0x1) & 1; } // 0x18c:1 (Size: 0x1, Type: BoolProperty)
    bool bOverrideLightMapRes() const { return (Read<uint8_t>(uintptr_t(this) + 0x18c) >> 0x2) & 1; } // 0x18c:2 (Size: 0x1, Type: BoolProperty)
    uint8_t ShadowCacheInvalidationBehavior() const { return Read<uint8_t>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x1, Type: EnumProperty)
    int32_t OverriddenLightMapRes() const { return Read<int32_t>(uintptr_t(this) + 0x194); } // 0x194 (Size: 0x4, Type: IntProperty)
    uint8_t LightmapType() const { return Read<uint8_t>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x1, Type: EnumProperty)
    bool bUseAsOccluder() const { return (Read<uint8_t>(uintptr_t(this) + 0x19c) >> 0x0) & 1; } // 0x19c:0 (Size: 0x1, Type: BoolProperty)
    bool bVisibleInRayTracing() const { return (Read<uint8_t>(uintptr_t(this) + 0x1a0) >> 0x0) & 1; } // 0x1a0:0 (Size: 0x1, Type: BoolProperty)
    bool bEvaluateWorldPositionOffset() const { return (Read<uint8_t>(uintptr_t(this) + 0x1a0) >> 0x1) & 1; } // 0x1a0:1 (Size: 0x1, Type: BoolProperty)
    int32_t WorldPositionOffsetDisableDistance() const { return Read<int32_t>(uintptr_t(this) + 0x1a4); } // 0x1a4 (Size: 0x4, Type: IntProperty)
    FBodyInstance BodyInstance() const { return Read<FBodyInstance>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x178, Type: StructProperty)
    TEnumAsByte<EHasCustomNavigableGeometry> CustomNavigableGeometry() const { return Read<TEnumAsByte<EHasCustomNavigableGeometry>>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x1, Type: ByteProperty)
    FLightingChannels LightingChannels() const { return Read<FLightingChannels>(uintptr_t(this) + 0x321); } // 0x321 (Size: 0x1, Type: StructProperty)
    bool bRenderCustomDepth() const { return (Read<uint8_t>(uintptr_t(this) + 0x324) >> 0x0) & 1; } // 0x324:0 (Size: 0x1, Type: BoolProperty)
    uint8_t CustomDepthStencilWriteMask() const { return Read<uint8_t>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x1, Type: EnumProperty)
    int32_t CustomDepthStencilValue() const { return Read<int32_t>(uintptr_t(this) + 0x32c); } // 0x32c (Size: 0x4, Type: IntProperty)
    int32_t TranslucencySortPriority() const { return Read<int32_t>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x4, Type: IntProperty)
    float CollisionRadius() const { return Read<float>(uintptr_t(this) + 0x334); } // 0x334 (Size: 0x4, Type: FloatProperty)
    float ShadeRadius() const { return Read<float>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x4, Type: FloatProperty)
    int32_t NumSteps() const { return Read<int32_t>(uintptr_t(this) + 0x33c); } // 0x33c (Size: 0x4, Type: IntProperty)
    float InitialSeedDensity() const { return Read<float>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x4, Type: FloatProperty)
    float AverageSpreadDistance() const { return Read<float>(uintptr_t(this) + 0x344); } // 0x344 (Size: 0x4, Type: FloatProperty)
    float SpreadVariance() const { return Read<float>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x4, Type: FloatProperty)
    int32_t SeedsPerStep() const { return Read<int32_t>(uintptr_t(this) + 0x34c); } // 0x34c (Size: 0x4, Type: IntProperty)
    int32_t DistributionSeed() const { return Read<int32_t>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x4, Type: IntProperty)
    float MaxInitialSeedOffset() const { return Read<float>(uintptr_t(this) + 0x354); } // 0x354 (Size: 0x4, Type: FloatProperty)
    bool bCanGrowInShade() const { return Read<bool>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x1, Type: BoolProperty)
    bool bSpawnsInShade() const { return Read<bool>(uintptr_t(this) + 0x359); } // 0x359 (Size: 0x1, Type: BoolProperty)
    float MaxInitialAge() const { return Read<float>(uintptr_t(this) + 0x35c); } // 0x35c (Size: 0x4, Type: FloatProperty)
    float MaxAge() const { return Read<float>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x4, Type: FloatProperty)
    float OverlapPriority() const { return Read<float>(uintptr_t(this) + 0x364); } // 0x364 (Size: 0x4, Type: FloatProperty)
    FFloatInterval ProceduralScale() const { return Read<FFloatInterval>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: StructProperty)
    FRuntimeFloatCurve ScaleCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x88, Type: StructProperty)
    FFoliageDensityFalloff DensityFalloff() const { return Read<FFoliageDensityFalloff>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x90, Type: StructProperty)
    int32_t ChangeCount() const { return Read<int32_t>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x4, Type: IntProperty)
    bool ReapplyDensity() const { return (Read<uint8_t>(uintptr_t(this) + 0x48c) >> 0x0) & 1; } // 0x48c:0 (Size: 0x1, Type: BoolProperty)
    bool ReapplyRadius() const { return (Read<uint8_t>(uintptr_t(this) + 0x48c) >> 0x1) & 1; } // 0x48c:1 (Size: 0x1, Type: BoolProperty)
    bool ReapplyAlignToNormal() const { return (Read<uint8_t>(uintptr_t(this) + 0x48c) >> 0x2) & 1; } // 0x48c:2 (Size: 0x1, Type: BoolProperty)
    bool ReapplyRandomYaw() const { return (Read<uint8_t>(uintptr_t(this) + 0x48c) >> 0x3) & 1; } // 0x48c:3 (Size: 0x1, Type: BoolProperty)
    bool ReapplyScaling() const { return (Read<uint8_t>(uintptr_t(this) + 0x48c) >> 0x4) & 1; } // 0x48c:4 (Size: 0x1, Type: BoolProperty)
    bool ReapplyScaleX() const { return (Read<uint8_t>(uintptr_t(this) + 0x48c) >> 0x5) & 1; } // 0x48c:5 (Size: 0x1, Type: BoolProperty)
    bool ReapplyScaleY() const { return (Read<uint8_t>(uintptr_t(this) + 0x48c) >> 0x6) & 1; } // 0x48c:6 (Size: 0x1, Type: BoolProperty)
    bool ReapplyScaleZ() const { return (Read<uint8_t>(uintptr_t(this) + 0x48c) >> 0x7) & 1; } // 0x48c:7 (Size: 0x1, Type: BoolProperty)
    bool ReapplyRandomPitchAngle() const { return (Read<uint8_t>(uintptr_t(this) + 0x48d) >> 0x0) & 1; } // 0x48d:0 (Size: 0x1, Type: BoolProperty)
    bool ReapplyGroundSlope() const { return (Read<uint8_t>(uintptr_t(this) + 0x48d) >> 0x1) & 1; } // 0x48d:1 (Size: 0x1, Type: BoolProperty)
    bool ReapplyHeight() const { return (Read<uint8_t>(uintptr_t(this) + 0x48d) >> 0x2) & 1; } // 0x48d:2 (Size: 0x1, Type: BoolProperty)
    bool ReapplyLandscapeLayers() const { return (Read<uint8_t>(uintptr_t(this) + 0x48d) >> 0x3) & 1; } // 0x48d:3 (Size: 0x1, Type: BoolProperty)
    bool ReapplyZOffset() const { return (Read<uint8_t>(uintptr_t(this) + 0x48d) >> 0x4) & 1; } // 0x48d:4 (Size: 0x1, Type: BoolProperty)
    bool ReapplyCollisionWithWorld() const { return (Read<uint8_t>(uintptr_t(this) + 0x48d) >> 0x5) & 1; } // 0x48d:5 (Size: 0x1, Type: BoolProperty)
    bool ReapplyVertexColorMask() const { return (Read<uint8_t>(uintptr_t(this) + 0x48d) >> 0x6) & 1; } // 0x48d:6 (Size: 0x1, Type: BoolProperty)
    bool bEnableDensityScaling() const { return (Read<uint8_t>(uintptr_t(this) + 0x48d) >> 0x7) & 1; } // 0x48d:7 (Size: 0x1, Type: BoolProperty)
    bool bEnableDiscardOnLoad() const { return (Read<uint8_t>(uintptr_t(this) + 0x48e) >> 0x0) & 1; } // 0x48e:0 (Size: 0x1, Type: BoolProperty)
    bool bEnableCullDistanceScaling() const { return (Read<uint8_t>(uintptr_t(this) + 0x48e) >> 0x1) & 1; } // 0x48e:1 (Size: 0x1, Type: BoolProperty)
    TArray<URuntimeVirtualTexture*> RuntimeVirtualTextures() const { return Read<TArray<URuntimeVirtualTexture*>>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x10, Type: ArrayProperty)
    int32_t VirtualTextureCullMips() const { return Read<int32_t>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x4, Type: IntProperty)
    uint8_t VirtualTextureRenderPassType() const { return Read<uint8_t>(uintptr_t(this) + 0x4a4); } // 0x4a4 (Size: 0x1, Type: EnumProperty)

    void SET_UpdateGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_Density(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_DensityAdjustmentFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_bSingleInstanceModeOverrideRadius(const bool& Value) { Write<bool>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x1, Type: BoolProperty)
    void SET_SingleInstanceModeRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_Scaling(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x1, Type: EnumProperty)
    void SET_ScaleX(const FFloatInterval& Value) { Write<FFloatInterval>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: StructProperty)
    void SET_ScaleY(const FFloatInterval& Value) { Write<FFloatInterval>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: StructProperty)
    void SET_ScaleZ(const FFloatInterval& Value) { Write<FFloatInterval>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: StructProperty)
    void SET_VertexColorMaskByChannel(const FFoliageVertexColorChannelMask& Value) { Write<FFoliageVertexColorChannelMask>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x30, Type: StructProperty)
    void SET_VertexColorMask(const TEnumAsByte<FoliageVertexColorMask>& Value) { Write<TEnumAsByte<FoliageVertexColorMask>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: ByteProperty)
    void SET_VertexColorMaskThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: FloatProperty)
    void SET_VertexColorMaskInvert(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xa0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xa0, B); } // 0xa0:0 (Size: 0x1, Type: BoolProperty)
    void SET_ZOffset(const FFloatInterval& Value) { Write<FFloatInterval>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x8, Type: StructProperty)
    void SET_AlignToNormal(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xac); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xac, B); } // 0xac:0 (Size: 0x1, Type: BoolProperty)
    void SET_AverageNormal(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xac); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0xac, B); } // 0xac:1 (Size: 0x1, Type: BoolProperty)
    void SET_AverageNormalSingleComponent(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xac); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0xac, B); } // 0xac:2 (Size: 0x1, Type: BoolProperty)
    void SET_AlignMaxAngle(const float& Value) { Write<float>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    void SET_RandomYaw(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xb4); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xb4, B); } // 0xb4:0 (Size: 0x1, Type: BoolProperty)
    void SET_RandomPitchAngle(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_GroundSlopeAngle(const FFloatInterval& Value) { Write<FFloatInterval>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x8, Type: StructProperty)
    void SET_Height(const FFloatInterval& Value) { Write<FFloatInterval>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x8, Type: StructProperty)
    void SET_LandscapeLayers(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    void SET_MinimumLayerWeight(const float& Value) { Write<float>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: FloatProperty)
    void SET_ExclusionLandscapeLayers(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
    void SET_MinimumExclusionLayerWeight(const float& Value) { Write<float>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    void SET_LandscapeLayer(const FName& Value) { Write<FName>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x4, Type: NameProperty)
    void SET_CollisionWithWorld(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x100); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x100, B); } // 0x100:0 (Size: 0x1, Type: BoolProperty)
    void SET_CollisionScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x18, Type: StructProperty)
    void SET_AverageNormalSampleCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: IntProperty)
    void SET_MeshBounds(const FBoxSphereBounds& Value) { Write<FBoxSphereBounds>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x38, Type: StructProperty)
    void SET_LowBoundOriginRadius(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x18, Type: StructProperty)
    void SET_Mobility(const TEnumAsByte<EComponentMobility>& Value) { Write<TEnumAsByte<EComponentMobility>>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x1, Type: ByteProperty)
    void SET_CullDistance(const FInt32Interval& Value) { Write<FInt32Interval>(uintptr_t(this) + 0x17c, Value); } // 0x17c (Size: 0x8, Type: StructProperty)
    void SET_bEnableStaticLighting(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x184); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x184, B); } // 0x184:0 (Size: 0x1, Type: BoolProperty)
    void SET_CastShadow(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x184); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x184, B); } // 0x184:1 (Size: 0x1, Type: BoolProperty)
    void SET_bAffectDynamicIndirectLighting(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x184); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x184, B); } // 0x184:2 (Size: 0x1, Type: BoolProperty)
    void SET_bAffectDistanceFieldLighting(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x184); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x184, B); } // 0x184:3 (Size: 0x1, Type: BoolProperty)
    void SET_bCastDynamicShadow(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x184); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x184, B); } // 0x184:4 (Size: 0x1, Type: BoolProperty)
    void SET_bCastStaticShadow(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x184); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x184, B); } // 0x184:5 (Size: 0x1, Type: BoolProperty)
    void SET_bCastContactShadow(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x188); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x188, B); } // 0x188:0 (Size: 0x1, Type: BoolProperty)
    void SET_bCastShadowAsTwoSided(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x18c); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x18c, B); } // 0x18c:0 (Size: 0x1, Type: BoolProperty)
    void SET_bReceivesDecals(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x18c); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x18c, B); } // 0x18c:1 (Size: 0x1, Type: BoolProperty)
    void SET_bOverrideLightMapRes(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x18c); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x18c, B); } // 0x18c:2 (Size: 0x1, Type: BoolProperty)
    void SET_ShadowCacheInvalidationBehavior(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x1, Type: EnumProperty)
    void SET_OverriddenLightMapRes(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x194, Value); } // 0x194 (Size: 0x4, Type: IntProperty)
    void SET_LightmapType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x1, Type: EnumProperty)
    void SET_bUseAsOccluder(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x19c); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x19c, B); } // 0x19c:0 (Size: 0x1, Type: BoolProperty)
    void SET_bVisibleInRayTracing(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1a0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1a0, B); } // 0x1a0:0 (Size: 0x1, Type: BoolProperty)
    void SET_bEvaluateWorldPositionOffset(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1a0); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x1a0, B); } // 0x1a0:1 (Size: 0x1, Type: BoolProperty)
    void SET_WorldPositionOffsetDisableDistance(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1a4, Value); } // 0x1a4 (Size: 0x4, Type: IntProperty)
    void SET_BodyInstance(const FBodyInstance& Value) { Write<FBodyInstance>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x178, Type: StructProperty)
    void SET_CustomNavigableGeometry(const TEnumAsByte<EHasCustomNavigableGeometry>& Value) { Write<TEnumAsByte<EHasCustomNavigableGeometry>>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x1, Type: ByteProperty)
    void SET_LightingChannels(const FLightingChannels& Value) { Write<FLightingChannels>(uintptr_t(this) + 0x321, Value); } // 0x321 (Size: 0x1, Type: StructProperty)
    void SET_bRenderCustomDepth(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x324); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x324, B); } // 0x324:0 (Size: 0x1, Type: BoolProperty)
    void SET_CustomDepthStencilWriteMask(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x1, Type: EnumProperty)
    void SET_CustomDepthStencilValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x32c, Value); } // 0x32c (Size: 0x4, Type: IntProperty)
    void SET_TranslucencySortPriority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x4, Type: IntProperty)
    void SET_CollisionRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x334, Value); } // 0x334 (Size: 0x4, Type: FloatProperty)
    void SET_ShadeRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x4, Type: FloatProperty)
    void SET_NumSteps(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x33c, Value); } // 0x33c (Size: 0x4, Type: IntProperty)
    void SET_InitialSeedDensity(const float& Value) { Write<float>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x4, Type: FloatProperty)
    void SET_AverageSpreadDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x344, Value); } // 0x344 (Size: 0x4, Type: FloatProperty)
    void SET_SpreadVariance(const float& Value) { Write<float>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x4, Type: FloatProperty)
    void SET_SeedsPerStep(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x34c, Value); } // 0x34c (Size: 0x4, Type: IntProperty)
    void SET_DistributionSeed(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x4, Type: IntProperty)
    void SET_MaxInitialSeedOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x354, Value); } // 0x354 (Size: 0x4, Type: FloatProperty)
    void SET_bCanGrowInShade(const bool& Value) { Write<bool>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x1, Type: BoolProperty)
    void SET_bSpawnsInShade(const bool& Value) { Write<bool>(uintptr_t(this) + 0x359, Value); } // 0x359 (Size: 0x1, Type: BoolProperty)
    void SET_MaxInitialAge(const float& Value) { Write<float>(uintptr_t(this) + 0x35c, Value); } // 0x35c (Size: 0x4, Type: FloatProperty)
    void SET_MaxAge(const float& Value) { Write<float>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x4, Type: FloatProperty)
    void SET_OverlapPriority(const float& Value) { Write<float>(uintptr_t(this) + 0x364, Value); } // 0x364 (Size: 0x4, Type: FloatProperty)
    void SET_ProceduralScale(const FFloatInterval& Value) { Write<FFloatInterval>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: StructProperty)
    void SET_ScaleCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x88, Type: StructProperty)
    void SET_DensityFalloff(const FFoliageDensityFalloff& Value) { Write<FFoliageDensityFalloff>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x90, Type: StructProperty)
    void SET_ChangeCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x4, Type: IntProperty)
    void SET_ReapplyDensity(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48c); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x48c, B); } // 0x48c:0 (Size: 0x1, Type: BoolProperty)
    void SET_ReapplyRadius(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48c); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x48c, B); } // 0x48c:1 (Size: 0x1, Type: BoolProperty)
    void SET_ReapplyAlignToNormal(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48c); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x48c, B); } // 0x48c:2 (Size: 0x1, Type: BoolProperty)
    void SET_ReapplyRandomYaw(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48c); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x48c, B); } // 0x48c:3 (Size: 0x1, Type: BoolProperty)
    void SET_ReapplyScaling(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48c); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x48c, B); } // 0x48c:4 (Size: 0x1, Type: BoolProperty)
    void SET_ReapplyScaleX(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48c); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x48c, B); } // 0x48c:5 (Size: 0x1, Type: BoolProperty)
    void SET_ReapplyScaleY(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48c); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x48c, B); } // 0x48c:6 (Size: 0x1, Type: BoolProperty)
    void SET_ReapplyScaleZ(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48c); B = (B & ~(1 << 0x7)) | (Value << 0x7); Write<uint8_t>(uintptr_t(this) + 0x48c, B); } // 0x48c:7 (Size: 0x1, Type: BoolProperty)
    void SET_ReapplyRandomPitchAngle(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48d); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x48d, B); } // 0x48d:0 (Size: 0x1, Type: BoolProperty)
    void SET_ReapplyGroundSlope(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48d); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x48d, B); } // 0x48d:1 (Size: 0x1, Type: BoolProperty)
    void SET_ReapplyHeight(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48d); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x48d, B); } // 0x48d:2 (Size: 0x1, Type: BoolProperty)
    void SET_ReapplyLandscapeLayers(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48d); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x48d, B); } // 0x48d:3 (Size: 0x1, Type: BoolProperty)
    void SET_ReapplyZOffset(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48d); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x48d, B); } // 0x48d:4 (Size: 0x1, Type: BoolProperty)
    void SET_ReapplyCollisionWithWorld(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48d); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x48d, B); } // 0x48d:5 (Size: 0x1, Type: BoolProperty)
    void SET_ReapplyVertexColorMask(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48d); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x48d, B); } // 0x48d:6 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableDensityScaling(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48d); B = (B & ~(1 << 0x7)) | (Value << 0x7); Write<uint8_t>(uintptr_t(this) + 0x48d, B); } // 0x48d:7 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableDiscardOnLoad(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48e); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x48e, B); } // 0x48e:0 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableCullDistanceScaling(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48e); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x48e, B); } // 0x48e:1 (Size: 0x1, Type: BoolProperty)
    void SET_RuntimeVirtualTextures(const TArray<URuntimeVirtualTexture*>& Value) { Write<TArray<URuntimeVirtualTexture*>>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x10, Type: ArrayProperty)
    void SET_VirtualTextureCullMips(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x4, Type: IntProperty)
    void SET_VirtualTextureRenderPassType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4a4, Value); } // 0x4a4 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x4c0
class UFoliageType_Actor : public UFoliageType
{
public:
    UClass* ActorClass() const { return Read<UClass*>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x8, Type: ClassProperty)
    bool bShouldAttachToBaseComponent() const { return Read<bool>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x1, Type: BoolProperty)
    bool bStaticMeshOnly() const { return Read<bool>(uintptr_t(this) + 0x4b1); } // 0x4b1 (Size: 0x1, Type: BoolProperty)
    UClass* StaticMeshOnlyComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: ClassProperty)

    void SET_ActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x8, Type: ClassProperty)
    void SET_bShouldAttachToBaseComponent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x1, Type: BoolProperty)
    void SET_bStaticMeshOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4b1, Value); } // 0x4b1 (Size: 0x1, Type: BoolProperty)
    void SET_StaticMeshOnlyComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x4d8
class UFoliageType_InstancedStaticMesh : public UFoliageType
{
public:
    UStaticMesh* Mesh() const { return Read<UStaticMesh*>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    TArray<UMaterialInterface*> OverrideMaterials() const { return Read<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInterface*> NaniteOverrideMaterials() const { return Read<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x10, Type: ArrayProperty)
    UClass* ComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x8, Type: ClassProperty)

    void SET_Mesh(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    void SET_OverrideMaterials(const TArray<UMaterialInterface*>& Value) { Write<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x10, Type: ArrayProperty)
    void SET_NaniteOverrideMaterials(const TArray<UMaterialInterface*>& Value) { Write<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x10, Type: ArrayProperty)
    void SET_ComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x308
class AInstancedFoliageActor : public AISMPartitionActor
{
public:
};

// Size: 0x610
class UInteractiveFoliageComponent : public UStaticMeshComponent
{
public:
};

// Size: 0x28
class UFoliageStatistics : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0xb40
class UGrassInstancedStaticMeshComponent : public UHierarchicalInstancedStaticMeshComponent
{
public:
};

// Size: 0x348
class AInteractiveFoliageActor : public AStaticMeshActor
{
public:
    UCapsuleComponent* CapsuleComponent() const { return Read<UCapsuleComponent*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    FVector TouchingActorEntryPosition() const { return Read<FVector>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x18, Type: StructProperty)
    FVector FoliageVelocity() const { return Read<FVector>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x18, Type: StructProperty)
    FVector FoliageForce() const { return Read<FVector>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x18, Type: StructProperty)
    FVector FoliagePosition() const { return Read<FVector>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x18, Type: StructProperty)
    float FoliageDamageImpulseScale() const { return Read<float>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x4, Type: FloatProperty)
    float FoliageTouchImpulseScale() const { return Read<float>(uintptr_t(this) + 0x324); } // 0x324 (Size: 0x4, Type: FloatProperty)
    float FoliageStiffness() const { return Read<float>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x4, Type: FloatProperty)
    float FoliageStiffnessQuadratic() const { return Read<float>(uintptr_t(this) + 0x32c); } // 0x32c (Size: 0x4, Type: FloatProperty)
    float FoliageDamping() const { return Read<float>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x4, Type: FloatProperty)
    float MaxDamageImpulse() const { return Read<float>(uintptr_t(this) + 0x334); } // 0x334 (Size: 0x4, Type: FloatProperty)
    float MaxTouchImpulse() const { return Read<float>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x4, Type: FloatProperty)
    float MaxForce() const { return Read<float>(uintptr_t(this) + 0x33c); } // 0x33c (Size: 0x4, Type: FloatProperty)
    float Mass() const { return Read<float>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x4, Type: FloatProperty)

    void SET_CapsuleComponent(const UCapsuleComponent*& Value) { Write<UCapsuleComponent*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_TouchingActorEntryPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x18, Type: StructProperty)
    void SET_FoliageVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x18, Type: StructProperty)
    void SET_FoliageForce(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x18, Type: StructProperty)
    void SET_FoliagePosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x18, Type: StructProperty)
    void SET_FoliageDamageImpulseScale(const float& Value) { Write<float>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x4, Type: FloatProperty)
    void SET_FoliageTouchImpulseScale(const float& Value) { Write<float>(uintptr_t(this) + 0x324, Value); } // 0x324 (Size: 0x4, Type: FloatProperty)
    void SET_FoliageStiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x4, Type: FloatProperty)
    void SET_FoliageStiffnessQuadratic(const float& Value) { Write<float>(uintptr_t(this) + 0x32c, Value); } // 0x32c (Size: 0x4, Type: FloatProperty)
    void SET_FoliageDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x4, Type: FloatProperty)
    void SET_MaxDamageImpulse(const float& Value) { Write<float>(uintptr_t(this) + 0x334, Value); } // 0x334 (Size: 0x4, Type: FloatProperty)
    void SET_MaxTouchImpulse(const float& Value) { Write<float>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x4, Type: FloatProperty)
    void SET_MaxForce(const float& Value) { Write<float>(uintptr_t(this) + 0x33c, Value); } // 0x33c (Size: 0x4, Type: FloatProperty)
    void SET_Mass(const float& Value) { Write<float>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x378
class AProceduralFoliageBlockingVolume : public AVolume
{
public:
    AProceduralFoliageVolume* ProceduralFoliageVolume() const { return Read<AProceduralFoliageVolume*>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    FFoliageDensityFalloff DensityFalloff() const { return Read<FFoliageDensityFalloff>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x90, Type: StructProperty)

    void SET_ProceduralFoliageVolume(const AProceduralFoliageVolume*& Value) { Write<AProceduralFoliageVolume*>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    void SET_DensityFalloff(const FFoliageDensityFalloff& Value) { Write<FFoliageDensityFalloff>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x90, Type: StructProperty)
};

// Size: 0xe0
class UProceduralFoliageComponent : public UActorComponent
{
public:
    UProceduralFoliageSpawner* FoliageSpawner() const { return Read<UProceduralFoliageSpawner*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    float TileOverlap() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    AVolume* SpawningVolume() const { return Read<AVolume*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    FGuid ProceduralGuid() const { return Read<FGuid>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: StructProperty)

    void SET_FoliageSpawner(const UProceduralFoliageSpawner*& Value) { Write<UProceduralFoliageSpawner*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_TileOverlap(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_SpawningVolume(const AVolume*& Value) { Write<AVolume*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_ProceduralGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x80
class UProceduralFoliageSpawner : public UObject
{
public:
    int32_t RandomSeed() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    float TileSize() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    int32_t NumUniqueTiles() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    float MinimumQuadTreeSize() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    TArray<FFoliageTypeObject> FoliageTypes() const { return Read<TArray<FFoliageTypeObject>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    bool bUseOverrideFoliageTerrainMaterials() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    TArray<TSoftObjectPtr<UMaterialInterface*>> OverrideFoliageTerrainMaterials() const { return Read<TArray<TSoftObjectPtr<UMaterialInterface*>>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)

    void SET_RandomSeed(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_TileSize(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_NumUniqueTiles(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_MinimumQuadTreeSize(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_FoliageTypes(const TArray<FFoliageTypeObject>& Value) { Write<TArray<FFoliageTypeObject>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_bUseOverrideFoliageTerrainMaterials(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_OverrideFoliageTerrainMaterials(const TArray<TSoftObjectPtr<UMaterialInterface*>>& Value) { Write<TArray<TSoftObjectPtr<UMaterialInterface*>>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x170
class UProceduralFoliageTile : public UObject
{
public:
    UProceduralFoliageSpawner* FoliageSpawner() const { return Read<UProceduralFoliageSpawner*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    TArray<FProceduralFoliageInstance> InstancesArray() const { return Read<TArray<FProceduralFoliageInstance>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: ArrayProperty)

    void SET_FoliageSpawner(const UProceduralFoliageSpawner*& Value) { Write<UProceduralFoliageSpawner*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_InstancesArray(const TArray<FProceduralFoliageInstance>& Value) { Write<TArray<FProceduralFoliageInstance>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2f0
class AProceduralFoliageVolume : public AVolume
{
public:
    UProceduralFoliageComponent* ProceduralComponent() const { return Read<UProceduralFoliageComponent*>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)

    void SET_ProceduralComponent(const UProceduralFoliageComponent*& Value) { Write<UProceduralFoliageComponent*>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc
struct FFoliageVertexColorChannelMask
{
public:
    bool UseMask() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x0) & 1; } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    float MaskThreshold() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    bool InvertMask() const { return (Read<uint8_t>(uintptr_t(this) + 0x8) >> 0x0) & 1; } // 0x8:0 (Size: 0x1, Type: BoolProperty)

    void SET_UseMask(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    void SET_MaskThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_InvertMask(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x8); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x8, B); } // 0x8:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x90
struct FFoliageDensityFalloff
{
public:
    bool bUseFalloffCurve() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    FRuntimeFloatCurve FalloffCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x88, Type: StructProperty)

    void SET_bUseFalloffCurve(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_FalloffCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x88, Type: StructProperty)
};

// Size: 0x20
struct FFoliageTypeObject
{
public:
    UObject* FoliageTypeObject() const { return Read<UObject*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UFoliageType* TypeInstance() const { return Read<UFoliageType*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    bool bIsAsset() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    UClass* Type() const { return Read<UClass*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ClassProperty)

    void SET_FoliageTypeObject(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_TypeInstance(const UFoliageType*& Value) { Write<UFoliageType*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsAsset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_Type(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x80
struct FProceduralFoliageInstance
{
public:
    FQuat Rotation() const { return Read<FQuat>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    float Age() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    FVector Normal() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    UFoliageType* Type() const { return Read<UFoliageType*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)

    void SET_Rotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Age(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_Normal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_Type(const UFoliageType*& Value) { Write<UFoliageType*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
};

