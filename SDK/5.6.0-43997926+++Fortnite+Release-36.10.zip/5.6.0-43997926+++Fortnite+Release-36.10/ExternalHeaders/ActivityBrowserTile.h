/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserTile
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x15d0
class UActivityBrowserTile_C : public UFortActivityBrowserTile
{
public:
};

