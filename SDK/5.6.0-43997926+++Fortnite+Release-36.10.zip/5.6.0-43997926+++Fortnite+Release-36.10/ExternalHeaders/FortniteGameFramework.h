/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteGameFramework
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "StateTreeModule.h"

// Size: 0x398
class AFGF_PlayerState : public APlayerState
{
public:
};

// Size: 0x770
class AFGF_PlayerController : public APlayerController
{
public:
};

// Size: 0x670
class AFGF_Character : public ACharacter
{
public:
};

// Size: 0x3c0
class AFGF_GameMode : public AGameMode
{
public:
};

// Size: 0x360
class AFGF_GameState : public AGameState
{
public:
    bool bIsObjectTrackingEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x358) >> 0x0) & 1; } // 0x358:0 (Size: 0x1, Type: BoolProperty)

    void SET_bIsObjectTrackingEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x358); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x358, B); } // 0x358:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UObjectBasedStateTreeSchema : public UStateTreeSchema
{
public:
};

// Size: 0x1f8
class UStateTreeManagerComponent : public UActorComponent
{
public:
    TArray<FStateTreeRuntimeData> StateTreeRuntimeDataList() const { return Read<TArray<FStateTreeRuntimeData>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TArray<FStateTreeClientSimulationData> SimulatedDataList() const { return Read<TArray<FStateTreeClientSimulationData>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    FStateChangeDataArray ReplicatedStateChanges() const { return Read<FStateChangeDataArray>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x120, Type: StructProperty)

    void SET_StateTreeRuntimeDataList(const TArray<FStateTreeRuntimeData>& Value) { Write<TArray<FStateTreeRuntimeData>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
    void SET_SimulatedDataList(const TArray<FStateTreeClientSimulationData>& Value) { Write<TArray<FStateTreeClientSimulationData>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    void SET_ReplicatedStateChanges(const FStateChangeDataArray& Value) { Write<FStateChangeDataArray>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x120, Type: StructProperty)
};

// Size: 0x68
class UStateTreeTaskObject : public UStateTreeTaskBlueprintBase
{
public:
    bool bReplicates() const { return Read<bool>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x1, Type: BoolProperty)

    void SET_bReplicates(const bool& Value) { Write<bool>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x38
struct FComponentCacheHelper
{
public:
};

// Size: 0x28
struct FActorOwnedStateTreeConfig
{
public:
    TSoftObjectPtr<UStateTree> StateTreeAsset() const { return Read<TSoftObjectPtr<UStateTree>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    bool bShouldReplicate() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_StateTreeAsset(const TSoftObjectPtr<UStateTree>& Value) { Write<TSoftObjectPtr<UStateTree>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_bShouldReplicate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FStateTreeRuntimeData
{
public:
    UObject* Owner() const { return Read<UObject*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UStateTree* StateTree() const { return Read<UStateTree*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FStateTreeInstanceData StateTreeInstanceData() const { return Read<FStateTreeInstanceData>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_Owner(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_StateTree(const UStateTree*& Value) { Write<UStateTree*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_StateTreeInstanceData(const FStateTreeInstanceData& Value) { Write<FStateTreeInstanceData>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x28
struct FStateChangeData : public FFastArraySerializerItem
{
public:
    int32_t StateTreeDataHandle() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    int32_t Handle() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t StateIdentifier() const { return Read<int32_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: IntProperty)
    UStateTreeTaskObject* StateObject() const { return Read<UStateTreeTaskObject*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    uint8_t StateChangeType() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)

    void SET_StateTreeDataHandle(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_Handle(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_StateIdentifier(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: IntProperty)
    void SET_StateObject(const UStateTreeTaskObject*& Value) { Write<UStateTreeTaskObject*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET_StateChangeType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x120
struct FStateChangeDataArray : public FFastArraySerializer
{
public:
    TArray<FStateChangeData> StateChangeDataList() const { return Read<TArray<FStateChangeData>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    UStateTreeManagerComponent* StateTreeManagerComponent() const { return Read<UStateTreeManagerComponent*>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: ObjectProperty)

    void SET_StateChangeDataList(const TArray<FStateChangeData>& Value) { Write<TArray<FStateChangeData>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    void SET_StateTreeManagerComponent(const UStateTreeManagerComponent*& Value) { Write<UStateTreeManagerComponent*>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FStateTreeClientSimulationData
{
public:
};

