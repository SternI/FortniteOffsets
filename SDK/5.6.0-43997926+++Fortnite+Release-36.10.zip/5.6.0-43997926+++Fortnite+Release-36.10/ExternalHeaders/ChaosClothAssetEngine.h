/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChaosClothAssetEngine
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "ClothingSystemRuntimeInterface.h"
#include "DataflowEngine.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "DataflowSimulation.h"
#include "ClothingSystemRuntimeCommon.h"

// Size: 0xa30
class UChaosClothComponent : public USkinnedMeshComponent
{
public:
    FDataflowSimulationAsset SimulationAsset() const { return Read<FDataflowSimulationAsset>(uintptr_t(this) + 0x8e0); } // 0x8e0 (Size: 0x58, Type: StructProperty)
    float BlendWeight() const { return Read<float>(uintptr_t(this) + 0x938); } // 0x938 (Size: 0x4, Type: FloatProperty)
    float ClothGeometryScale() const { return Read<float>(uintptr_t(this) + 0x93c); } // 0x93c (Size: 0x4, Type: FloatProperty)
    bool bUseAttachedParentAsPoseComponent() const { return (Read<uint8_t>(uintptr_t(this) + 0x940) >> 0x0) & 1; } // 0x940:0 (Size: 0x1, Type: BoolProperty)
    bool bWaitForParallelTask() const { return (Read<uint8_t>(uintptr_t(this) + 0x940) >> 0x1) & 1; } // 0x940:1 (Size: 0x1, Type: BoolProperty)
    bool bEnableSimulation() const { return (Read<uint8_t>(uintptr_t(this) + 0x940) >> 0x2) & 1; } // 0x940:2 (Size: 0x1, Type: BoolProperty)
    bool bSuspendSimulation() const { return (Read<uint8_t>(uintptr_t(this) + 0x940) >> 0x3) & 1; } // 0x940:3 (Size: 0x1, Type: BoolProperty)
    bool bBindToLeaderComponent() const { return (Read<uint8_t>(uintptr_t(this) + 0x940) >> 0x4) & 1; } // 0x940:4 (Size: 0x1, Type: BoolProperty)
    bool bTeleport() const { return (Read<uint8_t>(uintptr_t(this) + 0x940) >> 0x5) & 1; } // 0x940:5 (Size: 0x1, Type: BoolProperty)
    bool bReset() const { return (Read<uint8_t>(uintptr_t(this) + 0x940) >> 0x6) & 1; } // 0x940:6 (Size: 0x1, Type: BoolProperty)
    bool bCollideWithEnvironment() const { return (Read<uint8_t>(uintptr_t(this) + 0x940) >> 0x7) & 1; } // 0x940:7 (Size: 0x1, Type: BoolProperty)
    float TeleportDistanceThreshold() const { return Read<float>(uintptr_t(this) + 0x944); } // 0x944 (Size: 0x4, Type: FloatProperty)
    float TeleportRotationThreshold() const { return Read<float>(uintptr_t(this) + 0x948); } // 0x948 (Size: 0x4, Type: FloatProperty)
    TArray<FChaosClothSimulationProperties> ClothSimulationProperties() const { return Read<TArray<FChaosClothSimulationProperties>>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x10, Type: ArrayProperty)

    void SET_SimulationAsset(const FDataflowSimulationAsset& Value) { Write<FDataflowSimulationAsset>(uintptr_t(this) + 0x8e0, Value); } // 0x8e0 (Size: 0x58, Type: StructProperty)
    void SET_BlendWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x938, Value); } // 0x938 (Size: 0x4, Type: FloatProperty)
    void SET_ClothGeometryScale(const float& Value) { Write<float>(uintptr_t(this) + 0x93c, Value); } // 0x93c (Size: 0x4, Type: FloatProperty)
    void SET_bUseAttachedParentAsPoseComponent(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x940); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x940, B); } // 0x940:0 (Size: 0x1, Type: BoolProperty)
    void SET_bWaitForParallelTask(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x940); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x940, B); } // 0x940:1 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableSimulation(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x940); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x940, B); } // 0x940:2 (Size: 0x1, Type: BoolProperty)
    void SET_bSuspendSimulation(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x940); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x940, B); } // 0x940:3 (Size: 0x1, Type: BoolProperty)
    void SET_bBindToLeaderComponent(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x940); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x940, B); } // 0x940:4 (Size: 0x1, Type: BoolProperty)
    void SET_bTeleport(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x940); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x940, B); } // 0x940:5 (Size: 0x1, Type: BoolProperty)
    void SET_bReset(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x940); B = (B & ~(1 << 0x6)) | (Value << 0x6); Write<uint8_t>(uintptr_t(this) + 0x940, B); } // 0x940:6 (Size: 0x1, Type: BoolProperty)
    void SET_bCollideWithEnvironment(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x940); B = (B & ~(1 << 0x7)) | (Value << 0x7); Write<uint8_t>(uintptr_t(this) + 0x940, B); } // 0x940:7 (Size: 0x1, Type: BoolProperty)
    void SET_TeleportDistanceThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x944, Value); } // 0x944 (Size: 0x4, Type: FloatProperty)
    void SET_TeleportRotationThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x948, Value); } // 0x948 (Size: 0x4, Type: FloatProperty)
    void SET_ClothSimulationProperties(const TArray<FChaosClothSimulationProperties>& Value) { Write<TArray<FChaosClothSimulationProperties>>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UClothAssetSkeletalMeshConverter : public UObject
{
public:
};

// Size: 0x3b8
class UChaosClothAsset : public UChaosClothAssetBase
{
public:
    USkeleton* Skeleton() const { return Read<USkeleton*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    UPhysicsAsset* PhysicsAsset() const { return Read<UPhysicsAsset*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    bool bSmoothTransition() const { return Read<bool>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x1, Type: BoolProperty)
    bool bUseMultipleInfluences() const { return Read<bool>(uintptr_t(this) + 0x381); } // 0x381 (Size: 0x1, Type: BoolProperty)
    float SkinningKernelRadius() const { return Read<float>(uintptr_t(this) + 0x384); } // 0x384 (Size: 0x4, Type: FloatProperty)
    FGuid AssetGuid() const { return Read<FGuid>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x10, Type: StructProperty)

    void SET_Skeleton(const USkeleton*& Value) { Write<USkeleton*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_PhysicsAsset(const UPhysicsAsset*& Value) { Write<UPhysicsAsset*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_bSmoothTransition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x1, Type: BoolProperty)
    void SET_bUseMultipleInfluences(const bool& Value) { Write<bool>(uintptr_t(this) + 0x381, Value); } // 0x381 (Size: 0x1, Type: BoolProperty)
    void SET_SkinningKernelRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x384, Value); } // 0x384 (Size: 0x4, Type: FloatProperty)
    void SET_AssetGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x10, Type: StructProperty)
};

// Size: 0x370
class UChaosClothAssetBase : public USkinnedAsset
{
public:
    FDataflowInstance DataflowInstance() const { return Read<FDataflowInstance>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x40, Type: StructProperty)
    TArray<FSkeletalMaterial> Materials() const { return Read<TArray<FSkeletalMaterial>>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x10, Type: ArrayProperty)
    TArray<FSkeletalMeshLODInfo> LODInfo() const { return Read<TArray<FSkeletalMeshLODInfo>>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x10, Type: ArrayProperty)
    FPerQualityLevelInt MinQualityLevelLOD() const { return Read<FPerQualityLevelInt>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x68, Type: StructProperty)
    FPerPlatformBool DisableBelowMinLodStripping() const { return Read<FPerPlatformBool>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x1, Type: StructProperty)
    FPerPlatformInt MinLOD() const { return Read<FPerPlatformInt>(uintptr_t(this) + 0x1cc); } // 0x1cc (Size: 0x4, Type: StructProperty)
    bool bSupportRayTracing() const { return (Read<uint8_t>(uintptr_t(this) + 0x1d0) >> 0x0) & 1; } // 0x1d0:0 (Size: 0x1, Type: BoolProperty)
    int32_t RayTracingMinLOD() const { return Read<int32_t>(uintptr_t(this) + 0x1d4); } // 0x1d4 (Size: 0x4, Type: IntProperty)
    UPhysicsAsset* ShadowPhysicsAsset() const { return Read<UPhysicsAsset*>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* OverlayMaterial() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    float OverlayMaterialMaxDrawDistance() const { return Read<float>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x4, Type: FloatProperty)
    bool bHasVertexColors() const { return (Read<uint8_t>(uintptr_t(this) + 0x1ec) >> 0x0) & 1; } // 0x1ec:0 (Size: 0x1, Type: BoolProperty)
    FBoxSphereBounds Bounds() const { return Read<FBoxSphereBounds>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x38, Type: StructProperty)

    void SET_DataflowInstance(const FDataflowInstance& Value) { Write<FDataflowInstance>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x40, Type: StructProperty)
    void SET_Materials(const TArray<FSkeletalMaterial>& Value) { Write<TArray<FSkeletalMaterial>>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x10, Type: ArrayProperty)
    void SET_LODInfo(const TArray<FSkeletalMeshLODInfo>& Value) { Write<TArray<FSkeletalMeshLODInfo>>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x10, Type: ArrayProperty)
    void SET_MinQualityLevelLOD(const FPerQualityLevelInt& Value) { Write<FPerQualityLevelInt>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x68, Type: StructProperty)
    void SET_DisableBelowMinLodStripping(const FPerPlatformBool& Value) { Write<FPerPlatformBool>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x1, Type: StructProperty)
    void SET_MinLOD(const FPerPlatformInt& Value) { Write<FPerPlatformInt>(uintptr_t(this) + 0x1cc, Value); } // 0x1cc (Size: 0x4, Type: StructProperty)
    void SET_bSupportRayTracing(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1d0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1d0, B); } // 0x1d0:0 (Size: 0x1, Type: BoolProperty)
    void SET_RayTracingMinLOD(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1d4, Value); } // 0x1d4 (Size: 0x4, Type: IntProperty)
    void SET_ShadowPhysicsAsset(const UPhysicsAsset*& Value) { Write<UPhysicsAsset*>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    void SET_OverlayMaterial(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    void SET_OverlayMaterialMaxDrawDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x4, Type: FloatProperty)
    void SET_bHasVertexColors(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x1ec); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x1ec, B); } // 0x1ec:0 (Size: 0x1, Type: BoolProperty)
    void SET_Bounds(const FBoxSphereBounds& Value) { Write<FBoxSphereBounds>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x38, Type: StructProperty)
};

// Size: 0x38
class UChaosClothAssetInteractor : public UObject
{
public:
};

// Size: 0x28
struct FChaosClothSimulationProperties
{
public:
    UChaosClothAssetInteractor* ClothOutfitInteractor() const { return Read<UChaosClothAssetInteractor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_ClothOutfitInteractor(const UChaosClothAssetInteractor*& Value) { Write<UChaosClothAssetInteractor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x38
struct FChaosClothAssetLodTransitionDataCache
{
public:
};

// Size: 0x1f0
struct FChaosClothSimulationLodModel
{
public:
    TArray<FVector3f> Positions() const { return Read<TArray<FVector3f>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector3f> Normals() const { return Read<TArray<FVector3f>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<uint32_t> Indices() const { return Read<TArray<uint32_t>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FClothVertBoneData> BoneData() const { return Read<TArray<FClothVertBoneData>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<uint16_t> RequiredExtraBoneIndices() const { return Read<TArray<uint16_t>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector2f> PatternPositions() const { return Read<TArray<FVector2f>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<uint32_t> PatternIndices() const { return Read<TArray<uint32_t>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<uint32_t> PatternToWeldedIndices() const { return Read<TArray<uint32_t>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    FClothTetherData TetherData() const { return Read<FClothTetherData>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: StructProperty)

    void SET_Positions(const TArray<FVector3f>& Value) { Write<TArray<FVector3f>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Normals(const TArray<FVector3f>& Value) { Write<TArray<FVector3f>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Indices(const TArray<uint32_t>& Value) { Write<TArray<uint32_t>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_BoneData(const TArray<FClothVertBoneData>& Value) { Write<TArray<FClothVertBoneData>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_RequiredExtraBoneIndices(const TArray<uint16_t>& Value) { Write<TArray<uint16_t>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_PatternPositions(const TArray<FVector2f>& Value) { Write<TArray<FVector2f>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_PatternIndices(const TArray<uint32_t>& Value) { Write<TArray<uint32_t>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_PatternToWeldedIndices(const TArray<uint32_t>& Value) { Write<TArray<uint32_t>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    void SET_TetherData(const FClothTetherData& Value) { Write<FClothTetherData>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x38
struct FChaosClothSimulationModel
{
public:
    TArray<FChaosClothSimulationLodModel> ClothSimulationLodModels() const { return Read<TArray<FChaosClothSimulationLodModel>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> UsedBoneNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> UsedBoneIndices() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    int32_t ReferenceBoneIndex() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)

    void SET_ClothSimulationLodModels(const TArray<FChaosClothSimulationLodModel>& Value) { Write<TArray<FChaosClothSimulationLodModel>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_UsedBoneNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_UsedBoneIndices(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_ReferenceBoneIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
};

