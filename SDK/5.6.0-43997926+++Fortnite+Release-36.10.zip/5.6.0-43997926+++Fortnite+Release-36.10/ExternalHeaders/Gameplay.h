/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Gameplay
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Sounds.h"
#include "GameplayAbilities.h"
#include "Engine.h"
#include "Assets.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "CoreUObject.h"
#include "Niagara.h"
#include "RidingCodeRuntime.h"

// Size: 0x2040
class URiding_PlayerCameraMode_TacticalSprint_C : public UFortCameraMode_Riding
{
public:
};

// Size: 0xa68
class UGE_Riding_Player_Petting_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Riding_EatSlapBerry_TriggerInfiniteStamina_C : public UGameplayEffect
{
public:
};

// Size: 0x2040
class URidingCameraMode_C : public UFortCameraMode_Riding
{
public:
};

// Size: 0xb70
class UGA_Riding_Player_StopRidingOnTriggered_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
};

// Size: 0xb98
class UGA_Riding_Creature_EatToRefuel_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    FGameplayTagContainer Slap_Berry_Tags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x20, Type: StructProperty)
    UClass* Slap_Berry_Gameplay_Effect() const { return Read<UClass*>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x8, Type: ClassProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_Slap_Berry_Tags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x20, Type: StructProperty)
    void SET_Slap_Berry_Gameplay_Effect(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x8, Type: ClassProperty)
};

// Size: 0xa68
class UGE_Riding_Creature_Grant_EatToRefuel_C : public UGameplayEffect
{
public:
};

// Size: 0xb81
class UGA_Riding_Player_Sprint_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    TArray<FGameplayTag> Tags_to_cancel_sprinting() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x10, Type: ArrayProperty)
    bool ShouldCancelSprint() const { return Read<bool>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_Tags_to_cancel_sprinting(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x10, Type: ArrayProperty)
    void SET_ShouldCancelSprint(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa68
class UGE_Riding_Player_Sprint_C : public UGameplayEffect
{
public:
};

// Size: 0x1b39
class AB_CubeSurfing_Weapon_C : public AFortWeapon
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x19c8); } // 0x19c8 (Size: 0x8, Type: StructProperty)
    UWeaponEquipSoundComponent_C* WeaponEquipSoundComponent() const { return Read<UWeaponEquipSoundComponent_C*>(uintptr_t(this) + 0x19d0); } // 0x19d0 (Size: 0x8, Type: ObjectProperty)
    UBP_CubeSurfingST_C* BP_CubeSurfingST() const { return Read<UBP_CubeSurfingST_C*>(uintptr_t(this) + 0x19d8); } // 0x19d8 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* NS_CubeSurfing_Summon() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x19e0); } // 0x19e0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* Idle() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x19e8); } // 0x19e8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* MagicCube() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x19f0); } // 0x19f0 (Size: 0x8, Type: ObjectProperty)
    float VFX_Intro_Intro_BE1F830F4B336D6BC6BE6BB5D49C0A9C() const { return Read<float>(uintptr_t(this) + 0x19f8); } // 0x19f8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> VFX_Intro__Direction_BE1F830F4B336D6BC6BE6BB5D49C0A9C() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x19fc); } // 0x19fc (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* VFX_Intro() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x1a00); } // 0x1a00 (Size: 0x8, Type: ObjectProperty)
    float VtxForming_VtxMove_DBB1FB464E1BDB29E8A14998A851B6A7() const { return Read<float>(uintptr_t(this) + 0x1a08); } // 0x1a08 (Size: 0x4, Type: FloatProperty)
    float VtxForming_VtxHide_DBB1FB464E1BDB29E8A14998A851B6A7() const { return Read<float>(uintptr_t(this) + 0x1a0c); } // 0x1a0c (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> VtxForming__Direction_DBB1FB464E1BDB29E8A14998A851B6A7() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x1a10); } // 0x1a10 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* VtxForming() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x1a18); } // 0x1a18 (Size: 0x8, Type: ObjectProperty)
    float TL_CubeIntro_Float_C8C070484EDD68C4B425E2A1B118186F() const { return Read<float>(uintptr_t(this) + 0x1a20); } // 0x1a20 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TL_CubeIntro__Direction_C8C070484EDD68C4B425E2A1B118186F() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x1a24); } // 0x1a24 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* TL_CubeIntro() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x1a28); } // 0x1a28 (Size: 0x8, Type: ObjectProperty)
    float VtxAppear_VtxMove_EA08C7704160FF932A91318D0931075A() const { return Read<float>(uintptr_t(this) + 0x1a30); } // 0x1a30 (Size: 0x4, Type: FloatProperty)
    float VtxAppear_VtxHide_EA08C7704160FF932A91318D0931075A() const { return Read<float>(uintptr_t(this) + 0x1a34); } // 0x1a34 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> VtxAppear__Direction_EA08C7704160FF932A91318D0931075A() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x1a38); } // 0x1a38 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* VtxAppear() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x1a40); } // 0x1a40 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag CubeSurfTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1a48); } // 0x1a48 (Size: 0x4, Type: StructProperty)
    UAbilityAsync_WaitGameplayTagAdded* WaitTagAddAsync() const { return Read<UAbilityAsync_WaitGameplayTagAdded*>(uintptr_t(this) + 0x1a50); } // 0x1a50 (Size: 0x8, Type: ObjectProperty)
    UAbilityAsync_WaitGameplayTagRemoved* WaitTagRemoveAsync() const { return Read<UAbilityAsync_WaitGameplayTagRemoved*>(uintptr_t(this) + 0x1a58); } // 0x1a58 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawn* PlayerPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0x1a60); } // 0x1a60 (Size: 0x8, Type: ObjectProperty)
    UClass* AnimInstance() const { return Read<UClass*>(uintptr_t(this) + 0x1a68); } // 0x1a68 (Size: 0x8, Type: ClassProperty)
    UAbilityAsync_WaitGameplayEvent* WaitBoostEventAsync() const { return Read<UAbilityAsync_WaitGameplayEvent*>(uintptr_t(this) + 0x1a70); } // 0x1a70 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag GC_Boosting() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1a78); } // 0x1a78 (Size: 0x4, Type: StructProperty)
    FTimerHandle AbilityCostTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x1a80); } // 0x1a80 (Size: 0x8, Type: StructProperty)
    FScalableFloat HF_AmmoRateNormal() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1a88); } // 0x1a88 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_AmmoRateBoosting() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1ab0); } // 0x1ab0 (Size: 0x28, Type: StructProperty)
    bool IsDeploying_() const { return Read<bool>(uintptr_t(this) + 0x1b38); } // 0x1b38 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x19c8, Value); } // 0x19c8 (Size: 0x8, Type: StructProperty)
    void SET_WeaponEquipSoundComponent(const UWeaponEquipSoundComponent_C*& Value) { Write<UWeaponEquipSoundComponent_C*>(uintptr_t(this) + 0x19d0, Value); } // 0x19d0 (Size: 0x8, Type: ObjectProperty)
    void SET_BP_CubeSurfingST(const UBP_CubeSurfingST_C*& Value) { Write<UBP_CubeSurfingST_C*>(uintptr_t(this) + 0x19d8, Value); } // 0x19d8 (Size: 0x8, Type: ObjectProperty)
    void SET_NS_CubeSurfing_Summon(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x19e0, Value); } // 0x19e0 (Size: 0x8, Type: ObjectProperty)
    void SET_Idle(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x19e8, Value); } // 0x19e8 (Size: 0x8, Type: ObjectProperty)
    void SET_MagicCube(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x19f0, Value); } // 0x19f0 (Size: 0x8, Type: ObjectProperty)
    void SET_VFX_Intro_Intro_BE1F830F4B336D6BC6BE6BB5D49C0A9C(const float& Value) { Write<float>(uintptr_t(this) + 0x19f8, Value); } // 0x19f8 (Size: 0x4, Type: FloatProperty)
    void SET_VFX_Intro__Direction_BE1F830F4B336D6BC6BE6BB5D49C0A9C(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x19fc, Value); } // 0x19fc (Size: 0x1, Type: ByteProperty)
    void SET_VFX_Intro(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x1a00, Value); } // 0x1a00 (Size: 0x8, Type: ObjectProperty)
    void SET_VtxForming_VtxMove_DBB1FB464E1BDB29E8A14998A851B6A7(const float& Value) { Write<float>(uintptr_t(this) + 0x1a08, Value); } // 0x1a08 (Size: 0x4, Type: FloatProperty)
    void SET_VtxForming_VtxHide_DBB1FB464E1BDB29E8A14998A851B6A7(const float& Value) { Write<float>(uintptr_t(this) + 0x1a0c, Value); } // 0x1a0c (Size: 0x4, Type: FloatProperty)
    void SET_VtxForming__Direction_DBB1FB464E1BDB29E8A14998A851B6A7(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x1a10, Value); } // 0x1a10 (Size: 0x1, Type: ByteProperty)
    void SET_VtxForming(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x1a18, Value); } // 0x1a18 (Size: 0x8, Type: ObjectProperty)
    void SET_TL_CubeIntro_Float_C8C070484EDD68C4B425E2A1B118186F(const float& Value) { Write<float>(uintptr_t(this) + 0x1a20, Value); } // 0x1a20 (Size: 0x4, Type: FloatProperty)
    void SET_TL_CubeIntro__Direction_C8C070484EDD68C4B425E2A1B118186F(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x1a24, Value); } // 0x1a24 (Size: 0x1, Type: ByteProperty)
    void SET_TL_CubeIntro(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x1a28, Value); } // 0x1a28 (Size: 0x8, Type: ObjectProperty)
    void SET_VtxAppear_VtxMove_EA08C7704160FF932A91318D0931075A(const float& Value) { Write<float>(uintptr_t(this) + 0x1a30, Value); } // 0x1a30 (Size: 0x4, Type: FloatProperty)
    void SET_VtxAppear_VtxHide_EA08C7704160FF932A91318D0931075A(const float& Value) { Write<float>(uintptr_t(this) + 0x1a34, Value); } // 0x1a34 (Size: 0x4, Type: FloatProperty)
    void SET_VtxAppear__Direction_EA08C7704160FF932A91318D0931075A(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x1a38, Value); } // 0x1a38 (Size: 0x1, Type: ByteProperty)
    void SET_VtxAppear(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x1a40, Value); } // 0x1a40 (Size: 0x8, Type: ObjectProperty)
    void SET_CubeSurfTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1a48, Value); } // 0x1a48 (Size: 0x4, Type: StructProperty)
    void SET_WaitTagAddAsync(const UAbilityAsync_WaitGameplayTagAdded*& Value) { Write<UAbilityAsync_WaitGameplayTagAdded*>(uintptr_t(this) + 0x1a50, Value); } // 0x1a50 (Size: 0x8, Type: ObjectProperty)
    void SET_WaitTagRemoveAsync(const UAbilityAsync_WaitGameplayTagRemoved*& Value) { Write<UAbilityAsync_WaitGameplayTagRemoved*>(uintptr_t(this) + 0x1a58, Value); } // 0x1a58 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0x1a60, Value); } // 0x1a60 (Size: 0x8, Type: ObjectProperty)
    void SET_AnimInstance(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1a68, Value); } // 0x1a68 (Size: 0x8, Type: ClassProperty)
    void SET_WaitBoostEventAsync(const UAbilityAsync_WaitGameplayEvent*& Value) { Write<UAbilityAsync_WaitGameplayEvent*>(uintptr_t(this) + 0x1a70, Value); } // 0x1a70 (Size: 0x8, Type: ObjectProperty)
    void SET_GC_Boosting(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1a78, Value); } // 0x1a78 (Size: 0x4, Type: StructProperty)
    void SET_AbilityCostTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x1a80, Value); } // 0x1a80 (Size: 0x8, Type: StructProperty)
    void SET_HF_AmmoRateNormal(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1a88, Value); } // 0x1a88 (Size: 0x28, Type: StructProperty)
    void SET_HF_AmmoRateBoosting(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1ab0, Value); } // 0x1ab0 (Size: 0x28, Type: StructProperty)
    void SET_IsDeploying_(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1b38, Value); } // 0x1b38 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xf00
class UGA_Riding_Creature_IsBeingRidden_Passive_C : public UGA_NPC_Parent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xef8); } // 0xef8 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xef8, Value); } // 0xef8 (Size: 0x8, Type: StructProperty)
};

// Size: 0xa68
class UGE_Riding_Creatue_IsBeingRidden_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Riding_Creatue_IsBeingRidden_Passive_C : public UGameplayEffect
{
public:
};

// Size: 0xf00
class UGA_Riding_Creature_IsBeingRidden_C : public UGA_NPC_Parent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xef8); } // 0xef8 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xef8, Value); } // 0xef8 (Size: 0x8, Type: StructProperty)
};

// Size: 0xa68
class UGE_Riding_Irwin_Prey_Burt_IsBeingRidden_C : public UGE_Riding_Creatue_IsBeingRidden_C
{
public:
};

// Size: 0xb98
class UGA_Riding_Player_Petting_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    URidableComponent* Active_Ridable() const { return Read<URidableComponent*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    UClass* GE_PlayerPetting() const { return Read<UClass*>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: ClassProperty)
    TArray<FGameplayTag> TagsToCancelPetting() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x10, Type: ArrayProperty)
    AFortPlayerPawn* FortPlayerPawnRider() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_Active_Ridable(const URidableComponent*& Value) { Write<URidableComponent*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    void SET_GE_PlayerPetting(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: ClassProperty)
    void SET_TagsToCancelPetting(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x10, Type: ArrayProperty)
    void SET_FortPlayerPawnRider(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xb70
class UGA_Riding_Creature_Burt_SprintCharge_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
};

// Size: 0xa68
class UGE_CubeSurfing_BoostCooldown_C : public UGameplayEffect
{
public:
};

// Size: 0xb80
class UGA_Riding_Player_IsRiding_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    UAnimMontage* SettleMontageRef() const { return Read<UAnimMontage*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    UFortAbilityTask_PlayMontageWaitTarget* settleMontageTask() const { return Read<UFortAbilityTask_PlayMontageWaitTarget*>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_SettleMontageRef(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    void SET_settleMontageTask(const UFortAbilityTask_PlayMontageWaitTarget*& Value) { Write<UFortAbilityTask_PlayMontageWaitTarget*>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xa68
class UGE_Riding_Player_IsRiding_C : public UGameplayEffect
{
public:
};

