/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayBehaviorsModule
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"
#include "Engine.h"
#include "AIModule.h"
#include "CoreUObject.h"
#include "GameplayAbilities.h"
#include "GameplayTasks.h"

// Size: 0xc0
class UBTTask_SetKeyValueGameplayTag : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_GameplayTagContainer Value() const { return Read<FValueOrBBKey_GameplayTagContainer>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x28, Type: StructProperty)

    void SET_Value(const FValueOrBBKey_GameplayTagContainer& Value) { Write<FValueOrBBKey_GameplayTagContainer>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x28, Type: StructProperty)
};

// Size: 0x28
class UValueOrBBKey_GameplayTagBlueprintUtility : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0xe8
class UBTDecorator_GameplayTagQuery : public UBTDecorator
{
public:
    FBlackboardKeySelector ActorForGameplayTagQuery() const { return Read<FBlackboardKeySelector>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x28, Type: StructProperty)
    FGameplayTagQuery GameplayTagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x48, Type: StructProperty)
    TArray<FGameplayTag> QueryTags() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)

    void SET_ActorForGameplayTagQuery(const FBlackboardKeySelector& Value) { Write<FBlackboardKeySelector>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x28, Type: StructProperty)
    void SET_GameplayTagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x48, Type: StructProperty)
    void SET_QueryTags(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x78
class UBTTask_StopGameplayBehavior : public UBTTaskNode
{
public:
    UClass* BehaviorToStop() const { return Read<UClass*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ClassProperty)

    void SET_BehaviorToStop(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x58
class UGameplayBehaviorConfig_BehaviorTree : public UGameplayBehaviorConfig
{
public:
    TSoftObjectPtr<UBehaviorTree> BehaviorTree() const { return Read<TSoftObjectPtr<UBehaviorTree>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    bool bRevertToPreviousBTOnFinish() const { return (Read<uint8_t>(uintptr_t(this) + 0x50) >> 0x0) & 1; } // 0x50:0 (Size: 0x1, Type: BoolProperty)

    void SET_BehaviorTree(const TSoftObjectPtr<UBehaviorTree>& Value) { Write<TSoftObjectPtr<UBehaviorTree>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    void SET_bRevertToPreviousBTOnFinish(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x50); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x50, B); } // 0x50:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
class UGameplayBehaviorConfig : public UObject
{
public:
    UClass* BehaviorClass() const { return Read<UClass*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ClassProperty)

    void SET_BehaviorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ClassProperty)
};

// Size: 0xa8
class UGameplayBehavior_BehaviorTree : public UGameplayBehavior
{
public:
    UBehaviorTree* PreviousBT() const { return Read<UBehaviorTree*>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: ObjectProperty)
    AAIController* AIController() const { return Read<AAIController*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    bool bSingleRun() const { return Read<bool>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: BoolProperty)

    void SET_PreviousBT(const UBehaviorTree*& Value) { Write<UBehaviorTree*>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: ObjectProperty)
    void SET_AIController(const AAIController*& Value) { Write<AAIController*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    void SET_bSingleRun(const bool& Value) { Write<bool>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x88
class UGameplayBehavior : public UObject
{
public:
    FGameplayTag ActionTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: StructProperty)
    TArray<AActor*> RelevantActors() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    AActor* TransientSmartObjectOwner() const { return Read<AActor*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    AActor* TransientAvatar() const { return Read<AActor*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    TArray<UGameplayTask*> ActiveTasks() const { return Read<TArray<UGameplayTask*>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)

    void SET_ActionTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: StructProperty)
    void SET_RelevantActors(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_TransientSmartObjectOwner(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_TransientAvatar(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_ActiveTasks(const TArray<UGameplayTask*>& Value) { Write<TArray<UGameplayTask*>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
class UBlackboardKeyType_GameplayTag : public UBlackboardKeyType
{
public:
    FGameplayTagContainer DefaultValue() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)

    void SET_DefaultValue(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
};

// Size: 0x60
class UGameplayBehaviorConfig_Animation : public UGameplayBehaviorConfig
{
public:
    TSoftObjectPtr<UAnimMontage> AnimMontage() const { return Read<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    float PlayRate() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    FName StartSectionName() const { return Read<FName>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: NameProperty)
    bool bLoop() const { return (Read<uint8_t>(uintptr_t(this) + 0x58) >> 0x0) & 1; } // 0x58:0 (Size: 0x1, Type: BoolProperty)

    void SET_AnimMontage(const TSoftObjectPtr<UAnimMontage>& Value) { Write<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    void SET_PlayRate(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_StartSectionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: NameProperty)
    void SET_bLoop(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x58); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x58, B); } // 0x58:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UGameplayBehaviorsBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x80
class UGameplayBehaviorSubsystem : public UWorldSubsystem
{
public:
    TMap<FAgentGameplayBehaviors, AActor*> AgentGameplayBehaviors() const { return Read<TMap<FAgentGameplayBehaviors, AActor*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)

    void SET_AgentGameplayBehaviors(const TMap<FAgentGameplayBehaviors, AActor*>& Value) { Write<TMap<FAgentGameplayBehaviors, AActor*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
};

// Size: 0x98
class UGameplayBehavior_AnimationBased : public UGameplayBehavior
{
public:
    TArray<FMontagePlaybackData> ActivePlayback() const { return Read<TArray<FMontagePlaybackData>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)

    void SET_ActivePlayback(const TArray<FMontagePlaybackData>& Value) { Write<TArray<FMontagePlaybackData>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FValueOrBBKey_GameplayTagContainer : public FValueOrBlackboardKeyBase
{
public:
    FGameplayTagContainer DefaultValue() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: StructProperty)

    void SET_DefaultValue(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: StructProperty)
};

// Size: 0x10
struct FAgentGameplayBehaviors
{
public:
    TArray<UGameplayBehavior*> Behaviors() const { return Read<TArray<UGameplayBehavior*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Behaviors(const TArray<UGameplayBehavior*>& Value) { Write<TArray<UGameplayBehavior*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FMontagePlaybackData
{
public:
    AActor* Avatar() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* AnimMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UAbilitySystemComponent* AbilityComponent() const { return Read<UAbilitySystemComponent*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)

    void SET_Avatar(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_AnimMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_AbilityComponent(const UAbilitySystemComponent*& Value) { Write<UAbilitySystemComponent*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
};

