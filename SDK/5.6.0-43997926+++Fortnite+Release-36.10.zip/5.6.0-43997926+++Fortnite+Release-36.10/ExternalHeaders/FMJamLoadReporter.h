/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamLoadReporter
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "FMJamContentResolver.h"

// Size: 0x168
class UJamLoadReporter : public UGameStateComponent
{
public:
};

