/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AccoladesUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "AccoladesRuntime.h"
#include "FortniteGame.h"
#include "Engine.h"

// Size: 0x38
class UAthenaAccoladeWrapper : public UObject
{
public:
    FName AccoladeRowName() const { return Read<FName>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: NameProperty)
    FFortAccoladeSessionData AccoladeData() const { return Read<FFortAccoladeSessionData>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0xc, Type: StructProperty)

    void SET_AccoladeRowName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: NameProperty)
    void SET_AccoladeData(const FFortAccoladeSessionData& Value) { Write<FFortAccoladeSessionData>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0xc, Type: StructProperty)
};

// Size: 0x350
class UAthenaAccoladeListEntryWidget : public UCommonUserWidget
{
public:
};

// Size: 0xb60
class UAthenaAccoladeListWidget : public UCommonListView
{
public:
};

