/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AssetRegistry
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x28
class UAssetRegistryHelpers : public UObject
{
public:
};

// Size: 0x28
class UAssetRegistry : public UInterface
{
public:
};

// Size: 0x11a0
class UAssetRegistryImpl : public UObject
{
public:
};

// Size: 0x18
struct FTagAndValue
{
public:
    FName Tag() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FString Value() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)

    void SET_Tag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Value(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x5
struct FAssetRegistryDependencyOptions
{
public:
    bool bIncludeSoftPackageReferences() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bIncludeHardPackageReferences() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bIncludeSearchableNames() const { return Read<bool>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bIncludeSoftManagementReferences() const { return Read<bool>(uintptr_t(this) + 0x3); } // 0x3 (Size: 0x1, Type: BoolProperty)
    bool bIncludeHardManagementReferences() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)

    void SET_bIncludeSoftPackageReferences(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bIncludeHardPackageReferences(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_bIncludeSearchableNames(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: BoolProperty)
    void SET_bIncludeSoftManagementReferences(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3, Value); } // 0x3 (Size: 0x1, Type: BoolProperty)
    void SET_bIncludeHardManagementReferences(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
};

