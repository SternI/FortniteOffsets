/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnimationWarpingRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "AnimGraphRuntime.h"

// Size: 0x28
class UAnimationWarpingLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0xb0
struct FAnimNode_WarpTest : public FAnimNode_Base
{
public:
    FPoseLink Source() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    TArray<FTransform> Transforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    float SecondsToWait() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)

    void SET_Source(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_Transforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_SecondsToWait(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x2c
struct FFootPlacementInterpolationSettings
{
public:
    float UnplantLinearStiffness() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float UnplantLinearDamping() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float UnplantAngularStiffness() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float UnplantAngularDamping() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float SeparationStiffness() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float SeparationDamping() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float FloorLinearStiffness() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float FloorLinearDamping() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float FloorAngularStiffness() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float FloorAngularDamping() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    bool bEnableFloorInterpolation() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bSmoothRootBone() const { return Read<bool>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: BoolProperty)
    bool bEnableSeparationInterpolation() const { return Read<bool>(uintptr_t(this) + 0x2a); } // 0x2a (Size: 0x1, Type: BoolProperty)

    void SET_UnplantLinearStiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_UnplantLinearDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_UnplantAngularStiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_UnplantAngularDamping(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_SeparationStiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_SeparationDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_FloorLinearStiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_FloorLinearDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_FloorAngularStiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_FloorAngularDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_bEnableFloorInterpolation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_bSmoothRootBone(const bool& Value) { Write<bool>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableSeparationInterpolation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2a, Value); } // 0x2a (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FFootPlacementTraceSettings
{
public:
    float StartOffset() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float EndOffset() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float SweepRadius() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    bool bDisableComplexTrace() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<ETraceTypeQuery> ComplexTraceChannel() const { return Read<TEnumAsByte<ETraceTypeQuery>>(uintptr_t(this) + 0xd); } // 0xd (Size: 0x1, Type: ByteProperty)
    float MaxGroundPenetration() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETraceTypeQuery> SimpleTraceChannel() const { return Read<TEnumAsByte<ETraceTypeQuery>>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: ByteProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x15); } // 0x15 (Size: 0x1, Type: BoolProperty)

    void SET_StartOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_EndOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_SweepRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_bDisableComplexTrace(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
    void SET_ComplexTraceChannel(const TEnumAsByte<ETraceTypeQuery>& Value) { Write<TEnumAsByte<ETraceTypeQuery>>(uintptr_t(this) + 0xd, Value); } // 0xd (Size: 0x1, Type: ByteProperty)
    void SET_MaxGroundPenetration(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_SimpleTraceChannel(const TEnumAsByte<ETraceTypeQuery>& Value) { Write<TEnumAsByte<ETraceTypeQuery>>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: ByteProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15, Value); } // 0x15 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FFootPlacementRootDefinition
{
public:
    FBoneReference PelvisBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FBoneReference IKRootBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xc); } // 0xc (Size: 0xc, Type: StructProperty)

    void SET_PelvisBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_IKRootBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0xc, Type: StructProperty)
};

// Size: 0x20
struct FFootPlacementPelvisSettings
{
public:
    float MaxOffset() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float LinearStiffness() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float LinearDamping() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float HorizontalRebalancingWeight() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxOffsetHorizontal() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float HeelLiftRatio() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    uint8_t PelvisHeightMode() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t ActorMovementCompensationMode() const { return Read<uint8_t>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: EnumProperty)
    bool bEnableInterpolation() const { return Read<bool>(uintptr_t(this) + 0x1a); } // 0x1a (Size: 0x1, Type: BoolProperty)
    bool bDisablePelvisOffsetInAir() const { return Read<bool>(uintptr_t(this) + 0x1b); } // 0x1b (Size: 0x1, Type: BoolProperty)
    FName DisablePelvisCurveName() const { return Read<FName>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: NameProperty)

    void SET_MaxOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_LinearStiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_LinearDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_HorizontalRebalancingWeight(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_MaxOffsetHorizontal(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_HeelLiftRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_PelvisHeightMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_ActorMovementCompensationMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: EnumProperty)
    void SET_bEnableInterpolation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1a, Value); } // 0x1a (Size: 0x1, Type: BoolProperty)
    void SET_bDisablePelvisOffsetInAir(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1b, Value); } // 0x1b (Size: 0x1, Type: BoolProperty)
    void SET_DisablePelvisCurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: NameProperty)
};

// Size: 0x34
struct FFootPlacemenLegDefinition
{
public:
    FBoneReference FKFootBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FBoneReference IKFootBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xc); } // 0xc (Size: 0xc, Type: StructProperty)
    FBoneReference BallBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0xc, Type: StructProperty)
    int32_t NumBonesInLimb() const { return Read<int32_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: IntProperty)
    FName SpeedCurveName() const { return Read<FName>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: NameProperty)
    FName DisableLockCurveName() const { return Read<FName>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: NameProperty)
    FName DisableLegCurveName() const { return Read<FName>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: NameProperty)

    void SET_FKFootBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_IKFootBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0xc, Type: StructProperty)
    void SET_BallBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0xc, Type: StructProperty)
    void SET_NumBonesInLimb(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: IntProperty)
    void SET_SpeedCurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: NameProperty)
    void SET_DisableLockCurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: NameProperty)
    void SET_DisableLegCurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: NameProperty)
};

// Size: 0x34
struct FFootPlacementPlantSettings
{
public:
    float SpeedThreshold() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float DistanceToGround() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t LockType() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    float UnplantRadius() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float ReplantRadiusRatio() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float UnplantAngle() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float ReplantAngleRatio() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float MaxExtensionRatio() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float MinExtensionRatio() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float SeparatingDistance() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float UnalignmentSpeedThreshold() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float AnkleTwistReduction() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    bool bReconstructWorldPlantFromVelocity() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bAdjustHeelBeforePlanting() const { return Read<bool>(uintptr_t(this) + 0x31); } // 0x31 (Size: 0x1, Type: BoolProperty)

    void SET_SpeedThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_DistanceToGround(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_LockType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_UnplantRadius(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_ReplantRadiusRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_UnplantAngle(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_ReplantAngleRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_MaxExtensionRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_MinExtensionRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_SeparatingDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_UnalignmentSpeedThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_AnkleTwistReduction(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_bReconstructWorldPlantFromVelocity(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_bAdjustHeelBeforePlanting(const bool& Value) { Write<bool>(uintptr_t(this) + 0x31, Value); } // 0x31 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x4c0
struct FAnimNode_FootPlacement : public FAnimNode_SkeletalControlBase
{
public:
    uint8_t PlantSpeedMode() const { return Read<uint8_t>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: EnumProperty)
    FBoneReference IKFootRootBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0xc, Type: StructProperty)
    FBoneReference PelvisBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0xc, Type: StructProperty)
    FFootPlacementPelvisSettings PelvisSettings() const { return Read<FFootPlacementPelvisSettings>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x20, Type: StructProperty)
    TArray<FFootPlacemenLegDefinition> LegDefinitions() const { return Read<TArray<FFootPlacemenLegDefinition>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    FFootPlacementPlantSettings PlantSettings() const { return Read<FFootPlacementPlantSettings>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x34, Type: StructProperty)
    FFootPlacementInterpolationSettings InterpolationSettings() const { return Read<FFootPlacementInterpolationSettings>(uintptr_t(this) + 0x14c); } // 0x14c (Size: 0x2c, Type: StructProperty)
    FFootPlacementTraceSettings TraceSettings() const { return Read<FFootPlacementTraceSettings>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x18, Type: StructProperty)
    FVector BaseTranslationDelta() const { return Read<FVector>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x18, Type: StructProperty)

    void SET_PlantSpeedMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: EnumProperty)
    void SET_IKFootRootBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0xc, Type: StructProperty)
    void SET_PelvisBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0xc, Type: StructProperty)
    void SET_PelvisSettings(const FFootPlacementPelvisSettings& Value) { Write<FFootPlacementPelvisSettings>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x20, Type: StructProperty)
    void SET_LegDefinitions(const TArray<FFootPlacemenLegDefinition>& Value) { Write<TArray<FFootPlacemenLegDefinition>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    void SET_PlantSettings(const FFootPlacementPlantSettings& Value) { Write<FFootPlacementPlantSettings>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x34, Type: StructProperty)
    void SET_InterpolationSettings(const FFootPlacementInterpolationSettings& Value) { Write<FFootPlacementInterpolationSettings>(uintptr_t(this) + 0x14c, Value); } // 0x14c (Size: 0x2c, Type: StructProperty)
    void SET_TraceSettings(const FFootPlacementTraceSettings& Value) { Write<FFootPlacementTraceSettings>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x18, Type: StructProperty)
    void SET_BaseTranslationDelta(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x18, Type: StructProperty)
};

// Size: 0x100
struct FAnimNode_OffsetRootBone : public FAnimNode_Base
{
public:
    FPoseLink Source() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_Source(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x260
struct FAnimNode_OrientationWarping : public FAnimNode_SkeletalControlBase
{
public:
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: EnumProperty)
    float TargetTime() const { return Read<float>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: FloatProperty)
    float OrientationAngle() const { return Read<float>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    float LocomotionAngle() const { return Read<float>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    FVector LocomotionDirection() const { return Read<FVector>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x18, Type: StructProperty)
    float MinRootMotionSpeedThreshold() const { return Read<float>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    float LocomotionAngleDeltaThreshold() const { return Read<float>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    TArray<FBoneReference> SpineBones() const { return Read<TArray<FBoneReference>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    FBoneReference IKFootRootBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0xc, Type: StructProperty)
    TArray<FBoneReference> IKFootBones() const { return Read<TArray<FBoneReference>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x10, Type: ArrayProperty)
    UAnimationAsset* CurrentAnimAsset() const { return Read<UAnimationAsset*>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    float CurrentAnimAssetTime() const { return Read<float>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EAxis> RotationAxis() const { return Read<TEnumAsByte<EAxis>>(uintptr_t(this) + 0x134); } // 0x134 (Size: 0x1, Type: ByteProperty)
    float DistributedBoneOrientationAlpha() const { return Read<float>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x4, Type: FloatProperty)
    float RotationInterpSpeed() const { return Read<float>(uintptr_t(this) + 0x13c); } // 0x13c (Size: 0x4, Type: FloatProperty)
    float CounterCompensateInterpSpeed() const { return Read<float>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x4, Type: FloatProperty)
    float MaxCorrectionDegrees() const { return Read<float>(uintptr_t(this) + 0x144); } // 0x144 (Size: 0x4, Type: FloatProperty)
    float MaxRootMotionDeltaToCompensateDegrees() const { return Read<float>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x4, Type: FloatProperty)
    bool bCounterCompenstateInterpolationByRootMotion() const { return Read<bool>(uintptr_t(this) + 0x14c); } // 0x14c (Size: 0x1, Type: BoolProperty)
    bool bScaleByGlobalBlendWeight() const { return Read<bool>(uintptr_t(this) + 0x14d); } // 0x14d (Size: 0x1, Type: BoolProperty)
    bool bUseManualRootMotionVelocity() const { return Read<bool>(uintptr_t(this) + 0x14e); } // 0x14e (Size: 0x1, Type: BoolProperty)
    FVector ManualRootMotionVelocity() const { return Read<FVector>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x18, Type: StructProperty)
    uint8_t WarpingSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x1, Type: EnumProperty)
    FTransform WarpingSpaceTransform() const { return Read<FTransform>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x60, Type: StructProperty)

    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: EnumProperty)
    void SET_TargetTime(const float& Value) { Write<float>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: FloatProperty)
    void SET_OrientationAngle(const float& Value) { Write<float>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: FloatProperty)
    void SET_LocomotionAngle(const float& Value) { Write<float>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    void SET_LocomotionDirection(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x18, Type: StructProperty)
    void SET_MinRootMotionSpeedThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    void SET_LocomotionAngleDeltaThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    void SET_SpineBones(const TArray<FBoneReference>& Value) { Write<TArray<FBoneReference>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    void SET_IKFootRootBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0xc, Type: StructProperty)
    void SET_IKFootBones(const TArray<FBoneReference>& Value) { Write<TArray<FBoneReference>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentAnimAsset(const UAnimationAsset*& Value) { Write<UAnimationAsset*>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentAnimAssetTime(const float& Value) { Write<float>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x4, Type: FloatProperty)
    void SET_RotationAxis(const TEnumAsByte<EAxis>& Value) { Write<TEnumAsByte<EAxis>>(uintptr_t(this) + 0x134, Value); } // 0x134 (Size: 0x1, Type: ByteProperty)
    void SET_DistributedBoneOrientationAlpha(const float& Value) { Write<float>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x4, Type: FloatProperty)
    void SET_RotationInterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x13c, Value); } // 0x13c (Size: 0x4, Type: FloatProperty)
    void SET_CounterCompensateInterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x4, Type: FloatProperty)
    void SET_MaxCorrectionDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x144, Value); } // 0x144 (Size: 0x4, Type: FloatProperty)
    void SET_MaxRootMotionDeltaToCompensateDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x4, Type: FloatProperty)
    void SET_bCounterCompenstateInterpolationByRootMotion(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14c, Value); } // 0x14c (Size: 0x1, Type: BoolProperty)
    void SET_bScaleByGlobalBlendWeight(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14d, Value); } // 0x14d (Size: 0x1, Type: BoolProperty)
    void SET_bUseManualRootMotionVelocity(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14e, Value); } // 0x14e (Size: 0x1, Type: BoolProperty)
    void SET_ManualRootMotionVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x18, Type: StructProperty)
    void SET_WarpingSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x1, Type: EnumProperty)
    void SET_WarpingSpaceTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x60, Type: StructProperty)
};

// Size: 0x30
struct FAnimNode_OverrideRootMotion : public FAnimNode_Base
{
public:
    FPoseLink Source() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_Source(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x20
struct FSlopeWarpingFootDefinition
{
public:
    FBoneReference IKFootBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FBoneReference FKFootBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xc); } // 0xc (Size: 0xc, Type: StructProperty)
    int32_t NumBonesInLimb() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    float FootSize() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)

    void SET_IKFootBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_FKFootBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0xc, Type: StructProperty)
    void SET_NumBonesInLimb(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_FootSize(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
};

// Size: 0xb0
struct FSlopeWarpingFootData
{
public:
};

// Size: 0x2d8
struct FAnimNode_SlopeWarping : public FAnimNode_SkeletalControlBase
{
public:
    FBoneReference IKFootRootBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0xc, Type: StructProperty)
    FBoneReference PelvisBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xec); } // 0xec (Size: 0xc, Type: StructProperty)
    TArray<FSlopeWarpingFootDefinition> FeetDefinitions() const { return Read<TArray<FSlopeWarpingFootDefinition>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    TArray<FSlopeWarpingFootData> FeetData() const { return Read<TArray<FSlopeWarpingFootData>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    FVectorRK4SpringInterpolator PelvisOffsetInterpolator() const { return Read<FVectorRK4SpringInterpolator>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: StructProperty)
    FVector GravityDir() const { return Read<FVector>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x18, Type: StructProperty)
    FVector CustomFloorOffset() const { return Read<FVector>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x18, Type: StructProperty)
    float CachedDeltaTime() const { return Read<float>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x4, Type: FloatProperty)
    FVector TargetFloorNormalWorldSpace() const { return Read<FVector>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x18, Type: StructProperty)
    FVectorRK4SpringInterpolator FloorNormalInterpolator() const { return Read<FVectorRK4SpringInterpolator>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x8, Type: StructProperty)
    FVector TargetFloorOffsetLocalSpace() const { return Read<FVector>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x18, Type: StructProperty)
    FVectorRK4SpringInterpolator FloorOffsetInterpolator() const { return Read<FVectorRK4SpringInterpolator>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x8, Type: StructProperty)
    float MaxStepHeight() const { return Read<float>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x4, Type: FloatProperty)
    bool bKeepMeshInsideOfCapsule() const { return (Read<uint8_t>(uintptr_t(this) + 0x2a4) >> 0x0) & 1; } // 0x2a4:0 (Size: 0x1, Type: BoolProperty)
    bool bPullPelvisDown() const { return (Read<uint8_t>(uintptr_t(this) + 0x2a4) >> 0x1) & 1; } // 0x2a4:1 (Size: 0x1, Type: BoolProperty)
    bool bUseCustomFloorOffset() const { return (Read<uint8_t>(uintptr_t(this) + 0x2a4) >> 0x2) & 1; } // 0x2a4:2 (Size: 0x1, Type: BoolProperty)
    bool bWasOnGround() const { return (Read<uint8_t>(uintptr_t(this) + 0x2a4) >> 0x3) & 1; } // 0x2a4:3 (Size: 0x1, Type: BoolProperty)
    bool bShowDebug() const { return (Read<uint8_t>(uintptr_t(this) + 0x2a4) >> 0x4) & 1; } // 0x2a4:4 (Size: 0x1, Type: BoolProperty)
    bool bFloorSmoothingInitialized() const { return (Read<uint8_t>(uintptr_t(this) + 0x2a4) >> 0x5) & 1; } // 0x2a4:5 (Size: 0x1, Type: BoolProperty)
    FVector ActorLocation() const { return Read<FVector>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x18, Type: StructProperty)
    FVector GravityDirCompSpace() const { return Read<FVector>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x18, Type: StructProperty)

    void SET_IKFootRootBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0xc, Type: StructProperty)
    void SET_PelvisBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0xc, Type: StructProperty)
    void SET_FeetDefinitions(const TArray<FSlopeWarpingFootDefinition>& Value) { Write<TArray<FSlopeWarpingFootDefinition>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    void SET_FeetData(const TArray<FSlopeWarpingFootData>& Value) { Write<TArray<FSlopeWarpingFootData>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    void SET_PelvisOffsetInterpolator(const FVectorRK4SpringInterpolator& Value) { Write<FVectorRK4SpringInterpolator>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: StructProperty)
    void SET_GravityDir(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x18, Type: StructProperty)
    void SET_CustomFloorOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x18, Type: StructProperty)
    void SET_CachedDeltaTime(const float& Value) { Write<float>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x4, Type: FloatProperty)
    void SET_TargetFloorNormalWorldSpace(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x18, Type: StructProperty)
    void SET_FloorNormalInterpolator(const FVectorRK4SpringInterpolator& Value) { Write<FVectorRK4SpringInterpolator>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x8, Type: StructProperty)
    void SET_TargetFloorOffsetLocalSpace(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x18, Type: StructProperty)
    void SET_FloorOffsetInterpolator(const FVectorRK4SpringInterpolator& Value) { Write<FVectorRK4SpringInterpolator>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x8, Type: StructProperty)
    void SET_MaxStepHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x4, Type: FloatProperty)
    void SET_bKeepMeshInsideOfCapsule(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2a4); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x2a4, B); } // 0x2a4:0 (Size: 0x1, Type: BoolProperty)
    void SET_bPullPelvisDown(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2a4); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x2a4, B); } // 0x2a4:1 (Size: 0x1, Type: BoolProperty)
    void SET_bUseCustomFloorOffset(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2a4); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x2a4, B); } // 0x2a4:2 (Size: 0x1, Type: BoolProperty)
    void SET_bWasOnGround(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2a4); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x2a4, B); } // 0x2a4:3 (Size: 0x1, Type: BoolProperty)
    void SET_bShowDebug(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2a4); B = (B & ~(1 << 0x4)) | (Value << 0x4); Write<uint8_t>(uintptr_t(this) + 0x2a4, B); } // 0x2a4:4 (Size: 0x1, Type: BoolProperty)
    void SET_bFloorSmoothingInitialized(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x2a4); B = (B & ~(1 << 0x5)) | (Value << 0x5); Write<uint8_t>(uintptr_t(this) + 0x2a4, B); } // 0x2a4:5 (Size: 0x1, Type: BoolProperty)
    void SET_ActorLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x18, Type: StructProperty)
    void SET_GravityDirCompSpace(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x18, Type: StructProperty)
};

// Size: 0x1b0
struct FAnimNode_Steering : public FAnimNode_SkeletalControlBase
{
public:
    FQuat TargetOrientation() const { return Read<FQuat>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x20, Type: StructProperty)
    bool bMirrored() const { return Read<bool>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    float ProceduralTargetTime() const { return Read<float>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    float TargetTime() const { return Read<float>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    float AnimatedTargetTime() const { return Read<float>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x4, Type: FloatProperty)
    float RootMotionThreshold() const { return Read<float>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: FloatProperty)
    float DisableSteeringBelowSpeed() const { return Read<float>(uintptr_t(this) + 0x104); } // 0x104 (Size: 0x4, Type: FloatProperty)
    float DisableAdditiveBelowSpeed() const { return Read<float>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x4, Type: FloatProperty)
    float MinScaleRatio() const { return Read<float>(uintptr_t(this) + 0x10c); } // 0x10c (Size: 0x4, Type: FloatProperty)
    float MaxScaleRatio() const { return Read<float>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x4, Type: FloatProperty)
    UMirrorDataTable* MirrorDataTable() const { return Read<UMirrorDataTable*>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    UAnimationAsset* CurrentAnimAsset() const { return Read<UAnimationAsset*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    float CurrentAnimAssetTime() const { return Read<float>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x4, Type: FloatProperty)

    void SET_TargetOrientation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x20, Type: StructProperty)
    void SET_bMirrored(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    void SET_ProceduralTargetTime(const float& Value) { Write<float>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    void SET_TargetTime(const float& Value) { Write<float>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    void SET_AnimatedTargetTime(const float& Value) { Write<float>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x4, Type: FloatProperty)
    void SET_RootMotionThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: FloatProperty)
    void SET_DisableSteeringBelowSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x104, Value); } // 0x104 (Size: 0x4, Type: FloatProperty)
    void SET_DisableAdditiveBelowSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x4, Type: FloatProperty)
    void SET_MinScaleRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x10c, Value); } // 0x10c (Size: 0x4, Type: FloatProperty)
    void SET_MaxScaleRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x4, Type: FloatProperty)
    void SET_MirrorDataTable(const UMirrorDataTable*& Value) { Write<UMirrorDataTable*>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentAnimAsset(const UAnimationAsset*& Value) { Write<UAnimationAsset*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentAnimAssetTime(const float& Value) { Write<float>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x24
struct FStrideWarpingFootDefinition
{
public:
    FBoneReference IKFootBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FBoneReference FKFootBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xc); } // 0xc (Size: 0xc, Type: StructProperty)
    FBoneReference ThighBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0xc, Type: StructProperty)

    void SET_IKFootBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_FKFootBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0xc, Type: StructProperty)
    void SET_ThighBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0xc, Type: StructProperty)
};

// Size: 0x240
struct FAnimNode_StrideWarping : public FAnimNode_SkeletalControlBase
{
public:
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: EnumProperty)
    FVector StrideDirection() const { return Read<FVector>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x18, Type: StructProperty)
    float StrideScale() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    float LocomotionSpeed() const { return Read<float>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: FloatProperty)
    float MinRootMotionSpeedThreshold() const { return Read<float>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    FBoneReference PelvisBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0xc, Type: StructProperty)
    FBoneReference IKFootRootBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0xc, Type: StructProperty)
    TArray<FStrideWarpingFootDefinition> FootDefinitions() const { return Read<TArray<FStrideWarpingFootDefinition>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x10, Type: ArrayProperty)
    FInputClampConstants StrideScaleModifier() const { return Read<FInputClampConstants>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x14, Type: StructProperty)
    FWarpingVectorValue FloorNormalDirection() const { return Read<FWarpingVectorValue>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x20, Type: StructProperty)
    FWarpingVectorValue GravityDirection() const { return Read<FWarpingVectorValue>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x20, Type: StructProperty)
    FIKFootPelvisPullDownSolver PelvisIKFootSolver() const { return Read<FIKFootPelvisPullDownSolver>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x80, Type: StructProperty)
    bool bOrientStrideDirectionUsingFloorNormal() const { return Read<bool>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x1, Type: BoolProperty)
    bool bCompensateIKUsingFKThighRotation() const { return Read<bool>(uintptr_t(this) + 0x1f9); } // 0x1f9 (Size: 0x1, Type: BoolProperty)
    bool bClampIKUsingFKLimits() const { return Read<bool>(uintptr_t(this) + 0x1fa); } // 0x1fa (Size: 0x1, Type: BoolProperty)
    bool bDisableIfMissingRootMotion() const { return Read<bool>(uintptr_t(this) + 0x1fb); } // 0x1fb (Size: 0x1, Type: BoolProperty)

    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: EnumProperty)
    void SET_StrideDirection(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x18, Type: StructProperty)
    void SET_StrideScale(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    void SET_LocomotionSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: FloatProperty)
    void SET_MinRootMotionSpeedThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    void SET_PelvisBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0xc, Type: StructProperty)
    void SET_IKFootRootBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0xc, Type: StructProperty)
    void SET_FootDefinitions(const TArray<FStrideWarpingFootDefinition>& Value) { Write<TArray<FStrideWarpingFootDefinition>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x10, Type: ArrayProperty)
    void SET_StrideScaleModifier(const FInputClampConstants& Value) { Write<FInputClampConstants>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x14, Type: StructProperty)
    void SET_FloorNormalDirection(const FWarpingVectorValue& Value) { Write<FWarpingVectorValue>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x20, Type: StructProperty)
    void SET_GravityDirection(const FWarpingVectorValue& Value) { Write<FWarpingVectorValue>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x20, Type: StructProperty)
    void SET_PelvisIKFootSolver(const FIKFootPelvisPullDownSolver& Value) { Write<FIKFootPelvisPullDownSolver>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x80, Type: StructProperty)
    void SET_bOrientStrideDirectionUsingFloorNormal(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x1, Type: BoolProperty)
    void SET_bCompensateIKUsingFKThighRotation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1f9, Value); } // 0x1f9 (Size: 0x1, Type: BoolProperty)
    void SET_bClampIKUsingFKLimits(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1fa, Value); } // 0x1fa (Size: 0x1, Type: BoolProperty)
    void SET_bDisableIfMissingRootMotion(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1fb, Value); } // 0x1fb (Size: 0x1, Type: BoolProperty)
};

