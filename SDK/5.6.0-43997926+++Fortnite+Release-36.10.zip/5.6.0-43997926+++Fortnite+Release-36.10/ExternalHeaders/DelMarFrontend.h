/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarFrontend
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "DelMarCore.h"
#include "FortniteUI.h"
#include "Engine.h"

// Size: 0x28
class UDelMarFrontendCheatManager : public UChildCheatManager
{
public:
};

// Size: 0x188
class UDelMarFrontendExperienceFlow : public UObject
{
public:
    AFortPlayerController* CachedPlayerController() const { return Read<AFortPlayerController*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    UClass* ConfirmationWindowClass() const { return Read<UClass*>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: ClassProperty)
    FText TutorialPromptTitle() const { return Read<FText>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: TextProperty)
    FText TutorialPromptDescription() const { return Read<FText>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: TextProperty)
    FText TutorialPromptConfirmButtonText() const { return Read<FText>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: TextProperty)
    FText TutorialPromptDeclineButtonText() const { return Read<FText>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: TextProperty)
    FText SpeedRunPromptTitle() const { return Read<FText>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: TextProperty)
    FText SpeedRunPromptDescription() const { return Read<FText>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: TextProperty)
    FText SpeedRunPromptConfirmButtonText() const { return Read<FText>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: TextProperty)
    FText SpeedRunPromptDeclineButtonText() const { return Read<FText>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: TextProperty)
    TWeakObjectPtr<UDelMarGameUserSettings*> DelMarUserSettings() const { return Read<TWeakObjectPtr<UDelMarGameUserSettings*>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    TMap<FString, FString> NUXTrailerRating() const { return Read<TMap<FString, FString>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x50, Type: MapProperty)

    void SET_CachedPlayerController(const AFortPlayerController*& Value) { Write<AFortPlayerController*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_ConfirmationWindowClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: ClassProperty)
    void SET_TutorialPromptTitle(const FText& Value) { Write<FText>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: TextProperty)
    void SET_TutorialPromptDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: TextProperty)
    void SET_TutorialPromptConfirmButtonText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: TextProperty)
    void SET_TutorialPromptDeclineButtonText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: TextProperty)
    void SET_SpeedRunPromptTitle(const FText& Value) { Write<FText>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: TextProperty)
    void SET_SpeedRunPromptDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: TextProperty)
    void SET_SpeedRunPromptConfirmButtonText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: TextProperty)
    void SET_SpeedRunPromptDeclineButtonText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: TextProperty)
    void SET_DelMarUserSettings(const TWeakObjectPtr<UDelMarGameUserSettings*>& Value) { Write<TWeakObjectPtr<UDelMarGameUserSettings*>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_NUXTrailerRating(const TMap<FString, FString>& Value) { Write<TMap<FString, FString>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x30
class UDelMarGFA_OverrideFrontendIsland : public UGameFeatureAction
{
public:
    TWeakObjectPtr<UDelMarGameUserSettings*> DelMarUserSettings() const { return Read<TWeakObjectPtr<UDelMarGameUserSettings*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)

    void SET_DelMarUserSettings(const TWeakObjectPtr<UDelMarGameUserSettings*>& Value) { Write<TWeakObjectPtr<UDelMarGameUserSettings*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x4d8
class UDelMarModeSetModificationModal : public UFortActivityModeSetSelectionModalBase
{
public:
    UClass* TrackSelectScreenClass() const { return Read<UClass*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ClassProperty)
    UDelMarActivityVM* DelMarActivityVM() const { return Read<UDelMarActivityVM*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)

    void SET_TrackSelectScreenClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ClassProperty)
    void SET_DelMarActivityVM(const UDelMarActivityVM*& Value) { Write<UDelMarActivityVM*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x640
class UDelMarModeSetPreviewModal : public UFortActivityDetailsModalBase
{
public:
    UDelMarActivityVM* DelMarActivityVM() const { return Read<UDelMarActivityVM*>(uintptr_t(this) + 0x610); } // 0x610 (Size: 0x8, Type: ObjectProperty)
    UClass* RegularDetailsModalClass() const { return Read<UClass*>(uintptr_t(this) + 0x620); } // 0x620 (Size: 0x8, Type: ClassProperty)
    UClass* ActivityCreatorPageViewClass() const { return Read<UClass*>(uintptr_t(this) + 0x628); } // 0x628 (Size: 0x8, Type: ClassProperty)
    UClass* ActivityCampaignPurchaseScreenClass() const { return Read<UClass*>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0x8, Type: ClassProperty)
    UClass* ActivityAttributionsClass() const { return Read<UClass*>(uintptr_t(this) + 0x638); } // 0x638 (Size: 0x8, Type: ClassProperty)

    void SET_DelMarActivityVM(const UDelMarActivityVM*& Value) { Write<UDelMarActivityVM*>(uintptr_t(this) + 0x610, Value); } // 0x610 (Size: 0x8, Type: ObjectProperty)
    void SET_RegularDetailsModalClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x620, Value); } // 0x620 (Size: 0x8, Type: ClassProperty)
    void SET_ActivityCreatorPageViewClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x628, Value); } // 0x628 (Size: 0x8, Type: ClassProperty)
    void SET_ActivityCampaignPurchaseScreenClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0x8, Type: ClassProperty)
    void SET_ActivityAttributionsClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x638, Value); } // 0x638 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x50
class UDelMarRankedWidgetExtension : public UObject
{
public:
};

// Size: 0x170
class UDelMarTrackSelectionViewModel : public UFortDiscoverSurfaceViewModel
{
public:
    UFortDiscoverPanelTreeViewModel* IndexPanelTree() const { return Read<UFortDiscoverPanelTreeViewModel*>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x8, Type: ObjectProperty)
    UFortDiscoverProviderViewModel* FrontPagePanel() const { return Read<UFortDiscoverProviderViewModel*>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x8, Type: ObjectProperty)
    TArray<UFortDiscoverPanelTreeViewModel*> Categories() const { return Read<TArray<UFortDiscoverPanelTreeViewModel*>>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x10, Type: ArrayProperty)
    UFortDiscoverPanelTreeViewModel* SelectedCategory() const { return Read<UFortDiscoverPanelTreeViewModel*>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x8, Type: ObjectProperty)
    TArray<UFortDiscoverPanelTreeViewModel*> CurrentSubCategories() const { return Read<TArray<UFortDiscoverPanelTreeViewModel*>>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x10, Type: ArrayProperty)

    void SET_IndexPanelTree(const UFortDiscoverPanelTreeViewModel*& Value) { Write<UFortDiscoverPanelTreeViewModel*>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x8, Type: ObjectProperty)
    void SET_FrontPagePanel(const UFortDiscoverProviderViewModel*& Value) { Write<UFortDiscoverProviderViewModel*>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x8, Type: ObjectProperty)
    void SET_Categories(const TArray<UFortDiscoverPanelTreeViewModel*>& Value) { Write<TArray<UFortDiscoverPanelTreeViewModel*>>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x10, Type: ArrayProperty)
    void SET_SelectedCategory(const UFortDiscoverPanelTreeViewModel*& Value) { Write<UFortDiscoverPanelTreeViewModel*>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentSubCategories(const TArray<UFortDiscoverPanelTreeViewModel*>& Value) { Write<TArray<UFortDiscoverPanelTreeViewModel*>>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x4b8
class UDelMarTrackSelectScreen : public UFortActivityModeSetSelectionModalBase
{
public:
};

// Size: 0x38
class UDelMarUserSettingsSubsystem : public UFortLocalPlayerSubsystem
{
public:
    UDelMarGameUserSettings* DelMarGameUserSettings() const { return Read<UDelMarGameUserSettings*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_DelMarGameUserSettings(const UDelMarGameUserSettings*& Value) { Write<UDelMarGameUserSettings*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xb0
class UDelMarFrontendRuntimeOptions : public URuntimeOptionsBase
{
public:
    FString FrontendNuxVideoKey() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)
    FName FrontendNuxVideoName() const { return Read<FName>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: NameProperty)
    FString FrontendNuxVideoId() const { return Read<FString>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: StrProperty)
    int32_t NuxVideoVersion() const { return Read<int32_t>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: IntProperty)
    bool bAlwaysShowNuxVideo() const { return Read<bool>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x1, Type: BoolProperty)
    bool bDisableFrontendNuxFlow() const { return Read<bool>(uintptr_t(this) + 0x65); } // 0x65 (Size: 0x1, Type: BoolProperty)
    bool bDisableFrontendSpeedRunPrompt() const { return Read<bool>(uintptr_t(this) + 0x66); } // 0x66 (Size: 0x1, Type: BoolProperty)
    bool bFrontendSpeedRunPromptUsesTwoButtons() const { return Read<bool>(uintptr_t(this) + 0x67); } // 0x67 (Size: 0x1, Type: BoolProperty)
    FString DelMarTutorialLinkCode() const { return Read<FString>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StrProperty)
    FString DelMarSpeedRunLinkCode() const { return Read<FString>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StrProperty)
    FString DelMarDefaultLinkCode() const { return Read<FString>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: StrProperty)
    bool bUseNewTrackSelectFlow() const { return Read<bool>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: BoolProperty)
    bool bUseTrackSelectGrids() const { return Read<bool>(uintptr_t(this) + 0x99); } // 0x99 (Size: 0x1, Type: BoolProperty)
    bool bUsePreviewModal() const { return Read<bool>(uintptr_t(this) + 0x9a); } // 0x9a (Size: 0x1, Type: BoolProperty)
    TArray<FString> DelMarNewLinkCodes() const { return Read<TArray<FString>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: ArrayProperty)

    void SET_FrontendNuxVideoKey(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
    void SET_FrontendNuxVideoName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: NameProperty)
    void SET_FrontendNuxVideoId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: StrProperty)
    void SET_NuxVideoVersion(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: IntProperty)
    void SET_bAlwaysShowNuxVideo(const bool& Value) { Write<bool>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x1, Type: BoolProperty)
    void SET_bDisableFrontendNuxFlow(const bool& Value) { Write<bool>(uintptr_t(this) + 0x65, Value); } // 0x65 (Size: 0x1, Type: BoolProperty)
    void SET_bDisableFrontendSpeedRunPrompt(const bool& Value) { Write<bool>(uintptr_t(this) + 0x66, Value); } // 0x66 (Size: 0x1, Type: BoolProperty)
    void SET_bFrontendSpeedRunPromptUsesTwoButtons(const bool& Value) { Write<bool>(uintptr_t(this) + 0x67, Value); } // 0x67 (Size: 0x1, Type: BoolProperty)
    void SET_DelMarTutorialLinkCode(const FString& Value) { Write<FString>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StrProperty)
    void SET_DelMarSpeedRunLinkCode(const FString& Value) { Write<FString>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StrProperty)
    void SET_DelMarDefaultLinkCode(const FString& Value) { Write<FString>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: StrProperty)
    void SET_bUseNewTrackSelectFlow(const bool& Value) { Write<bool>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: BoolProperty)
    void SET_bUseTrackSelectGrids(const bool& Value) { Write<bool>(uintptr_t(this) + 0x99, Value); } // 0x99 (Size: 0x1, Type: BoolProperty)
    void SET_bUsePreviewModal(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9a, Value); } // 0x9a (Size: 0x1, Type: BoolProperty)
    void SET_DelMarNewLinkCodes(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xb0
class UDelMarActivityVM : public UMVVMViewModelBase
{
public:
    TArray<FString> ProductModes() const { return Read<TArray<FString>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    FString CurrentProductMode() const { return Read<FString>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StrProperty)
    UFortActivityViewModel* FortActivityVM() const { return Read<UFortActivityViewModel*>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: ObjectProperty)
    bool bActivitySupportsPrivateMatch() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)
    bool bIsPreviewModal() const { return Read<bool>(uintptr_t(this) + 0x91); } // 0x91 (Size: 0x1, Type: BoolProperty)

    void SET_ProductModes(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentProductMode(const FString& Value) { Write<FString>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StrProperty)
    void SET_FortActivityVM(const UFortActivityViewModel*& Value) { Write<UFortActivityViewModel*>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: ObjectProperty)
    void SET_bActivitySupportsPrivateMatch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
    void SET_bIsPreviewModal(const bool& Value) { Write<bool>(uintptr_t(this) + 0x91, Value); } // 0x91 (Size: 0x1, Type: BoolProperty)
};

