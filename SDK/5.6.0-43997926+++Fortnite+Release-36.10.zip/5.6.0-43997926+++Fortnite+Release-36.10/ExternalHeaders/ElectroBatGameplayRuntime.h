/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ElectroBatGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "GameplayAbilities.h"
#include "CoreUObject.h"

// Size: 0x80
class UElectroBatAttributeSet : public UFortAttributeSet
{
public:
    FFortGameplayAttributeData KnockbackCharge() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData CurrentChargeStage() const { return Read<FFortGameplayAttributeData>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x28, Type: StructProperty)

    void SET_KnockbackCharge(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x28, Type: StructProperty)
    void SET_CurrentChargeStage(const FFortGameplayAttributeData& Value) { Write<FFortGameplayAttributeData>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x28, Type: StructProperty)
};

// Size: 0x1340
class UElectroBatLayerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    FFortPlayerAnimAssets PlayerAnimAssetsOverrideDuringCharging() const { return Read<FFortPlayerAnimAssets>(uintptr_t(this) + 0x1308); } // 0x1308 (Size: 0x10, Type: StructProperty)
    float CustomMeleeTwist() const { return Read<float>(uintptr_t(this) + 0x1318); } // 0x1318 (Size: 0x4, Type: FloatProperty)
    bool bChargedSwingHit() const { return Read<bool>(uintptr_t(this) + 0x131c); } // 0x131c (Size: 0x1, Type: BoolProperty)
    bool bUserCurve01() const { return Read<bool>(uintptr_t(this) + 0x131d); } // 0x131d (Size: 0x1, Type: BoolProperty)
    bool bEnterChargedState() const { return Read<bool>(uintptr_t(this) + 0x131e); } // 0x131e (Size: 0x1, Type: BoolProperty)
    bool bUserCurve03() const { return Read<bool>(uintptr_t(this) + 0x131f); } // 0x131f (Size: 0x1, Type: BoolProperty)
    bool bExitOutro() const { return Read<bool>(uintptr_t(this) + 0x1320); } // 0x1320 (Size: 0x1, Type: BoolProperty)
    FGameplayTag ChargingTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1324); } // 0x1324 (Size: 0x4, Type: StructProperty)
    FGameplayTag HitTagName() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1328); } // 0x1328 (Size: 0x4, Type: StructProperty)

    void SET_PlayerAnimAssetsOverrideDuringCharging(const FFortPlayerAnimAssets& Value) { Write<FFortPlayerAnimAssets>(uintptr_t(this) + 0x1308, Value); } // 0x1308 (Size: 0x10, Type: StructProperty)
    void SET_CustomMeleeTwist(const float& Value) { Write<float>(uintptr_t(this) + 0x1318, Value); } // 0x1318 (Size: 0x4, Type: FloatProperty)
    void SET_bChargedSwingHit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x131c, Value); } // 0x131c (Size: 0x1, Type: BoolProperty)
    void SET_bUserCurve01(const bool& Value) { Write<bool>(uintptr_t(this) + 0x131d, Value); } // 0x131d (Size: 0x1, Type: BoolProperty)
    void SET_bEnterChargedState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x131e, Value); } // 0x131e (Size: 0x1, Type: BoolProperty)
    void SET_bUserCurve03(const bool& Value) { Write<bool>(uintptr_t(this) + 0x131f, Value); } // 0x131f (Size: 0x1, Type: BoolProperty)
    void SET_bExitOutro(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1320, Value); } // 0x1320 (Size: 0x1, Type: BoolProperty)
    void SET_ChargingTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1324, Value); } // 0x1324 (Size: 0x4, Type: StructProperty)
    void SET_HitTagName(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1328, Value); } // 0x1328 (Size: 0x4, Type: StructProperty)
};

// Size: 0x1f8
class UElectroBatWeaponComponent : public UFortWeaponComponent
{
public:
    FGameplayAttribute ChargeStageAttribute() const { return Read<FGameplayAttribute>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x38, Type: StructProperty)
    UClass* CustomSprintMMEClass() const { return Read<UClass*>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x8, Type: ClassProperty)
    FGameplayTag ElectroBatSprintingTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x4, Type: StructProperty)
    UClass* FallDamamgeImmunityEffectClass() const { return Read<UClass*>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x8, Type: ClassProperty)
    UClass* StartChargingEffectClass() const { return Read<UClass*>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x8, Type: ClassProperty)
    UClass* StopChargeEffectClass() const { return Read<UClass*>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x8, Type: ClassProperty)
    UClass* IncrementChargeEffectClass() const { return Read<UClass*>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x8, Type: ClassProperty)
    UClass* ChargingEffectClass() const { return Read<UClass*>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x8, Type: ClassProperty)
    FScalableFloat PreChargeDelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x28, Type: StructProperty)
    FScalableFloat TimePerCharge() const { return Read<FScalableFloat>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x28, Type: StructProperty)
    FScalableFloat TotalChargeStages() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x28, Type: StructProperty)

    void SET_ChargeStageAttribute(const FGameplayAttribute& Value) { Write<FGameplayAttribute>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x38, Type: StructProperty)
    void SET_CustomSprintMMEClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x8, Type: ClassProperty)
    void SET_ElectroBatSprintingTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x4, Type: StructProperty)
    void SET_FallDamamgeImmunityEffectClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x8, Type: ClassProperty)
    void SET_StartChargingEffectClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x8, Type: ClassProperty)
    void SET_StopChargeEffectClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x8, Type: ClassProperty)
    void SET_IncrementChargeEffectClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x8, Type: ClassProperty)
    void SET_ChargingEffectClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x8, Type: ClassProperty)
    void SET_PreChargeDelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x28, Type: StructProperty)
    void SET_TimePerCharge(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x28, Type: StructProperty)
    void SET_TotalChargeStages(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x28, Type: StructProperty)
};

