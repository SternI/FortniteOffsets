/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricTooltipUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "FortniteUI.h"
#include "CommonUI.h"
#include "UMG.h"

// Size: 0x88
class UFabricTooltipViewModel : public UMVVMViewModelBase
{
public:
    FText Name() const { return Read<FText>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: TextProperty)
    FText Description() const { return Read<FText>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: TextProperty)

    void SET_Name(const FText& Value) { Write<FText>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: TextProperty)
    void SET_Description(const FText& Value) { Write<FText>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: TextProperty)
};

// Size: 0x490
class UFabricTooltipWidget : public UFortActorIndicatorWidget
{
public:
    bool bUseShortDescription() const { return Read<bool>(uintptr_t(this) + 0x430); } // 0x430 (Size: 0x1, Type: BoolProperty)
    bool bUseShortDescriptionWithTouch() const { return Read<bool>(uintptr_t(this) + 0x431); } // 0x431 (Size: 0x1, Type: BoolProperty)
    float ShortDescriptionHeight() const { return Read<float>(uintptr_t(this) + 0x434); } // 0x434 (Size: 0x4, Type: FloatProperty)
    float ShowMoreThreshold() const { return Read<float>(uintptr_t(this) + 0x438); } // 0x438 (Size: 0x4, Type: FloatProperty)
    FText ShowMoreText() const { return Read<FText>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x10, Type: TextProperty)
    FText ShowLessText() const { return Read<FText>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x10, Type: TextProperty)
    UAthenaMarkerPointer* MarkerPointer() const { return Read<UAthenaMarkerPointer*>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Description() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SizeBox_Description() const { return Read<USizeBox*>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* Panel_ShowMorePrompt() const { return Read<UPanelWidget*>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ShowMorePrompt() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    bool bShowingFullDescription() const { return Read<bool>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x1, Type: BoolProperty)

    void SET_bUseShortDescription(const bool& Value) { Write<bool>(uintptr_t(this) + 0x430, Value); } // 0x430 (Size: 0x1, Type: BoolProperty)
    void SET_bUseShortDescriptionWithTouch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x431, Value); } // 0x431 (Size: 0x1, Type: BoolProperty)
    void SET_ShortDescriptionHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x434, Value); } // 0x434 (Size: 0x4, Type: FloatProperty)
    void SET_ShowMoreThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x438, Value); } // 0x438 (Size: 0x4, Type: FloatProperty)
    void SET_ShowMoreText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x10, Type: TextProperty)
    void SET_ShowLessText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x10, Type: TextProperty)
    void SET_MarkerPointer(const UAthenaMarkerPointer*& Value) { Write<UAthenaMarkerPointer*>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_Description(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    void SET_SizeBox_Description(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    void SET_Panel_ShowMorePrompt(const UPanelWidget*& Value) { Write<UPanelWidget*>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_ShowMorePrompt(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_bShowingFullDescription(const bool& Value) { Write<bool>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x1, Type: BoolProperty)
};

