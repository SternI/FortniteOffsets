/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarTrackSelectorUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "FortniteGame.h"

// Size: 0xe0
class UDelMarMatchmakingSettingsUI : public UMatchmakingSettingsUI
{
public:
    FText MatchmakingSettingsButtonPrimaryText() const { return Read<FText>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: TextProperty)
    FText MatchmakingSettingsButtonInvalidSelectionText() const { return Read<FText>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: TextProperty)
    FText MatchmakingSettingsButtonRankedText() const { return Read<FText>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: TextProperty)
    UClass* ProductModeUserFacingDataClass() const { return Read<UClass*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ClassProperty)

    void SET_MatchmakingSettingsButtonPrimaryText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: TextProperty)
    void SET_MatchmakingSettingsButtonInvalidSelectionText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: TextProperty)
    void SET_MatchmakingSettingsButtonRankedText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: TextProperty)
    void SET_ProductModeUserFacingDataClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x98
class UDelMarRankedViewModel : public UMVVMViewModelBase
{
public:
    UFortSocialUser* SocialUser() const { return Read<UFortSocialUser*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    bool bIsPlayerRanked() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    FString RankType() const { return Read<FString>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StrProperty)
    int32_t CurrentRank() const { return Read<int32_t>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: IntProperty)
    int32_t HighestRank() const { return Read<int32_t>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: IntProperty)
    int32_t CurrentPlayerPosition() const { return Read<int32_t>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: IntProperty)
    float Progress() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)

    void SET_SocialUser(const UFortSocialUser*& Value) { Write<UFortSocialUser*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsPlayerRanked(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_RankType(const FString& Value) { Write<FString>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StrProperty)
    void SET_CurrentRank(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: IntProperty)
    void SET_HighestRank(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: IntProperty)
    void SET_CurrentPlayerPosition(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: IntProperty)
    void SET_Progress(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
};

