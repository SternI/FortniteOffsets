/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FeralCorgiUIRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "FortniteUI.h"

// Size: 0x4a0
class UFeralCorgiPurchaseModal : public UCommonActivatableWidget
{
public:
    UInputComponent* IntroModalInputComp() const { return Read<UInputComponent*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    FDataTableRowHandle AcceptActionBinding() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x10, Type: StructProperty)
    FPrimaryContentSetup PrimaryContentSetup() const { return Read<FPrimaryContentSetup>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x4, Type: StructProperty)

    void SET_IntroModalInputComp(const UInputComponent*& Value) { Write<UInputComponent*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_AcceptActionBinding(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x10, Type: StructProperty)
    void SET_PrimaryContentSetup(const FPrimaryContentSetup& Value) { Write<FPrimaryContentSetup>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x4, Type: StructProperty)
};

