/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamInLobbyRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "SparksMusicPlayspaceRuntime.h"
#include "PlayspaceSystem.h"
#include "Engine.h"
#include "GameplayEventRouter.h"
#include "GameplayTags.h"

// Size: 0x40
class UJamInLobbyConfig : public UPrimaryDataAsset
{
public:
    TArray<FJamInLobbyEnableCondition> JamInLobbyEnabledConditions() const { return Read<TArray<FJamInLobbyEnableCondition>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_JamInLobbyEnabledConditions(const TArray<FJamInLobbyEnableCondition>& Value) { Write<TArray<FJamInLobbyEnableCondition>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x158
class UJamInLobbyControllerComponent_LoopOptions : public UJamControllerComponent_LoopOptions
{
public:
};

// Size: 0x108
class UFortGameStateComponent_JamInLobbyPlayspaceManager : public UFortGameStateComponent
{
public:
    UJamInLobbyConfig* JamInLobbyConfig() const { return Read<UJamInLobbyConfig*>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x8, Type: ObjectProperty)

    void SET_JamInLobbyConfig(const UJamInLobbyConfig*& Value) { Write<UJamInLobbyConfig*>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x8c8
class AJamInLobbyPlayspace : public AJamPlayspace
{
public:
    UAudioComponent* JamAudioSource() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x840); } // 0x840 (Size: 0x8, Type: ObjectProperty)
    FGameplayEventListenerHandle OnKeyChangedEventHandle() const { return Read<FGameplayEventListenerHandle>(uintptr_t(this) + 0x868); } // 0x868 (Size: 0x1c, Type: StructProperty)
    FGameplayEventListenerHandle OnModeChangedEventHandle() const { return Read<FGameplayEventListenerHandle>(uintptr_t(this) + 0x884); } // 0x884 (Size: 0x1c, Type: StructProperty)
    FGameplayEventListenerHandle OnTempoChangedEventHandle() const { return Read<FGameplayEventListenerHandle>(uintptr_t(this) + 0x8a0); } // 0x8a0 (Size: 0x1c, Type: StructProperty)

    void SET_JamAudioSource(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x840, Value); } // 0x840 (Size: 0x8, Type: ObjectProperty)
    void SET_OnKeyChangedEventHandle(const FGameplayEventListenerHandle& Value) { Write<FGameplayEventListenerHandle>(uintptr_t(this) + 0x868, Value); } // 0x868 (Size: 0x1c, Type: StructProperty)
    void SET_OnModeChangedEventHandle(const FGameplayEventListenerHandle& Value) { Write<FGameplayEventListenerHandle>(uintptr_t(this) + 0x884, Value); } // 0x884 (Size: 0x1c, Type: StructProperty)
    void SET_OnTempoChangedEventHandle(const FGameplayEventListenerHandle& Value) { Write<FGameplayEventListenerHandle>(uintptr_t(this) + 0x8a0, Value); } // 0x8a0 (Size: 0x1c, Type: StructProperty)
};

// Size: 0x60
struct FJamInLobbyEnableCondition
{
public:
    FGameplayTagQuery TagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x48, Type: StructProperty)
    FString RequiredCVar() const { return Read<FString>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StrProperty)
    bool bAlwaysDisableJamInLobby() const { return Read<bool>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x1, Type: BoolProperty)

    void SET_TagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x48, Type: StructProperty)
    void SET_RequiredCVar(const FString& Value) { Write<FString>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StrProperty)
    void SET_bAlwaysDisableJamInLobby(const bool& Value) { Write<bool>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x1, Type: BoolProperty)
};

