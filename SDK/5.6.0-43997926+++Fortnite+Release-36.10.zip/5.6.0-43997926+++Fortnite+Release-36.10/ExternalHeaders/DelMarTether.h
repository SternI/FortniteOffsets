/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarTether
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "DelMarCore.h"
#include "TowHookWeaponRuntime.h"
#include "FortniteGame.h"

// Size: 0xf0
class UDelMarPlayerTetherComponent : public UDelMarPlayerAttachmentComponent
{
public:
    TArray<UFortWeaponItemDefinition*> WeaponsToGive() const { return Read<TArray<UFortWeaponItemDefinition*>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    bool bInfiniteAmmo() const { return Read<bool>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    float SecondsBetweenRequests() const { return Read<float>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<ADelMarVehicle*> AttachedVehicle() const { return Read<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFortPawnComponent_TetheredMovement*> TetheredMovementComp() const { return Read<TWeakObjectPtr<UFortPawnComponent_TetheredMovement*>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)

    void SET_WeaponsToGive(const TArray<UFortWeaponItemDefinition*>& Value) { Write<TArray<UFortWeaponItemDefinition*>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    void SET_bInfiniteAmmo(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    void SET_SecondsBetweenRequests(const float& Value) { Write<float>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: FloatProperty)
    void SET_AttachedVehicle(const TWeakObjectPtr<ADelMarVehicle*>& Value) { Write<TWeakObjectPtr<ADelMarVehicle*>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    void SET_TetheredMovementComp(const TWeakObjectPtr<UFortPawnComponent_TetheredMovement*>& Value) { Write<TWeakObjectPtr<UFortPawnComponent_TetheredMovement*>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
};

