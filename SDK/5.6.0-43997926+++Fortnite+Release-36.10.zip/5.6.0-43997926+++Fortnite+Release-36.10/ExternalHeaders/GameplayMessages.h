/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayMessages
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayTags.h"

// Size: 0x98
class UAsyncAction_RegisterGameplayMessageReceiver : public UBlueprintAsyncActionBase
{
public:
};

// Size: 0x2a8
class AGameplayMessageReplicator : public AActor
{
public:
};

// Size: 0xd8
class UGameplayMessageRouter : public UGameInstanceSubsystem
{
public:
    AGameplayMessageReplicator* MessageReplicator() const { return Read<AGameplayMessageReplicator*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ObjectProperty)

    void SET_MessageReplicator(const AGameplayMessageReplicator*& Value) { Write<AGameplayMessageReplicator*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UBlueprintEventMessageTagLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x4
struct FEventMessageTag : public FGameplayTag
{
public:
};

// Size: 0x18
struct FReplicatedMessageData
{
public:
    UScriptStruct* StructType() const { return Read<UScriptStruct*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_StructType(const UScriptStruct*& Value) { Write<UScriptStruct*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FReplicatedMessage
{
public:
};

// Size: 0x18
struct FGameplayMessageReceiverHandle
{
public:
    TWeakObjectPtr<UGameplayMessageRouter*> Subsystem() const { return Read<TWeakObjectPtr<UGameplayMessageRouter*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FEventMessageTag Channel() const { return Read<FEventMessageTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    int32_t ID() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)

    void SET_Subsystem(const TWeakObjectPtr<UGameplayMessageRouter*>& Value) { Write<TWeakObjectPtr<UGameplayMessageRouter*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_Channel(const FEventMessageTag& Value) { Write<FEventMessageTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_ID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
};

// Size: 0x80
struct FGameplayMessageReceiverData
{
public:
};

