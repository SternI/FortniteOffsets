/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DualWieldingRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "../Enums.h"
#include "Engine.h"

// Size: 0xb90
class UFortGameplayAbility_ReloadPrimary : public UFortGameplayAbility_Reload
{
public:
};

// Size: 0xb90
class UFortGameplayAbility_ReloadSecondary : public UFortGameplayAbility_Reload
{
public:
};

// Size: 0x2670
class AFortWeaponRanged_DualWieldable : public AFortWeaponRanged
{
public:
    UAnimMontage* SecondaryFireAnimation() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x2628); } // 0x2628 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* SecondaryReloadAnimation() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x2630); } // 0x2630 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* BothPairedReloadAnimation() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x2638); } // 0x2638 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* SecondaryWeaponFireMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x2640); } // 0x2640 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* SecondaryWeaponReloadMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x2648); } // 0x2648 (Size: 0x8, Type: ObjectProperty)
    uint8_t DualWieldRole() const { return Read<uint8_t>(uintptr_t(this) + 0x2650); } // 0x2650 (Size: 0x1, Type: EnumProperty)
    TWeakObjectPtr<AFortWeaponRanged_DualWieldable*> PairedWeapon() const { return Read<TWeakObjectPtr<AFortWeaponRanged_DualWieldable*>>(uintptr_t(this) + 0x2654); } // 0x2654 (Size: 0x8, Type: WeakObjectProperty)

    void SET_SecondaryFireAnimation(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x2628, Value); } // 0x2628 (Size: 0x8, Type: ObjectProperty)
    void SET_SecondaryReloadAnimation(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x2630, Value); } // 0x2630 (Size: 0x8, Type: ObjectProperty)
    void SET_BothPairedReloadAnimation(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x2638, Value); } // 0x2638 (Size: 0x8, Type: ObjectProperty)
    void SET_SecondaryWeaponFireMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x2640, Value); } // 0x2640 (Size: 0x8, Type: ObjectProperty)
    void SET_SecondaryWeaponReloadMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x2648, Value); } // 0x2648 (Size: 0x8, Type: ObjectProperty)
    void SET_DualWieldRole(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2650, Value); } // 0x2650 (Size: 0x1, Type: EnumProperty)
    void SET_PairedWeapon(const TWeakObjectPtr<AFortWeaponRanged_DualWieldable*>& Value) { Write<TWeakObjectPtr<AFortWeaponRanged_DualWieldable*>>(uintptr_t(this) + 0x2654, Value); } // 0x2654 (Size: 0x8, Type: WeakObjectProperty)
};

