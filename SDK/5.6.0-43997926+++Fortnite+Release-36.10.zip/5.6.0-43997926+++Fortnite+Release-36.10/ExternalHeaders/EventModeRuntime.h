/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EventModeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "UMG.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "CoreUObject.h"

// Size: 0x228
class UFortGameFrameworkComponent_EventMode : public UGameFrameworkComponent
{
public:
    TSoftObjectPtr<UFortWeaponItemDefinition> ActivatorAsset() const { return Read<TSoftObjectPtr<UFortWeaponItemDefinition>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FUIExtension> UIExtensions() const { return Read<TArray<FUIExtension>>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x10, Type: ArrayProperty)
    TMap<TSoftClassPtr, FGameplayTag> TaggedUIExtensions() const { return Read<TMap<TSoftClassPtr, FGameplayTag>>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x50, Type: MapProperty)
    TArray<FEventModeFocusActor> FocusActors() const { return Read<TArray<FEventModeFocusActor>>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x10, Type: ArrayProperty)
    UInputComponent* InputComponent() const { return Read<UInputComponent*>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    TArray<FEventModeWidgetCachedData> CachedWidgetData() const { return Read<TArray<FEventModeWidgetCachedData>>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x10, Type: ArrayProperty)
    TSoftObjectPtr<AActor> CurrentlyFocusedActor() const { return Read<TSoftObjectPtr<AActor>>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x20, Type: SoftObjectProperty)

    void SET_ActivatorAsset(const TSoftObjectPtr<UFortWeaponItemDefinition>& Value) { Write<TSoftObjectPtr<UFortWeaponItemDefinition>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x20, Type: SoftObjectProperty)
    void SET_UIExtensions(const TArray<FUIExtension>& Value) { Write<TArray<FUIExtension>>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x10, Type: ArrayProperty)
    void SET_TaggedUIExtensions(const TMap<TSoftClassPtr, FGameplayTag>& Value) { Write<TMap<TSoftClassPtr, FGameplayTag>>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x50, Type: MapProperty)
    void SET_FocusActors(const TArray<FEventModeFocusActor>& Value) { Write<TArray<FEventModeFocusActor>>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x10, Type: ArrayProperty)
    void SET_InputComponent(const UInputComponent*& Value) { Write<UInputComponent*>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedWidgetData(const TArray<FEventModeWidgetCachedData>& Value) { Write<TArray<FEventModeWidgetCachedData>>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentlyFocusedActor(const TSoftObjectPtr<AActor>& Value) { Write<TSoftObjectPtr<AActor>>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x19c8
class AFortWeapon_EventMode : public AFortWeapon
{
public:
};

// Size: 0x48
struct FEventModeFocusActor
{
public:
    TSoftObjectPtr<AActor> Target() const { return Read<TSoftObjectPtr<AActor>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    float Distance() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    FVector Offset() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    float FOV() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)

    void SET_Target(const TSoftObjectPtr<AActor>& Value) { Write<TSoftObjectPtr<AActor>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Distance(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_Offset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_FOV(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc
struct FEventModeWidgetCachedData
{
public:
    uint8_t Slot() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    TWeakObjectPtr<UUserWidget*> Widget() const { return Read<TWeakObjectPtr<UUserWidget*>>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x8, Type: WeakObjectProperty)

    void SET_Slot(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_Widget(const TWeakObjectPtr<UUserWidget*>& Value) { Write<TWeakObjectPtr<UUserWidget*>>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x8, Type: WeakObjectProperty)
};

