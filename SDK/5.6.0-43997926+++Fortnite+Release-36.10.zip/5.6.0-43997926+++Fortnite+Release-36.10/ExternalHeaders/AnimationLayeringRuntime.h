/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnimationLayeringRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x40
class UBoneMaskDefinitionDataAsset : public UDataAsset
{
public:
    FBoneMaskDefinition BoneMaskDefinition() const { return Read<FBoneMaskDefinition>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StructProperty)

    void SET_BoneMaskDefinition(const FBoneMaskDefinition& Value) { Write<FBoneMaskDefinition>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StructProperty)
};

// Size: 0x50
struct FBoneMask
{
public:
    TMap<FBoneMaskEntry, FName> BoneMaskMap() const { return Read<TMap<FBoneMaskEntry, FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_BoneMaskMap(const TMap<FBoneMaskEntry, FName>& Value) { Write<TMap<FBoneMaskEntry, FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x8
struct FBoneMaskEntry
{
public:
    float LocalSpaceWeight() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MeshSpaceWeight() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_LocalSpaceWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MeshSpaceWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FBoneMaskPerBoneData
{
public:
    int32_t SkeletonPoseBoneIndex() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    float BlendWeight() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_SkeletonPoseBoneIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_BlendWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
struct FBoneMaskBodyPartDefinition
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    TArray<FBranchFilter> BranchFilters() const { return Read<TArray<FBranchFilter>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FBoneMaskPerBoneData> SkeletonPoseBoneWeights() const { return Read<TArray<FBoneMaskPerBoneData>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> SkeletonPoseChildBoneIndices() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_BranchFilters(const TArray<FBranchFilter>& Value) { Write<TArray<FBranchFilter>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_SkeletonPoseBoneWeights(const TArray<FBoneMaskPerBoneData>& Value) { Write<TArray<FBoneMaskPerBoneData>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_SkeletonPoseChildBoneIndices(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FBoneMaskDefinition
{
public:
    TArray<FBoneMaskBodyPartDefinition> BodyPartDefinitions() const { return Read<TArray<FBoneMaskBodyPartDefinition>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_BodyPartDefinitions(const TArray<FBoneMaskBodyPartDefinition>& Value) { Write<TArray<FBoneMaskBodyPartDefinition>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xc
struct FBoneMaskUpdateMultiParam
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    float LocalSpaceWeight() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float MeshSpaceWeight() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_LocalSpaceWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MeshSpaceWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FBoneMaskBodyPartNameContainer
{
public:
    TArray<FName> Names() const { return Read<TArray<FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Names(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x118
struct FAnimNode_BoneMask : public FAnimNode_Base
{
public:
    FPoseLink BasePose() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    TArray<FPoseLink> BlendPoses() const { return Read<TArray<FPoseLink>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<float> BlendWeights() const { return Read<TArray<float>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    FBoneMask BoneMask() const { return Read<FBoneMask>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x50, Type: StructProperty)
    UBoneMaskDefinitionDataAsset* BoneMaskDefinitionDataAsset() const { return Read<UBoneMaskDefinitionDataAsset*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    TArray<FBoneMaskBodyPartNameContainer> BodyParts() const { return Read<TArray<FBoneMaskBodyPartNameContainer>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    TEnumAsByte<ECurveBlendOption> CurveBlendOption() const { return Read<TEnumAsByte<ECurveBlendOption>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x1, Type: ByteProperty)
    int32_t LODThreshold() const { return Read<int32_t>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: IntProperty)
    bool bUpdateSkeletonDataOnDemand() const { return Read<bool>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x1, Type: BoolProperty)

    void SET_BasePose(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_BlendPoses(const TArray<FPoseLink>& Value) { Write<TArray<FPoseLink>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_BlendWeights(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_BoneMask(const FBoneMask& Value) { Write<FBoneMask>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x50, Type: StructProperty)
    void SET_BoneMaskDefinitionDataAsset(const UBoneMaskDefinitionDataAsset*& Value) { Write<UBoneMaskDefinitionDataAsset*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    void SET_BodyParts(const TArray<FBoneMaskBodyPartNameContainer>& Value) { Write<TArray<FBoneMaskBodyPartNameContainer>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    void SET_CurveBlendOption(const TEnumAsByte<ECurveBlendOption>& Value) { Write<TEnumAsByte<ECurveBlendOption>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x1, Type: ByteProperty)
    void SET_LODThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: IntProperty)
    void SET_bUpdateSkeletonDataOnDemand(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x128
struct FAnimNode_CopyBoneAdvanced : public FAnimNode_SkeletalControlBase
{
public:
    FBoneReference SourceBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0xc, Type: StructProperty)
    FBoneReference TargetBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0xc, Type: StructProperty)
    FVector TranslationWeight() const { return Read<FVector>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x18, Type: StructProperty)
    float RotationWeight() const { return Read<float>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    float ScaleWeight() const { return Read<float>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EBoneControlSpace> ControlSpace() const { return Read<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: ByteProperty)
    FBoneReference TranslationSpaceBone() const { return Read<FBoneReference>(uintptr_t(this) + 0x104); } // 0x104 (Size: 0xc, Type: StructProperty)
    bool bTranslationInCustomBoneSpace() const { return Read<bool>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x1, Type: BoolProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x111); } // 0x111 (Size: 0x1, Type: BoolProperty)

    void SET_SourceBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0xc, Type: StructProperty)
    void SET_TargetBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0xc, Type: StructProperty)
    void SET_TranslationWeight(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x18, Type: StructProperty)
    void SET_RotationWeight(const float& Value) { Write<float>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    void SET_ScaleWeight(const float& Value) { Write<float>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x4, Type: FloatProperty)
    void SET_ControlSpace(const TEnumAsByte<EBoneControlSpace>& Value) { Write<TEnumAsByte<EBoneControlSpace>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: ByteProperty)
    void SET_TranslationSpaceBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x104, Value); } // 0x104 (Size: 0xc, Type: StructProperty)
    void SET_bTranslationInCustomBoneSpace(const bool& Value) { Write<bool>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x1, Type: BoolProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x111, Value); } // 0x111 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1e0
struct FAnimNode_CopyMotion : public FAnimNode_SkeletalControlBase
{
public:
    FComponentSpacePoseLink BasePose() const { return Read<FComponentSpacePoseLink>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: StructProperty)
    FComponentSpacePoseLink BasePoseReference() const { return Read<FComponentSpacePoseLink>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: StructProperty)
    bool bUseBasePose() const { return Read<bool>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: BoolProperty)
    FName PoseHistoryTag() const { return Read<FName>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: NameProperty)
    float Delay() const { return Read<float>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    FBoneReference SourceBone() const { return Read<FBoneReference>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0xc, Type: StructProperty)
    FBoneReference BoneToModify() const { return Read<FBoneReference>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0xc, Type: StructProperty)
    FBoneReference CopySpace() const { return Read<FBoneReference>(uintptr_t(this) + 0x10c); } // 0x10c (Size: 0xc, Type: StructProperty)
    FBoneReference ApplySpace() const { return Read<FBoneReference>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0xc, Type: StructProperty)
    FRotator TranslationOffset() const { return Read<FRotator>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x18, Type: StructProperty)
    FRotator RotationOffset() const { return Read<FRotator>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x18, Type: StructProperty)
    FVector RotationPivot() const { return Read<FVector>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x18, Type: StructProperty)
    FName CurvePrefix() const { return Read<FName>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x4, Type: NameProperty)
    FName TargetCurveName() const { return Read<FName>(uintptr_t(this) + 0x174); } // 0x174 (Size: 0x4, Type: NameProperty)
    float TargetCurveScale() const { return Read<float>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x4, Type: FloatProperty)
    uint8_t TargetCurveComponent() const { return Read<uint8_t>(uintptr_t(this) + 0x17c); } // 0x17c (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<EAxis> TargetCurveRotationAxis() const { return Read<TEnumAsByte<EAxis>>(uintptr_t(this) + 0x17d); } // 0x17d (Size: 0x1, Type: ByteProperty)
    FName TranslationX_CurveName() const { return Read<FName>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x4, Type: NameProperty)
    FName TranslationY_CurveName() const { return Read<FName>(uintptr_t(this) + 0x184); } // 0x184 (Size: 0x4, Type: NameProperty)
    FName TranslationZ_CurveName() const { return Read<FName>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x4, Type: NameProperty)
    FName RotationRoll_CurveName() const { return Read<FName>(uintptr_t(this) + 0x18c); } // 0x18c (Size: 0x4, Type: NameProperty)
    FName RotationPitch_CurveName() const { return Read<FName>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x4, Type: NameProperty)
    FName RotationYaw_CurveName() const { return Read<FName>(uintptr_t(this) + 0x194); } // 0x194 (Size: 0x4, Type: NameProperty)
    FVector TranslationScale() const { return Read<FVector>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x18, Type: StructProperty)
    UCurveVector* TranslationRemapCurve() const { return Read<UCurveVector*>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    float RotationScale() const { return Read<float>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x4, Type: FloatProperty)
    UCurveFloat* RotationRemapCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x8, Type: ObjectProperty)

    void SET_BasePose(const FComponentSpacePoseLink& Value) { Write<FComponentSpacePoseLink>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: StructProperty)
    void SET_BasePoseReference(const FComponentSpacePoseLink& Value) { Write<FComponentSpacePoseLink>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: StructProperty)
    void SET_bUseBasePose(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: BoolProperty)
    void SET_PoseHistoryTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: NameProperty)
    void SET_Delay(const float& Value) { Write<float>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    void SET_SourceBone(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0xc, Type: StructProperty)
    void SET_BoneToModify(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0xc, Type: StructProperty)
    void SET_CopySpace(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x10c, Value); } // 0x10c (Size: 0xc, Type: StructProperty)
    void SET_ApplySpace(const FBoneReference& Value) { Write<FBoneReference>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0xc, Type: StructProperty)
    void SET_TranslationOffset(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x18, Type: StructProperty)
    void SET_RotationOffset(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x18, Type: StructProperty)
    void SET_RotationPivot(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x18, Type: StructProperty)
    void SET_CurvePrefix(const FName& Value) { Write<FName>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x4, Type: NameProperty)
    void SET_TargetCurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x174, Value); } // 0x174 (Size: 0x4, Type: NameProperty)
    void SET_TargetCurveScale(const float& Value) { Write<float>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x4, Type: FloatProperty)
    void SET_TargetCurveComponent(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x17c, Value); } // 0x17c (Size: 0x1, Type: EnumProperty)
    void SET_TargetCurveRotationAxis(const TEnumAsByte<EAxis>& Value) { Write<TEnumAsByte<EAxis>>(uintptr_t(this) + 0x17d, Value); } // 0x17d (Size: 0x1, Type: ByteProperty)
    void SET_TranslationX_CurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x4, Type: NameProperty)
    void SET_TranslationY_CurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x184, Value); } // 0x184 (Size: 0x4, Type: NameProperty)
    void SET_TranslationZ_CurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x4, Type: NameProperty)
    void SET_RotationRoll_CurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18c, Value); } // 0x18c (Size: 0x4, Type: NameProperty)
    void SET_RotationPitch_CurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x4, Type: NameProperty)
    void SET_RotationYaw_CurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x194, Value); } // 0x194 (Size: 0x4, Type: NameProperty)
    void SET_TranslationScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x18, Type: StructProperty)
    void SET_TranslationRemapCurve(const UCurveVector*& Value) { Write<UCurveVector*>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    void SET_RotationScale(const float& Value) { Write<float>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x4, Type: FloatProperty)
    void SET_RotationRemapCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x8, Type: ObjectProperty)
};

