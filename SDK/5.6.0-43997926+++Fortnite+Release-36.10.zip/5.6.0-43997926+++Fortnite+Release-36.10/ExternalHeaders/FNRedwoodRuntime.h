/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FNRedwoodRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "ChatCompletion.h"
#include "CoreUObject.h"
#include "Monologue.h"
#include "Engine.h"
#include "OratorRuntime.h"

// Size: 0x140
class UFNRedwoodModerator : public UObject
{
public:
    UMonologuePromptDataAsset* ModerationPrompt() const { return Read<UMonologuePromptDataAsset*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    FChatCompletionStructuredResponseDataSchema ModerationResponseSchema() const { return Read<FChatCompletionStructuredResponseDataSchema>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x108, Type: StructProperty)
    bool bRequiresDynamicResponseSchema() const { return Read<bool>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x1, Type: BoolProperty)

    void SET_ModerationPrompt(const UMonologuePromptDataAsset*& Value) { Write<UMonologuePromptDataAsset*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_ModerationResponseSchema(const FChatCompletionStructuredResponseDataSchema& Value) { Write<FChatCompletionStructuredResponseDataSchema>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x108, Type: StructProperty)
    void SET_bRequiresDynamicResponseSchema(const bool& Value) { Write<bool>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x140
class UFNRedwoodModerator_RestrictionViolation : public UFNRedwoodModerator
{
public:
};

// Size: 0x128
class UFNRedwoodModerationComponent : public UActorComponent
{
public:
    UDataTable* RestrictionsDataTable() const { return Read<UDataTable*>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    FText RestrictionLineFormat() const { return Read<FText>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: TextProperty)
    TArray<FFNRedwoodModerationRequest> InProgressModerationRequests() const { return Read<TArray<FFNRedwoodModerationRequest>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    int32_t NumModerationFailures() const { return Read<int32_t>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x4, Type: IntProperty)
    UMonologueComponent* CachedMonologueComponent() const { return Read<UMonologueComponent*>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    UOratorComponent* CachedOratorComponent() const { return Read<UOratorComponent*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)

    void SET_RestrictionsDataTable(const UDataTable*& Value) { Write<UDataTable*>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: ObjectProperty)
    void SET_RestrictionLineFormat(const FText& Value) { Write<FText>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: TextProperty)
    void SET_InProgressModerationRequests(const TArray<FFNRedwoodModerationRequest>& Value) { Write<TArray<FFNRedwoodModerationRequest>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    void SET_NumModerationFailures(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x4, Type: IntProperty)
    void SET_CachedMonologueComponent(const UMonologueComponent*& Value) { Write<UMonologueComponent*>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedOratorComponent(const UOratorComponent*& Value) { Write<UOratorComponent*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
class UFNRedwoodSubsystem : public UWorldSubsystem
{
public:
};

// Size: 0xa8
class UGameFeatureAction_SetupFNRedwoodAnalytics : public UGameFeatureAction
{
public:
    FString AnalyticsAppId() const { return Read<FString>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StrProperty)
    FString AnalyticsEventNamespace() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)

    void SET_AnalyticsAppId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StrProperty)
    void SET_AnalyticsEventNamespace(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
};

// Size: 0x200
class UFortPawnComponent_RedwoodSpatialFactsProvider : public UFortPawnComponent
{
public:
};

// Size: 0xe0
struct FFNRedwoodModerationRequest
{
public:
    AController* Instigator() const { return Read<AController*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UMonologueComponent* MonologueComponent() const { return Read<UMonologueComponent*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UClass* ModeratorClass() const { return Read<UClass*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ClassProperty)
    FChatCompletionRequestHandle ChatCompletionRequestToModerate() const { return Read<FChatCompletionRequestHandle>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    TArray<FMonologueEvent> EventsToForgetIfFailed() const { return Read<TArray<FMonologueEvent>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TMap<FMonologueFact, FName> ModerationPromptLocalFacts() const { return Read<TMap<FMonologueFact, FName>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x50, Type: MapProperty)
    TArray<FChatCompletionAttachment> ModerationPromptAttachments() const { return Read<TArray<FChatCompletionAttachment>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    FGuid OratorUtteranceGuid() const { return Read<FGuid>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: StructProperty)
    int32_t RetriesOnServerFailure() const { return Read<int32_t>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: IntProperty)
    float DelayBetweenRetries() const { return Read<float>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: FloatProperty)
    FChatCompletionRequestHandle ModerationChatCompletionRequest() const { return Read<FChatCompletionRequestHandle>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: StructProperty)

    void SET_Instigator(const AController*& Value) { Write<AController*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_MonologueComponent(const UMonologueComponent*& Value) { Write<UMonologueComponent*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_ModeratorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ClassProperty)
    void SET_ChatCompletionRequestToModerate(const FChatCompletionRequestHandle& Value) { Write<FChatCompletionRequestHandle>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_EventsToForgetIfFailed(const TArray<FMonologueEvent>& Value) { Write<TArray<FMonologueEvent>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_ModerationPromptLocalFacts(const TMap<FMonologueFact, FName>& Value) { Write<TMap<FMonologueFact, FName>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x50, Type: MapProperty)
    void SET_ModerationPromptAttachments(const TArray<FChatCompletionAttachment>& Value) { Write<TArray<FChatCompletionAttachment>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    void SET_OratorUtteranceGuid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: StructProperty)
    void SET_RetriesOnServerFailure(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: IntProperty)
    void SET_DelayBetweenRetries(const float& Value) { Write<float>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: FloatProperty)
    void SET_ModerationChatCompletionRequest(const FChatCompletionRequestHandle& Value) { Write<FChatCompletionRequestHandle>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x30
struct FFNRedwoodRestriction : public FTableRowBase
{
public:
    int32_t Index() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    FText Restriction() const { return Read<FText>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: TextProperty)
    TArray<FText> CannedResponsesToViolation() const { return Read<TArray<FText>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_Index(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_Restriction(const FText& Value) { Write<FText>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: TextProperty)
    void SET_CannedResponsesToViolation(const TArray<FText>& Value) { Write<TArray<FText>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x4
struct FFNRedwoodRestrictionViolation
{
public:
    int32_t ViolationIndex() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)

    void SET_ViolationIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x90
struct FFNRedwoodPerceivedPlayerDialogueEventPayload
{
public:
    FMonologuePerceivedEvent PerceivedPlayerDialogueEvent() const { return Read<FMonologuePerceivedEvent>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x38, Type: StructProperty)
    FMonologuePlayerDialogueEvent PlayerDialogueEvent() const { return Read<FMonologuePlayerDialogueEvent>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x48, Type: StructProperty)
    TArray<FChatCompletionAttachment> PlayerDialogueAudioAsAttachments() const { return Read<TArray<FChatCompletionAttachment>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)

    void SET_PerceivedPlayerDialogueEvent(const FMonologuePerceivedEvent& Value) { Write<FMonologuePerceivedEvent>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x38, Type: StructProperty)
    void SET_PlayerDialogueEvent(const FMonologuePlayerDialogueEvent& Value) { Write<FMonologuePlayerDialogueEvent>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x48, Type: StructProperty)
    void SET_PlayerDialogueAudioAsAttachments(const TArray<FChatCompletionAttachment>& Value) { Write<TArray<FChatCompletionAttachment>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa8
struct FFNRedwoodPerceivedTopicalEventPayload
{
public:
    FMonologuePerceivedEvent PerceivedTopicalEvent() const { return Read<FMonologuePerceivedEvent>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x38, Type: StructProperty)
    FMonologueTopicalEvent TopicalEvent() const { return Read<FMonologueTopicalEvent>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x28, Type: StructProperty)
    FMonologueFact TopicalEventConversationCueFact() const { return Read<FMonologueFact>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x48, Type: StructProperty)

    void SET_PerceivedTopicalEvent(const FMonologuePerceivedEvent& Value) { Write<FMonologuePerceivedEvent>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x38, Type: StructProperty)
    void SET_TopicalEvent(const FMonologueTopicalEvent& Value) { Write<FMonologueTopicalEvent>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x28, Type: StructProperty)
    void SET_TopicalEventConversationCueFact(const FMonologueFact& Value) { Write<FMonologueFact>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x48, Type: StructProperty)
};

// Size: 0x88
struct FFNRedwoodReaction_MonologueFactualizedEvent : public FFortEventReaction_SideEffect
{
public:
    FMonologueFactualizedTextTemplate EventDescriptionTemplate() const { return Read<FMonologueFactualizedTextTemplate>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    TMap<FMonologueFact, FName> AdditionalEventDescriptionFacts() const { return Read<TMap<FMonologueFact, FName>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)
    float Significance() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    int32_t RollChance() const { return Read<int32_t>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: IntProperty)

    void SET_EventDescriptionTemplate(const FMonologueFactualizedTextTemplate& Value) { Write<FMonologueFactualizedTextTemplate>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_AdditionalEventDescriptionFacts(const TMap<FMonologueFact, FName>& Value) { Write<TMap<FMonologueFact, FName>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
    void SET_Significance(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_RollChance(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: IntProperty)
};

// Size: 0x30
struct FFNRedwoodReaction_MonologueTopicalEvent : public FFortEventReaction_SideEffect
{
public:
    FText EventDescription() const { return Read<FText>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: TextProperty)
    FText ConversationCue() const { return Read<FText>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: TextProperty)
    float Significance() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    int32_t RollChance() const { return Read<int32_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: IntProperty)

    void SET_EventDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: TextProperty)
    void SET_ConversationCue(const FText& Value) { Write<FText>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: TextProperty)
    void SET_Significance(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_RollChance(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: IntProperty)
};

// Size: 0x20
struct FFNRedwoodReaction_MonologueVerbatimEvent : public FFortEventReaction_SideEffect
{
public:
    FText Monologue() const { return Read<FText>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: TextProperty)
    float Significance() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    int32_t RollChance() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)

    void SET_Monologue(const FText& Value) { Write<FText>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: TextProperty)
    void SET_Significance(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_RollChance(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
};

// Size: 0x58
struct FRedwoodSpatialFactsProvider_TrackedActorData
{
public:
};

