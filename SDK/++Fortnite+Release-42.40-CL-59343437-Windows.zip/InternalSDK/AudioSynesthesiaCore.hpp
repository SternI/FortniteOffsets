/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioSynesthesiaCore
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FLKFSNRTAggregateStats
    {
        float   IntegratedLoudness; // 0x000000 (0x000004)
        float   GatedLoudness;      // 0x000004 (0x000004)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FLKFSNRTChannelData
    {
        FLKFSNRTAggregateStats  AggregateStats;     // 0x000000 (0x000008)
        TArray<FLKFSNRTResults> LoudnessArray;      // 0x000008 (0x000010)
        FFloatInterval          LoudnessInterval;   // 0x000018 (0x000008)
    };
    // Size: 0x000014 (0x000014)
    struct alignas(0x4) FLKFSNRTResults
    {
        int32   Channel;            // 0x000000 (0x000004)
        float   Timestamp;          // 0x000004 (0x000004)
        float   Energy;             // 0x000008 (0x000004)
        float   Loudness;           // 0x00000C (0x000004)
        float   ShortTermLoudness;  // 0x000010 (0x000004)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FLKFSNRTWaveData
    {
        bool                                bIsSortedChronologically;       // 0x000000 (0x000001) [Default: false]
        uint8                               UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        float                               DurationInSeconds;              // 0x000004 (0x000004) [Default: 0f]
        TMap<int32, FLKFSNRTChannelData>    ChannelData;                    // 0x000008 (0x000010)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FLKFSResults
    {
        int32                       Channel;            // 0x000000 (0x000004)
        float                       Timestamp;          // 0x000004 (0x000004)
        float                       Energy;             // 0x000008 (0x000004)
        float                       Loudness;           // 0x00000C (0x000004)
        float                       ShortTermLoudness;  // 0x000010 (0x000004)
        float                       IntegratedLoudness; // 0x000014 (0x000004)
        float                       GatedLoudness;      // 0x000018 (0x000004)
        TOptional<FFloatInterval>   LoudnessRange;      // 0x00001C (0x00000C)
    };
}

