/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArcadeWeaponCoreUI_Functions
 * ============================================================
 */

#include "ArcadeWeaponCoreUI_Functions.hpp"

namespace UE
{

    int32 UArcadeWeaponLeaderboardPlayerEntryVM::GetCurrentMatchScore()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponCoreUI.ArcadeWeaponLeaderboardPlayerEntryVM.GetCurrentMatchScore");
    
        UArcadeWeaponLeaderboardPlayerEntryVM___GetCurrentMatchScore_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UArcadeWeaponLeaderboardPlayerEntryVM::GetHighScore()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponCoreUI.ArcadeWeaponLeaderboardPlayerEntryVM.GetHighScore");
    
        UArcadeWeaponLeaderboardPlayerEntryVM___GetHighScore_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FText UArcadeWeaponLeaderboardPlayerEntryVM::GetName()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponCoreUI.ArcadeWeaponLeaderboardPlayerEntryVM.GetName");
    
        UArcadeWeaponLeaderboardPlayerEntryVM___GetName_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UArcadeWeaponLeaderboardPlayerEntryVM::GetRank()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponCoreUI.ArcadeWeaponLeaderboardPlayerEntryVM.GetRank");
    
        UArcadeWeaponLeaderboardPlayerEntryVM___GetRank_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EArcadeWeaponLeaderboardMode UArcadeWeaponLeaderboardVM::GetLeaderboardMode()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponCoreUI.ArcadeWeaponLeaderboardVM.GetLeaderboardMode");
    
        UArcadeWeaponLeaderboardVM___GetLeaderboardMode_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UArcadeWeaponLeaderboardVM::HandleFriendsLeaderboardChanged()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponCoreUI.ArcadeWeaponLeaderboardVM.HandleFriendsLeaderboardChanged");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UArcadeWeaponLeaderboardVM::HandleGlobalLeaderboardChanged()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponCoreUI.ArcadeWeaponLeaderboardVM.HandleGlobalLeaderboardChanged");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UArcadeWeaponLeaderboardVM::HandleLeaderboardModeChanged()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponCoreUI.ArcadeWeaponLeaderboardVM.HandleLeaderboardModeChanged");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UArcadeWeaponLeaderboardVM::ToggleLeaderboard(EArcadeWeaponLeaderboardType InLeaderboardType)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponCoreUI.ArcadeWeaponLeaderboardVM.ToggleLeaderboard");
    
        UArcadeWeaponLeaderboardVM___ToggleLeaderboard_Params Params{};
        Params.InLeaderboardType = InLeaderboardType;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

