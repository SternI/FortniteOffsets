/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AuroraFortniteRuntime_Functions
 * ============================================================
 */

#include "AuroraFortniteRuntime_Functions.hpp"

namespace UE
{

    void UAuroraFortnitePlayerControllerComponent::OnMinigameStateChanged(AFortMinigame* InMinigame, EFortMinigameState InNewState)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteRuntime.AuroraFortnitePlayerControllerComponent.OnMinigameStateChanged");
    
        UAuroraFortnitePlayerControllerComponent___OnMinigameStateChanged_Params Params{};
        Params.InMinigame = InMinigame;
        Params.InNewState = InNewState;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAuroraFortnitePlayerControllerComponent::Server_SetPlatformFamily(FString InPlatformFamily)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteRuntime.AuroraFortnitePlayerControllerComponent.Server_SetPlatformFamily");
    
        UAuroraFortnitePlayerControllerComponent___Server_SetPlatformFamily_Params Params{};
        Params.InPlatformFamily = InPlatformFamily;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UCustomDebugCommand_AuroraPurchasesAlwaysFail::GetAlwaysFailPurchases()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteRuntime.CustomDebugCommand_AuroraPurchasesAlwaysFail.GetAlwaysFailPurchases");
    
        UCustomDebugCommand_AuroraPurchasesAlwaysFail___GetAlwaysFailPurchases_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UCustomDebugCommand_AuroraPurchasesAlwaysFail::SetAlwaysFailPurchases(bool bInAlwaysFailPurchases)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteRuntime.CustomDebugCommand_AuroraPurchasesAlwaysFail.SetAlwaysFailPurchases");
    
        UCustomDebugCommand_AuroraPurchasesAlwaysFail___SetAlwaysFailPurchases_Params Params{};
        Params.bInAlwaysFailPurchases = bInAlwaysFailPurchases;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

