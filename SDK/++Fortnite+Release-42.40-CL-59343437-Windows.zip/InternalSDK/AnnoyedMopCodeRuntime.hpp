/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnnoyedMopCodeRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000B08 (0x000030)
    class alignas(0x4) AFortProjectileAnnoyedMop : public AFortProjectileBase
    {
    public:
        float   CurrentScale;                   // 0x000AD8 (0x000004) [Default: 1f]
        uint8   UnknownData_000ADC[0x00002C];   // 0x000ADC (0x00002C)
    
    public: // Functions
        void    InitializeCollisionSegments(TArray<UCapsuleComponent*>& SegmentInitializers, UFortProjectileSegmentedCollisionComponent* SegmentedCollisionComp); // 0x07EDC67A [Final | Native | Protected | HasOutParms | BlueprintCallable]
        void    InitializeFXComponent(UNiagaraComponent* FXComponent); // 0x07EDCD48 [Final | Native | Protected | BlueprintCallable]
        float   UpdateSize(float DeltaSeconds, float GrowthSpeed); // 0x07EDD00C [Final | Native | Protected | BlueprintCallable]
    };
    // Size: 0x0011B0 (0x000040)
    class alignas(0x8) UAnnoyedMopPlayerAnimInstance : public UFortPlayerAnimInstanceProxy
    {
    public:
        uint8           bIsActionInput : 1;                             // 0x001170 (0x000001) : 0x0 [Default: false]
        uint8           bIsJumpAOELand : 1;                             // 0x001170 (0x000001) : 0x0 [Default: false]
        uint8           bIsJumpAOEStart : 1;                            // 0x001170 (0x000001) : 0x0 [Default: false]
        uint8           bIsInAirAttack : 1;                             // 0x001170 (0x000001) : 0x0 [Default: false]
        uint8           bIsCombo04 : 1;                                 // 0x001170 (0x000001) : 0x0 [Default: false]
        uint8           bIsInAirAttackLanding : 1;                      // 0x001170 (0x000001) : 0x0 [Default: false]
        uint8           UnknownBit_001170_1 : 1;                        // 0x001170 (0x000001) : 0x1
        uint8           UnknownBit_001170_2 : 1;                        // 0x001170 (0x000001) : 0x2
        uint8           UnknownBit_001170_3 : 1;                        // 0x001170 (0x000001) : 0x3
        uint8           UnknownBit_001170_4 : 1;                        // 0x001170 (0x000001) : 0x4
        uint8           UnknownBit_001170_5 : 1;                        // 0x001170 (0x000001) : 0x5
        uint8           UnknownBit_001170_6 : 1;                        // 0x001170 (0x000001) : 0x6
        uint8           UnknownBit_001170_7 : 1;                        // 0x001170 (0x000001) : 0x7
        uint8           UnknownData_001171[0x000003];                   // 0x001171 (0x000003)
        float           Combo04AOAlpha;                                 // 0x001174 (0x000004) [Default: 0f]
        FName           CurveName_UserCurve01;                          // 0x001178 (0x000004) [Default: FName(729486521) -> L"UserCurve01"]
        FName           CurveName_UserCurve02;                          // 0x00117C (0x000004) [Default: FName(-1674111815) -> L"UserCurve02"]
        FString         MontageName_AnnoyedMop_InAirAttack_M;           // 0x001180 (0x000010) [Default: L"AnnoyedMop_InAirAttack_M"]
        FString         MontageName_Combo_04;                           // 0x001190 (0x000010) [Default: L"Combo_04"]
        FGameplayTag    Granted_Athena_Power_ActivePower_IsActive_Tag;  // 0x0011A0 (0x000004)
        FGameplayTag    MovementMode_Falling_Tag;                       // 0x0011A4 (0x000004)
        uint8           UnknownData_0011A8[0x000008];                   // 0x0011A8 (0x000008)
    };
    // Size: 0x0001D0 (0x000030)
    class alignas(0x8) UAnnoyedMopProjectileComponent : public UFortProjectileSegmentedCollisionComponent
    {
    public:
        float                           CurrentScale;                   // 0x0001A0 (0x000004) [Default: 1f]
        uint8                           UnknownData_0001A4[0x000004];   // 0x0001A4 (0x000004)
        TArray<FCollisionSegmentData>   UnscaledCollisionSegmentData;   // 0x0001A8 (0x000010)
        uint8                           UnknownData_0001B8[0x000018];   // 0x0001B8 (0x000018)
    
    public: // Functions
        void    InitializeFXComponent(UNiagaraComponent* FXComponent); // 0x07EDC12C [Final | Native | Public | BlueprintCallable]
        float   UpdateSize(float DeltaSeconds, float GrowthSpeed); // 0x07EDC3F0 [Final | Native | Public | BlueprintCallable]
    };
    // Size: 0x0005A0 (0x000000)
    class UFortProjectileCollisionSegment : public UCapsuleComponent
    {
    public:
    };
}

