/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BeanstalkRuntime_Functions
 * ============================================================
 */

#include "BeanstalkRuntime.hpp"

namespace UE
{

    struct ABeanCharacter___BP_OnBeanLocalInteractFailed_Params
    {
        AActor* Interactable;   // 0x000000 (0x000008) [Default: 0x1493BD70]
    };

    struct ABeanCharacter___Client_OnTeleport_Params
    {
        FVector     Location;   // 0x000000 (0x000018)
        FRotator    Rotation;   // 0x000018 (0x000018)
    };

    struct ABeanCharacter___Debug_ServerActivateRagdoll_Params
    {
        FVector Force;  // 0x000000 (0x000018)
    };

    struct ABeanCharacter___GetAllCosmeticMaterials_Params
    {
        TArray<UMaterialInstanceDynamic*>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct ABeanCharacter___GetBeanAnimInstance_Params
    {
        UBeanCharAnimInstance*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493BD70]
    };

    struct ABeanCharacter___GetBeanCharacterMovement_Params
    {
        UBeanCharMovementComponent* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493BD70]
    };

    struct ABeanCharacter___GetBeingGrabbedComponent_Params
    {
        UBeanCharBeingGrabbedComponent* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493BD70]
    };

    struct ABeanCharacter___GetCollisionManager_Params
    {
        UBeanCharCollisionManagerComponent* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493BD70]
    };

    struct ABeanCharacter___GetConfiguration_Params
    {
        UBeanCharConfigObject*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493BD70]
    };

    struct ABeanCharacter___GetGrabComponent_Params
    {
        UBeanCharGrabComponent* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493BD70]
    };

    struct ABeanCharacter___GetJiggleMotionComponent_Params
    {
        UBeanJiggleMotionComponent* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493BD70]
    };

    struct ABeanCharacter___GetMantleComponent_Params
    {
        UBeanCharMantleComponent*   ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493BD70]
    };

    struct ABeanCharacter___GetMeshScale_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.49179e-26f]
    };

    struct ABeanCharacter___GetRagdollComponent_Params
    {
        UBeanCharRagdollComponent*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493BD70]
    };

    struct ABeanCharacter___GetRetargetSourceMesh_Params
    {
        USkeletalMeshComponent* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493BD70]
    };

    struct ABeanCharacter___IsBeingGrabbed_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct ABeanCharacter___PredictLaunch_Params
    {
        TScriptInterface<IBeanLaunchPredictorInterface> SourceImpactPredictor;      // 0x000000 (0x000010)
        UObject*                                        SourceOptionalSubobject;    // 0x000010 (0x000008) [Default: 0x19872160]
        FVector                                         LaunchVector;               // 0x000018 (0x000018) [OutParam]
    };

    struct ABeanCharacter___ServerPlayEmote_Params
    {
        UAthenaDanceItemDefinition* EmoteToPlay;    // 0x000000 (0x000008) [Default: 0x1493BD70]
        EFortEmotePlayMode          PlayMode;       // 0x000008 (0x000001) [Default: EFortEmotePlayMode(49)]
    };

    struct ABeanCharacter___TriggerRagdoll_Params
    {
        FVector Force;          // 0x000000 (0x000018) [OutParam]
        bool    bIsViaLaunch;   // 0x000018 (0x000001) [Default: true]
    };

    struct UBeanAudioDataAsset___GetSoundListsByCategory_Params
    {
        TMap<FBeanAudioKey, FBeanAudioSet>  ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UBeanCharAnimInstance___GetConfig_Params
    {
        UBeanCharConfigObject*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14939430]
    };

    struct UBeanCharAnimInstance___TryGetBeanCharacter_Params
    {
        ABeanCharacter* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14939430]
    };

    struct UBeanCharBeingGrabbedComponent___GetGrabbeeDragForce_Params
    {
        float   DragDuration;                   // 0x000000 (0x000004) [Default: 1.49371e-26f]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FVector LocationOffset;                 // 0x000008 (0x000018) [OutParam]
        FVector ReturnValue;                    // 0x000020 (0x000018) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetCamera_Params
    {
        FBeanCharCameraConfig   ReturnValue;    // 0x000000 (0x000018) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetCosmetics_Params
    {
        FBeanCharCosmeticConfig ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetDive_Params
    {
        FBeanCharDiveConfig ReturnValue;    // 0x000000 (0x000058) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetGetup_Params
    {
        FBeanCharGetupConfig    ReturnValue;    // 0x000000 (0x000028) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetGetupRoll_Params
    {
        FBeanCharGetupRollConfig    ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetGrab_Params
    {
        FBeanCharGrabConfig ReturnValue;    // 0x000000 (0x0000D0) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetHUD_Params
    {
        FBeanCharHUDConfig  ReturnValue;    // 0x000000 (0x000020) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetImpact_Params
    {
        FBeanCharImpactConfig   ReturnValue;    // 0x000000 (0x000110) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetInteraction_Params
    {
        FBeanCharInteractionsConfig ReturnValue;    // 0x000000 (0x0000F0) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetInventoryMode_Params
    {
        FBeanCharInventoryModeConfig    ReturnValue;    // 0x000000 (0x000080) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetJiggle_Params
    {
        FBeanCharJiggleConfig   ReturnValue;    // 0x000000 (0x000090) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetJostle_Params
    {
        FBeanCharJostleConfig   ReturnValue;    // 0x000000 (0x000030) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetJump_Params
    {
        FBeanCharJumpConfig ReturnValue;    // 0x000000 (0x000048) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetMantle_Params
    {
        FBeanCharMantleConfig   ReturnValue;    // 0x000000 (0x0000C0) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetMovement_Params
    {
        FBeanCharMovementConfig ReturnValue;    // 0x000000 (0x000178) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetRagdoll_Params
    {
        FBeanCharRagdollConfig  ReturnValue;    // 0x000000 (0x000158) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetRoll_Params
    {
        FBeanCharRollConfig ReturnValue;    // 0x000000 (0x000028) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetStagger_Params
    {
        FBeanCharStaggerConfig  ReturnValue;    // 0x000000 (0x00000C) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetSwimming_Params
    {
        FBeanCharSwimmingConfig ReturnValue;    // 0x000000 (0x000020) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetTouchControls_Params
    {
        FBeanCharTouchControlsConfig    ReturnValue;    // 0x000000 (0x00000C) [ReturnValue]
    };

    struct UBeanCharConfigObject___GetZipline_Params
    {
        FBeanCharZiplineConfig  ReturnValue;    // 0x000000 (0x000004) [ReturnValue]
    };

    struct UBeanCharGrabComponent___GetGrabberDragForce_Params
    {
        float   DragDuration;                   // 0x000000 (0x000004) [Default: 1.4941e-26f]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FVector ReturnValue;                    // 0x000008 (0x000018) [ReturnValue]
    };

    struct UBeanCharMovementComponent___ApplyKnockbackImpulse_Params
    {
        FVector Force;  // 0x000000 (0x000018) [OutParam]
    };

    struct UBeanCharMovementComponent___GetBeanCharacter_Params
    {
        ABeanCharacter* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x149403B0]
    };

    struct UBeanCharMovementComponent___GetTurn180State_Params
    {
        EBeanCharTurn180State   ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EBeanCharTurn180State(176)]
    };

    struct UBeanCharMovementComponent___Server_SetDebugForceCorrection_Params
    {
        EBeanDebugForceCorrectionMode   Mode;   // 0x000000 (0x000001) [Default: EBeanDebugForceCorrectionMode(176)]
    };

    struct UBeanCharMovementComponent___ServerRequestPredictLaunch_Params
    {
        UObject*    SourceObject;               // 0x000000 (0x000008) [Default: 0x149403B0]
        UObject*    SourceOptionalSubobject;    // 0x000008 (0x000008) [Default: 0x6B6318DD00000031]
        FVector     LaunchVector;               // 0x000010 (0x000018)
        float       MovementTimestamp;          // 0x000028 (0x000004) [Default: 1.4951e-26f]
    };

    struct UBeanCharMovementComponent___ServerSuggestImpartedMovementBaseVelocity_Params
    {
        FVector ImpartedVelocity;   // 0x000000 (0x000018)
        float   Timestamp;          // 0x000018 (0x000004) [Default: 1.39087e-23f]
    };

    struct UBeanCharMovementComponent___SetTurn180State_Params
    {
        EBeanCharTurn180State   NewTurnState;   // 0x000000 (0x000001) [Default: EBeanCharTurn180State(176)]
    };

    struct UBeanCharRagdollComponent___ApplyImpulse_Params
    {
        FVector Force;      // 0x000000 (0x000018) [OutParam]
        bool    bIsLaunch;  // 0x000018 (0x000001) [Default: true]
    };

    struct UBeanCharRagdollComponent___Client_SignalRagdollExit_Params
    {
        FVector EndLocation;                    // 0x000000 (0x000018)
        uint8   UnknownData_000018[0x000008];   // 0x000018 (0x000008)
        FQuat   EndRotation;                    // 0x000020 (0x000020)
        FVector EndVelocity;                    // 0x000040 (0x000018)
    };

    struct UBeanCharRagdollComponent___OnRagdollRootPrimitiveHit_Params
    {
        UPrimitiveComponent*    HitComp;        // 0x000000 (0x000008) [Default: 0x14941450]
        AActor*                 OtherActor;     // 0x000008 (0x000008) [Default: 0xBF5C18DD00000031]
        UPrimitiveComponent*    OtherComp;      // 0x000010 (0x000008) [Default: 0x19877B10]
        FVector                 NormalImpulse;  // 0x000018 (0x000018)
        FHitResult              Hit;            // 0x000030 (0x0000F8) [OutParam]
    };

    struct UBeanCharRagdollComponent___ServerRPCRagdollControlInput_Params
    {
        FVector InputVector;    // 0x000000 (0x000018)
    };

    struct UBeanCharRagdollComponent___SetRagdollEnabled_Params
    {
        bool    bShouldEnable;  // 0x000000 (0x000001) [Default: true]
    };

    struct UBeanCharStateMachine___Client_ForceSetState_Params
    {
        EBeanCharStateID    StateUP;                // 0x000000 (0x000001) [Default: EBeanCharStateID(64)]
        EBeanCharStateID    StateLW;                // 0x000001 (0x000001) [Default: EBeanCharStateID(80)]
        uint8               SyncID;                 // 0x000002 (0x000001) [Default: 148]
        bool                bResetPredictionData;   // 0x000003 (0x000001) [Default: true]
    };

    struct UBeanCharStateMachine___ClientRPC_RequestClientChangesState_Params
    {
        EBeanCharStateID    StateId;                        // 0x000000 (0x000001) [Default: EBeanCharStateID(64)]
        uint8               UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        FVector             Location;                       // 0x000008 (0x000018)
        FRotator            Rotation;                       // 0x000020 (0x000018)
    };

    struct UBeanCharStateMachine___Debug_RequestClientChangesState_Params
    {
        EBeanCharStateID    StateId;    // 0x000000 (0x000001) [Default: EBeanCharStateID(64)]
    };

    struct UBeanCharStateMachine___GetState_Params
    {
        EBeanCharStateLayerID   LayerID;                        // 0x000000 (0x000001) [Default: EBeanCharStateLayerID(64)]
        uint8                   UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        UClass*                 ReturnValue;                    // 0x000008 (0x000008) [ReturnValue] [Default: 0xBD5C18DD00000031]
    };

    struct UBeanCharStateMachine___GetStateActiveDuration_Params
    {
        EBeanCharStateID    StateId;                        // 0x000000 (0x000001) [Default: EBeanCharStateID(64)]
        uint8               UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        float               ReturnValue;                    // 0x000004 (0x000004) [ReturnValue] [Default: 0f]
    };

    struct UBeanCharStateMachine___GetStateId_Params
    {
        EBeanCharStateLayerID   LayerID;        // 0x000000 (0x000001) [Default: EBeanCharStateLayerID(64)]
        EBeanCharStateID        ReturnValue;    // 0x000001 (0x000001) [ReturnValue] [Default: EBeanCharStateID(80)]
    };

    struct UBeanCharStateMachine___ServerRPC_RequestClientChangeStateResponse_Params
    {
        EBeanCharStateID    StateId;    // 0x000000 (0x000001) [Default: EBeanCharStateID(64)]
    };

    struct UBeanCharState_Emote___OnEmoteFinishedCallback_Params
    {
        int32   EmoteIndex;         // 0x000000 (0x000004) [Default: 345267296]
        bool    bWasInterruption;   // 0x000004 (0x000001) [Default: false]
    };

    struct UBeanChar_EditMode_AnimLayer___GetConfig_Params
    {
        UBeanCharConfigObject*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493AA70]
    };

    struct UBeanChar_EditMode_AnimLayer___TryGetBeanCharacter_Params
    {
        ABeanCharacter* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493AA70]
    };

    struct UBeanChar_Flying_AnimLayer___GetConfig_Params
    {
        UBeanCharConfigObject*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493ADF0]
    };

    struct UBeanChar_Flying_AnimLayer___TryGetBeanCharacter_Params
    {
        ABeanCharacter* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493ADF0]
    };

    struct UBeanChar_Grab_AnimLayer___GetConfig_Params
    {
        UBeanCharConfigObject*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493B170]
    };

    struct UBeanChar_Grab_AnimLayer___TryGetBeanCharacter_Params
    {
        ABeanCharacter* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493B170]
    };

    struct UBeanChar_GroundLoc_AnimInstance___GetConfig_Params
    {
        UBeanCharConfigObject*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14939850]
    };

    struct UBeanChar_GroundLoc_AnimInstance___TryGetBeanCharacter_Params
    {
        ABeanCharacter* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14939850]
    };

    struct UBeanChar_Idle_AnimInstance___GetConfig_Params
    {
        UBeanCharConfigObject*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14939BD0]
    };

    struct UBeanChar_Idle_AnimInstance___TryGetBeanCharacter_Params
    {
        ABeanCharacter* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14939BD0]
    };

    struct UBeanChar_InAirLoc_AnimInstance___GetConfig_Params
    {
        UBeanCharConfigObject*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14939F50]
    };

    struct UBeanChar_InAirLoc_AnimInstance___TryGetBeanCharacter_Params
    {
        ABeanCharacter* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14939F50]
    };

    struct UBeanChar_Jiggle_AnimInstance___GetConfig_Params
    {
        UBeanCharConfigObject*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493A2D0]
    };

    struct UBeanChar_Jiggle_AnimInstance___TryGetBeanCharacter_Params
    {
        ABeanCharacter* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493A2D0]
    };

    struct UBeanChar_Main_AnimInstance___GetConfig_Params
    {
        UBeanCharConfigObject*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493A650]
    };

    struct UBeanChar_Main_AnimInstance___TryGetBeanCharacter_Params
    {
        ABeanCharacter* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493A650]
    };

    struct UBeanChar_Ragdoll_AnimLayer___GetConfig_Params
    {
        UBeanCharConfigObject*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493B4F0]
    };

    struct UBeanChar_Ragdoll_AnimLayer___TryGetBeanCharacter_Params
    {
        ABeanCharacter* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493B4F0]
    };

    struct UBeanChar_Swimming_AnimLayer___GetConfig_Params
    {
        UBeanCharConfigObject*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493B870]
    };

    struct UBeanChar_Swimming_AnimLayer___TryGetBeanCharacter_Params
    {
        ABeanCharacter* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493B870]
    };

    struct UBeanChar_Zipline_AnimLayer___GetConfig_Params
    {
        UBeanCharConfigObject*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493ADF0]
    };

    struct UBeanChar_Zipline_AnimLayer___TryGetBeanCharacter_Params
    {
        ABeanCharacter* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1493ADF0]
    };

    struct UBeanCheatManager___BeanAllowItemInteractionByTag_Params
    {
        FString TagString;  // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UBeanCheatManager___BeanDisallowItemInteractionByTag_Params
    {
        FString TagString;  // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UBeanCheatManager___BeanEnableBeanInEditMode_Params
    {
        bool    bEnabled;   // 0x000000 (0x000001) [Default: true]
    };

    struct UBeanCheatManager___BeanEnableGetupSpeedModifier_Params
    {
        bool    bEnabled;   // 0x000000 (0x000001) [Default: true]
    };

    struct UBeanCheatManager___BeanEnableInventoryMode_Params
    {
        bool    bEnable;    // 0x000000 (0x000001) [Default: true]
    };

    struct UBeanCheatManager___BeanRelockPlayerActionByTag_Params
    {
        FString TagString;  // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UBeanCheatManager___BeanSetGlobalRagdollThreshold_Params
    {
        float   Threshold;  // 0x000000 (0x000004) [Default: 1.5001e-26f]
    };

    struct UBeanCheatManager___BeanToggleAbilityRestrictions_Params
    {
        bool    bApplyRestrictions; // 0x000000 (0x000001) [Default: true]
    };

    struct UBeanCheatManager___BeanTogglePickupRestrictions_Params
    {
        bool    bApplyRestrictions; // 0x000000 (0x000001) [Default: true]
    };

    struct UBeanCheatManager___BeanUnlockBuildMode_Params
    {
        bool    bUnlock;    // 0x000000 (0x000001) [Default: true]
    };

    struct UBeanCheatManager___BeanUnlockPlayerActionByTag_Params
    {
        FString TagString;  // 0x000000 (0x000010) [Default: L"??"]
    };

    struct IBeanLaunchPredictorInterface___ValidateLaunch_Params
    {
        FBeanPredictedLaunch    PredictedLaunch;    // 0x000000 (0x000058) [OutParam]
        bool                    ReturnValue;        // 0x000058 (0x000001) [ReturnValue] [Default: false]
    };

    struct UBeanstalkFunctionLibrary___CanPawnSwitchToBeanNow_Params
    {
        AFortPlayerPawn*    PlayerPawn;     // 0x000000 (0x000008) [Default: 0x130A5F60]
        bool                ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBeanstalkFunctionLibrary___CanPlayerSwitchToBeanNow_Params
    {
        AFortPlayerController*  PlayerController;   // 0x000000 (0x000008) [Default: 0x130A5F60]
        bool                    ReturnValue;        // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBeanstalkFunctionLibrary___SwitchBackFromBeanPawn_Params
    {
        AFortPlayerController*  PlayerController;   // 0x000000 (0x000008) [Default: 0x130A5F60]
    };

    struct UBeanstalkFunctionLibrary___SwitchToBeanPawn_Params
    {
        AFortPlayerController*  PlayerController;   // 0x000000 (0x000008) [Default: 0x130A5F60]
        bool                    ReturnValue;        // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct UFortAutomationRpcManager_Beanstalk___OnBeanStateChanged_AddToHistory_Params
    {
        EBeanCharStateID        StateId;        // 0x000000 (0x000001) [Default: EBeanCharStateID(192)]
        EBeanCharStateLayerID   LayerID;        // 0x000001 (0x000001) [Default: EBeanCharStateLayerID(140)]
        bool                    bIsReplaying;   // 0x000002 (0x000001) [Default: true]
    };

    struct UFortAutomationRpcManager_Beanstalk___OnBeanStateChanged_BroadcastMessage_Params
    {
        EBeanCharStateID        StateId;        // 0x000000 (0x000001) [Default: EBeanCharStateID(192)]
        EBeanCharStateLayerID   LayerID;        // 0x000001 (0x000001) [Default: EBeanCharStateLayerID(140)]
        bool                    bIsReplaying;   // 0x000002 (0x000001) [Default: true]
    };

    struct UFortAutomationRpcManager_Beanstalk___OnBeanStateChanged_Grounded_ResetDive_Params
    {
        EBeanCharStateID        StateId;        // 0x000000 (0x000001) [Default: EBeanCharStateID(192)]
        EBeanCharStateLayerID   LayerID;        // 0x000001 (0x000001) [Default: EBeanCharStateLayerID(140)]
        bool                    bIsReplaying;   // 0x000002 (0x000001) [Default: true]
    };

    struct UFortAutomationRpcManager_Beanstalk___OnCharacterOverlap_BroadcastMessage_Params
    {
        AActor* OverlappedActor;    // 0x000000 (0x000008) [Default: 0x14948CC0]
        AActor* OtherActor;         // 0x000008 (0x000008) [Default: 0x8A5C18DD00000031]
    };

    struct UFortAutomationRpcManager_Beanstalk___OnCharacterOverlap_Dive_Params
    {
        AActor* OverlappedActor;    // 0x000000 (0x000008) [Default: 0x14948CC0]
        AActor* OtherActor;         // 0x000008 (0x000008) [Default: 0x8A5C18DD00000031]
    };

    struct UFortAutomationRpcManager_Beanstalk___OnCharacterOverlap_Jump_Params
    {
        AActor* OverlappedActor;    // 0x000000 (0x000008) [Default: 0x14948CC0]
        AActor* OtherActor;         // 0x000008 (0x000008) [Default: 0x8A5C18DD00000031]
    };

} // namespace UE

