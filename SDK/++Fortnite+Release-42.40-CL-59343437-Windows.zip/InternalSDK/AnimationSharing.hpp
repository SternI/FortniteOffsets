/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimationSharing
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000280 (0x000020)
    class alignas(0x8) UAnimSharingAdditiveInstance : public UAnimInstance
    {
    public:
        TWeakObjectPtr<USkeletalMeshComponent>  BaseComponent;                  // 0x000260 (0x000008) [Default: nullptr]
        TWeakObjectPtr<UAnimSequence>           AdditiveAnimation;              // 0x000268 (0x000008) [Default: nullptr]
        float                                   Alpha;                          // 0x000270 (0x000004) [Default: 0f]
        bool                                    bStateBool;                     // 0x000274 (0x000001) [Default: false]
        uint8                                   UnknownData_000275[0x00000B];   // 0x000275 (0x00000B)
    };
    // Size: 0x000198 (0x000170)
    class alignas(0x8) UAnimSharingInstance : public UObject
    {
    public:
        TArray<AActor*>                     RegisteredActors;               // 0x000028 (0x000010)
        uint8                               UnknownData_000038[0x000050];   // 0x000038 (0x000050)
        UAnimationSharingStateProcessor*    StateProcessor;                 // 0x000088 (0x000008) [Default: nullptr]
        uint8                               UnknownData_000090[0x000040];   // 0x000090 (0x000040)
        TArray<UAnimSequence*>              UsedAnimationSequences;         // 0x0000D0 (0x000010)
        uint8                               UnknownData_0000E0[0x000010];   // 0x0000E0 (0x000010)
        UEnum*                              StateEnum;                      // 0x0000F0 (0x000008) [Default: nullptr]
        AActor*                             SharingActor;                   // 0x0000F8 (0x000008) [Default: nullptr]
        uint8                               UnknownData_000100[0x000098];   // 0x000100 (0x000098)
    };
    // Size: 0x000280 (0x000020)
    class alignas(0x8) UAnimSharingStateInstance : public UAnimInstance
    {
    public:
        UAnimSequence*          AnimationToPlay;                // 0x000260 (0x000008) [Default: nullptr]
        float                   PermutationTimeOffset;          // 0x000268 (0x000004) [Default: 0f]
        float                   PlayRate;                       // 0x00026C (0x000004) [Default: 1f]
        bool                    bStateBool;                     // 0x000270 (0x000001) [Default: false]
        uint8                   UnknownData_000271[0x000007];   // 0x000271 (0x000007)
        UAnimSharingInstance*   Instance;                       // 0x000278 (0x000008) [Default: nullptr]
    
    public: // Functions
        void    GetInstancedActors(TArray<AActor*>& Actors); // 0x0566EA30 [Final | RequiredAPI | Native | Protected | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000280 (0x000020)
    class alignas(0x8) UAnimSharingTransitionInstance : public UAnimInstance
    {
    public:
        TWeakObjectPtr<USkeletalMeshComponent>  FromComponent;                  // 0x000260 (0x000008) [Default: nullptr]
        TWeakObjectPtr<USkeletalMeshComponent>  ToComponent;                    // 0x000268 (0x000008) [Default: nullptr]
        float                                   BlendTime;                      // 0x000270 (0x000004) [Default: 0.5f]
        bool                                    bBlendBool;                     // 0x000274 (0x000001) [Default: false]
        uint8                                   UnknownData_000275[0x00000B];   // 0x000275 (0x00000B)
    };
    // Size: 0x000118 (0x0000F0)
    class alignas(0x8) UAnimationSharingManager : public UObject
    {
    public:
        TArray<Uskeleton*>              Skeletons;                      // 0x000028 (0x000010)
        TArray<UAnimSharingInstance*>   PerSkeletonData;                // 0x000038 (0x000010)
        uint8                           UnknownData_000048[0x0000A0];   // 0x000048 (0x0000A0)
        void**                          VTable_0000E8;                  // 0x0000E8 (0x000008) VTable [7 slots] -> 0x134D6820
        uint8                           UnknownData_0000F0[0x000028];   // 0x0000F0 (0x000028)
    
    public: // Functions
        static bool                        AnimationSharingEnabled(); // 0x0E45819E [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static bool                        CreateAnimationSharingManager(UObject* WorldContextObject, UAnimationSharingSetup* Setup); // 0x0566ED6C [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static UAnimationSharingManager*   GetAnimationSharingManager(UObject* WorldContextObject); // 0x0566EFEC [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        bool                        RegisterActorWithSkeletonBP(AActor* InActor, Uskeleton* SharingSkeleton); // 0x0566F17C [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x0000B0 (0x000088)
    class alignas(0x8) UAnimationSharingSetup : public UObject
    {
    public:
        TArray<FPerSkeletonAnimationSharingSetup>   SkeletonSetups;         // 0x000028 (0x000010)
        FAnimationSharingScalability                ScalabilitySettings;    // 0x000038 (0x000078)
    };
    // Size: 0x000048 (0x000020)
    class alignas(0x8) UAnimationSharingStateProcessor : public UObject
    {
    public:
        TSoftObjectPtr<UEnum>   AnimationStateEnum; // 0x000028 (0x000020) [Default: nullptr]
    
    public: // Functions
        UEnum*  GetAnimationStateEnum(); // 0x0E457DEC [RequiredAPI | Native | Event | Public | BlueprintEvent]
        void    ProcessActorState(int32& OutState, AActor* InActor, uint8 CurrentState, uint8 OnDemandState, bool& bShouldProcess); // 0x0566E43C [RequiredAPI | Native | Event | Public | HasOutParms | BlueprintEvent]
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x8) FAnimationSetup
    {
        UAnimSequence*      AnimSequence;           // 0x000000 (0x000008)
        UClass*             AnimBlueprint;          // 0x000008 (0x000008)
        FPerPlatformInt     NumRandomizedInstances; // 0x000010 (0x000018)
        FPerPlatformBool    Enabled;                // 0x000028 (0x000018)
    };
    // Size: 0x000078 (0x000078)
    struct alignas(0x8) FAnimationSharingScalability
    {
        FPerPlatformBool    UseBlendTransitions;            // 0x000000 (0x000018)
        FPerPlatformFloat   BlendSignificanceValue;         // 0x000018 (0x000018)
        FPerPlatformInt     MaximumNumberConcurrentBlends;  // 0x000030 (0x000018)
        FPerPlatformFloat   TickSignificanceValue;          // 0x000048 (0x000018)
        FPerPlatformBool    RequireCurvesDuringBlends;      // 0x000060 (0x000018)
    };
    // Size: 0x000048 (0x000048)
    struct alignas(0x8) FAnimationStateEntry
    {
        uint8                   State;                              // 0x000000 (0x000001)
        uint8                   UnknownData_000001[0x000007];       // 0x000001 (0x000007)
        TArray<FAnimationSetup> AnimationSetups;                    // 0x000008 (0x000010)
        bool                    bOnDemand;                          // 0x000018 (0x000001)
        bool                    bRandomizeOnDemandAnims;            // 0x000019 (0x000001)
        bool                    bAdditive;                          // 0x00001A (0x000001)
        uint8                   UnknownByte_00001B;                 // 0x00001B (0x000001)
        float                   BlendTime;                          // 0x00001C (0x000004)
        bool                    bReturnToPreviousState;             // 0x000020 (0x000001)
        bool                    bSetNextState;                      // 0x000021 (0x000001)
        uint8                   NextState;                          // 0x000022 (0x000001)
        uint8                   UnknownData_000023[0x000005];       // 0x000023 (0x000005)
        FPerPlatformInt         MaximumNumberOfConcurrentInstances; // 0x000028 (0x000018)
        float                   WiggleTimePercentage;               // 0x000040 (0x000004)
        bool                    bRequiresCurves;                    // 0x000044 (0x000001)
        uint8                   UnknownData_000045[0x000003];       // 0x000045 (0x000003)
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x8) FPerSkeletonAnimationSharingSetup
    {
        Uskeleton*                      skeleton;                           // 0x000000 (0x000008)
        USkeletalMesh*                  SkeletalMesh;                       // 0x000008 (0x000008)
        UClass*                         BlendAnimBlueprint;                 // 0x000010 (0x000008)
        UClass*                         AdditiveAnimBlueprint;              // 0x000018 (0x000008)
        UClass*                         StateProcessorClass;                // 0x000020 (0x000008)
        bool                            bEnableMaterialParameterCaching;    // 0x000028 (0x000001)
        uint8                           UnknownData_000029[0x000007];       // 0x000029 (0x000007)
        TArray<FAnimationStateEntry>    AnimationStates;                    // 0x000030 (0x000010)
    };
    // Size: 0x000030 (0x000008)
    struct FTickAnimationSharingFunction : public FTickFunction
    {
        uint8   UnknownData_000028[0x000008];   // 0x000028 (0x000008)
    };
}

