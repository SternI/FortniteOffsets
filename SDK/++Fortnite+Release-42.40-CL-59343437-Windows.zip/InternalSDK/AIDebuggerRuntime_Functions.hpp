/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:48
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AIDebuggerRuntime_Functions
 * ============================================================
 */

#include "AIDebuggerRuntime.hpp"

namespace UE
{

    struct UAIDebuggerCheatManager___EnableNavMeshVisualizer_Params
    {
        bool    bEnable;    // 0x000000 (0x000001) [Default: true]
    };

    struct UAIDebuggerCheatManager___StartAIDebugger_Params
    {
        FString AIDebuggerSoftClassPath;    // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UFortControllerComponent_AIDebugger___GetOrCreateRenderer_Params
    {
        UAIDebuggerRendererComponent*   ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14857290]
    };

    struct UFortControllerComponent_AIDebugger___IsVisualizationEnabled_Params
    {
        EAIDebuggerVisualization    VisualizationType;  // 0x000000 (0x000001) [Default: EAIDebuggerVisualization(144)]
        bool                        ReturnValue;        // 0x000001 (0x000001) [ReturnValue] [Default: true]
    };

    struct UFortControllerComponent_AIDebugger___OnPlayerExitedIsland_Params
    {
        FEventMessageTag                        Channel;                        // 0x000000 (0x000004)
        uint8                                   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FPlayerExitSpatialActorContextWithPawn  PlayerExitSpatialActorContext;  // 0x000008 (0x000010) [OutParam]
    };

    struct UFortControllerComponent_AIDebugger___OnPossessedPawnChanged_Params
    {
        APawn*  OldPawn;    // 0x000000 (0x000008) [Default: 0x14857290]
        APawn*  NewPawn;    // 0x000008 (0x000008) [Default: 0x445E18DD00000031]
    };

    struct UFortControllerComponent_AIDebugger___SetVisualizationEnable_Params
    {
        EAIDebuggerVisualization    VisualizationType;  // 0x000000 (0x000001) [Default: EAIDebuggerVisualization(144)]
        bool                        bEnable;            // 0x000001 (0x000001) [Default: true]
    };

    struct UFortControllerComponent_AIDebugger___VisualizeNavMeshID_Params
    {
        int32   NavMeshID;  // 0x000000 (0x000004) [Default: 344289936]
    };

} // namespace UE

