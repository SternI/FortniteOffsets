/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BeanstalkDevicesCoreRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000288 (0x000018)
    class ABeanObstacleTickManager : public AActor
    {
    public:
        uint8   UnknownData_000270[0x000018];   // 0x000270 (0x000018)
    
    public: // Functions
        void    OnTickableComponentEndPlay(AActor* Actor, TEnumAsByte<EEndPlayReason> EndPlayReason); // 0x080E1880 [Final | Native | Private]
    };
    // Size: 0x000028 (0x000000)
    class UBeanDeviceFunctionLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FVector CalculateKnockbackForce(FBeanKnockbackForceCalculator& KnockbackForceCalculator, FVector SourceLocation, FVector TargetLocation); // 0x080DD6DC [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000150 (0x000090)
    class alignas(0x8) UBeanObstacleImpactComponent : public UActorComponent
    {
    public:
        void**                                      VTable_0000C0;                                      // 0x0000C0 (0x000008) VTable [3 slots] -> 0x14770790
        MULTI_INLINE_DELEGATE(BeanOnObstacleImpact) OnObstacleImpact;                                   // 0x0000C8 (0x000010)
        bool                                        bApplyDefaultKnockback;                             // 0x0000D8 (0x000001) [Default: true]
        bool                                        bApplyRagdoll;                                      // 0x0000D9 (0x000001) [Default: true]
        uint8                                       UnknownData_0000DA[0x000006];                       // 0x0000DA (0x000006)
        TArray<FComponentReference>                 AffectedColliders;                                  // 0x0000E0 (0x000010)
        FBeanKnockbackForceCalculator               KnockbackForce;                                     // 0x0000F0 (0x000030)
        bool                                        bApplyImpactLocally;                                // 0x000120 (0x000001) [Default: false]
        uint8                                       UnknownData_000121[0x000007];                       // 0x000121 (0x000007)
        double                                      MaxExpectedComponentVelocityForServerValidation;    // 0x000128 (0x000008) [Default: 0]
        TArray<TWeakObjectPtr<UPrimitiveComponent>> CachedColliders;                                    // 0x000130 (0x000010)
        TArray<FBeanComponentTransformDelta>        CachedColliderDeltas;                               // 0x000140 (0x000010)
    
    public: // Functions
        void    OnAffectedComponentHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, FHitResult& Hit); // 0x080DDF1A [Final | Native | Protected | HasOutParms | HasDefaults]
        void    OnSleepStateChanged(bool bIsSleeping); // 0x080DE548 [Final | Native | Protected]
    };
    // Size: 0x000110 (0x000050)
    class alignas(0x8) UBeanObstacleMeshSelectorComponent : public UActorComponent
    {
    public:
        MULTI_INLINE_DELEGATE(OnSelectedMeshSetSignature)   OnSelectedMeshSetDelegate;      // 0x0000C0 (0x000010)
        FComponentReference                                 TargetStaticMeshComponentRef;   // 0x0000D0 (0x000028)
        TArray<FSelectableMeshData>                         SelectableMeshes;               // 0x0000F8 (0x000010)
        UStaticMeshComponent*                               TargetStaticMeshComponent;      // 0x000108 (0x000008) [Default: nullptr]
    
    public: // Functions
        bool    SetSelectedMeshIndex(int32 MeshIndex); // 0x080DF6C2 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class UBeanObstacleMotion : public UObject
    {
    public:
    };
    // Size: 0x000058 (0x000030)
    class alignas(0x8) UBeanObstacleMotion_Punch : public UBeanObstacleMotion
    {
    public:
        FVector MovementVector;                 // 0x000028 (0x000018)
        float   StartDelay;                     // 0x000040 (0x000004) [Default: 0f]
        float   MoveOutDuration;                // 0x000044 (0x000004) [Default: 0.2f]
        float   OutPauseDuration;               // 0x000048 (0x000004) [Default: 0.5f]
        float   MoveInDuration;                 // 0x00004C (0x000004) [Default: 1f]
        float   InPauseDuration;                // 0x000050 (0x000004) [Default: 1f]
        uint8   UnknownData_000054[0x000004];   // 0x000054 (0x000004)
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x4) UBeanObstacleMotion_Rotational : public UBeanObstacleMotion
    {
    public:
        TEnumAsByte<EAxis>  RotationAxis;                   // 0x000028 (0x000001) [Default: 3]
        uint8               UnknownData_000029[0x000003];   // 0x000029 (0x000003)
        float               RotationSpeed;                  // 0x00002C (0x000004) [Default: 360f]
        float               StartRotation;                  // 0x000030 (0x000004) [Default: 0f]
        uint8               UnknownData_000034[0x000004];   // 0x000034 (0x000004)
    };
    // Size: 0x0001E0 (0x000120)
    class alignas(0x8) UBeanObstacleMovementComponent : public UActorComponent
    {
    public:
        uint8                                                       bRegisterWithBeanTickManager : 1;           // 0x0000C0 (0x000001) : 0x0 [Default: false]
        uint8                                                       UnknownBit_0000C0_1 : 1;                    // 0x0000C0 (0x000001) : 0x1
        uint8                                                       UnknownBit_0000C0_2 : 1;                    // 0x0000C0 (0x000001) : 0x2
        uint8                                                       UnknownBit_0000C0_3 : 1;                    // 0x0000C0 (0x000001) : 0x3
        uint8                                                       UnknownBit_0000C0_4 : 1;                    // 0x0000C0 (0x000001) : 0x4
        uint8                                                       UnknownBit_0000C0_5 : 1;                    // 0x0000C0 (0x000001) : 0x5
        uint8                                                       UnknownBit_0000C0_6 : 1;                    // 0x0000C0 (0x000001) : 0x6
        uint8                                                       UnknownBit_0000C0_7 : 1;                    // 0x0000C0 (0x000001) : 0x7
        uint8                                                       UnknownData_0000C1[0x000007];               // 0x0000C1 (0x000007)
        MULTI_INLINE_DELEGATE(BeanOnObstacleRewindChangedSignature) OnRewindStateChangedDelegate;               // 0x0000C8 (0x000010)
        MULTI_INLINE_DELEGATE(BeanOnObstacleMovementStartedMoving)  ClientOnStartedMoving;                      // 0x0000D8 (0x000010)
        MULTI_INLINE_DELEGATE(BeanOnObstacleMovementStoppedMoving)  ClientOnStoppedMoving;                      // 0x0000E8 (0x000010)
        FComponentReference                                         TargetComponentRef;                         // 0x0000F8 (0x000028)
        UBeanObstacleMotion*                                        ObstacleMotion;                             // 0x000120 (0x000008) [Default: nullptr]
        bool                                                        bShouldSweep;                               // 0x000128 (0x000001) [Default: false]
        uint8                                                       UnknownData_000129[0x000003];               // 0x000129 (0x000003)
        float                                                       ReconciliationInterpSpeed;                  // 0x00012C (0x000004) [Default: 10f]
        bool                                                        bEnableEventSleeping;                       // 0x000130 (0x000001) [Default: true]
        uint8                                                       UnknownData_000131[0x000007];               // 0x000131 (0x000007)
        double                                                      EventSleepDistanceThreshold;                // 0x000138 (0x000008) [Default: 1000]
        double                                                      EventSleepPollInterval;                     // 0x000140 (0x000008) [Default: 0.5]
        FVector                                                     TargetComponentOriginalRelativeLocation;    // 0x000148 (0x000018)
        FQuat                                                       TargetComponentOriginalRelativeRotation;    // 0x000160 (0x000020)
        TWeakObjectPtr<USceneComponent>                             TargetComponent;                            // 0x000180 (0x000008) [Default: nullptr]
        double                                                      LastEventSleepPollTime;                     // 0x000188 (0x000008) [Default: -1]
        uint8                                                       bLastFiredEventWasStart : 1;                // 0x000190 (0x000001) : 0x0 [Default: true]
        uint8                                                       bAreEventsAsleep : 1;                       // 0x000190 (0x000001) : 0x0 [Default: true]
        uint8                                                       bIsUsingTickManager : 1;                    // 0x000190 (0x000001) : 0x0 [Default: true]
        uint8                                                       bIsObstacleTickSleeping : 1;                // 0x000190 (0x000001) : 0x0 [Default: true]
        uint8                                                       bStartWithMotionEnabled : 1;                // 0x000190 (0x000001) : 0x0 [Default: true]
        uint8                                                       UnknownBit_000190_1 : 1;                    // 0x000190 (0x000001) : 0x1
        uint8                                                       UnknownBit_000190_2 : 1;                    // 0x000190 (0x000001) : 0x2
        uint8                                                       UnknownBit_000190_3 : 1;                    // 0x000190 (0x000001) : 0x3
        uint8                                                       UnknownBit_000190_4 : 1;                    // 0x000190 (0x000001) : 0x4
        uint8                                                       UnknownBit_000190_5 : 1;                    // 0x000190 (0x000001) : 0x5
        uint8                                                       UnknownBit_000190_6 : 1;                    // 0x000190 (0x000001) : 0x6
        uint8                                                       UnknownBit_000190_7 : 1;                    // 0x000190 (0x000001) : 0x7
        uint8                                                       UnknownData_000191[0x000007];               // 0x000191 (0x000007)
        FBeanObstacleMotionRuntimeState                             ObstacleMotionRuntimeState;                 // 0x000198 (0x000030)
        double                                                      CurrentEvalTime;                            // 0x0001C8 (0x000008) [Default: 0]
        EBeanObstacleMotionMovementState                            LastObstacleMovementState;                  // 0x0001D0 (0x000001) [Default: EBeanObstacleMotionMovementState(0)]
        uint8                                                       UnknownData_0001D1[0x00000F];               // 0x0001D1 (0x00000F)
    
    public: // Functions
        bool    IsMotionLocked(); // 0x10E1612C [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool    IsRewinding(); // 0x10E16148 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    OnRep_ObstacleMotionRuntimeState(FBeanObstacleMotionRuntimeState& OldRuntimeState); // 0x080DF862 [Final | Native | Protected | HasOutParms]
        void    OnSleepStateChanged(bool bIsSleeping); // 0x080DF9F8 [Final | Native | Protected]
        void    SetIsMotionLocked(bool bNewIsLocked, bool bResetToInitial); // 0x080DFB68 [Final | BlueprintAuthorityOnly | Native | Public | BlueprintCallable]
        void    SetIsRewinding(bool bNewRewind); // 0x080DFDF0 [Final | BlueprintAuthorityOnly | Native | Public | BlueprintCallable]
    };
    // Size: 0x000600 (0x000050)
    class alignas(0x8) UBeanObstacleOptimizerComponent : public UBoxComponent
    {
    public:
        float                                                       ExtraMarginSize;                                // 0x0005B0 (0x000004) [Default: 50f]
        bool                                                        bDisableCollidersWhenSleeping;                  // 0x0005B4 (0x000001) [Default: false]
        bool                                                        bDetachFromParentAndAttachToOptimizerActor;     // 0x0005B5 (0x000001) [Default: true]
        uint8                                                       UnknownData_0005B6[0x000002];                   // 0x0005B6 (0x000002)
        MULTI_INLINE_DELEGATE(OnSleepStateChanged)                  OnSleepStateChanged;                            // 0x0005B8 (0x000010)
        bool                                                        bIsSleeping;                                    // 0x0005C8 (0x000001) [Default: false]
        uint8                                                       UnknownData_0005C9[0x000003];                   // 0x0005C9 (0x000003)
        int32                                                       NumPawnsOverlapping;                            // 0x0005CC (0x000004) [Default: 0]
        TArray<TWeakObjectPtr<UPrimitiveComponent>>                 OptimizableColliders;                           // 0x0005D0 (0x000010)
        TMap<UPrimitiveComponent*, TEnumAsByte<ECollisionEnabled>>  OptimizableCollidersOriginalCollisionEnabled;   // 0x0005E0 (0x000010)
        uint8                                                       UnknownData_0005F0[0x000010];                   // 0x0005F0 (0x000010)
    
    public: // Functions
        void    OnOptimizerBeginOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, FHitResult& SweepResult); // 0x080E0710 [Final | RequiredAPI | Native | Protected | HasOutParms]
        void    OnOptimizerEndOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex); // 0x080E0D64 [Final | RequiredAPI | Native | Protected]
        void    OnOriginalOwnerEndPlay(AActor* Actor, TEnumAsByte<EEndPlayReason> EndPlayReason); // 0x080E122E [Final | RequiredAPI | Native | Protected]
        void    RecalculateEstimatedBounds(); // 0x10E17138 [Final | RequiredAPI | Native | Protected]
        void    OnSleepStateChanged(bool bIsSleeping); // 0x000545D2 [MulticastDelegate | Public | Delegate]
    };
    // Size: 0x0000D0 (0x0000D0)
    struct FBeanComponentTransformDelta
    {
        uint8   UnknownData_000000[0x0000D0];   // 0x000000 (0x0000D0)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FBeanKnockbackForceCalculator
    {
        EBeanObstacleImpactForceCalculatorType  Type;                               // 0x000000 (0x000001) [Default: EBeanObstacleImpactForceCalculatorType(16)]
        EBeanObstacleImpactForceApplication     ForceApplicationType;               // 0x000001 (0x000001) [Default: EBeanObstacleImpactForceApplication(111)]
        uint8                                   UnknownData_000002[0x000006];       // 0x000002 (0x000006)
        double                                  Strength;                           // 0x000008 (0x000008) [Default: 1.76334e-315]
        double                                  HorizontalStrength;                 // 0x000010 (0x000008) [Default: -1.94295e+139]
        double                                  VerticalStrength;                   // 0x000018 (0x000008) [Default: 1.87621e-315]
        double                                  Angle;                              // 0x000020 (0x000008) [Default: 2.11642e-315]
        bool                                    bAddSourceColliderVelocity;         // 0x000028 (0x000001) [Default: true]
        uint8                                   UnknownData_000029[0x000003];       // 0x000029 (0x000003)
        float                                   SourceColliderVelocityMultiplier;   // 0x00002C (0x000004) [Default: 9.29481e-42f]
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FBeanObstacleMotionRuntimeState
    {
        EObstacleMotionLockedState  MotionLockedState;              // 0x000000 (0x000004)
        uint8                       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        double                      MotionLockedChangedTime;        // 0x000008 (0x000008)
        bool                        bRewinding;                     // 0x000010 (0x000001)
        uint8                       UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        double                      RewindChangedTime;              // 0x000018 (0x000008)
        double                      AccumulatedTimeOffset;          // 0x000020 (0x000008)
        double                      LocalAccumulatedTimeOffset;     // 0x000028 (0x000008)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FSelectableMeshData
    {
        TSoftObjectPtr<UStaticMesh> Mesh;   // 0x000000 (0x000020)
    };
}

