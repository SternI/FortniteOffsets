/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:08
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AIModule_Functions
 * ============================================================
 */

#include "AIModule.hpp"

namespace UE
{

    struct AAIController___ClaimTaskResource_Params
    {
        UClass* ResourceClass;  // 0x000000 (0x000008) [Default: 0x1348C7F0]
    };

    struct AAIController___GetAIPerceptionComponent_Params
    {
        UAIPerceptionComponent* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1348C7F0]
    };

    struct AAIController___GetFocalPoint_Params
    {
        FVector ReturnValue;    // 0x000000 (0x000018) [ReturnValue]
    };

    struct AAIController___GetFocalPointOnActor_Params
    {
        AActor* Actor;          // 0x000000 (0x000008) [Default: 0x1348C7F0]
        FVector ReturnValue;    // 0x000008 (0x000018) [ReturnValue]
    };

    struct AAIController___GetFocusActor_Params
    {
        AActor* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1348C7F0]
    };

    struct AAIController___GetImmediateMoveDestination_Params
    {
        FVector ReturnValue;    // 0x000000 (0x000018) [ReturnValue]
    };

    struct AAIController___GetMoveStatus_Params
    {
        TEnumAsByte<EPathFollowingStatus>   ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: 240]
    };

    struct AAIController___GetPathFollowingComponent_Params
    {
        UPathFollowingComponent*    ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1348C7F0]
    };

    struct AAIController___HasPartialPath_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct AAIController___K2_SetFocalPoint_Params
    {
        FVector FP; // 0x000000 (0x000018)
    };

    struct AAIController___K2_SetFocus_Params
    {
        AActor* NewFocus;   // 0x000000 (0x000008) [Default: 0x1348C7F0]
    };

    struct AAIController___MoveToActor_Params
    {
        AActor*                                     Goal;               // 0x000000 (0x000008) [Default: 0x1348C7F0]
        float                                       AcceptanceRadius;   // 0x000008 (0x000004) [Default: 6.86636e-44f]
        bool                                        bStopOnOverlap;     // 0x00000C (0x000001) [Default: true]
        bool                                        bUsePathfinding;    // 0x00000D (0x000001) [Default: true]
        bool                                        bCanStrafe;         // 0x00000E (0x000001) [Default: true]
        uint8                                       UnknownByte_00000F; // 0x00000F (0x000001)
        UClass*                                     FilterClass;        // 0x000010 (0x000008) [Default: 0x17308FE0]
        bool                                        bAllowPartialPath;  // 0x000018 (0x000001) [Default: true]
        TEnumAsByte<EPathFollowingRequestResult>    ReturnValue;        // 0x000019 (0x000001) [ReturnValue] [Default: 132]
    };

    struct AAIController___MoveToLocation_Params
    {
        FVector                                     Dest;                               // 0x000000 (0x000018) [OutParam]
        float                                       AcceptanceRadius;                   // 0x000018 (0x000004) [Default: 5.70364e-25f]
        bool                                        bStopOnOverlap;                     // 0x00001C (0x000001) [Default: false]
        bool                                        bUsePathfinding;                    // 0x00001D (0x000001) [Default: false]
        bool                                        bProjectDestinationToNavigation;    // 0x00001E (0x000001) [Default: false]
        bool                                        bCanStrafe;                         // 0x00001F (0x000001) [Default: false]
        UClass*                                     FilterClass;                        // 0x000020 (0x000008) [Default: 0xD41A84BB]
        bool                                        bAllowPartialPath;                  // 0x000028 (0x000001) [Default: true]
        TEnumAsByte<EPathFollowingRequestResult>    ReturnValue;                        // 0x000029 (0x000001) [ReturnValue] [Default: 40]
    };

    struct AAIController___OnGameplayTaskResourcesClaimed_Params
    {
        FGameplayResourceSet    NewlyClaimed;       // 0x000000 (0x000002)
        FGameplayResourceSet    FreshlyReleased;    // 0x000002 (0x000002)
    };

    struct AAIController___OnUsingBlackBoard_Params
    {
        UBlackboardComponent*   BlackboardComp;     // 0x000000 (0x000008) [Default: 0x1348C7F0]
        UBlackboardData*        BlackboardAsset;    // 0x000008 (0x000008) [Default: 0x9F7518DD00000031]
    };

    struct AAIController___RunBehaviorTree_Params
    {
        UBehaviorTree*  BTAsset;        // 0x000000 (0x000008) [Default: 0x1348C7F0]
        bool            ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct AAIController___SetMoveBlockDetection_Params
    {
        bool    bEnable;    // 0x000000 (0x000001) [Default: true]
    };

    struct AAIController___SetPathFollowingComponent_Params
    {
        UPathFollowingComponent*    NewPFComponent; // 0x000000 (0x000008) [Default: 0x1348C7F0]
    };

    struct AAIController___UnclaimTaskResource_Params
    {
        UClass* ResourceClass;  // 0x000000 (0x000008) [Default: 0x1348C7F0]
    };

    struct AAIController___UseBlackboard_Params
    {
        UBlackboardData*        BlackboardAsset;        // 0x000000 (0x000008) [Default: 0x1348C7F0]
        UBlackboardComponent*   BlackboardComponent;    // 0x000008 (0x000008) [OutParam] [Default: 0x9F7518DD00000031]
        bool                    ReturnValue;            // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct ANavLinkProxy___HasMovingAgents_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct ANavLinkProxy___IsSmartLinkEnabled_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct ANavLinkProxy___ReceiveSmartLinkReached_Params
    {
        AActor* Agent;          // 0x000000 (0x000008) [Default: 0x134ADDA0]
        FVector Destination;    // 0x000008 (0x000018) [OutParam]
    };

    struct ANavLinkProxy___ResumePathFollowing_Params
    {
        AActor* Agent;  // 0x000000 (0x000008) [Default: 0x134ADDA0]
    };

    struct ANavLinkProxy___SetSmartLinkEnabled_Params
    {
        bool    bEnabled;   // 0x000000 (0x000001) [Default: true]
    };

    struct UAIAsyncTaskBlueprintProxy___OnMoveCompleted_Params
    {
        FAIRequestID                        RequestID;      // 0x000000 (0x000004)
        TEnumAsByte<EPathFollowingResult>   MovementResult; // 0x000004 (0x000001) [Default: 0]
    };

    struct UAIBlueprintHelperLibrary___CreateMoveToProxyObject_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x130A5F60]
        APawn*                      Pawn;                           // 0x000008 (0x000008) [Default: 0x162718DD00000031]
        FVector                     Destination;                    // 0x000010 (0x000018)
        AActor*                     TargetActor;                    // 0x000028 (0x000008) [Default: 0x1349FCA0]
        float                       AcceptanceRadius;               // 0x000030 (0x000004) [Default: 6.86636e-44f]
        bool                        bStopOnOverlap;                 // 0x000034 (0x000001) [Default: true]
        uint8                       UnknownData_000035[0x000003];   // 0x000035 (0x000003)
        UAIAsyncTaskBlueprintProxy* ReturnValue;                    // 0x000038 (0x000008) [ReturnValue] [Default: 0x1731C6F0]
    };

    struct UAIBlueprintHelperLibrary___GetAIController_Params
    {
        AActor*         ControlledActor;    // 0x000000 (0x000008) [Default: 0x130A5F60]
        AAIController*  ReturnValue;        // 0x000008 (0x000008) [ReturnValue] [Default: 0x162718DD00000031]
    };

    struct UAIBlueprintHelperLibrary___GetBlackboard_Params
    {
        AActor*                 Target;         // 0x000000 (0x000008) [Default: 0x130A5F60]
        UBlackboardComponent*   ReturnValue;    // 0x000008 (0x000008) [ReturnValue] [Default: 0x162718DD00000031]
    };

    struct UAIBlueprintHelperLibrary___GetCurrentPath_Params
    {
        AController*        Controller;     // 0x000000 (0x000008) [Default: 0x130A5F60]
        UNavigationPath*    ReturnValue;    // 0x000008 (0x000008) [ReturnValue] [Default: 0x162718DD00000031]
    };

    struct UAIBlueprintHelperLibrary___GetCurrentPathIndex_Params
    {
        AController*    Controller;     // 0x000000 (0x000008) [Default: 0x130A5F60]
        int32           ReturnValue;    // 0x000008 (0x000004) [ReturnValue] [Default: 49]
    };

    struct UAIBlueprintHelperLibrary___GetCurrentPathPoints_Params
    {
        AController*    Controller;     // 0x000000 (0x000008) [Default: 0x130A5F60]
        TArray<FVector> ReturnValue;    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UAIBlueprintHelperLibrary___GetNextNavLinkIndex_Params
    {
        AController*    Controller;     // 0x000000 (0x000008) [Default: 0x130A5F60]
        int32           ReturnValue;    // 0x000008 (0x000004) [ReturnValue] [Default: 49]
    };

    struct UAIBlueprintHelperLibrary___IsValidAIDirection_Params
    {
        FVector DirectionVector;    // 0x000000 (0x000018)
        bool    ReturnValue;        // 0x000018 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAIBlueprintHelperLibrary___IsValidAILocation_Params
    {
        FVector Location;       // 0x000000 (0x000018)
        bool    ReturnValue;    // 0x000018 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAIBlueprintHelperLibrary___IsValidAIRotation_Params
    {
        FRotator    Rotation;       // 0x000000 (0x000018)
        bool        ReturnValue;    // 0x000018 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAIBlueprintHelperLibrary___LockAIResourcesWithAnimation_Params
    {
        UAnimInstance*  AnimInstance;   // 0x000000 (0x000008) [Default: 0x130A5F60]
        bool            bLockMovement;  // 0x000008 (0x000001) [Default: true]
        bool            LockAILogic;    // 0x000009 (0x000001) [Default: false]
    };

    struct UAIBlueprintHelperLibrary___SendAIMessage_Params
    {
        APawn*      Target;                         // 0x000000 (0x000008) [Default: 0x130A5F60]
        FName       Message;                        // 0x000008 (0x000004) [Default: FName(49) -> L""]
        uint8       UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        UObject*    MessageSource;                  // 0x000010 (0x000008) [Default: 0x1731C3D0]
        bool        bSuccess;                       // 0x000018 (0x000001) [Default: true]
    };

    struct UAIBlueprintHelperLibrary___SimpleMoveToActor_Params
    {
        AController*    Controller; // 0x000000 (0x000008) [Default: 0x130A5F60]
        AActor*         Goal;       // 0x000008 (0x000008) [Default: 0x162718DD00000031]
    };

    struct UAIBlueprintHelperLibrary___SimpleMoveToLocation_Params
    {
        AController*    Controller; // 0x000000 (0x000008) [Default: 0x130A5F60]
        FVector         Goal;       // 0x000008 (0x000018) [OutParam]
    };

    struct UAIBlueprintHelperLibrary___SpawnAIFromClass_Params
    {
        UObject*        WorldContextObject;             // 0x000000 (0x000008) [Default: 0x130A5F60]
        UClass*         PawnClass;                      // 0x000008 (0x000008) [Default: 0x162718DD00000031]
        UBehaviorTree*  BehaviorTree;                   // 0x000010 (0x000008) [Default: 0x1731C3D0]
        FVector         Location;                       // 0x000018 (0x000018)
        FRotator        Rotation;                       // 0x000030 (0x000018)
        bool            bNoCollisionFail;               // 0x000048 (0x000001) [Default: true]
        uint8           UnknownData_000049[0x000007];   // 0x000049 (0x000007)
        AActor*         Owner;                          // 0x000050 (0x000008) [Default: nullptr]
        APawn*          ReturnValue;                    // 0x000058 (0x000008) [ReturnValue] [Default: nullptr]
    };

    struct UAIBlueprintHelperLibrary___UnlockAIResourcesWithAnimation_Params
    {
        UAnimInstance*  AnimInstance;       // 0x000000 (0x000008) [Default: 0x130A5F60]
        bool            bUnlockMovement;    // 0x000008 (0x000001) [Default: true]
        bool            UnlockAILogic;      // 0x000009 (0x000001) [Default: false]
    };

    struct UAIPerceptionComponent___GetActorsPerception_Params
    {
        AActor*                         Actor;          // 0x000000 (0x000008) [Default: 0x134AF0A0]
        FActorPerceptionBlueprintInfo   Info;           // 0x000008 (0x000020) [OutParam]
        bool                            ReturnValue;    // 0x000028 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAIPerceptionComponent___GetCurrentlyPerceivedActors_Params
    {
        UClass*         SenseToUse; // 0x000000 (0x000008) [Default: 0x134AF0A0]
        TArray<AActor*> OutActors;  // 0x000008 (0x000010) [OutParam]
    };

    struct UAIPerceptionComponent___GetKnownPerceivedActors_Params
    {
        UClass*         SenseToUse; // 0x000000 (0x000008) [Default: 0x134AF0A0]
        TArray<AActor*> OutActors;  // 0x000008 (0x000010) [OutParam]
    };

    struct UAIPerceptionComponent___GetPerceivedHostileActors_Params
    {
        TArray<AActor*> OutActors;  // 0x000000 (0x000010) [OutParam]
    };

    struct UAIPerceptionComponent___GetPerceivedHostileActorsBySense_Params
    {
        UClass*         SenseToUse; // 0x000000 (0x000008) [Default: 0x134AF0A0]
        TArray<AActor*> OutActors;  // 0x000008 (0x000010) [OutParam]
    };

    struct UAIPerceptionComponent___IsSenseEnabled_Params
    {
        UClass* SenseClass;     // 0x000000 (0x000008) [Default: 0x134AF0A0]
        bool    ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAIPerceptionComponent___OnOwnerEndPlay_Params
    {
        AActor*                     Actor;          // 0x000000 (0x000008) [Default: 0x134AF0A0]
        TEnumAsByte<EEndPlayReason> EndPlayReason;  // 0x000008 (0x000001) [Default: 49]
    };

    struct UAIPerceptionComponent___SetSenseEnabled_Params
    {
        UClass* SenseClass; // 0x000000 (0x000008) [Default: 0x134AF0A0]
        bool    bEnable;    // 0x000008 (0x000001) [Default: true]
    };

    struct UAIPerceptionStimuliSourceComponent___RegisterForSense_Params
    {
        UClass* SenseClass; // 0x000000 (0x000008) [Default: 0x134AF610]
    };

    struct UAIPerceptionStimuliSourceComponent___UnregisterFromSense_Params
    {
        UClass* SenseClass; // 0x000000 (0x000008) [Default: 0x134AF610]
    };

    struct UAIPerceptionSystem___GetSenseClassForStimulus_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x134AFB50]
        FAIStimulus Stimulus;           // 0x000008 (0x000050) [OutParam]
        UClass*     ReturnValue;        // 0x000058 (0x000008) [ReturnValue] [Default: 0x232DF3E99999A]
    };

    struct UAIPerceptionSystem___OnPerceptionStimuliSourceEndPlay_Params
    {
        AActor*                     Actor;          // 0x000000 (0x000008) [Default: 0x134AFB50]
        TEnumAsByte<EEndPlayReason> EndPlayReason;  // 0x000008 (0x000001) [Default: 49]
    };

    struct UAIPerceptionSystem___RegisterPerceptionStimuliSource_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x134AFB50]
        UClass*     Sense;              // 0x000008 (0x000008) [Default: 0x604E18DD00000031]
        AActor*     Target;             // 0x000010 (0x000008) [Default: 0x17340040]
        bool        ReturnValue;        // 0x000018 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAIPerceptionSystem___ReportEvent_Params
    {
        UAISenseEvent*  PerceptionEvent;    // 0x000000 (0x000008) [Default: 0x134AFB50]
    };

    struct UAIPerceptionSystem___ReportPerceptionEvent_Params
    {
        UObject*        WorldContextObject; // 0x000000 (0x000008) [Default: 0x134AFB50]
        UAISenseEvent*  PerceptionEvent;    // 0x000008 (0x000008) [Default: 0x604E18DD00000031]
    };

    struct UAISense_Blueprint___GetAllListenerActors_Params
    {
        TArray<AActor*> ListenerActors; // 0x000000 (0x000010) [OutParam]
    };

    struct UAISense_Blueprint___GetAllListenerComponents_Params
    {
        TArray<UAIPerceptionComponent*> ListenerComponents; // 0x000000 (0x000010) [OutParam]
    };

    struct UAISense_Blueprint___K2_OnNewPawn_Params
    {
        APawn*  NewPawn;    // 0x000000 (0x000008) [Default: 0x134B0650]
    };

    struct UAISense_Blueprint___OnListenerRegistered_Params
    {
        AActor*                 ActorListener;          // 0x000000 (0x000008) [Default: 0x134B0650]
        UAIPerceptionComponent* PerceptionComponent;    // 0x000008 (0x000008) [Default: 0x72718DD00000031]
    };

    struct UAISense_Blueprint___OnListenerUnregistered_Params
    {
        AActor*                 ActorListener;          // 0x000000 (0x000008) [Default: 0x134B0650]
        UAIPerceptionComponent* PerceptionComponent;    // 0x000008 (0x000008) [Default: 0x72718DD00000031]
    };

    struct UAISense_Blueprint___OnListenerUpdated_Params
    {
        AActor*                 ActorListener;          // 0x000000 (0x000008) [Default: 0x134B0650]
        UAIPerceptionComponent* PerceptionComponent;    // 0x000008 (0x000008) [Default: 0x72718DD00000031]
    };

    struct UAISense_Blueprint___OnUpdate_Params
    {
        TArray<UAISenseEvent*>  EventsToProcess;    // 0x000000 (0x000010) [OutParam]
        float                   ReturnValue;        // 0x000010 (0x000004) [ReturnValue] [Default: 5.81674e-25f]
    };

    struct UAISense_Damage___ReportDamageEvent_Params
    {
        UObject*    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x134B0920]
        AActor*     DamagedActor;                   // 0x000008 (0x000008) [Default: 0x62718DD00000031]
        AActor*     Instigator;                     // 0x000010 (0x000008) [Default: 0x17340680]
        float       DamageAmount;                   // 0x000018 (0x000004) [Default: 5.70364e-25f]
        uint8       UnknownData_00001C[0x000004];   // 0x00001C (0x000004)
        FVector     EventLocation;                  // 0x000020 (0x000018)
        FVector     HitLocation;                    // 0x000038 (0x000018)
        FName       Tag;                            // 0x000050 (0x000004) [Default: NAME_None]
    };

    struct UAISense_Hearing___ReportNoiseEvent_Params
    {
        UObject*    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x134B0BF0]
        FVector     NoiseLocation;                  // 0x000008 (0x000018)
        float       Loudness;                       // 0x000020 (0x000004) [Default: -231979f]
        uint8       UnknownData_000024[0x000004];   // 0x000024 (0x000004)
        AActor*     Instigator;                     // 0x000028 (0x000008) [Default: nullptr]
        float       MaxRange;                       // 0x000030 (0x000004) [Default: 0f]
        FName       Tag;                            // 0x000034 (0x000004) [Default: NAME_None]
    };

    struct UAISense_Prediction___RequestControllerPredictionEvent_Params
    {
        AAIController*  Requestor;      // 0x000000 (0x000008) [Default: 0x134B0ED0]
        AActor*         PredictedActor; // 0x000008 (0x000008) [Default: 0x52718DD00000031]
        float           PredictionTime; // 0x000010 (0x000004) [Default: 5.81733e-25f]
    };

    struct UAISense_Prediction___RequestPawnPredictionEvent_Params
    {
        APawn*  Requestor;      // 0x000000 (0x000008) [Default: 0x134B0ED0]
        AActor* PredictedActor; // 0x000008 (0x000008) [Default: 0x52718DD00000031]
        float   PredictionTime; // 0x000010 (0x000004) [Default: 5.81733e-25f]
    };

    struct UAISense_Touch___ReportTouchEvent_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x134B1720]
        AActor*     TouchReceiver;      // 0x000008 (0x000008) [Default: 0x32718DD00000031]
        AActor*     OtherActor;         // 0x000010 (0x000008) [Default: 0x17340E50]
        FVector     Location;           // 0x000018 (0x000018)
    };

    struct UAITask_MoveTo___AIMoveTo_Params
    {
        AAIController*              Controller;                     // 0x000000 (0x000008) [Default: 0x134B2320]
        FVector                     GoalLocation;                   // 0x000008 (0x000018)
        AActor*                     GoalActor;                      // 0x000020 (0x000008) [Default: 0x393884BB]
        float                       AcceptanceRadius;               // 0x000028 (0x000004) [Default: 2.5641e-27f]
        TEnumAsByte<EAIOptionFlag>  StopOnOverlap;                  // 0x00002C (0x000001) [Default: 0]
        TEnumAsByte<EAIOptionFlag>  AcceptPartialPath;              // 0x00002D (0x000001) [Default: 0]
        bool                        bUsePathfinding;                // 0x00002E (0x000001) [Default: false]
        bool                        bLockAILogic;                   // 0x00002F (0x000001) [Default: false]
        bool                        bUseContinuousGoalTracking;     // 0x000030 (0x000001) [Default: false]
        TEnumAsByte<EAIOptionFlag>  ProjectGoalOnNavigation;        // 0x000031 (0x000001) [Default: 0]
        TEnumAsByte<EAIOptionFlag>  RequireNavigableEndLocation;    // 0x000032 (0x000001) [Default: 0]
        uint8                       UnknownData_000033[0x000005];   // 0x000033 (0x000005)
        UAITask_MoveTo*             ReturnValue;                    // 0x000038 (0x000008) [ReturnValue] [Default: 0x1000100000048]
    };

    struct UAITask_RunEQS___RunEQS_Params
    {
        AAIController*  Controller;     // 0x000000 (0x000008) [Default: 0x134B2670]
        UEnvQuery*      QueryTemplate;  // 0x000008 (0x000008) [Default: 0x2718DD01000031]
        UAITask_RunEQS* ReturnValue;    // 0x000010 (0x000008) [ReturnValue] [Default: 0x17341620]
    };

    struct UBTDecorator_BlueprintBase___IsDecoratorExecutionActive_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBTDecorator_BlueprintBase___IsDecoratorObserverActive_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBTDecorator_BlueprintBase___PerformConditionCheck_Params
    {
        AActor* OwnerActor;     // 0x000000 (0x000008) [Default: 0x13495B80]
        bool    ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBTDecorator_BlueprintBase___PerformConditionCheckAI_Params
    {
        AAIController*  OwnerController;    // 0x000000 (0x000008) [Default: 0x13495B80]
        APawn*          ControlledPawn;     // 0x000008 (0x000008) [Default: 0x7C2718DD00000031]
        bool            ReturnValue;        // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBTDecorator_BlueprintBase___ReceiveExecutionFinish_Params
    {
        AActor*                     OwnerActor; // 0x000000 (0x000008) [Default: 0x13495B80]
        TEnumAsByte<EBTNodeResult>  NodeResult; // 0x000008 (0x000001) [Default: 49]
    };

    struct UBTDecorator_BlueprintBase___ReceiveExecutionFinishAI_Params
    {
        AAIController*              OwnerController;    // 0x000000 (0x000008) [Default: 0x13495B80]
        APawn*                      ControlledPawn;     // 0x000008 (0x000008) [Default: 0x7C2718DD00000031]
        TEnumAsByte<EBTNodeResult>  NodeResult;         // 0x000010 (0x000001) [Default: 144]
    };

    struct UBTDecorator_BlueprintBase___ReceiveExecutionStart_Params
    {
        AActor* OwnerActor; // 0x000000 (0x000008) [Default: 0x13495B80]
    };

    struct UBTDecorator_BlueprintBase___ReceiveExecutionStartAI_Params
    {
        AAIController*  OwnerController;    // 0x000000 (0x000008) [Default: 0x13495B80]
        APawn*          ControlledPawn;     // 0x000008 (0x000008) [Default: 0x7C2718DD00000031]
    };

    struct UBTDecorator_BlueprintBase___ReceiveObserverActivated_Params
    {
        AActor* OwnerActor; // 0x000000 (0x000008) [Default: 0x13495B80]
    };

    struct UBTDecorator_BlueprintBase___ReceiveObserverActivatedAI_Params
    {
        AAIController*  OwnerController;    // 0x000000 (0x000008) [Default: 0x13495B80]
        APawn*          ControlledPawn;     // 0x000008 (0x000008) [Default: 0x7C2718DD00000031]
    };

    struct UBTDecorator_BlueprintBase___ReceiveObserverDeactivated_Params
    {
        AActor* OwnerActor; // 0x000000 (0x000008) [Default: 0x13495B80]
    };

    struct UBTDecorator_BlueprintBase___ReceiveObserverDeactivatedAI_Params
    {
        AAIController*  OwnerController;    // 0x000000 (0x000008) [Default: 0x13495B80]
        APawn*          ControlledPawn;     // 0x000008 (0x000008) [Default: 0x7C2718DD00000031]
    };

    struct UBTDecorator_BlueprintBase___ReceiveTick_Params
    {
        AActor* OwnerActor;     // 0x000000 (0x000008) [Default: 0x13495B80]
        float   DeltaSeconds;   // 0x000008 (0x000004) [Default: 6.86636e-44f]
    };

    struct UBTDecorator_BlueprintBase___ReceiveTickAI_Params
    {
        AAIController*  OwnerController;    // 0x000000 (0x000008) [Default: 0x13495B80]
        APawn*          ControlledPawn;     // 0x000008 (0x000008) [Default: 0x7C2718DD00000031]
        float           DeltaSeconds;       // 0x000010 (0x000004) [Default: 5.74626e-25f]
    };

    struct UBTFunctionLibrary___ClearBlackboardValue_Params
    {
        UBTNode*                NodeOwner;  // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;        // 0x000008 (0x000028) [OutParam]
    };

    struct UBTFunctionLibrary___ClearBlackboardValueAsVector_Params
    {
        UBTNode*                NodeOwner;  // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;        // 0x000008 (0x000028) [OutParam]
    };

    struct UBTFunctionLibrary___GetBlackboardValueAsActor_Params
    {
        UBTNode*                NodeOwner;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;            // 0x000008 (0x000028) [OutParam]
        AActor*                 ReturnValue;    // 0x000030 (0x000008) [ReturnValue] [Default: 0x582718DD00000031]
    };

    struct UBTFunctionLibrary___GetBlackboardValueAsBool_Params
    {
        UBTNode*                NodeOwner;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;            // 0x000008 (0x000028) [OutParam]
        bool                    ReturnValue;    // 0x000030 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBTFunctionLibrary___GetBlackboardValueAsClass_Params
    {
        UBTNode*                NodeOwner;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;            // 0x000008 (0x000028) [OutParam]
        UClass*                 ReturnValue;    // 0x000030 (0x000008) [ReturnValue] [Default: 0x582718DD00000031]
    };

    struct UBTFunctionLibrary___GetBlackboardValueAsEnum_Params
    {
        UBTNode*                NodeOwner;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;            // 0x000008 (0x000028) [OutParam]
        uint8                   ReturnValue;    // 0x000030 (0x000001) [ReturnValue] [Default: 49]
    };

    struct UBTFunctionLibrary___GetBlackboardValueAsFloat_Params
    {
        UBTNode*                NodeOwner;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;            // 0x000008 (0x000028) [OutParam]
        float                   ReturnValue;    // 0x000030 (0x000004) [ReturnValue] [Default: 6.86636e-44f]
    };

    struct UBTFunctionLibrary___GetBlackboardValueAsInt_Params
    {
        UBTNode*                NodeOwner;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;            // 0x000008 (0x000028) [OutParam]
        int32                   ReturnValue;    // 0x000030 (0x000004) [ReturnValue] [Default: 49]
    };

    struct UBTFunctionLibrary___GetBlackboardValueAsName_Params
    {
        UBTNode*                NodeOwner;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;            // 0x000008 (0x000028) [OutParam]
        FName                   ReturnValue;    // 0x000030 (0x000004) [ReturnValue] [Default: FName(49) -> L""]
    };

    struct UBTFunctionLibrary___GetBlackboardValueAsObject_Params
    {
        UBTNode*                NodeOwner;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;            // 0x000008 (0x000028) [OutParam]
        UObject*                ReturnValue;    // 0x000030 (0x000008) [ReturnValue] [Default: 0x582718DD00000031]
    };

    struct UBTFunctionLibrary___GetBlackboardValueAsRotator_Params
    {
        UBTNode*                NodeOwner;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;            // 0x000008 (0x000028) [OutParam]
        FRotator                ReturnValue;    // 0x000030 (0x000018) [ReturnValue]
    };

    struct UBTFunctionLibrary___GetBlackboardValueAsString_Params
    {
        UBTNode*                NodeOwner;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;            // 0x000008 (0x000028) [OutParam]
        FString                 ReturnValue;    // 0x000030 (0x000010) [ReturnValue] [Default: L""]
    };

    struct UBTFunctionLibrary___GetBlackboardValueAsVector_Params
    {
        UBTNode*                NodeOwner;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;            // 0x000008 (0x000028) [OutParam]
        FVector                 ReturnValue;    // 0x000030 (0x000018) [ReturnValue]
    };

    struct UBTFunctionLibrary___GetOwnerComponent_Params
    {
        UBTNode*                NodeOwner;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        UBehaviorTreeComponent* ReturnValue;    // 0x000008 (0x000008) [ReturnValue] [Default: 0x592718DD00000031]
    };

    struct UBTFunctionLibrary___GetOwnersBlackboard_Params
    {
        UBTNode*                NodeOwner;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        UBlackboardComponent*   ReturnValue;    // 0x000008 (0x000008) [ReturnValue] [Default: 0x592718DD00000031]
    };

    struct UBTFunctionLibrary___SetBlackboardValueAsBool_Params
    {
        UBTNode*                NodeOwner;  // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;        // 0x000008 (0x000028) [OutParam]
        bool                    Value;      // 0x000030 (0x000001) [Default: true]
    };

    struct UBTFunctionLibrary___SetBlackboardValueAsClass_Params
    {
        UBTNode*                NodeOwner;  // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;        // 0x000008 (0x000028) [OutParam]
        UClass*                 Value;      // 0x000030 (0x000008) [Default: 0x582718DD00000031]
    };

    struct UBTFunctionLibrary___SetBlackboardValueAsEnum_Params
    {
        UBTNode*                NodeOwner;  // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;        // 0x000008 (0x000028) [OutParam]
        uint8                   Value;      // 0x000030 (0x000001) [Default: 49]
    };

    struct UBTFunctionLibrary___SetBlackboardValueAsFloat_Params
    {
        UBTNode*                NodeOwner;  // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;        // 0x000008 (0x000028) [OutParam]
        float                   Value;      // 0x000030 (0x000004) [Default: 6.86636e-44f]
    };

    struct UBTFunctionLibrary___SetBlackboardValueAsInt_Params
    {
        UBTNode*                NodeOwner;  // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;        // 0x000008 (0x000028) [OutParam]
        int32                   Value;      // 0x000030 (0x000004) [Default: 49]
    };

    struct UBTFunctionLibrary___SetBlackboardValueAsName_Params
    {
        UBTNode*                NodeOwner;  // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;        // 0x000008 (0x000028) [OutParam]
        FName                   Value;      // 0x000030 (0x000004) [Default: FName(49) -> L""]
    };

    struct UBTFunctionLibrary___SetBlackboardValueAsObject_Params
    {
        UBTNode*                NodeOwner;  // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;        // 0x000008 (0x000028) [OutParam]
        UObject*                Value;      // 0x000030 (0x000008) [Default: 0x582718DD00000031]
    };

    struct UBTFunctionLibrary___SetBlackboardValueAsRotator_Params
    {
        UBTNode*                NodeOwner;  // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;        // 0x000008 (0x000028) [OutParam]
        FRotator                Value;      // 0x000030 (0x000018)
    };

    struct UBTFunctionLibrary___SetBlackboardValueAsString_Params
    {
        UBTNode*                NodeOwner;  // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;        // 0x000008 (0x000028) [OutParam]
        FString                 Value;      // 0x000030 (0x000010) [Default: L""]
    };

    struct UBTFunctionLibrary___SetBlackboardValueAsVector_Params
    {
        UBTNode*                NodeOwner;  // 0x000000 (0x000008) [Default: 0x130A5F60]
        FBlackboardKeySelector  Key;        // 0x000008 (0x000028) [OutParam]
        FVector                 Value;      // 0x000030 (0x000018)
    };

    struct UBTFunctionLibrary___StartUsingExternalEvent_Params
    {
        UBTNode*    NodeOwner;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        AActor*     OwningActor;    // 0x000008 (0x000008) [Default: 0x592718DD00000031]
    };

    struct UBTFunctionLibrary___StopUsingExternalEvent_Params
    {
        UBTNode*    NodeOwner;  // 0x000000 (0x000008) [Default: 0x130A5F60]
    };

    struct UBTService_BlueprintBase___IsServiceActive_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBTService_BlueprintBase___ReceiveActivation_Params
    {
        AActor* OwnerActor; // 0x000000 (0x000008) [Default: 0x13499610]
    };

    struct UBTService_BlueprintBase___ReceiveActivationAI_Params
    {
        AAIController*  OwnerController;    // 0x000000 (0x000008) [Default: 0x13499610]
        APawn*          ControlledPawn;     // 0x000008 (0x000008) [Default: 0x34C18DD00000031]
    };

    struct UBTService_BlueprintBase___ReceiveDeactivation_Params
    {
        AActor* OwnerActor; // 0x000000 (0x000008) [Default: 0x13499610]
    };

    struct UBTService_BlueprintBase___ReceiveDeactivationAI_Params
    {
        AAIController*  OwnerController;    // 0x000000 (0x000008) [Default: 0x13499610]
        APawn*          ControlledPawn;     // 0x000008 (0x000008) [Default: 0x34C18DD00000031]
    };

    struct UBTService_BlueprintBase___ReceiveSearchStart_Params
    {
        AActor* OwnerActor; // 0x000000 (0x000008) [Default: 0x13499610]
    };

    struct UBTService_BlueprintBase___ReceiveSearchStartAI_Params
    {
        AAIController*  OwnerController;    // 0x000000 (0x000008) [Default: 0x13499610]
        APawn*          ControlledPawn;     // 0x000008 (0x000008) [Default: 0x34C18DD00000031]
    };

    struct UBTService_BlueprintBase___ReceiveTick_Params
    {
        AActor* OwnerActor;     // 0x000000 (0x000008) [Default: 0x13499610]
        float   DeltaSeconds;   // 0x000008 (0x000004) [Default: 6.86636e-44f]
    };

    struct UBTService_BlueprintBase___ReceiveTickAI_Params
    {
        AAIController*  OwnerController;    // 0x000000 (0x000008) [Default: 0x13499610]
        APawn*          ControlledPawn;     // 0x000008 (0x000008) [Default: 0x34C18DD00000031]
        float           DeltaSeconds;       // 0x000010 (0x000004) [Default: 5.7504e-25f]
    };

    struct UBTTask_BlueprintBase___FinishExecute_Params
    {
        bool    bSuccess;   // 0x000000 (0x000001) [Default: true]
    };

    struct UBTTask_BlueprintBase___IsTaskAborting_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBTTask_BlueprintBase___IsTaskExecuting_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBTTask_BlueprintBase___ReceiveAbort_Params
    {
        AActor* OwnerActor; // 0x000000 (0x000008) [Default: 0x1349A370]
    };

    struct UBTTask_BlueprintBase___ReceiveAbortAI_Params
    {
        AAIController*  OwnerController;    // 0x000000 (0x000008) [Default: 0x1349A370]
        APawn*          ControlledPawn;     // 0x000008 (0x000008) [Default: 0x552718DD00000031]
    };

    struct UBTTask_BlueprintBase___ReceiveExecute_Params
    {
        AActor* OwnerActor; // 0x000000 (0x000008) [Default: 0x1349A370]
    };

    struct UBTTask_BlueprintBase___ReceiveExecuteAI_Params
    {
        AAIController*  OwnerController;    // 0x000000 (0x000008) [Default: 0x1349A370]
        APawn*          ControlledPawn;     // 0x000008 (0x000008) [Default: 0x552718DD00000031]
    };

    struct UBTTask_BlueprintBase___ReceiveTick_Params
    {
        AActor* OwnerActor;     // 0x000000 (0x000008) [Default: 0x1349A370]
        float   DeltaSeconds;   // 0x000008 (0x000004) [Default: 6.86636e-44f]
    };

    struct UBTTask_BlueprintBase___ReceiveTickAI_Params
    {
        AAIController*  OwnerController;    // 0x000000 (0x000008) [Default: 0x1349A370]
        APawn*          ControlledPawn;     // 0x000008 (0x000008) [Default: 0x552718DD00000031]
        float           DeltaSeconds;       // 0x000010 (0x000004) [Default: 5.75139e-25f]
    };

    struct UBTTask_BlueprintBase___SetFinishOnMessage_Params
    {
        FName   MessageName;    // 0x000000 (0x000004) [Default: FName(323593072) -> L""]
    };

    struct UBTTask_BlueprintBase___SetFinishOnMessageWithId_Params
    {
        FName   MessageName;    // 0x000000 (0x000004) [Default: FName(323593072) -> L""]
        int32   RequestID;      // 0x000004 (0x000004) [Default: 0]
    };

    struct UBehaviorTreeComponent___AddCooldownTagDuration_Params
    {
        FGameplayTag    CooldownTag;            // 0x000000 (0x000004)
        float           CooldownDuration;       // 0x000004 (0x000004) [Default: 0f]
        bool            bAddToExistingDuration; // 0x000008 (0x000001) [Default: true]
    };

    struct UBehaviorTreeComponent___GetTagCooldownEndTime_Params
    {
        FGameplayTag    CooldownTag;                    // 0x000000 (0x000004)
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        double          ReturnValue;                    // 0x000008 (0x000008) [ReturnValue] [Default: 9.5895e-57]
    };

    struct UBehaviorTreeComponent___SetDynamicSubtree_Params
    {
        FGameplayTag    InjectTag;                      // 0x000000 (0x000004)
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UBehaviorTree*  BehaviorAsset;                  // 0x000008 (0x000008) [Default: 0x344E18DD00000031]
    };

    struct IBlackboardAssetProvider___GetBlackboardAsset_Params
    {
        UBlackboardData*    ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x12FAB170]
    };

    struct UBlackboardComponent___ClearValue_Params
    {
        FName   KeyName;    // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
    };

    struct UBlackboardComponent___GetLocationFromEntry_Params
    {
        FName   KeyName;                        // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FVector ResultLocation;                 // 0x000008 (0x000018) [OutParam]
        bool    ReturnValue;                    // 0x000020 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBlackboardComponent___GetRotationFromEntry_Params
    {
        FName       KeyName;                        // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        uint8       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FRotator    ResultRotation;                 // 0x000008 (0x000018) [OutParam]
        bool        ReturnValue;                    // 0x000020 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBlackboardComponent___GetValueAsBool_Params
    {
        FName   KeyName;        // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        bool    ReturnValue;    // 0x000004 (0x000001) [ReturnValue] [Default: false]
    };

    struct UBlackboardComponent___GetValueAsClass_Params
    {
        FName   KeyName;                        // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UClass* ReturnValue;                    // 0x000008 (0x000008) [ReturnValue] [Default: 0x726018DD00000031]
    };

    struct UBlackboardComponent___GetValueAsEnum_Params
    {
        FName   KeyName;        // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        uint8   ReturnValue;    // 0x000004 (0x000001) [ReturnValue] [Default: 0]
    };

    struct UBlackboardComponent___GetValueAsFloat_Params
    {
        FName   KeyName;        // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        float   ReturnValue;    // 0x000004 (0x000004) [ReturnValue] [Default: 0f]
    };

    struct UBlackboardComponent___GetValueAsInt_Params
    {
        FName   KeyName;        // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        int32   ReturnValue;    // 0x000004 (0x000004) [ReturnValue] [Default: 0]
    };

    struct UBlackboardComponent___GetValueAsName_Params
    {
        FName   KeyName;        // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        FName   ReturnValue;    // 0x000004 (0x000004) [ReturnValue] [Default: NAME_None]
    };

    struct UBlackboardComponent___GetValueAsObject_Params
    {
        FName       KeyName;                        // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        uint8       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UObject*    ReturnValue;                    // 0x000008 (0x000008) [ReturnValue] [Default: 0x726018DD00000031]
    };

    struct UBlackboardComponent___GetValueAsRotator_Params
    {
        FName       KeyName;                        // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        uint8       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FRotator    ReturnValue;                    // 0x000008 (0x000018) [ReturnValue]
    };

    struct UBlackboardComponent___GetValueAsString_Params
    {
        FName   KeyName;                        // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FString ReturnValue;                    // 0x000008 (0x000010) [ReturnValue] [Default: L""]
    };

    struct UBlackboardComponent___GetValueAsVector_Params
    {
        FName   KeyName;                        // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FVector ReturnValue;                    // 0x000008 (0x000018) [ReturnValue]
    };

    struct UBlackboardComponent___IsVectorValueSet_Params
    {
        FName   KeyName;        // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        bool    ReturnValue;    // 0x000004 (0x000001) [ReturnValue] [Default: false]
    };

    struct UBlackboardComponent___SetValueAsBool_Params
    {
        FName   KeyName;    // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        bool    BoolValue;  // 0x000004 (0x000001) [Default: false]
    };

    struct UBlackboardComponent___SetValueAsClass_Params
    {
        FName   KeyName;                        // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UClass* ClassValue;                     // 0x000008 (0x000008) [Default: 0x726018DD00000031]
    };

    struct UBlackboardComponent___SetValueAsEnum_Params
    {
        FName   KeyName;    // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        uint8   EnumValue;  // 0x000004 (0x000001) [Default: 0]
    };

    struct UBlackboardComponent___SetValueAsFloat_Params
    {
        FName   KeyName;    // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        float   FloatValue; // 0x000004 (0x000004) [Default: 0f]
    };

    struct UBlackboardComponent___SetValueAsInt_Params
    {
        FName   KeyName;    // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        int32   IntValue;   // 0x000004 (0x000004) [Default: 0]
    };

    struct UBlackboardComponent___SetValueAsName_Params
    {
        FName   KeyName;    // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        FName   NameValue;  // 0x000004 (0x000004) [Default: NAME_None]
    };

    struct UBlackboardComponent___SetValueAsObject_Params
    {
        FName       KeyName;                        // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        uint8       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UObject*    ObjectValue;                    // 0x000008 (0x000008) [Default: 0x726018DD00000031]
    };

    struct UBlackboardComponent___SetValueAsRotator_Params
    {
        FName       KeyName;                        // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        uint8       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FRotator    VectorValue;                    // 0x000008 (0x000018)
    };

    struct UBlackboardComponent___SetValueAsString_Params
    {
        FName   KeyName;                        // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FString StringValue;                    // 0x000008 (0x000010) [Default: L""]
    };

    struct UBlackboardComponent___SetValueAsVector_Params
    {
        FName   KeyName;                        // 0x000000 (0x000004) [OutParam] [Default: FName(323545024) -> L""]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FVector VectorValue;                    // 0x000008 (0x000018)
    };

    struct UBrainComponent___IsPaused_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBrainComponent___IsRunning_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBrainComponent___StopLogic_Params
    {
        FString Reason; // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UCrowdFollowingComponent___SuspendCrowdSteering_Params
    {
        bool    bSuspend;   // 0x000000 (0x000001) [Default: true]
    };

    struct UEnvQueryContext_BlueprintBase___ProvideActorsSet_Params
    {
        UObject*        QuerierObject;      // 0x000000 (0x000008) [Default: 0x134A01A0]
        AActor*         QuerierActor;       // 0x000008 (0x000008) [Default: 0xA72018DD00000031]
        TArray<AActor*> ResultingActorsSet; // 0x000010 (0x000010) [OutParam]
    };

    struct UEnvQueryContext_BlueprintBase___ProvideLocationsSet_Params
    {
        UObject*        QuerierObject;          // 0x000000 (0x000008) [Default: 0x134A01A0]
        AActor*         QuerierActor;           // 0x000008 (0x000008) [Default: 0xA72018DD00000031]
        TArray<FVector> ResultingLocationSet;   // 0x000010 (0x000010) [OutParam]
    };

    struct UEnvQueryContext_BlueprintBase___ProvideSingleActor_Params
    {
        UObject*    QuerierObject;  // 0x000000 (0x000008) [Default: 0x134A01A0]
        AActor*     QuerierActor;   // 0x000008 (0x000008) [Default: 0xA72018DD00000031]
        AActor*     ResultingActor; // 0x000010 (0x000008) [OutParam] [Default: 0x17323770]
    };

    struct UEnvQueryContext_BlueprintBase___ProvideSingleLocation_Params
    {
        UObject*    QuerierObject;      // 0x000000 (0x000008) [Default: 0x134A01A0]
        AActor*     QuerierActor;       // 0x000008 (0x000008) [Default: 0xA72018DD00000031]
        FVector     ResultingLocation;  // 0x000010 (0x000018) [OutParam]
    };

    struct UEnvQueryGenerator_BlueprintBase___AddGeneratedActor_Params
    {
        AActor* GeneratedActor; // 0x000000 (0x000008) [Default: 0x134A4930]
    };

    struct UEnvQueryGenerator_BlueprintBase___AddGeneratedVector_Params
    {
        FVector GeneratedVector;    // 0x000000 (0x000018)
    };

    struct UEnvQueryGenerator_BlueprintBase___DoItemGeneration_Params
    {
        TArray<FVector> ContextLocations;   // 0x000000 (0x000010) [OutParam]
    };

    struct UEnvQueryGenerator_BlueprintBase___DoItemGenerationFromActors_Params
    {
        TArray<AActor*> ContextActors;  // 0x000000 (0x000010) [OutParam]
    };

    struct UEnvQueryGenerator_BlueprintBase___GetQuerier_Params
    {
        UObject*    ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x134A4930]
    };

    struct UEnvQueryInstanceBlueprintWrapper___GetItemScore_Params
    {
        int32   ItemIndex;      // 0x000000 (0x000004) [Default: 323624864]
        float   ReturnValue;    // 0x000004 (0x000004) [ReturnValue] [Default: 0f]
    };

    struct UEnvQueryInstanceBlueprintWrapper___GetQueryResultsAsActors_Params
    {
        TArray<AActor*> ResultActors;   // 0x000000 (0x000010) [OutParam]
        bool            ReturnValue;    // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct UEnvQueryInstanceBlueprintWrapper___GetQueryResultsAsLocations_Params
    {
        TArray<FVector> ResultLocations;    // 0x000000 (0x000010) [OutParam]
        bool            ReturnValue;        // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct UEnvQueryInstanceBlueprintWrapper___GetQueryResultsAsTransforms_Params
    {
        TArray<FTransform>  ResultTransforms;   // 0x000000 (0x000010) [OutParam]
        bool                ReturnValue;        // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct UEnvQueryInstanceBlueprintWrapper___GetResultsAsActors_Params
    {
        TArray<AActor*> ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UEnvQueryInstanceBlueprintWrapper___GetResultsAsLocations_Params
    {
        TArray<FVector> ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UEnvQueryInstanceBlueprintWrapper___SetNamedParam_Params
    {
        FName   ParamName;  // 0x000000 (0x000004) [Default: FName(323624864) -> L""]
        float   Value;      // 0x000004 (0x000004) [Default: 0f]
    };

    struct UEnvQueryInstanceBlueprintWrapper___EQSQueryDoneSignature_Params
    {
        UEnvQueryInstanceBlueprintWrapper*  QueryInstance;  // 0x000000 (0x000008) [Default: 0x134A1FA0]
        TEnumAsByte<EEnvQueryStatus>        QueryStatus;    // 0x000008 (0x000001) [Default: 49]
    };

    struct UEnvQueryManager___RunEQSQuery_Params
    {
        UObject*                            WorldContextObject;             // 0x000000 (0x000008) [Default: 0x134A2260]
        UEnvQuery*                          QueryTemplate;                  // 0x000008 (0x000008) [Default: 0x4F18DD00000031]
        UObject*                            Querier;                        // 0x000010 (0x000008) [Default: 0x17330960]
        TEnumAsByte<EEnvQueryRunMode>       RunMode;                        // 0x000018 (0x000001) [Default: 224]
        uint8                               UnknownData_000019[0x000007];   // 0x000019 (0x000007)
        UClass*                             WrapperClass;                   // 0x000020 (0x000008) [Default: 0x1CB98ABB]
        UEnvQueryInstanceBlueprintWrapper*  ReturnValue;                    // 0x000028 (0x000008) [ReturnValue] [Default: 0x134A24E0]
    };

    struct UGeneratedNavLinksProxy___ReceiveSmartLinkReached_Params
    {
        AActor* Agent;          // 0x000000 (0x000008) [Default: 0x134AD140]
        FVector Destination;    // 0x000008 (0x000018)
    };

    struct UNavLocalGridManager___AddLocalNavigationGridForBox_Params
    {
        UObject*    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x134AE5B0]
        FVector     Location;                       // 0x000008 (0x000018) [OutParam]
        FVector     Extent;                         // 0x000020 (0x000018)
        FRotator    Rotation;                       // 0x000038 (0x000018)
        int32       Radius2D;                       // 0x000050 (0x000004) [Default: 0]
        float       Height;                         // 0x000054 (0x000004) [Default: 0f]
        bool        bRebuildGrids;                  // 0x000058 (0x000001) [Default: true]
        uint8       UnknownData_000059[0x000003];   // 0x000059 (0x000003)
        int32       ReturnValue;                    // 0x00005C (0x000004) [ReturnValue] [Default: 0]
    };

    struct UNavLocalGridManager___AddLocalNavigationGridForCapsule_Params
    {
        UObject*    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x134AE5B0]
        FVector     Location;                       // 0x000008 (0x000018) [OutParam]
        float       CapsuleRadius;                  // 0x000020 (0x000004) [Default: 1.49845e+34f]
        float       CapsuleHalfHeight;              // 0x000024 (0x000004) [Default: 0f]
        int32       Radius2D;                       // 0x000028 (0x000004) [Default: 0]
        float       Height;                         // 0x00002C (0x000004) [Default: 0f]
        bool        bRebuildGrids;                  // 0x000030 (0x000001) [Default: false]
        uint8       UnknownData_000031[0x000003];   // 0x000031 (0x000003)
        int32       ReturnValue;                    // 0x000034 (0x000004) [ReturnValue] [Default: 0]
    };

    struct UNavLocalGridManager___AddLocalNavigationGridForPoint_Params
    {
        UObject*    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x134AE5B0]
        FVector     Location;                       // 0x000008 (0x000018) [OutParam]
        int32       Radius2D;                       // 0x000020 (0x000004) [Default: 2016981691]
        float       Height;                         // 0x000024 (0x000004) [Default: 0f]
        bool        bRebuildGrids;                  // 0x000028 (0x000001) [Default: false]
        uint8       UnknownData_000029[0x000003];   // 0x000029 (0x000003)
        int32       ReturnValue;                    // 0x00002C (0x000004) [ReturnValue] [Default: 0]
    };

    struct UNavLocalGridManager___AddLocalNavigationGridForPoints_Params
    {
        UObject*        WorldContextObject;             // 0x000000 (0x000008) [Default: 0x134AE5B0]
        TArray<FVector> Locations;                      // 0x000008 (0x000010) [OutParam]
        int32           Radius2D;                       // 0x000018 (0x000004) [Default: 389055712]
        float           Height;                         // 0x00001C (0x000004) [Default: 0f]
        bool            bRebuildGrids;                  // 0x000020 (0x000001) [Default: true]
        uint8           UnknownData_000021[0x000003];   // 0x000021 (0x000003)
        int32           ReturnValue;                    // 0x000024 (0x000004) [ReturnValue] [Default: 0]
    };

    struct UNavLocalGridManager___FindLocalNavigationGridPath_Params
    {
        UObject*        WorldContextObject; // 0x000000 (0x000008) [Default: 0x134AE5B0]
        FVector         Start;              // 0x000008 (0x000018) [OutParam]
        FVector         End;                // 0x000020 (0x000018) [OutParam]
        TArray<FVector> PathPoints;         // 0x000038 (0x000010) [OutParam]
        bool            ReturnValue;        // 0x000048 (0x000001) [ReturnValue] [Default: false]
    };

    struct UNavLocalGridManager___RemoveLocalNavigationGrid_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x134AE5B0]
        int32       GridId;             // 0x000008 (0x000004) [Default: 49]
        bool        bRebuildGrids;      // 0x00000C (0x000001) [Default: true]
    };

    struct UNavLocalGridManager___SetLocalNavigationGridDensity_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x134AE5B0]
        float       CellSize;           // 0x000008 (0x000004) [Default: 6.86636e-44f]
        bool        ReturnValue;        // 0x00000C (0x000001) [ReturnValue] [Default: true]
    };

    struct UPathFollowingComponent___GetPathActionType_Params
    {
        TEnumAsByte<EPathFollowingAction>   ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: 32]
    };

    struct UPathFollowingComponent___GetPathDestination_Params
    {
        FVector ReturnValue;    // 0x000000 (0x000018) [ReturnValue]
    };

    struct UPathFollowingComponent___OnActorBump_Params
    {
        AActor*     SelfActor;      // 0x000000 (0x000008) [Default: 0x134AE920]
        AActor*     OtherActor;     // 0x000008 (0x000008) [Default: 0x9D7518DD00000031]
        FVector     NormalImpulse;  // 0x000010 (0x000018)
        FHitResult  Hit;            // 0x000028 (0x0000F8) [OutParam]
    };

    struct UPathFollowingComponent___OnNavDataRegistered_Params
    {
        ANavigationData*    NavData;    // 0x000000 (0x000008) [Default: 0x134AE920]
    };

    struct UPawnSensingComponent___GetPeripheralVisionAngle_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 2.56351e-27f]
    };

    struct UPawnSensingComponent___GetPeripheralVisionCosine_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 2.56351e-27f]
    };

    struct UPawnSensingComponent___SetPeripheralVisionAngle_Params
    {
        float   NewPeripheralVisionAngle;   // 0x000000 (0x000004) [Default: 2.56351e-27f]
    };

    struct UPawnSensingComponent___SetSensingInterval_Params
    {
        float   NewSensingInterval; // 0x000000 (0x000004) [Default: 2.56351e-27f]
    };

    struct UPawnSensingComponent___SetSensingUpdatesEnabled_Params
    {
        bool    bEnabled;   // 0x000000 (0x000001) [Default: true]
    };

    struct UPawnSensingComponent___HearNoiseDelegate_Params
    {
        APawn*  Instigator; // 0x000000 (0x000008) [Default: 0x134B1A30]
        FVector Location;   // 0x000008 (0x000018) [OutParam]
        float   Volume;     // 0x000020 (0x000004) [Default: 3.24924e+15f]
    };

    struct UPawnSensingComponent___SeePawnDelegate_Params
    {
        APawn*  Pawn;   // 0x000000 (0x000008) [Default: 0x134B1A30]
    };

    struct UValueOrBBKeyBlueprintUtility___GetBool_Params
    {
        FValueOrBBKey_Bool      Value;              // 0x000000 (0x000018) [OutParam]
        UBehaviorTreeComponent* BehaviorTreeComp;   // 0x000018 (0x000008) [Default: 0x173084E0]
        bool                    ReturnValue;        // 0x000020 (0x000001) [ReturnValue] [Default: true]
    };

    struct UValueOrBBKeyBlueprintUtility___GetClass_Params
    {
        FValueOrBBKey_Class     Value;              // 0x000000 (0x000020) [OutParam]
        UBehaviorTreeComponent* BehaviorTreeComp;   // 0x000020 (0x000008) [Default: 0x2938B2BB]
        UClass*                 ReturnValue;        // 0x000028 (0x000008) [ReturnValue] [Default: 0x12FAB170]
    };

    struct UValueOrBBKeyBlueprintUtility___GetEnum_Params
    {
        FValueOrBBKey_Enum      Value;              // 0x000000 (0x000030) [OutParam]
        UBehaviorTreeComponent* BehaviorTreeComp;   // 0x000030 (0x000008) [Default: 0x882018DD00000031]
        uint8                   ReturnValue;        // 0x000038 (0x000001) [ReturnValue] [Default: 160]
    };

    struct UValueOrBBKeyBlueprintUtility___GetFloat_Params
    {
        FValueOrBBKey_Float     Value;              // 0x000000 (0x000018) [OutParam]
        UBehaviorTreeComponent* BehaviorTreeComp;   // 0x000018 (0x000008) [Default: 0x173084E0]
        float                   ReturnValue;        // 0x000020 (0x000004) [ReturnValue] [Default: 4.10112e-14f]
    };

    struct UValueOrBBKeyBlueprintUtility___GetInt32_Params
    {
        FValueOrBBKey_Int32     Value;              // 0x000000 (0x000018) [OutParam]
        UBehaviorTreeComponent* BehaviorTreeComp;   // 0x000018 (0x000008) [Default: 0x173084E0]
        int32                   ReturnValue;        // 0x000020 (0x000004) [ReturnValue] [Default: 691581627]
    };

    struct UValueOrBBKeyBlueprintUtility___GetName_Params
    {
        FValueOrBBKey_Name      Value;              // 0x000000 (0x000018) [OutParam]
        UBehaviorTreeComponent* BehaviorTreeComp;   // 0x000018 (0x000008) [Default: 0x173084E0]
        FName                   ReturnValue;        // 0x000020 (0x000004) [ReturnValue] [Default: FName(691581627) -> L"Default__ValueOrBBKeyBlueprintUtility"]
    };

    struct UValueOrBBKeyBlueprintUtility___GetObject_Params
    {
        FValueOrBBKey_Object    Value;              // 0x000000 (0x000020) [OutParam]
        UBehaviorTreeComponent* BehaviorTreeComp;   // 0x000020 (0x000008) [Default: 0x2938B2BB]
        UObject*                ReturnValue;        // 0x000028 (0x000008) [ReturnValue] [Default: 0x12FAB170]
    };

    struct UValueOrBBKeyBlueprintUtility___GetRotator_Params
    {
        FValueOrBBKey_Rotator   Value;              // 0x000000 (0x000028) [OutParam]
        UBehaviorTreeComponent* BehaviorTreeComp;   // 0x000028 (0x000008) [Default: 0x12FAB170]
        FRotator                ReturnValue;        // 0x000030 (0x000018) [ReturnValue]
    };

    struct UValueOrBBKeyBlueprintUtility___GetString_Params
    {
        FValueOrBBKey_String    Value;              // 0x000000 (0x000020) [OutParam]
        UBehaviorTreeComponent* BehaviorTreeComp;   // 0x000020 (0x000008) [Default: 0x2938B2BB]
        FString                 ReturnValue;        // 0x000028 (0x000010) [ReturnValue] [Default: L"??"]
    };

    struct UValueOrBBKeyBlueprintUtility___GetStruct_Params
    {
        FValueOrBBKey_Struct    Value;              // 0x000000 (0x000020) [OutParam]
        UBehaviorTreeComponent* BehaviorTreeComp;   // 0x000020 (0x000008) [Default: 0x2938B2BB]
        FInstancedStruct        ReturnValue;        // 0x000028 (0x000010) [ReturnValue]
    };

    struct UValueOrBBKeyBlueprintUtility___GetVector_Params
    {
        FValueOrBBKey_Vector    Value;              // 0x000000 (0x000028) [OutParam]
        UBehaviorTreeComponent* BehaviorTreeComp;   // 0x000028 (0x000008) [Default: 0x12FAB170]
        FVector                 ReturnValue;        // 0x000030 (0x000018) [ReturnValue]
    };

} // namespace UE

