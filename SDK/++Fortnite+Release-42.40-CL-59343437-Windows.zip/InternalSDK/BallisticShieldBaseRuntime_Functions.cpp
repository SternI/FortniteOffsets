/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BallisticShieldBaseRuntime_Functions
 * ============================================================
 */

#include "BallisticShieldBaseRuntime_Functions.hpp"

namespace UE
{

    void IBallisticShieldWeaponInterface::GetBallisticShieldData(EBallisticShieldPlayerActionState& BallisticShieldPlayerState, float& StaggerBuildupPercent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BallisticShieldBaseRuntime.BallisticShieldWeaponInterface.GetBallisticShieldData");
    
        IBallisticShieldWeaponInterface___GetBallisticShieldData_Params Params{};
        Params.BallisticShieldPlayerState = BallisticShieldPlayerState;
        Params.StaggerBuildupPercent = StaggerBuildupPercent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BallisticShieldPlayerState = Params.BallisticShieldPlayerState;
        StaggerBuildupPercent = Params.StaggerBuildupPercent;
    }

} // namespace UE

