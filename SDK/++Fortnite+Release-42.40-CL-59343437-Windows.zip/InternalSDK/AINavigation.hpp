/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AINavigation
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000270 (0x000000)
    class AAutomaticNavigationActor : public AActor
    {
    public:
    };
    // Size: 0x000058 (0x000010)
    class alignas(0x8) UCompositeNavigationQuery : public UNavigationQueryFilter
    {
    public:
        TArray<UNavigationFilter*>  NavigationFilters;  // 0x000048 (0x000010)
    };
    // Size: 0x000028 (0x000000)
    class UNavigationFilter : public UObject
    {
    public:
    };
}

