/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnnualRefundTokenUI_Functions
 * ============================================================
 */

#include "AnnualRefundTokenUI.hpp"

namespace UE
{

    struct UFortAnnualRefundTicket___OnUpdateAvailableState_Params
    {
        bool    bIsAvailable;   // 0x000000 (0x000001) [Default: false]
    };

    struct UFortAnnualRefundTicket___OnUpdatePendingState_Params
    {
        bool    bIsPending; // 0x000000 (0x000001) [Default: false]
    };

    struct UFortPurchaseHistoryBundleEntry___SetExpandButtonText_Params
    {
        int32   NumPurchases;   // 0x000000 (0x000004) [Default: 344544080]
    };

    struct UFortPurchaseHistoryEntry___OnSetHistory_Params
    {
        bool    bHasBeenRefunded;           // 0x000000 (0x000001) [Default: true]
        bool    bIsCancelPurchaseEligible;  // 0x000001 (0x000001) [Default: true]
        bool    bIsTokenlessRefund;         // 0x000002 (0x000001) [Default: true]
        bool    bPlayerHasTokens;           // 0x000003 (0x000001) [Default: true]
        bool    bNonRefundable;             // 0x000004 (0x000001) [Default: false]
        bool    IsPartOfABundle;            // 0x000005 (0x000001) [Default: false]
        bool    IsNextRefundable;           // 0x000006 (0x000001) [Default: false]
        uint8   UnknownByte_000007;         // 0x000007 (0x000001)
        int32   IndexInBundle;              // 0x000008 (0x000004) [Default: 49]
        int32   NumPurchasesInBundle;       // 0x00000C (0x000004) [Default: -1268901667]
    };

    struct UFortPurchaseHistoryEntry___SetPurchaseText_Params
    {
        FText                           PurchaseDateText;   // 0x000000 (0x000010) [OutParam]
        FText                           RefundDateText;     // 0x000010 (0x000010) [OutParam]
        bool                            bHasBeenRefunded;   // 0x000020 (0x000001) [Default: true]
        EFortPurchaseHistoryRefundType  RefundType;         // 0x000021 (0x000001) [Default: EFortPurchaseHistoryRefundType(141)]
    };

    struct UFortPurchaseHistoryEntry___SetupItemCard_Params
    {
        UFortCosmeticItemCard*  ItemCard;   // 0x000000 (0x000008) [Default: 0x14894D40]
        UFortItem*              Item;       // 0x000008 (0x000008) [Default: 0xB45E18DD00000031]
    };

    struct UFortPurchaseHistoryEntryBase___UpdateItemList_Params
    {
        TArray<UFortCosmeticItemCard*>  ItemCards;  // 0x000000 (0x000010) [OutParam]
    };

    struct UFortPurchaseHistoryScreen___BP_IsShowingPurchases_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UFortPurchaseHistoryScreen___FilterMtxPurchaseHistoryByOffer_Params
    {
        UFortItemShopOfferVM*   InOffer;    // 0x000000 (0x000008) [Default: 0x14895F30]
    };

    struct UFortRefundConfirmation___BP_UpdateItemsList_Params
    {
        TArray<UFortItemDefinition*>    SelectedItemDefs;   // 0x000000 (0x000010) [OutParam]
        int32                           TotalMtxPaid;       // 0x000010 (0x000004) [Default: 426789552]
    };

    struct UFortRefundConfirmation___BP_UpdateRefundType_Params
    {
        EFortPurchaseHistoryRefundType  RefundType;     // 0x000000 (0x000001) [Default: EFortPurchaseHistoryRefundType(48)]
        bool                            bBundledRefund; // 0x000001 (0x000001) [Default: true]
    };

} // namespace UE

