/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:30
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AgileChugJugGameplay/GameplayCues/GCN_AgileChugJug_HealFinished
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000218 (0x000000)
    class UGCN_AgileChugJug_HealFinished_C : public UFortGameplayCueNotify_Burst
    {
    public:
    };
}

