/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:39
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AgileChugJugGameplay/Gameplay/Action_DropChugJug_Functions
 * ============================================================
 */

#include "Action_DropChugJug.hpp"

namespace UE
{

    struct UAction_DropChugJug_C___HandleItemSpawn_Params
    {
        AFortPawn*                          AvatarPawn;                                     // 0x000000 (0x000008) [Default: 0x12FBEC60]
        FDropItemCustomBehaviorParameters   Params;                                         // 0x000008 (0x0000C8) [OutParam]
        bool                                bOutUseDefaultSpawn;                            // 0x0000D0 (0x000001) [OutParam] [Default: true]
        uint8                               UnknownData_0000D1[0x000007];                   // 0x0000D1 (0x000007)
        UItemDefinitionBase*                CallFunc_BreakFortItemEntry_ItemDefinition;     // 0x0000D8 (0x000008) [Default: 0x275C1000275C0]
        FGuid                               CallFunc_BreakFortItemEntry_ItemGuid;           // 0x0000E0 (0x000010)
        int32                               CallFunc_BreakFortItemEntry_Count;              // 0x0000F0 (0x000004) [Default: -684745029]
        int32                               CallFunc_BreakFortItemEntry_Level;              // 0x0000F4 (0x000004) [Default: 1313179579]
        int32                               CallFunc_BreakFortItemEntry_LoadedAmmo;         // 0x0000F8 (0x000004) [Default: -1308254277]
        int32                               CallFunc_BreakFortItemEntry_PhantomReserveAmmo; // 0x0000FC (0x000004) [Default: 619415483]
        bool                                CallFunc_Greater_IntInt_ReturnValue;            // 0x000100 (0x000001) [Default: true]
    };

} // namespace UE

