/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:27
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AgileChugJugGameplay/Gameplay/B_Prj_Athena_Consumable_Thrown_ChugJug
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000BE8 (0x000024)
    class alignas(0x8) AB_Prj_Athena_Consumable_Thrown_ChugJug_C : public AB_Prj_Athena_Consumable_Thrown_C
    {
    public:
        uint8                       UnknownData_000BC4[0x000004];   // 0x000BC4 (0x000004)
        FPointerToUberGraphFrame    UberGraphFrame;                 // 0x000BC8 (0x000008)
        UAudioComponent*            Audio;                          // 0x000BD0 (0x000008) [Default: nullptr]
        UFortItemEntryComponent*    FortItemEntry;                  // 0x000BD8 (0x000008) [Default: nullptr]
        UFortItem*                  Item;                           // 0x000BE0 (0x000008) [Default: nullptr]
    
    public: // Functions
        void    SpawnItem(bool bHitWater); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    SetitemEntryOnDrop(UFortItem* ItemObj, APawn* CallFunc_GetInstigator_ReturnValue, UFortWorldItem* K2Node_DynamicCast_AsFort_World_Item, bool K2Node_DynamicCast_bSuccess, AFortPlayerPawn* K2Node_DynamicCast_AsFort_Player_Pawn, bool K2Node_DynamicCast_bSuccess_1, FFortItemEntry CallFunc_CreateItemEntryForDrop_ReturnValue); // 0x000545D2 [Public | HasDefaults | BlueprintCallable | BlueprintEvent]
        void    SetItem(UFortItem* Item); // 0x000545D2 [Public | BlueprintCallable | BlueprintEvent]
        void    ReceiveBeginPlay(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnBounce(FHitResult& Hit); // 0x000545D2 [Event | Public | HasOutParms | BlueprintEvent]
        void    ExecuteUbergraph_B_Prj_Athena_Consumable_Thrown_ChugJug(int32 EntryPoint, bool CallFunc_HasAuthority_ReturnValue, bool K2Node_Event_bHitWater, FVector CallFunc_K2_GetActorLocation_ReturnValue, FVector CallFunc_GetActorForwardVector_ReturnValue, FVector CallFunc_Add_VectorVector_ReturnValue, AFortPlayerController* CallFunc_Get_Spawned_Pickup_Optional_Owner_PC_Optional_Owner_PC, FHitResult K2Node_Event_Hit, FFortItemEntry CallFunc_GetOwnedItem_ReturnValue, AFortPickup* CallFunc_K2_SpawnPickupInWorldWithClassAndItemEntry_ReturnValue, AFortPlayerController* CallFunc_GetOwnerPlayerController_ReturnValue); // 0x000545D2 [Final | UbergraphFunction | HasDefaults]
    };
}

