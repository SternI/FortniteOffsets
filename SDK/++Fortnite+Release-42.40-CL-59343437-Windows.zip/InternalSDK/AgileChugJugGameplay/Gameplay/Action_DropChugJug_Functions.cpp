/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:39
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AgileChugJugGameplay/Gameplay/Action_DropChugJug_Functions
 * ============================================================
 */

#include "Action_DropChugJug_Functions.hpp"

namespace UE
{

    void UAction_DropChugJug_C::HandleItemSpawn(AFortPawn* AvatarPawn, FDropItemCustomBehaviorParameters& Params, bool& bOutUseDefaultSpawn, UItemDefinitionBase* CallFunc_BreakFortItemEntry_ItemDefinition, FGuid CallFunc_BreakFortItemEntry_ItemGuid, int32 CallFunc_BreakFortItemEntry_Count, int32 CallFunc_BreakFortItemEntry_Level, int32 CallFunc_BreakFortItemEntry_LoadedAmmo, int32 CallFunc_BreakFortItemEntry_PhantomReserveAmmo, bool CallFunc_Greater_IntInt_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("Action_DropChugJug.Action_DropChugJug_C.HandleItemSpawn");
    
        UAction_DropChugJug_C___HandleItemSpawn_Params Params{};
        Params.AvatarPawn = AvatarPawn;
        Params.Params = Params;
        Params.bOutUseDefaultSpawn = bOutUseDefaultSpawn;
        Params.CallFunc_BreakFortItemEntry_ItemDefinition = CallFunc_BreakFortItemEntry_ItemDefinition;
        Params.CallFunc_BreakFortItemEntry_ItemGuid = CallFunc_BreakFortItemEntry_ItemGuid;
        Params.CallFunc_BreakFortItemEntry_Count = CallFunc_BreakFortItemEntry_Count;
        Params.CallFunc_BreakFortItemEntry_Level = CallFunc_BreakFortItemEntry_Level;
        Params.CallFunc_BreakFortItemEntry_LoadedAmmo = CallFunc_BreakFortItemEntry_LoadedAmmo;
        Params.CallFunc_BreakFortItemEntry_PhantomReserveAmmo = CallFunc_BreakFortItemEntry_PhantomReserveAmmo;
        Params.CallFunc_Greater_IntInt_ReturnValue = CallFunc_Greater_IntInt_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Params = Params.Params;
        bOutUseDefaultSpawn = Params.bOutUseDefaultSpawn;
    }

} // namespace UE

