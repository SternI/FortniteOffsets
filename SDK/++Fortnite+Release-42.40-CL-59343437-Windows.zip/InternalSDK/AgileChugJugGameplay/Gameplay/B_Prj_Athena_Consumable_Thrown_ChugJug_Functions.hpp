/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:27
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AgileChugJugGameplay/Gameplay/B_Prj_Athena_Consumable_Thrown_ChugJug_Functions
 * ============================================================
 */

#include "B_Prj_Athena_Consumable_Thrown_ChugJug.hpp"

namespace UE
{

    struct AB_Prj_Athena_Consumable_Thrown_ChugJug_C___SpawnItem_Params
    {
        bool    bHitWater;  // 0x000000 (0x000001) [Default: true]
    };

    struct AB_Prj_Athena_Consumable_Thrown_ChugJug_C___SetitemEntryOnDrop_Params
    {
        UFortItem*          ItemObj;                                        // 0x000000 (0x000008) [Default: 0x142B38C0]
        APawn*              CallFunc_GetInstigator_ReturnValue;             // 0x000008 (0x000008) [Default: 0x7E1F1EDD00280031]
        UFortWorldItem*     K2Node_DynamicCast_AsFort_World_Item;           // 0x000010 (0x000008) [Default: 0x7FEDD8FFC540]
        bool                K2Node_DynamicCast_bSuccess;                    // 0x000018 (0x000001) [Default: true]
        uint8               UnknownData_000019[0x000007];                   // 0x000019 (0x000007)
        AFortPlayerPawn*    K2Node_DynamicCast_AsFort_Player_Pawn;          // 0x000020 (0x000008) [Default: 0xA9340BC]
        bool                K2Node_DynamicCast_bSuccess_1;                  // 0x000028 (0x000001) [Default: true]
        uint8               UnknownData_000029[0x000007];                   // 0x000029 (0x000007)
        FFortItemEntry      CallFunc_CreateItemEntryForDrop_ReturnValue;    // 0x000030 (0x000098)
    };

    struct AB_Prj_Athena_Consumable_Thrown_ChugJug_C___SetItem_Params
    {
        UFortItem*  Item;   // 0x000000 (0x000008) [Default: 0x142B38C0]
    };

    struct AB_Prj_Athena_Consumable_Thrown_ChugJug_C___OnBounce_Params
    {
        FHitResult  Hit;    // 0x000000 (0x0000F8) [OutParam]
    };

    struct AB_Prj_Athena_Consumable_Thrown_ChugJug_C___ExecuteUbergraph_B_Prj_Athena_Consumable_Thrown_ChugJug_Params
    {
        int32                   EntryPoint;                                                         // 0x000000 (0x000004) [Default: 338376896]
        bool                    CallFunc_HasAuthority_ReturnValue;                                  // 0x000004 (0x000001) [Default: false]
        bool                    K2Node_Event_bHitWater;                                             // 0x000005 (0x000001) [Default: false]
        uint8                   UnknownData_000006[0x000002];                                       // 0x000006 (0x000002)
        FVector                 CallFunc_K2_GetActorLocation_ReturnValue;                           // 0x000008 (0x000018)
        FVector                 CallFunc_GetActorForwardVector_ReturnValue;                         // 0x000020 (0x000018)
        FVector                 CallFunc_Add_VectorVector_ReturnValue;                              // 0x000038 (0x000018)
        AFortPlayerController*  CallFunc_Get_Spawned_Pickup_Optional_Owner_PC_Optional_Owner_PC;    // 0x000050 (0x000008) [Default: nullptr]
        FHitResult              K2Node_Event_Hit;                                                   // 0x000058 (0x0000F8)
        FFortItemEntry          CallFunc_GetOwnedItem_ReturnValue;                                  // 0x000150 (0x000098)
        AFortPickup*            CallFunc_K2_SpawnPickupInWorldWithClassAndItemEntry_ReturnValue;    // 0x0001E8 (0x000008) [Default: nullptr]
        AFortPlayerController*  CallFunc_GetOwnerPlayerController_ReturnValue;                      // 0x0001F0 (0x000008) [Default: nullptr]
    };

} // namespace UE

