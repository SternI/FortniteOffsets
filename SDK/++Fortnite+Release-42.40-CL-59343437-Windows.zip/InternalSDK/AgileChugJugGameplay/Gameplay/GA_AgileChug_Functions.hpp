/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:27
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AgileChugJugGameplay/Gameplay/GA_AgileChug_Functions
 * ============================================================
 */

#include "GA_AgileChug.hpp"

namespace UE
{

    struct UGA_AgileChug_C___SetupGE_Params
    {
        double                      HealAmount;                                                         // 0x000000 (0x000008) [Default: 1.62916e-315]
        double                      ShieldAmount;                                                       // 0x000008 (0x000008) [Default: -2.00903e+121]
        FGameplayEffectSpecHandle   GameplayEffect;                                                     // 0x000010 (0x000010) [OutParam]
        FGameplayEffectSpecHandle   CallFunc_MakeOutgoingGameplayEffectSpec_ReturnValue;                // 0x000020 (0x000010)
        FGameplayEffectSpecHandle   CallFunc_AssignTagSetByCallerMagnitude_ReturnValue;                 // 0x000030 (0x000010)
        FGameplayEffectSpecHandle   CallFunc_AssignTagSetByCallerMagnitude_ReturnValue_1;               // 0x000040 (0x000010)
        float                       CallFunc_AssignTagSetByCallerMagnitude_Magnitude_ImplicitCast;      // 0x000050 (0x000004) [Default: 0f]
        float                       CallFunc_AssignTagSetByCallerMagnitude_Magnitude_ImplicitCast_1;    // 0x000054 (0x000004) [Default: 0f]
    };

    struct UGA_AgileChug_C___SetAmmoCost_Params
    {
        double                          Cost;                                           // 0x000000 (0x000008) [Default: 1.62916e-315]
        FFortAbilityCostAmmoMagazine    LocalCostAmmoMagazine;                          // 0x000008 (0x000050)
        EStructUtilsResult              CallFunc_GetInstancedStructValue_ExecResult;    // 0x000058 (0x000001) [Default: EStructUtilsResult(2)]
        uint8                           UnknownData_000059[0x000007];                   // 0x000059 (0x000007)
        FFortAbilityCostAmmoMagazine    CallFunc_GetInstancedStructValue_Value;         // 0x000060 (0x000050)
        bool                            K2Node_SwitchEnum_CmpSuccess;                   // 0x0000B0 (0x000001) [Default: true]
        uint8                           UnknownData_0000B1[0x000003];                   // 0x0000B1 (0x000003)
        float                           K2Node_SetFieldsInStruct_Value_ImplicitCast;    // 0x0000B4 (0x000004) [Default: 2.8026e-45f]
    };

    struct UGA_AgileChug_C___OnWeaponAmmoChanged_Params
    {
        int32   LocalCount;     // 0x000000 (0x000004) [Default: 329745536]
        int32   LocalRemaining; // 0x000004 (0x000004) [Default: 0]
    };

    struct UGA_AgileChug_C___OnSprintTagAdded_Params
    {
        UAbilitySystemComponent*                        CallFunc_GetAbilitySystemComponentFromActorInfo_ReturnValue;    // 0x000000 (0x000008) [Default: 0x13A78480]
        bool                                            CallFunc_GetValueAsBool_ReturnValue;                            // 0x000008 (0x000001) [Default: true]
        bool                                            CallFunc_IsValid_ReturnValue;                                   // 0x000009 (0x000001) [Default: false]
        uint8                                           UnknownData_00000A[0x000006];                                   // 0x00000A (0x000006)
        TScriptInterface<IGameplayTagAssetInterface>    CallFunc_HasMatchingGameplayTag_self_CastInput;                 // 0x000010 (0x000010)
        bool                                            CallFunc_HasMatchingGameplayTag_ReturnValue;                    // 0x000020 (0x000001) [Default: true]
        bool                                            CallFunc_BooleanAND_ReturnValue;                                // 0x000021 (0x000001) [Default: true]
    };

    struct UGA_AgileChug_C___OnRelease_A4A377E4438EB738168D85A868FE5121_Params
    {
        float   TimeHeld;   // 0x000000 (0x000004) [Default: 4.22874e-27f]
    };

    struct UGA_AgileChug_C___OnConsumeWhileSprintingTagRemoved_Params
    {
        UAbilitySystemComponent*                        CallFunc_GetAbilitySystemComponentFromActorInfo_ReturnValue;    // 0x000000 (0x000008) [Default: 0x13A78480]
        TScriptInterface<IGameplayTagAssetInterface>    CallFunc_HasMatchingGameplayTag_self_CastInput;                 // 0x000008 (0x000010)
        bool                                            CallFunc_HasMatchingGameplayTag_ReturnValue;                    // 0x000018 (0x000001) [Default: true]
    };

    struct UGA_AgileChug_C___K2_OnEndAbility_Params
    {
        bool    bWasCancelled;  // 0x000000 (0x000001) [Default: true]
    };

    struct UGA_AgileChug_C___K2_CanActivateAbility_Params
    {
        FGameplayAbilityActorInfo   ActorInfo;                                      // 0x000000 (0x000048)
        FGameplayAbilitySpecHandle  Handle;                                         // 0x000048 (0x000018)
        FGameplayTagContainer       RelevantTags;                                   // 0x000060 (0x000020) [OutParam]
        bool                        ReturnValue;                                    // 0x000080 (0x000001) [ReturnValue] [Default: false]
        uint8                       UnknownData_000081[0x000007];                   // 0x000081 (0x000007)
        AFortPlayerPawn*            LocalFortPlayerPawn;                            // 0x000088 (0x000008) [Default: 0x2]
        AFortPlayerPawn*            K2Node_DynamicCast_AsFort_Player_Pawn;          // 0x000090 (0x000008) [Default: nullptr]
        bool                        K2Node_DynamicCast_bSuccess;                    // 0x000098 (0x000001) [Default: false]
        uint8                       UnknownData_000099[0x000003];                   // 0x000099 (0x000003)
        float                       CallFunc_GetMaxShield_ReturnValue;              // 0x00009C (0x000004) [Default: 0f]
        bool                        CallFunc_Greater_DoubleDouble_ReturnValue;      // 0x0000A0 (0x000001) [Default: true]
        bool                        CallFunc_IsPawnFullHealthAndShield_HealthFull;  // 0x0000A1 (0x000001) [Default: false]
        bool                        CallFunc_IsPawnFullHealthAndShield_ShieldFull;  // 0x0000A2 (0x000001) [Default: false]
        bool                        CallFunc_BooleanAND_ReturnValue;                // 0x0000A3 (0x000001) [Default: false]
        uint8                       UnknownData_0000A4[0x000004];                   // 0x0000A4 (0x000004)
        double                      CallFunc_Greater_DoubleDouble_A_ImplicitCast;   // 0x0000A8 (0x000008) [Default: 6.94834e-310]
    };

    struct UGA_AgileChug_C___IsPawnFullHealthAndShield_Params
    {
        AFortPlayerPawn*    FortPlayerPawn;                                     // 0x000000 (0x000008) [Default: 0x13A78480]
        bool                HealthFull;                                         // 0x000008 (0x000001) [OutParam] [Default: true]
        bool                ShieldFull;                                         // 0x000009 (0x000001) [OutParam] [Default: false]
        bool                ShieldFullOut;                                      // 0x00000A (0x000001) [Default: true]
        bool                HealthFullOut;                                      // 0x00000B (0x000001) [Default: false]
        float               CallFunc_GetShield_ReturnValue;                     // 0x00000C (0x000004) [Default: -2.79928e+15f]
        float               CallFunc_GetMaxShield_ReturnValue;                  // 0x000010 (0x000004) [Default: -2.25033e+15f]
        float               CallFunc_GetMaxHealth_ReturnValue;                  // 0x000014 (0x000004) [Default: 4.58911e-41f]
        bool                CallFunc_NearlyEqual_FloatFloat_ReturnValue;        // 0x000018 (0x000001) [Default: true]
        uint8               UnknownData_000019[0x000003];                       // 0x000019 (0x000003)
        float               CallFunc_GetHealth_ReturnValue;                     // 0x00001C (0x000004) [Default: 4.58855e-41f]
        bool                CallFunc_NearlyEqual_FloatFloat_ReturnValue_1;      // 0x000020 (0x000001) [Default: true]
        uint8               UnknownData_000021[0x000007];                       // 0x000021 (0x000007)
        double              CallFunc_NearlyEqual_FloatFloat_A_ImplicitCast;     // 0x000028 (0x000008) [Default: 1.62917e-315]
        double              CallFunc_NearlyEqual_FloatFloat_B_ImplicitCast;     // 0x000030 (0x000008) [Default: 0]
        double              CallFunc_NearlyEqual_FloatFloat_B_ImplicitCast_1;   // 0x000038 (0x000008) [Default: 0]
        double              CallFunc_NearlyEqual_FloatFloat_A_ImplicitCast_1;   // 0x000040 (0x000008) [Default: 9.88131e-324]
    };

    struct UGA_AgileChug_C___GetCustomAbilitySourceTransform_Params
    {
        FTransform          ReturnValue;                                    // 0x000000 (0x000060) [ReturnValue]
        AFortPlayerPawn*    CallFunc_GetAvatarAsFortPlayerPawn_ReturnValue; // 0x000060 (0x000008) [Default: nullptr]
        FVector             CallFunc_K2_GetActorLocation_ReturnValue;       // 0x000068 (0x000018)
        FVector             CallFunc_GetSocketLocation_ReturnValue;         // 0x000080 (0x000018)
        double              CallFunc_BreakVector_X;                         // 0x000098 (0x000008) [Default: 0]
        double              CallFunc_BreakVector_Y;                         // 0x0000A0 (0x000008) [Default: 9.88131e-324]
        double              CallFunc_BreakVector_Z;                         // 0x0000A8 (0x000008) [Default: 6.94834e-310]
        double              CallFunc_BreakVector_X_1;                       // 0x0000B0 (0x000008) [Default: 4.24399e-314]
        double              CallFunc_BreakVector_Y_1;                       // 0x0000B8 (0x000008) [Default: 6.94844e-310]
        double              CallFunc_BreakVector_Z_1;                       // 0x0000C0 (0x000008) [Default: 1.6976e-313]
        FVector             CallFunc_MakeVector_ReturnValue;                // 0x0000C8 (0x000018)
        FTransform          CallFunc_MakeTransform_ReturnValue;             // 0x0000E0 (0x000060)
    };

    struct UGA_AgileChug_C___ExecuteUbergraph_GA_AgileChug_Params
    {
        int32                                           EntryPoint;                                                     // 0x000000 (0x000004) [Default: 329745536]
        uint8                                           UnknownData_000004[0x000004];                                   // 0x000004 (0x000004)
        AFortPlayerPawn*                                CallFunc_GetAvatarAsFortPlayerPawn_ReturnValue;                 // 0x000008 (0x000008) [Default: 0xD91F1EDD00280031]
        FGameplayTag                                    Temp_struct_Variable;                                           // 0x000010 (0x000004)
        uint8                                           UnknownData_000014[0x000004];                                   // 0x000014 (0x000004)
        FGameplayAbilityTargetDataHandle                Temp_struct_Variable_1;                                         // 0x000018 (0x000028)
        float                                           K2Node_CustomEvent_TimeHeld;                                    // 0x000040 (0x000004) [Default: 2.8026e-45f]
        InputReleaseDelegate                            K2Node_CreateDelegate_OutputDelegate;                           // 0x000044 (0x00000C)
        float                                           Temp_real_Variable;                                             // 0x000050 (0x000004) [Default: 0f]
        uint8                                           UnknownData_000054[0x000004];                                   // 0x000054 (0x000004)
        UAbilityTask_WaitInputRelease*                  CallFunc_WaitInputRelease_ReturnValue;                          // 0x000058 (0x000008) [Default: 0x2]
        bool                                            CallFunc_IsValid_ReturnValue;                                   // 0x000060 (0x000001) [Default: false]
        bool                                            CallFunc_IsValid_ReturnValue_1;                                 // 0x000061 (0x000001) [Default: false]
        uint8                                           UnknownData_000062[0x000002];                                   // 0x000062 (0x000002)
        float                                           CallFunc_BP_Montage_GetSectionLength_ReturnValue;               // 0x000064 (0x000004) [Default: 0f]
        FGameplayCueParameters                          CallFunc_MakeGameplayCueParameters_ReturnValue;                 // 0x000068 (0x0000D0)
        WaitGameplayTagDelegate                         K2Node_CreateDelegate_OutputDelegate_1;                         // 0x000138 (0x00000C)
        WaitGameplayTagDelegate                         K2Node_CreateDelegate_OutputDelegate_2;                         // 0x000144 (0x00000C)
        FGameplayAbilityTargetDataHandle                K2Node_CustomEvent_TargetData_2;                                // 0x000150 (0x000028)
        FGameplayTag                                    K2Node_CustomEvent_ApplicationTag_2;                            // 0x000178 (0x000004)
        uint8                                           UnknownData_00017C[0x000004];                                   // 0x00017C (0x000004)
        UFortAbilityTask_PlayMontageWaitTarget*         CallFunc_PlayMontageWaitTarget_ReturnValue;                     // 0x000180 (0x000008) [Default: nullptr]
        bool                                            CallFunc_IsValid_ReturnValue_2;                                 // 0x000188 (0x000001) [Default: false]
        bool                                            K2Node_Event_bWasCancelled;                                     // 0x000189 (0x000001) [Default: false]
        uint8                                           UnknownData_00018A[0x000002];                                   // 0x00018A (0x000002)
        TimerDynamicDelegate                            K2Node_CreateDelegate_OutputDelegate_3;                         // 0x00018C (0x00000C)
        bool                                            CallFunc_IsServer_ReturnValue;                                  // 0x000198 (0x000001) [Default: false]
        uint8                                           UnknownData_000199[0x000007];                                   // 0x000199 (0x000007)
        AFortWeapon*                                    CallFunc_GetCurrentSourceWeapon_ReturnValue;                    // 0x0001A0 (0x000008) [Default: nullptr]
        OnLocalAmmoChanged                              K2Node_CreateDelegate_OutputDelegate_4;                         // 0x0001A8 (0x00000C)
        int32                                           K2Node_CustomEvent_LocalCount;                                  // 0x0001B4 (0x000004) [Default: 0]
        int32                                           K2Node_CustomEvent_LocalRemaining;                              // 0x0001B8 (0x000004) [Default: 0]
        bool                                            CallFunc_LessEqual_IntInt_ReturnValue;                          // 0x0001BC (0x000001) [Default: false]
        bool                                            CallFunc_K2_CommitAbility_ReturnValue;                          // 0x0001BD (0x000001) [Default: false]
        bool                                            Temp_bool_B_Execution_Happened_Variable;                        // 0x0001BE (0x000001) [Default: false]
        uint8                                           UnknownByte_0001BF;                                             // 0x0001BF (0x000001)
        WaitTargetSelectionDelegate                     K2Node_CreateDelegate_OutputDelegate_5;                         // 0x0001C0 (0x00000C)
        bool                                            CallFunc_K2_HasAuthority_ReturnValue;                           // 0x0001CC (0x000001) [Default: false]
        uint8                                           UnknownData_0001CD[0x000003];                                   // 0x0001CD (0x000003)
        float                                           CallFunc_GetValueAtLevel_ReturnValue;                           // 0x0001D0 (0x000004) [Default: 0f]
        uint8                                           UnknownData_0001D4[0x000004];                                   // 0x0001D4 (0x000004)
        FTimerHandle                                    CallFunc_K2_SetTimerDelegate_ReturnValue;                       // 0x0001D8 (0x000008)
        double                                          CallFunc_CalculateHealthAndShield_HealAmountOut;                // 0x0001E0 (0x000008) [Default: 0]
        double                                          CallFunc_CalculateHealthAndShield_ShieldAmountOut;              // 0x0001E8 (0x000008) [Default: 0]
        FGameplayEffectSpecHandle                       CallFunc_SetupGE_GameplayEffect;                                // 0x0001F0 (0x000010)
        FGameplayAbilityTargetDataHandle                K2Node_CustomEvent_TargetData;                                  // 0x000200 (0x000028)
        FGameplayTag                                    K2Node_CustomEvent_ApplicationTag;                              // 0x000228 (0x000004)
        FActiveGameplayEffectHandle                     CallFunc_K2_ApplyGameplayEffectSpecToOwner_ReturnValue;         // 0x00022C (0x000014)
        AFortPlayerPawn*                                CallFunc_GetAvatarAsFortPlayerPawn_ReturnValue_1;               // 0x000240 (0x000008) [Default: nullptr]
        WaitTargetSelectionDelegate                     K2Node_CreateDelegate_OutputDelegate_6;                         // 0x000248 (0x00000C)
        bool                                            CallFunc_IsPawnFullHealthAndShield_HealthFull;                  // 0x000254 (0x000001) [Default: false]
        bool                                            CallFunc_IsPawnFullHealthAndShield_ShieldFull;                  // 0x000255 (0x000001) [Default: false]
        bool                                            CallFunc_BooleanNAND_ReturnValue;                               // 0x000256 (0x000001) [Default: false]
        uint8                                           UnknownByte_000257;                                             // 0x000257 (0x000001)
        FGameplayAbilityTargetDataHandle                K2Node_CustomEvent_TargetData_1;                                // 0x000258 (0x000028)
        FGameplayTag                                    K2Node_CustomEvent_ApplicationTag_1;                            // 0x000280 (0x000004)
        bool                                            CallFunc_K2_HasAuthority_ReturnValue_1;                         // 0x000284 (0x000001) [Default: false]
        bool                                            Temp_bool_A_Execution_Happened_Variable;                        // 0x000285 (0x000001) [Default: false]
        uint8                                           UnknownData_000286[0x000002];                                   // 0x000286 (0x000002)
        FGameplayCueParameters                          CallFunc_MakeGameplayCueParameters_ReturnValue_1;               // 0x000288 (0x0000D0)
        bool                                            CallFunc_BooleanAND_ReturnValue;                                // 0x000358 (0x000001) [Default: false]
        uint8                                           UnknownData_000359[0x000007];                                   // 0x000359 (0x000007)
        AActor*                                         CallFunc_GetAvatarActorFromActorInfo_ReturnValue;               // 0x000360 (0x000008) [Default: nullptr]
        bool                                            CallFunc_GetValueAsBool_ReturnValue;                            // 0x000368 (0x000001) [Default: false]
        bool                                            CallFunc_GetValueAsBool_ReturnValue_1;                          // 0x000369 (0x000001) [Default: false]
        bool                                            CallFunc_GetValueAsBool_ReturnValue_2;                          // 0x00036A (0x000001) [Default: false]
        uint8                                           UnknownByte_00036B;                                             // 0x00036B (0x000001)
        FActiveGameplayEffectHandle                     CallFunc_BP_ApplyGameplayEffectToOwner_ReturnValue;             // 0x00036C (0x000014)
        AFortWeapon*                                    CallFunc_GetCurrentSourceWeapon_ReturnValue_1;                  // 0x000380 (0x000008) [Default: 0x13A789F0]
        int32                                           CallFunc_GetLocalRemainingAmmo_ReturnValue;                     // 0x000388 (0x000004) [Default: 329747056]
        bool                                            CallFunc_LessEqual_IntInt_ReturnValue_1;                        // 0x00038C (0x000001) [Default: false]
        uint8                                           UnknownData_00038D[0x000003];                                   // 0x00038D (0x000003)
        WaitTargetSelectionDelegate                     K2Node_CreateDelegate_OutputDelegate_7;                         // 0x000390 (0x00000C)
        uint8                                           UnknownData_00039C[0x000004];                                   // 0x00039C (0x000004)
        AFortWeapon*                                    CallFunc_GetCurrentSourceWeapon_ReturnValue_2;                  // 0x0003A0 (0x000008) [Default: 0x13A78AE0]
        UFortItem*                                      CallFunc_GetInventoryItem_ReturnValue;                          // 0x0003A8 (0x000008) [Default: 0x2]
        bool                                            CallFunc_IsValid_ReturnValue_3;                                 // 0x0003B0 (0x000001) [Default: false]
        uint8                                           UnknownData_0003B1[0x000007];                                   // 0x0003B1 (0x000007)
        UAbilityTask_WaitGameplayTagAdded*              CallFunc_WaitGameplayTagAdd_ReturnValue;                        // 0x0003B8 (0x000008) [Default: nullptr]
        UAbilityTask_WaitGameplayTagRemoved*            CallFunc_WaitGameplayTagRemove_ReturnValue;                     // 0x0003C0 (0x000008) [Default: nullptr]
        bool                                            CallFunc_IsValid_ReturnValue_4;                                 // 0x0003C8 (0x000001) [Default: true]
        bool                                            CallFunc_IsValid_ReturnValue_5;                                 // 0x0003C9 (0x000001) [Default: false]
        bool                                            CallFunc_GetValueAsBool_ReturnValue_3;                          // 0x0003CA (0x000001) [Default: false]
        uint8                                           UnknownData_0003CB[0x000005];                                   // 0x0003CB (0x000005)
        UAbilitySystemComponent*                        CallFunc_GetAbilitySystemComponentFromActorInfo_ReturnValue;    // 0x0003D0 (0x000008) [Default: nullptr]
        TScriptInterface<IGameplayTagAssetInterface>    CallFunc_HasMatchingGameplayTag_self_CastInput;                 // 0x0003D8 (0x000010)
        bool                                            CallFunc_HasMatchingGameplayTag_ReturnValue;                    // 0x0003E8 (0x000001) [Default: false]
        bool                                            CallFunc_GetValueAsBool_ReturnValue_4;                          // 0x0003E9 (0x000001) [Default: false]
        bool                                            CallFunc_BooleanAND_ReturnValue_1;                              // 0x0003EA (0x000001) [Default: false]
        bool                                            CallFunc_BooleanAND_ReturnValue_2;                              // 0x0003EB (0x000001) [Default: false]
    };

    struct UGA_AgileChug_C___Completed_B4B9CF6248850F50A4FAF9BA8C018C08_Params
    {
        FGameplayAbilityTargetDataHandle    TargetData;     // 0x000000 (0x000028) [OutParam]
        FGameplayTag                        ApplicationTag; // 0x000028 (0x000004)
    };

    struct UGA_AgileChug_C___CheckForInfiniteAmmo_Params
    {
        bool            bInfiniteAmmo;                                      // 0x000000 (0x000001) [Default: true]
        bool            CallFunc_Not_PreBool_ReturnValue;                   // 0x000001 (0x000001) [Default: true]
        uint8           UnknownData_000002[0x000006];                       // 0x000002 (0x000006)
        double          CallFunc_Conv_BoolToDouble_ReturnValue;             // 0x000008 (0x000008) [Default: -2.00903e+121]
        AFortWeapon*    CallFunc_GetCurrentSourceWeapon_ReturnValue;        // 0x000010 (0x000008) [Default: 0x7FEDD8FFD540]
        bool            CallFunc_IsValid_ReturnValue;                       // 0x000018 (0x000001) [Default: true]
        uint8           UnknownData_000019[0x000007];                       // 0x000019 (0x000007)
        UFortItem*      CallFunc_GetInventoryItem_ReturnValue;              // 0x000020 (0x000008) [Default: 0x78A40BC]
        bool            CallFunc_HasInfiniteAmmo_ReturnValue;               // 0x000028 (0x000001) [Default: true]
        bool            CallFunc_InventoryOwnerHasInfiniteAmmo_ReturnValue; // 0x000029 (0x000001) [Default: true]
        bool            CallFunc_BooleanOR_ReturnValue;                     // 0x00002A (0x000001) [Default: true]
    };

    struct UGA_AgileChug_C___CheckConsumeWhileSprintingAndForceHolster_Params
    {
        bool                                            CallFunc_GetValueAsBool_ReturnValue;            // 0x000000 (0x000001) [Default: true]
        bool                                            CallFunc_GetValueAsBool_ReturnValue_1;          // 0x000001 (0x000001) [Default: true]
        uint8                                           UnknownData_000002[0x000006];                   // 0x000002 (0x000006)
        AFortPlayerPawn*                                CallFunc_GetAvatarAsFortPlayerPawn_ReturnValue; // 0x000008 (0x000008) [Default: 0xD91F1EDD00280031]
        UAbilitySystemComponent*                        CallFunc_GetAbilitySystemComponent_ReturnValue; // 0x000010 (0x000008) [Default: 0x7FEDD8FFD540]
        TScriptInterface<IGameplayTagAssetInterface>    CallFunc_HasMatchingGameplayTag_self_CastInput; // 0x000018 (0x000010)
        bool                                            CallFunc_HasMatchingGameplayTag_ReturnValue;    // 0x000028 (0x000001) [Default: true]
        bool                                            CallFunc_BooleanAND_ReturnValue;                // 0x000029 (0x000001) [Default: true]
        bool                                            CallFunc_BooleanAND_ReturnValue_1;              // 0x00002A (0x000001) [Default: true]
        bool                                            CallFunc_BooleanAND_ReturnValue_2;              // 0x00002B (0x000001) [Default: true]
    };

    struct UGA_AgileChug_C___Cancelled_B4B9CF6248850F50A4FAF9BA8C018C08_Params
    {
        FGameplayAbilityTargetDataHandle    TargetData;     // 0x000000 (0x000028) [OutParam]
        FGameplayTag                        ApplicationTag; // 0x000028 (0x000004)
    };

    struct UGA_AgileChug_C___CanApplyHolster_Params
    {
        FName   HolsterId;      // 0x000000 (0x000004) [OutParam] [Default: FName(329745536) -> L""]
        bool    ReturnValue;    // 0x000004 (0x000001) [ReturnValue] [Default: false]
    };

    struct UGA_AgileChug_C___CalculateHealthAndShield_Params
    {
        double                          HealAmountOut;                                              // 0x000000 (0x000008) [OutParam] [Default: 1.62916e-315]
        double                          ShieldAmountOut;                                            // 0x000008 (0x000008) [OutParam] [Default: -2.00903e+121]
        bool                            ApplyOverHeal_;                                             // 0x000010 (0x000001) [Default: true]
        uint8                           UnknownData_000011[0x000007];                               // 0x000011 (0x000007)
        double                          ToFullShieldAmount;                                         // 0x000018 (0x000008) [Default: 6.9486e-310]
        double                          ShieldAmount;                                               // 0x000020 (0x000008) [Default: 6.24998e-316]
        AFortPlayerPawn*                FortPlayerPawn;                                             // 0x000028 (0x000008) [Default: 0x13A789A0]
        float                           HealAmount;                                                 // 0x000030 (0x000004) [Default: 0f]
        uint8                           UnknownData_000034[0x000004];                               // 0x000034 (0x000004)
        double                          OverHeal;                                                   // 0x000038 (0x000008) [Default: 0]
        double                          ToFullHealthAmount;                                         // 0x000040 (0x000008) [Default: 9.88131e-324]
        float                           CallFunc_GetHealth_ReturnValue;                             // 0x000048 (0x000004) [Default: 0f]
        float                           CallFunc_GetMaxHealth_ReturnValue;                          // 0x00004C (0x000004) [Default: 0f]
        bool                            CallFunc_GreaterEqual_DoubleDouble_ReturnValue;             // 0x000050 (0x000001) [Default: false]
        bool                            CallFunc_Less_DoubleDouble_ReturnValue;                     // 0x000051 (0x000001) [Default: false]
        bool                            CallFunc_Greater_DoubleDouble_ReturnValue;                  // 0x000052 (0x000001) [Default: false]
        bool                            CallFunc_BooleanAND_ReturnValue;                            // 0x000053 (0x000001) [Default: false]
        float                           CallFunc_GetShield_ReturnValue;                             // 0x000054 (0x000004) [Default: 0f]
        float                           CallFunc_GetMaxShield_ReturnValue;                          // 0x000058 (0x000004) [Default: 2.8026e-45f]
        uint8                           UnknownData_00005C[0x000004];                               // 0x00005C (0x000004)
        double                          CallFunc_Subtract_DoubleDouble_ReturnValue;                 // 0x000060 (0x000008) [Default: 0]
        float                           CallFunc_GetValueAtLevel_ReturnValue;                       // 0x000068 (0x000004) [Default: 0f]
        uint8                           UnknownData_00006C[0x000004];                               // 0x00006C (0x000004)
        double                          CallFunc_SelectFloat_ReturnValue;                           // 0x000070 (0x000008) [Default: 9.88131e-324]
        float                           CallFunc_GetHealth_ReturnValue_1;                           // 0x000078 (0x000004) [Default: 0f]
        float                           CallFunc_GetMaxHealth_ReturnValue_1;                        // 0x00007C (0x000004) [Default: 0f]
        double                          CallFunc_Subtract_DoubleDouble_ReturnValue_1;               // 0x000080 (0x000008) [Default: 0]
        float                           CallFunc_GetValueAtLevel_ReturnValue_1;                     // 0x000088 (0x000004) [Default: 2.8026e-45f]
        uint8                           UnknownData_00008C[0x000004];                               // 0x00008C (0x000004)
        double                          CallFunc_Subtract_DoubleDouble_ReturnValue_2;               // 0x000090 (0x000008) [Default: 0]
        bool                            CallFunc_GetValueAsBool_ReturnValue;                        // 0x000098 (0x000001) [Default: false]
        uint8                           UnknownData_000099[0x000007];                               // 0x000099 (0x000007)
        double                          CallFunc_FClamp_ReturnValue;                                // 0x0000A0 (0x000008) [Default: 9.88131e-324]
        double                          CallFunc_FMin_ReturnValue;                                  // 0x0000A8 (0x000008) [Default: 6.94834e-310]
        bool                            CallFunc_GetValueAsBool_ReturnValue_1;                      // 0x0000B0 (0x000001) [Default: true]
        uint8                           UnknownData_0000B1[0x000003];                               // 0x0000B1 (0x000003)
        float                           CallFunc_GetShield_ReturnValue_1;                           // 0x0000B4 (0x000004) [Default: 2.8026e-45f]
        float                           CallFunc_GetValueAtLevel_ReturnValue_2;                     // 0x0000B8 (0x000004) [Default: -1.78169e+15f]
        float                           CallFunc_GetMaxShield_ReturnValue_1;                        // 0x0000BC (0x000004) [Default: 4.58841e-41f]
        double                          CallFunc_Add_DoubleDouble_ReturnValue;                      // 0x0000C0 (0x000008) [Default: 1.6976e-313]
        double                          CallFunc_Subtract_DoubleDouble_ReturnValue_3;               // 0x0000C8 (0x000008) [Default: 7.74682e-304]
        double                          CallFunc_SelectFloat_ReturnValue_1;                         // 0x0000D0 (0x000008) [Default: 4.94066e-324]
        double                          CallFunc_FClamp_ReturnValue_1;                              // 0x0000D8 (0x000008) [Default: 0]
        float                           CallFunc_GetHealth_ReturnValue_2;                           // 0x0000E0 (0x000004) [Default: 0f]
        float                           CallFunc_GetMaxHealth_ReturnValue_2;                        // 0x0000E4 (0x000004) [Default: 0f]
        double                          CallFunc_Subtract_DoubleDouble_ReturnValue_4;               // 0x0000E8 (0x000008) [Default: 0]
        double                          CallFunc_FClamp_ReturnValue_2;                              // 0x0000F0 (0x000008) [Default: 0]
        float                           CallFunc_GetValueAtLevel_ReturnValue_3;                     // 0x0000F8 (0x000004) [Default: 0f]
        EFortGetPlayerPawnExecutions    CallFunc_GetAvatarAsValidFortPlayerPawn_OutExec;            // 0x0000FC (0x000001) [Default: EFortGetPlayerPawnExecutions(0)]
        uint8                           UnknownData_0000FD[0x000003];                               // 0x0000FD (0x000003)
        AFortPlayerPawn*                CallFunc_GetAvatarAsValidFortPlayerPawn_OutFortPlayerPawn;  // 0x000100 (0x000008) [Default: nullptr]
        double                          CallFunc_Subtract_DoubleDouble_ReturnValue_5;               // 0x000108 (0x000008) [Default: 0]
        double                          CallFunc_FClamp_ReturnValue_3;                              // 0x000110 (0x000008) [Default: 1.60234e-315]
        bool                            K2Node_SwitchEnum_CmpSuccess;                               // 0x000118 (0x000001) [Default: false]
        uint8                           UnknownData_000119[0x000007];                               // 0x000119 (0x000007)
        double                          CallFunc_FMin_ReturnValue_1;                                // 0x000120 (0x000008) [Default: 0]
        double                          K2Node_FunctionResult_HealAmountOut_ImplicitCast;           // 0x000128 (0x000008) [Default: 0]
        double                          CallFunc_GreaterEqual_DoubleDouble_A_ImplicitCast;          // 0x000130 (0x000008) [Default: 0]
        double                          CallFunc_GreaterEqual_DoubleDouble_B_ImplicitCast;          // 0x000138 (0x000008) [Default: 0]
        double                          CallFunc_Subtract_DoubleDouble_B_ImplicitCast;              // 0x000140 (0x000008) [Default: 0]
        double                          CallFunc_Subtract_DoubleDouble_A_ImplicitCast;              // 0x000148 (0x000008) [Default: 0]
        double                          CallFunc_SelectFloat_B_ImplicitCast;                        // 0x000150 (0x000008) [Default: 0]
        double                          CallFunc_Subtract_DoubleDouble_B_ImplicitCast_1;            // 0x000158 (0x000008) [Default: 0]
        double                          CallFunc_Subtract_DoubleDouble_A_ImplicitCast_1;            // 0x000160 (0x000008) [Default: 0]
        double                          CallFunc_FMin_A_ImplicitCast;                               // 0x000168 (0x000008) [Default: 0]
        double                          CallFunc_FClamp_Max_ImplicitCast;                           // 0x000170 (0x000008) [Default: 0]
        double                          CallFunc_Subtract_DoubleDouble_A_ImplicitCast_2;            // 0x000178 (0x000008) [Default: 0]
        float                           K2Node_VariableSet_HealAmount_ImplicitCast;                 // 0x000180 (0x000004) [Default: 0f]
        uint8                           UnknownData_000184[0x000004];                               // 0x000184 (0x000004)
        double                          CallFunc_Subtract_DoubleDouble_B_ImplicitCast_2;            // 0x000188 (0x000008) [Default: 0]
        double                          CallFunc_SelectFloat_B_ImplicitCast_1;                      // 0x000190 (0x000008) [Default: 2.122e-314]
        double                          CallFunc_Add_DoubleDouble_B_ImplicitCast;                   // 0x000198 (0x000008) [Default: 0]
        double                          CallFunc_Subtract_DoubleDouble_A_ImplicitCast_3;            // 0x0001A0 (0x000008) [Default: 0]
        double                          CallFunc_Subtract_DoubleDouble_B_ImplicitCast_3;            // 0x0001A8 (0x000008) [Default: 0]
        double                          CallFunc_Subtract_DoubleDouble_A_ImplicitCast_4;            // 0x0001B0 (0x000008) [Default: 0]
        double                          CallFunc_FMin_A_ImplicitCast_1;                             // 0x0001B8 (0x000008) [Default: 0]
        double                          CallFunc_FClamp_Max_ImplicitCast_1;                         // 0x0001C0 (0x000008) [Default: 0]
        double                          CallFunc_Subtract_DoubleDouble_A_ImplicitCast_5;            // 0x0001C8 (0x000008) [Default: 0]
        float                           K2Node_VariableSet_HealAmount_ImplicitCast_1;               // 0x0001D0 (0x000004) [Default: 0f]
    };

    struct UGA_AgileChug_C___ApplyHealthAndShieldVisuals_Params
    {
        double  HealAmount;                                     // 0x000000 (0x000008) [Default: 1.62916e-315]
        double  ShieldAmount;                                   // 0x000008 (0x000008) [Default: -2.00903e+121]
        bool    CallFunc_Greater_DoubleDouble_ReturnValue;      // 0x000010 (0x000001) [Default: true]
        bool    CallFunc_IsGameplayTagValid_ReturnValue;        // 0x000011 (0x000001) [Default: true]
        bool    CallFunc_BooleanAND_ReturnValue;                // 0x000012 (0x000001) [Default: true]
        bool    CallFunc_IsGameplayTagValid_ReturnValue_1;      // 0x000013 (0x000001) [Default: true]
        bool    CallFunc_Greater_DoubleDouble_ReturnValue_1;    // 0x000014 (0x000001) [Default: true]
        bool    CallFunc_BooleanAND_ReturnValue_1;              // 0x000015 (0x000001) [Default: true]
    };

    struct UGA_AgileChug_C___AdjustValuesForEffectiveHealthFirst_Params
    {
        bool    CallFunc_GetValueAsBool_ReturnValue;    // 0x000000 (0x000001) [Default: true]
    };

    struct UGA_AgileChug_C___RemoveItem_Params
    {
        AFortPawn*      CallFunc_GetActivatingPawn_ReturnValue;             // 0x000000 (0x000008) [Default: 0x13A78480]
        AFortWeapon*    CallFunc_GetCurrentSourceWeapon_ReturnValue;        // 0x000008 (0x000008) [Default: 0xD91F1EDD00280031]
        AController*    CallFunc_GetController_ReturnValue;                 // 0x000010 (0x000008) [Default: 0x7FEDD8FFD540]
        UFortItem*      CallFunc_GetInventoryItem_ReturnValue;              // 0x000018 (0x000008) [Default: 0x7FE99AACAFA0]
        int32           CallFunc_K2_RemoveFortItemFromPlayer_ReturnValue;   // 0x000020 (0x000004) [Default: 126501052]
    };

    struct UGA_AgileChug_C___Triggered_B4B9CF6248850F50A4FAF9BA8C018C08_Params
    {
        FGameplayAbilityTargetDataHandle    TargetData;     // 0x000000 (0x000028) [OutParam]
        FGameplayTag                        ApplicationTag; // 0x000028 (0x000004)
    };

    struct UGA_AgileChug_C___ToggleMeshVisibility_Params
    {
        bool            NewHidden;                                      // 0x000000 (0x000001) [Default: true]
        uint8           UnknownData_000001[0x000007];                   // 0x000001 (0x000007)
        AFortWeapon*    CallFunc_GetCurrentSourceWeapon_ReturnValue;    // 0x000008 (0x000008) [Default: 0xD91F1EDD00280031]
    };

} // namespace UE

