/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:27
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AgileChugJugGameplay/Gameplay/B_Prj_Athena_Consumable_Thrown_ChugJug_Functions
 * ============================================================
 */

#include "B_Prj_Athena_Consumable_Thrown_ChugJug_Functions.hpp"

namespace UE
{

    void AB_Prj_Athena_Consumable_Thrown_ChugJug_C::SpawnItem(bool bHitWater)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Prj_Athena_Consumable_Thrown_ChugJug.B_Prj_Athena_Consumable_Thrown_ChugJug_C.SpawnItem");
    
        AB_Prj_Athena_Consumable_Thrown_ChugJug_C___SpawnItem_Params Params{};
        Params.bHitWater = bHitWater;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AB_Prj_Athena_Consumable_Thrown_ChugJug_C::SetitemEntryOnDrop(UFortItem* ItemObj, APawn* CallFunc_GetInstigator_ReturnValue, UFortWorldItem* K2Node_DynamicCast_AsFort_World_Item, bool K2Node_DynamicCast_bSuccess, AFortPlayerPawn* K2Node_DynamicCast_AsFort_Player_Pawn, bool K2Node_DynamicCast_bSuccess_1, FFortItemEntry CallFunc_CreateItemEntryForDrop_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Prj_Athena_Consumable_Thrown_ChugJug.B_Prj_Athena_Consumable_Thrown_ChugJug_C.SetitemEntryOnDrop");
    
        AB_Prj_Athena_Consumable_Thrown_ChugJug_C___SetitemEntryOnDrop_Params Params{};
        Params.ItemObj = ItemObj;
        Params.CallFunc_GetInstigator_ReturnValue = CallFunc_GetInstigator_ReturnValue;
        Params.K2Node_DynamicCast_AsFort_World_Item = K2Node_DynamicCast_AsFort_World_Item;
        Params.K2Node_DynamicCast_bSuccess = K2Node_DynamicCast_bSuccess;
        Params.K2Node_DynamicCast_AsFort_Player_Pawn = K2Node_DynamicCast_AsFort_Player_Pawn;
        Params.K2Node_DynamicCast_bSuccess_1 = K2Node_DynamicCast_bSuccess_1;
        Params.CallFunc_CreateItemEntryForDrop_ReturnValue = CallFunc_CreateItemEntryForDrop_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AB_Prj_Athena_Consumable_Thrown_ChugJug_C::SetItem(UFortItem* Item)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Prj_Athena_Consumable_Thrown_ChugJug.B_Prj_Athena_Consumable_Thrown_ChugJug_C.SetItem");
    
        AB_Prj_Athena_Consumable_Thrown_ChugJug_C___SetItem_Params Params{};
        Params.Item = Item;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AB_Prj_Athena_Consumable_Thrown_ChugJug_C::ReceiveBeginPlay()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Prj_Athena_Consumable_Thrown_ChugJug.B_Prj_Athena_Consumable_Thrown_ChugJug_C.ReceiveBeginPlay");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AB_Prj_Athena_Consumable_Thrown_ChugJug_C::OnBounce(FHitResult& Hit)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Prj_Athena_Consumable_Thrown_ChugJug.B_Prj_Athena_Consumable_Thrown_ChugJug_C.OnBounce");
    
        AB_Prj_Athena_Consumable_Thrown_ChugJug_C___OnBounce_Params Params{};
        Params.Hit = Hit;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Hit = Params.Hit;
    }

    void AB_Prj_Athena_Consumable_Thrown_ChugJug_C::ExecuteUbergraph_B_Prj_Athena_Consumable_Thrown_ChugJug(int32 EntryPoint, bool CallFunc_HasAuthority_ReturnValue, bool K2Node_Event_bHitWater, FVector CallFunc_K2_GetActorLocation_ReturnValue, FVector CallFunc_GetActorForwardVector_ReturnValue, FVector CallFunc_Add_VectorVector_ReturnValue, AFortPlayerController* CallFunc_Get_Spawned_Pickup_Optional_Owner_PC_Optional_Owner_PC, FHitResult K2Node_Event_Hit, FFortItemEntry CallFunc_GetOwnedItem_ReturnValue, AFortPickup* CallFunc_K2_SpawnPickupInWorldWithClassAndItemEntry_ReturnValue, AFortPlayerController* CallFunc_GetOwnerPlayerController_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Prj_Athena_Consumable_Thrown_ChugJug.B_Prj_Athena_Consumable_Thrown_ChugJug_C.ExecuteUbergraph_B_Prj_Athena_Consumable_Thrown_ChugJug");
    
        AB_Prj_Athena_Consumable_Thrown_ChugJug_C___ExecuteUbergraph_B_Prj_Athena_Consumable_Thrown_ChugJug_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.CallFunc_HasAuthority_ReturnValue = CallFunc_HasAuthority_ReturnValue;
        Params.K2Node_Event_bHitWater = K2Node_Event_bHitWater;
        Params.CallFunc_K2_GetActorLocation_ReturnValue = CallFunc_K2_GetActorLocation_ReturnValue;
        Params.CallFunc_GetActorForwardVector_ReturnValue = CallFunc_GetActorForwardVector_ReturnValue;
        Params.CallFunc_Add_VectorVector_ReturnValue = CallFunc_Add_VectorVector_ReturnValue;
        Params.CallFunc_Get_Spawned_Pickup_Optional_Owner_PC_Optional_Owner_PC = CallFunc_Get_Spawned_Pickup_Optional_Owner_PC_Optional_Owner_PC;
        Params.K2Node_Event_Hit = K2Node_Event_Hit;
        Params.CallFunc_GetOwnedItem_ReturnValue = CallFunc_GetOwnedItem_ReturnValue;
        Params.CallFunc_K2_SpawnPickupInWorldWithClassAndItemEntry_ReturnValue = CallFunc_K2_SpawnPickupInWorldWithClassAndItemEntry_ReturnValue;
        Params.CallFunc_GetOwnerPlayerController_ReturnValue = CallFunc_GetOwnerPlayerController_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

