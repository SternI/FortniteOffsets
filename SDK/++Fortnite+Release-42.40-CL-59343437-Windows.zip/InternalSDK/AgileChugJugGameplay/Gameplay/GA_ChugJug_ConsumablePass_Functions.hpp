/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:27
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AgileChugJugGameplay/Gameplay/GA_ChugJug_ConsumablePass_Functions
 * ============================================================
 */

#include "GA_ChugJug_ConsumablePass.hpp"

namespace UE
{

    struct UGA_ChugJug_ConsumablePass_C___K2_OnEndAbility_Params
    {
        bool    bWasCancelled;  // 0x000000 (0x000001) [Default: true]
    };

    struct UGA_ChugJug_ConsumablePass_C___ExecuteUbergraph_GA_ChugJug_ConsumablePass_Params
    {
        int32                                       EntryPoint;                                                     // 0x000000 (0x000004) [Default: 329801920]
        uint8                                       UnknownData_000004[0x000004];                                   // 0x000004 (0x000004)
        AActor*                                     CallFunc_GetAvatarActorFromActorInfo_ReturnValue;               // 0x000008 (0x000008) [Default: 0xE1F1EDD00280031]
        UAbilityAsync_WaitGameplayEvent*            CallFunc_WaitGameplayEventToActor_ReturnValue;                  // 0x000010 (0x000008) [Default: 0x7FEDD8FFCA80]
        EventReceivedDelegate                       K2Node_CreateDelegate_OutputDelegate;                           // 0x000018 (0x00000C)
        bool                                        CallFunc_IsValid_ReturnValue;                                   // 0x000024 (0x000001) [Default: false]
        uint8                                       UnknownData_000025[0x000003];                                   // 0x000025 (0x000003)
        FGameplayEventData                          K2Node_CustomEvent_Payload;                                     // 0x000028 (0x0000C0)
        FGameplayEventData                          Temp_struct_Variable;                                           // 0x0000E8 (0x0000C0)
        bool                                        CallFunc_IsDedicatedServer_ReturnValue;                         // 0x0001A8 (0x000001) [Default: false]
        bool                                        K2Node_Event_bWasCancelled;                                     // 0x0001A9 (0x000001) [Default: false]
        bool                                        CallFunc_IsValid_ReturnValue_1;                                 // 0x0001AA (0x000001) [Default: false]
        uint8                                       UnknownData_0001AB[0x000005];                                   // 0x0001AB (0x000005)
        AB_Prj_Athena_Consumable_Thrown_ChugJug_C*  K2Node_DynamicCast_AsB_Prj_Athena_Consumable_Thrown_Chug_Jug;   // 0x0001B0 (0x000008) [Default: nullptr]
        bool                                        K2Node_DynamicCast_bSuccess;                                    // 0x0001B8 (0x000001) [Default: false]
        uint8                                       UnknownData_0001B9[0x000007];                                   // 0x0001B9 (0x000007)
        AFortWeapon*                                CallFunc_GetCurrentSourceWeapon_ReturnValue;                    // 0x0001C0 (0x000008) [Default: nullptr]
        AFortPawn*                                  CallFunc_GetActivatingPawn_ReturnValue;                         // 0x0001C8 (0x000008) [Default: nullptr]
        UFortItem*                                  CallFunc_GetInventoryItem_ReturnValue;                          // 0x0001D0 (0x000008) [Default: nullptr]
        AFortPlayerController*                      CallFunc_GetFortPlayerControllerFromActor_ReturnValue;          // 0x0001D8 (0x000008) [Default: nullptr]
        int32                                       CallFunc_K2_RemoveFortItemFromPlayer_ReturnValue;               // 0x0001E0 (0x000004) [Default: 0]
    };

    struct UGA_ChugJug_ConsumablePass_C___EventReceived_D8EEA86340BD268FB7E25B94B86D4511_Params
    {
        FGameplayEventData  Payload;    // 0x000000 (0x0000C0)
    };

} // namespace UE

