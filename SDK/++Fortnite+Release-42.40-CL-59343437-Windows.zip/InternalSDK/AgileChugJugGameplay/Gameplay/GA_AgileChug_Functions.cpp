/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:27
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AgileChugJugGameplay/Gameplay/GA_AgileChug_Functions
 * ============================================================
 */

#include "GA_AgileChug_Functions.hpp"

namespace UE
{

    void UGA_AgileChug_C::ShowTimerUntilApplication()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.ShowTimerUntilApplication");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_AgileChug_C::SetupGE(double HealAmount, double ShieldAmount, FGameplayEffectSpecHandle& GameplayEffect, FGameplayEffectSpecHandle CallFunc_MakeOutgoingGameplayEffectSpec_ReturnValue, FGameplayEffectSpecHandle CallFunc_AssignTagSetByCallerMagnitude_ReturnValue, FGameplayEffectSpecHandle CallFunc_AssignTagSetByCallerMagnitude_ReturnValue_1, float CallFunc_AssignTagSetByCallerMagnitude_Magnitude_ImplicitCast, float CallFunc_AssignTagSetByCallerMagnitude_Magnitude_ImplicitCast_1)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.SetupGE");
    
        UGA_AgileChug_C___SetupGE_Params Params{};
        Params.HealAmount = HealAmount;
        Params.ShieldAmount = ShieldAmount;
        Params.GameplayEffect = GameplayEffect;
        Params.CallFunc_MakeOutgoingGameplayEffectSpec_ReturnValue = CallFunc_MakeOutgoingGameplayEffectSpec_ReturnValue;
        Params.CallFunc_AssignTagSetByCallerMagnitude_ReturnValue = CallFunc_AssignTagSetByCallerMagnitude_ReturnValue;
        Params.CallFunc_AssignTagSetByCallerMagnitude_ReturnValue_1 = CallFunc_AssignTagSetByCallerMagnitude_ReturnValue_1;
        Params.CallFunc_AssignTagSetByCallerMagnitude_Magnitude_ImplicitCast = CallFunc_AssignTagSetByCallerMagnitude_Magnitude_ImplicitCast;
        Params.CallFunc_AssignTagSetByCallerMagnitude_Magnitude_ImplicitCast_1 = CallFunc_AssignTagSetByCallerMagnitude_Magnitude_ImplicitCast_1;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        GameplayEffect = Params.GameplayEffect;
    }

    void UGA_AgileChug_C::SetAmmoCost(double Cost, FFortAbilityCostAmmoMagazine LocalCostAmmoMagazine, EStructUtilsResult CallFunc_GetInstancedStructValue_ExecResult, FFortAbilityCostAmmoMagazine CallFunc_GetInstancedStructValue_Value, bool K2Node_SwitchEnum_CmpSuccess, float K2Node_SetFieldsInStruct_Value_ImplicitCast)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.SetAmmoCost");
    
        UGA_AgileChug_C___SetAmmoCost_Params Params{};
        Params.Cost = Cost;
        Params.LocalCostAmmoMagazine = LocalCostAmmoMagazine;
        Params.CallFunc_GetInstancedStructValue_ExecResult = CallFunc_GetInstancedStructValue_ExecResult;
        Params.CallFunc_GetInstancedStructValue_Value = CallFunc_GetInstancedStructValue_Value;
        Params.K2Node_SwitchEnum_CmpSuccess = K2Node_SwitchEnum_CmpSuccess;
        Params.K2Node_SetFieldsInStruct_Value_ImplicitCast = K2Node_SetFieldsInStruct_Value_ImplicitCast;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_AgileChug_C::PrepareToEndAbility()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.PrepareToEndAbility");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_AgileChug_C::OnWeaponAmmoChanged(int32 LocalCount, int32 LocalRemaining)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.OnWeaponAmmoChanged");
    
        UGA_AgileChug_C___OnWeaponAmmoChanged_Params Params{};
        Params.LocalCount = LocalCount;
        Params.LocalRemaining = LocalRemaining;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_AgileChug_C::OnSprintTagAdded(UAbilitySystemComponent* CallFunc_GetAbilitySystemComponentFromActorInfo_ReturnValue, bool CallFunc_GetValueAsBool_ReturnValue, bool CallFunc_IsValid_ReturnValue, TScriptInterface<IGameplayTagAssetInterface> CallFunc_HasMatchingGameplayTag_self_CastInput, bool CallFunc_HasMatchingGameplayTag_ReturnValue, bool CallFunc_BooleanAND_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.OnSprintTagAdded");
    
        UGA_AgileChug_C___OnSprintTagAdded_Params Params{};
        Params.CallFunc_GetAbilitySystemComponentFromActorInfo_ReturnValue = CallFunc_GetAbilitySystemComponentFromActorInfo_ReturnValue;
        Params.CallFunc_GetValueAsBool_ReturnValue = CallFunc_GetValueAsBool_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_HasMatchingGameplayTag_self_CastInput = CallFunc_HasMatchingGameplayTag_self_CastInput;
        Params.CallFunc_HasMatchingGameplayTag_ReturnValue = CallFunc_HasMatchingGameplayTag_ReturnValue;
        Params.CallFunc_BooleanAND_ReturnValue = CallFunc_BooleanAND_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_AgileChug_C::OnRelease_A4A377E4438EB738168D85A868FE5121(float TimeHeld)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.OnRelease_A4A377E4438EB738168D85A868FE5121");
    
        UGA_AgileChug_C___OnRelease_A4A377E4438EB738168D85A868FE5121_Params Params{};
        Params.TimeHeld = TimeHeld;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_AgileChug_C::OnConsumeWhileSprintingTagRemoved(UAbilitySystemComponent* CallFunc_GetAbilitySystemComponentFromActorInfo_ReturnValue, TScriptInterface<IGameplayTagAssetInterface> CallFunc_HasMatchingGameplayTag_self_CastInput, bool CallFunc_HasMatchingGameplayTag_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.OnConsumeWhileSprintingTagRemoved");
    
        UGA_AgileChug_C___OnConsumeWhileSprintingTagRemoved_Params Params{};
        Params.CallFunc_GetAbilitySystemComponentFromActorInfo_ReturnValue = CallFunc_GetAbilitySystemComponentFromActorInfo_ReturnValue;
        Params.CallFunc_HasMatchingGameplayTag_self_CastInput = CallFunc_HasMatchingGameplayTag_self_CastInput;
        Params.CallFunc_HasMatchingGameplayTag_ReturnValue = CallFunc_HasMatchingGameplayTag_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_AgileChug_C::K2_OnEndAbility(bool bWasCancelled)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.K2_OnEndAbility");
    
        UGA_AgileChug_C___K2_OnEndAbility_Params Params{};
        Params.bWasCancelled = bWasCancelled;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UGA_AgileChug_C::K2_CanActivateAbility(FGameplayAbilityActorInfo ActorInfo, FGameplayAbilitySpecHandle Handle, FGameplayTagContainer& RelevantTags, AFortPlayerPawn* LocalFortPlayerPawn, AFortPlayerPawn* K2Node_DynamicCast_AsFort_Player_Pawn, bool K2Node_DynamicCast_bSuccess, float CallFunc_GetMaxShield_ReturnValue, bool CallFunc_Greater_DoubleDouble_ReturnValue, bool CallFunc_IsPawnFullHealthAndShield_HealthFull, bool CallFunc_IsPawnFullHealthAndShield_ShieldFull, bool CallFunc_BooleanAND_ReturnValue, double CallFunc_Greater_DoubleDouble_A_ImplicitCast)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.K2_CanActivateAbility");
    
        UGA_AgileChug_C___K2_CanActivateAbility_Params Params{};
        Params.ActorInfo = ActorInfo;
        Params.Handle = Handle;
        Params.RelevantTags = RelevantTags;
        Params.LocalFortPlayerPawn = LocalFortPlayerPawn;
        Params.K2Node_DynamicCast_AsFort_Player_Pawn = K2Node_DynamicCast_AsFort_Player_Pawn;
        Params.K2Node_DynamicCast_bSuccess = K2Node_DynamicCast_bSuccess;
        Params.CallFunc_GetMaxShield_ReturnValue = CallFunc_GetMaxShield_ReturnValue;
        Params.CallFunc_Greater_DoubleDouble_ReturnValue = CallFunc_Greater_DoubleDouble_ReturnValue;
        Params.CallFunc_IsPawnFullHealthAndShield_HealthFull = CallFunc_IsPawnFullHealthAndShield_HealthFull;
        Params.CallFunc_IsPawnFullHealthAndShield_ShieldFull = CallFunc_IsPawnFullHealthAndShield_ShieldFull;
        Params.CallFunc_BooleanAND_ReturnValue = CallFunc_BooleanAND_ReturnValue;
        Params.CallFunc_Greater_DoubleDouble_A_ImplicitCast = CallFunc_Greater_DoubleDouble_A_ImplicitCast;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        RelevantTags = Params.RelevantTags;
    
        return Params.ReturnValue;
    }

    void UGA_AgileChug_C::K2_ActivateAbility()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.K2_ActivateAbility");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_AgileChug_C::IsPawnFullHealthAndShield(AFortPlayerPawn* FortPlayerPawn, bool& HealthFull, bool& ShieldFull, bool ShieldFullOut, bool HealthFullOut, float CallFunc_GetShield_ReturnValue, float CallFunc_GetMaxShield_ReturnValue, float CallFunc_GetMaxHealth_ReturnValue, bool CallFunc_NearlyEqual_FloatFloat_ReturnValue, float CallFunc_GetHealth_ReturnValue, bool CallFunc_NearlyEqual_FloatFloat_ReturnValue_1, double CallFunc_NearlyEqual_FloatFloat_A_ImplicitCast, double CallFunc_NearlyEqual_FloatFloat_B_ImplicitCast, double CallFunc_NearlyEqual_FloatFloat_B_ImplicitCast_1, double CallFunc_NearlyEqual_FloatFloat_A_ImplicitCast_1)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.IsPawnFullHealthAndShield");
    
        UGA_AgileChug_C___IsPawnFullHealthAndShield_Params Params{};
        Params.FortPlayerPawn = FortPlayerPawn;
        Params.HealthFull = HealthFull;
        Params.ShieldFull = ShieldFull;
        Params.ShieldFullOut = ShieldFullOut;
        Params.HealthFullOut = HealthFullOut;
        Params.CallFunc_GetShield_ReturnValue = CallFunc_GetShield_ReturnValue;
        Params.CallFunc_GetMaxShield_ReturnValue = CallFunc_GetMaxShield_ReturnValue;
        Params.CallFunc_GetMaxHealth_ReturnValue = CallFunc_GetMaxHealth_ReturnValue;
        Params.CallFunc_NearlyEqual_FloatFloat_ReturnValue = CallFunc_NearlyEqual_FloatFloat_ReturnValue;
        Params.CallFunc_GetHealth_ReturnValue = CallFunc_GetHealth_ReturnValue;
        Params.CallFunc_NearlyEqual_FloatFloat_ReturnValue_1 = CallFunc_NearlyEqual_FloatFloat_ReturnValue_1;
        Params.CallFunc_NearlyEqual_FloatFloat_A_ImplicitCast = CallFunc_NearlyEqual_FloatFloat_A_ImplicitCast;
        Params.CallFunc_NearlyEqual_FloatFloat_B_ImplicitCast = CallFunc_NearlyEqual_FloatFloat_B_ImplicitCast;
        Params.CallFunc_NearlyEqual_FloatFloat_B_ImplicitCast_1 = CallFunc_NearlyEqual_FloatFloat_B_ImplicitCast_1;
        Params.CallFunc_NearlyEqual_FloatFloat_A_ImplicitCast_1 = CallFunc_NearlyEqual_FloatFloat_A_ImplicitCast_1;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        HealthFull = Params.HealthFull;
        ShieldFull = Params.ShieldFull;
    }

    void UGA_AgileChug_C::HandleRelease()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.HandleRelease");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    FTransform UGA_AgileChug_C::GetCustomAbilitySourceTransform(AFortPlayerPawn* CallFunc_GetAvatarAsFortPlayerPawn_ReturnValue, FVector CallFunc_K2_GetActorLocation_ReturnValue, FVector CallFunc_GetSocketLocation_ReturnValue, double CallFunc_BreakVector_X, double CallFunc_BreakVector_Y, double CallFunc_BreakVector_Z, double CallFunc_BreakVector_X_1, double CallFunc_BreakVector_Y_1, double CallFunc_BreakVector_Z_1, FVector CallFunc_MakeVector_ReturnValue, FTransform CallFunc_MakeTransform_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.GetCustomAbilitySourceTransform");
    
        UGA_AgileChug_C___GetCustomAbilitySourceTransform_Params Params{};
        Params.CallFunc_GetAvatarAsFortPlayerPawn_ReturnValue = CallFunc_GetAvatarAsFortPlayerPawn_ReturnValue;
        Params.CallFunc_K2_GetActorLocation_ReturnValue = CallFunc_K2_GetActorLocation_ReturnValue;
        Params.CallFunc_GetSocketLocation_ReturnValue = CallFunc_GetSocketLocation_ReturnValue;
        Params.CallFunc_BreakVector_X = CallFunc_BreakVector_X;
        Params.CallFunc_BreakVector_Y = CallFunc_BreakVector_Y;
        Params.CallFunc_BreakVector_Z = CallFunc_BreakVector_Z;
        Params.CallFunc_BreakVector_X_1 = CallFunc_BreakVector_X_1;
        Params.CallFunc_BreakVector_Y_1 = CallFunc_BreakVector_Y_1;
        Params.CallFunc_BreakVector_Z_1 = CallFunc_BreakVector_Z_1;
        Params.CallFunc_MakeVector_ReturnValue = CallFunc_MakeVector_ReturnValue;
        Params.CallFunc_MakeTransform_ReturnValue = CallFunc_MakeTransform_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UGA_AgileChug_C::ExecuteUbergraph_GA_AgileChug(int32 EntryPoint, AFortPlayerPawn* CallFunc_GetAvatarAsFortPlayerPawn_ReturnValue, FGameplayTag Temp_struct_Variable, FGameplayAbilityTargetDataHandle Temp_struct_Variable_1, float K2Node_CustomEvent_TimeHeld, InputReleaseDelegate K2Node_CreateDelegate_OutputDelegate, float Temp_real_Variable, UAbilityTask_WaitInputRelease* CallFunc_WaitInputRelease_ReturnValue, bool CallFunc_IsValid_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, float CallFunc_BP_Montage_GetSectionLength_ReturnValue, FGameplayCueParameters CallFunc_MakeGameplayCueParameters_ReturnValue, WaitGameplayTagDelegate K2Node_CreateDelegate_OutputDelegate_1, WaitGameplayTagDelegate K2Node_CreateDelegate_OutputDelegate_2, FGameplayAbilityTargetDataHandle K2Node_CustomEvent_TargetData_2, FGameplayTag K2Node_CustomEvent_ApplicationTag_2, UFortAbilityTask_PlayMontageWaitTarget* CallFunc_PlayMontageWaitTarget_ReturnValue, bool CallFunc_IsValid_ReturnValue_2, bool K2Node_Event_bWasCancelled, TimerDynamicDelegate K2Node_CreateDelegate_OutputDelegate_3, bool CallFunc_IsServer_ReturnValue, AFortWeapon* CallFunc_GetCurrentSourceWeapon_ReturnValue, OnLocalAmmoChanged K2Node_CreateDelegate_OutputDelegate_4, int32 K2Node_CustomEvent_LocalCount, int32 K2Node_CustomEvent_LocalRemaining, bool CallFunc_LessEqual_IntInt_ReturnValue, bool CallFunc_K2_CommitAbility_ReturnValue, bool Temp_bool_B_Execution_Happened_Variable, WaitTargetSelectionDelegate K2Node_CreateDelegate_OutputDelegate_5, bool CallFunc_K2_HasAuthority_ReturnValue, float CallFunc_GetValueAtLevel_ReturnValue, FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue, double CallFunc_CalculateHealthAndShield_HealAmountOut, double CallFunc_CalculateHealthAndShield_ShieldAmountOut, FGameplayEffectSpecHandle CallFunc_SetupGE_GameplayEffect, FGameplayAbilityTargetDataHandle K2Node_CustomEvent_TargetData, FGameplayTag K2Node_CustomEvent_ApplicationTag, FActiveGameplayEffectHandle CallFunc_K2_ApplyGameplayEffectSpecToOwner_ReturnValue, AFortPlayerPawn* CallFunc_GetAvatarAsFortPlayerPawn_ReturnValue_1, WaitTargetSelectionDelegate K2Node_CreateDelegate_OutputDelegate_6, bool CallFunc_IsPawnFullHealthAndShield_HealthFull, bool CallFunc_IsPawnFullHealthAndShield_ShieldFull, bool CallFunc_BooleanNAND_ReturnValue, FGameplayAbilityTargetDataHandle K2Node_CustomEvent_TargetData_1, FGameplayTag K2Node_CustomEvent_ApplicationTag_1, bool CallFunc_K2_HasAuthority_ReturnValue_1, bool Temp_bool_A_Execution_Happened_Variable, FGameplayCueParameters CallFunc_MakeGameplayCueParameters_ReturnValue_1, bool CallFunc_BooleanAND_ReturnValue, AActor* CallFunc_GetAvatarActorFromActorInfo_ReturnValue, bool CallFunc_GetValueAsBool_ReturnValue, bool CallFunc_GetValueAsBool_ReturnValue_1, bool CallFunc_GetValueAsBool_ReturnValue_2, FActiveGameplayEffectHandle CallFunc_BP_ApplyGameplayEffectToOwner_ReturnValue, AFortWeapon* CallFunc_GetCurrentSourceWeapon_ReturnValue_1, int32 CallFunc_GetLocalRemainingAmmo_ReturnValue, bool CallFunc_LessEqual_IntInt_ReturnValue_1, WaitTargetSelectionDelegate K2Node_CreateDelegate_OutputDelegate_7, AFortWeapon* CallFunc_GetCurrentSourceWeapon_ReturnValue_2, UFortItem* CallFunc_GetInventoryItem_ReturnValue, bool CallFunc_IsValid_ReturnValue_3, UAbilityTask_WaitGameplayTagAdded* CallFunc_WaitGameplayTagAdd_ReturnValue, UAbilityTask_WaitGameplayTagRemoved* CallFunc_WaitGameplayTagRemove_ReturnValue, bool CallFunc_IsValid_ReturnValue_4, bool CallFunc_IsValid_ReturnValue_5, bool CallFunc_GetValueAsBool_ReturnValue_3, UAbilitySystemComponent* CallFunc_GetAbilitySystemComponentFromActorInfo_ReturnValue, TScriptInterface<IGameplayTagAssetInterface> CallFunc_HasMatchingGameplayTag_self_CastInput, bool CallFunc_HasMatchingGameplayTag_ReturnValue, bool CallFunc_GetValueAsBool_ReturnValue_4, bool CallFunc_BooleanAND_ReturnValue_1, bool CallFunc_BooleanAND_ReturnValue_2)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.ExecuteUbergraph_GA_AgileChug");
    
        UGA_AgileChug_C___ExecuteUbergraph_GA_AgileChug_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.CallFunc_GetAvatarAsFortPlayerPawn_ReturnValue = CallFunc_GetAvatarAsFortPlayerPawn_ReturnValue;
        Params.Temp_struct_Variable = Temp_struct_Variable;
        Params.Temp_struct_Variable_1 = Temp_struct_Variable_1;
        Params.K2Node_CustomEvent_TimeHeld = K2Node_CustomEvent_TimeHeld;
        Params.K2Node_CreateDelegate_OutputDelegate = K2Node_CreateDelegate_OutputDelegate;
        Params.Temp_real_Variable = Temp_real_Variable;
        Params.CallFunc_WaitInputRelease_ReturnValue = CallFunc_WaitInputRelease_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
        Params.CallFunc_BP_Montage_GetSectionLength_ReturnValue = CallFunc_BP_Montage_GetSectionLength_ReturnValue;
        Params.CallFunc_MakeGameplayCueParameters_ReturnValue = CallFunc_MakeGameplayCueParameters_ReturnValue;
        Params.K2Node_CreateDelegate_OutputDelegate_1 = K2Node_CreateDelegate_OutputDelegate_1;
        Params.K2Node_CreateDelegate_OutputDelegate_2 = K2Node_CreateDelegate_OutputDelegate_2;
        Params.K2Node_CustomEvent_TargetData_2 = K2Node_CustomEvent_TargetData_2;
        Params.K2Node_CustomEvent_ApplicationTag_2 = K2Node_CustomEvent_ApplicationTag_2;
        Params.CallFunc_PlayMontageWaitTarget_ReturnValue = CallFunc_PlayMontageWaitTarget_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_2 = CallFunc_IsValid_ReturnValue_2;
        Params.K2Node_Event_bWasCancelled = K2Node_Event_bWasCancelled;
        Params.K2Node_CreateDelegate_OutputDelegate_3 = K2Node_CreateDelegate_OutputDelegate_3;
        Params.CallFunc_IsServer_ReturnValue = CallFunc_IsServer_ReturnValue;
        Params.CallFunc_GetCurrentSourceWeapon_ReturnValue = CallFunc_GetCurrentSourceWeapon_ReturnValue;
        Params.K2Node_CreateDelegate_OutputDelegate_4 = K2Node_CreateDelegate_OutputDelegate_4;
        Params.K2Node_CustomEvent_LocalCount = K2Node_CustomEvent_LocalCount;
        Params.K2Node_CustomEvent_LocalRemaining = K2Node_CustomEvent_LocalRemaining;
        Params.CallFunc_LessEqual_IntInt_ReturnValue = CallFunc_LessEqual_IntInt_ReturnValue;
        Params.CallFunc_K2_CommitAbility_ReturnValue = CallFunc_K2_CommitAbility_ReturnValue;
        Params.Temp_bool_B_Execution_Happened_Variable = Temp_bool_B_Execution_Happened_Variable;
        Params.K2Node_CreateDelegate_OutputDelegate_5 = K2Node_CreateDelegate_OutputDelegate_5;
        Params.CallFunc_K2_HasAuthority_ReturnValue = CallFunc_K2_HasAuthority_ReturnValue;
        Params.CallFunc_GetValueAtLevel_ReturnValue = CallFunc_GetValueAtLevel_ReturnValue;
        Params.CallFunc_K2_SetTimerDelegate_ReturnValue = CallFunc_K2_SetTimerDelegate_ReturnValue;
        Params.CallFunc_CalculateHealthAndShield_HealAmountOut = CallFunc_CalculateHealthAndShield_HealAmountOut;
        Params.CallFunc_CalculateHealthAndShield_ShieldAmountOut = CallFunc_CalculateHealthAndShield_ShieldAmountOut;
        Params.CallFunc_SetupGE_GameplayEffect = CallFunc_SetupGE_GameplayEffect;
        Params.K2Node_CustomEvent_TargetData = K2Node_CustomEvent_TargetData;
        Params.K2Node_CustomEvent_ApplicationTag = K2Node_CustomEvent_ApplicationTag;
        Params.CallFunc_K2_ApplyGameplayEffectSpecToOwner_ReturnValue = CallFunc_K2_ApplyGameplayEffectSpecToOwner_ReturnValue;
        Params.CallFunc_GetAvatarAsFortPlayerPawn_ReturnValue_1 = CallFunc_GetAvatarAsFortPlayerPawn_ReturnValue_1;
        Params.K2Node_CreateDelegate_OutputDelegate_6 = K2Node_CreateDelegate_OutputDelegate_6;
        Params.CallFunc_IsPawnFullHealthAndShield_HealthFull = CallFunc_IsPawnFullHealthAndShield_HealthFull;
        Params.CallFunc_IsPawnFullHealthAndShield_ShieldFull = CallFunc_IsPawnFullHealthAndShield_ShieldFull;
        Params.CallFunc_BooleanNAND_ReturnValue = CallFunc_BooleanNAND_ReturnValue;
        Params.K2Node_CustomEvent_TargetData_1 = K2Node_CustomEvent_TargetData_1;
        Params.K2Node_CustomEvent_ApplicationTag_1 = K2Node_CustomEvent_ApplicationTag_1;
        Params.CallFunc_K2_HasAuthority_ReturnValue_1 = CallFunc_K2_HasAuthority_ReturnValue_1;
        Params.Temp_bool_A_Execution_Happened_Variable = Temp_bool_A_Execution_Happened_Variable;
        Params.CallFunc_MakeGameplayCueParameters_ReturnValue_1 = CallFunc_MakeGameplayCueParameters_ReturnValue_1;
        Params.CallFunc_BooleanAND_ReturnValue = CallFunc_BooleanAND_ReturnValue;
        Params.CallFunc_GetAvatarActorFromActorInfo_ReturnValue = CallFunc_GetAvatarActorFromActorInfo_ReturnValue;
        Params.CallFunc_GetValueAsBool_ReturnValue = CallFunc_GetValueAsBool_ReturnValue;
        Params.CallFunc_GetValueAsBool_ReturnValue_1 = CallFunc_GetValueAsBool_ReturnValue_1;
        Params.CallFunc_GetValueAsBool_ReturnValue_2 = CallFunc_GetValueAsBool_ReturnValue_2;
        Params.CallFunc_BP_ApplyGameplayEffectToOwner_ReturnValue = CallFunc_BP_ApplyGameplayEffectToOwner_ReturnValue;
        Params.CallFunc_GetCurrentSourceWeapon_ReturnValue_1 = CallFunc_GetCurrentSourceWeapon_ReturnValue_1;
        Params.CallFunc_GetLocalRemainingAmmo_ReturnValue = CallFunc_GetLocalRemainingAmmo_ReturnValue;
        Params.CallFunc_LessEqual_IntInt_ReturnValue_1 = CallFunc_LessEqual_IntInt_ReturnValue_1;
        Params.K2Node_CreateDelegate_OutputDelegate_7 = K2Node_CreateDelegate_OutputDelegate_7;
        Params.CallFunc_GetCurrentSourceWeapon_ReturnValue_2 = CallFunc_GetCurrentSourceWeapon_ReturnValue_2;
        Params.CallFunc_GetInventoryItem_ReturnValue = CallFunc_GetInventoryItem_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_3 = CallFunc_IsValid_ReturnValue_3;
        Params.CallFunc_WaitGameplayTagAdd_ReturnValue = CallFunc_WaitGameplayTagAdd_ReturnValue;
        Params.CallFunc_WaitGameplayTagRemove_ReturnValue = CallFunc_WaitGameplayTagRemove_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_4 = CallFunc_IsValid_ReturnValue_4;
        Params.CallFunc_IsValid_ReturnValue_5 = CallFunc_IsValid_ReturnValue_5;
        Params.CallFunc_GetValueAsBool_ReturnValue_3 = CallFunc_GetValueAsBool_ReturnValue_3;
        Params.CallFunc_GetAbilitySystemComponentFromActorInfo_ReturnValue = CallFunc_GetAbilitySystemComponentFromActorInfo_ReturnValue;
        Params.CallFunc_HasMatchingGameplayTag_self_CastInput = CallFunc_HasMatchingGameplayTag_self_CastInput;
        Params.CallFunc_HasMatchingGameplayTag_ReturnValue = CallFunc_HasMatchingGameplayTag_ReturnValue;
        Params.CallFunc_GetValueAsBool_ReturnValue_4 = CallFunc_GetValueAsBool_ReturnValue_4;
        Params.CallFunc_BooleanAND_ReturnValue_1 = CallFunc_BooleanAND_ReturnValue_1;
        Params.CallFunc_BooleanAND_ReturnValue_2 = CallFunc_BooleanAND_ReturnValue_2;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_AgileChug_C::EnableRelease()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.EnableRelease");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_AgileChug_C::Completed_B4B9CF6248850F50A4FAF9BA8C018C08(FGameplayAbilityTargetDataHandle& TargetData, FGameplayTag ApplicationTag)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.Completed_B4B9CF6248850F50A4FAF9BA8C018C08");
    
        UGA_AgileChug_C___Completed_B4B9CF6248850F50A4FAF9BA8C018C08_Params Params{};
        Params.TargetData = TargetData;
        Params.ApplicationTag = ApplicationTag;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        TargetData = Params.TargetData;
    }

    void UGA_AgileChug_C::CheckForInfiniteAmmo(bool bInfiniteAmmo, bool CallFunc_Not_PreBool_ReturnValue, double CallFunc_Conv_BoolToDouble_ReturnValue, AFortWeapon* CallFunc_GetCurrentSourceWeapon_ReturnValue, bool CallFunc_IsValid_ReturnValue, UFortItem* CallFunc_GetInventoryItem_ReturnValue, bool CallFunc_HasInfiniteAmmo_ReturnValue, bool CallFunc_InventoryOwnerHasInfiniteAmmo_ReturnValue, bool CallFunc_BooleanOR_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.CheckForInfiniteAmmo");
    
        UGA_AgileChug_C___CheckForInfiniteAmmo_Params Params{};
        Params.bInfiniteAmmo = bInfiniteAmmo;
        Params.CallFunc_Not_PreBool_ReturnValue = CallFunc_Not_PreBool_ReturnValue;
        Params.CallFunc_Conv_BoolToDouble_ReturnValue = CallFunc_Conv_BoolToDouble_ReturnValue;
        Params.CallFunc_GetCurrentSourceWeapon_ReturnValue = CallFunc_GetCurrentSourceWeapon_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_GetInventoryItem_ReturnValue = CallFunc_GetInventoryItem_ReturnValue;
        Params.CallFunc_HasInfiniteAmmo_ReturnValue = CallFunc_HasInfiniteAmmo_ReturnValue;
        Params.CallFunc_InventoryOwnerHasInfiniteAmmo_ReturnValue = CallFunc_InventoryOwnerHasInfiniteAmmo_ReturnValue;
        Params.CallFunc_BooleanOR_ReturnValue = CallFunc_BooleanOR_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_AgileChug_C::CheckConsumeWhileSprintingAndForceHolster(bool CallFunc_GetValueAsBool_ReturnValue, bool CallFunc_GetValueAsBool_ReturnValue_1, AFortPlayerPawn* CallFunc_GetAvatarAsFortPlayerPawn_ReturnValue, UAbilitySystemComponent* CallFunc_GetAbilitySystemComponent_ReturnValue, TScriptInterface<IGameplayTagAssetInterface> CallFunc_HasMatchingGameplayTag_self_CastInput, bool CallFunc_HasMatchingGameplayTag_ReturnValue, bool CallFunc_BooleanAND_ReturnValue, bool CallFunc_BooleanAND_ReturnValue_1, bool CallFunc_BooleanAND_ReturnValue_2)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.CheckConsumeWhileSprintingAndForceHolster");
    
        UGA_AgileChug_C___CheckConsumeWhileSprintingAndForceHolster_Params Params{};
        Params.CallFunc_GetValueAsBool_ReturnValue = CallFunc_GetValueAsBool_ReturnValue;
        Params.CallFunc_GetValueAsBool_ReturnValue_1 = CallFunc_GetValueAsBool_ReturnValue_1;
        Params.CallFunc_GetAvatarAsFortPlayerPawn_ReturnValue = CallFunc_GetAvatarAsFortPlayerPawn_ReturnValue;
        Params.CallFunc_GetAbilitySystemComponent_ReturnValue = CallFunc_GetAbilitySystemComponent_ReturnValue;
        Params.CallFunc_HasMatchingGameplayTag_self_CastInput = CallFunc_HasMatchingGameplayTag_self_CastInput;
        Params.CallFunc_HasMatchingGameplayTag_ReturnValue = CallFunc_HasMatchingGameplayTag_ReturnValue;
        Params.CallFunc_BooleanAND_ReturnValue = CallFunc_BooleanAND_ReturnValue;
        Params.CallFunc_BooleanAND_ReturnValue_1 = CallFunc_BooleanAND_ReturnValue_1;
        Params.CallFunc_BooleanAND_ReturnValue_2 = CallFunc_BooleanAND_ReturnValue_2;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_AgileChug_C::Cancelled_B4B9CF6248850F50A4FAF9BA8C018C08(FGameplayAbilityTargetDataHandle& TargetData, FGameplayTag ApplicationTag)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.Cancelled_B4B9CF6248850F50A4FAF9BA8C018C08");
    
        UGA_AgileChug_C___Cancelled_B4B9CF6248850F50A4FAF9BA8C018C08_Params Params{};
        Params.TargetData = TargetData;
        Params.ApplicationTag = ApplicationTag;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        TargetData = Params.TargetData;
    }

    bool UGA_AgileChug_C::CanApplyHolster(FName& HolsterId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.CanApplyHolster");
    
        UGA_AgileChug_C___CanApplyHolster_Params Params{};
        Params.HolsterId = HolsterId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        HolsterId = Params.HolsterId;
    
        return Params.ReturnValue;
    }

    void UGA_AgileChug_C::CalculateHealthAndShield(double& HealAmountOut, double& ShieldAmountOut, bool ApplyOverHeal_, double ToFullShieldAmount, double ShieldAmount, AFortPlayerPawn* FortPlayerPawn, float HealAmount, double OverHeal, double ToFullHealthAmount, float CallFunc_GetHealth_ReturnValue, float CallFunc_GetMaxHealth_ReturnValue, bool CallFunc_GreaterEqual_DoubleDouble_ReturnValue, bool CallFunc_Less_DoubleDouble_ReturnValue, bool CallFunc_Greater_DoubleDouble_ReturnValue, bool CallFunc_BooleanAND_ReturnValue, float CallFunc_GetShield_ReturnValue, float CallFunc_GetMaxShield_ReturnValue, double CallFunc_Subtract_DoubleDouble_ReturnValue, float CallFunc_GetValueAtLevel_ReturnValue, double CallFunc_SelectFloat_ReturnValue, float CallFunc_GetHealth_ReturnValue_1, float CallFunc_GetMaxHealth_ReturnValue_1, double CallFunc_Subtract_DoubleDouble_ReturnValue_1, float CallFunc_GetValueAtLevel_ReturnValue_1, double CallFunc_Subtract_DoubleDouble_ReturnValue_2, bool CallFunc_GetValueAsBool_ReturnValue, double CallFunc_FClamp_ReturnValue, double CallFunc_FMin_ReturnValue, bool CallFunc_GetValueAsBool_ReturnValue_1, float CallFunc_GetShield_ReturnValue_1, float CallFunc_GetValueAtLevel_ReturnValue_2, float CallFunc_GetMaxShield_ReturnValue_1, double CallFunc_Add_DoubleDouble_ReturnValue, double CallFunc_Subtract_DoubleDouble_ReturnValue_3, double CallFunc_SelectFloat_ReturnValue_1, double CallFunc_FClamp_ReturnValue_1, float CallFunc_GetHealth_ReturnValue_2, float CallFunc_GetMaxHealth_ReturnValue_2, double CallFunc_Subtract_DoubleDouble_ReturnValue_4, double CallFunc_FClamp_ReturnValue_2, float CallFunc_GetValueAtLevel_ReturnValue_3, EFortGetPlayerPawnExecutions CallFunc_GetAvatarAsValidFortPlayerPawn_OutExec, AFortPlayerPawn* CallFunc_GetAvatarAsValidFortPlayerPawn_OutFortPlayerPawn, double CallFunc_Subtract_DoubleDouble_ReturnValue_5, double CallFunc_FClamp_ReturnValue_3, bool K2Node_SwitchEnum_CmpSuccess, double CallFunc_FMin_ReturnValue_1, double K2Node_FunctionResult_HealAmountOut_ImplicitCast, double CallFunc_GreaterEqual_DoubleDouble_A_ImplicitCast, double CallFunc_GreaterEqual_DoubleDouble_B_ImplicitCast, double CallFunc_Subtract_DoubleDouble_B_ImplicitCast, double CallFunc_Subtract_DoubleDouble_A_ImplicitCast, double CallFunc_SelectFloat_B_ImplicitCast, double CallFunc_Subtract_DoubleDouble_B_ImplicitCast_1, double CallFunc_Subtract_DoubleDouble_A_ImplicitCast_1, double CallFunc_FMin_A_ImplicitCast, double CallFunc_FClamp_Max_ImplicitCast, double CallFunc_Subtract_DoubleDouble_A_ImplicitCast_2, float K2Node_VariableSet_HealAmount_ImplicitCast, double CallFunc_Subtract_DoubleDouble_B_ImplicitCast_2, double CallFunc_SelectFloat_B_ImplicitCast_1, double CallFunc_Add_DoubleDouble_B_ImplicitCast, double CallFunc_Subtract_DoubleDouble_A_ImplicitCast_3, double CallFunc_Subtract_DoubleDouble_B_ImplicitCast_3, double CallFunc_Subtract_DoubleDouble_A_ImplicitCast_4, double CallFunc_FMin_A_ImplicitCast_1, double CallFunc_FClamp_Max_ImplicitCast_1, double CallFunc_Subtract_DoubleDouble_A_ImplicitCast_5, float K2Node_VariableSet_HealAmount_ImplicitCast_1)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.CalculateHealthAndShield");
    
        UGA_AgileChug_C___CalculateHealthAndShield_Params Params{};
        Params.HealAmountOut = HealAmountOut;
        Params.ShieldAmountOut = ShieldAmountOut;
        Params.ApplyOverHeal_ = ApplyOverHeal_;
        Params.ToFullShieldAmount = ToFullShieldAmount;
        Params.ShieldAmount = ShieldAmount;
        Params.FortPlayerPawn = FortPlayerPawn;
        Params.HealAmount = HealAmount;
        Params.OverHeal = OverHeal;
        Params.ToFullHealthAmount = ToFullHealthAmount;
        Params.CallFunc_GetHealth_ReturnValue = CallFunc_GetHealth_ReturnValue;
        Params.CallFunc_GetMaxHealth_ReturnValue = CallFunc_GetMaxHealth_ReturnValue;
        Params.CallFunc_GreaterEqual_DoubleDouble_ReturnValue = CallFunc_GreaterEqual_DoubleDouble_ReturnValue;
        Params.CallFunc_Less_DoubleDouble_ReturnValue = CallFunc_Less_DoubleDouble_ReturnValue;
        Params.CallFunc_Greater_DoubleDouble_ReturnValue = CallFunc_Greater_DoubleDouble_ReturnValue;
        Params.CallFunc_BooleanAND_ReturnValue = CallFunc_BooleanAND_ReturnValue;
        Params.CallFunc_GetShield_ReturnValue = CallFunc_GetShield_ReturnValue;
        Params.CallFunc_GetMaxShield_ReturnValue = CallFunc_GetMaxShield_ReturnValue;
        Params.CallFunc_Subtract_DoubleDouble_ReturnValue = CallFunc_Subtract_DoubleDouble_ReturnValue;
        Params.CallFunc_GetValueAtLevel_ReturnValue = CallFunc_GetValueAtLevel_ReturnValue;
        Params.CallFunc_SelectFloat_ReturnValue = CallFunc_SelectFloat_ReturnValue;
        Params.CallFunc_GetHealth_ReturnValue_1 = CallFunc_GetHealth_ReturnValue_1;
        Params.CallFunc_GetMaxHealth_ReturnValue_1 = CallFunc_GetMaxHealth_ReturnValue_1;
        Params.CallFunc_Subtract_DoubleDouble_ReturnValue_1 = CallFunc_Subtract_DoubleDouble_ReturnValue_1;
        Params.CallFunc_GetValueAtLevel_ReturnValue_1 = CallFunc_GetValueAtLevel_ReturnValue_1;
        Params.CallFunc_Subtract_DoubleDouble_ReturnValue_2 = CallFunc_Subtract_DoubleDouble_ReturnValue_2;
        Params.CallFunc_GetValueAsBool_ReturnValue = CallFunc_GetValueAsBool_ReturnValue;
        Params.CallFunc_FClamp_ReturnValue = CallFunc_FClamp_ReturnValue;
        Params.CallFunc_FMin_ReturnValue = CallFunc_FMin_ReturnValue;
        Params.CallFunc_GetValueAsBool_ReturnValue_1 = CallFunc_GetValueAsBool_ReturnValue_1;
        Params.CallFunc_GetShield_ReturnValue_1 = CallFunc_GetShield_ReturnValue_1;
        Params.CallFunc_GetValueAtLevel_ReturnValue_2 = CallFunc_GetValueAtLevel_ReturnValue_2;
        Params.CallFunc_GetMaxShield_ReturnValue_1 = CallFunc_GetMaxShield_ReturnValue_1;
        Params.CallFunc_Add_DoubleDouble_ReturnValue = CallFunc_Add_DoubleDouble_ReturnValue;
        Params.CallFunc_Subtract_DoubleDouble_ReturnValue_3 = CallFunc_Subtract_DoubleDouble_ReturnValue_3;
        Params.CallFunc_SelectFloat_ReturnValue_1 = CallFunc_SelectFloat_ReturnValue_1;
        Params.CallFunc_FClamp_ReturnValue_1 = CallFunc_FClamp_ReturnValue_1;
        Params.CallFunc_GetHealth_ReturnValue_2 = CallFunc_GetHealth_ReturnValue_2;
        Params.CallFunc_GetMaxHealth_ReturnValue_2 = CallFunc_GetMaxHealth_ReturnValue_2;
        Params.CallFunc_Subtract_DoubleDouble_ReturnValue_4 = CallFunc_Subtract_DoubleDouble_ReturnValue_4;
        Params.CallFunc_FClamp_ReturnValue_2 = CallFunc_FClamp_ReturnValue_2;
        Params.CallFunc_GetValueAtLevel_ReturnValue_3 = CallFunc_GetValueAtLevel_ReturnValue_3;
        Params.CallFunc_GetAvatarAsValidFortPlayerPawn_OutExec = CallFunc_GetAvatarAsValidFortPlayerPawn_OutExec;
        Params.CallFunc_GetAvatarAsValidFortPlayerPawn_OutFortPlayerPawn = CallFunc_GetAvatarAsValidFortPlayerPawn_OutFortPlayerPawn;
        Params.CallFunc_Subtract_DoubleDouble_ReturnValue_5 = CallFunc_Subtract_DoubleDouble_ReturnValue_5;
        Params.CallFunc_FClamp_ReturnValue_3 = CallFunc_FClamp_ReturnValue_3;
        Params.K2Node_SwitchEnum_CmpSuccess = K2Node_SwitchEnum_CmpSuccess;
        Params.CallFunc_FMin_ReturnValue_1 = CallFunc_FMin_ReturnValue_1;
        Params.K2Node_FunctionResult_HealAmountOut_ImplicitCast = K2Node_FunctionResult_HealAmountOut_ImplicitCast;
        Params.CallFunc_GreaterEqual_DoubleDouble_A_ImplicitCast = CallFunc_GreaterEqual_DoubleDouble_A_ImplicitCast;
        Params.CallFunc_GreaterEqual_DoubleDouble_B_ImplicitCast = CallFunc_GreaterEqual_DoubleDouble_B_ImplicitCast;
        Params.CallFunc_Subtract_DoubleDouble_B_ImplicitCast = CallFunc_Subtract_DoubleDouble_B_ImplicitCast;
        Params.CallFunc_Subtract_DoubleDouble_A_ImplicitCast = CallFunc_Subtract_DoubleDouble_A_ImplicitCast;
        Params.CallFunc_SelectFloat_B_ImplicitCast = CallFunc_SelectFloat_B_ImplicitCast;
        Params.CallFunc_Subtract_DoubleDouble_B_ImplicitCast_1 = CallFunc_Subtract_DoubleDouble_B_ImplicitCast_1;
        Params.CallFunc_Subtract_DoubleDouble_A_ImplicitCast_1 = CallFunc_Subtract_DoubleDouble_A_ImplicitCast_1;
        Params.CallFunc_FMin_A_ImplicitCast = CallFunc_FMin_A_ImplicitCast;
        Params.CallFunc_FClamp_Max_ImplicitCast = CallFunc_FClamp_Max_ImplicitCast;
        Params.CallFunc_Subtract_DoubleDouble_A_ImplicitCast_2 = CallFunc_Subtract_DoubleDouble_A_ImplicitCast_2;
        Params.K2Node_VariableSet_HealAmount_ImplicitCast = K2Node_VariableSet_HealAmount_ImplicitCast;
        Params.CallFunc_Subtract_DoubleDouble_B_ImplicitCast_2 = CallFunc_Subtract_DoubleDouble_B_ImplicitCast_2;
        Params.CallFunc_SelectFloat_B_ImplicitCast_1 = CallFunc_SelectFloat_B_ImplicitCast_1;
        Params.CallFunc_Add_DoubleDouble_B_ImplicitCast = CallFunc_Add_DoubleDouble_B_ImplicitCast;
        Params.CallFunc_Subtract_DoubleDouble_A_ImplicitCast_3 = CallFunc_Subtract_DoubleDouble_A_ImplicitCast_3;
        Params.CallFunc_Subtract_DoubleDouble_B_ImplicitCast_3 = CallFunc_Subtract_DoubleDouble_B_ImplicitCast_3;
        Params.CallFunc_Subtract_DoubleDouble_A_ImplicitCast_4 = CallFunc_Subtract_DoubleDouble_A_ImplicitCast_4;
        Params.CallFunc_FMin_A_ImplicitCast_1 = CallFunc_FMin_A_ImplicitCast_1;
        Params.CallFunc_FClamp_Max_ImplicitCast_1 = CallFunc_FClamp_Max_ImplicitCast_1;
        Params.CallFunc_Subtract_DoubleDouble_A_ImplicitCast_5 = CallFunc_Subtract_DoubleDouble_A_ImplicitCast_5;
        Params.K2Node_VariableSet_HealAmount_ImplicitCast_1 = K2Node_VariableSet_HealAmount_ImplicitCast_1;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        HealAmountOut = Params.HealAmountOut;
        ShieldAmountOut = Params.ShieldAmountOut;
    }

    void UGA_AgileChug_C::ApplyHealthAndShieldVisuals(double HealAmount, double ShieldAmount, bool CallFunc_Greater_DoubleDouble_ReturnValue, bool CallFunc_IsGameplayTagValid_ReturnValue, bool CallFunc_BooleanAND_ReturnValue, bool CallFunc_IsGameplayTagValid_ReturnValue_1, bool CallFunc_Greater_DoubleDouble_ReturnValue_1, bool CallFunc_BooleanAND_ReturnValue_1)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.ApplyHealthAndShieldVisuals");
    
        UGA_AgileChug_C___ApplyHealthAndShieldVisuals_Params Params{};
        Params.HealAmount = HealAmount;
        Params.ShieldAmount = ShieldAmount;
        Params.CallFunc_Greater_DoubleDouble_ReturnValue = CallFunc_Greater_DoubleDouble_ReturnValue;
        Params.CallFunc_IsGameplayTagValid_ReturnValue = CallFunc_IsGameplayTagValid_ReturnValue;
        Params.CallFunc_BooleanAND_ReturnValue = CallFunc_BooleanAND_ReturnValue;
        Params.CallFunc_IsGameplayTagValid_ReturnValue_1 = CallFunc_IsGameplayTagValid_ReturnValue_1;
        Params.CallFunc_Greater_DoubleDouble_ReturnValue_1 = CallFunc_Greater_DoubleDouble_ReturnValue_1;
        Params.CallFunc_BooleanAND_ReturnValue_1 = CallFunc_BooleanAND_ReturnValue_1;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_AgileChug_C::ApplyEffectIncremental()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.ApplyEffectIncremental");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_AgileChug_C::AdjustValuesForEffectiveHealthFirst(bool CallFunc_GetValueAsBool_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.AdjustValuesForEffectiveHealthFirst");
    
        UGA_AgileChug_C___AdjustValuesForEffectiveHealthFirst_Params Params{};
        Params.CallFunc_GetValueAsBool_ReturnValue = CallFunc_GetValueAsBool_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_AgileChug_C::Added_8844FBDC4F2DA152381693A4CA77C984()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.Added_8844FBDC4F2DA152381693A4CA77C984");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_AgileChug_C::RemoveItem(AFortPawn* CallFunc_GetActivatingPawn_ReturnValue, AFortWeapon* CallFunc_GetCurrentSourceWeapon_ReturnValue, AController* CallFunc_GetController_ReturnValue, UFortItem* CallFunc_GetInventoryItem_ReturnValue, int32 CallFunc_K2_RemoveFortItemFromPlayer_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.RemoveItem");
    
        UGA_AgileChug_C___RemoveItem_Params Params{};
        Params.CallFunc_GetActivatingPawn_ReturnValue = CallFunc_GetActivatingPawn_ReturnValue;
        Params.CallFunc_GetCurrentSourceWeapon_ReturnValue = CallFunc_GetCurrentSourceWeapon_ReturnValue;
        Params.CallFunc_GetController_ReturnValue = CallFunc_GetController_ReturnValue;
        Params.CallFunc_GetInventoryItem_ReturnValue = CallFunc_GetInventoryItem_ReturnValue;
        Params.CallFunc_K2_RemoveFortItemFromPlayer_ReturnValue = CallFunc_K2_RemoveFortItemFromPlayer_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_AgileChug_C::Removed_A828D91444465A042C17ABA8436BC145()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.Removed_A828D91444465A042C17ABA8436BC145");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_AgileChug_C::Triggered_B4B9CF6248850F50A4FAF9BA8C018C08(FGameplayAbilityTargetDataHandle& TargetData, FGameplayTag ApplicationTag)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.Triggered_B4B9CF6248850F50A4FAF9BA8C018C08");
    
        UGA_AgileChug_C___Triggered_B4B9CF6248850F50A4FAF9BA8C018C08_Params Params{};
        Params.TargetData = TargetData;
        Params.ApplicationTag = ApplicationTag;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        TargetData = Params.TargetData;
    }

    void UGA_AgileChug_C::ToggleMeshVisibility(bool NewHidden, AFortWeapon* CallFunc_GetCurrentSourceWeapon_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_AgileChug.GA_AgileChug_C.ToggleMeshVisibility");
    
        UGA_AgileChug_C___ToggleMeshVisibility_Params Params{};
        Params.NewHidden = NewHidden;
        Params.CallFunc_GetCurrentSourceWeapon_ReturnValue = CallFunc_GetCurrentSourceWeapon_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

