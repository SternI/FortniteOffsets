/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:39
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AgileChugJugGameplay/Gameplay/Action_DropChugJug
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000029 (0x000001)
    class UAction_DropChugJug_C : public UDropItemCustomAction
    {
    public:
        bool    NewVar; // 0x000028 (0x000001) [Default: false]
    
    public: // Functions
        void    HandleItemSpawn(AFortPawn* AvatarPawn, FDropItemCustomBehaviorParameters& Params, bool& bOutUseDefaultSpawn, UItemDefinitionBase* CallFunc_BreakFortItemEntry_ItemDefinition, FGuid CallFunc_BreakFortItemEntry_ItemGuid, int32 CallFunc_BreakFortItemEntry_Count, int32 CallFunc_BreakFortItemEntry_Level, int32 CallFunc_BreakFortItemEntry_LoadedAmmo, int32 CallFunc_BreakFortItemEntry_PhantomReserveAmmo, bool CallFunc_Greater_IntInt_ReturnValue); // 0x000545D2 [Event | Public | HasOutParms | BlueprintCallable | BlueprintEvent | Const]
    };
}

