/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:27
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AgileChugJugGameplay/Gameplay/GA_ChugJug_ConsumablePass
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000D48 (0x000008)
    class alignas(0x8) UGA_ChugJug_ConsumablePass_C : public UGA_Athena_Consumable_Pass_Parent_C
    {
    public:
        FPointerToUberGraphFrame    UberGraphFrame; // 0x000D40 (0x000008)
    
    public: // Functions
        void    K2_OnEndAbility(bool bWasCancelled); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    K2_ActivateAbility(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    ExecuteUbergraph_GA_ChugJug_ConsumablePass(int32 EntryPoint, AActor* CallFunc_GetAvatarActorFromActorInfo_ReturnValue, UAbilityAsync_WaitGameplayEvent* CallFunc_WaitGameplayEventToActor_ReturnValue, EventReceivedDelegate K2Node_CreateDelegate_OutputDelegate, bool CallFunc_IsValid_ReturnValue, FGameplayEventData K2Node_CustomEvent_Payload, FGameplayEventData Temp_struct_Variable, bool CallFunc_IsDedicatedServer_ReturnValue, bool K2Node_Event_bWasCancelled, bool CallFunc_IsValid_ReturnValue_1, AB_Prj_Athena_Consumable_Thrown_ChugJug_C* K2Node_DynamicCast_AsB_Prj_Athena_Consumable_Thrown_Chug_Jug, bool K2Node_DynamicCast_bSuccess, AFortWeapon* CallFunc_GetCurrentSourceWeapon_ReturnValue, AFortPawn* CallFunc_GetActivatingPawn_ReturnValue, UFortItem* CallFunc_GetInventoryItem_ReturnValue, AFortPlayerController* CallFunc_GetFortPlayerControllerFromActor_ReturnValue, int32 CallFunc_K2_RemoveFortItemFromPlayer_ReturnValue); // 0x000545D2 [Final | UbergraphFunction | HasDefaults]
        void    EventReceived_D8EEA86340BD268FB7E25B94B86D4511(FGameplayEventData Payload); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
    };
}

