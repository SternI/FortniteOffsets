/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:27
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AgileChugJugGameplay/Gameplay/GA_ChugJug_ConsumablePass_Functions
 * ============================================================
 */

#include "GA_ChugJug_ConsumablePass_Functions.hpp"

namespace UE
{

    void UGA_ChugJug_ConsumablePass_C::K2_OnEndAbility(bool bWasCancelled)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_ChugJug_ConsumablePass.GA_ChugJug_ConsumablePass_C.K2_OnEndAbility");
    
        UGA_ChugJug_ConsumablePass_C___K2_OnEndAbility_Params Params{};
        Params.bWasCancelled = bWasCancelled;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_ChugJug_ConsumablePass_C::K2_ActivateAbility()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_ChugJug_ConsumablePass.GA_ChugJug_ConsumablePass_C.K2_ActivateAbility");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_ChugJug_ConsumablePass_C::ExecuteUbergraph_GA_ChugJug_ConsumablePass(int32 EntryPoint, AActor* CallFunc_GetAvatarActorFromActorInfo_ReturnValue, UAbilityAsync_WaitGameplayEvent* CallFunc_WaitGameplayEventToActor_ReturnValue, EventReceivedDelegate K2Node_CreateDelegate_OutputDelegate, bool CallFunc_IsValid_ReturnValue, FGameplayEventData K2Node_CustomEvent_Payload, FGameplayEventData Temp_struct_Variable, bool CallFunc_IsDedicatedServer_ReturnValue, bool K2Node_Event_bWasCancelled, bool CallFunc_IsValid_ReturnValue_1, AB_Prj_Athena_Consumable_Thrown_ChugJug_C* K2Node_DynamicCast_AsB_Prj_Athena_Consumable_Thrown_Chug_Jug, bool K2Node_DynamicCast_bSuccess, AFortWeapon* CallFunc_GetCurrentSourceWeapon_ReturnValue, AFortPawn* CallFunc_GetActivatingPawn_ReturnValue, UFortItem* CallFunc_GetInventoryItem_ReturnValue, AFortPlayerController* CallFunc_GetFortPlayerControllerFromActor_ReturnValue, int32 CallFunc_K2_RemoveFortItemFromPlayer_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_ChugJug_ConsumablePass.GA_ChugJug_ConsumablePass_C.ExecuteUbergraph_GA_ChugJug_ConsumablePass");
    
        UGA_ChugJug_ConsumablePass_C___ExecuteUbergraph_GA_ChugJug_ConsumablePass_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.CallFunc_GetAvatarActorFromActorInfo_ReturnValue = CallFunc_GetAvatarActorFromActorInfo_ReturnValue;
        Params.CallFunc_WaitGameplayEventToActor_ReturnValue = CallFunc_WaitGameplayEventToActor_ReturnValue;
        Params.K2Node_CreateDelegate_OutputDelegate = K2Node_CreateDelegate_OutputDelegate;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.K2Node_CustomEvent_Payload = K2Node_CustomEvent_Payload;
        Params.Temp_struct_Variable = Temp_struct_Variable;
        Params.CallFunc_IsDedicatedServer_ReturnValue = CallFunc_IsDedicatedServer_ReturnValue;
        Params.K2Node_Event_bWasCancelled = K2Node_Event_bWasCancelled;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
        Params.K2Node_DynamicCast_AsB_Prj_Athena_Consumable_Thrown_Chug_Jug = K2Node_DynamicCast_AsB_Prj_Athena_Consumable_Thrown_Chug_Jug;
        Params.K2Node_DynamicCast_bSuccess = K2Node_DynamicCast_bSuccess;
        Params.CallFunc_GetCurrentSourceWeapon_ReturnValue = CallFunc_GetCurrentSourceWeapon_ReturnValue;
        Params.CallFunc_GetActivatingPawn_ReturnValue = CallFunc_GetActivatingPawn_ReturnValue;
        Params.CallFunc_GetInventoryItem_ReturnValue = CallFunc_GetInventoryItem_ReturnValue;
        Params.CallFunc_GetFortPlayerControllerFromActor_ReturnValue = CallFunc_GetFortPlayerControllerFromActor_ReturnValue;
        Params.CallFunc_K2_RemoveFortItemFromPlayer_ReturnValue = CallFunc_K2_RemoveFortItemFromPlayer_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_ChugJug_ConsumablePass_C::EventReceived_D8EEA86340BD268FB7E25B94B86D4511(FGameplayEventData Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_ChugJug_ConsumablePass.GA_ChugJug_ConsumablePass_C.EventReceived_D8EEA86340BD268FB7E25B94B86D4511");
    
        UGA_ChugJug_ConsumablePass_C___EventReceived_D8EEA86340BD268FB7E25B94B86D4511_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

