/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BikeKidRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0002E8 (0x000008)
    class AFortAthenaMutator_BikeKid : public AFortAthenaMutator
    {
    public:
        bool    bIsControllingBikeKid;          // 0x0002E0 (0x000001) [Default: false]
        uint8   UnknownData_0002E1[0x000007];   // 0x0002E1 (0x000007)
    
    public: // Functions
        void    OnViewTargetChanged(AFortPlayerController* PlayerController, AActor* OldViewTarget, AActor* NewViewTarget); // 0x080E9790 [Final | Native | Private]
    };
    // Size: 0x0007A0 (0x000170)
    class alignas(0x8) AFortBikeKid : public ACharacter
    {
    public:
        void**                                              VTable_000630;                      // 0x000630 (0x000008) VTable [3 slots] -> 0x1477CE30
        void**                                              VTable_000638;                      // 0x000638 (0x000008) VTable [15 slots] -> 0x1477CE50
        void**                                              VTable_000640;                      // 0x000640 (0x000008) VTable [11 slots] -> 0x1477CE70
        void**                                              VTable_000648;                      // 0x000648 (0x000008) VTable [7 slots] -> 0x1477CED0
        void**                                              VTable_000650;                      // 0x000650 (0x000008) VTable [11 slots] -> 0x1477CF10
        uint8                                               UnknownData_000658[0x000008];       // 0x000658 (0x000008)
        void**                                              VTable_000660;                      // 0x000660 (0x000008) VTable [7 slots] -> 0x1477CF70
        uint8                                               UnknownData_000668[0x000010];       // 0x000668 (0x000010)
        UNiagaraComponent*                                  NSBikeKidIdle_Native;               // 0x000678 (0x000008) [Default: nullptr]
        UClass*                                             TeamMateIndicatorMarkerWidgetClass; // 0x000680 (0x000008) [Default: nullptr]
        UAudioComponent*                                    BikeKidMotorLoopComponent;          // 0x000688 (0x000008) [Default: nullptr]
        UAudioComponent*                                    BikeKidThrustSoundComponent;        // 0x000690 (0x000008) [Default: nullptr]
        FGameplayTagContainer                               DefaultTags;                        // 0x000698 (0x000020)
        FGameplayTag                                        ExplosionCueTag;                    // 0x0006B8 (0x000004)
        bool                                                bExploded;                          // 0x0006BC (0x000001) [Default: false]
        uint8                                               UnknownData_0006BD[0x00000B];       // 0x0006BD (0x00000B)
        UFortAbilitySystemComponent*                        AbilitySystemComponent;             // 0x0006C8 (0x000008) [Default: 0x7FE838AC12A0]
        UFortActorComponent_Affiliation*                    AffiliationComponent;               // 0x0006D0 (0x000008) [Default: 0x7FE838AC1FA0]
        UFortAbilitySet*                                    StartupAbilitySet;                  // 0x0006D8 (0x000008) [Default: nullptr]
        AFortPawn*                                          ControllingPlayerPawn;              // 0x0006E0 (0x000008) [Default: nullptr]
        UFortHealthSet*                                     HealthSet;                          // 0x0006E8 (0x000008) [Default: nullptr]
        UFortChargingSet_BikeKidEnergy*                     EnergySet;                          // 0x0006F0 (0x000008) [Default: nullptr]
        FFortAttributeInitializationKey                     AttributeInitKey;                   // 0x0006F8 (0x000008)
        TEnumAsByte<EPhysicalSurface>                       PrimarySurfaceType;                 // 0x000700 (0x000001) [Default: 0]
        TEnumAsByte<EFortBaseWeaponDamage>                  WeaponResponseType;                 // 0x000701 (0x000001) [Default: 0]
        bool                                                bPlayedDeath;                       // 0x000702 (0x000001) [Default: false]
        uint8                                               UnknownByte_000703;                 // 0x000703 (0x000001)
        FBikeKidDismissalData                               OutOfHealthDismissDelayData;        // 0x000704 (0x000010)
        uint8                                               UnknownData_000714[0x000004];       // 0x000714 (0x000004)
        TArray<FFortGameplayEffectContainerSpec>            ExplodeEffectContainerSpecs;        // 0x000718 (0x000010)
        MULTI_INLINE_DELEGATE(OnTeamIndexChangedDelegate)   OnTeamIndexChanged;                 // 0x000728 (0x000010)
        UClass*                                             PawnOverrideComponentClass;         // 0x000738 (0x000008) [Default: nullptr]
        USoundBase*                                         BikeKidMotorLoopSound;              // 0x000740 (0x000008) [Default: nullptr]
        USoundBase*                                         BikeKidThrusterSound;               // 0x000748 (0x000008) [Default: nullptr]
        UAudioParameterComponent*                           AudioParameter;                     // 0x000750 (0x000008) [Default: 0x7FE838AC21B8]
        FName                                               LocallyViewedPawnAudioParamName;    // 0x000758 (0x000004) [Default: FName(-1729722693) -> L"IsLocal"]
        FName                                               IsEnemyAudioParamName;              // 0x00075C (0x000004) [Default: FName(-1813608773) -> L"IsEnemy"]
        FName                                               ThrustAmountAudioParamName;         // 0x000760 (0x000004) [Default: FName(1860273851) -> L"ThrustAmount"]
        float                                               ThrustSoundThreshold;               // 0x000764 (0x000004) [Default: 0.3f]
        uint8                                               UnknownData_000768[0x000008];       // 0x000768 (0x000008)
        FScalableFloat                                      LaunchDelay;                        // 0x000770 (0x000028)
        float                                               ServerWorldCreationTime;            // 0x000798 (0x000004) [Default: -1f]
        uint8                                               UnknownData_00079C[0x000004];       // 0x00079C (0x000004)
    
    public: // Functions
        void                            BP_OnBikeKidDismissed(FGameplayTag& DismissalReason); // 0x000545D2 [Event | Public | HasOutParms | BlueprintEvent]
        void                            BP_OnBikeKidLaunched(); // 0x000545D2 [Event | Public | BlueprintEvent]
        void                            BP_OnDestructionStarted(); // 0x000545D2 [Event | Public | BlueprintEvent]
        void                            GameplayCue_Damage(TEnumAsByte<EGameplayCueEvent> EventType, FGameplayCueParameters Parameters); // 0x080E9C7E [Native | Protected]
        UFortBikeKidMovementComponent*  GetBikeKidMovementComponent(); // 0x10E238F2 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        AFortPawn*                      GetControllingPlayerPawn(); // 0x10E23944 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FRotator                        GetDeltaRotator(); // 0x10E23960 [Final | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        void                            GetForwardAndRightDotProducts_Native(float& OutForwardDot, float& OutRightDot); // 0x080EA076 [Final | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        float                           GetHealthPercentage(); // 0x10E23B6E [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float                           GetLaunchDelayRemaining(); // 0x10E23BF0 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                            IsInLaunchDelay(); // 0x10E23C82 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                            OnCapsuleComponentHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, FHitResult& Hit); // 0x071797DE [Final | Native | Protected | HasOutParms | HasDefaults]
        void                            OnDamagePlayEffects(float Damage, FGameplayTagContainer& DamageTags, FVector Momentum, FHitResult& HitInfo, AFortPawn* InstigatedBy, AActor* DamageCauser, FGameplayEffectContextHandle EffectContext); // 0x000545D2 [BlueprintCosmetic | Event | Protected | HasOutParms | HasDefaults | BlueprintEvent]
        void                            OnDeathPlayEffects(float Damage, FGameplayTagContainer& DamageTags, FVector Momentum, FHitResult& HitInfo, AFortPawn* InstigatedBy, AActor* DamageCauser, FGameplayEffectContextHandle EffectContext); // 0x000545D2 [BlueprintCosmetic | Event | Protected | HasOutParms | HasDefaults | BlueprintEvent]
        void                            OnRep_bExploded(); // 0x10E24002 [Final | Native | Private]
        void                            OnRep_ControllingPlayerPawn(AFortPawn* OldPawn); // 0x080EA322 [Final | Native | Private]
        void                            OnRotationInputReceived(FRotator& RotationInput); // 0x000545D2 [Event | Public | HasOutParms | HasDefaults | BlueprintEvent]
        void                            SetAffiliationAudio(); // 0x10E24034 [Final | Native | Protected | BlueprintCallable]
        void                            SetTeamMatesIndicator(bool bState); // 0x080EA490 [Final | Native | Protected | BlueprintCallable]
        void                            SetupGameplayAudioParameters(); // 0x10E246C0 [Final | BlueprintCosmetic | Native | Protected | BlueprintCallable]
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x8) UBikeKidDeferredDestructionPayload : public UObject
    {
    public:
        FBikeKidDismissalData   DeferredDestructionData;    // 0x000028 (0x000010)
    };
    // Size: 0x000030 (0x000008)
    class alignas(0x8) UBikeKidPassiveMarkPayload : public UObject
    {
    public:
        FBikeKidStatusData  TargetStatus;   // 0x000028 (0x000008)
    };
    // Size: 0x000188 (0x0000C0)
    class alignas(0x8) UFortBikeKidAnalyticsComponent : public UFortControllerComponent
    {
    public:
        float           SessionStartTime;                   // 0x0000C8 (0x000004) [Default: 0f]
        float           SessionLength;                      // 0x0000CC (0x000004) [Default: 0f]
        FScalableFloat  MinSessionLength;                   // 0x0000D0 (0x000028)
        float           DistanceTraveled;                   // 0x0000F8 (0x000004) [Default: 0f]
        FGameplayTag    DismissalReason;                    // 0x0000FC (0x000004)
        uint8           UnknownData_000100[0x000008];       // 0x000100 (0x000008)
        FScalableFloat  DistanceTraveledUpdateInterval;     // 0x000108 (0x000028)
        FTimerHandle    DistanceTraveledUpdateTimerHandle;  // 0x000130 (0x000008)
        FVector         LastRecorderBikeKidLocation;        // 0x000138 (0x000018)
        uint8           UnknownData_000150[0x000038];       // 0x000150 (0x000038)
    };
    // Size: 0x000210 (0x000008)
    class UFortBikeKidCameraMode : public UFort3PCameraMode
    {
    public:
        bool    bShouldInterpolateLocation;     // 0x000208 (0x000001) [Default: false]
        bool    bShouldInterpolateRotation;     // 0x000209 (0x000001) [Default: false]
        uint8   UnknownData_00020A[0x000006];   // 0x00020A (0x000006)
    };
    // Size: 0x000458 (0x000390)
    class alignas(0x8) UFortBikeKidControllingComponent : public UFortControllerComponent
    {
    public:
        FRotator                                CachedControllerRotator;            // 0x0000C8 (0x000018)
        uint8                                   UnknownData_0000E0[0x000030];       // 0x0000E0 (0x000030)
        UInputComponent*                        BikeKidInputComponent;              // 0x000110 (0x000008) [Default: nullptr]
        AFortBikeKid*                           ControlledBikeKid;                  // 0x000118 (0x000008) [Default: nullptr]
        AFortBikeKid*                           LastControlledBikeKid;              // 0x000120 (0x000008) [Default: nullptr]
        AActor*                                 OriginalBikeKidOwner;               // 0x000128 (0x000008) [Default: nullptr]
        UFortInputMappingContext*               BikeKidInputContext;                // 0x000130 (0x000008) [Default: nullptr]
        TArray<FBikeKidInputTriggerableEvent>   InputTriggerableEvents;             // 0x000138 (0x000010)
        UInputAction*                           DismissAction;                      // 0x000148 (0x000008) [Default: nullptr]
        uint8                                   UnknownData_000150[0x000008];       // 0x000150 (0x000008)
        FStenciledActorData                     OwningActorStencilData;             // 0x000158 (0x000080)
        FBikeKidDismissalData                   CurrentDismissalData;               // 0x0001D8 (0x000010)
        UClass*                                 FirstPersonCameraModeOverride;      // 0x0001E8 (0x000008) [Default: nullptr]
        UClass*                                 ThirdPersonCameraModeOverride;      // 0x0001F0 (0x000008) [Default: nullptr]
        FGameplayAbilitySpec                    FakeCameraAbilitySpec;              // 0x0001F8 (0x0000E8)
        TArray<FName>                           LegacyInputActionsToBlock;          // 0x0002E0 (0x000010)
        UClass*                                 BlockActionsGameplayEffect;         // 0x0002F0 (0x000008) [Default: nullptr]
        UBikeKidDeferredDestructionPayload*     DismissPayloadCache;                // 0x0002F8 (0x000008) [Default: nullptr]
        FScalableFloat                          DismissButtonPressCooldown;         // 0x000300 (0x000028)
        float                                   InitialDismissInputCooldown;        // 0x000328 (0x000004) [Default: 1.25f]
        uint8                                   UnknownData_00032C[0x00000C];       // 0x00032C (0x00000C)
        FViewTargetTransitionParams             PlayerToBikeKidTransitionParams;    // 0x000338 (0x000010)
        FViewTargetTransitionParams             BikeKidToPlayerTransitionParams;    // 0x000348 (0x000010)
        FGameplayTagContainer                   InterruptingPlayerTags;             // 0x000358 (0x000020)
        uint8                                   UnknownData_000378[0x000010];       // 0x000378 (0x000010)
        FScalableFloat                          MaxTurnRate;                        // 0x000388 (0x000028)
        FScalableFloat                          MouseTurnRate;                      // 0x0003B0 (0x000028)
        FScalableFloat                          GamepadTurnRate;                    // 0x0003D8 (0x000028)
        FScalableFloat                          TouchLookAccelerationMultiplier;    // 0x000400 (0x000028)
        FScalableFloat                          GyroTurnRate;                       // 0x000428 (0x000028)
        uint8                                   UnknownData_000450[0x000008];       // 0x000450 (0x000008)
    
    public: // Functions
        void            BP_OnBikeKidDestroyed(FGameplayTag& DismissalReason); // 0x000545D2 [BlueprintCosmetic | Event | Protected | HasOutParms | BlueprintEvent]
        void            BP_OnDestructionStarted(bool bInstantDestruction, FGameplayTag DismissalReason); // 0x000545D2 [BlueprintCosmetic | Event | Protected | BlueprintEvent]
        void            BP_OnDismissal(FGameplayTag DismissalReason); // 0x000545D2 [BlueprintCosmetic | Event | Protected | BlueprintEvent]
        void            BP_StartedControlling(AFortBikeKid* InBikeKid); // 0x000545D2 [BlueprintCosmetic | Event | Protected | BlueprintEvent]
        void            ClampRotationInput(FRotator& InOutRotationInput); // 0x080EAA50 [Final | Native | Private | HasOutParms | HasDefaults]
        AFortBikeKid*   GetControlledBikeKid(); // 0x10E26554 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void            NotifyClientBikeKidDestruction(FGameplayTag DestructionReason); // 0x0607D06C [Final | Net | NetReliable | Native | Event | Private | NetClient]
        void            NotifyClientStopControlling(); // 0x0E6F04AC [Final | Net | NetReliable | Native | Event | Private | NetClient]
        void            OnControlledBikeClientDismiss(); // 0x10E2657E [Final | Native | Private]
        void            OnLaunched(); // 0x10E265F6 [Final | Native | Private]
        void            OnOwningPlayerStartedDBNO(); // 0x10E2665C [Final | Native | Private]
        void            OnPlayerInterruptionTagsChanged(FGameplayTag Tag, int32 NewCount); // 0x080EABC8 [Final | Native | Private]
        void            OnRep_ControlledBikeKid(); // 0x10E26730 [Final | Native | Private]
        void            OnWeaponEquipped(AFortWeapon* NewWeapon, AFortWeapon* PrevWeapon); // 0x080EAE6A [Final | Native | Private]
        void            PlayerInputMassageAxis(float& InOutNewVal, UFortPlayerInput* PlayerInput, FKey& Key, float DeltaTime); // 0x080EB100 [Final | Native | Private | HasOutParms]
        void            PlayerInputMassageVectorAxis(FVector& InOutNewVal, UFortPlayerInput* PlayerInput, FKey& Key, float DeltaTime); // 0x080EB806 [Final | Native | Private | HasOutParms | HasDefaults]
        void            PlayerInputOverrideGamepadLookRates(FRotator& InOutLookRatesBase, FRotator& InOutLookRatesFinal, UFortPlayerInput* PlayerInput, float DeltaTime); // 0x080EBC6C [Final | Native | Private | HasOutParms | HasDefaults]
        void            PlayerInputOverrideTouchLookAccelerationMultiplier(float& InOutMultiplier, UFortPlayerInput* PlayerInput); // 0x080EC0C4 [Final | Native | Private | HasOutParms]
        void            PlayerInputProcessTouch(float& InOutLookYawDelta, float& InOutLookPitchDelta, UFortPlayerInput* PlayerInput, FVector2D& TouchLookInput, float DeltaTime); // 0x080EC352 [Final | Native | Private | HasOutParms | HasDefaults]
        void            ServerRequestBikeKidDismissal(); // 0x0F28FDD2 [Final | Net | NetReliable | Native | Event | Private | NetServer]
        void            StartControllingBikeKid(AFortBikeKid* BikeKidToControl); // 0x080EC950 [Final | BlueprintAuthorityOnly | Native | Public | BlueprintCallable]
        void            TryToStopControllingBikeKid(FBikeKidDismissalData& DeferredDestroyData); // 0x080ECABE [Final | BlueprintAuthorityOnly | Native | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x001060 (0x000070)
    class alignas(0x8) UFortBikeKidMovementComponent : public UCharacterMovementComponent
    {
    public:
        FScalableFloat  PreLaunchSpeed;                 // 0x000FF0 (0x000028)
        FScalableFloat  PostLaunchSpeed;                // 0x001018 (0x000028)
        UBoxComponent*  HitBoxComponent;                // 0x001040 (0x000008) [Default: nullptr]
        uint8           UnknownData_001048[0x000018];   // 0x001048 (0x000018)
    
    public: // Functions
        void    SetHitBoxComponent(UBoxComponent* HitBox); // 0x080EE520 [Final | Native | Public | BlueprintCallable]
    };
    // Size: 0x0000D0 (0x000008)
    class alignas(0x8) UFortBikeKidPawnOverrideComponent : public UFortPawnOverrideComponent
    {
    public:
        UClass* BikeKidSpectateCameraMode;  // 0x0000C8 (0x000008) [Default: nullptr]
    };
    // Size: 0x0000D0 (0x000008)
    class alignas(0x8) UFortBikeKidPawnOwnerOverrideComponent : public UFortPawnOverrideComponent
    {
    public:
        TWeakObjectPtr<AFortBikeKid>    ControlledBikeKid;  // 0x0000C8 (0x000008) [Default: nullptr]
    };
    // Size: 0x000120 (0x0000C0)
    class alignas(0x8) UFortChargingSet_BikeKidEnergy : public UFortChargingSet_Base
    {
    public:
        FFortGameplayAttributeData  Energy;                         // 0x000060 (0x000028)
        FFortGameplayAttributeData  MaxEnergy;                      // 0x000088 (0x000028)
        FFortGameplayAttributeData  EnergyChargeRate;               // 0x0000B0 (0x000028)
        FFortGameplayAttributeData  ServerTimeEnergyIncrements;     // 0x0000D8 (0x000028)
        uint8                       UnknownData_000100[0x000020];   // 0x000100 (0x000020)
    
    public: // Functions
        void    OnRep_Energy(FFortGameplayAttributeData& OldValue); // 0x080EE7FA [Final | RequiredAPI | Native | Protected | HasOutParms]
    };
    // Size: 0x000B48 (0x000028)
    class alignas(0x8) UFortGameplayAbility_BikeKid_Activate : public UFortGameplayAbility
    {
    public:
        UClass* RCActorClass;                       // 0x000B20 (0x000008) [Default: nullptr]
        FVector SpawnOffset;                        // 0x000B28 (0x000018)
        float   ForwardObstructionCheckDistance;    // 0x000B40 (0x000004) [Default: 25f]
        uint8   UnknownData_000B44[0x000004];       // 0x000B44 (0x000004)
    };
    // Size: 0x000B30 (0x000010)
    class alignas(0x8) UFortGameplayAbility_BikeKid_Dismiss : public UFortGameplayAbility
    {
    public:
        FBikeKidDismissalData   DismissDelayData;   // 0x000B20 (0x000010)
    
    public: // Functions
        AFortBikeKid*   GetControlledBikeKid(); // 0x10E20BAA [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000CA0 (0x000138)
    class alignas(0x8) UFortGameplayAbility_BikeKid_MarkPotentialTargets : public UFortGameplayAbility_BikeKid_TargetingBase
    {
    public:
        FIndicatedActorData IndicatedActorData;             // 0x000B68 (0x000100)
        uint8               UnknownData_000C68[0x000010];   // 0x000C68 (0x000010)
        FScalableFloat      MaxNumberOfPotentialTargets;    // 0x000C78 (0x000028)
    
    public: // Functions
        void    OnStartHighlightingTarget(AActor* Target); // 0x000545D2 [BlueprintCosmetic | Event | Protected | BlueprintEvent]
        void    OnStoppedHighlightingTarget(AActor* Target); // 0x000545D2 [BlueprintCosmetic | Event | Protected | BlueprintEvent]
    };
    // Size: 0x000D68 (0x000200)
    class alignas(0x8) UFortGameplayAbility_BikeKid_PassiveMark : public UFortGameplayAbility_BikeKid_TargetingBase
    {
    public:
        FBikeKidStatusData          CurrentTargetStatus;            // 0x000B68 (0x000008)
        FStenciledActorData         StenciledActorData;             // 0x000B70 (0x000080)
        FIndicatedActorData         IndicatedActorData;             // 0x000BF0 (0x000100)
        FScalableFloat              ActorTargetingRange;            // 0x000CF0 (0x000028)
        FScalableFloat              TimeToConfirmTarget;            // 0x000D18 (0x000028)
        AActor*                     CurrentTarget;                  // 0x000D40 (0x000008) [Default: nullptr]
        FTimerHandle                TargetConfirmationTimerHandle;  // 0x000D48 (0x000008)
        UBikeKidPassiveMarkPayload* PayloadCache;                   // 0x000D50 (0x000008) [Default: nullptr]
        uint8                       UnknownData_000D58[0x000010];   // 0x000D58 (0x000010)
    
    public: // Functions
        void    BP_OnTargetStatusChanged(AActor* ActiveTarget); // 0x000545D2 [BlueprintAuthorityOnly | Event | Protected | BlueprintEvent]
        void    OnActorIndicatorExpired(AActor* IndicatedActor); // 0x080E94A2 [Final | Native | Private]
        void    OnRep_CurrentTargetStatus(); // 0x10E217D4 [Final | Native | Protected]
    };
    // Size: 0x000C58 (0x0000F0)
    class alignas(0x8) UFortGameplayAbility_BikeKid_SpeedBoost : public UFortGameplayAbility_BikeKid_TargetingBase
    {
    public:
        FGameplayTag                            DoorBashCueTag;                     // 0x000B68 (0x000004)
        uint8                                   UnknownData_000B6C[0x000004];       // 0x000B6C (0x000004)
        UClass*                                 DamageGameplayEffectClass;          // 0x000B70 (0x000008) [Default: nullptr]
        FGameplayTag                            DoorBashPawnLaunchGameplayCueTag;   // 0x000B78 (0x000004)
        uint8                                   UnknownData_000B7C[0x000004];       // 0x000B7C (0x000004)
        FScalableFloat                          DoorBashEnabledHotfix;              // 0x000B80 (0x000028)
        FScalableFloat                          DoorBashSphereRadiusForPawnLaunch;  // 0x000BA8 (0x000028)
        FScalableFloat                          DoorBashScalarForPawnLaunch;        // 0x000BD0 (0x000028)
        TArray<TEnumAsByte<EObjectTypeQuery>>   DoorBashCollisionTypesForPawn;      // 0x000BF8 (0x000010)
        FScalableFloat                          DoorBashEnabled;                    // 0x000C08 (0x000028)
        FScalableFloat                          DamageOnBoostEnabled;               // 0x000C30 (0x000028)
    
    public: // Functions
        void    OnBoostedIntoActor(FHitResult& HitResult); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
        void    OnDoorBashed(FHitResult& HitResult, UFortBuildingWallDoorComponent* BashedDoor); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
    };
    // Size: 0x000B68 (0x000048)
    class alignas(0x8) UFortGameplayAbility_BikeKid_TargetingBase : public UFortGameplayAbility
    {
    public:
        UTargetingPreset*       TargetingPreset;                // 0x000B20 (0x000008) [Default: nullptr]
        FTargetingRequestHandle AsyncTargetingHandle;           // 0x000B28 (0x000004)
        uint8                   UnknownData_000B2C[0x000004];   // 0x000B2C (0x000004)
        FTimerHandle            TargetingTimerHandle;           // 0x000B30 (0x000008)
        FScalableFloat          TargetingInterval;              // 0x000B38 (0x000028)
        bool                    bUseControllerAsInstigator;     // 0x000B60 (0x000001) [Default: false]
        uint8                   UnknownData_000B61[0x000007];   // 0x000B61 (0x000007)
    
    public: // Functions
        void    BP_OnTargetsFound(FTargetingRequestHandle& TargetingHandle); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
        void    StartTargeting(); // 0x10E22B8A [Final | Native | Protected | BlueprintCallable]
        void    StopTargeting(); // 0x10E22BA0 [Final | Native | Protected | BlueprintCallable]
    };
    // Size: 0x000B98 (0x000078)
    class alignas(0x8) UFortGameplayAbility_BikeKid_Tether : public UFortGameplayAbility
    {
    public:
        FScalableFloat          WarningRange;                   // 0x000B20 (0x000028)
        FScalableFloat          SignalLossRange;                // 0x000B48 (0x000028)
        bool                    bIsInWarningRange;              // 0x000B70 (0x000001) [Default: false]
        bool                    bIsInSignalLossRange;           // 0x000B71 (0x000001) [Default: false]
        uint8                   UnknownData_000B72[0x000006];   // 0x000B72 (0x000006)
        FTimerHandle            TetheringTimerHandle;           // 0x000B78 (0x000008)
        FTimerHandle            TetheringReportTimerHandle;     // 0x000B80 (0x000008)
        FBikeKidDismissalData   DismissDelayData;               // 0x000B88 (0x000010)
    
    public: // Functions
        void    StartCheckingDistances(); // 0x10E22F02 [Final | Native | Protected | BlueprintCallable]
        void    StopCheckingDistances(); // 0x10E22FCE [Final | Native | Protected | BlueprintCallable]
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x4) FBikeKidDismissalData
    {
        float           DeposessDelay;                  // 0x000000 (0x000004)
        bool            bInstantDestruction;            // 0x000004 (0x000001)
        uint8           UnknownData_000005[0x000003];   // 0x000005 (0x000003)
        FGameplayTag    DismissalReason;                // 0x000008 (0x000004)
        float           ServerDismissStartTime;         // 0x00000C (0x000004)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FBikeKidInputTriggerableEvent
    {
        FName           InputActionName;                // 0x000000 (0x000004)
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UInputAction*   InputAction;                    // 0x000008 (0x000008)
        FGameplayTag    GameplayEventToTrigger;         // 0x000010 (0x000004)
        uint8           UnknownData_000014[0x000004];   // 0x000014 (0x000004)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FBikeKidStatusData
    {
        EFortBikeKidTargetStatus    Status;                         // 0x000000 (0x000001)
        uint8                       UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        float                       ServerTimeStatusChanged;        // 0x000004 (0x000004)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x8) FOnFortBikeKidDeployed
    {
        TWeakObjectPtr<AFortBikeKid>    DeployedBikeKid;    // 0x000000 (0x000008)
    };
    // Size: 0x000004 (0x000004)
    struct alignas(0x4) FOnFortBikeKidDismissed
    {
        FGameplayTag    DismissalReason;    // 0x000000 (0x000004)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FOnFortBikeKidMarkedEnemies
    {
        FGameplayTag    Source;                         // 0x000000 (0x000004)
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<AActor*> MarkedActors;                   // 0x000008 (0x000010)
    };
}

