/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioAnalyzer
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0000A0 (0x000078)
    class alignas(0x8) UAudioAnalyzer : public UObject
    {
    public:
        UAudioBus*                  AudioBus;                       // 0x000028 (0x000008) [Default: nullptr]
        uint8                       UnknownData_000030[0x000008];   // 0x000030 (0x000008)
        UAudioAnalyzerSubsystem*    AudioAnalyzerSubsystem;         // 0x000038 (0x000008) [Default: nullptr]
        uint8                       UnknownData_000040[0x000060];   // 0x000040 (0x000060)
    
    public: // Functions
        void    StartAnalyzing(UObject* WorldContextObject, UAudioBus* AudioBusToAnalyze); // 0x07FF2294 [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void    StopAnalyzing(UObject* WorldContextObject); // 0x07FF272A [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class UAudioAnalyzerAssetBase : public UObject
    {
    public:
    };
    // Size: 0x000078 (0x000050)
    class alignas(0x8) UAudioAnalyzerNRT : public UAudioAnalyzerAssetBase
    {
    public:
        USoundWave* Sound;                          // 0x000028 (0x000008) [Default: nullptr]
        float       DurationInSeconds;              // 0x000030 (0x000004) [Default: 0f]
        uint8       UnknownData_000034[0x000044];   // 0x000034 (0x000044)
    };
    // Size: 0x000028 (0x000000)
    class UAudioAnalyzerNRTSettings : public UAudioAnalyzerAssetBase
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class UAudioAnalyzerSettings : public UAudioAnalyzerAssetBase
    {
    public:
    };
    // Size: 0x000050 (0x000020)
    class alignas(0x8) UAudioAnalyzerSubsystem : public UEngineSubsystem
    {
    public:
        TArray<UAudioAnalyzer*> AudioAnalyzers;                 // 0x000030 (0x000010)
        uint8                   UnknownData_000040[0x000010];   // 0x000040 (0x000010)
    };
}

