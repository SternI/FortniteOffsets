/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AssetTags
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000030 (0x000000)
    class UAssetTagsSubsystem : public UEngineSubsystem
    {
    public:
    
    public: // Functions
        bool                CollectionExists(FName Name); // 0x07FBC0F8 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        TArray<FAssetData>  GetAssetsInCollection(FName Name); // 0x07FBC264 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        TArray<FName>       GetCollections(); // 0x10CE076E [Final | RequiredAPI | Native | Public | BlueprintCallable]
        TArray<FName>       GetCollectionsContainingAsset(FName AssetPathName); // 0x07FBC3F8 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        TArray<FName>       GetCollectionsContainingAssetData(FAssetData& AssetData); // 0x07FBC59E [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        TArray<FName>       GetCollectionsContainingAssetPtr(UObject* AssetPtr); // 0x07FBC79A [Final | RequiredAPI | Native | Public | BlueprintCallable]
        TArray<FName>       K2_GetCollectionsContainingAsset(FSoftObjectPath& AssetPath); // 0x07FBC942 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
    };
}

