/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AuroraCore_Functions
 * ============================================================
 */

#include "AuroraCore_Functions.hpp"

namespace UE
{

    void UAuroraPlayerControllerComponent::BP_CloseOffersDialog(bool bForce)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.BP_CloseOffersDialog");
    
        UAuroraPlayerControllerComponent___BP_CloseOffersDialog_Params Params{};
        Params.bForce = bForce;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAuroraPlayerControllerComponent::BP_OnFinalizedPurchaseResult(FInstancedStruct& InReceipt, bool bSuccessful)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.BP_OnFinalizedPurchaseResult");
    
        UAuroraPlayerControllerComponent___BP_OnFinalizedPurchaseResult_Params Params{};
        Params.InReceipt = InReceipt;
        Params.bSuccessful = bSuccessful;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InReceipt = Params.InReceipt;
    }

    void UAuroraPlayerControllerComponent::BP_OnIntentPurchaseOfferFailed(FGuid& InOfferInstanceId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.BP_OnIntentPurchaseOfferFailed");
    
        UAuroraPlayerControllerComponent___BP_OnIntentPurchaseOfferFailed_Params Params{};
        Params.InOfferInstanceId = InOfferInstanceId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InOfferInstanceId = Params.InOfferInstanceId;
    }

    void UAuroraPlayerControllerComponent::BP_OnOwnedProductQuantitiesChanged(TMap<FString, int64>& InOwnedProductQuantities)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.BP_OnOwnedProductQuantitiesChanged");
    
        UAuroraPlayerControllerComponent___BP_OnOwnedProductQuantitiesChanged_Params Params{};
        Params.InOwnedProductQuantities = InOwnedProductQuantities;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InOwnedProductQuantities = Params.InOwnedProductQuantities;
    }

    void UAuroraPlayerControllerComponent::BP_OnPurchasedInvoice(FInstancedStruct& InInvoice, bool bSuccessful, FInstancedStruct& InReceipt, FString InErrorCode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.BP_OnPurchasedInvoice");
    
        UAuroraPlayerControllerComponent___BP_OnPurchasedInvoice_Params Params{};
        Params.InInvoice = InInvoice;
        Params.bSuccessful = bSuccessful;
        Params.InReceipt = InReceipt;
        Params.InErrorCode = InErrorCode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InInvoice = Params.InInvoice;
        InReceipt = Params.InReceipt;
    }

    void UAuroraPlayerControllerComponent::BP_ShowOffersDialog(FGuid& InCatalogId, TArray<FInstancedStruct>& InOffers, FText& InTitle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.BP_ShowOffersDialog");
    
        UAuroraPlayerControllerComponent___BP_ShowOffersDialog_Params Params{};
        Params.InCatalogId = InCatalogId;
        Params.InOffers = InOffers;
        Params.InTitle = InTitle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InCatalogId = Params.InCatalogId;
        InOffers = Params.InOffers;
        InTitle = Params.InTitle;
    }

    void UAuroraPlayerControllerComponent::BP_StartPurchaseInvoice(FInstancedStruct& InInvoice, bool bInSuccessful, FString InErrorCode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.BP_StartPurchaseInvoice");
    
        UAuroraPlayerControllerComponent___BP_StartPurchaseInvoice_Params Params{};
        Params.InInvoice = InInvoice;
        Params.bInSuccessful = bInSuccessful;
        Params.InErrorCode = InErrorCode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InInvoice = Params.InInvoice;
    }

    void UAuroraPlayerControllerComponent::BP_StartPurchaseInvoiceOfferQueried(FInstancedStruct& InInvoice, bool bSuccessful, FInstancedStruct& InOffer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.BP_StartPurchaseInvoiceOfferQueried");
    
        UAuroraPlayerControllerComponent___BP_StartPurchaseInvoiceOfferQueried_Params Params{};
        Params.InInvoice = InInvoice;
        Params.bSuccessful = bSuccessful;
        Params.InOffer = InOffer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InInvoice = Params.InInvoice;
        InOffer = Params.InOffer;
    }

    void UAuroraPlayerControllerComponent::CancelOfferPurchase()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.CancelOfferPurchase");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAuroraPlayerControllerComponent::ClientCloseIndividualOfferDialog()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.ClientCloseIndividualOfferDialog");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAuroraPlayerControllerComponent::ClientCloseOffersDialog(FGuid InCatalogId, bool bForce)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.ClientCloseOffersDialog");
    
        UAuroraPlayerControllerComponent___ClientCloseOffersDialog_Params Params{};
        Params.InCatalogId = InCatalogId;
        Params.bForce = bForce;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAuroraPlayerControllerComponent::ClientFinalizePurchaseResult(FInstancedStruct InReceipt, bool bSuccessful)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.ClientFinalizePurchaseResult");
    
        UAuroraPlayerControllerComponent___ClientFinalizePurchaseResult_Params Params{};
        Params.InReceipt = InReceipt;
        Params.bSuccessful = bSuccessful;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAuroraPlayerControllerComponent::ClientIntentPurchaseOfferFailed(FGuid InOfferInstanceId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.ClientIntentPurchaseOfferFailed");
    
        UAuroraPlayerControllerComponent___ClientIntentPurchaseOfferFailed_Params Params{};
        Params.InOfferInstanceId = InOfferInstanceId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAuroraPlayerControllerComponent::ClientShowOffersDialog(FGuid InCatalogId, TArray<FInstancedStruct> InOffers, FText InTitle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.ClientShowOffersDialog");
    
        UAuroraPlayerControllerComponent___ClientShowOffersDialog_Params Params{};
        Params.InCatalogId = InCatalogId;
        Params.InOffers = InOffers;
        Params.InTitle = InTitle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAuroraPlayerControllerComponent::ClientStartPurchaseInvoice(FInstancedStruct InInvoice, bool bInSuccessful, FString InErrorCode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.ClientStartPurchaseInvoice");
    
        UAuroraPlayerControllerComponent___ClientStartPurchaseInvoice_Params Params{};
        Params.InInvoice = InInvoice;
        Params.bInSuccessful = bInSuccessful;
        Params.InErrorCode = InErrorCode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAuroraPlayerControllerComponent::CloseOffersDialog(FGuid& InCatalogId, bool bForce)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.CloseOffersDialog");
    
        UAuroraPlayerControllerComponent___CloseOffersDialog_Params Params{};
        Params.InCatalogId = InCatalogId;
        Params.bForce = bForce;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InCatalogId = Params.InCatalogId;
    }

    TMap<FString, int64> UAuroraPlayerControllerComponent::GetOwnedProductQuantities()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.GetOwnedProductQuantities");
    
        UAuroraPlayerControllerComponent___GetOwnedProductQuantities_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAuroraPlayerControllerComponent::OnRep_PurchaseImplementationClass()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.OnRep_PurchaseImplementationClass");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAuroraPlayerControllerComponent::PurchaseInvoice(FInstancedStruct& InInvoice)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.PurchaseInvoice");
    
        UAuroraPlayerControllerComponent___PurchaseInvoice_Params Params{};
        Params.InInvoice = InInvoice;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InInvoice = Params.InInvoice;
    }

    void UAuroraPlayerControllerComponent::ServerCancelOfferPurchase()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.ServerCancelOfferPurchase");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAuroraPlayerControllerComponent::ServerIntentPurchaseOffer(FGuid InOfferInstanceId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.ServerIntentPurchaseOffer");
    
        UAuroraPlayerControllerComponent___ServerIntentPurchaseOffer_Params Params{};
        Params.InOfferInstanceId = InOfferInstanceId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAuroraPlayerControllerComponent::ServerOnCloseOffersDialog()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.ServerOnCloseOffersDialog");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAuroraPlayerControllerComponent::ServerUploadReceipt(FInstancedStruct InReceipt)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.ServerUploadReceipt");
    
        UAuroraPlayerControllerComponent___ServerUploadReceipt_Params Params{};
        Params.InReceipt = InReceipt;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAuroraPlayerControllerComponent::ShowOffersDialog(FGuid& InCatalogId, TArray<FInstancedStruct>& InOffers, FText& InTitle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.AuroraPlayerControllerComponent.ShowOffersDialog");
    
        UAuroraPlayerControllerComponent___ShowOffersDialog_Params Params{};
        Params.InCatalogId = InCatalogId;
        Params.InOffers = InOffers;
        Params.InTitle = InTitle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InCatalogId = Params.InCatalogId;
        InOffers = Params.InOffers;
        InTitle = Params.InTitle;
    }

} // namespace UE

