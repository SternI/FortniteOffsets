/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:48
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BattleRoyaleGameplayAlertsUI/Data/GameplayAlertSceneInfo
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FGameplayAlertSceneInfo
    {
        FGameplayTag        AlertGameplayTag_7_45F91C4640C38B57BD8E42B36FE3FF59;    // 0x000000 (0x000004)
        uint8               UnknownData_000004[0x000004];                           // 0x000004 (0x000004)
        UDynamicUIScene*    AlertUIScene_5_846ED33740274597BB10AB9A6A48BFF2;        // 0x000008 (0x000008) [Default: nullptr]
    };
}

