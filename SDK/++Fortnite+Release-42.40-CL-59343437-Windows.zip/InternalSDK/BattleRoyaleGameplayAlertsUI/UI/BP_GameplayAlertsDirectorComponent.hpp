/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BattleRoyaleGameplayAlertsUI/UI/BP_GameplayAlertsDirectorComponent
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0000EC (0x00002C)
    class alignas(0x8) UBP_GameplayAlertsDirectorComponent_C : public UFortDynamicUIDirectorComponent
    {
    public:
        FPointerToUberGraphFrame                    UberGraphFrame;             // 0x0000C0 (0x000008)
        UAsyncAction_StartListeningToEvent*         EventAsyncTaskRef;          // 0x0000C8 (0x000008) [Default: nullptr]
        UDynamicUIScene*                            CurrentAlertUIScene;        // 0x0000D0 (0x000008) [Default: nullptr]
        UAsyncAction_StartListeningToStatefulEvent* Async_Task_Ref;             // 0x0000D8 (0x000008) [Default: nullptr]
        FGameplayTag                                CurrentAlertGameplayTag;    // 0x0000E0 (0x000004)
        FFortEvent_CurrentGameplayAlertChanged      CurrentEventPayload;        // 0x0000E4 (0x000004)
        FFortEvent_RemoveGameplayAlertRequested     RemoveEvent;                // 0x0000E8 (0x000004)
    
    public: // Functions
        void    AddGameplayAlertScene(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    ExecuteUbergraph_BP_GameplayAlertsDirectorComponent(int32 EntryPoint, UAsyncAction_StartListeningToStatefulEvent* K2Node_CustomEvent_ProxyObject_2, AsyncStatefulGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate, FFortEvent_CurrentGameplayAlertChanged Temp_struct_Variable, UAsyncAction_StartListeningToStatefulEvent* K2Node_CustomEvent_ProxyObject_1, AsyncStatefulGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate_1, FFortEvent_CurrentGameplayAlertChanged Temp_struct_Variable_1, UAsyncAction_StartListeningToStatefulEvent* K2Node_CustomEvent_ProxyObject, AsyncStatefulGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate_2, FFortEvent_CurrentGameplayAlertChanged Temp_struct_Variable_2, UAsyncAction_StartListeningToStatefulEvent* Temp_object_Variable, bool CallFunc_GetPayload_ReturnValue, bool CallFunc_GetPayload_ReturnValue_1, UDynamicUIScene* CallFunc_GetUISceneForAlert_UIScene, TEnumAsByte<EEndPlayReason> K2Node_Event_EndPlayReason, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue, UAsyncAction_StartListeningToStatefulEvent* CallFunc_StartListeningToStatefulEvent_ReturnValue, bool CallFunc_IsValid_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, FFortEvent_CurrentGameplayAlertChanged Temp_struct_Variable_3, bool CallFunc_GetPayload_ReturnValue_2, bool CallFunc_IsValid_ReturnValue_2, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_1, bool CallFunc_K2_BroadcastEvent_ReturnValue, FFortEvent_RemoveGameplayAlertRequested K2Node_MakeStruct_FortEvent_RemoveGameplayAlertRequested); // 0x000545D2 [Final | UbergraphFunction | HasDefaults]
        void    GetUISceneForAlert(FGameplayTag GameplayAlertTag, UDynamicUIScene*& UIScene, FGameplayAlertSceneInfo DataRegistryOutItem, FName CallFunc_GetTagName_ReturnValue, FDataRegistryId K2Node_MakeStruct_DataRegistryId, bool CallFunc_GetCachedItemBP_ReturnValue); // 0x000545D2 [Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintEvent | BlueprintPure]
        void    OnEventReceived_731F22B440B4F3E52DA690A263DCAC4F(UAsyncAction_StartListeningToStatefulEvent* ProxyObject); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnEventStateCleared_731F22B440B4F3E52DA690A263DCAC4F(UAsyncAction_StartListeningToStatefulEvent* ProxyObject); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnSavedEventStateExists_731F22B440B4F3E52DA690A263DCAC4F(UAsyncAction_StartListeningToStatefulEvent* ProxyObject); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    ReceiveBeginPlay(); // 0x000545D2 [Event | Public | BlueprintEvent]
        void    ReceiveEndPlay(TEnumAsByte<EEndPlayReason> EndPlayReason); // 0x000545D2 [Event | Public | BlueprintEvent]
        void    RemoveGameplayAlertScene(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
    };
}

