/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BattleRoyaleGameplayAlertsUI/UI/BP_GameplayAlertsDirectorComponent_Functions
 * ============================================================
 */

#include "BP_GameplayAlertsDirectorComponent.hpp"

namespace UE
{

    struct UBP_GameplayAlertsDirectorComponent_C___ExecuteUbergraph_BP_GameplayAlertsDirectorComponent_Params
    {
        int32                                       EntryPoint;                                                 // 0x000000 (0x000004) [Default: 340256000]
        uint8                                       UnknownData_000004[0x000004];                               // 0x000004 (0x000004)
        UAsyncAction_StartListeningToStatefulEvent* K2Node_CustomEvent_ProxyObject_2;                           // 0x000008 (0x000008) [Default: 0x67D81DDD00280031]
        AsyncStatefulGameplayEventDelegate          K2Node_CreateDelegate_OutputDelegate;                       // 0x000010 (0x00000C)
        FFortEvent_CurrentGameplayAlertChanged      Temp_struct_Variable;                                       // 0x00001C (0x000004)
        UAsyncAction_StartListeningToStatefulEvent* K2Node_CustomEvent_ProxyObject_1;                           // 0x000020 (0x000008) [Default: 0x663126BC]
        AsyncStatefulGameplayEventDelegate          K2Node_CreateDelegate_OutputDelegate_1;                     // 0x000028 (0x00000C)
        FFortEvent_CurrentGameplayAlertChanged      Temp_struct_Variable_1;                                     // 0x000034 (0x000004)
        UAsyncAction_StartListeningToStatefulEvent* K2Node_CustomEvent_ProxyObject;                             // 0x000038 (0x000008) [Default: 0x130B78F0]
        AsyncStatefulGameplayEventDelegate          K2Node_CreateDelegate_OutputDelegate_2;                     // 0x000040 (0x00000C)
        FFortEvent_CurrentGameplayAlertChanged      Temp_struct_Variable_2;                                     // 0x00004C (0x000004)
        UAsyncAction_StartListeningToStatefulEvent* Temp_object_Variable;                                       // 0x000050 (0x000008) [Default: nullptr]
        bool                                        CallFunc_GetPayload_ReturnValue;                            // 0x000058 (0x000001) [Default: false]
        bool                                        CallFunc_GetPayload_ReturnValue_1;                          // 0x000059 (0x000001) [Default: false]
        uint8                                       UnknownData_00005A[0x000006];                               // 0x00005A (0x000006)
        UDynamicUIScene*                            CallFunc_GetUISceneForAlert_UIScene;                        // 0x000060 (0x000008) [Default: nullptr]
        TEnumAsByte<EEndPlayReason>                 K2Node_Event_EndPlayReason;                                 // 0x000068 (0x000001) [Default: 0]
        uint8                                       UnknownData_000069[0x000007];                               // 0x000069 (0x000007)
        UGameplayEventRouterComponent*              CallFunc_GetGlobalEventRouter_ReturnValue;                  // 0x000070 (0x000008) [Default: nullptr]
        UAsyncAction_StartListeningToStatefulEvent* CallFunc_StartListeningToStatefulEvent_ReturnValue;         // 0x000078 (0x000008) [Default: nullptr]
        bool                                        CallFunc_IsValid_ReturnValue;                               // 0x000080 (0x000001) [Default: false]
        bool                                        CallFunc_IsValid_ReturnValue_1;                             // 0x000081 (0x000001) [Default: false]
        uint8                                       UnknownData_000082[0x000002];                               // 0x000082 (0x000002)
        FFortEvent_CurrentGameplayAlertChanged      Temp_struct_Variable_3;                                     // 0x000084 (0x000004)
        bool                                        CallFunc_GetPayload_ReturnValue_2;                          // 0x000088 (0x000001) [Default: true]
        bool                                        CallFunc_IsValid_ReturnValue_2;                             // 0x000089 (0x000001) [Default: true]
        uint8                                       UnknownData_00008A[0x000006];                               // 0x00008A (0x000006)
        UGameplayEventRouterComponent*              CallFunc_GetGlobalEventRouter_ReturnValue_1;                // 0x000090 (0x000008) [Default: 0xFFFFFFFF]
        bool                                        CallFunc_K2_BroadcastEvent_ReturnValue;                     // 0x000098 (0x000001) [Default: true]
        uint8                                       UnknownData_000099[0x000003];                               // 0x000099 (0x000003)
        FFortEvent_RemoveGameplayAlertRequested     K2Node_MakeStruct_FortEvent_RemoveGameplayAlertRequested;   // 0x00009C (0x000004)
    };

    struct UBP_GameplayAlertsDirectorComponent_C___GetUISceneForAlert_Params
    {
        FGameplayTag            GameplayAlertTag;                       // 0x000000 (0x000004)
        uint8                   UnknownData_000004[0x000004];           // 0x000004 (0x000004)
        UDynamicUIScene*        UIScene;                                // 0x000008 (0x000008) [OutParam] [Default: 0x67D81DDD00280031]
        FGameplayAlertSceneInfo DataRegistryOutItem;                    // 0x000010 (0x000010)
        FName                   CallFunc_GetTagName_ReturnValue;        // 0x000020 (0x000004) [Default: FName(1714497212) -> L"Default__BP_GameplayAlertsDirectorComponent_C"]
        FDataRegistryId         K2Node_MakeStruct_DataRegistryId;       // 0x000024 (0x000008)
        bool                    CallFunc_GetCachedItemBP_ReturnValue;   // 0x00002C (0x000001) [Default: false]
    };

    struct UBP_GameplayAlertsDirectorComponent_C___OnEventReceived_731F22B440B4F3E52DA690A263DCAC4F_Params
    {
        UAsyncAction_StartListeningToStatefulEvent* ProxyObject;    // 0x000000 (0x000008) [Default: 0x1447E500]
    };

    struct UBP_GameplayAlertsDirectorComponent_C___OnEventStateCleared_731F22B440B4F3E52DA690A263DCAC4F_Params
    {
        UAsyncAction_StartListeningToStatefulEvent* ProxyObject;    // 0x000000 (0x000008) [Default: 0x1447E500]
    };

    struct UBP_GameplayAlertsDirectorComponent_C___OnSavedEventStateExists_731F22B440B4F3E52DA690A263DCAC4F_Params
    {
        UAsyncAction_StartListeningToStatefulEvent* ProxyObject;    // 0x000000 (0x000008) [Default: 0x1447E500]
    };

    struct UBP_GameplayAlertsDirectorComponent_C___ReceiveEndPlay_Params
    {
        TEnumAsByte<EEndPlayReason> EndPlayReason;  // 0x000000 (0x000001) [Default: 0]
    };

} // namespace UE

