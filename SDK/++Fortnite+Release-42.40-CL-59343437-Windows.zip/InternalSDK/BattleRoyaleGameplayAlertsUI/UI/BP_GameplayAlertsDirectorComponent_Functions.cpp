/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BattleRoyaleGameplayAlertsUI/UI/BP_GameplayAlertsDirectorComponent_Functions
 * ============================================================
 */

#include "BP_GameplayAlertsDirectorComponent_Functions.hpp"

namespace UE
{

    void UBP_GameplayAlertsDirectorComponent_C::AddGameplayAlertScene()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_GameplayAlertsDirectorComponent.BP_GameplayAlertsDirectorComponent_C.AddGameplayAlertScene");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBP_GameplayAlertsDirectorComponent_C::ExecuteUbergraph_BP_GameplayAlertsDirectorComponent(int32 EntryPoint, UAsyncAction_StartListeningToStatefulEvent* K2Node_CustomEvent_ProxyObject_2, AsyncStatefulGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate, FFortEvent_CurrentGameplayAlertChanged Temp_struct_Variable, UAsyncAction_StartListeningToStatefulEvent* K2Node_CustomEvent_ProxyObject_1, AsyncStatefulGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate_1, FFortEvent_CurrentGameplayAlertChanged Temp_struct_Variable_1, UAsyncAction_StartListeningToStatefulEvent* K2Node_CustomEvent_ProxyObject, AsyncStatefulGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate_2, FFortEvent_CurrentGameplayAlertChanged Temp_struct_Variable_2, UAsyncAction_StartListeningToStatefulEvent* Temp_object_Variable, bool CallFunc_GetPayload_ReturnValue, bool CallFunc_GetPayload_ReturnValue_1, UDynamicUIScene* CallFunc_GetUISceneForAlert_UIScene, TEnumAsByte<EEndPlayReason> K2Node_Event_EndPlayReason, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue, UAsyncAction_StartListeningToStatefulEvent* CallFunc_StartListeningToStatefulEvent_ReturnValue, bool CallFunc_IsValid_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, FFortEvent_CurrentGameplayAlertChanged Temp_struct_Variable_3, bool CallFunc_GetPayload_ReturnValue_2, bool CallFunc_IsValid_ReturnValue_2, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_1, bool CallFunc_K2_BroadcastEvent_ReturnValue, FFortEvent_RemoveGameplayAlertRequested K2Node_MakeStruct_FortEvent_RemoveGameplayAlertRequested)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_GameplayAlertsDirectorComponent.BP_GameplayAlertsDirectorComponent_C.ExecuteUbergraph_BP_GameplayAlertsDirectorComponent");
    
        UBP_GameplayAlertsDirectorComponent_C___ExecuteUbergraph_BP_GameplayAlertsDirectorComponent_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.K2Node_CustomEvent_ProxyObject_2 = K2Node_CustomEvent_ProxyObject_2;
        Params.K2Node_CreateDelegate_OutputDelegate = K2Node_CreateDelegate_OutputDelegate;
        Params.Temp_struct_Variable = Temp_struct_Variable;
        Params.K2Node_CustomEvent_ProxyObject_1 = K2Node_CustomEvent_ProxyObject_1;
        Params.K2Node_CreateDelegate_OutputDelegate_1 = K2Node_CreateDelegate_OutputDelegate_1;
        Params.Temp_struct_Variable_1 = Temp_struct_Variable_1;
        Params.K2Node_CustomEvent_ProxyObject = K2Node_CustomEvent_ProxyObject;
        Params.K2Node_CreateDelegate_OutputDelegate_2 = K2Node_CreateDelegate_OutputDelegate_2;
        Params.Temp_struct_Variable_2 = Temp_struct_Variable_2;
        Params.Temp_object_Variable = Temp_object_Variable;
        Params.CallFunc_GetPayload_ReturnValue = CallFunc_GetPayload_ReturnValue;
        Params.CallFunc_GetPayload_ReturnValue_1 = CallFunc_GetPayload_ReturnValue_1;
        Params.CallFunc_GetUISceneForAlert_UIScene = CallFunc_GetUISceneForAlert_UIScene;
        Params.K2Node_Event_EndPlayReason = K2Node_Event_EndPlayReason;
        Params.CallFunc_GetGlobalEventRouter_ReturnValue = CallFunc_GetGlobalEventRouter_ReturnValue;
        Params.CallFunc_StartListeningToStatefulEvent_ReturnValue = CallFunc_StartListeningToStatefulEvent_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
        Params.Temp_struct_Variable_3 = Temp_struct_Variable_3;
        Params.CallFunc_GetPayload_ReturnValue_2 = CallFunc_GetPayload_ReturnValue_2;
        Params.CallFunc_IsValid_ReturnValue_2 = CallFunc_IsValid_ReturnValue_2;
        Params.CallFunc_GetGlobalEventRouter_ReturnValue_1 = CallFunc_GetGlobalEventRouter_ReturnValue_1;
        Params.CallFunc_K2_BroadcastEvent_ReturnValue = CallFunc_K2_BroadcastEvent_ReturnValue;
        Params.K2Node_MakeStruct_FortEvent_RemoveGameplayAlertRequested = K2Node_MakeStruct_FortEvent_RemoveGameplayAlertRequested;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_GameplayAlertsDirectorComponent_C::GetUISceneForAlert(FGameplayTag GameplayAlertTag, UDynamicUIScene*& UIScene, FGameplayAlertSceneInfo DataRegistryOutItem, FName CallFunc_GetTagName_ReturnValue, FDataRegistryId K2Node_MakeStruct_DataRegistryId, bool CallFunc_GetCachedItemBP_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_GameplayAlertsDirectorComponent.BP_GameplayAlertsDirectorComponent_C.GetUISceneForAlert");
    
        UBP_GameplayAlertsDirectorComponent_C___GetUISceneForAlert_Params Params{};
        Params.GameplayAlertTag = GameplayAlertTag;
        Params.UIScene = UIScene;
        Params.DataRegistryOutItem = DataRegistryOutItem;
        Params.CallFunc_GetTagName_ReturnValue = CallFunc_GetTagName_ReturnValue;
        Params.K2Node_MakeStruct_DataRegistryId = K2Node_MakeStruct_DataRegistryId;
        Params.CallFunc_GetCachedItemBP_ReturnValue = CallFunc_GetCachedItemBP_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        UIScene = Params.UIScene;
    }

    void UBP_GameplayAlertsDirectorComponent_C::OnEventReceived_731F22B440B4F3E52DA690A263DCAC4F(UAsyncAction_StartListeningToStatefulEvent* ProxyObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_GameplayAlertsDirectorComponent.BP_GameplayAlertsDirectorComponent_C.OnEventReceived_731F22B440B4F3E52DA690A263DCAC4F");
    
        UBP_GameplayAlertsDirectorComponent_C___OnEventReceived_731F22B440B4F3E52DA690A263DCAC4F_Params Params{};
        Params.ProxyObject = ProxyObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_GameplayAlertsDirectorComponent_C::OnEventStateCleared_731F22B440B4F3E52DA690A263DCAC4F(UAsyncAction_StartListeningToStatefulEvent* ProxyObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_GameplayAlertsDirectorComponent.BP_GameplayAlertsDirectorComponent_C.OnEventStateCleared_731F22B440B4F3E52DA690A263DCAC4F");
    
        UBP_GameplayAlertsDirectorComponent_C___OnEventStateCleared_731F22B440B4F3E52DA690A263DCAC4F_Params Params{};
        Params.ProxyObject = ProxyObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_GameplayAlertsDirectorComponent_C::OnSavedEventStateExists_731F22B440B4F3E52DA690A263DCAC4F(UAsyncAction_StartListeningToStatefulEvent* ProxyObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_GameplayAlertsDirectorComponent.BP_GameplayAlertsDirectorComponent_C.OnSavedEventStateExists_731F22B440B4F3E52DA690A263DCAC4F");
    
        UBP_GameplayAlertsDirectorComponent_C___OnSavedEventStateExists_731F22B440B4F3E52DA690A263DCAC4F_Params Params{};
        Params.ProxyObject = ProxyObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_GameplayAlertsDirectorComponent_C::ReceiveBeginPlay()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_GameplayAlertsDirectorComponent.BP_GameplayAlertsDirectorComponent_C.ReceiveBeginPlay");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBP_GameplayAlertsDirectorComponent_C::ReceiveEndPlay(TEnumAsByte<EEndPlayReason> EndPlayReason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_GameplayAlertsDirectorComponent.BP_GameplayAlertsDirectorComponent_C.ReceiveEndPlay");
    
        UBP_GameplayAlertsDirectorComponent_C___ReceiveEndPlay_Params Params{};
        Params.EndPlayReason = EndPlayReason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_GameplayAlertsDirectorComponent_C::RemoveGameplayAlertScene()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_GameplayAlertsDirectorComponent.BP_GameplayAlertsDirectorComponent_C.RemoveGameplayAlertScene");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

} // namespace UE

