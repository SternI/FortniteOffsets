/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AuroraFortniteUI
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0002A8 (0x000008)
    class alignas(0x8) AAuroraFortniteUIDirector : public ADynamicUIDirectorBase
    {
    public:
        UFortAuroraShopVM*  AuroraShopVM;   // 0x0002A0 (0x000008) [Default: nullptr]
    
    public: // Functions
        void    OnOfferPurchaseCanceled(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnOfferPurchaseConfirmed(FInstancedStruct& Invoice); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
        void    OnOfferSelected(FGuid& OfferId); // 0x000545D2 [Event | Protected | HasOutParms | HasDefaults | BlueprintEvent]
    };
    // Size: 0x000330 (0x000028)
    class alignas(0x8) UAuroraFortniteTransitionableWidget : public UUserWidget
    {
    public:
        void**  VTable_000308;                  // 0x000308 (0x000008) VTable [7 slots] -> 0x14728D60
        bool    bIsTransitioning;               // 0x000310 (0x000001) [Default: false]
        uint8   UnknownData_000311[0x00001F];   // 0x000311 (0x00001F)
    
    public: // Functions
        void    BroadcastTransitionCompleted(); // 0x10D9A880 [Native | Protected | BlueprintCallable]
        void    OnHide(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnShow(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    UpdateIsTransitioning(bool bInIsTransitioning); // 0x0802F098 [Final | Native | Protected | BlueprintCallable]
    };
    // Size: 0x000100 (0x000010)
    class alignas(0x8) UFortAuroraBundleOfferVM : public UFortAuroraOfferVM
    {
    public:
        TArray<UFortAuroraProductVM*>   Products;   // 0x0000F0 (0x000010)
    };
    // Size: 0x0000F0 (0x000088)
    class alignas(0x8) UFortAuroraOfferVM : public UFortBaseOfferVM
    {
    public:
        FGuid                       OfferId;                        // 0x000068 (0x000010)
        FInstancedStruct            Invoice;                        // 0x000078 (0x000010)
        FText                       ShortDescription;               // 0x000088 (0x000010)
        FText                       Description;                    // 0x000098 (0x000010)
        TSoftObjectPtr<UTexture2D>  Icon;                           // 0x0000A8 (0x000020) [Default: nullptr]
        EFortAuroraOfferType        OfferType;                      // 0x0000C8 (0x000001) [Default: EFortAuroraOfferType(0)]
        EFortAuroraOwnedState       OwnedState;                     // 0x0000C9 (0x000001) [Default: EFortAuroraOwnedState(0)]
        uint8                       UnknownData_0000CA[0x000026];   // 0x0000CA (0x000026)
    
    public: // Functions
        static UFortAuroraOfferVM* CreateAuroraOfferVM(FInstancedStruct& OfferData, TMap<FString, int64>& OwnedProductQuantities, AFortPlayerController* InOwningPlayer); // 0x0802F208 [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
        FText               GetDisplayType(); // 0x10D9B2EC [Native | Public | BlueprintCallable | BlueprintPure | Const]
        FText               GetLegalText(); // 0x10D9B36C [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x0000F8 (0x000008)
    class alignas(0x8) UFortAuroraProductOfferVM : public UFortAuroraOfferVM
    {
    public:
        UFortAuroraProductVM*   Product;    // 0x0000F0 (0x000008) [Default: nullptr]
    };
    // Size: 0x0000E8 (0x000080)
    class alignas(0x8) UFortAuroraProductVM : public UMVVMViewModelBase
    {
    public:
        FString                     ProductId;                      // 0x000068 (0x000010) [Default: L""]
        FText                       Name;                           // 0x000078 (0x000010)
        FText                       ShortDescription;               // 0x000088 (0x000010)
        FText                       Description;                    // 0x000098 (0x000010)
        TSoftObjectPtr<UTexture2D>  Icon;                           // 0x0000A8 (0x000020) [Default: nullptr]
        int64                       Count;                          // 0x0000C8 (0x000008) [Default: 0ll]
        int64                       MaxCount;                       // 0x0000D0 (0x000008) [Default: 0ll]
        int64                       OwnedCount;                     // 0x0000D8 (0x000008) [Default: 0ll]
        EFortAuroraOwnedState       OwnedState;                     // 0x0000E0 (0x000001) [Default: EFortAuroraOwnedState(0)]
        bool                        bConsumable;                    // 0x0000E1 (0x000001) [Default: false]
        uint8                       UnknownData_0000E2[0x000006];   // 0x0000E2 (0x000006)
    };
    // Size: 0x000118 (0x0000A0)
    class alignas(0x8) UFortAuroraShopVM : public UFortPerUserViewModel
    {
    public:
        FGuid                           CatalogId;                      // 0x000078 (0x000010)
        TArray<UFortAuroraOfferVM*>     CatalogOffers;                  // 0x000088 (0x000010)
        FText                           CatalogTitle;                   // 0x000098 (0x000010)
        UFortAuroraOfferVM*             InspectedOffer;                 // 0x0000A8 (0x000008) [Default: nullptr]
        UFortAuroraOfferVM*             LastPurchasedOffer;             // 0x0000B0 (0x000008) [Default: nullptr]
        EFortAuroraOfferRequestState    InspectionState;                // 0x0000B8 (0x000001) [Default: EFortAuroraOfferRequestState(0)]
        EFortAuroraOfferRequestState    PurchaseState;                  // 0x0000B9 (0x000001) [Default: EFortAuroraOfferRequestState(0)]
        uint8                           UnknownData_0000BA[0x00005E];   // 0x0000BA (0x00005E)
    
    public: // Functions
        void    BroadcastInspectedOfferCanceled(); // 0x10D9C61E [Final | Native | Public | BlueprintCallable]
        void    BroadcastInspectedOfferPurchaseConfirmed(); // 0x10D9C634 [Final | Native | Public | BlueprintCallable]
        void    BroadcastOnOfferSelected(FGuid& OfferId); // 0x0802FB0A [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        FText   GetLastErrorCode(); // 0x10D9C64A [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool    IsInTestMode(); // 0x10D9C6CE [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool    IsMtxPurchaseFlowEnabled(); // 0x10D9C6F4 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    ReportInspectedOffer(); // 0x10D9C724 [Final | Native | Public | BlueprintCallable | Const]
        void    ResetCatalogOffers(); // 0x10D9C8C2 [Final | Native | Public | BlueprintCallable]
        void    ResetInspectedOfferAndStates(); // 0x10D9C8D8 [Final | Native | Public | BlueprintCallable]
        void    ResetLastPurchasedOffer(); // 0x10D9C8EE [Final | Native | Public | BlueprintCallable]
        void    SetCatalogOffers(FGuid& InCatalogId, TArray<FInstancedStruct>& Offers, FText& Title, TMap<FString, int64>& OwnedProductQuantities); // 0x080308EE [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        void    SetInspectedOffer(FInstancedStruct& Invoice, FInstancedStruct& offer, TMap<FString, int64>& OwnedProductQuantities); // 0x08031318 [Final | Native | Public | HasOutParms | BlueprintCallable]
        void    SetInspectionState(EFortAuroraOfferRequestState State); // 0x08031CB2 [Final | Native | Public | BlueprintCallable]
        void    SetPurchaseState(EFortAuroraOfferRequestState State); // 0x0803200A [Final | Native | Public | BlueprintCallable]
        bool    ShouldForceAllowTestPurchases(); // 0x10D9C904 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    UpdateLastErrorCode(FString InErrorCode); // 0x0803254A [Final | Native | Public | BlueprintCallable]
        void    UpdateOwnedProductQuantities(TMap<FString, int64>& OwnedProductQuantities); // 0x080326C8 [Final | Native | Public | HasOutParms | BlueprintCallable]
    };
}

