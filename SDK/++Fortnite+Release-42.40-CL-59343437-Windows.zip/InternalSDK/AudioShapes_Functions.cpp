/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioShapes_Functions
 * ============================================================
 */

#include "AudioShapes_Functions.hpp"

namespace UE
{

    void UAudioShapeBoxComponent::SetBoxTransform(FTransform& InTransform)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapeBoxComponent.SetBoxTransform");
    
        UAudioShapeBoxComponent___SetBoxTransform_Params Params{};
        Params.InTransform = InTransform;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InTransform = Params.InTransform;
    }

    void UAudioShapeComponent::Disable()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapeComponent.Disable");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioShapeComponent::Enable()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapeComponent.Enable");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    bool UAudioShapeComponent::IsAudioShapeReady()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapeComponent.IsAudioShapeReady");
    
        UAudioShapeComponent___IsAudioShapeReady_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAudioShapeComponent::IsShapeActive()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapeComponent.IsShapeActive");
    
        UAudioShapeComponent___IsShapeActive_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioShapeComponent::UpdateAudioShape(TArray<APlayerController*>& InLocalControllers)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapeComponent.UpdateAudioShape");
    
        UAudioShapeComponent___UpdateAudioShape_Params Params{};
        Params.InLocalControllers = InLocalControllers;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InLocalControllers = Params.InLocalControllers;
    }

    void UAudioShapeCylinderComponent::SetHalfHeight(float InHalfHeight)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapeCylinderComponent.SetHalfHeight");
    
        UAudioShapeCylinderComponent___SetHalfHeight_Params Params{};
        Params.InHalfHeight = InHalfHeight;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioShapeCylinderComponent::SetRadius(float InRadius)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapeCylinderComponent.SetRadius");
    
        UAudioShapeCylinderComponent___SetRadius_Params Params{};
        Params.InRadius = InRadius;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioShapeLineComponent::SetEndPoint(FVector& InEndPoint)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapeLineComponent.SetEndPoint");
    
        UAudioShapeLineComponent___SetEndPoint_Params Params{};
        Params.InEndPoint = InEndPoint;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InEndPoint = Params.InEndPoint;
    }

    void UAudioShapeLineComponent::SetStartPoint(FVector& InStartPoint)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapeLineComponent.SetStartPoint");
    
        UAudioShapeLineComponent___SetStartPoint_Params Params{};
        Params.InStartPoint = InStartPoint;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InStartPoint = Params.InStartPoint;
    }

    int32 UAudioShapeLineListComponent::AddPoint(FVector& InPoint)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapeLineListComponent.AddPoint");
    
        UAudioShapeLineListComponent___AddPoint_Params Params{};
        Params.InPoint = InPoint;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InPoint = Params.InPoint;
    
        return Params.ReturnValue;
    }

    void UAudioShapeLineListComponent::GetPoints(TArray<FVector>& OutPoints)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapeLineListComponent.GetPoints");
    
        UAudioShapeLineListComponent___GetPoints_Params Params{};
        Params.OutPoints = OutPoints;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutPoints = Params.OutPoints;
    }

    bool UAudioShapeLineListComponent::RemovePoint(int32 InIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapeLineListComponent.RemovePoint");
    
        UAudioShapeLineListComponent___RemovePoint_Params Params{};
        Params.InIndex = InIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAudioShapeLineListComponent::UpdatePoint(int32 InIndex, FVector& InPoint)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapeLineListComponent.UpdatePoint");
    
        UAudioShapeLineListComponent___UpdatePoint_Params Params{};
        Params.InIndex = InIndex;
        Params.InPoint = InPoint;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InPoint = Params.InPoint;
    
        return Params.ReturnValue;
    }

    UAudioComponent* UAudioShapePrimitiveComponent::GetEdgeAudioComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapePrimitiveComponent.GetEdgeAudioComponent");
    
        UAudioShapePrimitiveComponent___GetEdgeAudioComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAudioComponent* UAudioShapePrimitiveComponent::GetInsideAudioComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapePrimitiveComponent.GetInsideAudioComponent");
    
        UAudioShapePrimitiveComponent___GetInsideAudioComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAudioShapePrimitiveComponent::GetIsPlayerInside()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapePrimitiveComponent.GetIsPlayerInside");
    
        UAudioShapePrimitiveComponent___GetIsPlayerInside_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioShapeSphereComponent::SetRadius(float InRadius)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapeSphereComponent.SetRadius");
    
        UAudioShapeSphereComponent___SetRadius_Params Params{};
        Params.InRadius = InRadius;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UAudioComponent* UAudioShapeSplineComponent::GetAudioComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapeSplineComponent.GetAudioComponent");
    
        UAudioShapeSplineComponent___GetAudioComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioShapeSplineComponent::SetSpline(USplineComponent* NewSpline)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioShapes.AudioShapeSplineComponent.SetSpline");
    
        UAudioShapeSplineComponent___SetSpline_Params Params{};
        Params.NewSpline = NewSpline;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

