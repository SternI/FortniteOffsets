/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AloeCroutonWeaponRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000170 (0x000110)
    class alignas(0x8) UFortChargingSet_AloeCrouton : public UFortChargingSet_Base
    {
    public:
        FFortGameplayAttributeData  Charge;                         // 0x000060 (0x000028)
        FFortGameplayAttributeData  MaxCharge;                      // 0x000088 (0x000028)
        FFortGameplayAttributeData  ChargeRate;                     // 0x0000B0 (0x000028)
        FFortGameplayAttributeData  ChargeIncrementAmount;          // 0x0000D8 (0x000028)
        FFortGameplayAttributeData  ChargeRegenThreshold;           // 0x000100 (0x000028)
        FFortGameplayAttributeData  ServerTimeChargeIncrements;     // 0x000128 (0x000028)
        uint8                       UnknownData_000150[0x000020];   // 0x000150 (0x000020)
    
    public: // Functions
        float   GetCooldownDuration(); // 0x10C0095C [Native | Public | BlueprintCallable | BlueprintPure | Const]
        float   GetCooldownRemaining(); // 0x10C0098A [Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    OnRep_Charge(FFortGameplayAttributeData& OldValue); // 0x07ED0B84 [Final | Native | Protected | HasOutParms]
    };
    // Size: 0x000048 (0x000000)
    class UFortCosmeticStatObject_AloeCroutonCharge : public UFortCosmeticStatObject
    {
    public:
    
    public: // Functions
        void    HandleChargeCountChanged(float OldChargeCount, float NewChargeCount, TWeakObjectPtr<AFortPlayerController> PlayerController); // 0x07ED0D2E [Final | Native | Private]
    };
}

