/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AttachableWheelsRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000310 (0x0000A0)
    class alignas(0x8) AAttachableWheel : public AActor
    {
    public:
        UStaticMeshComponent*           WheelMeshComponent;                     // 0x000270 (0x000008) [Default: 0x7FE838238980]
        FRotator                        WheelOrientation;                       // 0x000278 (0x000018)
        float                           WheelDistance;                          // 0x000290 (0x000004) [Default: 0f]
        uint8                           UnknownData_000294[0x000004];           // 0x000294 (0x000004)
        UPhysicsConstraintComponent*    AxleConstraint;                         // 0x000298 (0x000008) [Default: nullptr]
        FAttachableWheelAttachData      AttachData;                             // 0x0002A0 (0x000058)
        bool                            bAutoCreateAttachableWheelsComponent;   // 0x0002F8 (0x000001) [Default: true]
        bool                            bEnableWheelWheelCollision;             // 0x0002F9 (0x000001) [Default: false]
        bool                            bReplicateRuntimeData;                  // 0x0002FA (0x000001) [Default: true]
        uint8                           UnknownByte_0002FB;                     // 0x0002FB (0x000001)
        FAttachableWheelRuntimeData     RuntimeData;                            // 0x0002FC (0x00000C)
        uint8                           UnknownData_000308[0x000008];           // 0x000308 (0x000008)
    
    public: // Functions
        bool                        AttachInPlace(UPrimitiveComponent* InComponent); // 0x07FDF828 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        bool                        AttachTo(UPrimitiveComponent* InComponent, FVector& WorldLocation, FVector& AxleDirection, FVector SteerAxis); // 0x07FDF99E [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        void                        Detach(); // 0x10D1C936 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        bool                        DetachFrom(UPrimitiveComponent* InComponent); // 0x07FE03AC [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        DrawDebug(); // 0x0CA02B1A [Final | RequiredAPI | Native | Public | BlueprintCallable | Const]
        FAttachableWheelAttachData  GetAttachData(); // 0x10D1CA18 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UPrimitiveComponent*        GetAttachedComponent(); // 0x10D1CA48 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                        GetWorldSpaceAttachData(FAttachableWheelAttachData& OutAttachData, UPrimitiveComponent* PrimitiveComponent, FName BodyName); // 0x07FE0542 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        void                        OnAttached(UPrimitiveComponent* AttachedComponent); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void                        OnDetached(UPrimitiveComponent* DetachedComponent); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void                        OnPhysicsStateChanged(UPrimitiveComponent* PrimitiveComponent, EComponentPhysicsStateChange StateChange); // 0x07FE091C [RequiredAPI | Native | Protected]
        void                        OnRep_AttachData(FAttachableWheelAttachData& AttachDataPrev); // 0x07FE0BA2 [Final | RequiredAPI | Native | Protected | HasOutParms]
        void                        OnRep_RuntimeData(FAttachableWheelRuntimeData& RuntimeDataPrev); // 0x07FE0D4A [Final | RequiredAPI | Native | Protected | HasOutParms]
        void                        SetRuntimeData(float Torque, float Velocity, float SteerAngle); // 0x07FE0EC2 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        SetRuntimeData_SteerAngle(float SteerAngle); // 0x07FE1270 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        SetRuntimeData_Torque(float Torque); // 0x07FE13FA [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        SetRuntimeData_Velocity(float Velocity); // 0x07FE1574 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x0000E8 (0x000028)
    class alignas(0x8) UAttachableWheelsComponent : public UActorComponent
    {
    public:
        uint8                   UnknownData_0000C0[0x000008];   // 0x0000C0 (0x000008)
        TSet<AAttachableWheel*> AttachedWheels;                 // 0x0000C8 (0x000010)
        float                   MaxChassisMassFraction;         // 0x0000D8 (0x000004) [Default: 0f]
        uint8                   UnknownData_0000DC[0x00000C];   // 0x0000DC (0x00000C)
    
    public: // Functions
        int32                       DetachAllWheels(); // 0x10D1E48C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        DrawDebug(); // 0x0CA02B1A [Final | RequiredAPI | Native | Public | BlueprintCallable | Const]
        AAttachableWheel*           GetAttachedWheelClosestOnAxis(FVector& Point, float& OutClosetDistanceToAxis, FVector& OutClosestPointOnAxis, FVector& OutClosestAxis); // 0x07FE18FE [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        TArray<AAttachableWheel*>   GetAttachedWheels(); // 0x10D1E8A2 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                        HandleWheelAttached_Internal(AAttachableWheel* AttachedWheel); // 0x07FE1D9E [Final | Native | Protected]
        bool                        HandleWheelDetached_Internal(AAttachableWheel* AttachedWheel); // 0x07FE1F14 [Final | Native | Protected]
        void                        OnWheelAttached(AAttachableWheel* AttachedWheel); // 0x000545D2 [RequiredAPI | Event | Public | BlueprintEvent]
        void                        OnWheelDetached(AAttachableWheel* AttachedWheel); // 0x000545D2 [RequiredAPI | Event | Public | BlueprintEvent]
        void                        SetMaxChassisMassFraction(float InMaxChassisMassFraction); // 0x07FE208A [Final | Native | Public | BlueprintCallable]
    };
    // Size: 0x000058 (0x000058)
    struct alignas(0x8) FAttachableWheelAttachData
    {
        TWeakObjectPtr<UPrimitiveComponent> PrimitiveComponent; // 0x000000 (0x000008)
        FVector                             Pos;                // 0x000008 (0x000018)
        FVector                             Axis1;              // 0x000020 (0x000018)
        FVector                             Axis2;              // 0x000038 (0x000018)
        float                               Damping;            // 0x000050 (0x000004)
        FName                               AttachmentName;     // 0x000054 (0x000004)
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FAttachableWheelRuntimeData
    {
        float   Torque;     // 0x000000 (0x000004)
        float   Velocity;   // 0x000004 (0x000004)
        float   SteerAngle; // 0x000008 (0x000004)
    };
}

