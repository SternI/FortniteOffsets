/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AssetTags_Functions
 * ============================================================
 */

#include "AssetTags_Functions.hpp"

namespace UE
{

    bool UAssetTagsSubsystem::CollectionExists(FName Name)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetTags.AssetTagsSubsystem.CollectionExists");
    
        UAssetTagsSubsystem___CollectionExists_Params Params{};
        Params.Name = Name;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FAssetData> UAssetTagsSubsystem::GetAssetsInCollection(FName Name)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetTags.AssetTagsSubsystem.GetAssetsInCollection");
    
        UAssetTagsSubsystem___GetAssetsInCollection_Params Params{};
        Params.Name = Name;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FName> UAssetTagsSubsystem::GetCollections()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetTags.AssetTagsSubsystem.GetCollections");
    
        UAssetTagsSubsystem___GetCollections_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FName> UAssetTagsSubsystem::GetCollectionsContainingAsset(FName AssetPathName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetTags.AssetTagsSubsystem.GetCollectionsContainingAsset");
    
        UAssetTagsSubsystem___GetCollectionsContainingAsset_Params Params{};
        Params.AssetPathName = AssetPathName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FName> UAssetTagsSubsystem::GetCollectionsContainingAssetData(FAssetData& AssetData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetTags.AssetTagsSubsystem.GetCollectionsContainingAssetData");
    
        UAssetTagsSubsystem___GetCollectionsContainingAssetData_Params Params{};
        Params.AssetData = AssetData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        AssetData = Params.AssetData;
    
        return Params.ReturnValue;
    }

    TArray<FName> UAssetTagsSubsystem::GetCollectionsContainingAssetPtr(UObject* AssetPtr)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetTags.AssetTagsSubsystem.GetCollectionsContainingAssetPtr");
    
        UAssetTagsSubsystem___GetCollectionsContainingAssetPtr_Params Params{};
        Params.AssetPtr = AssetPtr;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FName> UAssetTagsSubsystem::K2_GetCollectionsContainingAsset(FSoftObjectPath& AssetPath)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetTags.AssetTagsSubsystem.K2_GetCollectionsContainingAsset");
    
        UAssetTagsSubsystem___K2_GetCollectionsContainingAsset_Params Params{};
        Params.AssetPath = AssetPath;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        AssetPath = Params.AssetPath;
    
        return Params.ReturnValue;
    }

} // namespace UE

