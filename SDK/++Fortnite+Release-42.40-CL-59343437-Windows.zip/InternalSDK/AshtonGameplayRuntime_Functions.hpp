/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AshtonGameplayRuntime_Functions
 * ============================================================
 */

#include "AshtonGameplayRuntime.hpp"

namespace UE
{

    struct IAshtonShieldWeaponInterface___GetAshtonShieldData_Params
    {
        FScalableFloat  BlockHealth;    // 0x000000 (0x000028) [OutParam]
        float           DamageCount;    // 0x000028 (0x000004) [OutParam] [Default: 1.5821e-27f]
    };

} // namespace UE

