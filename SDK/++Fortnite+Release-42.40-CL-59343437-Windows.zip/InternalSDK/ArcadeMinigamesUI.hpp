/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArcadeMinigamesUI
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000560 (0x0000C0)
    class alignas(0x8) UArcadeMinigame2DWidget : public UArcadeMinigameWidget
    {
    public:
        EArcadeMinigamePhase    GamePhase;                      // 0x0004A0 (0x000001) [Default: EArcadeMinigamePhase(0)]
        uint8                   UnknownData_0004A1[0x000003];   // 0x0004A1 (0x000003)
        int32                   Score;                          // 0x0004A4 (0x000004) [Default: 0]
        int32                   Highscore;                      // 0x0004A8 (0x000004) [Default: 0]
        uint8                   UnknownData_0004AC[0x000004];   // 0x0004AC (0x000004)
        UInputAction*           MovementAction;                 // 0x0004B0 (0x000008) [Default: nullptr]
        UInputAction*           PrimaryAction;                  // 0x0004B8 (0x000008) [Default: nullptr]
        UInputAction*           PrimaryOnPressAction;           // 0x0004C0 (0x000008) [Default: nullptr]
        UInputAction*           SecondaryAction;                // 0x0004C8 (0x000008) [Default: nullptr]
        FMargin                 GamePadding;                    // 0x0004D0 (0x000010)
        uint8                   UnknownData_0004E0[0x000018];   // 0x0004E0 (0x000018)
        FSlateFontInfo          ScoreFont;                      // 0x0004F8 (0x000058)
        uint8                   UnknownData_000550[0x000010];   // 0x000550 (0x000010)
    
    public: // Functions
        void    EndGame(); // 0x10C17034 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetPaused(bool bPause); // 0x07EEB590 [Final | Native | Public | BlueprintCallable]
        void    SetScoreFont(FName& FontName, int32 DefaultSize); // 0x07EEB716 [Final | Native | Public | HasOutParms | BlueprintCallable]
        void    StartGame(); // 0x10C17146 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x0004A0 (0x000000)
    class UArcadeMinigameWidget : public UCommonActivatableWidget
    {
    public:
    
    public: // Functions
        bool    HasAnyControlAction(); // 0x10C1725C [RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool    HasMovementControl(); // 0x103FD074 [RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool    HasPrimaryControl(); // 0x0F8421F0 [RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool    HasSecondaryControl(); // 0x10C17286 [RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x0004C8 (0x000028)
    class alignas(0x8) UArcadeMobileControlOverlayWidget : public UCommonActivatableWidget
    {
    public:
        UInputAction*   ExitAction;                     // 0x0004A0 (0x000008) [Default: nullptr]
        uint8           UnknownData_0004A8[0x000020];   // 0x0004A8 (0x000020)
    
    public: // Functions
        bool    HasExitControl(); // 0x10C172B0 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool    HasMovementControl(); // 0x10C172CE [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool    HasPrimaryControl(); // 0x10C17310 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool    HasSecondaryControl(); // 0x10C17352 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    InjectMovement(FVector2D Value); // 0x07EEB9A8 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void    OnExitButtonPressed(); // 0x10C17406 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    OnPrimaryButtonPressed(); // 0x10C1742C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    OnPrimaryButtonReleased(); // 0x10C1746C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    OnSecondaryButtonPressed(); // 0x10C174AE [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    OnSecondaryButtonReleased(); // 0x10C174EA [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000368 (0x000060)
    class alignas(0x8) UArcadeMobileJoystickWidget : public UUserWidget
    {
    public:
        MULTI_INLINE_DELEGATE(OnJoystickValueChanged)   OnValueChanged;                 // 0x000308 (0x000010)
        UImage*                                         ThumbImage;                     // 0x000318 (0x000008) [Default: nullptr]
        UOverlay*                                       StickVisual;                    // 0x000320 (0x000008) [Default: nullptr]
        float                                           MaxThumbOffsetPixels;           // 0x000328 (0x000004) [Default: 60f]
        float                                           OriginFollowDistancePixels;     // 0x00032C (0x000004) [Default: 20f]
        FVector2D                                       DefaultStickMargin;             // 0x000330 (0x000010)
        uint8                                           UnknownData_000340[0x000028];   // 0x000340 (0x000028)
    
    public: // Functions
        FVector2D   GetCurrentValue(); // 0x10C17526 [Final | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000680 (0x000120)
    class alignas(0x8) UArcadeVolleyWidget : public UArcadeMinigame2DWidget
    {
    public:
        uint8           UnknownData_000560[0x000018];   // 0x000560 (0x000018)
        int32           WinningScore;                   // 0x000578 (0x000004) [Default: 7]
        float           BallInitialSpeed;               // 0x00057C (0x000004) [Default: 880f]
        float           BallSpeedIncrement;             // 0x000580 (0x000004) [Default: 20f]
        float           PaddleSpeed;                    // 0x000584 (0x000004) [Default: 400f]
        float           PaddleWidth;                    // 0x000588 (0x000004) [Default: 14f]
        float           PaddleHeight;                   // 0x00058C (0x000004) [Default: 100f]
        float           AISpeed;                        // 0x000590 (0x000004) [Default: 200f]
        FLinearColor    PaddleColor;                    // 0x000594 (0x000010)
        FLinearColor    BallColor;                      // 0x0005A4 (0x000010)
        FLinearColor    CenterDashColor;                // 0x0005B4 (0x000010)
        FLinearColor    ScoreColor;                     // 0x0005C4 (0x000010)
        uint8           UnknownData_0005D4[0x000004];   // 0x0005D4 (0x000004)
        USoundBase*     WallBounceSound;                // 0x0005D8 (0x000008) [Default: nullptr]
        USoundBase*     PaddleHitSound;                 // 0x0005E0 (0x000008) [Default: nullptr]
        USoundBase*     ServeSound;                     // 0x0005E8 (0x000008) [Default: nullptr]
        USoundBase*     PlayerScoredSound;              // 0x0005F0 (0x000008) [Default: nullptr]
        USoundBase*     MatchEndedSound;                // 0x0005F8 (0x000008) [Default: nullptr]
        USoundBase*     GameStartedSound;               // 0x000600 (0x000008) [Default: nullptr]
        uint8           UnknownData_000608[0x000078];   // 0x000608 (0x000078)
    
    public: // Functions
        void    OnMatchEnded(int32 WinnerPlayerIndex); // 0x07EEBB16 [Native | Event | Protected | BlueprintEvent]
        void    OnPlayerScored(int32 PlayerIndex); // 0x04FB6D0C [Native | Event | Protected | BlueprintEvent]
        void    OnServed(); // 0x0F94C054 [Native | Event | Protected | BlueprintEvent]
    };
    // Size: 0x0004B0 (0x0001A8)
    class alignas(0x8) UBoostBallGameStage : public UUserWidget
    {
    public:
        bool            bRequestEndGame;                // 0x000308 (0x000001) [Default: false]
        uint8           UnknownData_000309[0x000003];   // 0x000309 (0x000003)
        float           CarMaxTurnRate;                 // 0x00030C (0x000004) [Default: 300f]
        float           CarAccel;                       // 0x000310 (0x000004) [Default: 1800f]
        float           CarCruiseSpeed;                 // 0x000314 (0x000004) [Default: 700f]
        float           CarCoastDamping;                // 0x000318 (0x000004) [Default: 3f]
        float           BoostCruiseSpeed;               // 0x00031C (0x000004) [Default: 1150f]
        float           BoostAccelBonus;                // 0x000320 (0x000004) [Default: 1200f]
        float           BoostMax;                       // 0x000324 (0x000004) [Default: 100f]
        float           BoostDrainRate;                 // 0x000328 (0x000004) [Default: 40f]
        float           BoostRefillRate;                // 0x00032C (0x000004) [Default: 20f]
        float           HandbrakeDampingMul;            // 0x000330 (0x000004) [Default: 4f]
        float           HandbrakeTurnMul;               // 0x000334 (0x000004) [Default: 1.5f]
        float           BallDamping;                    // 0x000338 (0x000004) [Default: 1.2f]
        float           BallWallRestitution;            // 0x00033C (0x000004) [Default: 0.8f]
        float           CarWallRestitution;             // 0x000340 (0x000004) [Default: 0.3f]
        float           HitRestitution;                 // 0x000344 (0x000004) [Default: 1.1f]
        float           HitSpeedCap;                    // 0x000348 (0x000004) [Default: 1600f]
        float           AISpeedFactor;                  // 0x00034C (0x000004) [Default: 0.9f]
        float           AIReactionDelay;                // 0x000350 (0x000004) [Default: 0.15f]
        float           MatchSeconds;                   // 0x000354 (0x000004) [Default: 90f]
        int32           KickoffCountdown;               // 0x000358 (0x000004) [Default: 3]
        uint8           UnknownData_00035C[0x000004];   // 0x00035C (0x000004)
        USoundBase*     CarBallHitSound;                // 0x000360 (0x000008) [Default: nullptr]
        USoundBase*     BallWallBounceSound;            // 0x000368 (0x000008) [Default: nullptr]
        USoundBase*     CarWallBounceSound;             // 0x000370 (0x000008) [Default: nullptr]
        USoundBase*     CarCarBumpSound;                // 0x000378 (0x000008) [Default: nullptr]
        USoundBase*     PlayerScoredSound;              // 0x000380 (0x000008) [Default: nullptr]
        USoundBase*     AiScoredSound;                  // 0x000388 (0x000008) [Default: nullptr]
        USoundBase*     MatchStartSound;                // 0x000390 (0x000008) [Default: nullptr]
        USoundBase*     MatchEndSound;                  // 0x000398 (0x000008) [Default: nullptr]
        UCanvasPanel*   GameCanvas;                     // 0x0003A0 (0x000008) [Default: nullptr]
        UImage*         Img_PlayerCar;                  // 0x0003A8 (0x000008) [Default: nullptr]
        UImage*         Img_AICar;                      // 0x0003B0 (0x000008) [Default: nullptr]
        UImage*         Img_Ball;                       // 0x0003B8 (0x000008) [Default: nullptr]
        UProgressBar*   BoostBar;                       // 0x0003C0 (0x000008) [Default: nullptr]
        UTextBlock*     ScoreText;                      // 0x0003C8 (0x000008) [Default: nullptr]
        UTextBlock*     TimeText;                       // 0x0003D0 (0x000008) [Default: nullptr]
        UTextBlock*     CountdownText;                  // 0x0003D8 (0x000008) [Default: nullptr]
        uint8           UnknownData_0003E0[0x0000A0];   // 0x0003E0 (0x0000A0)
        UImage*         PlayerExhaustImg;               // 0x000480 (0x000008) [Default: nullptr]
        UImage*         AIExhaustImg;                   // 0x000488 (0x000008) [Default: nullptr]
        uint8           UnknownData_000490[0x000020];   // 0x000490 (0x000020)
    
    public: // Functions
        void    StartMatch(); // 0x10C17542 [Final | Native | Public | BlueprintCallable]
    };
    // Size: 0x0004C8 (0x000028)
    class alignas(0x8) UBoostBallScreen : public UArcadeMinigameWidget
    {
    public:
        UWidgetSwitcher*        StateSwitcher;                  // 0x0004A0 (0x000008) [Default: nullptr]
        UBoostBallGameStage*    GameStage;                      // 0x0004A8 (0x000008) [Default: nullptr]
        UTextBlock*             HighScoreText;                  // 0x0004B0 (0x000008) [Default: nullptr]
        UTextBlock*             ResultText;                     // 0x0004B8 (0x000008) [Default: nullptr]
        uint8                   UnknownData_0004C0[0x000008];   // 0x0004C0 (0x000008)
    
    public: // Functions
        void    HandlePrimaryPressed(); // 0x10C1760E [Final | Native | Public | BlueprintCallable]
        void    HandlePrimaryReleased(); // 0x10C176B4 [Final | Native | Public | BlueprintCallable]
        void    HandleSecondaryPressed(); // 0x10C17708 [Final | Native | Public | BlueprintCallable]
        void    HandleSecondaryReleased(); // 0x10C1775C [Final | Native | Public | BlueprintCallable]
        void    SetStickInput(FVector2D Stick); // 0x07EEBC8A [Final | Native | Public | HasDefaults | BlueprintCallable]
    };
}

