/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArcadeWeaponUI_Functions
 * ============================================================
 */

#include "ArcadeWeaponUI_Functions.hpp"

namespace UE
{

    bool UArcadeWeaponInGameUIHitPointsVM::GetIsTrickShot()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponUI.ArcadeWeaponInGameUIHitPointsVM.GetIsTrickShot");
    
        UArcadeWeaponInGameUIHitPointsVM___GetIsTrickShot_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FText UArcadeWeaponInGameUIHitPointsVM::GetScoreText()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponUI.ArcadeWeaponInGameUIHitPointsVM.GetScoreText");
    
        UArcadeWeaponInGameUIHitPointsVM___GetScoreText_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FVector2D UArcadeWeaponInGameUIHitPointsVM::GetScoreTextRenderTranslation()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponUI.ArcadeWeaponInGameUIHitPointsVM.GetScoreTextRenderTranslation");
    
        UArcadeWeaponInGameUIHitPointsVM___GetScoreTextRenderTranslation_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UArcadeWeaponUIScoreVM::GetCurrentMatchScore()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponUI.ArcadeWeaponUIScoreVM.GetCurrentMatchScore");
    
        UArcadeWeaponUIScoreVM___GetCurrentMatchScore_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UArcadeWeaponUIScoreVM::GetCurrentStreak()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponUI.ArcadeWeaponUIScoreVM.GetCurrentStreak");
    
        UArcadeWeaponUIScoreVM___GetCurrentStreak_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

} // namespace UE

