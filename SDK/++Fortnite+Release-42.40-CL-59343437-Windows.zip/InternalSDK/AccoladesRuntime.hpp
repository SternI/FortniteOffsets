/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AccoladesRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000038 (0x000010)
    class UFortAccoladeCollectionFeatureCollector : public UObject
    {
    public:
        uint8   UnknownData_000028[0x000010];   // 0x000028 (0x000010)
    };
    // Size: 0x000028 (0x000000)
    class UFortCheatManager_Accolades : public UChildCheatManager
    {
    public:
    
    public: // Functions
        void    ResetAccoladeData(); // 0x0CA02B1A [Final | BlueprintAuthorityOnly | Exec | Native | Private]
        void    TriggerAccolade(FString AccoladeName, int32 TimesToTrigger); // 0x0613D928 [Final | BlueprintAuthorityOnly | Exec | Native | Private]
    };
    // Size: 0x0001C0 (0x0000F8)
    class alignas(0x8) UFortControllerComponent_AccoladeCollection : public UFortControllerComponent
    {
    public:
        uint8                               UnknownData_0000C8[0x000050];   // 0x0000C8 (0x000050)
        FName                               PinnedAccoladeName;             // 0x000118 (0x000004) [Default: NAME_None]
        uint8                               UnknownData_00011C[0x000034];   // 0x00011C (0x000034)
        FPersistenceFrameworkSaveControl    SaveControl;                    // 0x000150 (0x000010)
        FFortAccoladeCollectionDataArray    AccoladeCollectionDataArray;    // 0x000160 (0x000060)
    
    public: // Functions
        void    ClientNotifyRestored(EPersistenceFrameworkResult Result); // 0x061BA028 [Final | Net | NetReliable | Native | Event | Private | NetClient]
        void    ClientResetAccoladeData(); // 0x0F28FDD2 [Final | Net | NetReliable | Native | Event | Private | NetClient]
        void    HandleOnCurrentPlaylistLoaded(FName PlaylistName, FGameplayTagContainer& PlaylistContextTags); // 0x07E959E4 [Final | Native | Private | HasOutParms]
        void    HandlePlayerProfileInitialized(); // 0x10BAE51E [Final | Native | Private]
        void    OnRep_PinnedAccoladeName(FName OldPinnedAccoladeName); // 0x07E95C80 [Final | Native | Private]
        void    ServerMarkAccoladesAsSeen(TArray<FName> AccoladeNames); // 0x064CF462 [Final | Net | NetReliable | Native | Event | Private | NetServer]
        void    ServerPinAccolade(FName AccoladeName); // 0x0607CEF8 [Final | Net | NetReliable | Native | Event | Private | NetServer]
    };
    // Size: 0x000258 (0x000190)
    class alignas(0x8) UFortControllerComponent_Accolades : public UFortControllerComponent
    {
    public:
        uint8                                   UnknownData_0000C8[0x0000C0];       // 0x0000C8 (0x0000C0)
        FFortUpdatedTrackedAccoladeDataArray    UpdatedTrackedAccoladeDataArray;    // 0x000188 (0x000060)
        FFortCompletedAccoladeDataArray         CompletedAccoladeDataArray;         // 0x0001E8 (0x000060)
        uint8                                   UnknownData_000248[0x000010];       // 0x000248 (0x000010)
    };
    // Size: 0x0000D0 (0x000010)
    class UFortGameStateComponent_AccoladeCollection : public UFortGameStateComponent
    {
    public:
        uint8   UnknownData_0000C0[0x000010];   // 0x0000C0 (0x000010)
    };
    // Size: 0x000148 (0x000088)
    class alignas(0x8) UFortGameStateComponent_Accolades : public UFortGameStateComponent
    {
    public:
        void**  VTable_0000C0;                  // 0x0000C0 (0x000008) VTable [3 slots] -> 0x1468E3D0
        uint8   UnknownData_0000C8[0x000080];   // 0x0000C8 (0x000080)
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x8) UGameFeatureAction_AddAccoladeTables : public UGameFeatureAction
    {
    public:
        TArray<TSoftObjectPtr<UDataTable>>  AccoladeTables; // 0x000028 (0x000010)
    };
    // Size: 0x000128 (0x000020)
    class alignas(0x8) UPFWAccoladeCollection_Container : public UPersistenceFrameworkContainer
    {
    public:
        void**  VTable_000108;                  // 0x000108 (0x000008) VTable [165 slots] -> 0x13FBE550
        void**  VTable_000110;                  // 0x000110 (0x000008) VTable [6 slots] -> 0x1468E3F0
        uint8   UnknownData_000118[0x000010];   // 0x000118 (0x000010)
    };
    // Size: 0x000120 (0x000010)
    class UPFWAccoladeCollection_FilteredListContainer : public UPersistenceFrameworkFilteredListContainer
    {
    public:
        uint8   UnknownData_000110[0x000010];   // 0x000110 (0x000010)
    };
    // Size: 0x0000A0 (0x000000)
    class UPFWAccoladeCollection_Module : public UPersistenceFrameworkModule
    {
    public:
    };
    // Size: 0x0000A0 (0x000000)
    class UPFWAccoladeCollection_Trigger : public UPersistenceFrameworkSaveTrigger_Manual
    {
    public:
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FFortAccoladeCollectionData
    {
        uint32  AchievedCount;                  // 0x000000 (0x000004)
        bool    bAcknowledged;                  // 0x000004 (0x000001)
        uint8   UnknownData_000005[0x000003];   // 0x000005 (0x000003)
    };
    // Size: 0x000060 (0x000018)
    struct alignas(0x8) FFortAccoladeCollectionDataArray : public FFastArraySerializer
    {
        uint8                                   UnknownData_000048[0x000008];   // 0x000048 (0x000008)
        TArray<FFortAccoladeCollectionDataItem> AccoladeCollectionData;         // 0x000050 (0x000010)
    };
    // Size: 0x000018 (0x00000C)
    struct alignas(0x8) FFortAccoladeCollectionDataItem : public FFastArraySerializerItem
    {
        FName                       AccoladeName;   // 0x00000C (0x000004)
        FFortAccoladeCollectionData CollectionData; // 0x000010 (0x000008)
    };
    // Size: 0x00000C (0x00000C)
    struct FFortAccoladeSessionData
    {
        uint8   UnknownData_000000[0x00000C];   // 0x000000 (0x00000C)
    };
    // Size: 0x000110 (0x000108)
    struct alignas(0x8) FFortAccoladesTableRow : public FTableRowBase
    {
        FInstancedStruct            EventConditional;           // 0x000008 (0x000010)
        TArray<FInstancedStruct>    EventRewards;               // 0x000018 (0x000010)
        TArray<FInstancedStruct>    OneTimeEventRewards;        // 0x000028 (0x000010)
        FText                       DisplayName;                // 0x000038 (0x000010)
        FText                       DisplayDescription;         // 0x000048 (0x000010)
        int32                       DisplayOrder;               // 0x000058 (0x000004) [Default: 186086210]
        EFortAccoladeType           AccoladeType;               // 0x00005C (0x000001) [Default: EFortAccoladeType(0)]
        EXPEventPriorityType        Priority;                   // 0x00005D (0x000001) [Default: EXPEventPriorityType(0)]
        EFortAccoladeTierType       AccoladeTier;               // 0x00005E (0x000001) [Default: EFortAccoladeTierType(0)]
        uint8                       UnknownByte_00005F;         // 0x00005F (0x000001)
        TSoftObjectPtr<USoundCue>   AwardedSoundCue;            // 0x000060 (0x000020) [Default: 0xD921AE]
        TSoftObjectPtr<UTexture2D>  PreviewImage;               // 0x000080 (0x000020) [Default: 0x9B9FEFC]
        int32                       MaxMatchCount;              // 0x0000A0 (0x000004) [Default: 2382604]
        int32                       MaxPlayerCount;             // 0x0000A4 (0x000004) [Default: 0]
        FGameplayTagContainer       Tags;                       // 0x0000A8 (0x000020)
        FGameplayTagQuery           ProductCompatibilityQuery;  // 0x0000C8 (0x000048)
    };
    // Size: 0x000018 (0x00000C)
    struct alignas(0x4) FFortCompletedAccoladeData : public FFastArraySerializerItem
    {
        FName               AccoladeRowName;                // 0x00000C (0x000004)
        uint32              XPAwarded;                      // 0x000010 (0x000004)
        EFortAccoladeType   AccoladeType;                   // 0x000014 (0x000001)
        uint8               UnknownData_000015[0x000003];   // 0x000015 (0x000003)
    };
    // Size: 0x000060 (0x000018)
    struct alignas(0x8) FFortCompletedAccoladeDataArray : public FFastArraySerializer
    {
        uint8                               UnknownData_000048[0x000008];   // 0x000048 (0x000008)
        TArray<FFortCompletedAccoladeData>  CompletedAccolades;             // 0x000050 (0x000010)
    };
    // Size: 0x000090 (0x000090)
    struct FFortTriggeredAccoladeData
    {
        uint8   UnknownData_000000[0x000090];   // 0x000000 (0x000090)
    };
    // Size: 0x000014 (0x000008)
    struct alignas(0x4) FFortUpdatedTrackedAccoladeData : public FFastArraySerializerItem
    {
        FName   AccoladeRowName;    // 0x00000C (0x000004)
        uint32  Count;              // 0x000010 (0x000004)
    };
    // Size: 0x000060 (0x000018)
    struct alignas(0x8) FFortUpdatedTrackedAccoladeDataArray : public FFastArraySerializer
    {
        uint8                                   UnknownData_000048[0x000008];   // 0x000048 (0x000008)
        TArray<FFortUpdatedTrackedAccoladeData> UpdatedTrackedAccolades;        // 0x000050 (0x000010)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FPFWAccoladeCollection_AchievedAccolade_PersistentInfoData
    {
        FString AccoladeName;                   // 0x000000 (0x000010)
        uint32  AccoladeCount;                  // 0x000010 (0x000004)
        uint8   UnknownData_000014[0x000004];   // 0x000014 (0x000004)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FPFWAccoladeCollection_PersistentInfo
    {
        TArray<FPFWAccoladeCollection_AchievedAccolade_PersistentInfoData>  AccoladeCollection_AchievedAccolades;       // 0x000000 (0x000010)
        FPFWAccoladeCollection_PinnedAccolade_PersistentInfoData            AccoladeCollection_PinnedAccolade;          // 0x000010 (0x000010)
        FPFWAccoladeCollection_UnacknowledgedAccolades_PersistentInfoData   AccoladeCollection_UnacknowledgedAccolades; // 0x000020 (0x000010)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FPFWAccoladeCollection_PinnedAccolade_PersistentInfoData
    {
        FString AccoladeName;   // 0x000000 (0x000010)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FPFWAccoladeCollection_UnacknowledgedAccolades_PersistentInfoData
    {
        TArray<FString> AccoladeNames;  // 0x000000 (0x000010)
    };
}

