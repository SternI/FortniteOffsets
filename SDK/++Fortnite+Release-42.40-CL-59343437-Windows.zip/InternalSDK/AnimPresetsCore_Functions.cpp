/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimPresetsCore_Functions
 * ============================================================
 */

#include "AnimPresetsCore_Functions.hpp"

namespace UE
{

    TSoftClassPtr<UClass> UAnimPreset::GetPresetClass()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimPresetsCore.AnimPreset.GetPresetClass");
    
        UAnimPreset___GetPresetClass_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAnimPreset::HandleAnimInstance(UAnimInstance* Instance)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimPresetsCore.AnimPreset.HandleAnimInstance");
    
        UAnimPreset___HandleAnimInstance_Params Params{};
        Params.Instance = Instance;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

