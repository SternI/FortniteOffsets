/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BeanstalkCosmeticsRuntime_Functions
 * ============================================================
 */

#include "BeanstalkCosmeticsRuntime_Functions.hpp"

namespace UE
{

    void ABeanFortPlayerMannequin::BP_UpdateCosmeticMaterials(UBeanCosmeticItemDefinitionBase* BeanCD, UMaterialInstanceDynamic* MaterialBody, UMaterialInstanceDynamic* MaterialCostume, UMaterialInstanceDynamic* MaterialHead)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkCosmeticsRuntime.BeanFortPlayerMannequin.BP_UpdateCosmeticMaterials");
    
        ABeanFortPlayerMannequin___BP_UpdateCosmeticMaterials_Params Params{};
        Params.BeanCD = BeanCD;
        Params.MaterialBody = MaterialBody;
        Params.MaterialCostume = MaterialCostume;
        Params.MaterialHead = MaterialHead;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UAthenaCharacterItemDefinition* UBeanAthenaCharacterItemDefinitionOverride::GetBeanCharacterFromCID(TSoftObjectPtr<UAthenaCharacterItemDefinition> CID)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkCosmeticsRuntime.BeanAthenaCharacterItemDefinitionOverride.GetBeanCharacterFromCID");
    
        UBeanAthenaCharacterItemDefinitionOverride___GetBeanCharacterFromCID_Params Params{};
        Params.CID = CID;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanAthenaCharacterItemDefinitionOverride* UBeanAthenaCharacterItemDefinitionOverride::GetBIDOFromCID(TSoftObjectPtr<UAthenaCharacterItemDefinition> CID)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkCosmeticsRuntime.BeanAthenaCharacterItemDefinitionOverride.GetBIDOFromCID");
    
        UBeanAthenaCharacterItemDefinitionOverride___GetBIDOFromCID_Params Params{};
        Params.CID = CID;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortCosmeticStep_ApplyBeanCD::BP_UpdateCosmeticMaterials(UBeanCosmeticItemDefinitionBase* BeanCD, UMaterialInstanceDynamic* MaterialBody, UMaterialInstanceDynamic* MaterialCostume, UMaterialInstanceDynamic* MaterialHead)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkCosmeticsRuntime.FortCosmeticStep_ApplyBeanCD.BP_UpdateCosmeticMaterials");
    
        UFortCosmeticStep_ApplyBeanCD___BP_UpdateCosmeticMaterials_Params Params{};
        Params.BeanCD = BeanCD;
        Params.MaterialBody = MaterialBody;
        Params.MaterialCostume = MaterialCostume;
        Params.MaterialHead = MaterialHead;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

