/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioSynesthesia
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000078 (0x000000)
    class UAudioSynesthesiaNRT : public UAudioAnalyzerNRT
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class UAudioSynesthesiaNRTSettings : public UAudioAnalyzerNRTSettings
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class UAudioSynesthesiaSettings : public UAudioAnalyzerSettings
    {
    public:
    };
    // Size: 0x0000F8 (0x000058)
    class alignas(0x8) UConstantQAnalyzer : public UAudioAnalyzer
    {
    public:
        UConstantQSettings*                             Settings;                       // 0x0000A0 (0x000008) [Default: 0x7FE838B38FC8]
        MULTI_INLINE_DELEGATE(OnConstantQResults)       OnConstantQResults;             // 0x0000A8 (0x000010)
        uint8                                           UnknownData_0000B8[0x000018];   // 0x0000B8 (0x000018)
        MULTI_INLINE_DELEGATE(OnLatestConstantQResults) OnLatestConstantQResults;       // 0x0000D0 (0x000010)
        uint8                                           UnknownData_0000E0[0x000018];   // 0x0000E0 (0x000018)
    
    public: // Functions
        void    GetCenterFrequencies(TArray<float>& OutCenterFrequencies); // 0x07FF3710 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        int32   GetNumCenterFrequencies(); // 0x10D3A46E [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000080 (0x000008)
    class alignas(0x8) UConstantQNRT : public UAudioSynesthesiaNRT
    {
    public:
        UConstantQNRTSettings*  Settings;   // 0x000078 (0x000008) [Default: 0x7FE838B390D8]
    
    public: // Functions
        void    GetChannelConstantQAtTime(float InSeconds, int32 InChannel, TArray<float>& OutConstantQ); // 0x07FF38E0 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        void    GetNormalizedChannelConstantQAtTime(float InSeconds, int32 InChannel, TArray<float>& OutConstantQ); // 0x07FF3C8E [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000048 (0x000020)
    class alignas(0x4) UConstantQNRTSettings : public UAudioSynesthesiaNRTSettings
    {
    public:
        float                       StartingFrequency;              // 0x000028 (0x000004) [Default: 40f]
        int32                       NumBands;                       // 0x00002C (0x000004) [Default: 48]
        float                       NumBandsPerOctave;              // 0x000030 (0x000004) [Default: 12f]
        float                       AnalysisPeriod;                 // 0x000034 (0x000004) [Default: 0.01f]
        bool                        bDownmixToMono;                 // 0x000038 (0x000001) [Default: false]
        EConstantQFFTSizeEnum       FFTSize;                        // 0x000039 (0x000001) [Default: EConstantQFFTSizeEnum(6)]
        EFFTWindowType              WindowType;                     // 0x00003A (0x000001) [Default: EFFTWindowType(3)]
        EAudioSpectrumType          SpectrumType;                   // 0x00003B (0x000001) [Default: EAudioSpectrumType(1)]
        float                       BandWidthStretch;               // 0x00003C (0x000004) [Default: 1f]
        EConstantQNormalizationEnum CQTNormalization;               // 0x000040 (0x000001) [Default: EConstantQNormalizationEnum(1)]
        uint8                       UnknownData_000041[0x000003];   // 0x000041 (0x000003)
        float                       NoiseFloorDb;                   // 0x000044 (0x000004) [Default: -60f]
    };
    // Size: 0x000048 (0x000020)
    class alignas(0x4) UConstantQSettings : public UAudioSynesthesiaSettings
    {
    public:
        float                       StartingFrequencyHz;            // 0x000028 (0x000004) [Default: 40f]
        int32                       NumBands;                       // 0x00002C (0x000004) [Default: 48]
        float                       NumBandsPerOctave;              // 0x000030 (0x000004) [Default: 12f]
        float                       AnalysisPeriodInSeconds;        // 0x000034 (0x000004) [Default: 0.01f]
        bool                        bDownmixToMono;                 // 0x000038 (0x000001) [Default: false]
        EConstantQFFTSizeEnum       FFTSize;                        // 0x000039 (0x000001) [Default: EConstantQFFTSizeEnum(6)]
        EFFTWindowType              WindowType;                     // 0x00003A (0x000001) [Default: EFFTWindowType(3)]
        EAudioSpectrumType          SpectrumType;                   // 0x00003B (0x000001) [Default: EAudioSpectrumType(1)]
        float                       BandWidthStretch;               // 0x00003C (0x000004) [Default: 1f]
        EConstantQNormalizationEnum CQTNormalization;               // 0x000040 (0x000001) [Default: EConstantQNormalizationEnum(1)]
        uint8                       UnknownData_000041[0x000003];   // 0x000041 (0x000003)
        float                       NoiseFloorDb;                   // 0x000044 (0x000004) [Default: -60f]
    };
    // Size: 0x000148 (0x0000A8)
    class alignas(0x8) ULKFSAnalyzer : public UAudioAnalyzer
    {
    public:
        ULKFSSettings*                                          Settings;                       // 0x0000A0 (0x000008) [Default: 0x7FE838B392A8]
        MULTI_INLINE_DELEGATE(OnOverallLKFSResults)             OnOverallLKFSResults;           // 0x0000A8 (0x000010)
        uint8                                                   UnknownData_0000B8[0x000018];   // 0x0000B8 (0x000018)
        MULTI_INLINE_DELEGATE(OnPerChannelLKFSResults)          OnPerChannelLKFSResults;        // 0x0000D0 (0x000010)
        uint8                                                   UnknownData_0000E0[0x000018];   // 0x0000E0 (0x000018)
        MULTI_INLINE_DELEGATE(OnLatestOverallLKFSResults)       OnLatestOverallLKFSResults;     // 0x0000F8 (0x000010)
        uint8                                                   UnknownData_000108[0x000018];   // 0x000108 (0x000018)
        MULTI_INLINE_DELEGATE(OnLatestPerChannelLKFSResults)    OnLatestPerChannelLKFSResults;  // 0x000120 (0x000010)
        uint8                                                   UnknownData_000130[0x000018];   // 0x000130 (0x000018)
    };
    // Size: 0x000080 (0x000008)
    class alignas(0x8) ULKFSNRT : public UAudioSynesthesiaNRT
    {
    public:
        ULKFSNRTSettings*   Settings;   // 0x000078 (0x000008) [Default: 0x7FE838B393A0]
    
    public: // Functions
        void                    GetChannelLoudnessAtTime(float InSeconds, int32 InChannel, float& OutLoudness); // 0x07FF403C [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        float                   GetGatedLoudness(); // 0x10D3C90E [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float                   GetGatedLoudnessForChannel(int32 InChannel); // 0x07FF43DE [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float                   GetIntegratedLoudness(); // 0x10D3CA7C [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float                   GetIntegratedLoudnessForChannel(int32 InChannel); // 0x07FF4554 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                    GetLoudnessAtTime(float InSeconds, float& OutLoudness); // 0x07FF46CA [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        TArray<FLKFSNRTResults> GetLoudnessData(); // 0x10D3CBE6 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FLKFSNRTResults         GetLoudnessDataAtTime(float InSeconds); // 0x07FF4962 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FLKFSNRTResults> GetLoudnessDataForChannel(int32 InChannel); // 0x07FF4AF0 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FLKFSNRTResults         GetLoudnessDataForChannelAtTime(float InSeconds, int32 InChannel); // 0x07FF4C9E [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x4) ULKFSNRTSettings : public UAudioSynesthesiaNRTSettings
    {
    public:
        float   AnalysisPeriod;                 // 0x000028 (0x000004) [Default: 0.1f]
        float   AnalysisWindowDuration;         // 0x00002C (0x000004) [Default: 0.4f]
        float   ShortTermLoudnessDuration;      // 0x000030 (0x000004) [Default: 3f]
        uint8   UnknownData_000034[0x000004];   // 0x000034 (0x000004)
    };
    // Size: 0x000040 (0x000018)
    class alignas(0x4) ULKFSSettings : public UAudioSynesthesiaSettings
    {
    public:
        float   AnalysisPeriod;                     // 0x000028 (0x000004) [Default: 0.1f]
        float   AnalysisWindowDuration;             // 0x00002C (0x000004) [Default: 0.4f]
        float   ShortTermLoudnessDuration;          // 0x000030 (0x000004) [Default: 3f]
        float   IntegratedLoudnessAnalysisPeriod;   // 0x000034 (0x000004) [Default: 1f]
        float   IntegratedLoudnessDuration;         // 0x000038 (0x000004) [Default: 60f]
        bool    bCalculatePerChannelLoudnessRange;  // 0x00003C (0x000001) [Default: false]
        bool    bCalculateOverallLoudnessRange;     // 0x00003D (0x000001) [Default: false]
        uint8   UnknownData_00003E[0x000002];       // 0x00003E (0x000002)
    };
    // Size: 0x0000E8 (0x000048)
    class alignas(0x8) ULoudnessAnalyzer : public UAudioAnalyzer
    {
    public:
        ULoudnessSettings*                                          Settings;                           // 0x0000A0 (0x000008) [Default: 0x7FE838B39500]
        MULTI_INLINE_DELEGATE(OnOverallLoudnessResults)             OnOverallLoudnessResults;           // 0x0000A8 (0x000010)
        MULTI_INLINE_DELEGATE(OnPerChannelLoudnessResults)          OnPerChannelLoudnessResults;        // 0x0000B8 (0x000010)
        MULTI_INLINE_DELEGATE(OnLatestOverallLoudnessResults)       OnLatestOverallLoudnessResults;     // 0x0000C8 (0x000010)
        MULTI_INLINE_DELEGATE(OnLatestPerChannelLoudnessResults)    OnLatestPerChannelLoudnessResults;  // 0x0000D8 (0x000010)
    };
    // Size: 0x000080 (0x000008)
    class alignas(0x8) ULoudnessNRT : public UAudioSynesthesiaNRT
    {
    public:
        ULoudnessNRTSettings*   Settings;   // 0x000078 (0x000008) [Default: 0x7FE838B39600]
    
    public: // Functions
        void    GetChannelLoudnessAtTime(float InSeconds, int32 InChannel, float& OutLoudness); // 0x07FF4F36 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        void    GetLoudnessAtTime(float InSeconds, float& OutLoudness); // 0x07FF52D8 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        void    GetNormalizedChannelLoudnessAtTime(float InSeconds, int32 InChannel, float& OutLoudness); // 0x07FF5570 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        void    GetNormalizedLoudnessAtTime(float InSeconds, float& OutLoudness); // 0x07FF5912 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000040 (0x000018)
    class alignas(0x4) ULoudnessNRTSettings : public UAudioSynesthesiaNRTSettings
    {
    public:
        float                       AnalysisPeriod;                 // 0x000028 (0x000004) [Default: 0.01f]
        float                       MinimumFrequency;               // 0x00002C (0x000004) [Default: 20f]
        float                       MaximumFrequency;               // 0x000030 (0x000004) [Default: 20000f]
        ELoudnessNRTCurveTypeEnum   CurveType;                      // 0x000034 (0x000001) [Default: ELoudnessNRTCurveTypeEnum(3)]
        uint8                       UnknownData_000035[0x000003];   // 0x000035 (0x000003)
        float                       NoiseFloorDb;                   // 0x000038 (0x000004) [Default: -60f]
        uint8                       UnknownData_00003C[0x000004];   // 0x00003C (0x000004)
    };
    // Size: 0x000040 (0x000018)
    class alignas(0x4) ULoudnessSettings : public UAudioSynesthesiaSettings
    {
    public:
        float                   AnalysisPeriod;                 // 0x000028 (0x000004) [Default: 0.01f]
        float                   MinimumFrequency;               // 0x00002C (0x000004) [Default: 20f]
        float                   MaximumFrequency;               // 0x000030 (0x000004) [Default: 20000f]
        ELoudnessCurveTypeEnum  CurveType;                      // 0x000034 (0x000001) [Default: ELoudnessCurveTypeEnum(3)]
        uint8                   UnknownData_000035[0x000003];   // 0x000035 (0x000003)
        float                   NoiseFloorDb;                   // 0x000038 (0x000004) [Default: -60f]
        float                   ExpectedMaxLoudness;            // 0x00003C (0x000004) [Default: 0f]
    };
    // Size: 0x000148 (0x0000A8)
    class alignas(0x8) UMeterAnalyzer : public UAudioAnalyzer
    {
    public:
        UMeterSettings*                                         Settings;                       // 0x0000A0 (0x000008) [Default: 0x7FE838B397D0]
        MULTI_INLINE_DELEGATE(OnOverallMeterResults)            OnOverallMeterResults;          // 0x0000A8 (0x000010)
        uint8                                                   UnknownData_0000B8[0x000018];   // 0x0000B8 (0x000018)
        MULTI_INLINE_DELEGATE(OnPerChannelMeterResults)         OnPerChannelMeterResults;       // 0x0000D0 (0x000010)
        uint8                                                   UnknownData_0000E0[0x000018];   // 0x0000E0 (0x000018)
        MULTI_INLINE_DELEGATE(OnLatestOverallMeterResults)      OnLatestOverallMeterResults;    // 0x0000F8 (0x000010)
        uint8                                                   UnknownData_000108[0x000018];   // 0x000108 (0x000018)
        MULTI_INLINE_DELEGATE(OnLatestPerChannelMeterResults)   OnLatestPerChannelMeterResults; // 0x000120 (0x000010)
        uint8                                                   UnknownData_000130[0x000018];   // 0x000130 (0x000018)
    };
    // Size: 0x000048 (0x000020)
    class alignas(0x4) UMeterSettings : public UAudioSynesthesiaSettings
    {
    public:
        float           AnalysisPeriod;                 // 0x000028 (0x000004) [Default: 0.01f]
        EMeterPeakType  PeakMode;                       // 0x00002C (0x000001) [Default: EMeterPeakType(1)]
        uint8           UnknownData_00002D[0x000003];   // 0x00002D (0x000003)
        int32           MeterAttackTime;                // 0x000030 (0x000004) [Default: 300]
        int32           MeterReleaseTime;               // 0x000034 (0x000004) [Default: 300]
        int32           PeakHoldTime;                   // 0x000038 (0x000004) [Default: 100]
        float           ClippingThreshold;              // 0x00003C (0x000004) [Default: 1f]
        bool            bIsAnalog;                      // 0x000040 (0x000001) [Default: true]
        uint8           UnknownData_000041[0x000007];   // 0x000041 (0x000007)
    };
    // Size: 0x000080 (0x000008)
    class alignas(0x8) UOnsetNRT : public UAudioSynesthesiaNRT
    {
    public:
        UOnsetNRTSettings*  Settings;   // 0x000078 (0x000008) [Default: 0x7FE838B398D8]
    
    public: // Functions
        void    GetChannelOnsetsBetweenTimes(float InStartSeconds, float InEndSeconds, int32 InChannel, TArray<float>& OutOnsetTimestamps, TArray<float>& OutOnsetStrengths); // 0x07FF5BAA [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        void    GetNormalizedChannelOnsetsBetweenTimes(float InStartSeconds, float InEndSeconds, int32 InChannel, TArray<float>& OutOnsetTimestamps, TArray<float>& OutOnsetStrengths); // 0x07FF6286 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000040 (0x000018)
    class alignas(0x4) UOnsetNRTSettings : public UAudioSynesthesiaNRTSettings
    {
    public:
        bool    bDownmixToMono;                 // 0x000028 (0x000001) [Default: false]
        uint8   UnknownData_000029[0x000003];   // 0x000029 (0x000003)
        float   GranularityInSeconds;           // 0x00002C (0x000004) [Default: 0.01f]
        float   Sensitivity;                    // 0x000030 (0x000004) [Default: 0.5f]
        float   MinimumFrequency;               // 0x000034 (0x000004) [Default: 20f]
        float   MaximumFrequency;               // 0x000038 (0x000004) [Default: 16000f]
        uint8   UnknownData_00003C[0x000004];   // 0x00003C (0x000004)
    };
    // Size: 0x000030 (0x000008)
    class alignas(0x4) USynesthesiaSpectrumAnalysisSettings : public UAudioSynesthesiaSettings
    {
    public:
        float               AnalysisPeriod; // 0x000028 (0x000004) [Default: 0.01f]
        EFFTSize            FFTSize;        // 0x00002C (0x000001) [Default: EFFTSize(0)]
        EAudioSpectrumType  SpectrumType;   // 0x00002D (0x000001) [Default: EAudioSpectrumType(1)]
        EFFTWindowType      WindowType;     // 0x00002E (0x000001) [Default: EFFTWindowType(2)]
        bool                bDownmixToMono; // 0x00002F (0x000001) [Default: true]
    };
    // Size: 0x0000F8 (0x000058)
    class alignas(0x8) USynesthesiaSpectrumAnalyzer : public UAudioAnalyzer
    {
    public:
        USynesthesiaSpectrumAnalysisSettings*           Settings;                       // 0x0000A0 (0x000008) [Default: 0x7FE838B39A40]
        MULTI_INLINE_DELEGATE(OnSpectrumResults)        OnSpectrumResults;              // 0x0000A8 (0x000010)
        uint8                                           UnknownData_0000B8[0x000018];   // 0x0000B8 (0x000018)
        MULTI_INLINE_DELEGATE(OnLatestSpectrumResults)  OnLatestSpectrumResults;        // 0x0000D0 (0x000010)
        uint8                                           UnknownData_0000E0[0x000018];   // 0x0000E0 (0x000018)
    
    public: // Functions
        void    GetCenterFrequencies(float InSampleRate, TArray<float>& OutCenterFrequencies); // 0x07FF69D4 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        int32   GetNumCenterFrequencies(); // 0x10D3F2EC [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FConstantQResults
    {
        float           TimeSeconds;                    // 0x000000 (0x000004)
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<float>   SpectrumValues;                 // 0x000008 (0x000010)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x4) FLoudnessResults
    {
        float   Loudness;           // 0x000000 (0x000004)
        float   NormalizedLoudness; // 0x000004 (0x000004)
        float   PerceptualEnergy;   // 0x000008 (0x000004)
        float   TimeSeconds;        // 0x00000C (0x000004)
    };
    // Size: 0x000014 (0x000014)
    struct alignas(0x4) FMeterResults
    {
        float   TimeSeconds;        // 0x000000 (0x000004)
        float   MeterValue;         // 0x000004 (0x000004)
        float   PeakValue;          // 0x000008 (0x000004)
        int32   NumSamplesClipping; // 0x00000C (0x000004)
        float   ClippingValue;      // 0x000010 (0x000004)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FSynesthesiaSpectrumResults
    {
        float           TimeSeconds;                    // 0x000000 (0x000004)
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<float>   SpectrumValues;                 // 0x000008 (0x000010)
    };
}

