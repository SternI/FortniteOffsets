/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArcadeMinigamesUI_Functions
 * ============================================================
 */

#include "ArcadeMinigamesUI.hpp"

namespace UE
{

    struct UArcadeMinigame2DWidget___SetPaused_Params
    {
        bool    bPause; // 0x000000 (0x000001) [Default: true]
    };

    struct UArcadeMinigame2DWidget___SetScoreFont_Params
    {
        FName   FontName;       // 0x000000 (0x000004) [OutParam] [Default: FName(344569472) -> L""]
        int32   DefaultSize;    // 0x000004 (0x000004) [Default: 0]
    };

    struct UArcadeMinigameWidget___HasAnyControlAction_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UArcadeMinigameWidget___HasMovementControl_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UArcadeMinigameWidget___HasPrimaryControl_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UArcadeMinigameWidget___HasSecondaryControl_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UArcadeMobileControlOverlayWidget___HasExitControl_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UArcadeMobileControlOverlayWidget___HasMovementControl_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UArcadeMobileControlOverlayWidget___HasPrimaryControl_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UArcadeMobileControlOverlayWidget___HasSecondaryControl_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UArcadeMobileControlOverlayWidget___InjectMovement_Params
    {
        FVector2D   Value;  // 0x000000 (0x000010)
    };

    struct UArcadeMobileJoystickWidget___GetCurrentValue_Params
    {
        FVector2D   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UArcadeVolleyWidget___OnMatchEnded_Params
    {
        int32   WinnerPlayerIndex;  // 0x000000 (0x000004) [Default: 344575328]
    };

    struct UArcadeVolleyWidget___OnPlayerScored_Params
    {
        int32   PlayerIndex;    // 0x000000 (0x000004) [Default: 344575328]
    };

    struct UBoostBallScreen___SetStickInput_Params
    {
        FVector2D   Stick;  // 0x000000 (0x000010)
    };

} // namespace UE

