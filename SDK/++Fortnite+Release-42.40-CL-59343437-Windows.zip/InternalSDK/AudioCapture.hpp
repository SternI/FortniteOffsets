/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioCapture
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000070 (0x000008)
    class UAudioCapture : public UAudioGenerator
    {
    public:
        uint8   UnknownData_000068[0x000008];   // 0x000068 (0x000008)
    
    public: // Functions
        bool    GetAudioCaptureDeviceInfo(FAudioCaptureDeviceInfo& OutInfo); // 0x07FE870C [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        bool    IsCapturingAudio(); // 0x10D27F5A [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    StartCapturingAudio(); // 0x10D27F84 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    StopCapturingAudio(); // 0x10D27FC0 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class UAudioCaptureBlueprintLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FString Conv_AudioInputDeviceInfoToString(FAudioInputDeviceInfo& Info); // 0x07FE889C [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static void    GetAvailableAudioInputDevices(UObject* WorldContextObject, OnAudioInputDevicesObtained& OnObtainDevicesEvent); // 0x07FE8ADC [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x0006E0 (0x0000C0)
    class alignas(0x4) UAudioCaptureComponent : public USynthComponent
    {
    public:
        int32   JitterLatencyFrames;            // 0x000620 (0x000004) [Default: 0]
        uint8   UnknownData_000624[0x0000BC];   // 0x000624 (0x0000BC)
    };
    // Size: 0x000028 (0x000000)
    class UAudioCaptureFunctionLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static UAudioCapture*  CreateAudioCapture(); // 0x10D27FFC [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FAudioCaptureDeviceInfo
    {
        FName   DeviceName;         // 0x000000 (0x000004)
        int32   NumInputChannels;   // 0x000004 (0x000004)
        int32   SampleRate;         // 0x000008 (0x000004)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FAudioInputDeviceInfo
    {
        FString DeviceName;                     // 0x000000 (0x000010)
        FString DeviceID;                       // 0x000010 (0x000010)
        int32   InputChannels;                  // 0x000020 (0x000004)
        int32   PreferredSampleRate;            // 0x000024 (0x000004)
        uint8   bSupportsHardwareAEC : 1;       // 0x000028 (0x000001) : 0x0
        uint8   UnknownBit_000028_1 : 1;        // 0x000028 (0x000001) : 0x1
        uint8   UnknownBit_000028_2 : 1;        // 0x000028 (0x000001) : 0x2
        uint8   UnknownBit_000028_3 : 1;        // 0x000028 (0x000001) : 0x3
        uint8   UnknownBit_000028_4 : 1;        // 0x000028 (0x000001) : 0x4
        uint8   UnknownBit_000028_5 : 1;        // 0x000028 (0x000001) : 0x5
        uint8   UnknownBit_000028_6 : 1;        // 0x000028 (0x000001) : 0x6
        uint8   UnknownBit_000028_7 : 1;        // 0x000028 (0x000001) : 0x7
        uint8   UnknownData_000029[0x000007];   // 0x000029 (0x000007)
    };
}

