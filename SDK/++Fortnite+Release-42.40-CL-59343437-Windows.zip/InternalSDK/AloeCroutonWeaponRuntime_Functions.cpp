/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AloeCroutonWeaponRuntime_Functions
 * ============================================================
 */

#include "AloeCroutonWeaponRuntime_Functions.hpp"

namespace UE
{

    float UFortChargingSet_AloeCrouton::GetCooldownDuration()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AloeCroutonWeaponRuntime.FortChargingSet_AloeCrouton.GetCooldownDuration");
    
        UFortChargingSet_AloeCrouton___GetCooldownDuration_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UFortChargingSet_AloeCrouton::GetCooldownRemaining()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AloeCroutonWeaponRuntime.FortChargingSet_AloeCrouton.GetCooldownRemaining");
    
        UFortChargingSet_AloeCrouton___GetCooldownRemaining_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortChargingSet_AloeCrouton::OnRep_Charge(FFortGameplayAttributeData& OldValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AloeCroutonWeaponRuntime.FortChargingSet_AloeCrouton.OnRep_Charge");
    
        UFortChargingSet_AloeCrouton___OnRep_Charge_Params Params{};
        Params.OldValue = OldValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OldValue = Params.OldValue;
    }

    void UFortCosmeticStatObject_AloeCroutonCharge::HandleChargeCountChanged(float OldChargeCount, float NewChargeCount, TWeakObjectPtr<AFortPlayerController> PlayerController)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AloeCroutonWeaponRuntime.FortCosmeticStatObject_AloeCroutonCharge.HandleChargeCountChanged");
    
        UFortCosmeticStatObject_AloeCroutonCharge___HandleChargeCountChanged_Params Params{};
        Params.OldChargeCount = OldChargeCount;
        Params.NewChargeCount = NewChargeCount;
        Params.PlayerController = PlayerController;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

