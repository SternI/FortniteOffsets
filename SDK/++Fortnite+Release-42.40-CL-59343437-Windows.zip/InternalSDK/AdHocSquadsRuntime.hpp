/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AdHocSquadsRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000128 (0x000018)
    class alignas(0x8) UAdHocSquadPawnOutlineComponent : public UPawnOutlineComponentBase
    {
    public:
        TWeakObjectPtr<AFortAthenaMutator_AdHocSquads>  CachedAdHocSquadsMutator;       // 0x000110 (0x000008) [Default: nullptr]
        uint8                                           UnknownData_000118[0x000008];   // 0x000118 (0x000008)
        uint8                                           AdHocSquadId;                   // 0x000120 (0x000001) [Default: 255]
        bool                                            bIsInLocalAdHocSquad;           // 0x000121 (0x000001) [Default: false]
        uint8                                           UnknownData_000122[0x000006];   // 0x000122 (0x000006)
    
    public: // Functions
        void    HandlePlayerSquadChanged(AFortPlayerStateAthena* InPlayerState, uint8 PreviousSquadId); // 0x07ECF9B4 [Final | Native | Private]
        void    OnRep_AdHocSquadId(uint8 PreviousAdHocSquadId); // 0x07ECFC26 [Final | Native | Private]
    };
}

