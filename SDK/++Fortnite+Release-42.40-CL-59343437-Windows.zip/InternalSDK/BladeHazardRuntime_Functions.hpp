/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BladeHazardRuntime_Functions
 * ============================================================
 */

#include "BladeHazardRuntime.hpp"

namespace UE
{

    struct AFortBladeHazard___GetForceDirectionForHit_Params
    {
        FHitResult  Hit;            // 0x000000 (0x0000F8) [OutParam]
        FVector     ReturnValue;    // 0x0000F8 (0x000018) [ReturnValue]
    };

} // namespace UE

