/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimToTexture_Functions
 * ============================================================
 */

#include "AnimToTexture_Functions.hpp"

namespace UE
{

    UTexture2D* UAnimToTextureDataAsset::BP_GetBonePositionTexture()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimToTexture.AnimToTextureDataAsset.BP_GetBonePositionTexture");
    
        UAnimToTextureDataAsset___BP_GetBonePositionTexture_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UTexture2D* UAnimToTextureDataAsset::BP_GetBoneRotationTexture()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimToTexture.AnimToTextureDataAsset.BP_GetBoneRotationTexture");
    
        UAnimToTextureDataAsset___BP_GetBoneRotationTexture_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UTexture2D* UAnimToTextureDataAsset::BP_GetBoneWeightTexture()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimToTexture.AnimToTextureDataAsset.BP_GetBoneWeightTexture");
    
        UAnimToTextureDataAsset___BP_GetBoneWeightTexture_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    USkeletalMesh* UAnimToTextureDataAsset::BP_GetSkeletalMesh()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimToTexture.AnimToTextureDataAsset.BP_GetSkeletalMesh");
    
        UAnimToTextureDataAsset___BP_GetSkeletalMesh_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UStaticMesh* UAnimToTextureDataAsset::BP_GetStaticMesh()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimToTexture.AnimToTextureDataAsset.BP_GetStaticMesh");
    
        UAnimToTextureDataAsset___BP_GetStaticMesh_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAnimToTextureDataAsset::GetIndexFromAnimSequence(UAnimSequence* Sequence)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimToTexture.AnimToTextureDataAsset.GetIndexFromAnimSequence");
    
        UAnimToTextureDataAsset___GetIndexFromAnimSequence_Params Params{};
        Params.Sequence = Sequence;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAnimToTextureDataAsset::ResetInfo()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimToTexture.AnimToTextureDataAsset.ResetInfo");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    bool UAnimToTextureInstancePlaybackLibrary::BatchUpdateInstancesAutoPlayData(UInstancedStaticMeshComponent* InstancedMeshComponent, TArray<FAnimToTextureAutoPlayData>& AutoPlayData, TArray<FTransform>& Transforms, bool bMarkRenderStateDirty)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimToTexture.AnimToTextureInstancePlaybackLibrary.BatchUpdateInstancesAutoPlayData");
    
        UAnimToTextureInstancePlaybackLibrary___BatchUpdateInstancesAutoPlayData_Params Params{};
        Params.InstancedMeshComponent = InstancedMeshComponent;
        Params.AutoPlayData = AutoPlayData;
        Params.Transforms = Transforms;
        Params.bMarkRenderStateDirty = bMarkRenderStateDirty;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        AutoPlayData = Params.AutoPlayData;
        Transforms = Params.Transforms;
    
        return Params.ReturnValue;
    }

    bool UAnimToTextureInstancePlaybackLibrary::BatchUpdateInstancesFrameData(UInstancedStaticMeshComponent* InstancedMeshComponent, TArray<FAnimToTextureFrameData>& FrameData, TArray<FTransform>& Transforms, bool bMarkRenderStateDirty)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimToTexture.AnimToTextureInstancePlaybackLibrary.BatchUpdateInstancesFrameData");
    
        UAnimToTextureInstancePlaybackLibrary___BatchUpdateInstancesFrameData_Params Params{};
        Params.InstancedMeshComponent = InstancedMeshComponent;
        Params.FrameData = FrameData;
        Params.Transforms = Transforms;
        Params.bMarkRenderStateDirty = bMarkRenderStateDirty;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        FrameData = Params.FrameData;
        Transforms = Params.Transforms;
    
        return Params.ReturnValue;
    }

    bool UAnimToTextureInstancePlaybackLibrary::GetAutoPlayDataFromDataAsset(UAnimToTextureDataAsset* DataAsset, int32 AnimationIndex, FAnimToTextureAutoPlayData& AutoPlayData, float TimeOffset, float PlayRate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimToTexture.AnimToTextureInstancePlaybackLibrary.GetAutoPlayDataFromDataAsset");
    
        UAnimToTextureInstancePlaybackLibrary___GetAutoPlayDataFromDataAsset_Params Params{};
        Params.DataAsset = DataAsset;
        Params.AnimationIndex = AnimationIndex;
        Params.AutoPlayData = AutoPlayData;
        Params.TimeOffset = TimeOffset;
        Params.PlayRate = PlayRate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        AutoPlayData = Params.AutoPlayData;
    
        return Params.ReturnValue;
    }

    float UAnimToTextureInstancePlaybackLibrary::GetFrame(float time, float StartFrame, float EndFrame, float TimeOffset, float PlayRate, float SampleRate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimToTexture.AnimToTextureInstancePlaybackLibrary.GetFrame");
    
        UAnimToTextureInstancePlaybackLibrary___GetFrame_Params Params{};
        Params.time = time;
        Params.StartFrame = StartFrame;
        Params.EndFrame = EndFrame;
        Params.TimeOffset = TimeOffset;
        Params.PlayRate = PlayRate;
        Params.SampleRate = SampleRate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAnimToTextureInstancePlaybackLibrary::GetFrameDataFromDataAsset(UAnimToTextureDataAsset* DataAsset, int32 AnimationIndex, float time, FAnimToTextureFrameData& FrameData, float TimeOffset, float PlayRate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimToTexture.AnimToTextureInstancePlaybackLibrary.GetFrameDataFromDataAsset");
    
        UAnimToTextureInstancePlaybackLibrary___GetFrameDataFromDataAsset_Params Params{};
        Params.DataAsset = DataAsset;
        Params.AnimationIndex = AnimationIndex;
        Params.time = time;
        Params.FrameData = FrameData;
        Params.TimeOffset = TimeOffset;
        Params.PlayRate = PlayRate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        FrameData = Params.FrameData;
    
        return Params.ReturnValue;
    }

    bool UAnimToTextureInstancePlaybackLibrary::SetupInstancedMeshComponent(UInstancedStaticMeshComponent* InstancedMeshComponent, int32 NumInstances, bool bAutoPlay)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimToTexture.AnimToTextureInstancePlaybackLibrary.SetupInstancedMeshComponent");
    
        UAnimToTextureInstancePlaybackLibrary___SetupInstancedMeshComponent_Params Params{};
        Params.InstancedMeshComponent = InstancedMeshComponent;
        Params.NumInstances = NumInstances;
        Params.bAutoPlay = bAutoPlay;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAnimToTextureInstancePlaybackLibrary::UpdateInstanceAutoPlayData(UInstancedStaticMeshComponent* InstancedMeshComponent, int32 InstanceIndex, FAnimToTextureAutoPlayData& AutoPlayData, bool bMarkRenderStateDirty)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimToTexture.AnimToTextureInstancePlaybackLibrary.UpdateInstanceAutoPlayData");
    
        UAnimToTextureInstancePlaybackLibrary___UpdateInstanceAutoPlayData_Params Params{};
        Params.InstancedMeshComponent = InstancedMeshComponent;
        Params.InstanceIndex = InstanceIndex;
        Params.AutoPlayData = AutoPlayData;
        Params.bMarkRenderStateDirty = bMarkRenderStateDirty;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        AutoPlayData = Params.AutoPlayData;
    
        return Params.ReturnValue;
    }

    bool UAnimToTextureInstancePlaybackLibrary::UpdateInstanceFrameData(UInstancedStaticMeshComponent* InstancedMeshComponent, int32 InstanceIndex, FAnimToTextureFrameData& FrameData, bool bMarkRenderStateDirty)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimToTexture.AnimToTextureInstancePlaybackLibrary.UpdateInstanceFrameData");
    
        UAnimToTextureInstancePlaybackLibrary___UpdateInstanceFrameData_Params Params{};
        Params.InstancedMeshComponent = InstancedMeshComponent;
        Params.InstanceIndex = InstanceIndex;
        Params.FrameData = FrameData;
        Params.bMarkRenderStateDirty = bMarkRenderStateDirty;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        FrameData = Params.FrameData;
    
        return Params.ReturnValue;
    }

} // namespace UE

