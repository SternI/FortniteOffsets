/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AndroidPermission_Functions
 * ============================================================
 */

#include "AndroidPermission_Functions.hpp"

namespace UE
{

    UAndroidPermissionCallbackProxy* UAndroidPermissionFunctionLibrary::AcquirePermissions(TArray<FString>& permissions)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AndroidPermission.AndroidPermissionFunctionLibrary.AcquirePermissions");
    
        UAndroidPermissionFunctionLibrary___AcquirePermissions_Params Params{};
        Params.permissions = permissions;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        permissions = Params.permissions;
    
        return Params.ReturnValue;
    }

    bool UAndroidPermissionFunctionLibrary::CheckPermission(FString permission)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AndroidPermission.AndroidPermissionFunctionLibrary.CheckPermission");
    
        UAndroidPermissionFunctionLibrary___CheckPermission_Params Params{};
        Params.permission = permission;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

} // namespace UE

