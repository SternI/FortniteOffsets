/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AIPrompt
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000270 (0x000000)
    class ALLMPersonaActor : public AActor
    {
    public:
    };
    // Size: 0x0002C8 (0x000050)
    class alignas(0x8) UAIPromptOratorInputControllerComponent : public UPersonaOratorInputControllerComponent
    {
    public:
        TOptional<FGuid>        ActiveConversationID;           // 0x000278 (0x000014)
        uint8                   UnknownData_00028C[0x000004];   // 0x00028C (0x000004)
        APlayerController*      CachedPlayerController;         // 0x000290 (0x000008) [Default: nullptr]
        uint8                   UnknownData_000298[0x000008];   // 0x000298 (0x000008)
        UInputMappingContext*   AIPromptInputMappingContext;    // 0x0002A0 (0x000008) [Default: nullptr]
        UInputAction*           PushToTalkAction;               // 0x0002A8 (0x000008) [Default: nullptr]
        uint8                   UnknownData_0002B0[0x000018];   // 0x0002B0 (0x000018)
    
    public: // Functions
        void    ClearActiveConversationID(); // 0x0E77C2DC [Net | NetReliable | Native | Event | Public | NetClient | BlueprintCallable]
        void    ClearPTTTimer(); // 0x10ECF1CC [Final | Native | Private]
        void    OnEnableInput(bool InInputEnabled); // 0x081D0AFA [Final | Native | Protected]
        void    OnMuteChangedEvent(); // 0x10ECF5A2 [Final | Native | Private]
        void    OnSetInHearingRange(bool bInInHearingRange); // 0x081D0C6A [Final | Native | Private]
        void    PushToTalkEnded(FInputActionInstance& ActionData); // 0x081D0DDA [Final | Native | Private | HasOutParms]
        void    SetActiveConversationID(FGuid InActiveConversationID); // 0x081D0FBC [Net | NetReliable | Native | Event | Public | HasDefaults | NetClient | BlueprintCallable]
        void    SetInHearingRange(bool InInHearingRange); // 0x063769A4 [Net | NetReliable | Native | Event | Public | NetClient | BlueprintCallable]
        void    SetInputEnabled(bool InInputEnabled); // 0x081D1138 [Net | NetReliable | Native | Event | Public | NetClient | BlueprintCallable]
        void    StartPushToTalk(FInputActionInstance& ActionData); // 0x081D12B0 [Final | Native | Private | HasOutParms]
        void    StartvoiceRecording(); // 0x10ECFB76 [Final | Native | Private]
        void    StopVoiceRecording(); // 0x10ECFCEE [Final | Native | Private]
    };
    // Size: 0x000080 (0x000018)
    class alignas(0x8) UAIPromptSubtitleViewModel : public UMVVMViewModelBase
    {
    public:
        FText   Text;                           // 0x000068 (0x000010)
        bool    Show;                           // 0x000078 (0x000001) [Default: false]
        bool    AudioPlayback;                  // 0x000079 (0x000001) [Default: false]
        uint8   UnknownData_00007A[0x000006];   // 0x00007A (0x000006)
    };
    // Size: 0x000050 (0x000028)
    class alignas(0x8) UCharacterPersonaAsset : public UDataAsset
    {
    public:
        void**          VTable_000028;                  // 0x000028 (0x000008) VTable [19 slots] -> 0x133FF600
        void**          VTable_000030;                  // 0x000030 (0x000008) VTable [2 slots] -> 0x147D01D0
        UClass*         VoiceModel;                     // 0x000038 (0x000008) [Default: nullptr]
        UPersonaPrompt* CharacterPrompt;                // 0x000040 (0x000008) [Default: 0x7FE838AA0490]
        bool            bIsFinalPersonaData;            // 0x000048 (0x000001) [Default: false]
        uint8           UnknownData_000049[0x000007];   // 0x000049 (0x000007)
    };
    // Size: 0x000098 (0x000000)
    class UCharacterPersonaAssetBindingDataTable : public UDataTable
    {
    public:
    };
    // Size: 0x000080 (0x000048)
    class alignas(0x8) UConversationTargetWorldSubsystem : public UWorldSubsystem
    {
    public:
        void**                                      VTable_000038;                  // 0x000038 (0x000008) VTable [131 slots] -> 0x147D1990
        uint8                                       UnknownData_000040[0x000030];   // 0x000040 (0x000030)
        TArray<ULLMPersonaConversationComponent*>   Conversations;                  // 0x000070 (0x000010)
    };
    // Size: 0x000328 (0x000020)
    class UFortAIPromptContainerBase : public UUserWidget
    {
    public:
        uint8   UnknownData_000308[0x000020];   // 0x000308 (0x000020)
    
    public: // Functions
        void            AddStatusWidget(FGuid& ConversationId, FPersonaUIWidgetLayoutDefinition& WidgetLayoutDefinition, UUserWidget* StatusWidget); // 0x000545D2 [Event | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintEvent]
        void            AddSubtitleWidget(UUserWidget* CustomSubtitleWidget); // 0x000545D2 [Event | Protected | BlueprintCallable | BlueprintEvent]
        UUserWidget*    GetSubtitleWidgetFromConversationID(FGuid& ConversationId); // 0x081D02DC [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        void            RemoveStatusWidget(FGuid& ConversationId); // 0x000545D2 [Event | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintEvent]
        void            RemoveSubtitleWidget(UUserWidget* CustomSubtitleWidget); // 0x000545D2 [Event | Protected | BlueprintCallable | BlueprintEvent]
    };
    // Size: 0x000040 (0x000018)
    class alignas(0x8) UFortPersonaListEntry : public UObject
    {
    public:
        UTexture2D*     Icon;   // 0x000028 (0x000008) [Default: nullptr]
        FLinearColor    Color;  // 0x000030 (0x000010)
    };
    // Size: 0x000210 (0x000030)
    class ULLMConversation : public ULLMPersonaConversationComponent
    {
    public:
        uint8   UnknownData_0001E0[0x000030];   // 0x0001E0 (0x000030)
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x8) ULLMFactDataAsset : public UDataAsset
    {
    public:
        TArray<FLLMFactTableRow>    FactRows;   // 0x000028 (0x000010)
    };
    // Size: 0x0001E0 (0x0001B8)
    class alignas(0x8) ULLMPersonaConversationComponent : public UObject
    {
    public:
        void**                                                                              VTable_000028;                              // 0x000028 (0x000008) VTable [29 slots] -> 0x147D28C0
        void**                                                                              VTable_000030;                              // 0x000030 (0x000008) VTable [9 slots] -> 0x147D2960
        uint8                                                                               UnknownData_000038[0x000008];               // 0x000038 (0x000008)
        MULTI_INLINE_DELEGATE(ResponseSuccessDelegate)                                      OnResponseSuccess;                          // 0x000040 (0x000010)
        MULTI_INLINE_DELEGATE(PersonaUtteranceStartedDelegate)                              OnPersonaUtteranceStarted;                  // 0x000050 (0x000010)
        MULTI_INLINE_DELEGATE(PersonaUtteranceEndedDelegate)                                OnPersonaUtteranceStopped;                  // 0x000060 (0x000010)
        MULTI_INLINE_DELEGATE(PersonaUtteranceCancelledDelegate)                            OnPersonaUtteranceCancelled;                // 0x000070 (0x000010)
        UClass*                                                                             MonologuePawnClass;                         // 0x000080 (0x000008) [Default: nullptr]
        FChatCompletionSafetySettings                                                       ChatCompletionSafetySettings;               // 0x000088 (0x000010)
        UCharacterPersonaAssetBindingDataTable*                                             CharacterPersonaAssetBindings;              // 0x000098 (0x000008) [Default: nullptr]
        USoundClass*                                                                        PersonaVoiceSoundClass;                     // 0x0000A0 (0x000008) [Default: nullptr]
        UClass*                                                                             PersonaUIComponentClass;                    // 0x0000A8 (0x000008) [Default: nullptr]
        UCreativeRegisteredPlayersManagerComponent*                                         CreativeRegisteredPlayersManagerComponent;  // 0x0000B0 (0x000008) [Default: 0x7FE838AA0CB8]
        FGuid                                                                               ConversationId;                             // 0x0000B8 (0x000010)
        uint8                                                                               UnknownData_0000C8[0x000018];               // 0x0000C8 (0x000018)
        MULTI_INLINE_DELEGATE(OnPersonaCriteriaEvaluatedTrue)                               OnPersonaCriteriaEvaluatedTrue;             // 0x0000E0 (0x000010)
        uint8                                                                               UnknownData_0000F0[0x000010];               // 0x0000F0 (0x000010)
        TMap<TWeakObjectPtr<APlayerController>, UAIPromptOratorInputControllerComponent*>   CachedPlayerSessionMap;                     // 0x000100 (0x000010)
        uint8                                                                               UnknownData_000110[0x000090];               // 0x000110 (0x000090)
        FString                                                                             DefaultMonologuePawnClass;                  // 0x0001A0 (0x000010) [Default: L"/Script/Engine.BlueprintGeneratedClass'/CRD_AIPrompt/Monologue/MonologuePawn.MonologuePawn_C'"]
        FString                                                                             DefaultPersonaUIComponentClass;             // 0x0001B0 (0x000010) [Default: L"/Script/Engine.BlueprintGeneratedClass'/CRD_AIPrompt/UI/PersonaDeviceUIControllerComponent.PersonaDeviceUIControllerComponent_C'"]
        FString                                                                             DefaultPersonaVoiceSoundClass;              // 0x0001C0 (0x000010) [Default: L"/Script/Engine.SoundClass'/Game/Sounds/FortSoundClassesAndModes/Fort_Persona.Fort_Persona'"]
        FString                                                                             DefaultCharacterPersonaAssetBindings;       // 0x0001D0 (0x000010) [Default: L"/Script/AIPrompt.CharacterPersonaAssetBindingDataTable'/CRD_AIPrompt/Personas/CharacterPersonaAssetBindingDataTable.CharacterPersonaAssetBindingDataTable'"]
    
    public: // Functions
        void                        AddPlayerToPromptList(AController* Controller); // 0x081D3BB8 [Final | Native | Public | BlueprintCallable]
        void                        AddSessionFacts(FLLMFacts& LLMFacts); // 0x081D3D26 [Final | Native | Public | HasOutParms | BlueprintCallable]
        void                        AssignLLMPersonas(TArray<FLLMPersona> InPersonas, FLLMPersona InDefaultPersona); // 0x081D3ECC [Final | Native | Public | BlueprintCallable]
        void                        BindDefaultPersonaToPawn(APawn* Pawn); // 0x081D41DC [Final | Native | Public | BlueprintCallable]
        void                        Cleanup(); // 0x10ED9F5A [Final | Native | Public | BlueprintCallable]
        void                        FireAnalyticsEvent_PersonaDeviceSettings(bool bUseCustomWidget, bool bUseSubtitles); // 0x044C8FB6 [Final | Native | Public | BlueprintCallable]
        TArray<APlayerController*>  GetParticipantPlayerControllers(); // 0x10ED9F70 [Final | Native | Public | BlueprintCallable]
        void                        OnPlayerVoiceInputStarted(UOratorInputControllerComponent* OratorInputControllerComponent); // 0x081D434A [Final | Native | Private]
        void                        OnPlayerVoiceInputStopped(UOratorInputControllerComponent* OratorInputControllerComponent); // 0x081D44B8 [Final | Native | Private]
        void                        OpenSession(); // 0x10EDA3C8 [Final | Native | Public | BlueprintCallable]
        void                        PostRoundCleanup(); // 0x0CA02B1A [Final | Native | Public | BlueprintCallable]
        void                        RegisterPlayer(AController* Controller, FPersonaUIParams PersonaUIParams); // 0x081D4626 [Final | Native | Public | BlueprintCallable]
        void                        RemoveAllPlayerFromPromptList(); // 0x10EDA3DE [Final | Native | Public | BlueprintCallable]
        void                        RemovePlayerFromOtherConvos(AController* Controller); // 0x081D4960 [Final | Native | Public | BlueprintCallable]
        void                        RemovePlayerFromPromptList(AController* Controller); // 0x081D4ACE [Final | Native | Public | BlueprintCallable]
        void                        SendDefaultPrompt(FString DefaultPrompt); // 0x081D4C3C [Final | Native | Public | BlueprintCallable]
        void                        SetInterruptBehavior(EInterruptBehavior InInterruptBehavior); // 0x081D4E22 [Final | Native | Public | BlueprintCallable]
        void                        SetResponseEventCriteria(TArray<FResponseEventCriteria>& InResponseEventCriteria); // 0x081D4F8C [Final | Native | Public | HasOutParms | BlueprintCallable]
        void                        StopPersonaVoice(); // 0x10EDA9B4 [Final | Native | Public | BlueprintCallable]
        void                        UnregisterAllPlayers(); // 0x10EDAA66 [Final | Native | Public | BlueprintCallable]
        void                        UnregisterPlayer(AController* Controller); // 0x081D512A [Final | Native | Public | BlueprintCallable]
        void                        UpdateInstigatorBlockList(APlayerController* Instigator, TArray<FUniqueNetIdRepl>& BlockList); // 0x081D5298 [Final | Native | Private | HasOutParms]
    };
    // Size: 0x0000C8 (0x000008)
    class alignas(0x8) ULLMPersonaConversationComponentHolder : public UActorComponent
    {
    public:
        ULLMPersonaConversationComponent*   LLMPersonaConversationComponent;    // 0x0000C0 (0x000008) [Default: nullptr]
    
    public: // Functions
        ULLMPersonaConversationComponent*   GetLLMPersonaConversationComponent(); // 0x0CBFB83E [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x8) ULLMVoicePreviewMappingDataAsset : public UDataAsset
    {
    public:
        TArray<FLLMVoicePreviewMapping> VoicePreviewSounds; // 0x000028 (0x000010)
    };
    // Size: 0x0000A8 (0x000080)
    class alignas(0x8) UNPCCharacterModifier_Persona : public UNPCCharacterModifier
    {
    public:
        void**                                                  VTable_000028;                  // 0x000028 (0x000008) VTable [4 slots] -> 0x147D3D38
        void**                                                  VTable_000030;                  // 0x000030 (0x000008) VTable [2 slots] -> 0x147D3D48
        uint8                                                   bOverrideCosmeticFacts : 1;     // 0x000038 (0x000001) : 0x0 [Default: true]
        uint8                                                   bPreviewAudioRange : 1;         // 0x000038 (0x000001) : 0x0 [Default: true]
        uint8                                                   bEnableFacialAnimations : 1;    // 0x000038 (0x000001) : 0x0 [Default: true]
        uint8                                                   bOverrideBoundPersonaData : 1;  // 0x000038 (0x000001) : 0x0 [Default: true]
        uint8                                                   UnknownBit_000038_1 : 1;        // 0x000038 (0x000001) : 0x1
        uint8                                                   UnknownBit_000038_2 : 1;        // 0x000038 (0x000001) : 0x2
        uint8                                                   UnknownBit_000038_3 : 1;        // 0x000038 (0x000001) : 0x3
        uint8                                                   UnknownBit_000038_4 : 1;        // 0x000038 (0x000001) : 0x4
        uint8                                                   UnknownBit_000038_5 : 1;        // 0x000038 (0x000001) : 0x5
        uint8                                                   UnknownBit_000038_6 : 1;        // 0x000038 (0x000001) : 0x6
        uint8                                                   UnknownBit_000038_7 : 1;        // 0x000038 (0x000001) : 0x7
        uint8                                                   UnknownData_000039[0x000007];   // 0x000039 (0x000007)
        UClass*                                                 VoiceModel;                     // 0x000040 (0x000008) [Default: nullptr]
        EInterruptBehavior                                      InterruptionRule;               // 0x000048 (0x000001) [Default: EInterruptBehavior(0)]
        uint8                                                   UnknownData_000049[0x000003];   // 0x000049 (0x000003)
        float                                                   HearingRange;                   // 0x00004C (0x000004) [Default: 3000f]
        float                                                   Volume;                         // 0x000050 (0x000004) [Default: 1f]
        uint8                                                   UnknownData_000054[0x000004];   // 0x000054 (0x000004)
        USoundAttenuation*                                      Attenuation;                    // 0x000058 (0x000008) [Default: nullptr]
        FColor                                                  Color;                          // 0x000060 (0x000004)
        uint8                                                   UnknownData_000064[0x000004];   // 0x000064 (0x000004)
        FLLMFacts                                               CharacterFacts;                 // 0x000068 (0x000018)
        UPersonaPrompt*                                         CharacterPrompt;                // 0x000080 (0x000008) [Default: 0x7FE838AA1300]
        TSoftObjectPtr<UCharacterPersonaAssetBindingDataTable>  CharacterPersonaAssetBindings;  // 0x000088 (0x000020) [Default: nullptr]
    
    public: // Functions
        static TArray<UClass*> GetAllowedVoices(bool bRestrictEpicInternalConstructor); // 0x081D5B52 [Final | RequiredAPI | Native | Static | Public]
    };
    // Size: 0x000058 (0x000028)
    class alignas(0x8) UPersonaContextTagSettings : public UDeveloperSettings
    {
    public:
        TSoftObjectPtr<UDataTable>  GrantedContextTagsDataTable;    // 0x000030 (0x000020) [Default: nullptr]
        FGameplayTag                BoundCharacterTag;              // 0x000050 (0x000004)
        FGameplayTag                LockedCharacterTag;             // 0x000054 (0x000004)
    };
    // Size: 0x000048 (0x000020)
    class UPersonaDelegateWrapper : public UObject
    {
    public:
        uint8   UnknownData_000028[0x000020];   // 0x000028 (0x000020)
    
    public: // Functions
        void    OnMonologueEventPerceived(FMonologuePerceivedEvent& PerceivedEvent); // 0x081D5CFC [Final | Native | Public | HasOutParms]
        void    OnPlayerUnregistered(AFortPlayerState* UnregisteredPlayerState); // 0x081D5EAC [Final | Native | Public]
    };
    // Size: 0x000028 (0x000000)
    class IPersonaNameProvider : public IInterface
    {
    public:
    };
    // Size: 0x000460 (0x0000F0)
    class alignas(0x8) UPersonaOratorComponent : public UFNRedwoodOratorComponent
    {
    public:
        uint8                                   UnknownData_000370[0x000040];           // 0x000370 (0x000040)
        UClass*                                 LinkedAnimationLayer;                   // 0x0003B0 (0x000008) [Default: nullptr]
        UCharacterPersonaAssetBindingDataTable* CharacterPersonaAssetBindingDataTable;  // 0x0003B8 (0x000008) [Default: nullptr]
        UCharacterPersonaAsset*                 CharacterPersonaAsset;                  // 0x0003C0 (0x000008) [Default: nullptr]
        uint8                                   UnknownData_0003C8[0x000010];           // 0x0003C8 (0x000010)
        FPersonaOratorAudioParams               PersonaOratorAudioParams;               // 0x0003D8 (0x000030)
        FGuid                                   PersonaConversationGuid;                // 0x000408 (0x000010)
        bool                                    bHasLinkedAnimationLayer;               // 0x000418 (0x000001) [Default: false]
        uint8                                   UnknownData_000419[0x000007];           // 0x000419 (0x000007)
        AActor*                                 FocusActor;                             // 0x000420 (0x000008) [Default: nullptr]
        TOptional<FGuid>                        CachedUtteranceID;                      // 0x000428 (0x000014)
        float                                   StopFocusDelay;                         // 0x00043C (0x000004) [Default: 3f]
        FName                                   LookAtKeyName;                          // 0x000440 (0x000004) [Default: NAME_None]
        uint8                                   UnknownData_000444[0x00001C];           // 0x000444 (0x00001C)
    
    public: // Functions
        void    HandleUtteranceCancelled(FGuid UtteranceID); // 0x0493F01A [Final | Native | Private | HasDefaults]
        void    OnRep_HasLinkedAnimationLayer(); // 0x10EE8CD6 [Final | Native | Private]
        void    OnRep_PersonaConversationGuid(); // 0x10EE8CEC [Final | Native | Private]
        void    OnRep_PersonaOratorAudioParams(); // 0x10EE8D02 [Final | Native | Private]
        void    TryBindToPersonaUIController(); // 0x0F33FAAC [Net | NetReliable | Native | Event | Public | NetClient]
    };
    // Size: 0x000278 (0x000028)
    class alignas(0x8) UPersonaOratorInputControllerComponent : public UFNRedwoodOratorInputControllerComponent
    {
    public:
        MULTI_INLINE_DELEGATE(OnControllerBlockListUpdated) OnControllerBlockListUpdated;   // 0x000250 (0x000010)
        MULTI_INLINE_DELEGATE(OnMuteChanged)                OnMuteChanged;                  // 0x000260 (0x000010)
        uint8                                               UnknownData_000270[0x000008];   // 0x000270 (0x000008)
    
    public: // Functions
        bool    IsMuted(); // 0x0F8C47CE [Final | BlueprintCosmetic | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    ServerUpdateBlockList(TArray<FUniqueNetIdRepl> BlockList); // 0x081D7066 [Final | Net | NetReliable | Native | Event | Private | NetServer]
        void    ServerUpdateStopVoiceCaptureTime(FDateTime InStopVoiceCaptureTime); // 0x06F4E6F2 [Final | Net | NetReliable | Native | Event | Private | NetServer | HasDefaults]
    };
    // Size: 0x0000B0 (0x000088)
    class alignas(0x8) UPersonaPrompt : public UObject
    {
    public:
        FLLMFacts                                               PersonaFacts;                   // 0x000028 (0x000018)
        FLLMFacts                                               SessionFacts;                   // 0x000040 (0x000018)
        MULTI_INLINE_DELEGATE(PersonaPromptResponseDelegate)    OnResponseReceived;             // 0x000058 (0x000010)
        MULTI_INLINE_DELEGATE(ResponseStructsUpdated)           OnResponseStructsUpdated;       // 0x000068 (0x000010)
        uint8                                                   UnknownData_000078[0x000018];   // 0x000078 (0x000018)
        FString                                                 Voice;                          // 0x000090 (0x000010) [Default: L""]
        FString                                                 PromptInterruptionRule;         // 0x0000A0 (0x000010) [Default: L"persona_interruption_rule.IgnoreUntilFinished"]
    
    public: // Functions
        void    ClearHistory(); // 0x10ECE878 [Final | Native | Public | BlueprintCallable]
        void    SendPrompt(FString Topic, bool bIsBatchPrompt, int32 BatchSize, UScriptStruct* StructType); // 0x081D0460 [Final | Native | Public | BlueprintCallable]
    };
    // Size: 0x000250 (0x000190)
    class alignas(0x8) UPersonaUIControllerComponent : public UControllerComponent
    {
    public:
        UDynamicUIScene*                                    PersonaDynamicUIScene;              // 0x0000C0 (0x000008) [Default: nullptr]
        UDataTable*                                         PersonaErrorDataTable;              // 0x0000C8 (0x000008) [Default: nullptr]
        UClass*                                             PersonaViewModelClass;              // 0x0000D0 (0x000008) [Default: nullptr]
        TSoftClassPtr<UClass>                               PermissionWidgetClass;              // 0x0000D8 (0x000020) [Default: nullptr]
        TSoftClassPtr<UClass>                               PersonaStatusWidgetContainerClass;  // 0x0000F8 (0x000020) [Default: nullptr]
        UFortAIPromptContainerBase*                         PersonaWidgetContainer;             // 0x000118 (0x000008) [Default: nullptr]
        TArray<FPersonaPendingWidgetEntry>                  PendingWidgets;                     // 0x000120 (0x000010)
        TMap<EAIPromptUILayoutType, TSoftClassPtr<UClass>>  StatusWidgetClasses;                // 0x000130 (0x000010)
        UClass*                                             CustomSubtitleWidgetClass;          // 0x000140 (0x000008) [Default: nullptr]
        TMap<FName, UNpcDataAsset*>                         PersonaNpcDataAssets;               // 0x000148 (0x000010)
        TMap<FGuid, FPersonaConversationUI>                 ConversationViewModels;             // 0x000158 (0x000010)
        bool                                                bHideStatusWhenOutOfRange;          // 0x000168 (0x000001) [Default: false]
        uint8                                               UnknownData_000169[0x000007];       // 0x000169 (0x000007)
        TMap<FGuid, UPersonaUtteranceWrapper*>              PersonaUtteranceWrappers;           // 0x000170 (0x000010)
        uint8                                               UnknownData_000180[0x0000D0];       // 0x000180 (0x0000D0)
    
    public: // Functions
        void    AddedToConversation(FGuid PersonaConversation, FPersonaUIParams PersonaUIParams, UPersonaOratorComponent* PersonaOrator); // 0x081D71F6 [Net | NetReliable | Native | Event | Public | HasDefaults | NetClient]
        void    HandleHUDElementVisibilityRefreshed(); // 0x10EEB5F6 [Final | Native | Private]
        void    OnPlayerAllowedToHearOratorChanged(UOratorControllerComponent* InOratorControllerComponent, bool bPlayerAllowedToHearOrator); // 0x081D7658 [Final | Native | Private]
        void    OnPromptIgnored(FGuid PersonaConversation, bool bIsProcessing); // 0x081D8074 [Net | NetReliable | Native | Event | Public | HasDefaults | NetClient]
        void    OnResponseFailed(FGuid PersonaConversation, ELLMErrorType ErrorType, TArray<EPersonaModerationCategory> TrippedModerationCategories); // 0x081D8300 [Net | NetReliable | Native | Event | Public | HasDefaults | NetClient]
        void    OnResponseProcessing(FGuid PersonaConversation); // 0x081D86AA [Net | NetReliable | Native | Event | Public | HasDefaults | NetClient]
        void    OnResponseReceived(FGuid PersonaConversation, FText ResponseContents, AFortPlayerState* UtteranceInstigator); // 0x081D881E [Net | NetReliable | Native | Event | Public | HasDefaults | NetClient]
        void    OnStartedPlayingAudio(FGuid PersonaConversation); // 0x081D8C82 [Net | NetReliable | Native | Event | Public | HasDefaults | NetClient]
        void    OnStoppedPlayingAudio(FGuid PersonaConversation); // 0x081D8DF6 [Net | NetReliable | Native | Event | Public | HasDefaults | NetClient]
        void    OnVoiceRecordingStarted(FGuid& PersonaConversation); // 0x081D8F6A [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        void    OnVoiceRecordingStopped(FGuid& PersonaConversation); // 0x081D90EA [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        void    OpenRequestPermissionScreen(); // 0x10EEB662 [Final | Native | Public | BlueprintCallable]
        void    RemovedFromConversation(FGuid PersonaConversation); // 0x081D926A [Net | NetReliable | Native | Event | Public | HasDefaults | NetClient]
        void    SetConnected(FGuid PersonaConversation, bool bIsConnected); // 0x081D93DE [Net | NetReliable | Native | Event | Public | HasDefaults | NetClient]
        void    SetInHearingRange(FGuid& PersonaConversation, bool bInHearingRange); // 0x081D966A [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        void    SetInputEnabled(FGuid& PersonaConversation, bool bInputEnabled); // 0x081D9904 [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        void    SetMuted(bool bMuted); // 0x081D9B9E [Final | Native | Public | BlueprintCallable]
        void    SetPersonaIcon(FGuid PersonaConversation, TSoftObjectPtr<UTexture2D> InPersonaIcon); // 0x081D9D12 [Net | NetReliable | Native | Event | Public | HasDefaults | NetClient]
        void    SetPersonaName(FGuid PersonaConversation, FString InPersonaName); // 0x081D9FB0 [Net | NetReliable | Native | Event | Public | HasDefaults | NetClient]
        void    SetTimeLeftRecording(FGuid& PersonaConversation, float DeltaTime, float RecordingTimeMax); // 0x081DA248 [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000078 (0x000050)
    class UPersonaUtteranceWrapper : public UObject
    {
    public:
        uint8   UnknownData_000028[0x000050];   // 0x000028 (0x000050)
    
    public: // Functions
        void    OnOratorCurrentUtteranceClosed(FGuid UtteranceGuid, FString UtteranceText, FString ReplyContentId); // 0x081D602A [Final | Native | Public | HasDefaults]
        void    OnOratorUtteranceAudibilityChanged(FGuid UtteranceGuid, bool bIsAudible); // 0x081D64DA [Final | Native | Public | HasDefaults]
        void    OnOratorUtteranceCancelled(FGuid UtteranceGuid); // 0x081D6778 [Final | Native | Public | HasDefaults]
        void    OnOratorUtteranceEnded(FGuid UtteranceGuid); // 0x081D68FE [Final | Native | Public | HasDefaults]
        void    OnOratorUtteranceStarted(FGuid UtteranceGuid); // 0x081D6A84 [Final | Native | Public | HasDefaults]
    };
    // Size: 0x0000E8 (0x000080)
    class alignas(0x8) UPersonaViewModel : public UMVVMViewModelBase
    {
    public:
        bool                            IsVisible;                              // 0x000068 (0x000001) [Default: true]
        bool                            IsSuppressed;                           // 0x000069 (0x000001) [Default: false]
        bool                            CanInteract;                            // 0x00006A (0x000001) [Default: false]
        bool                            IsConnecting;                           // 0x00006B (0x000001) [Default: false]
        bool                            IsProcessing;                           // 0x00006C (0x000001) [Default: false]
        bool                            HasFailedToProcess;                     // 0x00006D (0x000001) [Default: false]
        bool                            HasReceivedResponse;                    // 0x00006E (0x000001) [Default: false]
        bool                            IsRecording;                            // 0x00006F (0x000001) [Default: false]
        bool                            IsPlayingAudio;                         // 0x000070 (0x000001) [Default: false]
        bool                            IsMuted;                                // 0x000071 (0x000001) [Default: false]
        bool                            IsAccountBlocked;                       // 0x000072 (0x000001) [Default: false]
        bool                            RateLimitReach;                         // 0x000073 (0x000001) [Default: false]
        uint8                           UnknownData_000074[0x000004];           // 0x000074 (0x000004)
        UInputAction*                   VoiceInputAction;                       // 0x000078 (0x000008) [Default: nullptr]
        float                           TimeLeftForAudioRecording;              // 0x000080 (0x000004) [Default: 0f]
        float                           TimeLeftForAudioRecordingNormalized;    // 0x000084 (0x000004) [Default: 0f]
        UTexture2D*                     PersonaIcon;                            // 0x000088 (0x000008) [Default: nullptr]
        bool                            ShowPersonaIcon;                        // 0x000090 (0x000001) [Default: false]
        uint8                           UnknownData_000091[0x000007];           // 0x000091 (0x000007)
        FText                           PersonaName;                            // 0x000098 (0x000010)
        bool                            ShowPersonaName;                        // 0x0000A8 (0x000001) [Default: false]
        uint8                           UnknownData_0000A9[0x000003];           // 0x0000A9 (0x000003)
        FLinearColor                    PersonaColor;                           // 0x0000AC (0x000010)
        uint8                           UnknownData_0000BC[0x000004];           // 0x0000BC (0x000004)
        TArray<UFortPersonaListEntry*>  PersonaList;                            // 0x0000C0 (0x000010)
        bool                            ShowPersonaList;                        // 0x0000D0 (0x000001) [Default: false]
        uint8                           UnknownData_0000D1[0x000007];           // 0x0000D1 (0x000007)
        FText                           ErrorMessage;                           // 0x0000D8 (0x000010)
    };
    // Size: 0x000028 (0x000000)
    class IPersonaVoiceDataProvider : public IInterface
    {
    public:
    };
    // Size: 0x0001C8 (0x000018)
    class alignas(0x8) UPlaylistUserOptionLLMFacts : public UPlaylistUserOptionBase
    {
    public:
        FLLMFacts   DefaultValue;   // 0x0001B0 (0x000018)
    };
    // Size: 0x000228 (0x000078)
    class alignas(0x8) UPlaylistUserOptionPersona : public UPlaylistUserOptionBase
    {
    public:
        FLLMPersona DefaultValue;   // 0x0001B0 (0x000078)
    };
    // Size: 0x0001C0 (0x000010)
    class alignas(0x8) UPlaylistUserOptionPersonas : public UPlaylistUserOptionBase
    {
    public:
        FPersonas   DefaultValue;   // 0x0001B0 (0x000010)
    };
    // Size: 0x0001C8 (0x000018)
    class alignas(0x8) UPlaylistUserOptionResponseEventCriteria : public UPlaylistUserOptionBase
    {
    public:
        FResponseEventCriteria  DefaultValue;   // 0x0001B0 (0x000018)
    };
    // Size: 0x000028 (0x000000)
    class UResonanceTextToSpeechProvider : public UOratorTextToSpeechProvider
    {
    public:
    };
    // Size: 0x000020 (0x000018)
    struct alignas(0x8) FAIPromptErrorMessage : public FTableRowBase
    {
        ELLMErrorType   ErrorType;                      // 0x000008 (0x000001) [Default: ELLMErrorType(120)]
        uint8           UnknownData_000009[0x000007];   // 0x000009 (0x000007)
        FText           ErrorMessage;                   // 0x000010 (0x000010)
    };
    // Size: 0x000060 (0x000058)
    struct alignas(0x8) FCharacterPersonaAssetBinding : public FTableRowBase
    {
        TSoftObjectPtr<UCharacterPersonaAsset>  CharacterPersonaAsset;          // 0x000008 (0x000020) [Default: nullptr]
        bool                                    bOverrideAssetData;             // 0x000028 (0x000001) [Default: false]
        bool                                    bIsFinalPersonaDataOverride;    // 0x000029 (0x000001) [Default: false]
        uint8                                   UnknownData_00002A[0x000006];   // 0x00002A (0x000006)
        TSoftClassPtr<UClass>                   VoiceModelOverride;             // 0x000030 (0x000020) [Default: nullptr]
        FText                                   CharacterPromptOverride;        // 0x000050 (0x000010)
    };
    // Size: 0x000030 (0x000028)
    struct alignas(0x8) FLLMFactTableRow : public FTableRowBase
    {
        EFactKnowledgeType  FactKnowledge;                  // 0x000008 (0x000001)
        uint8               UnknownData_000009[0x000007];   // 0x000009 (0x000007)
        FText               FactProperty;                   // 0x000010 (0x000010)
        FText               FactDescription;                // 0x000020 (0x000010)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FLLMFacts
    {
        FDataRegistryType               RegistryType;                   // 0x000000 (0x000004)
        EFactKnowledgeType              KnowledgeType;                  // 0x000004 (0x000001)
        uint8                           UnknownData_000005[0x000003];   // 0x000005 (0x000003)
        TMap<FDataRegistryId, FText>    FactMap;                        // 0x000008 (0x000010)
    };
    // Size: 0x000078 (0x000078)
    struct alignas(0x8) FLLMPersona
    {
        FString                     Name;                           // 0x000000 (0x000010)
        bool                        bShowName;                      // 0x000010 (0x000001)
        bool                        bPreviewAudioRange;             // 0x000011 (0x000001)
        uint8                       UnknownData_000012[0x000006];   // 0x000012 (0x000006)
        TSoftObjectPtr<UTexture2D>  Icon;                           // 0x000018 (0x000020)
        FLinearColor                Color;                          // 0x000038 (0x000010)
        float                       HearingRange;                   // 0x000048 (0x000004)
        float                       Volume;                         // 0x00004C (0x000004)
        USoundAttenuation*          Attenuation;                    // 0x000050 (0x000008)
        FDataRegistryId             Voice;                          // 0x000058 (0x000008)
        FLLMFacts                   PersonaFacts;                   // 0x000060 (0x000018)
    };
    // Size: 0x000018 (0x000010)
    struct alignas(0x8) FLLMVoicePreviewMapping : public FTableRowBase
    {
        FName       VoiceID;                        // 0x000008 (0x000004)
        uint8       UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        USoundBase* VoicePreviewSound;              // 0x000010 (0x000008)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FPersonaConversationUI
    {
        UPersonaViewModel*          PersonaViewModel;               // 0x000000 (0x000008)
        UAIPromptSubtitleViewModel* SubtitleViewModel;              // 0x000008 (0x000008)
        bool                        bShowPersonaName;               // 0x000010 (0x000001)
        bool                        bHideStatusWhenOutOfRange;      // 0x000011 (0x000001)
        bool                        bInHearingRange;                // 0x000012 (0x000001)
        uint8                       UnknownData_000013[0x000005];   // 0x000013 (0x000005)
    };
    // Size: 0x000060 (0x000060)
    struct alignas(0x8) FPersonaEvent_UIAdded
    {
        TSoftClassPtr<UClass>               CustomUIWidget;                 // 0x000000 (0x000020)
        TSoftClassPtr<UClass>               CustomSubtitleWidget;           // 0x000020 (0x000020)
        UPersonaViewModel*                  PersonaViewModel;               // 0x000040 (0x000008)
        UAIPromptSubtitleViewModel*         SubtitleViewModel;              // 0x000048 (0x000008)
        TEnumAsByte<EHorizontalAlignment>   HorizontalAlignment;            // 0x000050 (0x000001)
        TEnumAsByte<EVerticalAlignment>     VerticalAlignment;              // 0x000051 (0x000001)
        uint8                               UnknownData_000052[0x000002];   // 0x000052 (0x000002)
        float                               UIWidgetXOffset;                // 0x000054 (0x000004)
        float                               UIWidgetYOffset;                // 0x000058 (0x000004)
        EAIPromptUILayoutType               UserWidgetLayoutType;           // 0x00005C (0x000001)
        bool                                bIsExperimental;                // 0x00005D (0x000001)
        uint8                               UnknownData_00005E[0x000002];   // 0x00005E (0x000002)
    };
    // Size: 0x000001 (0x000001)
    struct FPersonaEvent_UIVisibility
    {
        bool    bVisibility;    // 0x000000 (0x000001)
    };
    // Size: 0x00000C (0x00000C)
    struct FPersonaLinkedActor
    {
        uint8   UnknownData_000000[0x00000C];   // 0x000000 (0x00000C)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FPersonaOratorAudioParams
    {
        FSoftObjectPath AttenuationPath;    // 0x000000 (0x000018)
        FSoftObjectPath SoundClassPath;     // 0x000018 (0x000018)
    };
    // Size: 0x0000C8 (0x0000C8)
    struct alignas(0x8) FPersonaPendingWidgetEntry
    {
        FGuid                   ConversationId; // 0x000000 (0x000010)
        FPersonaConversationUI  ViewModels;     // 0x000010 (0x000018)
        FPersonaUIParams        Params;         // 0x000028 (0x0000A0)
    };
    // Size: 0x000002 (0x000002)
    struct FPersonaPlayerStatus
    {
        bool    bInputStateEnabled; // 0x000000 (0x000001)
        bool    bInHearingRange;    // 0x000001 (0x000001)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FPersonaResponseSchema
    {
        TArray<int32>   EventNumbersTriggered;  // 0x000000 (0x000010)
    };
    // Size: 0x0000A0 (0x0000A0)
    struct alignas(0x8) FPersonaUIParams
    {
        FString                             PersonaName;                    // 0x000000 (0x000010)
        bool                                bShowPersonaName;               // 0x000010 (0x000001)
        uint8                               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        TSoftObjectPtr<UTexture2D>          PersonaIcon;                    // 0x000018 (0x000020)
        FLinearColor                        PersonaColor;                   // 0x000038 (0x000010)
        bool                                bShowTextOutput;                // 0x000048 (0x000001)
        bool                                bHideStatusWhenOutOfRange;      // 0x000049 (0x000001)
        bool                                bShowPersonaList;               // 0x00004A (0x000001)
        uint8                               UnknownData_00004B[0x000005];   // 0x00004B (0x000005)
        TSoftClassPtr<UClass>               CustomUIWidget;                 // 0x000050 (0x000020)
        TSoftClassPtr<UClass>               CustomSubtitleWidget;           // 0x000070 (0x000020)
        TEnumAsByte<EHorizontalAlignment>   HorizontalAlignment;            // 0x000090 (0x000001)
        TEnumAsByte<EVerticalAlignment>     VerticalAlignment;              // 0x000091 (0x000001)
        uint8                               UnknownData_000092[0x000002];   // 0x000092 (0x000002)
        float                               UIWidgetXOffset;                // 0x000094 (0x000004)
        float                               UIWidgetYOffset;                // 0x000098 (0x000004)
        EAIPromptUILayoutType               UserWidgetLayoutType;           // 0x00009C (0x000001)
        bool                                bIsExperimental;                // 0x00009D (0x000001)
        uint8                               UnknownData_00009E[0x000002];   // 0x00009E (0x000002)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FPersonaUIWidgetLayoutDefinition
    {
        UPersonaViewModel*                  PersonaViewModel;               // 0x000000 (0x000008)
        UAIPromptSubtitleViewModel*         SubtitleViewModel;              // 0x000008 (0x000008)
        TEnumAsByte<EHorizontalAlignment>   HorizontalAlignment;            // 0x000010 (0x000001)
        TEnumAsByte<EVerticalAlignment>     VerticalAlignment;              // 0x000011 (0x000001)
        uint8                               UnknownData_000012[0x000002];   // 0x000012 (0x000002)
        float                               UIWidgetXOffset;                // 0x000014 (0x000004)
        float                               UIWidgetYOffset;                // 0x000018 (0x000004)
        bool                                bIsExperimental;                // 0x00001C (0x000001)
        EAIPromptUILayoutType               UserWidgetLayoutType;           // 0x00001D (0x000001)
        uint8                               UnknownData_00001E[0x000002];   // 0x00001E (0x000002)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FPersonas
    {
        TArray<FLLMPersona> Personas;   // 0x000000 (0x000010)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FPromptPropertyDefinition
    {
        FName               PropertyId;                     // 0x000000 (0x000004)
        EPromptPropertyType PropertyType;                   // 0x000004 (0x000001)
        EPinContainerType   ContainerType;                  // 0x000005 (0x000001)
        uint8               UnknownData_000006[0x000002];   // 0x000006 (0x000002)
        FString             DisplayName;                    // 0x000008 (0x000010)
        FString             Description;                    // 0x000018 (0x000010)
    };
    // Size: 0x000078 (0x000078)
    struct alignas(0x8) FPromptResultDetails
    {
        FText   PersonaName;                    // 0x000000 (0x000010)
        FText   PromptTranscription;            // 0x000010 (0x000010)
        FText   LLMResponse;                    // 0x000020 (0x000010)
        FText   StructName;                     // 0x000030 (0x000010)
        FText   StructuredResponse;             // 0x000040 (0x000010)
        FText   ErrorMessage;                   // 0x000050 (0x000010)
        FText   ErrorDetails;                   // 0x000060 (0x000010)
        bool    bHasError;                      // 0x000070 (0x000001)
        bool    bHasStructuredResponse;         // 0x000071 (0x000001)
        uint8   UnknownData_000072[0x000006];   // 0x000072 (0x000006)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FPromptStructDefinition
    {
        FString                             DisplayName;    // 0x000000 (0x000010)
        TArray<FPromptPropertyDefinition>   Properties;     // 0x000010 (0x000010)
        UScriptStruct*                      Struct;         // 0x000020 (0x000008)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FResponseEventCriteria
    {
        FString Criteria;                       // 0x000000 (0x000010)
        int32   ResponseEventID;                // 0x000010 (0x000004)
        uint8   UnknownData_000014[0x000004];   // 0x000014 (0x000004)
    };
    // Size: 0x000020 (0x000018)
    struct alignas(0x8) FUserOptionDefinitionLLMFactsMetaData : public FUserOptionDefinitionMetaData
    {
        FLLMFacts   DefaultValue;   // 0x000008 (0x000018)
    };
    // Size: 0x000080 (0x000078)
    struct alignas(0x8) FUserOptionDefinitionPersonaMetaData : public FUserOptionDefinitionMetaData
    {
        FLLMPersona DefaultValue;   // 0x000008 (0x000078)
    };
    // Size: 0x000018 (0x000010)
    struct alignas(0x8) FUserOptionDefinitionPersonasMetaData : public FUserOptionDefinitionMetaData
    {
        FPersonas   DefaultValue;   // 0x000008 (0x000010)
    };
    // Size: 0x000020 (0x000018)
    struct alignas(0x8) FUserOptionDefinitionResponseEventCriteriaData : public FUserOptionDefinitionMetaData
    {
        FResponseEventCriteria  DefaultValue;   // 0x000008 (0x000018)
    };
}

