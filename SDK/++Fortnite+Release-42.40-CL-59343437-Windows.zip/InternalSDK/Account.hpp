/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:04
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/Account
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000038 (0x000010)
    class alignas(0x8) UExternalAccountProvider : public UObject
    {
    public:
        TArray<FExternalAccountServiceConfig>   Services;   // 0x000028 (0x000010)
    };
    // Size: 0x000970 (0x000948)
    class alignas(0x8) UOnlineAccountCommon : public UObject
    {
    public:
        uint8                                       UnknownData_000028[0x000010];                       // 0x000028 (0x000010)
        FString                                     AvailabilityServiceGameName;                        // 0x000038 (0x000010) [Default: L""]
        bool                                        bRequireLightswitchAtStartup;                       // 0x000048 (0x000001) [Default: true]
        bool                                        bPartialLoginEnabled;                               // 0x000049 (0x000001) [Default: false]
        bool                                        bCheckStoreAccountEnabled;                          // 0x00004A (0x000001) [Default: false]
        bool                                        bRedeemOfflinePurchasesEnabled;                     // 0x00004B (0x000001) [Default: true]
        bool                                        bCheckingRejoinEnabled;                             // 0x00004C (0x000001) [Default: true]
        uint8                                       UnknownData_00004D[0x000003];                       // 0x00004D (0x000003)
        FString                                     EulaKey;                                            // 0x000050 (0x000010) [Default: L""]
        TArray<FString>                             EulaKeys;                                           // 0x000060 (0x000010)
        TMap<FString, FString>                      EulaKeyMapping;                                     // 0x000070 (0x000010)
        int32                                       EulaCacheVersion;                                   // 0x000080 (0x000004) [Default: 1]
        bool                                        bEnableWaitingRoom;                                 // 0x000084 (0x000001) [Default: true]
        uint8                                       UnknownData_000085[0x000003];                       // 0x000085 (0x000003)
        TArray<FWebEnvUrl>                          WebCreateEpicAccountUrl;                            // 0x000088 (0x000010)
        bool                                        bAllowLocalLogout;                                  // 0x000098 (0x000001) [Default: false]
        uint8                                       UnknownData_000099[0x000003];                       // 0x000099 (0x000003)
        float                                       OSSv2EpicGameServicesLoginRecoveryRetryInterval;    // 0x00009C (0x000004) [Default: 30f]
        float                                       OSSv2WaitForEASTokenRetryInterval;                  // 0x0000A0 (0x000004) [Default: 1f]
        float                                       OSSv2WaitForEASTokenTimeout;                        // 0x0000A4 (0x000004) [Default: 60f]
        uint8                                       UnknownData_0000A8[0x000038];                       // 0x0000A8 (0x000038)
        float                                       DefaultLoginStepTimeout;                            // 0x0000E0 (0x000004) [Default: 0f]
        uint8                                       UnknownData_0000E4[0x000004];                       // 0x0000E4 (0x000004)
        TMap<FName, float>                          CustomLoginStepTimeouts;                            // 0x0000E8 (0x000010)
        bool                                        bEnableDevLoginStepTimeouts;                        // 0x0000F8 (0x000001) [Default: false]
        uint8                                       UnknownData_0000F9[0x000003];                       // 0x0000F9 (0x000003)
        float                                       DefaultLogoutStepTimeout;                           // 0x0000FC (0x000004) [Default: 120f]
        TMap<FName, float>                          CustomLogoutStepTimeouts;                           // 0x000100 (0x000010)
        bool                                        bEnableDevLogoutStepTimeouts;                       // 0x000110 (0x000001) [Default: false]
        uint8                                       UnknownData_000111[0x000027];                       // 0x000111 (0x000027)
        int32                                       LogoutFrameDelay;                                   // 0x000138 (0x000004) [Default: 5]
        uint8                                       UnknownData_00013C[0x000004];                       // 0x00013C (0x000004)
        TArray<FServiceLoginConfig>                 ServiceLoginConfig;                                 // 0x000140 (0x000010)
        FString                                     RedeemAccessUrl;                                    // 0x000150 (0x000010) [Default: L"`baseurl/api/storeaccess/v1/redeem_access/`accountid"]
        FString                                     RequestFreeAccessUrl;                               // 0x000160 (0x000010) [Default: L"`baseurl/api/storeaccess/v1/request_access/`accountid"]
        FString                                     RealGameAccessUrl;                                  // 0x000170 (0x000010) [Default: L"`baseurl/api/accesscontrol/status"]
        float                                       SkipRedeemOfflinePurchasesChance;                   // 0x000180 (0x000004) [Default: 0f]
        bool                                        bUseFreeAccessInsteadOfGameAccess;                  // 0x000184 (0x000001) [Default: false]
        bool                                        bShouldGrantFreeAccess;                             // 0x000185 (0x000001) [Default: false]
        uint8                                       UnknownByte_000186;                                 // 0x000186 (0x000001)
        bool                                        bAllowHomeSharingAccess;                            // 0x000187 (0x000001) [Default: false]
        bool                                        bRequireUGCPrivilege;                               // 0x000188 (0x000001) [Default: true]
        bool                                        bWaitForEULAHandlerDelegate;                        // 0x000189 (0x000001) [Default: false]
        bool                                        bPlatformSupportsAutologinRetry;                    // 0x00018A (0x000001) [Default: false]
        uint8                                       UnknownData_00018B[0x000255];                       // 0x00018B (0x000255)
        float                                       AccessGrantDelaySeconds;                            // 0x0003E0 (0x000004) [Default: 2f]
        uint8                                       UnknownData_0003E4[0x000004];                       // 0x0003E4 (0x000004)
        UWaitingRoomState*                          WaitingRoomState;                                   // 0x0003E8 (0x000008) [Default: nullptr]
        uint8                                       UnknownData_0003F0[0x0004A0];                       // 0x0003F0 (0x0004A0)
        TArray<FOnlineAccountOperationStepConfig>   LoginStepConfig;                                    // 0x000890 (0x000010)
        TArray<FOnlineAccountOperationStepConfig>   LogoutStepConfig;                                   // 0x0008A0 (0x000010)
        TArray<FOnlineAccountOperationStepConfig>   CreateAccountStepConfig;                            // 0x0008B0 (0x000010)
        uint8                                       UnknownData_0008C0[0x0000B0];                       // 0x0008C0 (0x0000B0)
    };
    // Size: 0x000088 (0x000060)
    class alignas(0x4) UWaitingRoomState : public UObject
    {
    public:
        uint8   UnknownData_000028[0x000034];   // 0x000028 (0x000034)
        int32   GracePeriodMins;                // 0x00005C (0x000004) [Default: 10]
        uint8   UnknownData_000060[0x000028];   // 0x000060 (0x000028)
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x8) FExchangeAccessParams
    {
        FString EntitlementId;  // 0x000000 (0x000010)
        FString ReceiptId;      // 0x000010 (0x000010)
        FString VendorReceipt;  // 0x000020 (0x000010)
        FString AppStore;       // 0x000030 (0x000010)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FExternalAccountServiceConfig
    {
        EExternalAccountType    Type;                           // 0x000000 (0x000001)
        uint8                   UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        FName                   ExternalServiceName;            // 0x000004 (0x000004)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FGiftMessage
    {
        FString GiftCode;                       // 0x000000 (0x000010) [Default: L""]
        FString SenderName;                     // 0x000010 (0x000010) [Default: L""]
        uint8   UnknownData_000020[0x000010];   // 0x000020 (0x000010)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FOnlineAccountOperationStepConfig
    {
        FName           Name;                           // 0x000000 (0x000004) [Default: NAME_None]
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FName>   Dependencies;                   // 0x000008 (0x000010)
    };
    // Size: 0x000660 (0x000660)
    struct alignas(0x8) FOnlineAccountTexts
    {
        FText                                   AllGiftCodesUsed;                       // 0x000000 (0x000010)
        FText                                   AssociateConsoleAuth;                   // 0x000010 (0x000010)
        FText                                   AutoLoginFailed;                        // 0x000020 (0x000010)
        FText                                   AutoLoginFailedMobile;                  // 0x000030 (0x000010)
        FText                                   BannedFromGame;                         // 0x000040 (0x000010)
        FText                                   CheckEntitledToPlay;                    // 0x000050 (0x000010)
        FText                                   CheckingRejoin;                         // 0x000060 (0x000010)
        FText                                   CheckServiceAvailability;               // 0x000070 (0x000010)
        FText                                   ConsolePrivileges;                      // 0x000080 (0x000010)
        FText                                   CreateAccountCompleted;                 // 0x000090 (0x000010)
        FText                                   CreateAccountFailure;                   // 0x0000A0 (0x000010)
        FText                                   CreateAccountStepTimeout;               // 0x0000B0 (0x000010)
        FText                                   CreateHeadless;                         // 0x0000C0 (0x000010)
        FText                                   DoQosPingTests;                         // 0x0000D0 (0x000010)
        FText                                   DowntimeMinutesWarningText;             // 0x0000E0 (0x000010)
        FText                                   DowntimeSecondsWarningText;             // 0x0000F0 (0x000010)
        FText                                   DuplicateAuthAssociaton;                // 0x000100 (0x000010)
        FText                                   EulaCheck;                              // 0x000110 (0x000010)
        FText                                   ExchangeConsoleGiftsForAccess;          // 0x000120 (0x000010)
        FText                                   FailedAccountCreate;                    // 0x000130 (0x000010)
        FText                                   FailedEulaCheck_EulaAcceptanceFailed;   // 0x000140 (0x000010)
        FText                                   FailedEulaCheck_MustAcceptEula;         // 0x000150 (0x000010)
        FText                                   FailedLoginCredentialsMsg;              // 0x000160 (0x000010)
        FText                                   FailedLoginAgeVerificationIncomplete;   // 0x000170 (0x000010)
        FText                                   FailedLoginParentalLock;                // 0x000180 (0x000010)
        FText                                   FailedLoginNoRealId;                    // 0x000190 (0x000010)
        FText                                   FailedLoginLockoutMsg;                  // 0x0001A0 (0x000010)
        FText                                   FailedLoginRequiresMFA;                 // 0x0001B0 (0x000010)
        FText                                   FailedLoginRequiresAuthAppMFA;          // 0x0001C0 (0x000010)
        FText                                   FailedInvalidMFA;                       // 0x0001D0 (0x000010)
        FText                                   FailedLoginRequiresCorrectiveAction;    // 0x0001E0 (0x000010)
        FText                                   FailedLoginMsg;                         // 0x0001F0 (0x000010)
        FText                                   FailedLoginMsg_InvalidRefreshToken;     // 0x000200 (0x000010)
        FText                                   FailedStartLogin;                       // 0x000210 (0x000010)
        FText                                   FailedStartLogin_InvalidRefreshToken;   // 0x000220 (0x000010)
        FText                                   FailedStartLogin_NoConnection;          // 0x000230 (0x000010)
        FText                                   GameDisplayName;                        // 0x000240 (0x000010)
        FText                                   GeneralLoginFailure;                    // 0x000250 (0x000010)
        FText                                   HeadlessAccountFailed;                  // 0x000260 (0x000010)
        FText                                   InMatchShutdownTimeWarningText;         // 0x000270 (0x000010)
        FText                                   InvalidUser;                            // 0x000280 (0x000010)
        FText                                   LoggedOutofMCP;                         // 0x000290 (0x000010)
        FText                                   DisconnectedFromMCP;                    // 0x0002A0 (0x000010)
        FText                                   LoggedOutReturnedToTitle;               // 0x0002B0 (0x000010)
        FText                                   LoggedOutSwitchedProfile;               // 0x0002C0 (0x000010)
        FText                                   LoggingIn;                              // 0x0002D0 (0x000010)
        FText                                   LoggingInConsoleAuth;                   // 0x0002E0 (0x000010)
        FText                                   LoggingOut;                             // 0x0002F0 (0x000010)
        FText                                   LoginConsole;                           // 0x000300 (0x000010)
        FText                                   LoginFailure;                           // 0x000310 (0x000010)
        FText                                   Logout_Unlink;                          // 0x000320 (0x000010)
        FText                                   LogoutCompleted;                        // 0x000330 (0x000010)
        FText                                   LostConnection;                         // 0x000340 (0x000010)
        FText                                   LoginStepTimeout;                       // 0x000350 (0x000010)
        FText                                   MCPTimeout;                             // 0x000360 (0x000010)
        FText                                   LightswitchCheckNetworkFailureMsg;      // 0x000370 (0x000010)
        FText                                   NetworkConnectionUnavailable;           // 0x000380 (0x000010)
        FText                                   NoPlayEntitlement;                      // 0x000390 (0x000010)
        FText                                   NoServerAccess;                         // 0x0003A0 (0x000010)
        FText                                   PlayAccessRevoked;                      // 0x0003B0 (0x000010)
        FText                                   PremiumAccountName_Default;             // 0x0003C0 (0x000010)
        FText                                   PremiumAccountName_Sony;                // 0x0003D0 (0x000010)
        FText                                   PremiumAccountName_Nintendo;            // 0x0003E0 (0x000010)
        FText                                   PremiumAccountName_XboxOne;             // 0x0003F0 (0x000010)
        FText                                   CheckLocalUserIsStoreUser;              // 0x000400 (0x000010)
        FText                                   RedeemOfflinePurchases;                 // 0x000410 (0x000010)
        FText                                   ServiceDowntime;                        // 0x000420 (0x000010)
        FText                                   SignInCompleting;                       // 0x000430 (0x000010)
        FText                                   SignIntoConsoleServices;                // 0x000440 (0x000010)
        FText                                   TokenExpired;                           // 0x000450 (0x000010)
        FText                                   UnableToConnect;                        // 0x000460 (0x000010)
        FText                                   UnableToJoinWaitingRoomLoginQueue;      // 0x000470 (0x000010)
        FText                                   UnexpectedConsoleAuthFailure;           // 0x000480 (0x000010)
        FText                                   UnlinkConsoleFailed;                    // 0x000490 (0x000010)
        FText                                   UserLoginFailed;                        // 0x0004A0 (0x000010)
        FText                                   WaitingRoom;                            // 0x0004B0 (0x000010)
        FText                                   WaitingRoomError;                       // 0x0004C0 (0x000010)
        FText                                   WaitingRoomFailure;                     // 0x0004D0 (0x000010)
        FText                                   WaitingRoomWaiting;                     // 0x0004E0 (0x000010)
        FOnlineAccountTexts_FailedLoginConsole  FailedLoginConsole;                     // 0x0004F0 (0x0000F0)
        FText                                   LoggingInExternalAuth;                  // 0x0005E0 (0x000010)
        FText                                   CreateDeviceAuth;                       // 0x0005F0 (0x000010)
        FText                                   ExtAuthCanceled;                        // 0x000600 (0x000010)
        FText                                   ExtAuthFailure;                         // 0x000610 (0x000010)
        FText                                   ExtAuthAssociationFailure;              // 0x000620 (0x000010)
        FText                                   ExtAuthTimeout;                         // 0x000630 (0x000010)
        FText                                   ExtAuthMissingAuthAssociation;          // 0x000640 (0x000010)
        FText                                   UnableToQueryReceipts;                  // 0x000650 (0x000010)
    };
    // Size: 0x0000F0 (0x0000F0)
    struct alignas(0x8) FOnlineAccountTexts_FailedLoginConsole
    {
        FText   AgeRestriction;                     // 0x000000 (0x000010)
        FText   Generic;                            // 0x000010 (0x000010)
        FText   MissingAuthAssociation;             // 0x000020 (0x000010)
        FText   NeedPremiumAccount;                 // 0x000030 (0x000010)
        FText   OnlinePlayRestriction;              // 0x000040 (0x000010)
        FText   PatchAvailable;                     // 0x000050 (0x000010)
        FText   PatchAvailableInstruction_Default;  // 0x000060 (0x000010)
        FText   PatchAvailableInstruction_Xbox;     // 0x000070 (0x000010)
        FText   PleaseSignIn;                       // 0x000080 (0x000010)
        FText   SystemUpdateAvailable;              // 0x000090 (0x000010)
        FText   UI;                                 // 0x0000A0 (0x000010)
        FText   UnableToComplete;                   // 0x0000B0 (0x000010)
        FText   UnableToSignIn;                     // 0x0000C0 (0x000010)
        FText   UnableToStartPrivCheck;             // 0x0000D0 (0x000010)
        FText   UnexpectedError;                    // 0x0000E0 (0x000010)
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FServiceLoginConfig
    {
        FName   LoginType;                      // 0x000000 (0x000004)
        FName   ExternalAuthMethod;             // 0x000004 (0x000004)
        uint8   UnknownData_000008[0x000004];   // 0x000008 (0x000004)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FWebEnvUrl
    {
        FString Url;            // 0x000000 (0x000010) [Default: L""]
        FString RedirectUrl;    // 0x000010 (0x000010) [Default: L""]
        FString Environment;    // 0x000020 (0x000010) [Default: L""]
    };
}

