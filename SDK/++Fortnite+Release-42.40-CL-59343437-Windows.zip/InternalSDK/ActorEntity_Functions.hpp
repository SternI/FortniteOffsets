/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ActorEntity_Functions
 * ============================================================
 */

#include "ActorEntity.hpp"

namespace UE
{

    struct UPhysicsComponentBridgeHelper___HandleActorComponentHit_Params
    {
        UPrimitiveComponent*    PrimitiveComponent; // 0x000000 (0x000008) [Default: 0x1363D5B0]
        AActor*                 OtherActor;         // 0x000008 (0x000008) [Default: 0xDA2418DD00000031]
        UPrimitiveComponent*    OtherComponent;     // 0x000010 (0x000008) [Default: 0x1760C3E0]
        FVector                 NormalImpulse;      // 0x000018 (0x000018)
        FHitResult              Hit;                // 0x000030 (0x0000F8) [OutParam]
    };

    struct UPossessableComponentBridgeHelper___HandlePawnControllerChanged_Params
    {
        APawn*          OwnerPawn;      // 0x000000 (0x000008) [Default: 0x1363D5B0]
        AController*    OldController;  // 0x000008 (0x000008) [Default: 0xD82418DD00000031]
        AController*    NewController;  // 0x000010 (0x000008) [Default: 0x1760B000]
    };

} // namespace UE

