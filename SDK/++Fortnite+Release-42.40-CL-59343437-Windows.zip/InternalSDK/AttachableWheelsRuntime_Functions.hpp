/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AttachableWheelsRuntime_Functions
 * ============================================================
 */

#include "AttachableWheelsRuntime.hpp"

namespace UE
{

    struct AAttachableWheel___AttachInPlace_Params
    {
        UPrimitiveComponent*    InComponent;    // 0x000000 (0x000008) [Default: 0x148E8D50]
        bool                    ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct AAttachableWheel___AttachTo_Params
    {
        UPrimitiveComponent*    InComponent;    // 0x000000 (0x000008) [Default: 0x148E8D50]
        FVector                 WorldLocation;  // 0x000008 (0x000018) [OutParam]
        FVector                 AxleDirection;  // 0x000020 (0x000018) [OutParam]
        FVector                 SteerAxis;      // 0x000038 (0x000018)
        bool                    ReturnValue;    // 0x000050 (0x000001) [ReturnValue] [Default: false]
    };

    struct AAttachableWheel___DetachFrom_Params
    {
        UPrimitiveComponent*    InComponent;    // 0x000000 (0x000008) [Default: 0x148E8D50]
        bool                    ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct AAttachableWheel___GetAttachData_Params
    {
        FAttachableWheelAttachData  ReturnValue;    // 0x000000 (0x000058) [ReturnValue]
    };

    struct AAttachableWheel___GetAttachedComponent_Params
    {
        UPrimitiveComponent*    ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x148E8D50]
    };

    struct AAttachableWheel___GetWorldSpaceAttachData_Params
    {
        FAttachableWheelAttachData  OutAttachData;      // 0x000000 (0x000058) [OutParam]
        UPrimitiveComponent*        PrimitiveComponent; // 0x000058 (0x000008) [Default: 0x2000100A9246860]
        FName                       BodyName;           // 0x000060 (0x000004) [Default: FName(1) -> L""]
        bool                        ReturnValue;        // 0x000064 (0x000001) [ReturnValue] [Default: false]
    };

    struct AAttachableWheel___OnAttached_Params
    {
        UPrimitiveComponent*    AttachedComponent;  // 0x000000 (0x000008) [Default: 0x148E8D50]
    };

    struct AAttachableWheel___OnDetached_Params
    {
        UPrimitiveComponent*    DetachedComponent;  // 0x000000 (0x000008) [Default: 0x148E8D50]
    };

    struct AAttachableWheel___OnPhysicsStateChanged_Params
    {
        UPrimitiveComponent*            PrimitiveComponent; // 0x000000 (0x000008) [Default: 0x148E8D50]
        EComponentPhysicsStateChange    StateChange;        // 0x000008 (0x000001) [Default: EComponentPhysicsStateChange(49)]
    };

    struct AAttachableWheel___OnRep_AttachData_Params
    {
        FAttachableWheelAttachData  AttachDataPrev; // 0x000000 (0x000058) [OutParam]
    };

    struct AAttachableWheel___OnRep_RuntimeData_Params
    {
        FAttachableWheelRuntimeData RuntimeDataPrev;    // 0x000000 (0x00000C) [OutParam]
    };

    struct AAttachableWheel___SetRuntimeData_Params
    {
        float   Torque;     // 0x000000 (0x000004) [Default: 1.43941e-26f]
        float   Velocity;   // 0x000004 (0x000004) [Default: 0f]
        float   SteerAngle; // 0x000008 (0x000004) [Default: 6.86636e-44f]
    };

    struct AAttachableWheel___SetRuntimeData_SteerAngle_Params
    {
        float   SteerAngle; // 0x000000 (0x000004) [Default: 1.43941e-26f]
    };

    struct AAttachableWheel___SetRuntimeData_Torque_Params
    {
        float   Torque; // 0x000000 (0x000004) [Default: 1.43941e-26f]
    };

    struct AAttachableWheel___SetRuntimeData_Velocity_Params
    {
        float   Velocity;   // 0x000000 (0x000004) [Default: 1.43941e-26f]
    };

    struct UAttachableWheelsComponent___DetachAllWheels_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344888592]
    };

    struct UAttachableWheelsComponent___GetAttachedWheelClosestOnAxis_Params
    {
        FVector             Point;                          // 0x000000 (0x000018) [OutParam]
        float               OutClosetDistanceToAxis;        // 0x000018 (0x000004) [OutParam] [Default: 1.29755e-23f]
        uint8               UnknownData_00001C[0x000004];   // 0x00001C (0x000004)
        FVector             OutClosestPointOnAxis;          // 0x000020 (0x000018) [OutParam]
        FVector             OutClosestAxis;                 // 0x000038 (0x000018) [OutParam]
        AAttachableWheel*   ReturnValue;                    // 0x000050 (0x000008) [ReturnValue] [Default: nullptr]
    };

    struct UAttachableWheelsComponent___GetAttachedWheels_Params
    {
        TArray<AAttachableWheel*>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAttachableWheelsComponent___HandleWheelAttached_Internal_Params
    {
        AAttachableWheel*   AttachedWheel;  // 0x000000 (0x000008) [Default: 0x148E9510]
        bool                ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAttachableWheelsComponent___HandleWheelDetached_Internal_Params
    {
        AAttachableWheel*   AttachedWheel;  // 0x000000 (0x000008) [Default: 0x148E9510]
        bool                ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAttachableWheelsComponent___OnWheelAttached_Params
    {
        AAttachableWheel*   AttachedWheel;  // 0x000000 (0x000008) [Default: 0x148E9510]
    };

    struct UAttachableWheelsComponent___OnWheelDetached_Params
    {
        AAttachableWheel*   AttachedWheel;  // 0x000000 (0x000008) [Default: 0x148E9510]
    };

    struct UAttachableWheelsComponent___SetMaxChassisMassFraction_Params
    {
        float   InMaxChassisMassFraction;   // 0x000000 (0x000004) [Default: 1.43971e-26f]
    };

} // namespace UE

