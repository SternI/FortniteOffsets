/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BattleRoyaleGameplayAlerts
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000120 (0x000058)
    class UGameplayAlertsControllerComponent : public UFortControllerComponent
    {
    public:
        uint8   UnknownData_0000C8[0x000058];   // 0x0000C8 (0x000058)
    };
    // Size: 0x000004 (0x000004)
    struct alignas(0x4) FFortEvent_AddGameplayAlertRequested
    {
        FGameplayTag    GameplayAlertTag;   // 0x000000 (0x000004)
    };
    // Size: 0x000004 (0x000004)
    struct alignas(0x4) FFortEvent_CurrentGameplayAlertChanged
    {
        FGameplayTag    GameplayAlertTag;   // 0x000000 (0x000004)
    };
    // Size: 0x000004 (0x000004)
    struct alignas(0x4) FFortEvent_RemoveGameplayAlertRequested
    {
        FGameplayTag    GameplayAlertTag;   // 0x000000 (0x000004)
    };
}

