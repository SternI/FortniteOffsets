/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:48
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ACLPlugin_Functions
 * ============================================================
 */

#include "ACLPlugin_Functions.hpp"

namespace UE
{

    ACLVisualFidelity UAnimationCompressionLibraryDatabase::GetVisualFidelity(UAnimationCompressionLibraryDatabase* DatabaseAsset)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ACLPlugin.AnimationCompressionLibraryDatabase.GetVisualFidelity");
    
        UAnimationCompressionLibraryDatabase___GetVisualFidelity_Params Params{};
        Params.DatabaseAsset = DatabaseAsset;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAnimationCompressionLibraryDatabase::SetVisualFidelity(UObject* WorldContextObject, FLatentActionInfo LatentInfo, UAnimationCompressionLibraryDatabase* DatabaseAsset, ACLVisualFidelityChangeResult& Result, ACLVisualFidelity VisualFidelity)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ACLPlugin.AnimationCompressionLibraryDatabase.SetVisualFidelity");
    
        UAnimationCompressionLibraryDatabase___SetVisualFidelity_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.LatentInfo = LatentInfo;
        Params.DatabaseAsset = DatabaseAsset;
        Params.Result = Result;
        Params.VisualFidelity = VisualFidelity;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Result = Params.Result;
    }

} // namespace UE

