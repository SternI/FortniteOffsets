/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BeanstalkDevicesCoreRuntime_Functions
 * ============================================================
 */

#include "BeanstalkDevicesCoreRuntime.hpp"

namespace UE
{

    struct ABeanObstacleTickManager___OnTickableComponentEndPlay_Params
    {
        AActor*                     Actor;          // 0x000000 (0x000008) [Default: 0x149526A0]
        TEnumAsByte<EEndPlayReason> EndPlayReason;  // 0x000008 (0x000001) [Default: 49]
    };

    struct UBeanDeviceFunctionLibrary___CalculateKnockbackForce_Params
    {
        FBeanKnockbackForceCalculator   KnockbackForceCalculator;   // 0x000000 (0x000030) [OutParam]
        FVector                         SourceLocation;             // 0x000030 (0x000018)
        FVector                         TargetLocation;             // 0x000048 (0x000018)
        FVector                         ReturnValue;                // 0x000060 (0x000018) [ReturnValue]
    };

    struct UBeanObstacleImpactComponent___OnAffectedComponentHit_Params
    {
        UPrimitiveComponent*    HitComponent;   // 0x000000 (0x000008) [Default: 0x149502A0]
        AActor*                 OtherActor;     // 0x000008 (0x000008) [Default: 0xC6318DD00000031]
        UPrimitiveComponent*    OtherComp;      // 0x000010 (0x000008) [Default: 0x19887A00]
        FVector                 NormalImpulse;  // 0x000018 (0x000018)
        FHitResult              Hit;            // 0x000030 (0x0000F8) [OutParam]
    };

    struct UBeanObstacleImpactComponent___OnSleepStateChanged_Params
    {
        bool    bIsSleeping;    // 0x000000 (0x000001) [Default: true]
    };

    struct UBeanObstacleMeshSelectorComponent___SetSelectedMeshIndex_Params
    {
        int32   MeshIndex;      // 0x000000 (0x000004) [Default: 345311184]
        bool    ReturnValue;    // 0x000004 (0x000001) [ReturnValue] [Default: false]
    };

    struct UBeanObstacleMovementComponent___IsMotionLocked_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBeanObstacleMovementComponent___IsRewinding_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBeanObstacleMovementComponent___OnRep_ObstacleMotionRuntimeState_Params
    {
        FBeanObstacleMotionRuntimeState OldRuntimeState;    // 0x000000 (0x000030) [OutParam]
    };

    struct UBeanObstacleMovementComponent___OnSleepStateChanged_Params
    {
        bool    bIsSleeping;    // 0x000000 (0x000001) [Default: true]
    };

    struct UBeanObstacleMovementComponent___SetIsMotionLocked_Params
    {
        bool    bNewIsLocked;       // 0x000000 (0x000001) [Default: true]
        bool    bResetToInitial;    // 0x000001 (0x000001) [Default: true]
    };

    struct UBeanObstacleMovementComponent___SetIsRewinding_Params
    {
        bool    bNewRewind; // 0x000000 (0x000001) [Default: true]
    };

    struct UBeanObstacleOptimizerComponent___OnOptimizerBeginOverlap_Params
    {
        UPrimitiveComponent*    OverlappedComp;                 // 0x000000 (0x000008) [Default: 0x14951A10]
        AActor*                 OtherActor;                     // 0x000008 (0x000008) [Default: 0x66318DD00000031]
        UPrimitiveComponent*    OtherComp;                      // 0x000010 (0x000008) [Default: 0x1988BD40]
        int32                   OtherBodyIndex;                 // 0x000018 (0x000004) [Default: 428368144]
        bool                    bFromSweep;                     // 0x00001C (0x000001) [Default: false]
        uint8                   UnknownData_00001D[0x000003];   // 0x00001D (0x000003)
        FHitResult              SweepResult;                    // 0x000020 (0x0000F8) [OutParam]
    };

    struct UBeanObstacleOptimizerComponent___OnOptimizerEndOverlap_Params
    {
        UPrimitiveComponent*    OverlappedComponent;    // 0x000000 (0x000008) [Default: 0x14951A10]
        AActor*                 OtherActor;             // 0x000008 (0x000008) [Default: 0x66318DD00000031]
        UPrimitiveComponent*    OtherComp;              // 0x000010 (0x000008) [Default: 0x1988BD40]
        int32                   OtherBodyIndex;         // 0x000018 (0x000004) [Default: 428368144]
    };

    struct UBeanObstacleOptimizerComponent___OnOriginalOwnerEndPlay_Params
    {
        AActor*                     Actor;          // 0x000000 (0x000008) [Default: 0x14951A10]
        TEnumAsByte<EEndPlayReason> EndPlayReason;  // 0x000008 (0x000001) [Default: 49]
    };

    struct UBeanObstacleOptimizerComponent___OnSleepStateChanged_Params
    {
        bool    bIsSleeping;    // 0x000000 (0x000001) [Default: true]
    };

} // namespace UE

