/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioGameplayVolume_Functions
 * ============================================================
 */

#include "AudioGameplayVolume_Functions.hpp"

namespace UE
{

    void AAudioGameplayVolume::OnListenerEnter()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayVolume.AudioGameplayVolume.OnListenerEnter");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AAudioGameplayVolume::OnListenerExit()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayVolume.AudioGameplayVolume.OnListenerExit");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AAudioGameplayVolume::OnRep_bEnabled()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayVolume.AudioGameplayVolume.OnRep_bEnabled");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AAudioGameplayVolume::SetEnabled(bool bEnable)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayVolume.AudioGameplayVolume.SetEnabled");
    
        AAudioGameplayVolume___SetEnabled_Params Params{};
        Params.bEnable = bEnable;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAttenuationVolumeComponent::SetExteriorVolume(float Volume, float InterpolateTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayVolume.AttenuationVolumeComponent.SetExteriorVolume");
    
        UAttenuationVolumeComponent___SetExteriorVolume_Params Params{};
        Params.Volume = Volume;
        Params.InterpolateTime = InterpolateTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAttenuationVolumeComponent::SetInteriorVolume(float Volume, float InterpolateTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayVolume.AttenuationVolumeComponent.SetInteriorVolume");
    
        UAttenuationVolumeComponent___SetInteriorVolume_Params Params{};
        Params.Volume = Volume;
        Params.InterpolateTime = InterpolateTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioGameplayVolumeMutator::SetPriority(int32 InPriority)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayVolume.AudioGameplayVolumeMutator.SetPriority");
    
        UAudioGameplayVolumeMutator___SetPriority_Params Params{};
        Params.InPriority = InPriority;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFilterVolumeComponent::SetExteriorLPF(float Volume, float InterpolateTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayVolume.FilterVolumeComponent.SetExteriorLPF");
    
        UFilterVolumeComponent___SetExteriorLPF_Params Params{};
        Params.Volume = Volume;
        Params.InterpolateTime = InterpolateTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFilterVolumeComponent::SetInteriorLPF(float Volume, float InterpolateTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayVolume.FilterVolumeComponent.SetInteriorLPF");
    
        UFilterVolumeComponent___SetInteriorLPF_Params Params{};
        Params.Volume = Volume;
        Params.InterpolateTime = InterpolateTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UReverbVolumeComponent::SetReverbSettings(FReverbSettings& NewReverbSettings)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayVolume.ReverbVolumeComponent.SetReverbSettings");
    
        UReverbVolumeComponent___SetReverbSettings_Params Params{};
        Params.NewReverbSettings = NewReverbSettings;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        NewReverbSettings = Params.NewReverbSettings;
    }

    void USubmixOverrideVolumeComponent::SetSubmixOverrideSettings(TArray<FAudioVolumeSubmixOverrideSettings>& NewSubmixOverrideSettings)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayVolume.SubmixOverrideVolumeComponent.SetSubmixOverrideSettings");
    
        USubmixOverrideVolumeComponent___SetSubmixOverrideSettings_Params Params{};
        Params.NewSubmixOverrideSettings = NewSubmixOverrideSettings;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        NewSubmixOverrideSettings = Params.NewSubmixOverrideSettings;
    }

    void USubmixSendVolumeComponent::SetSubmixSendSettings(TArray<FAudioVolumeSubmixSendSettings>& NewSubmixSendSettings)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayVolume.SubmixSendVolumeComponent.SetSubmixSendSettings");
    
        USubmixSendVolumeComponent___SetSubmixSendSettings_Params Params{};
        Params.NewSubmixSendSettings = NewSubmixSendSettings;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        NewSubmixSendSettings = Params.NewSubmixSendSettings;
    }

} // namespace UE

