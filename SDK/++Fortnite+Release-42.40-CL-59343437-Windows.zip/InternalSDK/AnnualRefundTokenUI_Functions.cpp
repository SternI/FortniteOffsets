/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnnualRefundTokenUI_Functions
 * ============================================================
 */

#include "AnnualRefundTokenUI_Functions.hpp"

namespace UE
{

    void UFortAnnualRefundTicket::OnPlayLockingAnimation()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnualRefundTokenUI.FortAnnualRefundTicket.OnPlayLockingAnimation");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortAnnualRefundTicket::OnUpdateAvailableState(bool bIsAvailable)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnualRefundTokenUI.FortAnnualRefundTicket.OnUpdateAvailableState");
    
        UFortAnnualRefundTicket___OnUpdateAvailableState_Params Params{};
        Params.bIsAvailable = bIsAvailable;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortAnnualRefundTicket::OnUpdatePendingState(bool bIsPending)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnualRefundTokenUI.FortAnnualRefundTicket.OnUpdatePendingState");
    
        UFortAnnualRefundTicket___OnUpdatePendingState_Params Params{};
        Params.bIsPending = bIsPending;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortPurchaseHistoryBundleEntry::SetExpandButtonText(int32 NumPurchases)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnualRefundTokenUI.FortPurchaseHistoryBundleEntry.SetExpandButtonText");
    
        UFortPurchaseHistoryBundleEntry___SetExpandButtonText_Params Params{};
        Params.NumPurchases = NumPurchases;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortPurchaseHistoryEntry::OnSetHistory(bool bHasBeenRefunded, bool bIsCancelPurchaseEligible, bool bIsTokenlessRefund, bool bPlayerHasTokens, bool bNonRefundable, bool IsPartOfABundle, bool IsNextRefundable, int32 IndexInBundle, int32 NumPurchasesInBundle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnualRefundTokenUI.FortPurchaseHistoryEntry.OnSetHistory");
    
        UFortPurchaseHistoryEntry___OnSetHistory_Params Params{};
        Params.bHasBeenRefunded = bHasBeenRefunded;
        Params.bIsCancelPurchaseEligible = bIsCancelPurchaseEligible;
        Params.bIsTokenlessRefund = bIsTokenlessRefund;
        Params.bPlayerHasTokens = bPlayerHasTokens;
        Params.bNonRefundable = bNonRefundable;
        Params.IsPartOfABundle = IsPartOfABundle;
        Params.IsNextRefundable = IsNextRefundable;
        Params.IndexInBundle = IndexInBundle;
        Params.NumPurchasesInBundle = NumPurchasesInBundle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortPurchaseHistoryEntry::SetPurchaseText(FText& PurchaseDateText, FText& RefundDateText, bool bHasBeenRefunded, EFortPurchaseHistoryRefundType RefundType)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnualRefundTokenUI.FortPurchaseHistoryEntry.SetPurchaseText");
    
        UFortPurchaseHistoryEntry___SetPurchaseText_Params Params{};
        Params.PurchaseDateText = PurchaseDateText;
        Params.RefundDateText = RefundDateText;
        Params.bHasBeenRefunded = bHasBeenRefunded;
        Params.RefundType = RefundType;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PurchaseDateText = Params.PurchaseDateText;
        RefundDateText = Params.RefundDateText;
    }

    void UFortPurchaseHistoryEntry::SetupItemCard(UFortCosmeticItemCard* ItemCard, UFortItem* Item)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnualRefundTokenUI.FortPurchaseHistoryEntry.SetupItemCard");
    
        UFortPurchaseHistoryEntry___SetupItemCard_Params Params{};
        Params.ItemCard = ItemCard;
        Params.Item = Item;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortPurchaseHistoryEntryBase::UpdateItemList(TArray<UFortCosmeticItemCard*>& ItemCards)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnualRefundTokenUI.FortPurchaseHistoryEntryBase.UpdateItemList");
    
        UFortPurchaseHistoryEntryBase___UpdateItemList_Params Params{};
        Params.ItemCards = ItemCards;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ItemCards = Params.ItemCards;
    }

    bool UFortPurchaseHistoryScreen::BP_IsShowingPurchases()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnualRefundTokenUI.FortPurchaseHistoryScreen.BP_IsShowingPurchases");
    
        UFortPurchaseHistoryScreen___BP_IsShowingPurchases_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortPurchaseHistoryScreen::FilterMtxPurchaseHistoryByOffer(UFortItemShopOfferVM* InOffer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnualRefundTokenUI.FortPurchaseHistoryScreen.FilterMtxPurchaseHistoryByOffer");
    
        UFortPurchaseHistoryScreen___FilterMtxPurchaseHistoryByOffer_Params Params{};
        Params.InOffer = InOffer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortPurchaseHistoryScreen::OnBeginRefundSubmission()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnBeginRefundSubmission");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortPurchaseHistoryScreen::OnEndRefundSubmission()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnEndRefundSubmission");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortPurchaseHistoryScreen::OnNoPurchasesAvailable()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnNoPurchasesAvailable");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortPurchaseHistoryScreen::OnPopulateView()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnPopulateView");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortPurchaseHistoryScreen::ShowStandaloneBackButton()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnualRefundTokenUI.FortPurchaseHistoryScreen.ShowStandaloneBackButton");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortRefundConfirmation::BP_UpdateItemsList(TArray<UFortItemDefinition*>& SelectedItemDefs, int32 TotalMtxPaid)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnualRefundTokenUI.FortRefundConfirmation.BP_UpdateItemsList");
    
        UFortRefundConfirmation___BP_UpdateItemsList_Params Params{};
        Params.SelectedItemDefs = SelectedItemDefs;
        Params.TotalMtxPaid = TotalMtxPaid;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SelectedItemDefs = Params.SelectedItemDefs;
    }

    void UFortRefundConfirmation::BP_UpdateRefundType(EFortPurchaseHistoryRefundType RefundType, bool bBundledRefund)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnualRefundTokenUI.FortRefundConfirmation.BP_UpdateRefundType");
    
        UFortRefundConfirmation___BP_UpdateRefundType_Params Params{};
        Params.RefundType = RefundType;
        Params.bBundledRefund = bBundledRefund;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

