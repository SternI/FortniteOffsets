/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AIProgressBarRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0003C8 (0x000158)
    class alignas(0x8) AChallengeManagerBase : public AActor
    {
    public:
        MULTI_INLINE_DELEGATE(OnBossProgressUpdated)    OnBossProgressUpdated;              // 0x000270 (0x000010)
        MULTI_INLINE_DELEGATE(OnCurrentStateUpdated)    OnCurrentStateUpdated;              // 0x000280 (0x000010)
        MULTI_INLINE_DELEGATE(OnChallengeBegun)         OnChallengeBegun;                   // 0x000290 (0x000010)
        MULTI_INLINE_DELEGATE(OnStageAdvanced)          OnStageAdvanced;                    // 0x0002A0 (0x000010)
        MULTI_INLINE_DELEGATE(OnBossReadyForFinalFight) OnBossReadyForFinalFight;           // 0x0002B0 (0x000010)
        MULTI_INLINE_DELEGATE(OnTotalProgressUpdated)   OnTotalProgressUpdated;             // 0x0002C0 (0x000010)
        UFortAthenaLivingWorldEncounterInstance*        EncounterRef;                       // 0x0002D0 (0x000008) [Default: nullptr]
        FGameplayTag                                    ChallengeIDTag;                     // 0x0002D8 (0x000004)
        uint8                                           UnknownData_0002DC[0x000004];       // 0x0002DC (0x000004)
        FGameplayTagContainer                           LooseTagToApplyWhileInChallenge;    // 0x0002E0 (0x000020)
        FGameplayTag                                    CurrentChallengeID;                 // 0x000300 (0x000004)
        bool                                            bBossDeathCompletesChallenge;       // 0x000304 (0x000001) [Default: false]
        uint8                                           UnknownData_000305[0x000003];       // 0x000305 (0x000003)
        FGameplayTag                                    BossIDTag;                          // 0x000308 (0x000004)
        uint8                                           UnknownData_00030C[0x000004];       // 0x00030C (0x000004)
        AActor*                                         BossActor;                          // 0x000310 (0x000008) [Default: nullptr]
        bool                                            bIsBossReadyForFinalFight;          // 0x000318 (0x000001) [Default: false]
        uint8                                           UnknownData_000319[0x000007];       // 0x000319 (0x000007)
        TArray<FAIProgressBarStageData>                 StageData;                          // 0x000320 (0x000010)
        bool                                            bCountMinionDeathForProgress;       // 0x000330 (0x000001) [Default: false]
        uint8                                           UnknownData_000331[0x000007];       // 0x000331 (0x000007)
        double                                          BossProgress;                       // 0x000338 (0x000008) [Default: 0]
        EChallengeState                                 CurrentState;                       // 0x000340 (0x000001) [Default: EChallengeState(0)]
        uint8                                           UnknownData_000341[0x000003];       // 0x000341 (0x000003)
        int32                                           CurrentStage;                       // 0x000344 (0x000004) [Default: 0]
        int32                                           CurrentPhase;                       // 0x000348 (0x000004) [Default: 0]
        int32                                           CurrentPhaseProgress;               // 0x00034C (0x000004) [Default: 0]
        int32                                           CurrentPhaseProgressTarget;         // 0x000350 (0x000004) [Default: 0]
        uint8                                           UnknownData_000354[0x000004];       // 0x000354 (0x000004)
        TArray<int32>                                   PhaseProgressTargets;               // 0x000358 (0x000010)
        int32                                           TotalProgress;                      // 0x000368 (0x000004) [Default: 0]
        uint8                                           UnknownData_00036C[0x000004];       // 0x00036C (0x000004)
        TArray<int32>                                   TotalProgressToStageAdvance;        // 0x000370 (0x000010)
        int32                                           GoalTargetIndexByPlaylist;          // 0x000380 (0x000004) [Default: 0]
        FGameplayTag                                    CurrentPhaseMusicTag;               // 0x000384 (0x000004)
        TArray<FGameplayTag>                            PhaseMusicTags;                     // 0x000388 (0x000010)
        FScalableFloat                                  RowDisableMapIconOnBossSpawn;       // 0x000398 (0x000028)
        uint8                                           UnknownData_0003C0[0x000008];       // 0x0003C0 (0x000008)
    
    public: // Functions
        void                    AdvanceChallenge(); // 0x0DDE740C [Native | Event | Protected | BlueprintCallable | BlueprintEvent]
        void                    BindToBossPawnEvents(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void                    CleanupEncounter(); // 0x10BA2070 [Final | Native | Public | BlueprintCallable]
        void                    DespawnAllMinions(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void                    DisableMapIcon(); // 0x000545D2 [Event | Protected | BlueprintCallable | BlueprintEvent]
        void                    FinishTransition(); // 0x0C98478C [Native | Event | Protected | BlueprintCallable | BlueprintEvent]
        AActor*                 GetBossActor(); // 0x10BA21D0 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FGameplayTag            GetBossIDTag(); // 0x0CAFA6CA [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32                   GetCurrentPhaseProgressTarget(); // 0x10BA21EC [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        FAIProgressBarStageData GetCurrentStageData(); // 0x10BA222E [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        EChallengeState         GetCurrentState(); // 0x10BA2342 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FGameplayTag            GetMusicTagByPhase(); // 0x10BA235C [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        int32                   GetStageGoalTarget(); // 0x10BA2398 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        int32                   GetStageTotalProgressGoal(int32 Stage); // 0x07E94630 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        void                    HandleActorDied(UFortAthenaLivingWorldEncounterInstance* EncounterInstance, AActor* DiedActor); // 0x07E947BC [Native | Event | Protected | BlueprintCallable | BlueprintEvent]
        void                    HandleBossDied(); // 0x10BA2436 [Final | Native | Public | BlueprintCallable]
        void                    HandleBossHealthChanged(); // 0x0C98A4E4 [Native | Event | Protected | BlueprintCallable | BlueprintEvent]
        void                    HandleBossSpawned(AActor* SpawnedActor); // 0x07E94A46 [Native | Event | Public | BlueprintCallable | BlueprintEvent]
        void                    HandlePawnSpawned(UFortAthenaLivingWorldEncounterInstance* EncounterInstance, AActor* SpawnedActor, UFortAthenaLivingWorldEventData* EventData); // 0x07E94BBC [Native | Event | Protected | BlueprintCallable | BlueprintEvent]
        bool                    IncrementProgress(); // 0x10BA2530 [Final | Native | Protected | BlueprintCallable]
        bool                    IsBossReadyForFinalFight(); // 0x10BA25FC [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                    OnRep_BossProgress(); // 0x1065AE82 [Final | Native | Protected]
        void                    OnRep_CurrentState(); // 0x10BA2616 [Final | Native | Protected]
        void                    OnRep_IsBossReadyForFinalFight(); // 0x10BA2694 [Final | Native | Protected]
        void                    OnRep_TotalProgress(); // 0x10BA26F8 [Final | Native | Protected]
        void                    PlayTransitionEffects(); // 0x000545D2 [Event | Protected | BlueprintCallable | BlueprintEvent]
        void                    RequestPawnEnterArena(AActor* Actor); // 0x0425BEC6 [Native | Event | Public | BlueprintCallable | BlueprintEvent]
        void                    RequestPawnExitArena(AActor* Actor); // 0x074ED5FE [Native | Event | Public | BlueprintCallable | BlueprintEvent]
        void                    ResetProgress(); // 0x0FBA4E48 [Native | Event | Public | BlueprintCallable | BlueprintEvent]
        void                    SetAIProgressBarChallengeRef(AActor* Actor, bool bSetToSelf); // 0x000545D2 [Event | Protected | BlueprintCallable | BlueprintEvent]
        void                    SetCurrentState(EChallengeState NewState); // 0x07E94F5C [Final | Native | Public | BlueprintCallable]
        void                    SetIsBossReadyForFinalFight(bool bIsReady); // 0x07E950CA [Final | Native | Public | BlueprintCallable]
        void                    SetPhaseMusicEvent(); // 0x000545D2 [Event | Protected | BlueprintCallable | BlueprintEvent]
        bool                    ShouldAdvanceStage(); // 0x10BA27A2 [Final | Native | Protected | BlueprintCallable]
        void                    SpawnReward(AActor* Boss); // 0x000545D2 [Event | Public | BlueprintCallable | BlueprintEvent]
        void                    StartChallenegeAfterDelay(); // 0x0CBB274C [Native | Event | Public | BlueprintCallable | BlueprintEvent]
        void                    StartChallenge(); // 0x10BA27E6 [Final | Native | Public | BlueprintCallable]
        void                    StartSimpleChallenge(); // 0x0CB66890 [Native | Event | Public | BlueprintCallable | BlueprintEvent]
        void                    TransitionToStage(); // 0x0C98A4CA [Native | Event | Protected | BlueprintCallable | BlueprintEvent]
        void                    UnbindToBossPawnEvents(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void                    UpdateChallengeState(EChallengeState NewState); // 0x07E9523A [Final | Native | Protected | BlueprintCallable]
        void                    UpdateCurrentPhase(); // 0x0C98A4B0 [Native | Event | Protected | BlueprintCallable | BlueprintEvent]
        void                    UpdateMapIconByState(EChallengeState ChallengeState); // 0x000545D2 [Event | Protected | BlueprintCallable | BlueprintEvent]
        void                    UpdateMusicTagOnSpawnedActors(); // 0x000545D2 [Event | Protected | BlueprintCallable | BlueprintEvent]
        void                    OnBossProgressUpdated(); // 0x000545D2 [MulticastDelegate | Public | Delegate]
        void                    OnBossReadyForFinalFight(); // 0x000545D2 [MulticastDelegate | Public | Delegate]
        void                    OnChallengeBegun(); // 0x000545D2 [MulticastDelegate | Public | Delegate]
        void                    OnCurrentStateUpdated(); // 0x000545D2 [MulticastDelegate | Public | Delegate]
        void                    OnStageAdvanced(int32 NewStage); // 0x000545D2 [MulticastDelegate | Public | Delegate]
        void                    OnTotalProgressUpdated(); // 0x000545D2 [MulticastDelegate | Public | Delegate]
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FAIProgressBarStageData
    {
        TArray<int32>   GoalTarget;                             // 0x000000 (0x000010)
        int32           Phase;                                  // 0x000010 (0x000004)
        bool            bDespawnWave;                           // 0x000014 (0x000001)
        uint8           UnknownData_000015[0x000003];           // 0x000015 (0x000003)
        float           PostStageDelay;                         // 0x000018 (0x000004)
        bool            bAdvancesLWEncounterStage;              // 0x00001C (0x000001)
        bool            bShouldPlayTransitionOnStageFinished;   // 0x00001D (0x000001)
        uint8           UnknownData_00001E[0x000002];           // 0x00001E (0x000002)
    };
}

