/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/Area51GunRuntime_Functions
 * ============================================================
 */

#include "Area51GunRuntime.hpp"

namespace UE
{

    struct IArea51WeaponAnimInterface___GetAnimData_Params
    {
        EArea51BeamStates   BeamState;  // 0x000000 (0x000001) [OutParam] [Default: EArea51BeamStates(112)]
    };

    struct UChainLightningArc___GetTargetActor_Params
    {
        AActor* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x148B8D30]
    };

    struct UFortActorComponent_ChainLightning___ActivateLightning_Params
    {
        FVector StartLocation;      // 0x000000 (0x000018)
        FVector HitNormal;          // 0x000018 (0x000018)
        AActor* InstigatorActor;    // 0x000030 (0x000008) [Default: 0x130A96B0]
    };

    struct UFortActorComponent_ChainLightning___DebugTraceServerAndClient_Params
    {
        FVector TraceStart;     // 0x000000 (0x000018)
        FVector TraceEnd;       // 0x000018 (0x000018)
        bool    bServerCalled;  // 0x000030 (0x000001) [Default: true]
    };

    struct UFortActorComponent_ChainLightning___GetSourceLocation_Params
    {
        FVector ReturnValue;    // 0x000000 (0x000018) [ReturnValue]
    };

    struct UFortActorComponent_ChainLightning___IsLightningActive_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UFortActorComponent_ChainLightning___ServerApplyDamageEffect_Params
    {
        FHitResult      Target;     // 0x000000 (0x0000F8)
        TArray<uint8>   Context;    // 0x0000F8 (0x000010)
    };

    struct UFortActorComponent_ChainLightning___SetSourceLocation_Params
    {
        FVector NewLocation;    // 0x000000 (0x000018)
        FVector NewHitNormal;   // 0x000018 (0x000018)
    };

} // namespace UE

