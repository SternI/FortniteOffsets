/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AIPrompt_Functions
 * ============================================================
 */

#include "AIPrompt_Functions.hpp"

namespace UE
{

    void UAIPromptOratorInputControllerComponent::ClearActiveConversationID()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.AIPromptOratorInputControllerComponent.ClearActiveConversationID");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAIPromptOratorInputControllerComponent::ClearPTTTimer()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.AIPromptOratorInputControllerComponent.ClearPTTTimer");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAIPromptOratorInputControllerComponent::OnEnableInput(bool InInputEnabled)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.AIPromptOratorInputControllerComponent.OnEnableInput");
    
        UAIPromptOratorInputControllerComponent___OnEnableInput_Params Params{};
        Params.InInputEnabled = InInputEnabled;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPromptOratorInputControllerComponent::OnMuteChangedEvent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.AIPromptOratorInputControllerComponent.OnMuteChangedEvent");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAIPromptOratorInputControllerComponent::OnSetInHearingRange(bool bInInHearingRange)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.AIPromptOratorInputControllerComponent.OnSetInHearingRange");
    
        UAIPromptOratorInputControllerComponent___OnSetInHearingRange_Params Params{};
        Params.bInInHearingRange = bInInHearingRange;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPromptOratorInputControllerComponent::PushToTalkEnded(FInputActionInstance& ActionData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.AIPromptOratorInputControllerComponent.PushToTalkEnded");
    
        UAIPromptOratorInputControllerComponent___PushToTalkEnded_Params Params{};
        Params.ActionData = ActionData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ActionData = Params.ActionData;
    }

    void UAIPromptOratorInputControllerComponent::SetActiveConversationID(FGuid InActiveConversationID)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.AIPromptOratorInputControllerComponent.SetActiveConversationID");
    
        UAIPromptOratorInputControllerComponent___SetActiveConversationID_Params Params{};
        Params.InActiveConversationID = InActiveConversationID;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPromptOratorInputControllerComponent::SetInHearingRange(bool InInHearingRange)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.AIPromptOratorInputControllerComponent.SetInHearingRange");
    
        UAIPromptOratorInputControllerComponent___SetInHearingRange_Params Params{};
        Params.InInHearingRange = InInHearingRange;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPromptOratorInputControllerComponent::SetInputEnabled(bool InInputEnabled)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.AIPromptOratorInputControllerComponent.SetInputEnabled");
    
        UAIPromptOratorInputControllerComponent___SetInputEnabled_Params Params{};
        Params.InInputEnabled = InInputEnabled;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPromptOratorInputControllerComponent::StartPushToTalk(FInputActionInstance& ActionData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.AIPromptOratorInputControllerComponent.StartPushToTalk");
    
        UAIPromptOratorInputControllerComponent___StartPushToTalk_Params Params{};
        Params.ActionData = ActionData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ActionData = Params.ActionData;
    }

    void UAIPromptOratorInputControllerComponent::StartvoiceRecording()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.AIPromptOratorInputControllerComponent.StartvoiceRecording");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAIPromptOratorInputControllerComponent::StopVoiceRecording()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.AIPromptOratorInputControllerComponent.StopVoiceRecording");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortAIPromptContainerBase::AddStatusWidget(FGuid& ConversationId, FPersonaUIWidgetLayoutDefinition& WidgetLayoutDefinition, UUserWidget* StatusWidget)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.FortAIPromptContainerBase.AddStatusWidget");
    
        UFortAIPromptContainerBase___AddStatusWidget_Params Params{};
        Params.ConversationId = ConversationId;
        Params.WidgetLayoutDefinition = WidgetLayoutDefinition;
        Params.StatusWidget = StatusWidget;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ConversationId = Params.ConversationId;
        WidgetLayoutDefinition = Params.WidgetLayoutDefinition;
    }

    void UFortAIPromptContainerBase::AddSubtitleWidget(UUserWidget* CustomSubtitleWidget)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.FortAIPromptContainerBase.AddSubtitleWidget");
    
        UFortAIPromptContainerBase___AddSubtitleWidget_Params Params{};
        Params.CustomSubtitleWidget = CustomSubtitleWidget;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UUserWidget* UFortAIPromptContainerBase::GetSubtitleWidgetFromConversationID(FGuid& ConversationId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.FortAIPromptContainerBase.GetSubtitleWidgetFromConversationID");
    
        UFortAIPromptContainerBase___GetSubtitleWidgetFromConversationID_Params Params{};
        Params.ConversationId = ConversationId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ConversationId = Params.ConversationId;
    
        return Params.ReturnValue;
    }

    void UFortAIPromptContainerBase::RemoveStatusWidget(FGuid& ConversationId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.FortAIPromptContainerBase.RemoveStatusWidget");
    
        UFortAIPromptContainerBase___RemoveStatusWidget_Params Params{};
        Params.ConversationId = ConversationId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ConversationId = Params.ConversationId;
    }

    void UFortAIPromptContainerBase::RemoveSubtitleWidget(UUserWidget* CustomSubtitleWidget)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.FortAIPromptContainerBase.RemoveSubtitleWidget");
    
        UFortAIPromptContainerBase___RemoveSubtitleWidget_Params Params{};
        Params.CustomSubtitleWidget = CustomSubtitleWidget;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ULLMPersonaConversationComponent::AddPlayerToPromptList(AController* Controller)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.AddPlayerToPromptList");
    
        ULLMPersonaConversationComponent___AddPlayerToPromptList_Params Params{};
        Params.Controller = Controller;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ULLMPersonaConversationComponent::AddSessionFacts(FLLMFacts& LLMFacts)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.AddSessionFacts");
    
        ULLMPersonaConversationComponent___AddSessionFacts_Params Params{};
        Params.LLMFacts = LLMFacts;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        LLMFacts = Params.LLMFacts;
    }

    void ULLMPersonaConversationComponent::AssignLLMPersonas(TArray<FLLMPersona> InPersonas, FLLMPersona InDefaultPersona)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.AssignLLMPersonas");
    
        ULLMPersonaConversationComponent___AssignLLMPersonas_Params Params{};
        Params.InPersonas = InPersonas;
        Params.InDefaultPersona = InDefaultPersona;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ULLMPersonaConversationComponent::BindDefaultPersonaToPawn(APawn* Pawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.BindDefaultPersonaToPawn");
    
        ULLMPersonaConversationComponent___BindDefaultPersonaToPawn_Params Params{};
        Params.Pawn = Pawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ULLMPersonaConversationComponent::Cleanup()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.Cleanup");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ULLMPersonaConversationComponent::FireAnalyticsEvent_PersonaDeviceSettings(bool bUseCustomWidget, bool bUseSubtitles)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.FireAnalyticsEvent_PersonaDeviceSettings");
    
        ULLMPersonaConversationComponent___FireAnalyticsEvent_PersonaDeviceSettings_Params Params{};
        Params.bUseCustomWidget = bUseCustomWidget;
        Params.bUseSubtitles = bUseSubtitles;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    TArray<APlayerController*> ULLMPersonaConversationComponent::GetParticipantPlayerControllers()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.GetParticipantPlayerControllers");
    
        ULLMPersonaConversationComponent___GetParticipantPlayerControllers_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void ULLMPersonaConversationComponent::OnPlayerVoiceInputStarted(UOratorInputControllerComponent* OratorInputControllerComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.OnPlayerVoiceInputStarted");
    
        ULLMPersonaConversationComponent___OnPlayerVoiceInputStarted_Params Params{};
        Params.OratorInputControllerComponent = OratorInputControllerComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ULLMPersonaConversationComponent::OnPlayerVoiceInputStopped(UOratorInputControllerComponent* OratorInputControllerComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.OnPlayerVoiceInputStopped");
    
        ULLMPersonaConversationComponent___OnPlayerVoiceInputStopped_Params Params{};
        Params.OratorInputControllerComponent = OratorInputControllerComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ULLMPersonaConversationComponent::OpenSession()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.OpenSession");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ULLMPersonaConversationComponent::PostRoundCleanup()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.PostRoundCleanup");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ULLMPersonaConversationComponent::RegisterPlayer(AController* Controller, FPersonaUIParams PersonaUIParams)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.RegisterPlayer");
    
        ULLMPersonaConversationComponent___RegisterPlayer_Params Params{};
        Params.Controller = Controller;
        Params.PersonaUIParams = PersonaUIParams;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ULLMPersonaConversationComponent::RemoveAllPlayerFromPromptList()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.RemoveAllPlayerFromPromptList");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ULLMPersonaConversationComponent::RemovePlayerFromOtherConvos(AController* Controller)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.RemovePlayerFromOtherConvos");
    
        ULLMPersonaConversationComponent___RemovePlayerFromOtherConvos_Params Params{};
        Params.Controller = Controller;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ULLMPersonaConversationComponent::RemovePlayerFromPromptList(AController* Controller)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.RemovePlayerFromPromptList");
    
        ULLMPersonaConversationComponent___RemovePlayerFromPromptList_Params Params{};
        Params.Controller = Controller;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ULLMPersonaConversationComponent::SendDefaultPrompt(FString DefaultPrompt)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.SendDefaultPrompt");
    
        ULLMPersonaConversationComponent___SendDefaultPrompt_Params Params{};
        Params.DefaultPrompt = DefaultPrompt;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ULLMPersonaConversationComponent::SetInterruptBehavior(EInterruptBehavior InInterruptBehavior)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.SetInterruptBehavior");
    
        ULLMPersonaConversationComponent___SetInterruptBehavior_Params Params{};
        Params.InInterruptBehavior = InInterruptBehavior;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ULLMPersonaConversationComponent::SetResponseEventCriteria(TArray<FResponseEventCriteria>& InResponseEventCriteria)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.SetResponseEventCriteria");
    
        ULLMPersonaConversationComponent___SetResponseEventCriteria_Params Params{};
        Params.InResponseEventCriteria = InResponseEventCriteria;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InResponseEventCriteria = Params.InResponseEventCriteria;
    }

    void ULLMPersonaConversationComponent::StopPersonaVoice()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.StopPersonaVoice");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ULLMPersonaConversationComponent::UnregisterAllPlayers()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.UnregisterAllPlayers");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ULLMPersonaConversationComponent::UnregisterPlayer(AController* Controller)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.UnregisterPlayer");
    
        ULLMPersonaConversationComponent___UnregisterPlayer_Params Params{};
        Params.Controller = Controller;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ULLMPersonaConversationComponent::UpdateInstigatorBlockList(APlayerController* Instigator, TArray<FUniqueNetIdRepl>& BlockList)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponent.UpdateInstigatorBlockList");
    
        ULLMPersonaConversationComponent___UpdateInstigatorBlockList_Params Params{};
        Params.Instigator = Instigator;
        Params.BlockList = BlockList;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlockList = Params.BlockList;
    }

    ULLMPersonaConversationComponent* ULLMPersonaConversationComponentHolder::GetLLMPersonaConversationComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.LLMPersonaConversationComponentHolder.GetLLMPersonaConversationComponent");
    
        ULLMPersonaConversationComponentHolder___GetLLMPersonaConversationComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<UClass*> UNPCCharacterModifier_Persona::GetAllowedVoices(bool bRestrictEpicInternalConstructor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.NPCCharacterModifier_Persona.GetAllowedVoices");
    
        UNPCCharacterModifier_Persona___GetAllowedVoices_Params Params{};
        Params.bRestrictEpicInternalConstructor = bRestrictEpicInternalConstructor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UPersonaDelegateWrapper::OnMonologueEventPerceived(FMonologuePerceivedEvent& PerceivedEvent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaDelegateWrapper.OnMonologueEventPerceived");
    
        UPersonaDelegateWrapper___OnMonologueEventPerceived_Params Params{};
        Params.PerceivedEvent = PerceivedEvent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PerceivedEvent = Params.PerceivedEvent;
    }

    void UPersonaDelegateWrapper::OnPlayerUnregistered(AFortPlayerState* UnregisteredPlayerState)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaDelegateWrapper.OnPlayerUnregistered");
    
        UPersonaDelegateWrapper___OnPlayerUnregistered_Params Params{};
        Params.UnregisteredPlayerState = UnregisteredPlayerState;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaOratorComponent::HandleUtteranceCancelled(FGuid UtteranceID)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaOratorComponent.HandleUtteranceCancelled");
    
        UPersonaOratorComponent___HandleUtteranceCancelled_Params Params{};
        Params.UtteranceID = UtteranceID;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaOratorComponent::OnRep_HasLinkedAnimationLayer()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaOratorComponent.OnRep_HasLinkedAnimationLayer");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UPersonaOratorComponent::OnRep_PersonaConversationGuid()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaOratorComponent.OnRep_PersonaConversationGuid");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UPersonaOratorComponent::OnRep_PersonaOratorAudioParams()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaOratorComponent.OnRep_PersonaOratorAudioParams");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UPersonaOratorComponent::TryBindToPersonaUIController()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaOratorComponent.TryBindToPersonaUIController");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    bool UPersonaOratorInputControllerComponent::IsMuted()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaOratorInputControllerComponent.IsMuted");
    
        UPersonaOratorInputControllerComponent___IsMuted_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UPersonaOratorInputControllerComponent::ServerUpdateBlockList(TArray<FUniqueNetIdRepl> BlockList)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaOratorInputControllerComponent.ServerUpdateBlockList");
    
        UPersonaOratorInputControllerComponent___ServerUpdateBlockList_Params Params{};
        Params.BlockList = BlockList;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaOratorInputControllerComponent::ServerUpdateStopVoiceCaptureTime(FDateTime InStopVoiceCaptureTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaOratorInputControllerComponent.ServerUpdateStopVoiceCaptureTime");
    
        UPersonaOratorInputControllerComponent___ServerUpdateStopVoiceCaptureTime_Params Params{};
        Params.InStopVoiceCaptureTime = InStopVoiceCaptureTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaPrompt::ClearHistory()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaPrompt.ClearHistory");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UPersonaPrompt::SendPrompt(FString Topic, bool bIsBatchPrompt, int32 BatchSize, UScriptStruct* StructType)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaPrompt.SendPrompt");
    
        UPersonaPrompt___SendPrompt_Params Params{};
        Params.Topic = Topic;
        Params.bIsBatchPrompt = bIsBatchPrompt;
        Params.BatchSize = BatchSize;
        Params.StructType = StructType;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaUIControllerComponent::AddedToConversation(FGuid PersonaConversation, FPersonaUIParams PersonaUIParams, UPersonaOratorComponent* PersonaOrator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.AddedToConversation");
    
        UPersonaUIControllerComponent___AddedToConversation_Params Params{};
        Params.PersonaConversation = PersonaConversation;
        Params.PersonaUIParams = PersonaUIParams;
        Params.PersonaOrator = PersonaOrator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaUIControllerComponent::HandleHUDElementVisibilityRefreshed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.HandleHUDElementVisibilityRefreshed");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UPersonaUIControllerComponent::OnPlayerAllowedToHearOratorChanged(UOratorControllerComponent* InOratorControllerComponent, bool bPlayerAllowedToHearOrator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.OnPlayerAllowedToHearOratorChanged");
    
        UPersonaUIControllerComponent___OnPlayerAllowedToHearOratorChanged_Params Params{};
        Params.InOratorControllerComponent = InOratorControllerComponent;
        Params.bPlayerAllowedToHearOrator = bPlayerAllowedToHearOrator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaUIControllerComponent::OnPromptIgnored(FGuid PersonaConversation, bool bIsProcessing)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.OnPromptIgnored");
    
        UPersonaUIControllerComponent___OnPromptIgnored_Params Params{};
        Params.PersonaConversation = PersonaConversation;
        Params.bIsProcessing = bIsProcessing;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaUIControllerComponent::OnResponseFailed(FGuid PersonaConversation, ELLMErrorType ErrorType, TArray<EPersonaModerationCategory> TrippedModerationCategories)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.OnResponseFailed");
    
        UPersonaUIControllerComponent___OnResponseFailed_Params Params{};
        Params.PersonaConversation = PersonaConversation;
        Params.ErrorType = ErrorType;
        Params.TrippedModerationCategories = TrippedModerationCategories;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaUIControllerComponent::OnResponseProcessing(FGuid PersonaConversation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.OnResponseProcessing");
    
        UPersonaUIControllerComponent___OnResponseProcessing_Params Params{};
        Params.PersonaConversation = PersonaConversation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaUIControllerComponent::OnResponseReceived(FGuid PersonaConversation, FText ResponseContents, AFortPlayerState* UtteranceInstigator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.OnResponseReceived");
    
        UPersonaUIControllerComponent___OnResponseReceived_Params Params{};
        Params.PersonaConversation = PersonaConversation;
        Params.ResponseContents = ResponseContents;
        Params.UtteranceInstigator = UtteranceInstigator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaUIControllerComponent::OnStartedPlayingAudio(FGuid PersonaConversation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.OnStartedPlayingAudio");
    
        UPersonaUIControllerComponent___OnStartedPlayingAudio_Params Params{};
        Params.PersonaConversation = PersonaConversation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaUIControllerComponent::OnStoppedPlayingAudio(FGuid PersonaConversation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.OnStoppedPlayingAudio");
    
        UPersonaUIControllerComponent___OnStoppedPlayingAudio_Params Params{};
        Params.PersonaConversation = PersonaConversation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaUIControllerComponent::OnVoiceRecordingStarted(FGuid& PersonaConversation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.OnVoiceRecordingStarted");
    
        UPersonaUIControllerComponent___OnVoiceRecordingStarted_Params Params{};
        Params.PersonaConversation = PersonaConversation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PersonaConversation = Params.PersonaConversation;
    }

    void UPersonaUIControllerComponent::OnVoiceRecordingStopped(FGuid& PersonaConversation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.OnVoiceRecordingStopped");
    
        UPersonaUIControllerComponent___OnVoiceRecordingStopped_Params Params{};
        Params.PersonaConversation = PersonaConversation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PersonaConversation = Params.PersonaConversation;
    }

    void UPersonaUIControllerComponent::OpenRequestPermissionScreen()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.OpenRequestPermissionScreen");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UPersonaUIControllerComponent::RemovedFromConversation(FGuid PersonaConversation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.RemovedFromConversation");
    
        UPersonaUIControllerComponent___RemovedFromConversation_Params Params{};
        Params.PersonaConversation = PersonaConversation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaUIControllerComponent::SetConnected(FGuid PersonaConversation, bool bIsConnected)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.SetConnected");
    
        UPersonaUIControllerComponent___SetConnected_Params Params{};
        Params.PersonaConversation = PersonaConversation;
        Params.bIsConnected = bIsConnected;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaUIControllerComponent::SetInHearingRange(FGuid& PersonaConversation, bool bInHearingRange)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.SetInHearingRange");
    
        UPersonaUIControllerComponent___SetInHearingRange_Params Params{};
        Params.PersonaConversation = PersonaConversation;
        Params.bInHearingRange = bInHearingRange;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PersonaConversation = Params.PersonaConversation;
    }

    void UPersonaUIControllerComponent::SetInputEnabled(FGuid& PersonaConversation, bool bInputEnabled)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.SetInputEnabled");
    
        UPersonaUIControllerComponent___SetInputEnabled_Params Params{};
        Params.PersonaConversation = PersonaConversation;
        Params.bInputEnabled = bInputEnabled;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PersonaConversation = Params.PersonaConversation;
    }

    void UPersonaUIControllerComponent::SetMuted(bool bMuted)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.SetMuted");
    
        UPersonaUIControllerComponent___SetMuted_Params Params{};
        Params.bMuted = bMuted;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaUIControllerComponent::SetPersonaIcon(FGuid PersonaConversation, TSoftObjectPtr<UTexture2D> InPersonaIcon)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.SetPersonaIcon");
    
        UPersonaUIControllerComponent___SetPersonaIcon_Params Params{};
        Params.PersonaConversation = PersonaConversation;
        Params.InPersonaIcon = InPersonaIcon;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaUIControllerComponent::SetPersonaName(FGuid PersonaConversation, FString InPersonaName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.SetPersonaName");
    
        UPersonaUIControllerComponent___SetPersonaName_Params Params{};
        Params.PersonaConversation = PersonaConversation;
        Params.InPersonaName = InPersonaName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaUIControllerComponent::SetTimeLeftRecording(FGuid& PersonaConversation, float DeltaTime, float RecordingTimeMax)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUIControllerComponent.SetTimeLeftRecording");
    
        UPersonaUIControllerComponent___SetTimeLeftRecording_Params Params{};
        Params.PersonaConversation = PersonaConversation;
        Params.DeltaTime = DeltaTime;
        Params.RecordingTimeMax = RecordingTimeMax;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PersonaConversation = Params.PersonaConversation;
    }

    void UPersonaUtteranceWrapper::OnOratorCurrentUtteranceClosed(FGuid UtteranceGuid, FString UtteranceText, FString ReplyContentId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUtteranceWrapper.OnOratorCurrentUtteranceClosed");
    
        UPersonaUtteranceWrapper___OnOratorCurrentUtteranceClosed_Params Params{};
        Params.UtteranceGuid = UtteranceGuid;
        Params.UtteranceText = UtteranceText;
        Params.ReplyContentId = ReplyContentId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaUtteranceWrapper::OnOratorUtteranceAudibilityChanged(FGuid UtteranceGuid, bool bIsAudible)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUtteranceWrapper.OnOratorUtteranceAudibilityChanged");
    
        UPersonaUtteranceWrapper___OnOratorUtteranceAudibilityChanged_Params Params{};
        Params.UtteranceGuid = UtteranceGuid;
        Params.bIsAudible = bIsAudible;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaUtteranceWrapper::OnOratorUtteranceCancelled(FGuid UtteranceGuid)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUtteranceWrapper.OnOratorUtteranceCancelled");
    
        UPersonaUtteranceWrapper___OnOratorUtteranceCancelled_Params Params{};
        Params.UtteranceGuid = UtteranceGuid;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaUtteranceWrapper::OnOratorUtteranceEnded(FGuid UtteranceGuid)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUtteranceWrapper.OnOratorUtteranceEnded");
    
        UPersonaUtteranceWrapper___OnOratorUtteranceEnded_Params Params{};
        Params.UtteranceGuid = UtteranceGuid;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPersonaUtteranceWrapper::OnOratorUtteranceStarted(FGuid UtteranceGuid)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPrompt.PersonaUtteranceWrapper.OnOratorUtteranceStarted");
    
        UPersonaUtteranceWrapper___OnOratorUtteranceStarted_Params Params{};
        Params.UtteranceGuid = UtteranceGuid;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

