/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioWorldization_Functions
 * ============================================================
 */

#include "AudioWorldization_Functions.hpp"

namespace UE
{

    TMap<FGameplayTag, int32> UAudioWorldizationSubsystem::GetActorTagCounts()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWorldization.AudioWorldizationSubsystem.GetActorTagCounts");
    
        UAudioWorldizationSubsystem___GetActorTagCounts_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FGameplayTagContainer UAudioWorldizationSubsystem::GetActorTags()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWorldization.AudioWorldizationSubsystem.GetActorTags");
    
        UAudioWorldizationSubsystem___GetActorTags_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAudioWorldizationSubsystem::GetEnclosureFactor()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWorldization.AudioWorldizationSubsystem.GetEnclosureFactor");
    
        UAudioWorldizationSubsystem___GetEnclosureFactor_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAudioWorldizationSubsystem::GetWallDistanceRatio()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWorldization.AudioWorldizationSubsystem.GetWallDistanceRatio");
    
        UAudioWorldizationSubsystem___GetWallDistanceRatio_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAudioWorldizationSubsystem::IsAGVDisabled()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWorldization.AudioWorldizationSubsystem.IsAGVDisabled");
    
        UAudioWorldizationSubsystem___IsAGVDisabled_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioWorldizationSubsystem::OverrideEffectSends(FName InIdentifier, TArray<FAudioWorldizationSend>& InSends)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWorldization.AudioWorldizationSubsystem.OverrideEffectSends");
    
        UAudioWorldizationSubsystem___OverrideEffectSends_Params Params{};
        Params.InIdentifier = InIdentifier;
        Params.InSends = InSends;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InSends = Params.InSends;
    }

    void UAudioWorldizationSubsystem::RemoveEffectSendOverride(FName InIdentifier)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWorldization.AudioWorldizationSubsystem.RemoveEffectSendOverride");
    
        UAudioWorldizationSubsystem___RemoveEffectSendOverride_Params Params{};
        Params.InIdentifier = InIdentifier;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioWorldizationSubsystem::RemoveWorldizationSettings(FName InIdentifier)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWorldization.AudioWorldizationSubsystem.RemoveWorldizationSettings");
    
        UAudioWorldizationSubsystem___RemoveWorldizationSettings_Params Params{};
        Params.InIdentifier = InIdentifier;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioWorldizationSubsystem::SetDefaultSettings()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWorldization.AudioWorldizationSubsystem.SetDefaultSettings");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioWorldizationSubsystem::SetEnabled(bool bNewEnabled)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWorldization.AudioWorldizationSubsystem.SetEnabled");
    
        UAudioWorldizationSubsystem___SetEnabled_Params Params{};
        Params.bNewEnabled = bNewEnabled;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioWorldizationSubsystem::SetWorldizationSettings(FAudioWorldizationSettings& InSettings)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWorldization.AudioWorldizationSubsystem.SetWorldizationSettings");
    
        UAudioWorldizationSubsystem___SetWorldizationSettings_Params Params{};
        Params.InSettings = InSettings;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InSettings = Params.InSettings;
    }

} // namespace UE

