/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AdvancedWidgets
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0006F0 (0x000588)
    class alignas(0x8) URadialSlider : public UWidget
    {
    public:
        float                                                   Value;                          // 0x000168 (0x000004) [Default: 0f]
        GetFloat                                                ValueDelegate;                  // 0x00016C (0x00000C)
        bool                                                    bUseCustomDefaultValue;         // 0x000178 (0x000001) [Default: false]
        uint8                                                   UnknownData_000179[0x000003];   // 0x000179 (0x000003)
        float                                                   CustomDefaultValue;             // 0x00017C (0x000004) [Default: 0f]
        FRuntimeFloatCurve                                      SliderRange;                    // 0x000180 (0x000048)
        TArray<float>                                           ValueTags;                      // 0x0001C8 (0x000010)
        float                                                   SliderHandleStartAngle;         // 0x0001D8 (0x000004) [Default: 60f]
        float                                                   SliderHandleEndAngle;           // 0x0001DC (0x000004) [Default: 300f]
        float                                                   AngularOffset;                  // 0x0001E0 (0x000004) [Default: 0f]
        uint8                                                   UnknownData_0001E4[0x000004];   // 0x0001E4 (0x000004)
        FVector2D                                               HandStartEndRatio;              // 0x0001E8 (0x000010)
        uint8                                                   UnknownData_0001F8[0x000008];   // 0x0001F8 (0x000008)
        FSliderStyle                                            WidgetStyle;                    // 0x000200 (0x000440)
        FLinearColor                                            SliderBarColor;                 // 0x000640 (0x000010)
        FLinearColor                                            SliderProgressColor;            // 0x000650 (0x000010)
        FLinearColor                                            SliderHandleColor;              // 0x000660 (0x000010)
        FLinearColor                                            CenterBackgroundColor;          // 0x000670 (0x000010)
        bool                                                    Locked;                         // 0x000680 (0x000001) [Default: false]
        bool                                                    MouseUsesStep;                  // 0x000681 (0x000001) [Default: false]
        bool                                                    RequiresControllerLock;         // 0x000682 (0x000001) [Default: true]
        uint8                                                   UnknownByte_000683;             // 0x000683 (0x000001)
        float                                                   StepSize;                       // 0x000684 (0x000004) [Default: 0.01f]
        bool                                                    IsFocusable;                    // 0x000688 (0x000001) [Default: true]
        bool                                                    UseVerticalDrag;                // 0x000689 (0x000001) [Default: false]
        bool                                                    ShowSliderHandle;               // 0x00068A (0x000001) [Default: true]
        bool                                                    ShowSliderHand;                 // 0x00068B (0x000001) [Default: false]
        uint8                                                   UnknownData_00068C[0x000004];   // 0x00068C (0x000004)
        MULTI_INLINE_DELEGATE(OnMouseCaptureBeginEvent)         OnMouseCaptureBegin;            // 0x000690 (0x000010)
        MULTI_INLINE_DELEGATE(OnMouseCaptureEndEvent)           OnMouseCaptureEnd;              // 0x0006A0 (0x000010)
        MULTI_INLINE_DELEGATE(OnControllerCaptureBeginEvent)    OnControllerCaptureBegin;       // 0x0006B0 (0x000010)
        MULTI_INLINE_DELEGATE(OnControllerCaptureEndEvent)      OnControllerCaptureEnd;         // 0x0006C0 (0x000010)
        MULTI_INLINE_DELEGATE(OnFloatValueChangedEvent)         OnValueChanged;                 // 0x0006D0 (0x000010)
        uint8                                                   UnknownData_0006E0[0x000010];   // 0x0006E0 (0x000010)
    
    public: // Functions
        float   GetCustomDefaultValue(); // 0x10D583E6 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float   GetNormalizedSliderHandlePosition(); // 0x10D5847C [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float   GetValue(); // 0x10D584B4 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    SetAngularOffset(float InValue); // 0x080051E4 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetCenterBackgroundColor(FLinearColor InValue); // 0x0800536A [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void    SetCustomDefaultValue(float InValue); // 0x080054F6 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetHandStartEndRatio(FVector2D InValue); // 0x08005664 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void    SetLocked(bool InValue); // 0x08005810 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetShowSliderHand(bool InShowSliderHand); // 0x08005980 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetShowSliderHandle(bool InShowSliderHandle); // 0x08005B04 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetSliderBarColor(FLinearColor InValue); // 0x08005C88 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void    SetSliderHandleColor(FLinearColor InValue); // 0x08005E14 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void    SetSliderHandleEndAngle(float InValue); // 0x08005FA0 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetSliderHandleStartAngle(float InValue); // 0x0800613A [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetSliderProgressColor(FLinearColor InValue); // 0x080062D2 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void    SetSliderRange(FRuntimeFloatCurve& InSliderRange); // 0x0800645E [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void    SetStepSize(float InValue); // 0x08006880 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetUseVerticalDrag(bool InUseVerticalDrag); // 0x080069EE [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetValue(float InValue); // 0x08006B72 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetValueTags(TArray<float>& InValueTags); // 0x08006CE0 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x0002E0 (0x0002D8)
    struct alignas(0x8) FColorGradingSpinBoxStyle : public FSlateWidgetStyle
    {
        uint8       UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        FSlateBrush BorderBrush;                    // 0x000010 (0x0000B0)
        FSlateBrush ActiveBorderBrush;              // 0x0000C0 (0x0000B0)
        FSlateBrush HoveredBorderBrush;             // 0x000170 (0x0000B0)
        FSlateBrush SelectorBrush;                  // 0x000220 (0x0000B0)
        float       SelectorWidth;                  // 0x0002D0 (0x000004) [Default: 0f]
        uint8       UnknownData_0002D4[0x00000C];   // 0x0002D4 (0x00000C)
    };
}

