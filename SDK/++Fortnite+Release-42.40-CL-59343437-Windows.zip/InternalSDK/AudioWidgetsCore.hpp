/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioWidgetsCore
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000014 (0x000014)
    struct alignas(0x8) FAudioMeterChannelInfo
    {
        float               MeterValue;         // 0x000000 (0x000004)
        float               PeakValue;          // 0x000004 (0x000004)
        float               ClippingValue;      // 0x000008 (0x000004)
        TOptional<float>    MeterValueBarStart; // 0x00000C (0x000008)
    };
    // Size: 0x000068 (0x000060)
    struct alignas(0x8) FAudioMeterDefaultColorWidgetStyle : public FSlateWidgetStyle
    {
        FLinearColor    MeterBackgroundColor;   // 0x000008 (0x000010)
        FLinearColor    MeterValueColor;        // 0x000018 (0x000010)
        FLinearColor    MeterPeakColor;         // 0x000028 (0x000010)
        FLinearColor    MeterClippingColor;     // 0x000038 (0x000010)
        FLinearColor    MeterScaleColor;        // 0x000048 (0x000010)
        FLinearColor    MeterScaleLabelColor;   // 0x000058 (0x000010)
    };
    // Size: 0x0004E0 (0x0004D8)
    struct alignas(0x8) FAudioMeterWidgetStyle : public FSlateWidgetStyle
    {
        uint8           UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        FSlateBrush     MeterValueImage;                // 0x000010 (0x0000B0)
        FSlateBrush     BackgroundImage;                // 0x0000C0 (0x0000B0)
        FSlateBrush     MeterBackgroundImage;           // 0x000170 (0x0000B0)
        FSlateBrush     MeterValueBackgroundImage;      // 0x000220 (0x0000B0)
        FSlateBrush     MeterPeakImage;                 // 0x0002D0 (0x0000B0)
        FSlateBrush     MeterClippingImage;             // 0x000380 (0x0000B0)
        FVector2D       MeterSize;                      // 0x000430 (0x000010)
        FVector2D       MeterPadding;                   // 0x000440 (0x000010)
        float           MeterValuePadding;              // 0x000450 (0x000004)
        float           PeakValueWidth;                 // 0x000454 (0x000004)
        float           ClippingValueWidth;             // 0x000458 (0x000004)
        uint8           UnknownData_00045C[0x000004];   // 0x00045C (0x000004)
        FVector2D       ValueRangeDb;                   // 0x000460 (0x000010)
        bool            bShowScale;                     // 0x000470 (0x000001)
        bool            bScaleSide;                     // 0x000471 (0x000001)
        uint8           UnknownData_000472[0x000002];   // 0x000472 (0x000002)
        float           ScaleHashOffset;                // 0x000474 (0x000004)
        float           ScaleHashWidth;                 // 0x000478 (0x000004)
        float           ScaleHashHeight;                // 0x00047C (0x000004)
        int32           DecibelsPerHash;                // 0x000480 (0x000004)
        uint8           UnknownData_000484[0x000004];   // 0x000484 (0x000004)
        FSlateFontInfo  Font;                           // 0x000488 (0x000058)
    };
    // Size: 0x000014 (0x000014)
    struct alignas(0x8) FLoudnessMeterDisplayOptions
    {
        bool            bShowValue;         // 0x000000 (0x000001)
        bool            bShowMeter;         // 0x000001 (0x000001)
        bool            bHoldMaxForValue;   // 0x000002 (0x000001)
        bool            bHoldMaxForMeter;   // 0x000003 (0x000001)
        FLinearColor    Color;              // 0x000004 (0x000010)
    };
    // Size: 0x0000A0 (0x0000A0)
    struct alignas(0x8) FLoudnessMeterSettings
    {
        int32                           ConfigVersion;                  // 0x000000 (0x000004)
        int32                           LoudnessScaleRange;             // 0x000004 (0x000004)
        int32                           LoudnessScaleOffset;            // 0x000008 (0x000004)
        int32                           LoudnessScaleTarget;            // 0x00000C (0x000004)
        float                           TruePeakLimit;                  // 0x000010 (0x000004)
        FLinearColor                    TargetColor;                    // 0x000014 (0x000010)
        bool                            bUseRelativeLoudnessScale;      // 0x000024 (0x000001)
        bool                            bDisplayAnalysisTimer;          // 0x000025 (0x000001)
        uint8                           UnknownData_000026[0x000002];   // 0x000026 (0x000002)
        FLoudnessMeterDisplayOptions    LongTermLoudness;               // 0x000028 (0x000014)
        FLoudnessMeterDisplayOptions    ShortTermLoudness;              // 0x00003C (0x000014)
        FLoudnessMeterDisplayOptions    MomentaryLoudness;              // 0x000050 (0x000014)
        FLoudnessMeterDisplayOptions    LoudnessRange;                  // 0x000064 (0x000014)
        FLoudnessMeterDisplayOptions    TruePeak;                       // 0x000078 (0x000014)
        uint8                           UnknownData_00008C[0x000004];   // 0x00008C (0x000004)
        uint64                          ValuesOrderingPermutation;      // 0x000090 (0x000008)
        uint64                          MetersOrderingPermutation;      // 0x000098 (0x000008)
    };
}

