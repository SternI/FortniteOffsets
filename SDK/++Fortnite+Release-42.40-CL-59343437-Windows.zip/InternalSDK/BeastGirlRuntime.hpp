/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BeastGirlRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0060F0 (0x000210)
    class alignas(0x8) ABeastGirlStandInPawn : public AFortStandInPlayerPawn
    {
    public:
        void**                                          VTable_005EE0;                      // 0x005EE0 (0x000008) VTable [3 slots] -> 0x14776990
        MULTI_INLINE_DELEGATE(OnPossessedByController)  OnPossessedByController;            // 0x005EE8 (0x000010)
        MULTI_INLINE_DELEGATE(OnBeastGirlPawnHit)       OnPawnPhysicalHit;                  // 0x005EF8 (0x000010)
        FName                                           HolsterId;                          // 0x005F08 (0x000004) [Default: FName(1694338747) -> L"BeastGirl_Transform"]
        uint8                                           UnknownData_005F0C[0x000004];       // 0x005F0C (0x000004)
        TArray<FGameplayTag>                            InventoryItemsToRemove;             // 0x005F10 (0x000010)
        UFortWorldItemDefinition*                       DefaultWeaponDefinition;            // 0x005F20 (0x000008) [Default: nullptr]
        FScalableFloat                                  HF_OutOfHealthImmediateHeal;        // 0x005F28 (0x000028)
        FScalableFloat                                  HF_OutOfHealthImmediateShield;      // 0x005F50 (0x000028)
        FBeastGirlTransformationData                    ReplicatedTransformationData;       // 0x005F78 (0x000001)
        uint8                                           UnknownData_005F79[0x000007];       // 0x005F79 (0x000007)
        TArray<UCustomCharacterPart*>                   CharacterParts;                     // 0x005F80 (0x000010)
        FBeastGirlTransformationAnimations              OptOutTransformationAnimations;     // 0x005F90 (0x000010)
        FBeastGirlTransformationAnimations              WeakenedTransformationAnimations;   // 0x005FA0 (0x000010)
        FGameplayTag                                    SpriteTag;                          // 0x005FB0 (0x000004)
        bool                                            bHadSpriteEquipped;                 // 0x005FB4 (0x000001) [Default: false]
        uint8                                           UnknownData_005FB5[0x00001F];       // 0x005FB5 (0x00001F)
        float                                           CachedPreviousHealth;               // 0x005FD4 (0x000004) [Default: 0f]
        FGameplayTag                                    PrimaryWeaponActiveTag;             // 0x005FD8 (0x000004)
        FGameplayTag                                    SecondaryWeaponActiveTag;           // 0x005FDC (0x000004)
        FGameplayTag                                    SprintActiveTag;                    // 0x005FE0 (0x000004)
        TWeakObjectPtr<UPrimitiveComponent>             AttachedBaseForTransformation;      // 0x005FE4 (0x000008) [Default: nullptr]
        TWeakObjectPtr<UFortWorldItem>                  DefaultWeaponInstance;              // 0x005FEC (0x000008) [Default: nullptr]
        uint8                                           bIsTransformingInto : 1;            // 0x005FF4 (0x000001) : 0x0 [Default: false]
        uint8                                           UnknownBit_005FF4_1 : 1;            // 0x005FF4 (0x000001) : 0x1
        uint8                                           UnknownBit_005FF4_2 : 1;            // 0x005FF4 (0x000001) : 0x2
        uint8                                           UnknownBit_005FF4_3 : 1;            // 0x005FF4 (0x000001) : 0x3
        uint8                                           UnknownBit_005FF4_4 : 1;            // 0x005FF4 (0x000001) : 0x4
        uint8                                           UnknownBit_005FF4_5 : 1;            // 0x005FF4 (0x000001) : 0x5
        uint8                                           UnknownBit_005FF4_6 : 1;            // 0x005FF4 (0x000001) : 0x6
        uint8                                           UnknownBit_005FF4_7 : 1;            // 0x005FF4 (0x000001) : 0x7
        uint8                                           UnknownData_005FF5[0x000003];       // 0x005FF5 (0x000003)
        UFortAbilitySet*                                PawnAbilitySet;                     // 0x005FF8 (0x000008) [Default: nullptr]
        FGameplayTag                                    BeastGirlActiveDurationTag;         // 0x006000 (0x000004)
        uint8                                           UnknownData_006004[0x000004];       // 0x006004 (0x000004)
        UAthenaCharacterItemDefinition*                 BeastGirlTempCharacter;             // 0x006008 (0x000008) [Default: nullptr]
        UAthenaCharacterItemDefinition*                 CachedCharacter;                    // 0x006010 (0x000008) [Default: nullptr]
        FFortAbilitySetHandle                           AbilitySetHandle;                   // 0x006018 (0x000038)
        uint8                                           UnknownData_006050[0x0000A0];       // 0x006050 (0x0000A0)
    
    public: // Functions
        void                                ApplyWaterJumpCooldown(); // 0x000545D2 [Event | Protected | BlueprintCallable | BlueprintEvent]
        void                                AttachOriginalPawnToMovementBase(); // 0x10E1AA96 [Final | Native | Public | BlueprintCallable]
        void                                BP_HandleTransfomation(); // 0x000545D2 [Event | Public | BlueprintCallable | BlueprintEvent]
        void                                BP_OnOutOfHealth(AFortPawn* OriginalPawn); // 0x000545D2 [Event | Public | BlueprintEvent]
        void                                BP_OnRestoreToOriginalPawn(AFortPawn* OriginalPawn); // 0x000545D2 [Event | Public | BlueprintEvent]
        void                                DestroyPawn(); // 0x10E1AB7E [Final | Native | Public | BlueprintCallable]
        void                                DetachOriginalPawnFromMovingBase(); // 0x10E1ABDE [Final | Native | Public | BlueprintCallable]
        void                                EquipDefaultWeapon(); // 0x10E1ACD0 [Final | Native | Public | BlueprintCallable]
        void                                ForceBackblingVisibility(AFortPlayerPawn* Pawn); // 0x080E369C [Final | Native | Public | BlueprintCallable]
        void                                ForceRefreshEquippedWeapon(AFortWeapon* NewWeapon); // 0x080E380A [Final | Native | Public | BlueprintCallable]
        void                                GameplayTagCallback_InsideSafeZone(FGameplayTag Tag, int32 NewCount); // 0x080E3978 [Final | Native | Private]
        void                                GameplayTagCallback_SprintActive(FGameplayTag Tag, int32 NewCount); // 0x080E3BF0 [Final | Native | Private]
        FBeastGirlTransformationAnimations  GetTransformationAnimations(bool bIsOptOut); // 0x080E3E68 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                                HandleCapsuleHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, FHitResult& Hit); // 0x080E3FEE [Final | Native | Private | HasOutParms | HasDefaults]
        void                                HandleOnWeaponEquipped(AFortWeapon* NewWeapon, AFortWeapon* PrevWeapon); // 0x080E466C [Final | Native | Public]
        void                                OnBeastGirlDidDamage(AActor* DamagedActor, float Damage, AController* InstigatedBy, AActor* DamageCauser, FVector HitLocation, UPrimitiveComponent* FHitComponent, FName BoneName, FVector Momentum); // 0x080E48E8 [Final | Native | Private | HasDefaults]
        void                                OnPlayerEliminated(FFortVerbMessage_PawnEliminated& Event); // 0x080E503A [Final | Native | Private | HasOutParms]
        void                                OnReceiveReplacedPawn(); // 0x000545D2 [Event | Public | BlueprintEvent]
        void                                OnRep_AttachedBaseForTransformation(); // 0x10E1B524 [Final | Native | Private]
        void                                OnRep_bHadSpriteEquipped(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void                                OnRep_Weapon(); // 0x000545D2 [Event | Public | BlueprintEvent]
        void                                ReplaceAndPossess(AFortPlayerPawn* PlayerPawn); // 0x04381806 [Final | Native | Public | BlueprintCallable]
        void                                RestoreToOriginalPawn(AFortPlayerController* FallbackController); // 0x04381806 [Final | Native | Public | BlueprintCallable]
        void                                SetIsTransformingInto(bool bTransformingInto); // 0x080E525E [Final | Native | Public | BlueprintCallable]
        void                                SetReplicatedTransformationData(bool bIsOptOut, bool bIsInWater); // 0x080E53DE [Final | Native | Public | BlueprintCallable]
        static ABeastGirlStandInPawn*              SpawnBeastGirlForPlayerPawn(AFortPlayerPawn* PlayerPawn, UClass* ClassToSpawn); // 0x080E5672 [Final | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x0001F8 (0x000138)
    class alignas(0x8) UBeastGirlTransformationManager : public UActorComponent
    {
    public:
        uint8                       UnknownData_0000C0[0x000028];           // 0x0000C0 (0x000028)
        void**                      VTable_0000E8;                          // 0x0000E8 (0x000008) VTable [6 slots] -> 0x1336B230
        uint8                       UnknownData_0000F0[0x000038];           // 0x0000F0 (0x000038)
        FScalableFloat              HF_RevertTransformFinishHealthToAdd;    // 0x000128 (0x000028)
        FScalableFloat              HF_RevertTransformFinishShieldToAdd;    // 0x000150 (0x000028)
        FScalableFloat              HF_MinimumBeastHealth;                  // 0x000178 (0x000028)
        UClass*                     ReverseTransformationAbility;           // 0x0001A0 (0x000008) [Default: nullptr]
        uint8                       UnknownData_0001A8[0x000018];           // 0x0001A8 (0x000018)
        UClass*                     OptOutTransformationAbility;            // 0x0001C0 (0x000008) [Default: nullptr]
        uint8                       UnknownData_0001C8[0x000018];           // 0x0001C8 (0x000018)
        ABeastGirlStandInPawn*      SpawnedBeastGirlPawn;                   // 0x0001E0 (0x000008) [Default: nullptr]
        UFortWorldItemDefinition*   ConsumableItemDefinition;               // 0x0001E8 (0x000008) [Default: nullptr]
        uint8                       bOptingOut : 1;                         // 0x0001F0 (0x000001) : 0x0 [Default: false]
        uint8                       UnknownBit_0001F0_1 : 1;                // 0x0001F0 (0x000001) : 0x1
        uint8                       UnknownBit_0001F0_2 : 1;                // 0x0001F0 (0x000001) : 0x2
        uint8                       UnknownBit_0001F0_3 : 1;                // 0x0001F0 (0x000001) : 0x3
        uint8                       UnknownBit_0001F0_4 : 1;                // 0x0001F0 (0x000001) : 0x4
        uint8                       UnknownBit_0001F0_5 : 1;                // 0x0001F0 (0x000001) : 0x5
        uint8                       UnknownBit_0001F0_6 : 1;                // 0x0001F0 (0x000001) : 0x6
        uint8                       UnknownBit_0001F0_7 : 1;                // 0x0001F0 (0x000001) : 0x7
        uint8                       UnknownData_0001F1[0x000007];           // 0x0001F1 (0x000007)
    
    public: // Functions
        void    ApplyConsumableDurabilityCost(); // 0x10E1C562 [Final | Native | Public | BlueprintCallable]
        float   GetNewDurability(float FinalBeastGirlHealth, UFortWorldItemDefinition* ItemDefinition); // 0x000545D2 [Event | Protected | BlueprintEvent | Const]
        bool    HasEnoughDurability(AFortWeapon* CurrentWeapon); // 0x000545D2 [Event | Protected | BlueprintEvent | Const]
        bool    NewCode_AddConsumableWithRemainingHealth(); // 0x0C984634 [Final | Native | Public | BlueprintCallable]
        bool    OldCode_AddConsumableWithRemainingHealth(); // 0x0C984634 [Final | Native | Public | BlueprintCallable]
        void    OnRep_BeastGirlPawn(); // 0x0CD2CBCA [Native | Event | Protected | BlueprintEvent]
        void    ResetOptOutFlag(); // 0x10E1C720 [Final | Native | Public | BlueprintCallable]
        void    RestoreOriginalHealthAndShields(); // 0x10E1C738 [Final | Native | Public | BlueprintCallable]
        void    Server_StartReverseTransformation(bool bFromOptOut); // 0x050585E8 [Net | NetReliable | Native | Event | Protected | NetServer]
        void    SetBeastGirlPawn(ABeastGirlStandInPawn* BeastGirlPawn); // 0x0756D326 [Final | Native | Public | BlueprintCallable]
        void    StartReverseTransformation(bool bFromOptOut); // 0x080E5AAC [Final | Native | Public | BlueprintCallable]
    };
    // Size: 0x001270 (0x000100)
    class alignas(0x8) UBeastLayerAnimInstance : public UFortPlayerAnimInstanceProxy
    {
    public:
        FRotator        DivePitchAdjustmentRotator;                         // 0x001170 (0x000018)
        double          IdleCorrectiveAlpha;                                // 0x001188 (0x000008) [Default: 0]
        double          HipOffsetVertical;                                  // 0x001190 (0x000008) [Default: 0]
        bool            bDiveAbilityLanded;                                 // 0x001198 (0x000001) [Default: false]
        bool            bDiveAbilityActive;                                 // 0x001199 (0x000001) [Default: false]
        bool            bPlayJumpStart;                                     // 0x00119A (0x000001) [Default: false]
        bool            bAllowLandingAdditive;                              // 0x00119B (0x000001) [Default: false]
        bool            bBlendLowerBodyCorrective;                          // 0x00119C (0x000001) [Default: false]
        bool            bDiveState_Loop;                                    // 0x00119D (0x000001) [Default: false]
        bool            bLandingAdditiveAllowLowerBody;                     // 0x00119E (0x000001) [Default: false]
        bool            bTransformAllowLowerBody;                           // 0x00119F (0x000001) [Default: false]
        bool            bSnapLowerBodyCorrective;                           // 0x0011A0 (0x000001) [Default: false]
        bool            bDiveState_Land;                                    // 0x0011A1 (0x000001) [Default: false]
        bool            bDiveState_Transition;                              // 0x0011A2 (0x000001) [Default: false]
        bool            bDiveState_Inactive;                                // 0x0011A3 (0x000001) [Default: false]
        bool            bEnterTransformState;                               // 0x0011A4 (0x000001) [Default: false]
        bool            bDiveState_EnterChargeState;                        // 0x0011A5 (0x000001) [Default: false]
        bool            bDiveState_Roar_AllowLowerBody;                     // 0x0011A6 (0x000001) [Default: false]
        bool            bLowerBodyCorrective_BlendOff;                      // 0x0011A7 (0x000001) [Default: false]
        bool            bAllowAdditiveIdleLoop;                             // 0x0011A8 (0x000001) [Default: false]
        bool            bAllowLowerbodyLandingOverride;                     // 0x0011A9 (0x000001) [Default: false]
        bool            bTransformExitActive;                               // 0x0011AA (0x000001) [Default: false]
        bool            bTransformExitManual;                               // 0x0011AB (0x000001) [Default: false]
        FGameplayTag    DiveActiveTagName;                                  // 0x0011AC (0x000004)
        FGameplayTag    FromAirTagName;                                     // 0x0011B0 (0x000004)
        FGameplayTag    FromGroundTagName;                                  // 0x0011B4 (0x000004)
        UAnimSequence*  BeastGirlTransformBackFastStartCLMAnimSequence;     // 0x0011B8 (0x000008) [Default: nullptr]
        UAnimSequence*  BeastGirltransformBackStartCLMAnimSequence;         // 0x0011C0 (0x000008) [Default: nullptr]
        UAnimSequence*  BeastGirltransformBackInWaterStartCLMAnimSequence;  // 0x0011C8 (0x000008) [Default: nullptr]
        UAnimSequence*  CheerTransformPart2CMLAnimSequence;                 // 0x0011D0 (0x000008) [Default: nullptr]
        UAnimSequence*  CheerTransformPart2InWaterCMLAnimSequence;          // 0x0011D8 (0x000008) [Default: nullptr]
        uint8           bIsPlayingMantis : 1;                               // 0x0011E0 (0x000001) : 0x0 [Default: false]
        uint8           bWasPlayingMantis : 1;                              // 0x0011E0 (0x000001) : 0x0 [Default: false]
        uint8           bIsPlayingMantisInAir : 1;                          // 0x0011E0 (0x000001) : 0x0 [Default: false]
        uint8           bWasFalling : 1;                                    // 0x0011E0 (0x000001) : 0x0 [Default: false]
        uint8           bWantsToTurn : 1;                                   // 0x0011E0 (0x000001) : 0x0 [Default: false]
        uint8           bDiveState_Launch : 1;                              // 0x0011E0 (0x000001) : 0x0 [Default: false]
        uint8           bDiveState_Charge : 1;                              // 0x0011E0 (0x000001) : 0x0 [Default: false]
        uint8           UnknownBit_0011E0_1 : 1;                            // 0x0011E0 (0x000001) : 0x1
        uint8           UnknownBit_0011E0_2 : 1;                            // 0x0011E0 (0x000001) : 0x2
        uint8           UnknownBit_0011E0_3 : 1;                            // 0x0011E0 (0x000001) : 0x3
        uint8           UnknownBit_0011E0_4 : 1;                            // 0x0011E0 (0x000001) : 0x4
        uint8           UnknownBit_0011E0_5 : 1;                            // 0x0011E0 (0x000001) : 0x5
        uint8           UnknownBit_0011E0_6 : 1;                            // 0x0011E0 (0x000001) : 0x6
        uint8           UnknownBit_0011E0_7 : 1;                            // 0x0011E0 (0x000001) : 0x7
        bool            bShouldCloseGate;                                   // 0x0011E1 (0x000001) [Default: false]
        bool            bPlayingEndTransformAnimation;                      // 0x0011E2 (0x000001) [Default: false]
        uint8           UnknownByte_0011E3;                                 // 0x0011E3 (0x000001)
        float           DivePitchAdjustment;                                // 0x0011E4 (0x000004) [Default: 0f]
        uint8           UnknownData_0011E8[0x000088];                       // 0x0011E8 (0x000088)
    };
    // Size: 0x000028 (0x000000)
    class IBeastPlayerAnimationInterface : public IInterface
    {
    public:
    
    public: // Functions
        void    GetAnimData(bool& bIsInTransformAnimation, FBeastGirlTransformationData& ReplicatedTransformData, EBeastGirlDiveState& DiveState); // 0x080E32C8 [Native | Event | Public | HasOutParms | BlueprintEvent | Const]
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FBeastGirlTransformationAnimations
    {
        UAnimationAsset*    OnGround;   // 0x000000 (0x000008)
        UAnimationAsset*    InWater;    // 0x000008 (0x000008)
    };
    // Size: 0x000001 (0x000001)
    struct FBeastGirlTransformationData
    {
        uint8   bTransforming : 1;      // 0x000000 (0x000001) : 0x0
        uint8   bIsOptOut : 1;          // 0x000000 (0x000001) : 0x0
        uint8   bIsInWater : 1;         // 0x000000 (0x000001) : 0x0
        uint8   UnknownBit_000000_1 : 1; // 0x000000 (0x000001) : 0x1
        uint8   UnknownBit_000000_2 : 1; // 0x000000 (0x000001) : 0x2
        uint8   UnknownBit_000000_3 : 1; // 0x000000 (0x000001) : 0x3
        uint8   UnknownBit_000000_4 : 1; // 0x000000 (0x000001) : 0x4
        uint8   UnknownBit_000000_5 : 1; // 0x000000 (0x000001) : 0x5
        uint8   UnknownBit_000000_6 : 1; // 0x000000 (0x000001) : 0x6
        uint8   UnknownBit_000000_7 : 1; // 0x000000 (0x000001) : 0x7
    };
    // Size: 0x000050 (0x000050)
    struct FCachedDamageData
    {
        uint8   UnknownData_000000[0x000050];   // 0x000000 (0x000050)
    };
}

