/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AtomRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000288 (0x000018)
    class alignas(0x8) AAtomModelActor : public AActor
    {
    public:
        UAtomModel* AtomModel;          // 0x000270 (0x000008) [Default: nullptr]
        FString     PrimitiveStyleName; // 0x000278 (0x000010) [Default: L"Runtime"]
    };
    // Size: 0x000028 (0x000000)
    class UAtomActorConnectivityResolver : public UObject
    {
    public:
    };
    // Size: 0x000040 (0x000010)
    class alignas(0x8) UAtomActorConnectivityResolverRegistry : public UDeveloperSettings
    {
    public:
        TArray<UClass*> Resolvers;  // 0x000030 (0x000010)
    };
    // Size: 0x000028 (0x000000)
    class UAtomAssetUserDataActorConnectivityResolver : public UAtomActorConnectivityResolver
    {
    public:
    };
    // Size: 0x000150 (0x000128)
    class alignas(0x8) UAtomBrickPlacementPreviewProxy : public UObject
    {
    public:
        AActor*                                             PlacementPreviewActor;          // 0x000028 (0x000008) [Default: nullptr]
        UMaterialInstanceDynamic*                           PreviewMaterialInstance;        // 0x000030 (0x000008) [Default: nullptr]
        UCurveFloat*                                        InterpolationCurve;             // 0x000038 (0x000008) [Default: nullptr]
        TMap<UStaticMesh*, UInstancedStaticMeshComponent*>  StaticMeshToInstancedMeshMap;   // 0x000040 (0x000010)
        uint8                                               UnknownData_000050[0x000100];   // 0x000050 (0x000100)
    };
    // Size: 0x000580 (0x000010)
    class alignas(0x8) UAtomCollisionComponent : public UPrimitiveComponent
    {
    public:
        TWeakObjectPtr<UBodySetup>  BodySetup;                      // 0x000570 (0x000008) [Default: nullptr]
        uint8                       UnknownData_000578[0x000008];   // 0x000578 (0x000008)
    };
    // Size: 0x000040 (0x000018)
    class alignas(0x8) UAtomCollisionRejection : public UObject
    {
    public:
        void**  VTable_000028;                  // 0x000028 (0x000008) VTable [5 slots] -> 0x14704920
        uint8   UnknownData_000030[0x000010];   // 0x000030 (0x000010)
    };
    // Size: 0x0000D0 (0x000010)
    class alignas(0x8) UAtomColorComponent : public UActorComponent
    {
    public:
        UAtomColorLUTAtlas* ColorLUTAtlas;      // 0x0000C0 (0x000008) [Default: nullptr]
        UTexture2D*         ColorLUTTexture;    // 0x0000C8 (0x000008) [Default: nullptr]
    
    public: // Functions
        int32   GetColorLUTIndex(); // 0x10CE1736 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    SetColorLUTAtlas(UAtomColorLUTAtlas* InColorLUTAtlas); // 0x07FBDEB4 [Final | Native | Public | BlueprintCallable]
        void    SetColorLUTTexture(UTexture2D* InColorLUTTexture); // 0x07FBE040 [Final | Native | Public | BlueprintCallable]
    };
    // Size: 0x000048 (0x000020)
    class alignas(0x8) UAtomColorLUTAtlas : public UObject
    {
    public:
        UTexture2D*         AtlasTexture;                   // 0x000028 (0x000008) [Default: nullptr]
        TArray<UTexture2D*> Textures;                       // 0x000030 (0x000010)
        uint8               UnknownData_000040[0x000008];   // 0x000040 (0x000008)
    
    public: // Functions
        int32   FindOrAddLUTIndex(UTexture2D* InTexture); // 0x07FBE620 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        int32   GetAtlasSize(); // 0x10CE1958 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32   GetLUTIndex(UTexture2D* InTexture); // 0x07FBE798 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x0000F0 (0x000030)
    class alignas(0x8) UAtomColorThemeComponent : public UActorComponent
    {
    public:
        UAtomColorLUTAtlas*     ColorLUTAtlas;                      // 0x0000C0 (0x000008) [Default: nullptr]
        UTexture2D*             ColorLUTTexture;                    // 0x0000C8 (0x000008) [Default: nullptr]
        bool                    bIsThemeCustomTexture;              // 0x0000D0 (0x000001) [Default: false]
        uint8                   UnknownData_0000D1[0x000003];       // 0x0000D1 (0x000003)
        FName                   ColorThemeLibrary;                  // 0x0000D4 (0x000004) [Default: NAME_None]
        FName                   ColorTheme;                         // 0x0000D8 (0x000004) [Default: NAME_None]
        uint8                   UnknownData_0000DC[0x000004];       // 0x0000DC (0x000004)
        UTexture2D*             SelectedGeneratedLibraryTexture;    // 0x0000E0 (0x000008) [Default: nullptr]
        UAtomColorThemeLibrary* SelectedColorThemeLibrary;          // 0x0000E8 (0x000008) [Default: nullptr]
    
    public: // Functions
        void            ApplyColorTheme(); // 0x10CE1F6E [Final | RequiredAPI | Native | Public | Const]
        TArray<FName>   GetAtomColorThemeLibraries(); // 0x10CE2196 [Final | Native | Public | BlueprintCallable]
        int32           GetColorThemeIndex(); // 0x10CE22B0 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FName>   GetThemeNames(); // 0x10CE22D6 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool            SetColorThemeByName(FName Name); // 0x07FBF3A4 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        bool            SetColorThemeByTexture(UTexture2D* Texture); // 0x07FBF59E [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000088 (0x000060)
    class alignas(0x8) UAtomColorThemeLibrary : public UObject
    {
    public:
        FString                     Description;                                // 0x000028 (0x000010) [Default: L""]
        uint8                       MinimumReservedSlotsForTextureBasedThemes;  // 0x000038 (0x000001) [Default: 3]
        uint8                       UnknownData_000039[0x000007];               // 0x000039 (0x000007)
        TArray<FAtomColorTheme>     ColorThemes;                                // 0x000040 (0x000010)
        TSoftObjectPtr<UTexture2D>  GeneratedTexture;                           // 0x000050 (0x000020) [Default: nullptr]
        TArray<UTexture2D*>         LUTTextures;                                // 0x000070 (0x000010)
        uint8                       UnknownData_000080[0x000008];               // 0x000080 (0x000008)
    
    public: // Functions
        int32   GetAtlasDynamicTextureSize(); // 0x10CE2658 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32   GetAtlasSize(); // 0x10CE26BC [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32   GetNumberOfStaticThemesRows(); // 0x10CE271E [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool    IsLUTTextureCompatible(UTexture2D* LUTTexture); // 0x07FBFD5E [Final | RequiredAPI | Native | Public | Const]
    };
    // Size: 0x000058 (0x000030)
    class alignas(0x8) UAtomColorThemeTextureUserData : public UAssetUserData
    {
    public:
        TArray<FName>                           ThemeNames;                 // 0x000028 (0x000010)
        TSoftObjectPtr<UAtomColorThemeLibrary>  SourceColorThemeLibrary;    // 0x000038 (0x000020) [Default: nullptr]
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x8) UAtomCommonPartModelAssetUserData : public UAssetUserData
    {
    public:
        FAtomCommonPartAssetDescription AssetDescription;               // 0x000028 (0x00000C)
        uint8                           UnknownData_000034[0x000004];   // 0x000034 (0x000004)
    };
    // Size: 0x0002A8 (0x000280)
    class UAtomCommonPartStaticMeshAssetUserData : public UAssetUserData
    {
    public:
        uint8   UnknownData_000028[0x000280];   // 0x000028 (0x000280)
    };
    // Size: 0x000078 (0x000050)
    class alignas(0x8) UAtomConnectivityAssetUserData : public UAssetUserData
    {
    public:
        FSerializedConnectivityObjects  AtomModelConnections;   // 0x000028 (0x000040)
        TArray<FName>                   Tags;                   // 0x000068 (0x000010)
    };
    // Size: 0x000028 (0x000000)
    class UAtomConnectivityQueryBlueprintLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FVector GetClosestConnectionPointInActors(TArray<AActor*>& Actors, FVector& Location); // 0x07FBD1FC [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000030 (0x000008)
    class alignas(0x8) UAtomConnectivityRejection : public UObject
    {
    public:
        void**  VTable_000028;  // 0x000028 (0x000008) VTable [5 slots] -> 0x147048F0
    };
    // Size: 0x000030 (0x000000)
    class UAtomDatabaseSubsystemBase : public UEngineSubsystem
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class UAtomEditorModePrimitiveUserData : public UAssetUserData
    {
    public:
    };
    // Size: 0x000100 (0x0000D8)
    class alignas(0x8) UAtomISMPoolRenderer : public UObject
    {
    public:
        void**              VTable_000028;                  // 0x000028 (0x000008) VTable [17 slots] -> 0x146FD7B0
        void**              VTable_000030;                  // 0x000030 (0x000008) VTable [5 slots] -> 0x146FD810
        UISMPoolComponent*  CachedISMPoolComponent;         // 0x000038 (0x000008) [Default: nullptr]
        UISMPoolComponent*  LocalISMPoolComponent;          // 0x000040 (0x000008) [Default: nullptr]
        uint8               UnknownData_000048[0x0000B8];   // 0x000048 (0x0000B8)
    };
    // Size: 0x000058 (0x000030)
    class alignas(0x8) UAtomLUCTAtlas : public UObject
    {
    public:
        TMap<FName, FAtomLUCTRemappedColorTable>    Themes;                 // 0x000028 (0x000010)
        TSoftObjectPtr<UTexture2D>                  GeneratedAtlasTexture;  // 0x000038 (0x000020) [Default: nullptr]
    };
    // Size: 0x000198 (0x000170)
    class alignas(0x8) UAtomModel : public UObject
    {
    public:
        FAtomModelAssetSettings                 Settings;                       // 0x000028 (0x000028)
        TArray<FAtomModelPrimitive>             Primitives;                     // 0x000050 (0x000010)
        TArray<FAtomHingedElement>              Elements;                       // 0x000060 (0x000010)
        TArray<FAtomModelSelectionSet>          SelectionSets;                  // 0x000070 (0x000010)
        TArray<FAtomModelConfigurationGroup>    Groups;                         // 0x000080 (0x000010)
        FSerializedConnectivityObjects          SerializedConnectivityObjects;  // 0x000090 (0x000040)
        TMap<FString, TSoftObjectPtr<UTexture>> TextureNameToAsset;             // 0x0000D0 (0x000010)
        TMap<FName, FString>                    Attributes;                     // 0x0000E0 (0x000010)
        TSet<FName>                             Tags;                           // 0x0000F0 (0x000010)
        uint8                                   UnknownData_000100[0x000010];   // 0x000100 (0x000010)
        FAtomSourceModel                        SourceModel;                    // 0x000110 (0x000088)
    
    public: // Functions
        FString                             GetChildIdentifier(int32 InChildIdx); // 0x052762A4 [Final | Native | Public | BlueprintCallable]
        TArray<TSoftObjectPtr<UStaticMesh>> GetGeneratedMergedMeshes(); // 0x10CE5B8A [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FString                             GetModelName(); // 0x10CE5C08 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FString                             GetModelPath(); // 0x10CE5CAA [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FAtomModelPartsCollection           GetPartsCollection(); // 0x10CE5DA8 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                                GetPrimitivesForChildArray(int32 InChildIdx, TArray<FAtomModelPrimitiveInstance>& OutPrimitives); // 0x0742A5C8 [Final | Native | Public | HasOutParms | BlueprintCallable]
        FVector                             GetRootGroupPivot(); // 0x10CE67A4 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        UTexture*                           GetTextureForDecorationTextureName(FString TextureName); // 0x07FC0124 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000028 (0x000000)
    class UAtomModelActorConnectivityResolver : public UAtomActorConnectivityResolver
    {
    public:
    };
    // Size: 0x000078 (0x000000)
    class UAtomModelAssetUserData : public UAtomConnectivityAssetUserData
    {
    public:
    };
    // Size: 0x000280 (0x000040)
    class alignas(0x8) UAtomModelComponent : public USceneComponent
    {
    public:
        UAtomModel*                         AtomModel;                      // 0x000240 (0x000008) [Default: nullptr]
        EAtomModelInstanceType              InstanceType;                   // 0x000248 (0x000001) [Default: EAtomModelInstanceType(0)]
        bool                                bUseCombinedMeshes;             // 0x000249 (0x000001) [Default: true]
        EAtomMaterialColorSource            MaterialColorSource;            // 0x00024A (0x000001) [Default: EAtomMaterialColorSource(2)]
        bool                                bCreateRigidElements;           // 0x00024B (0x000001) [Default: false]
        bool                                bEnableConnectivity;            // 0x00024C (0x000001) [Default: true]
        uint8                               UnknownData_00024D[0x000003];   // 0x00024D (0x000003)
        FName                               SelectionSetFilter;             // 0x000250 (0x000004) [Default: NAME_None]
        uint8                               CommonPartOptimization;         // 0x000254 (0x000001) [Default: 0]
        uint8                               UnknownData_000255[0x000003];   // 0x000255 (0x000003)
        TArray<USceneComponent*>            RigidElementComponents;         // 0x000258 (0x000010)
        TMap<FName, FModelPrimitiveEntry>   ComponentToPrimitive;           // 0x000268 (0x000010)
        EPrimitiveGeometryComplexity        PrimitiveGeometryComplexity;    // 0x000278 (0x000001) [Default: EPrimitiveGeometryComplexity(2)]
        uint8                               PrimitiveGeometrySections;      // 0x000279 (0x000001) [Default: 51]
        bool                                bShowCommonParts;               // 0x00027A (0x000001) [Default: true]
        uint8                               UnknownData_00027B[0x000005];   // 0x00027B (0x000005)
    
    public: // Functions
        bool    ModelSupportsMaterialInstancePayload(); // 0x10CE8090 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x0000C0 (0x000098)
    class alignas(0x8) UAtomModelPartsCollectionConnectivity : public UObject
    {
    public:
        uint8                       UnknownData_000028[0x000008];   // 0x000028 (0x000008)
        FAtomModelPartsCollection   PartsCollection;                // 0x000030 (0x000080)
        uint8                       UnknownData_0000B0[0x000010];   // 0x0000B0 (0x000010)
    
    public: // Functions
        EFieldConnectResult         GetTechnicHoleConnectivityState(FAtomPartConnectivityFieldReference& TechnicHolePartConnectivityRef, FAtomPartConnectivityFieldReference& ConnectedPartConnectivityRef); // 0x07FC1080 [Final | Native | Public | HasOutParms | BlueprintCallable]
        TArray<EFieldConnectResult> GetTechnicPinConnectivityStates(FAtomPartConnectivityFieldReference& TechnicPinPartConnectivityRef, TArray<FAtomPartConnectivityFieldReference>& ConnectedPartsConnectivityRef); // 0x07FC144A [Final | Native | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000058 (0x000030)
    class alignas(0x8) UAtomModelProcessor : public UObject
    {
    public:
        bool    bEnableRebuildProgress;         // 0x000028 (0x000001) [Default: false]
        uint8   UnknownData_000029[0x000003];   // 0x000029 (0x000003)
        float   DialogDelay;                    // 0x00002C (0x000004) [Default: 1f]
        int32   NumProgressSteps;               // 0x000030 (0x000004) [Default: 1]
        uint8   UnknownData_000034[0x000004];   // 0x000034 (0x000004)
        FString ProgressMessage;                // 0x000038 (0x000010) [Default: L"Rebuilding Model..."]
        uint8   UnknownData_000048[0x000010];   // 0x000048 (0x000010)
    
    public: // Functions
        void                    IncrementProgress(int32 NumSteps, FString Message); // 0x07FC17EC [Final | RequiredAPI | Native | Public | BlueprintCallable]
        FString                 OnGetProcessModelTargetAssetPath(UAtomModel* Model, FAtomModelPartsCollection& AtomModelPartsCollection); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        FString                 OnGetProcessPrimitiveTargetAssetPath(UAtomModel* Model, UAtomPrimitive* Primitive, FAtomModelPartsCollection& AtomModelPartsCollection, FAtomOnProcessPrimitiveSettings& Settings); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        FString                 OnGetTargetAssetPath(UAtomModel* Model, UAtomPrimitive* Primitive, FAtomModelPartsCollection& AtomModelPartsCollection); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        FAtomProcessorResult    OnProcessModel(UAtomModel* Model, FAtomModelPartsCollection& AtomModelPartsCollection, TArray<TSoftObjectPtr<UObject>>& ExistingObjects); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        FAtomProcessorResult    OnProcessPrimitive(UAtomModel* DummyModel, UAtomPrimitive* Primitive, FAtomModelPartsCollection& AtomModelPartsCollection, FAtomOnProcessPrimitiveSettings& Settings); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
    };
    // Size: 0x000028 (0x000000)
    class UAtomPartsCollectionBlueprintLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static void                                    AddPartInstance(FAtomModelPartsCollection& PartCollection, FAtomModelPartInstanceInfo& PartInstance); // 0x07FC2710 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FString                                 Conv_ModelPartGuidToString(FAtomModelPartGuid& InModelPartGuid); // 0x07FC2A9C [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FAtomModelPartGuid                      Conv_StringToModelPartGuid(FString InString); // 0x07FC2C5A [Final | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static FAtomModelPartColorInfo                 CreateColorInfoFromColorId(int32 ColorId); // 0x07FC2DFE [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static UAtomModelPartsCollectionConnectivity*  CreatePartsCollectionConnectivity(FAtomModelPartsCollection& PartsCollection, UAtomModel* Model, float Scale); // 0x07FC2F7C [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FAtomModelPartsCollection               FilterCommonPartsToStyle(FAtomModelPartsCollection& PartsCollection, FName GeometryStyle); // 0x07FC3382 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FAtomModelPartsCollection               FilterGroup(UAtomModel* Model, FAtomModelPartsCollection& PartsCollectionToFilter, FString GroupName, FString NewPartsCollectionName); // 0x07FC3866 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FAtomModelPartsCollection               FilterNonTransparent(FAtomModelPartsCollection& PartsCollectionToFilter, FString NewPartsCollectionName); // 0x07FC3D8A [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FAtomModelPartsCollection               FilterSelectionSet(FAtomModelPartsCollection& PartsCollectionToFilter, FString SelectionSetName, FString NewPartsCollectionName); // 0x07FC40CE [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FAtomModelPartsCollection               FilterTransparent(FAtomModelPartsCollection& PartsCollectionToFilter, FString NewPartsCollectionName); // 0x07FC4540 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static int32                                   GetModelPartGuidHash(FAtomModelPartGuid& InModelPartGuid); // 0x07FC4884 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FString                                 GetName(FAtomModelPartsCollection& PartsCollection); // 0x07FC4A26 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static TArray<FAtomModelPartInstanceInfo>      GetParts(FAtomModelPartsCollection& PartsCollection); // 0x07FC4CAC [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static TArray<FAtomCommonPartAndTransform>     GetPrimitiveCommonParts(UAtomPrimitive* Primitive, double Scale); // 0x07FC4E7E [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                    InitializeCommonParts(UAtomModelPartsCollectionConnectivity* PartsCollectionConnectivity, int32 CommonPartOptimizationFlags); // 0x07FC5128 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static bool                                    PrimitiveHasConsistentCommonPartStyles(UAtomPrimitive* Primitive); // 0x07FC53AC [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                    RemovePartInstance(FAtomModelPartsCollection& PartCollection, FAtomModelPartGuid& PartInstanceId); // 0x07FC5672 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                                    ReplacePartInstance(FAtomModelPartsCollection& PartCollection, FAtomModelPartInstanceInfo& SourcePartInstance, FAtomModelPartGuid& TargetPartInstanceId); // 0x07FC5994 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                                    SetName(FAtomModelPartsCollection& PartsCollection, FString Name); // 0x07FC5E3C [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class UAtomPlacementResultHelperLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static void    Break(FAtomPlacementResult& PlacementResult, FTransform& OutTransformDelta, TArray<TScriptInterface<IAtomRejectionReason>>& OutRejectionReasons); // 0x07FD26D0 [Final | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
    };
    // Size: 0x000028 (0x000000)
    class IAtomPlacementTool : public IInterface
    {
    public:
    
    public: // Functions
        bool                                            BeginUpdatingPlacement(FPlacementOperation& NewPlacementOperation); // 0x07FD7044 [Native | Public | HasOutParms | BlueprintCallable]
        void                                            EndUpdatingPlacement(bool bCancelled); // 0x0619A0EA [Native | Public | BlueprintCallable]
        TArray<TScriptInterface<IAtomRejectionReason>>  GetPlacementRejectionReasons(); // 0x10D125DA [Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                                            RegisterAndConnectActor(AActor* Actor); // 0x07FD727E [Native | Public | BlueprintCallable]
        bool                                            UpdatePlacement(FPlacementContextData& ContextData); // 0x07FD73F8 [Native | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000660 (0x000638)
    class alignas(0x8) UAtomPlacementToolBase : public UObject
    {
    public:
        void**                                      VTable_000028;                      // 0x000028 (0x000008) VTable [16 slots] -> 0x147081E0
        TWeakObjectPtr<UConnectivityRegistration>   ConnectivityRegistrationWeakPtr;    // 0x000030 (0x000008) [Default: nullptr]
        uint8                                       UnknownData_000038[0x000008];       // 0x000038 (0x000008)
        TOptional<FPlacementOperation>              PlacementOperation;                 // 0x000040 (0x0005A0)
        uint8                                       UnknownData_0005E0[0x000080];       // 0x0005E0 (0x000080)
    };
    // Size: 0x000200 (0x0001D8)
    class alignas(0x8) UAtomPrimitive : public UObject
    {
    public:
        int32                                                                           PartId;                             // 0x000028 (0x000004) [Default: 0]
        uint8                                                                           UnknownData_00002C[0x000004];       // 0x00002C (0x000004)
        FString                                                                         PartRevision;                       // 0x000030 (0x000010) [Default: L""]
        FName                                                                           DesignName;                         // 0x000040 (0x000004) [Default: NAME_None]
        bool                                                                            bIsFlex;                            // 0x000044 (0x000001) [Default: false]
        bool                                                                            bIsVariant;                         // 0x000045 (0x000001) [Default: false]
        uint8                                                                           UnknownData_000046[0x000002];       // 0x000046 (0x000002)
        TArray<FString>                                                                 DecorationSurfaceNames;             // 0x000048 (0x000010)
        int32                                                                           NumberOfColorSurfaces;              // 0x000058 (0x000004) [Default: 0]
        EAtomPlatform                                                                   AtomPlatform;                       // 0x00005C (0x000001) [Default: EAtomPlatform(0)]
        uint8                                                                           UnknownData_00005D[0x000003];       // 0x00005D (0x000003)
        int32                                                                           AtomMainGroupId;                    // 0x000060 (0x000004) [Default: 0]
        int32                                                                           AtomSubMainGroupId;                 // 0x000064 (0x000004) [Default: 0]
        TMap<EAtomCommonPartType, FAtomPrimitiveCommonPart>                             PrimitiveCommonParts;               // 0x000068 (0x000010)
        bool                                                                            bOverrideConnectionFields;          // 0x000078 (0x000001) [Default: false]
        uint8                                                                           UnknownData_000079[0x000007];       // 0x000079 (0x000007)
        FBoxSphereBounds                                                                UnscaledBounds;                     // 0x000080 (0x000038)
        uint8                                                                           UnknownData_0000B8[0x000008];       // 0x0000B8 (0x000008)
        FAtomPrimitivePhysicsAttributes                                                 PhysicsAttributes;                  // 0x0000C0 (0x0000A0)
        TArray<UAtomPrimitiveGeometryContainer*>                                        GeometryContainers;                 // 0x000160 (0x000010)
        TArray<FAtomPrimitiveDetailTextureData>                                         DetailTextures;                     // 0x000170 (0x000010)
        FConnectionFieldContainer                                                       ConnectionFields;                   // 0x000180 (0x000030)
        FConnectionFieldContainer                                                       ConnectionFieldsOverride;           // 0x0001B0 (0x000030)
        TMap<FAtomPrimitiveGeometrySectionReference, FTypedConnectivityFieldReference>  TechnicCapConnectivityRefs;         // 0x0001E0 (0x000010)
        TMap<FAtomPrimitiveGeometrySectionReference, FTypedConnectivityFieldReference>  TechnicConnectorConnectivityRefs;   // 0x0001F0 (0x000010)
    
    public: // Functions
        FBoxSphereBounds                    GetBounds(float Scale); // 0x07FC61A0 [Final | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        FVector                             GetCenterOfMass(float Scale); // 0x07FC633A [Final | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        int32                               GetDecorationSurfaceIndex(FString SurfaceName); // 0x07FC64CE [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32                               GetExportStyleMaxLOD(FString ExportStyle); // 0x07FC6652 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UAtomPrimitiveGeometryContainer*    GetGeometryContainerForBestExportStyle(TArray<FString>& GeometryStylePriorityList, int32 LODIndex); // 0x07FC67D6 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        UAtomPrimitiveGeometryContainer*    GetGeometryContainerForExportStyle(FString ExportStyleName, FString FallbackExportStyleName, int32 LODIndex, bool bUseFallbacks); // 0x07FC6A90 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        static FName                               GetMainGroupName(int32 MainGroupId); // 0x06544416 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static FName                               GetSubMainGroupName(int32 SubMainGroupId); // 0x06544416 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        bool                                IsFlexElement(); // 0x0FEF1D6E [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UTexture*                           LoadDetailTextureForExportStyle(FString ExportStyle, int32 LOD, EAtomPrimitiveDetailTextureType TextureType); // 0x07FC6EE6 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UTexture*                           LoadDetailTextureForExportStyleAndSection(FString ExportStyle, int32 LOD, EAtomPrimitiveDetailTextureType TextureType, EPrimitiveGeometrySectionFlag Section); // 0x07FC73A4 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000078 (0x000000)
    class UAtomPrimitiveAssetUserData : public UAtomConnectivityAssetUserData
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class UAtomPrimitiveBlueprintLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static float   GetDefaultPrimitiveScale(); // 0x10CF05AC [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
    };
    // Size: 0x000048 (0x000020)
    class alignas(0x8) UAtomPrimitiveCollisionGeometryWrapper : public UObject
    {
    public:
        TArray<FAtomPrimitiveCollisionGeometryBox>      BoxElems;       // 0x000028 (0x000010)
        TArray<FAtomPrimitiveCollisionGeometryConvex>   ConvexElems;    // 0x000038 (0x000010)
    };
    // Size: 0x0006E0 (0x000030)
    class alignas(0x8) UAtomPrimitiveComponent : public UStaticMeshComponent
    {
    public:
        UAtomPrimitive* AtomPrimitive;                  // 0x0006B0 (0x000008) [Default: nullptr]
        FString         RenderStyle;                    // 0x0006B8 (0x000010) [Default: L"Realtime"]
        FString         FallbackRenderStyle;            // 0x0006C8 (0x000010) [Default: L"Realtime"]
        bool            bUseCombinedMeshes;             // 0x0006D8 (0x000001) [Default: true]
        bool            bUseRenderStyle;                // 0x0006D9 (0x000001) [Default: false]
        bool            bUseFallbackRenderStyle;        // 0x0006DA (0x000001) [Default: false]
        uint8           UnknownData_0006DB[0x000005];   // 0x0006DB (0x000005)
    };
    // Size: 0x0002A8 (0x000280)
    class UAtomPrimitiveGeometry : public UObject
    {
    public:
        uint8   UnknownData_000028[0x000280];   // 0x000028 (0x000280)
    
    public: // Functions
        UAtomPrimitiveGeometry*         Append(UAtomPrimitiveGeometry* GeometryToAppend, FTransform3f& Transform); // 0x07FCA444 [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        UAtomPrimitiveGeometry*         AppendAndWeld(UAtomPrimitiveGeometry* GeometryToAppend, FTransform3f& Transform); // 0x07FCA6F2 [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        void                            AttachVerticesToBoneIndex(int32 BoneIndex); // 0x07FCA9A0 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            AttachVerticesToNamedBone(FString BoneName); // 0x07FCAE52 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        UAtomPrimitiveGeometry*         BakeScale(float Scale); // 0x07FCAFD0 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        UAtomPrimitiveGeometry*         BakeTransform(FTransform3f& Transform); // 0x07FCB146 [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        UAtomPrimitiveGeometry*         BakeTransforms(TArray<FTransform3f>& Transforms); // 0x07FCB2E2 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        UAtomPrimitiveGeometry*         ConvertVertexColorsLinearToSRGB(); // 0x10CF0CC0 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        UAtomPrimitiveGeometry*         CopyNormalMapsToUV0(); // 0x10CF0F22 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        static UAtomPrimitiveGeometry*         CreateAtomGeometryFromCommonPart(FString ExportStyleName, EAtomCommonPartType CommonPartType, int32 LODIndex, FString CommonPartsMeshPath); // 0x07FCB5D2 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static UAtomPrimitiveGeometry*         CreateEmptyAtomGeometry(int32 NumberOfUVChannels); // 0x07FCB9F4 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        UAtomPrimitiveGeometry*         DuplicateGeometry(); // 0x10CF195E [Final | RequiredAPI | Native | Public | BlueprintCallable | Const]
        int32                           GetBoneIndexForName(FString BoneName); // 0x07FCBB60 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        static bool                            GetCommonPartBestExportStyle(TArray<FString>& GeometryStylePriorityList, EAtomCommonPartType CommonPartType, FString& OutGeometryStyle, FString CommonPartsMeshPath); // 0x07FCBD0A [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        TArray<FString>                 GetMaterialNames(); // 0x10CF1A48 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        static int32                           GetNumberOfCommonPartLODs(FString ExportStyleName, EAtomCommonPartType CommonPartType, FString CommonPartsMeshPath); // 0x07FCC176 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        UAtomPrimitiveGeometry*         SetMaterialName(FString Name, int32 PolygonGroupIndex); // 0x07FCC518 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        UAtomPrimitiveGeometry*         SetTiledUVs(float TileSize); // 0x07FCC9D8 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        UAtomPrimitiveGeometry*         SetVertexColor(FColor& Color); // 0x07FCCB4E [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        TArray<UAtomPrimitiveGeometry*> SplitByPolygonGroup(bool bIgnoreEmptyGroups); // 0x07FCCCCE [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UStaticMesh*                    ToSimplifiedStaticMesh(float Scale, UObject* Outer, FString Name, bool bFastBuild); // 0x07FCCE80 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000080 (0x000058)
    class alignas(0x8) UAtomPrimitiveGeometryContainer : public UObject
    {
    public:
        TSoftObjectPtr<UStaticMesh>                                 SourceMesh;                     // 0x000028 (0x000020) [Default: nullptr]
        FName                                                       ExportStyleName;                // 0x000048 (0x000004) [Default: NAME_None]
        int32                                                       LOD;                            // 0x00004C (0x000004) [Default: 0]
        TMap<FString, int32>                                        GeometryCount;                  // 0x000050 (0x000010)
        TMap<FString, FAtomPrimitiveGeometrySectionTextureInfos>    SectionTextureInfos;            // 0x000060 (0x000010)
        uint8                                                       UnknownData_000070[0x000010];   // 0x000070 (0x000010)
    
    public: // Functions
        static TArray<FString>                             GetAllOtherPartNames(); // 0x10CF3558 [Final | Native | Static | Public | BlueprintCallable]
        static TArray<FString>                             GetAllUncommonPartNames(); // 0x10CF3632 [Final | Native | Static | Public | BlueprintCallable]
        TArray<FAtomPrimitiveGeometryAndTransform>  GetCapsGeometry(int32 ColorChangeIndex); // 0x07FCD938 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FAtomPrimitiveGeometryAndTransform>  GetCollisionGeometry(); // 0x10CF3728 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FTransform>                          GetDefaultBoneTransforms(float Scale); // 0x07FCDB2A [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FAtomPrimitiveGeometryAndTransform>  GetDetailsGeometry(int32 ColorChangeIndex); // 0x07FCDCDA [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FString                                     GetExportStyleName(); // 0x10CF3F1E [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UAtomPrimitiveGeometry*                     GetGeometry(EPrimitiveGeometryComplexity PrimitiveGeometryComplexity); // 0x07FCDECC [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure]
        static FString                                     GetGeometryOtherPartName(EAtomPrimitiveGeometryOtherPartType OtherPartType); // 0x07FCE098 [Final | Native | Static | Public | BlueprintCallable | BlueprintPure]
        UAtomPrimitiveGeometry*                     GetGeometrySection(int32 PrimitiveGeometrySectionFlag); // 0x07FCE25C [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UAtomPrimitiveGeometry*                     GetGeometrySectionWithFilter(int32 PrimitiveGeometrySectionFlag, FAtomPrimitiveGeometrySectionFilterParams& FilterParams); // 0x07FCE3D0 [Final | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        UAtomPrimitiveGeometry*                     GetGeometrySectionWithMaterialNames(int32 PrimitiveGeometrySectionFlags, FString ShellMaterial, FString UndersideMaterial); // 0x07FCE6A8 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure]
        static FString                                     GetGeometryUncommonPartName(EAtomPrimitiveGeometryUncommonPartType UncommonPartType); // 0x07FCEA52 [Final | Native | Static | Public | BlueprintCallable | BlueprintPure]
        UAtomPrimitiveGeometry*                     GetGeometryWithMaterialNames(EPrimitiveGeometryComplexity PrimitiveGeometryComplexity, FString ShellMaterial, FString UndersideMaterial); // 0x07FCEC30 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure]
        int32                                       GetLOD(); // 0x0CB038D2 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FAtomPrimitiveGeometryAndTransform>  GetOtherCapsGeometry(int32 ColorChangeIndex); // 0x07FCEFD8 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FAtomPrimitiveGeometryAndTransform>  GetOtherPartsGeometry(int32 ColorChangeIndex); // 0x07FCF1CA [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FAtomPrimitiveGeometryAndTransform>  GetOtherPartsGeometryWithFilter(FAtomPrimitiveGeometrySectionFilterParams& FilterParams); // 0x07FCF378 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        TArray<FAtomPrimitiveGeometryAndTransform>  GetScaledCapsGeometry(float Scale); // 0x07FCF5D0 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FAtomPrimitiveGeometryAndTransform>  GetScaledCollisionGeometry(float Scale); // 0x07FCF7E2 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FAtomPrimitiveGeometryAndTransform>  GetScaledDetailsGeometry(float Scale); // 0x07FCF9AE [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UAtomPrimitiveGeometry*                     GetScaledGeometry(EPrimitiveGeometryComplexity PrimitiveGeometryComplexity, float Scale); // 0x07FCFBC0 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FAtomPrimitiveGeometryAndTransform          GetScaledShellGeometry(float Scale); // 0x07FCFE44 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                                        GetSectionTextureName(EPrimitiveGeometrySectionFlag SectionType, EAtomPrimitiveDetailTextureType TextureType, FString& OutTextureName); // 0x07FCFFFA [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        FAtomPrimitiveGeometryAndTransform          GetShellGeometry(int32 ColorChangeIndex); // 0x07FD03CC [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FAtomPrimitiveGeometryAndTransform>  GetTechnicCapsGeometry(int32 ColorChangeIndex); // 0x07FD05A0 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FAtomPrimitiveGeometryAndTransform>  GetTechnicConnectorsGeometry(int32 ColorChangeIndex); // 0x07FD0792 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FAtomPrimitiveGeometryAndTransform>  GetUncommonPartsGeometry(int32 ColorChangeIndex); // 0x07FD0940 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FAtomPrimitiveGeometryAndTransform>  GetUncommonPartsGeometryWithFilter(FAtomPrimitiveGeometrySectionFilterParams& FilterParams); // 0x07FD0AEE [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        bool                                        HasCollisionGeometry(); // 0x10CF4652 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FAtomPrimitiveCollisionGeometry             MakePrimitiveCollisionGeometry(float Scale); // 0x07FD0D3C [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x0006C0 (0x000010)
    class alignas(0x8) UAtomPrimitiveStaticMeshComponent : public UStaticMeshComponent
    {
    public:
        void**  VTable_0006B0;                  // 0x0006B0 (0x000008) VTable [8 slots] -> 0x147042A0
        uint8   UnknownData_0006B8[0x000008];   // 0x0006B8 (0x000008)
    };
    // Size: 0x000028 (0x000000)
    class UAtomProcessorBlueprintLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FAtomProcessorResult    AppendAtomProcessorResult(FAtomProcessorResult& Result, FAtomProcessorResult& ResultToAppend); // 0x07FC1AE2 [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
        static UAtomModelProcessor*    GetModelProcessor(FAtomModelProcessorInstance& ProcessorInstance); // 0x07FC1E24 [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
        static UClass*                 GetProcessorClass(FAtomModelProcessorInstance& ProcessorInstance); // 0x07FC1FC6 [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
        static bool                    IsValid(FAtomModelProcessorInstance& ProcessorInstance); // 0x07FC2178 [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                    SetModelProcessor(FAtomModelProcessorInstance& ProcessorInstance, UAtomModelProcessor* ModelProcessor, bool bUseCustomSettings); // 0x07FC231C [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class IAtomRejectionReason : public IInterface
    {
    public:
    
    public: // Functions
        FString GetRejectionMessage(); // 0x0D36D600 [RequiredAPI | Native | Event | Public | BlueprintCallable | BlueprintEvent | BlueprintPure | Const]
    };
    // Size: 0x000028 (0x000000)
    class UAtomRuntimeBlueprintLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static TMap<int32, FAtomColorInfo> GetAllColorInfo(); // 0x10CF68AA [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static int32                       GetBitPackForColor(FColor& Color); // 0x07FD10F8 [Final | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        static int32                       GetBitPackForColorId(int32 AtomColorId); // 0x07FD1278 [Final | Native | Static | Public | BlueprintCallable]
        static float                       GetBitPackForLUTMaterial(int32 ColorId, FGuid& PrimitiveUUID, int32 VariantId); // 0x07FD13E4 [Final | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static void                        GetCommonPartAssetDescriptionFromStaticMesh(UStaticMesh* StaticMesh, FAtomCommonPartAssetDescription& OutDescription, EGetCommonPartDescriptionResult& OutIsValid); // 0x07FD17A4 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static EAtomCommonPartCategory     GetCommonPartCategoryFromType(EAtomCommonPartType CommonPartType); // 0x07FD1B90 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static void                        GetCommonPartDescriptionFromType(EAtomCommonPartType CommonPartType, FAtomCommonPartDescription& OutDescription); // 0x07FD1D0E [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FAtomColorInfo              GetInfoForColorId(int32 ColorId); // 0x07FD1FA4 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000060 (0x000030)
    class alignas(0x8) UAtomRuntimeSettings : public UDeveloperSettings
    {
    public:
        float                       PrimitiveGlobalScale;                       // 0x000030 (0x000004) [Default: 20f]
        uint8                       UnknownData_000034[0x000004];               // 0x000034 (0x000004)
        TSoftObjectPtr<UDataTable>  ColorDataTableOverride;                     // 0x000038 (0x000020) [Default: nullptr]
        bool                        bCookContent;                               // 0x000058 (0x000001) [Default: false]
        uint8                       UnknownData_000059[0x000003];               // 0x000059 (0x000003)
        float                       BrickPlacementCollisionOverlapTolerance;    // 0x00005C (0x000004) [Default: 0.342f]
    
    public: // Functions
        UDataTable* GetAtomEditorModeColorDataTable(); // 0x10CF6BA8 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UDataTable* GetColorDataTable(); // 0x10CF6CDA [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000120 (0x0000D8)
    class UAtomSpatialAccelerationSubsystem : public UTickableWorldSubsystem
    {
    public:
        uint8   UnknownData_000048[0x0000D8];   // 0x000048 (0x0000D8)
    };
    // Size: 0x000270 (0x000150)
    class UAtomSpatialAccelerationSubsystemOctree : public UAtomSpatialAccelerationSubsystem
    {
    public:
        uint8   UnknownData_000120[0x000150];   // 0x000120 (0x000150)
    };
    // Size: 0x000200 (0x0000E0)
    class UAtomSpatialAccelerationSubsystemUniformGrid : public UAtomSpatialAccelerationSubsystem
    {
    public:
        uint8   UnknownData_000120[0x0000E0];   // 0x000120 (0x0000E0)
    };
    // Size: 0x000028 (0x000000)
    class UAtomTextureImportData : public UAssetImportData
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class UConnectivityBlueprintLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static bool    AreActorsConnected(AActor* ActorA, AActor* ActorB, UConnectivityRegistration* ConnectivityRegistration); // 0x07FD32F8 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x0000F8 (0x0000D0)
    class UConnectivityRegistration : public UObject
    {
    public:
        uint8   UnknownData_000028[0x0000D0];   // 0x000028 (0x0000D0)
    };
    // Size: 0x000028 (0x000000)
    class IDirectPlacement : public IInterface
    {
    public:
    
    public: // Functions
        bool    TryDirectPlacement(FPlacementOperation& InPlacementOperation, FPlacementContextData& InPlacementContextData); // 0x07FD778E [Native | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000690 (0x000020)
    class alignas(0x8) UDirectSnapPlacementTool : public UProximitySnapPlacementTool
    {
    public:
        void**  VTable_000670;                  // 0x000670 (0x000008) VTable [11 slots] -> 0x14706C60
        void**  VTable_000678;                  // 0x000678 (0x000008) VTable [3 slots] -> 0x14706CA0
        uint8   UnknownData_000680[0x000010];   // 0x000680 (0x000010)
    
    public: // Functions
        AActor* PickActorToDrag(FRay& CastRay); // 0x07FD41EC [RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class IDragPlacement : public IInterface
    {
    public:
    
    public: // Functions
        AActor* PickActorToDrag(FRay& CastRay); // 0x07FD75E8 [Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
    // Size: 0x0006C0 (0x000060)
    class alignas(0x8) UDragSnapPlacementTool : public UAtomPlacementToolBase
    {
    public:
        void**  VTable_000660;                  // 0x000660 (0x000008) VTable [8 slots] -> 0x14706FB0
        uint8   UnknownData_000668[0x000058];   // 0x000668 (0x000058)
    };
    // Size: 0x000028 (0x000000)
    class UPlacementOperationBlueprintLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FPlacementOperation MakeDragPlacementOperation(TArray<AActor*>& Actors, FTransform& StartTransform, FVector& DragLocation); // 0x07FBD4C2 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        static FPlacementOperation MakePlacementOperation(TArray<AActor*>& Actors, FTransform& StartTransform); // 0x07FBD912 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
    };
    // Size: 0x0000B0 (0x000088)
    class alignas(0x8) UPlacementSettings : public UObject
    {
    public:
        uint8                   UnknownData_000028[0x000050];           // 0x000028 (0x000050)
        EAtomSnapToolMode       SnapToolMode;                           // 0x000078 (0x000001) [Default: EAtomSnapToolMode(0)]
        bool                    bIgnoreRejectedEdgeSnappingPlacement;   // 0x000079 (0x000001) [Default: true]
        bool                    bResetPlacementRotation;                // 0x00007A (0x000001) [Default: true]
        EDragSnapMode           DragSnapMode;                           // 0x00007B (0x000001) [Default: EDragSnapMode(0)]
        bool                    bEnableEdgeSnapping;                    // 0x00007C (0x000001) [Default: true]
        uint8                   UnknownData_00007D[0x000003];           // 0x00007D (0x000003)
        uint32                  MaxSnappingDistanceInKnobCount;         // 0x000080 (0x000004) [Default: 2u]
        float                   LateralNudgeDistanceInKnobCount;        // 0x000084 (0x000004) [Default: 1f]
        float                   VerticalNudgeDistanceInPlateCount;      // 0x000088 (0x000004) [Default: 1f]
        float                   RotateNudgeDegrees;                     // 0x00008C (0x000004) [Default: 90f]
        bool                    bSingleFieldPlacement;                  // 0x000090 (0x000001) [Default: false]
        bool                    bEnableCollisionDetection;              // 0x000091 (0x000001) [Default: true]
        uint8                   UnknownData_000092[0x000006];           // 0x000092 (0x000006)
        double                  LineTraceLength;                        // 0x000098 (0x000008) [Default: 2000]
        FCollisionProfileName   ConnectivityTraceProfileName;           // 0x0000A0 (0x000004)
        FCollisionProfileName   RegistrationOverlapProfileName;         // 0x0000A4 (0x000004)
        bool                    bDebugVisualization;                    // 0x0000A8 (0x000001) [Default: true]
        uint8                   UnknownData_0000A9[0x000003];           // 0x0000A9 (0x000003)
        int32                   DebugDrawFlags;                         // 0x0000AC (0x000004) [Default: 2]
    };
    // Size: 0x000670 (0x000010)
    class UProximitySnapPlacementTool : public UAtomPlacementToolBase
    {
    public:
        uint8   UnknownData_000660[0x000010];   // 0x000660 (0x000010)
    };
    // Size: 0x000028 (0x000000)
    class UWorldConnectivityBlueprintLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static AActor*     GetActor(UObject* WorldContext, FWorldConnectivityHandle& Handle); // 0x07FDB3CA [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FVector     GetFieldCenter(UObject* WorldContext, FPlanarFieldInfo& Field); // 0x07FDB65C [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        static FTransform  GetTransform(UObject* WorldContext, FWorldConnectivityHandle& Handle); // 0x07FDB954 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        static bool        IsValid(FWorldConnectivityHandle& Handle); // 0x07ADBC16 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
    };
    // Size: 0x000040 (0x000008)
    class alignas(0x8) UWorldConnectivitySubsystem : public UWorldSubsystem
    {
    public:
        UConnectivityRegistration*  ConnectivityRegistration;   // 0x000038 (0x000008) [Default: 0x7FE838B40040]
    
    public: // Functions
        void                                DisconnectAllObjectConnections(FWorldConnectivityHandle Object); // 0x07FD807C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                                DisconnectObjects(FWorldConnectivityHandle ObjectA, FWorldConnectivityHandle ObjectB); // 0x07FD81FC [Final | RequiredAPI | Native | Public | BlueprintCallable]
        AActor*                             GetActor(FWorldConnectivityHandle Handle); // 0x07FD848E [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UAtomModel*                         GetAtomModel(AActor* Actor); // 0x07FD8602 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UAtomModelAssetUserData*            GetAtomModelAssetUserData(UObject* Object); // 0x07FD879C [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FPlanarFieldInfo                    GetClosestFieldToPoint(FWorldConnectivityHandle Handle, FVector& WorldLocation, EConnectionFieldGender Type, bool& bSuccess); // 0x07FD890A [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        TArray<FWorldConnectivityHandle>    GetConnectedObjects(FWorldConnectivityHandle Object); // 0x07FD8E3C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        TArray<FWorldConnectivityHandle>    GetConnectedObjectsRecursively(FWorldConnectivityHandle Object); // 0x07FD8FEA [Final | RequiredAPI | Native | Public | BlueprintCallable]
        FWorldConnectivityHandle            GetConnectivityHandle(AActor* Actor); // 0x07FD9198 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FWorldConnectivityHandle>    GetConnectivityHandles(AActor* Actor); // 0x07FD9318 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FVector                             GetOverlapPenetrationDepth(AStaticMeshActor* Actor1, AStaticMeshActor* Actor2, FVector Offset); // 0x07FD94C8 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        FVector                             GetPlanarFieldCenter(FPlanarFieldInfo& Field); // 0x07FD9886 [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        TArray<FPlanarFieldInfo>            GetPlanarFields(FWorldConnectivityHandle Handle, EConnectionFieldGender Type); // 0x07FD9A60 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        FTransform                          GetTransform(FWorldConnectivityHandle Handle); // 0x07FD9D0C [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        double                              PlanarGridStepSize(); // 0x10D16AF8 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                                RegisterAtomActor(AActor* Actor); // 0x07FD9E88 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        bool                                RegisterConnectivityActor(AActor* Actor, UAtomModel* Model); // 0x07FD9FFE [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                                RegisterCustomConnectivityActor(AActor* Actor, FSerializedConnectivityObjects& ConnectivityObject); // 0x07FDA282 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                                RegisterModelActor(AActor* Actor, FSerializedConnectivityObjects& Connections); // 0x07FDA282 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        TArray<FConnectivityQueryResult>    RunPlanarConnectivityQuery(AActor* AtomActorToPlace, AActor* AtomActorToConnect, FVector& QueryStartLocation, FVector& QueryEndLocation, TEnumAsByte<ECollisionChannel> QueryCollisionChannel, int32 QueryRadius, bool bPerformConnectionOnSuccess); // 0x07FDA580 [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        bool                                TryConnectObjectAtLocation(FWorldConnectivityHandle ObjectToConnect, FTransform& DesiredObjectTransform, TArray<FWorldConnectivityHandle>& ConnectionCandidates, bool PerformConnection); // 0x07FDAD66 [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        void                                UnregisterConnectivityActor(AActor* Actor); // 0x07FDB258 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FAtomBoneReference
    {
        int32   PrimitiveIndex; // 0x000000 (0x000004)
        int32   PartIndex;      // 0x000004 (0x000004)
        int32   BoneIndex;      // 0x000008 (0x000004)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FAtomColor
    {
        int32           ID;                             // 0x000000 (0x000004) [Default: 198028954]
        EColorEffects   Effects;                        // 0x000004 (0x000001) [Default: EColorEffects(0)]
        uint8           UnknownData_000005[0x000003];   // 0x000005 (0x000003)
        FLinearColor    Color;                          // 0x000008 (0x000010)
    };
    // Size: 0x000028 (0x000020)
    struct alignas(0x8) FAtomColorInfo : public FTableRowBase
    {
        FColor              Color;                          // 0x000008 (0x000004)
        EAtomMaterialType   MaterialType;                   // 0x00000C (0x000001) [Default: EAtomMaterialType(0)]
        uint8               UnknownData_00000D[0x000003];   // 0x00000D (0x000003)
        FString             Name;                           // 0x000010 (0x000010) [Default: L""]
        bool                bIsActive;                      // 0x000020 (0x000001) [Default: true]
        uint8               UnknownData_000021[0x000007];   // 0x000021 (0x000007)
    };
    // Size: 0x000004 (0x000004)
    struct alignas(0x4) FAtomColorProperty
    {
        int32   AtomColorValue; // 0x000000 (0x000004)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FAtomColorSurface
    {
        int32           ColorId;    // 0x000000 (0x000004)
        EAtomShaderType ShaderType; // 0x000004 (0x000004)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FAtomColorTheme
    {
        FName                           ThemeName;                      // 0x000000 (0x000004)
        uint8                           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FAtomThemeColorEntry>    Entries;                        // 0x000008 (0x000010)
    };
    // Size: 0x000080 (0x000080)
    struct alignas(0x8) FAtomCommonPartAndTransform
    {
        EAtomCommonPartType Type;                           // 0x000000 (0x000001)
        uint8               UnknownData_000001[0x00000F];   // 0x000001 (0x00000F)
        FTransform          Transform;                      // 0x000010 (0x000060)
        TArray<FName>       GeometryStyles;                 // 0x000070 (0x000010)
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FAtomCommonPartAssetDescription
    {
        EAtomCommonPartType CommonPartType;                 // 0x000000 (0x000001) [Default: EAtomCommonPartType(69)]
        uint8               UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        FName               CommonPartStyle;                // 0x000004 (0x000004) [Default: FName(7274612) -> L""]
        float               Scale;                          // 0x000008 (0x000004) [Default: 6.15313e-39f]
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x4) FAtomCommonPartDescription
    {
        float   Radius;                         // 0x000000 (0x000004)
        float   Height;                         // 0x000004 (0x000004)
        float   InnerRadius;                    // 0x000008 (0x000004)
        uint8   PlaneQuadrant;                  // 0x00000C (0x000001)
        bool    bShowLogo;                      // 0x00000D (0x000001)
        uint8   UnknownData_00000E[0x000002];   // 0x00000E (0x000002)
    };
    // Size: 0x000050 (0x000050)
    struct alignas(0x8) FAtomCommonPartInstance
    {
        FTransform3f                            Transform;                      // 0x000000 (0x000030)
        FAtomPrimitiveConnectionPointReference  ConnectionPointReference;       // 0x000030 (0x000004)
        uint8                                   UnknownData_000034[0x000004];   // 0x000034 (0x000004)
        TArray<FName>                           GeometryStyles;                 // 0x000038 (0x000010)
        uint8                                   UnknownData_000048[0x000008];   // 0x000048 (0x000008)
    };
    // Size: 0x000050 (0x000050)
    struct alignas(0x8) FAtomCommonPartInstancesCache
    {
        TArray<UStaticMesh*>                    Meshes;             // 0x000000 (0x000010)
        TArray<UMaterialInterface*>             Materials;          // 0x000010 (0x000010)
        TArray<FGuid>                           UUIDs;              // 0x000020 (0x000010)
        TArray<FCommonPartInstanceDescription>  Instances;          // 0x000030 (0x000010)
        TArray<FTransform3f>                    InstanceTransforms; // 0x000040 (0x000010)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAtomCommonPartOcclusionInfo
    {
        TArray<bool>    InstancesOccluded;  // 0x000000 (0x000010)
    };
    // Size: 0x000038 (0x000038)
    struct alignas(0x8) FAtomConnectionPointLocation
    {
        FVector                 RelativeConnectionPointLocation;    // 0x000000 (0x000018)
        TSoftObjectPtr<AActor>  Actor;                              // 0x000018 (0x000020)
    };
    // Size: 0x0003A0 (0x0003A0)
    struct alignas(0x8) FAtomConnectionProxy
    {
        uint8                                           UnknownData_000000[0x000008];   // 0x000000 (0x000008)
        void**                                          VTable_000008;                  // 0x000008 (0x000008) VTable [56 slots] -> 0x1527E678
        uint8                                           UnknownData_000010[0x000068];   // 0x000010 (0x000068)
        void**                                          VTable_000078;                  // 0x000078 (0x000008) VTable [56 slots] -> 0x1527E678
        uint8                                           UnknownData_000080[0x000068];   // 0x000080 (0x000068)
        void**                                          VTable_0000E8;                  // 0x0000E8 (0x000008) VTable [119 slots] -> 0x12DEA3B0
        uint8                                           UnknownData_0000F0[0x000068];   // 0x0000F0 (0x000068)
        void**                                          VTable_000158;                  // 0x000158 (0x000008) VTable [124 slots] -> 0x12DD0C70
        uint8                                           UnknownData_000160[0x000078];   // 0x000160 (0x000078)
        void**                                          VTable_0001D8;                  // 0x0001D8 (0x000008) VTable [101 slots] -> 0x12DCF560
        uint8                                           UnknownData_0001E0[0x0000F8];   // 0x0001E0 (0x0000F8)
        void**                                          VTable_0002D8;                  // 0x0002D8 (0x000008) VTable [449 slots] -> 0x12DCFCA0
        uint8                                           UnknownData_0002E0[0x000068];   // 0x0002E0 (0x000068)
        void**                                          VTable_000348;                  // 0x000348 (0x000008) VTable [101 slots] -> 0x12DCF560
        uint8                                           UnknownData_000350[0x000040];   // 0x000350 (0x000040)
        TArray<TScriptInterface<IAtomRejectionReason>>  RejectionReasons;               // 0x000390 (0x000010)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FAtomDecorationAssignment
    {
        FString SurfaceName;    // 0x000000 (0x000010)
        FString TextureName;    // 0x000010 (0x000010)
        FString Version;        // 0x000020 (0x000010)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAtomGlueSet
    {
        TSet<FAtomModelPartReference>   Entries;    // 0x000000 (0x000010)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FAtomHingedElement
    {
        TArray<FAtomRigidElement>   RigidElements;                  // 0x000000 (0x000010)
        int32                       HierarchyRootIndex;             // 0x000010 (0x000004) [Default: 379749680]
        uint8                       UnknownData_000014[0x000004];   // 0x000014 (0x000004)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FAtomLUCTRemappedColorEntry
    {
        FAtomColorProperty  SourceColor;    // 0x000000 (0x000004)
        FAtomColorProperty  RemappedColor;  // 0x000004 (0x000004)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAtomLUCTRemappedColorTable
    {
        TArray<FAtomLUCTRemappedColorEntry> Entries;    // 0x000000 (0x000010)
    };
    // Size: 0x000070 (0x000070)
    struct alignas(0x8) FAtomMaterialFeatures
    {
        EAtomMaterialType               MaterialType;                   // 0x000000 (0x000001) [Default: EAtomMaterialType(64)]
        uint8                           UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        TMap<int32, UTexture*>          UDIMDecorationMap;              // 0x000008 (0x000010)
        UTexture*                       NormalMap;                      // 0x000018 (0x000008) [Default: 0x12FAFE60]
        UTexture*                       AlphaMask;                      // 0x000020 (0x000008) [Default: 0x16A41AA0]
        UTexture*                       TechnicNormalMap;               // 0x000028 (0x000008) [Default: 0x1977CA41]
        UTexture*                       TechnicMasks;                   // 0x000030 (0x000008) [Default: 0xF5CC0EB9]
        UTexture*                       LookUpTableAtlasTexture;        // 0x000038 (0x000008) [Default: nullptr]
        EAtomMaterialColorSource        ColorSource;                    // 0x000040 (0x000001) [Default: EAtomMaterialColorSource(99)]
        uint8                           UnknownData_000041[0x000003];   // 0x000041 (0x000003)
        int32                           ColorId;                        // 0x000044 (0x000004) [Default: 0]
        EAtomMaterialUVFeature          UVFeature;                      // 0x000048 (0x000001) [Default: EAtomMaterialUVFeature(0)]
        EAtomMaterialTranslucencyType   TranslucencyType;               // 0x000049 (0x000001) [Default: EAtomMaterialTranslucencyType(0)]
        uint8                           UnknownData_00004A[0x000006];   // 0x00004A (0x000006)
        FAtomMaterialOverride           MaterialOverride;               // 0x000050 (0x000010)
        TArray<FInstancedStruct>        AdditionalFeatures;             // 0x000060 (0x000010)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAtomMaterialOverride
    {
        UMaterialInterface* Material;                       // 0x000000 (0x000008)
        bool                bManualColorSource;             // 0x000008 (0x000001)
        uint8               UnknownData_000009[0x000007];   // 0x000009 (0x000007)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FAtomMergedMeshLODDistanceSettings
    {
        bool            bOverrideLODScreenSizes;        // 0x000000 (0x000001) [Default: true]
        uint8           UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        float           BaseLODScreenSize;              // 0x000004 (0x000004) [Default: 0f]
        float           BaseLODScreenSizeScaling;       // 0x000008 (0x000004) [Default: 9.3887e-44f]
        uint8           UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        TArray<float>   LODDistances;                   // 0x000010 (0x000010)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FAtomModelAssetSettings
    {
        float                                   Scale;                          // 0x000000 (0x000004)
        bool                                    CreateRigidElementComponents;   // 0x000004 (0x000001)
        uint8                                   UnknownData_000005[0x000003];   // 0x000005 (0x000003)
        FAtomModelGeometryOptimizationSettings  OptimizationSettings;           // 0x000008 (0x000018)
        bool                                    bEnableConnectivity;            // 0x000020 (0x000001)
        uint8                                   UnknownData_000021[0x000007];   // 0x000021 (0x000007)
    };
    // Size: 0x0000D0 (0x0000D0)
    struct alignas(0x8) FAtomModelConfigurationGroup
    {
        FGuid                       ID;                             // 0x000000 (0x000010)
        FName                       Name;                           // 0x000010 (0x000004)
        FGuid                       ParentGroupId;                  // 0x000014 (0x000010)
        uint8                       UnknownData_000024[0x000004];   // 0x000024 (0x000004)
        TSet<FGuid>                 PrimitiveIds;                   // 0x000028 (0x000010)
        TArray<FAtomModelSocket>    Sockets;                        // 0x000038 (0x000010)
        uint8                       UnknownData_000048[0x000008];   // 0x000048 (0x000008)
        FTransform                  GroupPivot;                     // 0x000050 (0x000060)
        TMap<FName, FString>        Attributes;                     // 0x0000B0 (0x000010)
        TSet<FName>                 Tags;                           // 0x0000C0 (0x000010)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FAtomModelGeometryOptimizationSettings
    {
        bool    bEnforceLODBudgets;             // 0x000000 (0x000001)
        bool    bUseTagBudget;                  // 0x000001 (0x000001)
        uint8   UnknownData_000002[0x000002];   // 0x000002 (0x000002)
        int32   TriangleBudget;                 // 0x000004 (0x000004)
        double  SimplifyBaseTolerance;          // 0x000008 (0x000008)
        double  OptimizeBaseTriCost;            // 0x000010 (0x000008)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAtomModelHierarchicalScene
    {
        TArray<FAtomModelHierarchicalSceneNode> SceneNodes; // 0x000000 (0x000010)
    };
    // Size: 0x000090 (0x000090)
    struct alignas(0x8) FAtomModelHierarchicalSceneNode
    {
        FString         Name;                           // 0x000000 (0x000010)
        FTransform      WorldTransform;                 // 0x000010 (0x000060)
        int32           ParentIndex;                    // 0x000070 (0x000004)
        uint8           UnknownData_000074[0x000004];   // 0x000074 (0x000004)
        TArray<FString> ItemNames;                      // 0x000078 (0x000010)
        uint8           UnknownData_000088[0x000008];   // 0x000088 (0x000008)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FAtomModelIssue
    {
        EAtomIssue  Issue;      // 0x000000 (0x000004)
        int32       ID;         // 0x000004 (0x000004)
        FString     StringData; // 0x000008 (0x000010)
    };
    // Size: 0x000028 (0x000020)
    struct alignas(0x8) FAtomModelMapping : public FTableRowBase
    {
        FString                                     ModelName;              // 0x000008 (0x000010)
        TMap<FString, FAtomModelProcessedResults>   ProcessedResultsMap;    // 0x000018 (0x000010)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAtomModelOcclusionCache
    {
        TMap<FAtomModelPartGuid, FAtomModelPrimitiveOcclusionInfo>  PartsOcclusion; // 0x000000 (0x000010)
    };
    // Size: 0x000070 (0x000070)
    struct alignas(0x8) FAtomModelPart
    {
        TSoftObjectPtr<UAtomPrimitive>      AtomPrimitive;                  // 0x000000 (0x000020)
        TArray<FTransform>                  Transforms;                     // 0x000020 (0x000010)
        uint32                              PartId;                         // 0x000030 (0x000004)
        uint8                               UnknownData_000034[0x000004];   // 0x000034 (0x000004)
        FString                             PartRevision;                   // 0x000038 (0x000010)
        TArray<FAtomColorSurface>           ColorSurfaces;                  // 0x000048 (0x000010)
        TArray<FAtomDecorationAssignment>   Decorations;                    // 0x000058 (0x000010)
        bool                                bIgnoreCommonPartCulling;       // 0x000068 (0x000001)
        uint8                               UnknownData_000069[0x000007];   // 0x000069 (0x000007)
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FAtomModelPartColorInfo
    {
        FColor              Color;                          // 0x000000 (0x000004)
        int32               ColorId;                        // 0x000004 (0x000004)
        EAtomMaterialType   MaterialType;                   // 0x000008 (0x000001)
        uint8               UnknownData_000009[0x000003];   // 0x000009 (0x000003)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FAtomModelPartDecorationInfo
    {
        UMaterialInterface* Material;                       // 0x000000 (0x000008)
        UTexture*           Texture;                        // 0x000008 (0x000008)
        FString             PrimitiveSurfaceName;           // 0x000010 (0x000010)
        int32               PrimitiveSurfaceIndex;          // 0x000020 (0x000004)
        uint8               UnknownData_000024[0x000004];   // 0x000024 (0x000004)
    };
    // Size: 0x000014 (0x000014)
    struct alignas(0x8) FAtomModelPartGuid
    {
        FGuid   Guid;       // 0x000000 (0x000010)
        int32   PartIndex;  // 0x000010 (0x000004)
    };
    // Size: 0x0000B0 (0x0000B0)
    struct alignas(0x8) FAtomModelPartInstanceInfo
    {
        FAtomModelPartGuid                      PartGuid;                       // 0x000000 (0x000014)
        uint8                                   UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        int32                                   PartId;                         // 0x000018 (0x000004)
        uint8                                   UnknownData_00001C[0x000004];   // 0x00001C (0x000004)
        UAtomPrimitive*                         Primitive;                      // 0x000020 (0x000008)
        TArray<FTransform>                      Transforms;                     // 0x000028 (0x000010)
        TArray<FAtomModelPartDecorationInfo>    Decorations;                    // 0x000038 (0x000010)
        TArray<FAtomModelPartColorInfo>         Colors;                         // 0x000048 (0x000010)
        TArray<FString>                         SelectionSets;                  // 0x000058 (0x000010)
        FString                                 Group;                          // 0x000068 (0x000010)
        FString                                 ParentGroup;                    // 0x000078 (0x000010)
        TArray<FAtomCommonPartAndTransform>     CommonParts;                    // 0x000088 (0x000010)
        bool                                    bIsUndersideVisible;            // 0x000098 (0x000001)
        uint8                                   UnknownData_000099[0x000017];   // 0x000099 (0x000017)
    };
    // Size: 0x000014 (0x000014)
    struct alignas(0x8) FAtomModelPartReference
    {
        FGuid   PrimitiveUUID;  // 0x000000 (0x000010)
        int32   PartIndex;      // 0x000010 (0x000004)
    };
    // Size: 0x000080 (0x000080)
    struct alignas(0x8) FAtomModelPartsCollection
    {
        FString                             Name;   // 0x000000 (0x000010)
        FTransform                          Pivot;  // 0x000010 (0x000060)
        TArray<FAtomModelPartInstanceInfo>  Parts;  // 0x000070 (0x000010)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FAtomModelPrimitive
    {
        TArray<FAtomModelPart>  Parts;      // 0x000000 (0x000010)
        int32                   DesignId;   // 0x000010 (0x000004)
        FGuid                   UUID;       // 0x000014 (0x000010)
        FName                   DesignName; // 0x000024 (0x000004)
    };
    // Size: 0x000018 (0x000000)
    struct FAtomModelPrimitiveGroup : public FAtomPrimitiveGroup
    {
    };
    // Size: 0x000090 (0x000090)
    struct alignas(0x8) FAtomModelPrimitiveInstance
    {
        UAtomPrimitive* Primitive;                      // 0x000000 (0x000008)
        uint8           UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        FTransform      PrimitiveTransform;             // 0x000010 (0x000060)
        FVector         PivotOrigin;                    // 0x000070 (0x000018)
        uint8           UnknownData_000088[0x000008];   // 0x000088 (0x000008)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FAtomModelPrimitiveOcclusionInfo
    {
        bool                                                    bShellOccluded;                 // 0x000000 (0x000001)
        uint8                                                   UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        TMap<EAtomCommonPartType, FAtomCommonPartOcclusionInfo> CommonPartsOccluded;            // 0x000008 (0x000010)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FAtomModelProcessedResults
    {
        TSoftClassPtr<UClass>           ResultType;         // 0x000000 (0x000020)
        TArray<TSoftObjectPtr<UObject>> ProcessedResults;   // 0x000020 (0x000010)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FAtomModelProcessorInstance
    {
        bool                            bUseCustomSettings;             // 0x000000 (0x000001)
        uint8                           UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        UAtomModelProcessor*            Processor;                      // 0x000008 (0x000008)
        UAtomModelProcessor*            InternalTransientPropStorage;   // 0x000010 (0x000008)
        TArray<TSoftObjectPtr<UObject>> ProcessedObjects;               // 0x000018 (0x000010)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FAtomModelSelectionSet
    {
        TSet<FGuid> PrimitiveIds;       // 0x000000 (0x000010)
        FName       SelectionSetName;   // 0x000010 (0x000004)
        FName       ImportedName;       // 0x000014 (0x000004)
        FGuid       ID;                 // 0x000018 (0x000010)
    };
    // Size: 0x000080 (0x000080)
    struct alignas(0x8) FAtomModelSocket
    {
        FGuid       ID;                             // 0x000000 (0x000010)
        FName       Name;                           // 0x000010 (0x000004)
        uint8       UnknownData_000014[0x00000C];   // 0x000014 (0x00000C)
        FTransform  Transform;                      // 0x000020 (0x000060)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAtomModelTags
    {
        TArray<FName>   Tags;   // 0x000000 (0x000010)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FAtomOnProcessPrimitiveSettings
    {
        FString CustomLocation;                 // 0x000000 (0x000010)
        bool    bSupportDecorations;            // 0x000010 (0x000001)
        uint8   UnknownData_000011[0x000007];   // 0x000011 (0x000007)
    };
    // Size: 0x0000C0 (0x0000C0)
    struct alignas(0x8) FAtomPartConnectivityFieldReference
    {
        FAtomModelPartInstanceInfo          PartInfo;                       // 0x000000 (0x0000B0)
        FTypedConnectivityFieldReference    ConnectivityField;              // 0x0000B0 (0x00000C)
        uint8                               UnknownData_0000BC[0x000004];   // 0x0000BC (0x000004)
    };
    // Size: 0x000410 (0x000410)
    struct alignas(0x8) FAtomPlacementResult
    {
        FTransform              TransformDelta;                 // 0x000000 (0x000060)
        FAtomConnectionProxy    ConnectionProxy;                // 0x000060 (0x0003A0)
        EAtomPlacementType      PlacementType;                  // 0x000400 (0x000001) [Default: EAtomPlacementType(81)]
        uint8                   UnknownData_000401[0x00000F];   // 0x000401 (0x00000F)
    };
    // Size: 0x000001 (0x000001)
    struct FAtomPrimitiveBevelOptions
    {
        uint8   UnknownByte_000000; // 0x000000 (0x000001)
    };
    // Size: 0x000001 (0x000001)
    struct FAtomPrimitiveBuildOptions
    {
        uint8   UnknownByte_000000; // 0x000000 (0x000001)
    };
    // Size: 0x000001 (0x000001)
    struct FAtomPrimitiveBuildSettings
    {
        uint8   UnknownByte_000000; // 0x000000 (0x000001)
    };
    // Size: 0x0000A0 (0x0000A0)
    struct alignas(0x8) FAtomPrimitiveCollisionGeometry
    {
        FKAggregateGeom AggGeom;    // 0x000000 (0x0000A0)
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x8) FAtomPrimitiveCollisionGeometryBox
    {
        FVector     Center;                         // 0x000000 (0x000018)
        FRotator    Rotation;                       // 0x000018 (0x000018)
        float       X;                              // 0x000030 (0x000004)
        float       Y;                              // 0x000034 (0x000004)
        float       Z;                              // 0x000038 (0x000004)
        uint8       UnknownData_00003C[0x000004];   // 0x00003C (0x000004)
    };
    // Size: 0x0000C0 (0x0000C0)
    struct alignas(0x8) FAtomPrimitiveCollisionGeometryConvex
    {
        TArray<FVector> VertexData;                     // 0x000000 (0x000010)
        TArray<int32>   IndexData;                      // 0x000010 (0x000010)
        FBox            ElemBox;                        // 0x000020 (0x000038)
        uint8           UnknownData_000058[0x000008];   // 0x000058 (0x000008)
        FTransform      Transform;                      // 0x000060 (0x000060)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FAtomPrimitiveCollisionVolumeBase
    {
        FVector Location;                       // 0x000000 (0x000018)
        uint16  BoneIndex;                      // 0x000018 (0x000002) [Default: 7872]
        uint8   UnknownData_00001A[0x000006];   // 0x00001A (0x000006)
    };
    // Size: 0x000050 (0x000030)
    struct alignas(0x8) FAtomPrimitiveCollisionVolumeBox : public FAtomPrimitiveCollisionVolumeBase
    {
        FRotator    Rotation;   // 0x000020 (0x000018)
        FVector     HalfExtent; // 0x000038 (0x000018)
    };
    // Size: 0x000040 (0x000020)
    struct alignas(0x8) FAtomPrimitiveCollisionVolumeCapsule : public FAtomPrimitiveCollisionVolumeBase
    {
        FRotator    Rotation;   // 0x000020 (0x000018)
        float       Radius;     // 0x000038 (0x000004) [Default: 0f]
        float       HalfLength; // 0x00003C (0x000004) [Default: 0f]
    };
    // Size: 0x000050 (0x000050)
    struct alignas(0x8) FAtomPrimitiveCollisionVolumeContainer
    {
        TArray<FAtomPrimitiveCollisionVolumeBox>            Boxes;      // 0x000000 (0x000010)
        TArray<FAtomPrimitiveCollisionVolumeSphere>         Spheres;    // 0x000010 (0x000010)
        TArray<FAtomPrimitiveCollisionVolumeCapsule>        Capsules;   // 0x000020 (0x000010)
        TArray<FAtomPrimitiveCollisionVolumeCylinder>       Cylinders;  // 0x000030 (0x000010)
        TArray<FAtomPrimitiveCollisionVolumeHollowCylinder> Tubes;      // 0x000040 (0x000010)
    };
    // Size: 0x000040 (0x000020)
    struct alignas(0x8) FAtomPrimitiveCollisionVolumeCylinder : public FAtomPrimitiveCollisionVolumeBase
    {
        FRotator    Rotation;   // 0x000020 (0x000018)
        float       Radius;     // 0x000038 (0x000004) [Default: 0f]
        float       HalfLength; // 0x00003C (0x000004) [Default: 0f]
    };
    // Size: 0x000048 (0x000028)
    struct alignas(0x8) FAtomPrimitiveCollisionVolumeHollowCylinder : public FAtomPrimitiveCollisionVolumeBase
    {
        FRotator    Rotation;                       // 0x000020 (0x000018)
        float       InnerRadius;                    // 0x000038 (0x000004) [Default: 0f]
        float       OuterRadius;                    // 0x00003C (0x000004) [Default: 0f]
        float       HalfLength;                     // 0x000040 (0x000004) [Default: -2.16407e-29f]
        uint8       UnknownData_000044[0x000004];   // 0x000044 (0x000004)
    };
    // Size: 0x000028 (0x000008)
    struct alignas(0x4) FAtomPrimitiveCollisionVolumeSphere : public FAtomPrimitiveCollisionVolumeBase
    {
        float   Radius;                         // 0x000020 (0x000004) [Default: 4.2039e-45f]
        uint8   UnknownData_000024[0x000004];   // 0x000024 (0x000004)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAtomPrimitiveCommonPart
    {
        TArray<FAtomCommonPartInstance> UnscaledInstances;  // 0x000000 (0x000010)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FAtomPrimitiveConnection
    {
        FAtomBoneReference  From;   // 0x000000 (0x00000C)
        FAtomBoneReference  To;     // 0x00000C (0x00000C)
    };
    // Size: 0x000004 (0x000004)
    struct alignas(0x2) FAtomPrimitiveConnectionPointReference
    {
        int16   PlanarFieldIndex;       // 0x000000 (0x000002)
        int16   ConnectionPointIndex;   // 0x000002 (0x000002)
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x8) FAtomPrimitiveDetailTextureData
    {
        TSoftObjectPtr<UTexture>        Texture;                        // 0x000000 (0x000020)
        FName                           Style;                          // 0x000020 (0x000004)
        uint8                           UnknownData_000024[0x000004];   // 0x000024 (0x000004)
        TArray<int32>                   Lods;                           // 0x000028 (0x000010)
        EPrimitiveGeometrySectionFlag   GeometrySection;                // 0x000038 (0x000001)
        EAtomPrimitiveDetailTextureType TextureType;                    // 0x000039 (0x000001)
        uint8                           UnknownData_00003A[0x000006];   // 0x00003A (0x000006)
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x8) FAtomPrimitiveGeometryAndTransform
    {
        UAtomPrimitiveGeometry* AtomPrimitiveGeometry;          // 0x000000 (0x000008) [Default: 0x197A71C0]
        uint8                   UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        FTransform3f            Transform;                      // 0x000010 (0x000030)
    };
    // Size: 0x000188 (0x000188)
    struct alignas(0x8) FAtomPrimitiveGeometryLODs
    {
        TArray<UAtomPrimitiveGeometry*>                     GeometryLODs;                   // 0x000000 (0x000010)
        TArray<FAtomPrimitiveGeometryMaterialAssignments>   GeometryLODsMaterials;          // 0x000010 (0x000010)
        UAtomPrimitiveGeometry*                             HiResNaniteGeomery;             // 0x000020 (0x000008) [Default: 0xD4CA0EB9]
        FAtomPrimitiveGeometryMaterialAssignments           HiResNaniteGeomeryMaterials;    // 0x000028 (0x000020)
        FAtomPrimitiveCollisionGeometry                     Collision;                      // 0x000048 (0x0000A0)
        FAtomPrimitiveCollisionGeometry                     DetailedCollision;              // 0x0000E8 (0x0000A0)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FAtomPrimitiveGeometryMaterialAssignments
    {
        TArray<FString>                 MaterialSlotName;   // 0x000000 (0x000010)
        TArray<FAtomMaterialFeatures>   MaterialFeatures;   // 0x000010 (0x000010)
    };
    // Size: 0x000048 (0x000048)
    struct alignas(0x8) FAtomPrimitiveGeometrySectionFilterParams
    {
        TArray<FString> UncommonPartsIncludeList;       // 0x000000 (0x000010)
        TArray<FString> UncommonPartsExcludeList;       // 0x000010 (0x000010)
        TArray<FString> OtherPartsIncludeList;          // 0x000020 (0x000010)
        TArray<FString> OtherPartsExcludeList;          // 0x000030 (0x000010)
        int32           ColorChangeIndex;               // 0x000040 (0x000004) [Default: 0]
        uint8           UnknownData_000044[0x000004];   // 0x000044 (0x000004)
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FAtomPrimitiveGeometrySectionReference
    {
        FName   StyleName;      // 0x000000 (0x000004)
        int32   LOD;            // 0x000004 (0x000004)
        int32   SectionIndex;   // 0x000008 (0x000004)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAtomPrimitiveGeometrySectionTextureInfos
    {
        TMap<EAtomPrimitiveDetailTextureType, FString>  TextureInfos;   // 0x000000 (0x000010)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FAtomPrimitiveGroup
    {
        FVector PivotOrigin;    // 0x000000 (0x000018)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FAtomPrimitiveInstanceData
    {
        TArray<FAtomPrimitiveMaterialAssignment>    MaterialAssignments;    // 0x000000 (0x000010)
        TSoftObjectPtr<UStaticMesh>                 MeshOverride;           // 0x000010 (0x000020)
    };
    // Size: 0x000120 (0x000118)
    struct alignas(0x8) FAtomPrimitiveMapping : public FTableRowBase
    {
        int32                           PartId;                         // 0x000008 (0x000004)
        uint8                           UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FString                         Revision;                       // 0x000010 (0x000010)
        FName                           DesignName;                     // 0x000020 (0x000004)
        uint8                           UnknownData_000024[0x000004];   // 0x000024 (0x000004)
        TSoftObjectPtr<UStaticMesh>     StaticMesh;                     // 0x000028 (0x000020)
        TSet<int32>                     AllowedColorSet;                // 0x000048 (0x000010)
        TSet<FString>                   SearchTerms;                    // 0x000058 (0x000010)
        TSoftObjectPtr<UTexture2D>      Thumbnail;                      // 0x000068 (0x000020)
        uint8                           UnknownData_000088[0x000008];   // 0x000088 (0x000008)
        FTransform                      ThumbnailPrimitiveOffset;       // 0x000090 (0x000060)
        FName                           SanitizedName;                  // 0x0000F0 (0x000004)
        uint8                           UnknownData_0000F4[0x000004];   // 0x0000F4 (0x000004)
        TSoftObjectPtr<UAtomPrimitive>  AtomPrimitiveOverride;          // 0x0000F8 (0x000020)
        FName                           CategoryName;                   // 0x000118 (0x000004)
        int32                           CategoryIndex;                  // 0x00011C (0x000004)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FAtomPrimitiveMaterialAssignment
    {
        FName                               SlotName;                       // 0x000000 (0x000004)
        uint8                               UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TSoftObjectPtr<UMaterialInterface>  Material;                       // 0x000008 (0x000020)
        bool                                bIsCustomMaterialOverride;      // 0x000028 (0x000001)
        bool                                bHasManualColorSource;          // 0x000029 (0x000001)
        uint8                               UnknownData_00002A[0x000006];   // 0x00002A (0x000006)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FAtomPrimitiveOptimizationSettings
    {
        EAtomPrimitiveGeoOptimization               OptimizationType;               // 0x000000 (0x000001)
        uint8                                       UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        EAtomPrimitiveGeoOptimization_Old           GeometryOptions;                // 0x000004 (0x000004)
        EAtomPrimitiveApproximationShapeType        ApproximationShapeType;         // 0x000008 (0x000001)
        uint8                                       UnknownData_000009[0x000003];   // 0x000009 (0x000003)
        EAtomPrimitiveApproximationShapeType_Old    ApproximationStrategy;          // 0x00000C (0x000004)
        bool                                        bUseOptimizationAxisOverride;   // 0x000010 (0x000001)
        uint8                                       UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FVector                                     ApproximationAxisOverride;      // 0x000018 (0x000018)
    };
    // Size: 0x0000A0 (0x0000A0)
    struct alignas(0x8) FAtomPrimitivePhysicsAttributes
    {
        FMatrix InertiaTensor;                  // 0x000000 (0x000080)
        FVector CenterOfMass;                   // 0x000080 (0x000018)
        float   Mass;                           // 0x000098 (0x000004) [Default: 0f]
        uint8   UnknownData_00009C[0x000004];   // 0x00009C (0x000004)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FAtomPrimitiveStyleImportData
    {
        FString                         Revision;                       // 0x000000 (0x000010)
        EAtomDatabaseSourceTypeFlags    DatabaseSourceType;             // 0x000010 (0x000001)
        uint8                           UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FString                         SourceDatabase;                 // 0x000018 (0x000010)
        int32                           ImportWarnings;                 // 0x000028 (0x000004)
        uint8                           UnknownData_00002C[0x000004];   // 0x00002C (0x000004)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FAtomPrimitiveUserNote
    {
        FString Text;           // 0x000000 (0x000010) [Default: L"??"]
        FString PartRevision;   // 0x000010 (0x000010) [Default: L""]
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FAtomProcessorResult
    {
        bool                bSuccess;                       // 0x000000 (0x000001)
        uint8               UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        TArray<UObject*>    ProcessedObjects;               // 0x000008 (0x000010)
        TArray<UObject*>    SharedAssets;                   // 0x000018 (0x000010)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FAtomResolvedModelPartReference
    {
        FAtomBoneReference          Indices;        // 0x000000 (0x00000C)
        FAtomRigidElementIndices    ElementIndices; // 0x00000C (0x00000C)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FAtomRigidElement
    {
        TArray<FAtomBoneReference>          BoneReferences;     // 0x000000 (0x000010)
        TArray<FAtomRigidElementConnection> Connections;        // 0x000010 (0x000010)
        FName                               Name;               // 0x000020 (0x000004)
        int32                               IndexOfMetaBone;    // 0x000024 (0x000004)
    };
    // Size: 0x000080 (0x000080)
    struct alignas(0x8) FAtomRigidElementConnection
    {
        FTransform                          Transform;                      // 0x000000 (0x000060)
        int32                               OtherElementIndex;              // 0x000060 (0x000004)
        int32                               ConnectionUniqueId;             // 0x000064 (0x000004)
        TArray<FAtomPrimitiveConnection>    PrimitiveConnections;           // 0x000068 (0x000010)
        uint8                               UnknownData_000078[0x000008];   // 0x000078 (0x000008)
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FAtomRigidElementIndices
    {
        int32   HingedElementIndex; // 0x000000 (0x000004)
        int32   RigidElementIndex;  // 0x000004 (0x000004)
        int32   BoneIndex;          // 0x000008 (0x000004)
    };
    // Size: 0x00001C (0x00001C)
    struct alignas(0x8) FAtomRigidElementSettings
    {
        FAtomModelPartReference ElementIdentifyingPart;         // 0x000000 (0x000014)
        FName                   RigidElementName;               // 0x000014 (0x000004)
        bool                    MergeWithParentElement;         // 0x000018 (0x000001)
        bool                    ShouldBeRootElement;            // 0x000019 (0x000001)
        uint8                   UnknownData_00001A[0x000002];   // 0x00001A (0x000002)
    };
    // Size: 0x000020 (0x000008)
    struct alignas(0x4) FAtomSelectionSetPrimitiveGroup : public FAtomPrimitiveGroup
    {
        FName   SelectionSetName;               // 0x000018 (0x000004) [Default: NAME_None]
        uint8   UnknownData_00001C[0x000004];   // 0x00001C (0x000004)
    };
    // Size: 0x000088 (0x000088)
    struct alignas(0x8) FAtomSourceModel
    {
        TArray<FAtomModelPrimitive>             Primitives;     // 0x000000 (0x000010)
        TArray<FAtomHingedElement>              Elements;       // 0x000010 (0x000010)
        TArray<FAtomModelSelectionSet>          SelectionSets;  // 0x000020 (0x000010)
        TArray<FAtomGlueSet>                    GlueSets;       // 0x000030 (0x000010)
        TArray<FAtomModelConfigurationGroup>    Groups;         // 0x000040 (0x000010)
        FBox                                    Bounds;         // 0x000050 (0x000038)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FAtomThemeColorEntry
    {
        FAtomColorProperty  OriginalColor;      // 0x000000 (0x000004)
        FAtomColorProperty  ReplacementColor;   // 0x000004 (0x000004)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x2) FCommonPartInstanceDescription
    {
        int16   MeshIdx;        // 0x000000 (0x000002)
        int16   MaterialIdx;    // 0x000002 (0x000002)
        int16   UUIDIdx;        // 0x000004 (0x000002)
        uint16  ColorId;        // 0x000006 (0x000002)
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x8) FConnectionField
    {
        FQuat                   Rotation;           // 0x000000 (0x000020)
        FVector                 Location;           // 0x000020 (0x000018)
        uint32                  SubType;            // 0x000038 (0x000004) [Default: 2u]
        uint16                  BoneIndex;          // 0x00003C (0x000002) [Default: 0]
        EConnectionFieldType    Type;               // 0x00003E (0x000001) [Default: EConnectionFieldType(0)]
        uint8                   UnknownByte_00003F; // 0x00003F (0x000001)
    };
    // Size: 0x000060 (0x000010)
    struct alignas(0x4) FConnectionFieldAxle : public FConnectionFieldLine
    {
        bool    Grabbing;                       // 0x000050 (0x000001) [Default: false]
        bool    RequireGrabbing;                // 0x000051 (0x000001) [Default: false]
        uint8   UnknownData_000052[0x000002];   // 0x000052 (0x000002)
        float   DiscreteSnapInterval;           // 0x000054 (0x000004) [Default: 0f]
        uint8   UnknownData_000058[0x000008];   // 0x000058 (0x000008)
    };
    // Size: 0x000040 (0x000000)
    struct FConnectionFieldBall : public FConnectionFieldPoint
    {
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FConnectionFieldContainer
    {
        TArray<FConnectionFieldPlanar>  PlanarFields;   // 0x000000 (0x000010)
        TArray<FInstancedStruct>        LineFields;     // 0x000010 (0x000010)
        TArray<FInstancedStruct>        PointFields;    // 0x000020 (0x000010)
    };
    // Size: 0x000050 (0x000010)
    struct alignas(0x4) FConnectionFieldFixed : public FConnectionFieldPoint
    {
        uint32  Axes;                           // 0x000040 (0x000004)
        uint8   UnknownData_000044[0x00000C];   // 0x000044 (0x00000C)
    };
    // Size: 0x000060 (0x000010)
    struct alignas(0x8) FConnectionFieldGear : public FConnectionFieldLine
    {
        double  Radius;                         // 0x000050 (0x000008)
        uint32  ToothCount;                     // 0x000058 (0x000004)
        uint8   UnknownData_00005C[0x000004];   // 0x00005C (0x000004)
    };
    // Size: 0x000070 (0x000030)
    struct alignas(0x8) FConnectionFieldHinge : public FConnectionFieldPoint
    {
        bool    Oriented;                       // 0x000040 (0x000001)
        bool    Flip;                           // 0x000041 (0x000001)
        bool    HasLimits;                      // 0x000042 (0x000001)
        bool    RequireGrabbing;                // 0x000043 (0x000001)
        uint8   UnknownData_000044[0x000004];   // 0x000044 (0x000004)
        double  OrientedMin;                    // 0x000048 (0x000008)
        double  OrientedMax;                    // 0x000050 (0x000008)
        double  FlippedMin;                     // 0x000058 (0x000008)
        double  FlippedMax;                     // 0x000060 (0x000008)
        uint8   UnknownData_000068[0x000008];   // 0x000068 (0x000008)
    };
    // Size: 0x000050 (0x000010)
    struct alignas(0x8) FConnectionFieldLine : public FConnectionField
    {
        double  Length;                         // 0x000040 (0x000008) [Default: 1.78925e-314]
        bool    StartCapped;                    // 0x000048 (0x000001) [Default: false]
        bool    EndCapped;                      // 0x000049 (0x000001) [Default: false]
        uint8   UnknownData_00004A[0x000006];   // 0x00004A (0x000006)
    };
    // Size: 0x000060 (0x000020)
    struct alignas(0x8) FConnectionFieldPlanar : public FConnectionField
    {
        uint8                       Width;                          // 0x000040 (0x000001) [Default: 5]
        uint8                       Height;                         // 0x000041 (0x000001) [Default: 0]
        uint8                       UnknownData_000042[0x000006];   // 0x000042 (0x000006)
        TArray<FConnectionPoint>    Points;                         // 0x000048 (0x000010)
        uint8                       UnknownData_000058[0x000008];   // 0x000058 (0x000008)
    };
    // Size: 0x000040 (0x000000)
    struct FConnectionFieldPoint : public FConnectionField
    {
    };
    // Size: 0x000070 (0x000020)
    struct alignas(0x8) FConnectionFieldSlider : public FConnectionFieldLine
    {
        bool    Cylindrical;                    // 0x000050 (0x000001) [Default: true]
        bool    HasSpring;                      // 0x000051 (0x000001) [Default: true]
        uint8   UnknownData_000052[0x000006];   // 0x000052 (0x000006)
        double  SpringRest;                     // 0x000058 (0x000008) [Default: 0]
        double  SpringStrength;                 // 0x000060 (0x000008) [Default: 1.71981e-314]
        double  SpringDamping;                  // 0x000068 (0x000008) [Default: 0]
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FConnectionPoint
    {
        EConnectionPointType    Type;                           // 0x000000 (0x000001) [Default: EConnectionPointType(16)]
        uint8                   Size;                           // 0x000001 (0x000001) [Default: 121]
        uint8                   UnknownData_000002[0x000002];   // 0x000002 (0x000002)
        EConnectionPointFlags   Flags;                          // 0x000004 (0x000004) [Default: EConnectionPointFlags(0)]
        int32                   Features;                       // 0x000008 (0x000004) [Default: 318439600]
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x8) FConnectivityFieldConnection
    {
        FConnectivityFieldReference Reference;                      // 0x000000 (0x000008)
        EFieldConnectResult         ConnectResult;                  // 0x000008 (0x000001) [Default: EFieldConnectResult(96)]
        uint8                       UnknownData_000009[0x000003];   // 0x000009 (0x000003)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FConnectivityFieldReference
    {
        int32   ObjectID;                       // 0x000000 (0x000004) [Default: 427456992]
        uint16  FieldIndex;                     // 0x000004 (0x000002) [Default: 0]
        uint8   UnknownData_000006[0x000002];   // 0x000006 (0x000002)
    };
    // Size: 0x0000C0 (0x0000C0)
    struct alignas(0x8) FConnectivityQueryResult
    {
        bool        bHasValidConnection;                // 0x000000 (0x000001) [Default: true]
        uint8       UnknownData_000001[0x00000F];       // 0x000001 (0x00000F)
        FTransform  TargetTransformToConnect;           // 0x000010 (0x000060)
        FVector     HitLocation;                        // 0x000070 (0x000018)
        FVector     OffsetToBestFit;                    // 0x000088 (0x000018)
        int32       SourceFieldIndex;                   // 0x0000A0 (0x000004) [Default: 318437520]
        int32       SourceFieldObjectId;                // 0x0000A4 (0x000004) [Default: 0]
        int32       SourceFieldConnectionPointIndex;    // 0x0000A8 (0x000004) [Default: 379852624]
        int32       TargetFieldIndex;                   // 0x0000AC (0x000004) [Default: 0]
        int32       TargetFieldObjectId;                // 0x0000B0 (0x000004) [Default: 427462049]
        int32       TargetFieldConnectionPointIndex;    // 0x0000B4 (0x000004) [Default: 0]
        FName       ErrorMessage;                       // 0x0000B8 (0x000004) [Default: FName(-1719984455) -> L"ReturnValue"]
        uint8       UnknownData_0000BC[0x000004];       // 0x0000BC (0x000004)
    };
    // Size: 0x000001 (0x000001)
    struct FFieldConnectionInfo
    {
        EFieldConnectResult ConnectResult;  // 0x000000 (0x000001) [Default: EFieldConnectResult(224)]
    };
    // Size: 0x000018 (0x000008)
    struct FHingeFieldConnectionInfo : public FPointFieldConnectionInfo
    {
        bool    Flip;                           // 0x000010 (0x000001) [Default: true]
        uint8   UnknownData_000011[0x000007];   // 0x000011 (0x000007)
    };
    // Size: 0x000008 (0x000007)
    struct FLineFieldConnectionInfo : public FFieldConnectionInfo
    {
        bool    Flip;                           // 0x000001 (0x000001) [Default: true]
        uint8   UnknownData_000002[0x000006];   // 0x000002 (0x000006)
    };
    // Size: 0x000038 (0x000038)
    struct alignas(0x8) FModelPrimitiveEntry
    {
        TSoftObjectPtr<UPrimitiveComponent> Component;                      // 0x000000 (0x000020) [Default: 0xBCDAE9A]
        FAtomModelPartReference             PartReference;                  // 0x000020 (0x000014)
        uint8                               UnknownData_000034[0x000004];   // 0x000034 (0x000004)
    };
    // Size: 0x0000F0 (0x0000F0)
    struct alignas(0x8) FPlacementContextData
    {
        FTransform  PlacementTransform; // 0x000000 (0x000060)
        FTransform  CameraTransform;    // 0x000060 (0x000060)
        FRay        CastRay;            // 0x0000C0 (0x000030)
    };
    // Size: 0x000590 (0x000590)
    struct alignas(0x8) FPlacementOperation
    {
        TArray<AActor*>                 ActorsToMove;                   // 0x000000 (0x000010)
        uint8                           UnknownData_000010[0x000010];   // 0x000010 (0x000010)
        TOptional<FAtomPlacementResult> PlacementResult;                // 0x000020 (0x000420)
        uint8                           UnknownData_000440[0x000058];   // 0x000440 (0x000058)
        void**                          VTable_000498;                  // 0x000498 (0x000008) VTable [579 slots] -> 0x12DCF890
        uint8                           UnknownData_0004A0[0x000078];   // 0x0004A0 (0x000078)
        void**                          VTable_000518;                  // 0x000518 (0x000008) VTable [243 slots] -> 0x12DCF0F0
        uint8                           UnknownData_000520[0x000068];   // 0x000520 (0x000068)
        void**                          VTable_000588;                  // 0x000588 (0x000008) VTable [243 slots] -> 0x12DCF0F0
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FPlacementPreviewInterpolationSettings
    {
        float                       duration;                       // 0x000000 (0x000004)
        EAlphaBlendOption           EasingFunction;                 // 0x000004 (0x000001)
        uint8                       UnknownData_000005[0x000003];   // 0x000005 (0x000003)
        TSoftObjectPtr<UCurveFloat> EasingCurve;                    // 0x000008 (0x000020)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FPlacementPreviewMaterialSettings
    {
        TSoftObjectPtr<UMaterialInterface>  Material;                       // 0x000000 (0x000020)
        FName                               MaterialColorPropertyName;      // 0x000020 (0x000004)
        FColor                              ValidPlacementColor;            // 0x000024 (0x000004)
        FColor                              RejectedPlacementColor;         // 0x000028 (0x000004)
        uint8                               UnknownData_00002C[0x000004];   // 0x00002C (0x000004)
    };
    // Size: 0x000020 (0x00001F)
    struct alignas(0x8) FPlanarFieldConnectionInfo : public FFieldConnectionInfo
    {
        uint8                                   UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        TArray<FPlanarFieldPointConnectionInfo> PointConnections;               // 0x000008 (0x000010)
        uint32                                  OverlapA;                       // 0x000018 (0x000004) [Default: 427456737u]
        uint32                                  OverlapB;                       // 0x00001C (0x000004) [Default: 0u]
    };
    // Size: 0x000090 (0x000090)
    struct alignas(0x8) FPlanarFieldInfo
    {
        FTransform                      Transform;                      // 0x000000 (0x000060)
        FVector2D                       Size;                           // 0x000060 (0x000010)
        EConnectionFieldGender          PlanarFieldType;                // 0x000070 (0x000001) [Default: EConnectionFieldGender(240)]
        uint8                           UnknownData_000071[0x000007];   // 0x000071 (0x000007)
        TArray<FPlanarFieldPointInfo>   PointInfo;                      // 0x000078 (0x000010)
        uint8                           UnknownData_000088[0x000008];   // 0x000088 (0x000008)
    };
    // Size: 0x000004 (0x000004)
    struct alignas(0x2) FPlanarFieldPointConnectionInfo
    {
        uint16  IndexA; // 0x000000 (0x000002) [Default: 34832]
        uint16  IndexB; // 0x000002 (0x000002) [Default: 6522]
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FPlanarFieldPointInfo
    {
        FVector                 PointLocation;                  // 0x000000 (0x000018)
        EConnectionPointType    PointType;                      // 0x000018 (0x000001) [Default: EConnectionPointType(49)]
        bool                    IsAvailable;                    // 0x000019 (0x000001) [Default: true]
        uint8                   UnknownData_00001A[0x000006];   // 0x00001A (0x000006)
    };
    // Size: 0x000010 (0x00000F)
    struct alignas(0x8) FPointFieldConnectionInfo : public FFieldConnectionInfo
    {
        uint8   UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        double  OneAxisRotation;                // 0x000008 (0x000008) [Default: 1.78019e-306]
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x8) FSerializedConnectivityObjects
    {
        TArray<FConnectionFieldContainer>   Fields;             // 0x000000 (0x000010)
        TArray<FSerializedPlanarConnection> PlanarConnections;  // 0x000010 (0x000010)
        TArray<FSerializedLineConnection>   LineConnections;    // 0x000020 (0x000010)
        TArray<FSerializedPointConnection>  PointConnections;   // 0x000030 (0x000010)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FSerializedLineConnection
    {
        FLineFieldConnectionInfo    Connection; // 0x000000 (0x000008)
        FConnectivityFieldReference FieldA;     // 0x000008 (0x000008)
        FConnectivityFieldReference FieldB;     // 0x000010 (0x000008)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FSerializedPlanarConnection
    {
        FPlanarFieldConnectionInfo  Connection; // 0x000000 (0x000020)
        FConnectivityFieldReference FieldA;     // 0x000020 (0x000008)
        FConnectivityFieldReference FieldB;     // 0x000028 (0x000008)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FSerializedPointConnection
    {
        FPointFieldConnectionInfo   Connection; // 0x000000 (0x000010)
        FConnectivityFieldReference FieldA;     // 0x000010 (0x000008)
        FConnectivityFieldReference FieldB;     // 0x000018 (0x000008)
    };
    // Size: 0x00000C (0x000004)
    struct FTypedConnectivityFieldReference : public FConnectivityFieldReference
    {
        EConnectionFieldSuperType   FieldType;                      // 0x000008 (0x000001) [Default: EConnectionFieldSuperType(109)]
        uint8                       UnknownData_000009[0x000003];   // 0x000009 (0x000003)
    };
    // Size: 0x000004 (0x000004)
    struct alignas(0x4) FWorldConnectivityHandle
    {
        int32   ObjectID;   // 0x000000 (0x000004) [Default: 4259909]
    };
}

