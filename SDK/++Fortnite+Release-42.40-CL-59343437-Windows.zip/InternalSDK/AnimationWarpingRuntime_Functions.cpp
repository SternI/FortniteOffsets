/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimationWarpingRuntime_Functions
 * ============================================================
 */

#include "AnimationWarpingRuntime_Functions.hpp"

namespace UE
{

    void UAnimationWarpingLibrary::ApplyDeltaToOffsetRootBone(FOffsetRootBoneAnimNodeReference& OffsetRootBoneNode, FVector TranslationWorld, FQuat RotationWorld)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationWarpingRuntime.AnimationWarpingLibrary.ApplyDeltaToOffsetRootBone");
    
        UAnimationWarpingLibrary___ApplyDeltaToOffsetRootBone_Params Params{};
        Params.OffsetRootBoneNode = OffsetRootBoneNode;
        Params.TranslationWorld = TranslationWorld;
        Params.RotationWorld = RotationWorld;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OffsetRootBoneNode = Params.OffsetRootBoneNode;
    }

    void UAnimationWarpingLibrary::ConvertToOffsetRootBoneNodePure(FAnimNodeReference& Node, FOffsetRootBoneAnimNodeReference& OffsetRootBoneNode, bool& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationWarpingRuntime.AnimationWarpingLibrary.ConvertToOffsetRootBoneNodePure");
    
        UAnimationWarpingLibrary___ConvertToOffsetRootBoneNodePure_Params Params{};
        Params.Node = Node;
        Params.OffsetRootBoneNode = OffsetRootBoneNode;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        OffsetRootBoneNode = Params.OffsetRootBoneNode;
        Result = Params.Result;
    }

    bool UAnimationWarpingLibrary::GetCurveValueFromAnimation(UAnimSequenceBase* Animation, FName CurveName, float time, float& OutValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationWarpingRuntime.AnimationWarpingLibrary.GetCurveValueFromAnimation");
    
        UAnimationWarpingLibrary___GetCurveValueFromAnimation_Params Params{};
        Params.Animation = Animation;
        Params.CurveName = CurveName;
        Params.time = time;
        Params.OutValue = OutValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutValue = Params.OutValue;
    
        return Params.ReturnValue;
    }

    bool UAnimationWarpingLibrary::GetFloatValueFromCurve(UCurveFloat* InCurve, float time, float& OutValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationWarpingRuntime.AnimationWarpingLibrary.GetFloatValueFromCurve");
    
        UAnimationWarpingLibrary___GetFloatValueFromCurve_Params Params{};
        Params.InCurve = InCurve;
        Params.time = time;
        Params.OutValue = OutValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutValue = Params.OutValue;
    
        return Params.ReturnValue;
    }

    FTransform UAnimationWarpingLibrary::GetOffsetRootTransform(FAnimNodeReference& Node)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationWarpingRuntime.AnimationWarpingLibrary.GetOffsetRootTransform");
    
        UAnimationWarpingLibrary___GetOffsetRootTransform_Params Params{};
        Params.Node = Node;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
    
        return Params.ReturnValue;
    }

    bool UAnimationWarpingLibrary::GetVectorValueFromCurve(UCurveVector* InCurve, float time, FVector& OutValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationWarpingRuntime.AnimationWarpingLibrary.GetVectorValueFromCurve");
    
        UAnimationWarpingLibrary___GetVectorValueFromCurve_Params Params{};
        Params.InCurve = InCurve;
        Params.time = time;
        Params.OutValue = OutValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutValue = Params.OutValue;
    
        return Params.ReturnValue;
    }

} // namespace UE

