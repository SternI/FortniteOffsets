/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnnualRefundTokenUI
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000310 (0x000008)
    class alignas(0x8) UFortAnnualRefundTicket : public UUserWidget
    {
    public:
        UCommonTextBlock*   Text_AvailableDate; // 0x000308 (0x000008) [Default: nullptr]
    
    public: // Functions
        void    OnPlayLockingAnimation(); // 0x000545D2 [Event | Public | BlueprintEvent]
        void    OnUpdateAvailableState(bool bIsAvailable); // 0x000545D2 [Event | Public | BlueprintEvent]
        void    OnUpdatePendingState(bool bIsPending); // 0x000545D2 [Event | Public | BlueprintEvent]
    };
    // Size: 0x000468 (0x000020)
    class alignas(0x8) UFortAnnualRefundTokenData : public UFortGameFeatureData
    {
    public:
        TSoftClassPtr<UClass>   PurchaseHistoryScreenClass; // 0x000448 (0x000020) [Default: nullptr]
    };
    // Size: 0x001690 (0x000010)
    class UFortPurchaseHistoryBundleEntry : public UFortPurchaseHistoryEntryBase
    {
    public:
        bool    bIsExpanded;                    // 0x001680 (0x000001) [Default: false]
        uint8   UnknownData_001681[0x00000F];   // 0x001681 (0x00000F)
    
    public: // Functions
        void    SetExpandButtonText(int32 NumPurchases); // 0x000545D2 [Event | Public | BlueprintEvent]
    };
    // Size: 0x001680 (0x000000)
    class UFortPurchaseHistoryEntry : public UFortPurchaseHistoryEntryBase
    {
    public:
    
    public: // Functions
        void    OnSetHistory(bool bHasBeenRefunded, bool bIsCancelPurchaseEligible, bool bIsTokenlessRefund, bool bPlayerHasTokens, bool bNonRefundable, bool IsPartOfABundle, bool IsNextRefundable, int32 IndexInBundle, int32 NumPurchasesInBundle); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    SetPurchaseText(FText& PurchaseDateText, FText& RefundDateText, bool bHasBeenRefunded, EFortPurchaseHistoryRefundType RefundType); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
        void    SetupItemCard(UFortCosmeticItemCard* ItemCard, UFortItem* Item); // 0x000545D2 [Event | Protected | BlueprintEvent]
    };
    // Size: 0x001680 (0x000040)
    class alignas(0x8) UFortPurchaseHistoryEntryBase : public UFortHoldableButton
    {
    public:
        void**              VTable_001640;                  // 0x001640 (0x000008) VTable [7 slots] -> 0x146B4D00
        UClass*             ItemCardClass;                  // 0x001648 (0x000008) [Default: nullptr]
        float               CardWidthOverride;              // 0x001650 (0x000004) [Default: 0f]
        uint8               UnknownData_001654[0x000004];   // 0x001654 (0x000004)
        UCommonTextBlock*   Text_Name;                      // 0x001658 (0x000008) [Default: nullptr]
        TArray<FString>     LootEntryItemTypesToExclude;    // 0x001660 (0x000010)
        TArray<FString>     LootEntryItemTypesToCombine;    // 0x001670 (0x000010)
    
    public: // Functions
        void    UpdateItemList(TArray<UFortCosmeticItemCard*>& ItemCards); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
    };
    // Size: 0x000490 (0x0001F8)
    class alignas(0x8) UFortPurchaseHistoryListView : public UListViewBase
    {
    public:
        void**  VTable_000298;                  // 0x000298 (0x000008) VTable [38 slots] -> 0x146B5DC0
        uint8   UnknownData_0002A0[0x0001F0];   // 0x0002A0 (0x0001F0)
    };
    // Size: 0x000680 (0x000100)
    class alignas(0x8) UFortPurchaseHistoryScreen : public UFortActivatablePanel
    {
    public:
        FDataTableRowHandle             BackAction;                                 // 0x000580 (0x000010)
        uint8                           UnknownData_000590[0x000018];               // 0x000590 (0x000018)
        TSoftClassPtr<UClass>           RefundConfirmationClass;                    // 0x0005A8 (0x000020) [Default: nullptr]
        TSoftClassPtr<UClass>           DirectPurchaseInfoModalClass;               // 0x0005C8 (0x000020) [Default: nullptr]
        UCommonAnimatedSwitcher*        Switcher_MainContent;                       // 0x0005E8 (0x000008) [Default: nullptr]
        UFortPurchaseHistoryTreeView*   TreeView_Purchases;                         // 0x0005F0 (0x000008) [Default: nullptr]
        UCommonButtonBase*              Button_PostApproval;                        // 0x0005F8 (0x000008) [Default: nullptr]
        UScrollBox*                     ScrollBox_ReturnTypeInfo;                   // 0x000600 (0x000008) [Default: nullptr]
        UCommonTextBlock*               Text_Desc;                                  // 0x000608 (0x000008) [Default: nullptr]
        UCommonTextBlock*               Text_RefundCount;                           // 0x000610 (0x000008) [Default: nullptr]
        UCommonTextBlock*               Text_ResultHeader;                          // 0x000618 (0x000008) [Default: nullptr]
        UCommonTextBlock*               Text_ResultTitle;                           // 0x000620 (0x000008) [Default: nullptr]
        UCommonTextBlock*               Text_ResultDesc;                            // 0x000628 (0x000008) [Default: nullptr]
        UFortAnnualRefundTicket*        RefundTicket_Left;                          // 0x000630 (0x000008) [Default: nullptr]
        UFortAnnualRefundTicket*        RefundTicket_Center;                        // 0x000638 (0x000008) [Default: nullptr]
        UFortAnnualRefundTicket*        RefundTicket_Right;                         // 0x000640 (0x000008) [Default: nullptr]
        UWidget*                        Widget_CancelPurchaseInfo;                  // 0x000648 (0x000008) [Default: nullptr]
        UWidget*                        Widget_ReturnTicketInfo;                    // 0x000650 (0x000008) [Default: nullptr]
        UWidget*                        Widget_TokenlessRefundInfo;                 // 0x000658 (0x000008) [Default: nullptr]
        UWidget*                        Widget_NonRefundableInfo;                   // 0x000660 (0x000008) [Default: nullptr]
        UWidget*                        Widget_BundledPurchaseInfo;                 // 0x000668 (0x000008) [Default: nullptr]
        UWidget*                        Widget_BundledPurchaseTokenlessRefundInfo;  // 0x000670 (0x000008) [Default: nullptr]
        uint8                           UnknownData_000678[0x000008];               // 0x000678 (0x000008)
    
    public: // Functions
        bool    BP_IsShowingPurchases(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    FilterMtxPurchaseHistoryByOffer(UFortItemShopOfferVM* InOffer); // 0x07EDD568 [Final | Native | Public | BlueprintCallable]
        void    OnBeginRefundSubmission(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnEndRefundSubmission(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnNoPurchasesAvailable(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnPopulateView(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    ShowStandaloneBackButton(); // 0x000545D2 [Event | Public | BlueprintEvent]
    };
    // Size: 0x0004C8 (0x000038)
    class alignas(0x8) UFortPurchaseHistoryTreeView : public UFortPurchaseHistoryListView
    {
    public:
        uint8   UnknownData_000490[0x000010];   // 0x000490 (0x000010)
        UClass* HeaderEntryWidgetClass;         // 0x0004A0 (0x000008) [Default: nullptr]
        uint8   UnknownData_0004A8[0x000020];   // 0x0004A8 (0x000020)
    };
    // Size: 0x0005D8 (0x000058)
    class alignas(0x8) UFortRefundConfirmation : public UFortActivatablePanel
    {
    public:
        uint8                       UnknownData_000580[0x000010];   // 0x000580 (0x000010)
        UCommonTextBlock*           Text_RefundsRemaining;          // 0x000590 (0x000008) [Default: nullptr]
        UCommonTextBlock*           Text_RefundCount;               // 0x000598 (0x000008) [Default: nullptr]
        UCommonTextBlock*           Text_AreYouSure;                // 0x0005A0 (0x000008) [Default: nullptr]
        UCommonButtonBase*          Button_Yes;                     // 0x0005A8 (0x000008) [Default: nullptr]
        UCommonButtonBase*          Button_No;                      // 0x0005B0 (0x000008) [Default: nullptr]
        UCommonButtonBase*          Button_CloseTouch;              // 0x0005B8 (0x000008) [Default: nullptr]
        UFortAnnualRefundTicket*    RefundTicket_Left;              // 0x0005C0 (0x000008) [Default: nullptr]
        UFortAnnualRefundTicket*    RefundTicket_Center;            // 0x0005C8 (0x000008) [Default: nullptr]
        UFortAnnualRefundTicket*    RefundTicket_Right;             // 0x0005D0 (0x000008) [Default: nullptr]
    
    public: // Functions
        void    BP_UpdateItemsList(TArray<UFortItemDefinition*>& SelectedItemDefs, int32 TotalMtxPaid); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
        void    BP_UpdateRefundType(EFortPurchaseHistoryRefundType RefundType, bool bBundledRefund); // 0x000545D2 [Event | Protected | BlueprintEvent]
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FPurchaseHistoryBundleEntry
    {
        uint8   UnknownData_000000[0x000010];   // 0x000000 (0x000010)
        FString ID;                             // 0x000010 (0x000010)
    };
}

