/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AircraftADS_Functions
 * ============================================================
 */

#include "AircraftADS_Functions.hpp"

namespace UE
{

    void UFortControllerComponent_AircraftADS::BP_OnZoomInCameraActivate(AFortPlayerController* Initiator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AircraftADS.FortControllerComponent_AircraftADS.BP_OnZoomInCameraActivate");
    
        UFortControllerComponent_AircraftADS___BP_OnZoomInCameraActivate_Params Params{};
        Params.Initiator = Initiator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortControllerComponent_AircraftADS::BP_OnZoomInCameraDeactivate(AFortPlayerController* Initiator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AircraftADS.FortControllerComponent_AircraftADS.BP_OnZoomInCameraDeactivate");
    
        UFortControllerComponent_AircraftADS___BP_OnZoomInCameraDeactivate_Params Params{};
        Params.Initiator = Initiator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortControllerComponent_AircraftADS::OnExitAircraft(AController* Controller)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AircraftADS.FortControllerComponent_AircraftADS.OnExitAircraft");
    
        UFortControllerComponent_AircraftADS___OnExitAircraft_Params Params{};
        Params.Controller = Controller;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortControllerComponent_AircraftADS::OnADSCameraActivation(AFortPlayerController* Controller)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AircraftADS.FortControllerComponent_AircraftADS.OnADSCameraActivation");
    
        UFortControllerComponent_AircraftADS___OnADSCameraActivation_Params Params{};
        Params.Controller = Controller;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortControllerComponent_AircraftADS::OnADSCameraDeactivation(AFortPlayerController* Controller)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AircraftADS.FortControllerComponent_AircraftADS.OnADSCameraDeactivation");
    
        UFortControllerComponent_AircraftADS___OnADSCameraDeactivation_Params Params{};
        Params.Controller = Controller;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

