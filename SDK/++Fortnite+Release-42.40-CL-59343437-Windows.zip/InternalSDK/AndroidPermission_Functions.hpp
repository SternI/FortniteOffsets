/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AndroidPermission_Functions
 * ============================================================
 */

#include "AndroidPermission.hpp"

namespace UE
{

    struct UAndroidPermissionFunctionLibrary___AcquirePermissions_Params
    {
        TArray<FString>                     permissions;    // 0x000000 (0x000010) [OutParam]
        UAndroidPermissionCallbackProxy*    ReturnValue;    // 0x000010 (0x000008) [ReturnValue] [Default: 0x196F8250]
    };

    struct UAndroidPermissionFunctionLibrary___CheckPermission_Params
    {
        FString permission;     // 0x000000 (0x000010) [Default: L"??"]
        bool    ReturnValue;    // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

} // namespace UE

