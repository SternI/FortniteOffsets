/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AuroraFortniteCore
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000030 (0x00002F)
    struct alignas(0x8) FAuroraInvoiceFortnite : public FAuroraInvoice
    {
        FString UxTraceId;  // 0x000010 (0x000010) [Default: L""]
        FString OfferId;    // 0x000020 (0x000010) [Default: L""]
    };
    // Size: 0x000008 (0x000007)
    struct FAuroraPriceVbucks : public FAuroraPriceDimension
    {
    };
}

