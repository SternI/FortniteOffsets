/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AutomationUtils
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class UAutomationUtilsBlueprintLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static void    AddAutomationMountPoint(FString RootPath); // 0x056C7D68 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void    FinishAllAssetCompilation(); // 0x0E4A2A5A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void    RemoveAutomationMountPoint(FString RootPath); // 0x056C7EDE [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void    TakeGameplayAutomationScreenshot(FString ScreenshotName, float MaxGlobalError, float MaxLocalError, FString MapNameOverride); // 0x056C8054 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
}

