/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioInsightsRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class UAudioInsightsBlueprintLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static void    LogAudioInsightsEvent(UObject* WorldContextObject, FString EventName, USoundBase* SoundAsset, AActor* Actor); // 0x07FF0DDC [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void    LogAudioInsightsEventForAudioComponent(UObject* WorldContextObject, FString EventName, UAudioComponent* AudioComponent); // 0x056F031C [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
}

