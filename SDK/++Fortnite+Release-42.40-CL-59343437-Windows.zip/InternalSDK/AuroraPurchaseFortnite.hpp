/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AuroraPurchaseFortnite
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000038 (0x000008)
    class alignas(0x4) UAuroraAnalyticsSubsystem : public UGameInstanceSubsystem
    {
    public:
        float   ChanceToSendUserExperienceEvent;    // 0x000030 (0x000004) [Default: 100f]
        uint8   UnknownData_000034[0x000004];       // 0x000034 (0x000004)
    };
    // Size: 0x0001F8 (0x0001D0)
    class alignas(0x8) UAuroraPurchaseFortnite : public UObject
    {
    public:
        void**          VTable_000028;                          // 0x000028 (0x000008) VTable [21 slots] -> 0x1472B460
        void**          VTable_000030;                          // 0x000030 (0x000008) VTable [28 slots] -> 0x1472B510
        void**          VTable_000038;                          // 0x000038 (0x000008) VTable [20 slots] -> 0x1472B550
        float           TickRate;                               // 0x000040 (0x000004) [Default: 0.25f]
        uint8           UnknownData_000044[0x000004];           // 0x000044 (0x000004)
        double          QueryInventoryRetryBackoff;             // 0x000048 (0x000008) [Default: 1]
        TArray<FString> ApplyOperationRetryDenyList;            // 0x000050 (0x000010)
        int64           MaxApplyOperationRetries;               // 0x000060 (0x000008) [Default: 5ll]
        float           ApplyOperationRetryDelay;               // 0x000068 (0x000004) [Default: 0f]
        bool            bShouldApplyOperationReturnImmediately; // 0x00006C (0x000001) [Default: false]
        uint8           UnknownData_00006D[0x000003];           // 0x00006D (0x000003)
        int32           ApplyOperationMaxInFlightRequests;      // 0x000070 (0x000004) [Default: 1]
        float           ApplyOperationMinimumInterval;          // 0x000074 (0x000004) [Default: 0f]
        bool            bApplyOperationPreserveCallOrder;       // 0x000078 (0x000001) [Default: true]
        bool            bApplyOperationMustUseRepeatCount;      // 0x000079 (0x000001) [Default: false]
        bool            bApplyOperationAllowImmediateExecution; // 0x00007A (0x000001) [Default: false]
        uint8           UnknownData_00007B[0x000005];           // 0x00007B (0x000005)
        int64           ApplyOperationMaxPendingOperations;     // 0x000080 (0x000008) [Default: 50ll]
        double          CacheClearDelay;                        // 0x000088 (0x000008) [Default: 15]
        uint8           UnknownData_000090[0x000168];           // 0x000090 (0x000168)
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x8) FAuroraPurchaseInvoicePayload
    {
        FString WorkspaceId;    // 0x000000 (0x000010)
        FString LinkMode;       // 0x000010 (0x000010)
        FString InvoiceId;      // 0x000020 (0x000010)
        FString UxTraceId;      // 0x000030 (0x000010)
    };
    // Size: 0x000010 (0x00000F)
    struct FAuroraReceiptFortnite : public FAuroraReceipt
    {
    };
}

