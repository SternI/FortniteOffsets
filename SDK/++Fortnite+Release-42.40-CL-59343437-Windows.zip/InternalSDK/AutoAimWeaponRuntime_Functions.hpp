/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AutoAimWeaponRuntime_Functions
 * ============================================================
 */

#include "AutoAimWeaponRuntime.hpp"

namespace UE
{

    struct UAutoAimWeaponKismetLibrary___DoesAutoAimWeaponHaveLineOfSight_Params
    {
        AFortPawn*  SourcePawn;     // 0x000000 (0x000008) [Default: 0x130A5F60]
        AFortPawn*  TargetPawn;     // 0x000008 (0x000008) [Default: 0x715C18DD00000031]
        bool        ReturnValue;    // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAutoAimWeaponKismetLibrary___DoesAutoAimWeaponReticleIntersectTarget_Params
    {
        float       OutReticleDistance;             // 0x000000 (0x000004) [OutParam] [Default: 1.74651e-27f]
        uint8       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        AFortPawn*  SourcePawn;                     // 0x000008 (0x000008) [Default: 0x715C18DD00000031]
        AFortPawn*  TargetPawn;                     // 0x000010 (0x000008) [Default: 0x197ED650]
        float       ReticleSize;                    // 0x000018 (0x000004) [Default: 1.31726e-23f]
        bool        ReturnValue;                    // 0x00001C (0x000001) [ReturnValue] [Default: false]
    };

    struct UAutoAimWeaponKismetLibrary___FindBestAutoAimTarget_Params
    {
        AFortPawn*          OutTargetPawn;                  // 0x000000 (0x000008) [OutParam] [Default: 0x130A5F60]
        float               OutReticleDistance;             // 0x000008 (0x000004) [OutParam] [Default: 6.86636e-44f]
        uint8               UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        AFortPlayerPawn*    SourcePawn;                     // 0x000010 (0x000008) [Default: 0x197ED650]
        float               ReticleSize;                    // 0x000018 (0x000004) [Default: 1.31726e-23f]
        float               Range;                          // 0x00001C (0x000004) [Default: 0f]
    };

    struct UAutoAimWeaponKismetLibrary___GetAutoAimWeaponPawnComponent_Params
    {
        AFortPawn*                      SourcePawn;     // 0x000000 (0x000008) [Default: 0x130A5F60]
        UAutoAimWeaponPawnComponent*    ReturnValue;    // 0x000008 (0x000008) [ReturnValue] [Default: 0x715C18DD00000031]
    };

    struct UAutoAimWeaponPawnComponent___ApplySpreadToAimRotation_Params
    {
        FRotator    OutRotation;        // 0x000000 (0x000018) [OutParam]
        float       SpreadInDegrees;    // 0x000018 (0x000004) [Default: 1.31726e-23f]
    };

    struct UAutoAimWeaponPawnComponent___GetCurrentLockOnCount_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 345033760]
    };

    struct UAutoAimWeaponPawnComponent___GetLockOnProgress_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.46208e-26f]
    };

    struct UAutoAimWeaponPawnComponent___GetLockOnTargetLocation_Params
    {
        FVector OutLockTargetLocation;  // 0x000000 (0x000018) [OutParam]
        bool    ReturnValue;            // 0x000018 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAutoAimWeaponPawnComponent___GetTargetToReticleDistanceNormalized_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.46208e-26f]
    };

    struct UAutoAimWeaponPawnComponent___RotateAimTowardsLockOnTarget_Params
    {
        FRotator    OutRotation;    // 0x000000 (0x000018) [OutParam]
    };

} // namespace UE

