/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:48
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ACLPlugin
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000038 (0x000000)
    class UAnimBoneCompressionCodec_ACL : public UAnimBoneCompressionCodec_ACLBase
    {
    public:
    };
    // Size: 0x000038 (0x000000)
    class UAnimBoneCompressionCodec_ACLBase : public UAnimBoneCompressionCodec
    {
    public:
    };
    // Size: 0x000038 (0x000000)
    class UAnimBoneCompressionCodec_ACLCustom : public UAnimBoneCompressionCodec_ACLBase
    {
    public:
    };
    // Size: 0x000040 (0x000008)
    class alignas(0x8) UAnimBoneCompressionCodec_ACLDatabase : public UAnimBoneCompressionCodec_ACLBase
    {
    public:
        UAnimationCompressionLibraryDatabase*   DatabaseAsset;  // 0x000038 (0x000008) [Default: nullptr]
    };
    // Size: 0x000038 (0x000000)
    class UAnimBoneCompressionCodec_ACLSafe : public UAnimBoneCompressionCodec_ACLBase
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class UAnimCurveCompressionCodec_ACL : public UAnimCurveCompressionCodec
    {
    public:
    };
    // Size: 0x000128 (0x000100)
    class alignas(0x8) UAnimationCompressionLibraryDatabase : public UObject
    {
    public:
        TArray<uint8>       CookedCompressedBytes;          // 0x000028 (0x000010)
        TArray<uint64>      CookedAnimSequenceMappings;     // 0x000038 (0x000010)
        uint8               UnknownData_000048[0x0000D8];   // 0x000048 (0x0000D8)
        uint32              MaxStreamRequestSizeKB;         // 0x000120 (0x000004) [Default: 1024u]
        ACLVisualFidelity   DefaultVisualFidelity;          // 0x000124 (0x000001) [Default: ACLVisualFidelity(2)]
        uint8               UnknownData_000125[0x000003];   // 0x000125 (0x000003)
    
    public: // Functions
        static ACLVisualFidelity   GetVisualFidelity(UAnimationCompressionLibraryDatabase* DatabaseAsset); // 0x07E68044 [Final | Native | Static | Public | BlueprintCallable]
        static void                SetVisualFidelity(UObject* WorldContextObject, FLatentActionInfo LatentInfo, UAnimationCompressionLibraryDatabase* DatabaseAsset, ACLVisualFidelityChangeResult& Result, ACLVisualFidelity VisualFidelity); // 0x07E681BE [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
    };
}

