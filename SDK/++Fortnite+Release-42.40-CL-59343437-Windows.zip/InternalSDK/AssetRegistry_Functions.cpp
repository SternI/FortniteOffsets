/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:12
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AssetRegistry_Functions
 * ============================================================
 */

#include "AssetRegistry_Functions.hpp"

namespace UE
{

    bool IAssetRegistry::GetAllAssets(TArray<FAssetData>& OutAssetData, bool bIncludeOnlyOnDiskAssets)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.GetAllAssets");
    
        IAssetRegistry___GetAllAssets_Params Params{};
        Params.OutAssetData = OutAssetData;
        Params.bIncludeOnlyOnDiskAssets = bIncludeOnlyOnDiskAssets;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutAssetData = Params.OutAssetData;
    
        return Params.ReturnValue;
    }

    void IAssetRegistry::GetAllCachedPaths(TArray<FString>& OutPathList)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.GetAllCachedPaths");
    
        IAssetRegistry___GetAllCachedPaths_Params Params{};
        Params.OutPathList = OutPathList;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutPathList = Params.OutPathList;
    }

    bool IAssetRegistry::GetAncestorClassNames(FTopLevelAssetPath ClassPathName, TArray<FTopLevelAssetPath>& OutAncestorClassNames)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.GetAncestorClassNames");
    
        IAssetRegistry___GetAncestorClassNames_Params Params{};
        Params.ClassPathName = ClassPathName;
        Params.OutAncestorClassNames = OutAncestorClassNames;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutAncestorClassNames = Params.OutAncestorClassNames;
    
        return Params.ReturnValue;
    }

    FAssetData IAssetRegistry::GetAssetByObjectPath(FName ObjectPath, bool bIncludeOnlyOnDiskAssets)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.GetAssetByObjectPath");
    
        IAssetRegistry___GetAssetByObjectPath_Params Params{};
        Params.ObjectPath = ObjectPath;
        Params.bIncludeOnlyOnDiskAssets = bIncludeOnlyOnDiskAssets;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool IAssetRegistry::GetAssets(FARFilter& Filter, TArray<FAssetData>& OutAssetData, bool bSkipARFilteredAssets)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.GetAssets");
    
        IAssetRegistry___GetAssets_Params Params{};
        Params.Filter = Filter;
        Params.OutAssetData = OutAssetData;
        Params.bSkipARFilteredAssets = bSkipARFilteredAssets;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Filter = Params.Filter;
        OutAssetData = Params.OutAssetData;
    
        return Params.ReturnValue;
    }

    bool IAssetRegistry::GetAssetsByClass(FTopLevelAssetPath ClassPathName, TArray<FAssetData>& OutAssetData, bool bSearchSubClasses)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.GetAssetsByClass");
    
        IAssetRegistry___GetAssetsByClass_Params Params{};
        Params.ClassPathName = ClassPathName;
        Params.OutAssetData = OutAssetData;
        Params.bSearchSubClasses = bSearchSubClasses;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutAssetData = Params.OutAssetData;
    
        return Params.ReturnValue;
    }

    bool IAssetRegistry::GetAssetsByPackageName(FName PackageName, TArray<FAssetData>& OutAssetData, bool bIncludeOnlyOnDiskAssets, bool bSkipARFilteredAssets)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.GetAssetsByPackageName");
    
        IAssetRegistry___GetAssetsByPackageName_Params Params{};
        Params.PackageName = PackageName;
        Params.OutAssetData = OutAssetData;
        Params.bIncludeOnlyOnDiskAssets = bIncludeOnlyOnDiskAssets;
        Params.bSkipARFilteredAssets = bSkipARFilteredAssets;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutAssetData = Params.OutAssetData;
    
        return Params.ReturnValue;
    }

    bool IAssetRegistry::GetAssetsByPath(FName PackagePath, TArray<FAssetData>& OutAssetData, bool bRecursive, bool bIncludeOnlyOnDiskAssets)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.GetAssetsByPath");
    
        IAssetRegistry___GetAssetsByPath_Params Params{};
        Params.PackagePath = PackagePath;
        Params.OutAssetData = OutAssetData;
        Params.bRecursive = bRecursive;
        Params.bIncludeOnlyOnDiskAssets = bIncludeOnlyOnDiskAssets;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutAssetData = Params.OutAssetData;
    
        return Params.ReturnValue;
    }

    bool IAssetRegistry::GetAssetsByPaths(TArray<FName> PackagePaths, TArray<FAssetData>& OutAssetData, bool bRecursive, bool bIncludeOnlyOnDiskAssets)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.GetAssetsByPaths");
    
        IAssetRegistry___GetAssetsByPaths_Params Params{};
        Params.PackagePaths = PackagePaths;
        Params.OutAssetData = OutAssetData;
        Params.bRecursive = bRecursive;
        Params.bIncludeOnlyOnDiskAssets = bIncludeOnlyOnDiskAssets;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutAssetData = Params.OutAssetData;
    
        return Params.ReturnValue;
    }

    void IAssetRegistry::GetDerivedClassNames(TArray<FTopLevelAssetPath>& ClassNames, TSet<FTopLevelAssetPath>& ExcludedClassNames, TSet<FTopLevelAssetPath>& OutDerivedClassNames)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.GetDerivedClassNames");
    
        IAssetRegistry___GetDerivedClassNames_Params Params{};
        Params.ClassNames = ClassNames;
        Params.ExcludedClassNames = ExcludedClassNames;
        Params.OutDerivedClassNames = OutDerivedClassNames;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ClassNames = Params.ClassNames;
        ExcludedClassNames = Params.ExcludedClassNames;
        OutDerivedClassNames = Params.OutDerivedClassNames;
    }

    bool IAssetRegistry::GetInMemoryAssets(FARFilter& Filter, TArray<FAssetData>& OutAssetData, bool bSkipARFilteredAssets)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.GetInMemoryAssets");
    
        IAssetRegistry___GetInMemoryAssets_Params Params{};
        Params.Filter = Filter;
        Params.OutAssetData = OutAssetData;
        Params.bSkipARFilteredAssets = bSkipARFilteredAssets;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Filter = Params.Filter;
        OutAssetData = Params.OutAssetData;
    
        return Params.ReturnValue;
    }

    void IAssetRegistry::GetSubPaths(FString InBasePath, TArray<FString>& OutPathList, bool bInRecurse)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.GetSubPaths");
    
        IAssetRegistry___GetSubPaths_Params Params{};
        Params.InBasePath = InBasePath;
        Params.OutPathList = OutPathList;
        Params.bInRecurse = bInRecurse;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutPathList = Params.OutPathList;
    }

    bool IAssetRegistry::HasAssets(FName PackagePath, bool bRecursive)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.HasAssets");
    
        IAssetRegistry___HasAssets_Params Params{};
        Params.PackagePath = PackagePath;
        Params.bRecursive = bRecursive;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool IAssetRegistry::IsLoadingAssets()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.IsLoadingAssets");
    
        IAssetRegistry___IsLoadingAssets_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool IAssetRegistry::IsSearchAllAssets()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.IsSearchAllAssets");
    
        IAssetRegistry___IsSearchAllAssets_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool IAssetRegistry::IsSearchAsync()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.IsSearchAsync");
    
        IAssetRegistry___IsSearchAsync_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FAssetData IAssetRegistry::K2_GetAssetByObjectPath(FSoftObjectPath& ObjectPath, bool bIncludeOnlyOnDiskAssets, bool bSkipARFilteredAssets)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.K2_GetAssetByObjectPath");
    
        IAssetRegistry___K2_GetAssetByObjectPath_Params Params{};
        Params.ObjectPath = ObjectPath;
        Params.bIncludeOnlyOnDiskAssets = bIncludeOnlyOnDiskAssets;
        Params.bSkipARFilteredAssets = bSkipARFilteredAssets;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ObjectPath = Params.ObjectPath;
    
        return Params.ReturnValue;
    }

    bool IAssetRegistry::K2_GetDependencies(FName PackageName, FAssetRegistryDependencyOptions& DependencyOptions, TArray<FName>& OutDependencies)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.K2_GetDependencies");
    
        IAssetRegistry___K2_GetDependencies_Params Params{};
        Params.PackageName = PackageName;
        Params.DependencyOptions = DependencyOptions;
        Params.OutDependencies = OutDependencies;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        DependencyOptions = Params.DependencyOptions;
        OutDependencies = Params.OutDependencies;
    
        return Params.ReturnValue;
    }

    bool IAssetRegistry::K2_GetReferencers(FName PackageName, FAssetRegistryDependencyOptions& ReferenceOptions, TArray<FName>& OutReferencers)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.K2_GetReferencers");
    
        IAssetRegistry___K2_GetReferencers_Params Params{};
        Params.PackageName = PackageName;
        Params.ReferenceOptions = ReferenceOptions;
        Params.OutReferencers = OutReferencers;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ReferenceOptions = Params.ReferenceOptions;
        OutReferencers = Params.OutReferencers;
    
        return Params.ReturnValue;
    }

    void IAssetRegistry::PrioritizeSearchPath(FString PathToPrioritize)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.PrioritizeSearchPath");
    
        IAssetRegistry___PrioritizeSearchPath_Params Params{};
        Params.PathToPrioritize = PathToPrioritize;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void IAssetRegistry::RunAssetsThroughFilter(TArray<FAssetData>& AssetDataList, FARFilter& Filter)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.RunAssetsThroughFilter");
    
        IAssetRegistry___RunAssetsThroughFilter_Params Params{};
        Params.AssetDataList = AssetDataList;
        Params.Filter = Filter;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        AssetDataList = Params.AssetDataList;
        Filter = Params.Filter;
    }

    void IAssetRegistry::ScanFilesSynchronous(TArray<FString>& InFilePaths, bool bForceRescan)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.ScanFilesSynchronous");
    
        IAssetRegistry___ScanFilesSynchronous_Params Params{};
        Params.InFilePaths = InFilePaths;
        Params.bForceRescan = bForceRescan;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InFilePaths = Params.InFilePaths;
    }

    void IAssetRegistry::ScanModifiedAssetFiles(TArray<FString>& InFilePaths)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.ScanModifiedAssetFiles");
    
        IAssetRegistry___ScanModifiedAssetFiles_Params Params{};
        Params.InFilePaths = InFilePaths;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InFilePaths = Params.InFilePaths;
    }

    void IAssetRegistry::ScanPathsSynchronous(TArray<FString>& InPaths, bool bForceRescan, bool bIgnoreDenyListScanFilters)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.ScanPathsSynchronous");
    
        IAssetRegistry___ScanPathsSynchronous_Params Params{};
        Params.InPaths = InPaths;
        Params.bForceRescan = bForceRescan;
        Params.bIgnoreDenyListScanFilters = bIgnoreDenyListScanFilters;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InPaths = Params.InPaths;
    }

    void IAssetRegistry::SearchAllAssets(bool bSynchronousSearch)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.SearchAllAssets");
    
        IAssetRegistry___SearchAllAssets_Params Params{};
        Params.bSynchronousSearch = bSynchronousSearch;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void IAssetRegistry::UseFilterToExcludeAssets(TArray<FAssetData>& AssetDataList, FARFilter& Filter)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.UseFilterToExcludeAssets");
    
        IAssetRegistry___UseFilterToExcludeAssets_Params Params{};
        Params.AssetDataList = AssetDataList;
        Params.Filter = Filter;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        AssetDataList = Params.AssetDataList;
        Filter = Params.Filter;
    }

    void IAssetRegistry::WaitForCompletion()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.WaitForCompletion");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void IAssetRegistry::WaitForPackage(FString PackageName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistry.WaitForPackage");
    
        IAssetRegistry___WaitForPackage_Params Params{};
        Params.PackageName = PackageName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    FAssetData UAssetRegistryHelpers::CreateAssetData(UObject* InAsset, bool bAllowBlueprintClass)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.CreateAssetData");
    
        UAssetRegistryHelpers___CreateAssetData_Params Params{};
        Params.InAsset = InAsset;
        Params.bAllowBlueprintClass = bAllowBlueprintClass;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UClass* UAssetRegistryHelpers::FindAssetNativeClass(FAssetData& AssetData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.FindAssetNativeClass");
    
        UAssetRegistryHelpers___FindAssetNativeClass_Params Params{};
        Params.AssetData = AssetData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        AssetData = Params.AssetData;
    
        return Params.ReturnValue;
    }

    UObject* UAssetRegistryHelpers::GetAsset(FAssetData& InAssetData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.GetAsset");
    
        UAssetRegistryHelpers___GetAsset_Params Params{};
        Params.InAssetData = InAssetData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InAssetData = Params.InAssetData;
    
        return Params.ReturnValue;
    }

    TScriptInterface<IAssetRegistry> UAssetRegistryHelpers::GetAssetRegistry()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.GetAssetRegistry");
    
        UAssetRegistryHelpers___GetAssetRegistry_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAssetRegistryHelpers::GetBlueprintAssets(FARFilter& InFilter, TArray<FAssetData>& OutAssetData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.GetBlueprintAssets");
    
        UAssetRegistryHelpers___GetBlueprintAssets_Params Params{};
        Params.InFilter = InFilter;
        Params.OutAssetData = OutAssetData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InFilter = Params.InFilter;
        OutAssetData = Params.OutAssetData;
    }

    UClass* UAssetRegistryHelpers::GetClass(FAssetData& InAssetData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.GetClass");
    
        UAssetRegistryHelpers___GetClass_Params Params{};
        Params.InAssetData = InAssetData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InAssetData = Params.InAssetData;
    
        return Params.ReturnValue;
    }

    void UAssetRegistryHelpers::GetDerivedClassAssetData(TArray<FTopLevelAssetPath>& InBaseClasses, TArray<FAssetData>& OutDerivedClassAssetData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.GetDerivedClassAssetData");
    
        UAssetRegistryHelpers___GetDerivedClassAssetData_Params Params{};
        Params.InBaseClasses = InBaseClasses;
        Params.OutDerivedClassAssetData = OutDerivedClassAssetData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InBaseClasses = Params.InBaseClasses;
        OutDerivedClassAssetData = Params.OutDerivedClassAssetData;
    }

    FString UAssetRegistryHelpers::GetExportTextName(FAssetData& InAssetData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.GetExportTextName");
    
        UAssetRegistryHelpers___GetExportTextName_Params Params{};
        Params.InAssetData = InAssetData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InAssetData = Params.InAssetData;
    
        return Params.ReturnValue;
    }

    FString UAssetRegistryHelpers::GetFullName(FAssetData& InAssetData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.GetFullName");
    
        UAssetRegistryHelpers___GetFullName_Params Params{};
        Params.InAssetData = InAssetData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InAssetData = Params.InAssetData;
    
        return Params.ReturnValue;
    }

    bool UAssetRegistryHelpers::GetTagValue(FAssetData& InAssetData, FName& InTagName, FString& OutTagValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.GetTagValue");
    
        UAssetRegistryHelpers___GetTagValue_Params Params{};
        Params.InAssetData = InAssetData;
        Params.InTagName = InTagName;
        Params.OutTagValue = OutTagValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InAssetData = Params.InAssetData;
        InTagName = Params.InTagName;
        OutTagValue = Params.OutTagValue;
    
        return Params.ReturnValue;
    }

    bool UAssetRegistryHelpers::IsAssetLoaded(FAssetData& InAssetData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.IsAssetLoaded");
    
        UAssetRegistryHelpers___IsAssetLoaded_Params Params{};
        Params.InAssetData = InAssetData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InAssetData = Params.InAssetData;
    
        return Params.ReturnValue;
    }

    bool UAssetRegistryHelpers::IsRedirector(FAssetData& InAssetData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.IsRedirector");
    
        UAssetRegistryHelpers___IsRedirector_Params Params{};
        Params.InAssetData = InAssetData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InAssetData = Params.InAssetData;
    
        return Params.ReturnValue;
    }

    bool UAssetRegistryHelpers::IsUAsset(FAssetData& InAssetData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.IsUAsset");
    
        UAssetRegistryHelpers___IsUAsset_Params Params{};
        Params.InAssetData = InAssetData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InAssetData = Params.InAssetData;
    
        return Params.ReturnValue;
    }

    bool UAssetRegistryHelpers::IsValid(FAssetData& InAssetData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.IsValid");
    
        UAssetRegistryHelpers___IsValid_Params Params{};
        Params.InAssetData = InAssetData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InAssetData = Params.InAssetData;
    
        return Params.ReturnValue;
    }

    FARFilter UAssetRegistryHelpers::SetFilterTagsAndValues(FARFilter& InFilter, TArray<FTagAndValue>& InTagsAndValues)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.SetFilterTagsAndValues");
    
        UAssetRegistryHelpers___SetFilterTagsAndValues_Params Params{};
        Params.InFilter = InFilter;
        Params.InTagsAndValues = InTagsAndValues;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InFilter = Params.InFilter;
        InTagsAndValues = Params.InTagsAndValues;
    
        return Params.ReturnValue;
    }

    void UAssetRegistryHelpers::SortByAssetName(TArray<FAssetData>& Assets, EAssetRegistrySortOrder SortOrder)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.SortByAssetName");
    
        UAssetRegistryHelpers___SortByAssetName_Params Params{};
        Params.Assets = Assets;
        Params.SortOrder = SortOrder;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Assets = Params.Assets;
    }

    void UAssetRegistryHelpers::SortByPredicate(TArray<FAssetData>& Assets, SortingPredicate SortingPredicate, EAssetRegistrySortOrder SortOrder)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.SortByPredicate");
    
        UAssetRegistryHelpers___SortByPredicate_Params Params{};
        Params.Assets = Assets;
        Params.SortingPredicate = SortingPredicate;
        Params.SortOrder = SortOrder;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Assets = Params.Assets;
    }

    FSoftObjectPath UAssetRegistryHelpers::ToSoftObjectPath(FAssetData& InAssetData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.ToSoftObjectPath");
    
        UAssetRegistryHelpers___ToSoftObjectPath_Params Params{};
        Params.InAssetData = InAssetData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InAssetData = Params.InAssetData;
    
        return Params.ReturnValue;
    }

    bool UAssetRegistryHelpers::SortingPredicate(FAssetData& Left, FAssetData& Right)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssetRegistry.AssetRegistryHelpers.SortingPredicate");
    
        UAssetRegistryHelpers___SortingPredicate_Params Params{};
        Params.Left = Left;
        Params.Right = Right;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Left = Params.Left;
        Right = Params.Right;
    
        return Params.ReturnValue;
    }

} // namespace UE

