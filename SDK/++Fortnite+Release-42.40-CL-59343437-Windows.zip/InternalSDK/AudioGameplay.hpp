/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:09
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioGameplay
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000048 (0x000020)
    class alignas(0x8) UAudioAssetUserData : public UAssetUserData
    {
    public:
        FGameplayTagContainer   MetadataTags;   // 0x000028 (0x000020)
    
    public: // Functions
        static FGameplayTagContainer   GetAllTags(USoundBase* InSound); // 0x04DFD522 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static FGameplayTagContainer   GetFilteredTags(USoundBase* InSound, FGameplayTag InTag); // 0x04DFD716 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static bool                    HasTag(USoundBase* InSound, FGameplayTag InTag, bool bExactMatch); // 0x04DFDA18 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
    };
    // Size: 0x000330 (0x0000F0)
    class alignas(0x8) UAudioComponentGroup : public USceneComponent
    {
    public:
        void**                                                  VTable_000240;                  // 0x000240 (0x000008) VTable [17 slots] -> 0x131F1140
        MULTI_INLINE_DELEGATE(SoundGroupChanged)                OnStopped;                      // 0x000248 (0x000010)
        MULTI_INLINE_DELEGATE(SoundGroupChanged)                OnKilled;                       // 0x000258 (0x000010)
        MULTI_INLINE_DELEGATE(SoundGroupChanged)                OnVirtualized;                  // 0x000268 (0x000010)
        MULTI_INLINE_DELEGATE(SoundGroupChanged)                OnUnvirtualized;                // 0x000278 (0x000010)
        TArray<UAudioComponent*>                                Components;                     // 0x000288 (0x000010)
        TArray<FAudioParameter>                                 ParamsToSet;                    // 0x000298 (0x000010)
        TArray<FAudioParameter>                                 PersistentParams;               // 0x0002A8 (0x000010)
        TArray<TScriptInterface<IAudioComponentGroupExtension>> Extensions;                     // 0x0002B8 (0x000010)
        uint8                                                   UnknownData_0002C8[0x000068];   // 0x0002C8 (0x000068)
    
    public: // Functions
        void                    AddExtension(TScriptInterface<IAudioComponentGroupExtension> NewExtension); // 0x04DFDDB4 [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                    AddExternalComponent(UAudioComponent* ComponentToAdd); // 0x04DFDF66 [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                    BroadcastEvent(FName EventName); // 0x04DFE0D4 [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                    BroadcastKill(); // 0x0D84D6C8 [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                    BroadcastStopAll(); // 0x0D84D724 [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                    DisableVirtualization(); // 0x0D84D780 [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                    EnableVirtualization(); // 0x0D84D884 [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        bool                    GetBoolParamValue(FName ParamName); // 0x04DFE240 [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float                   GetFloatParamValue(FName ParamName); // 0x04DFE3DC [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FString                 GetStringParamValue(FName ParamName); // 0x04DFE564 [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                    IsPlayingAny(); // 0x0D84D94C [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                    IsVirtualized(); // 0x0D84D968 [Final | BlueprintCosmetic | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                    RemoveExtension(TScriptInterface<IAudioComponentGroupExtension> NewExtension); // 0x04DFE808 [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                    RemoveExternalComponent(UAudioComponent* ComponentToRemove); // 0x04DFE9AC [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                    SetLowPassFilter(float InFrequency); // 0x04DFEB1A [Final | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                    SetPitchMultiplier(float InPitch); // 0x04DFEC8C [Final | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                    SetVolumeMultiplier(float InVolume); // 0x04DFEDFE [Final | BlueprintCosmetic | Native | Public | BlueprintCallable]
        static UAudioComponentGroup*   StaticGetOrCreateComponentGroup(AActor* Actor); // 0x04DFEF70 [Final | RequiredAPI | BlueprintCosmetic | Native | Static | Public | BlueprintCallable]
        void                    StopSound(USoundBase* Sound, float FadeTime); // 0x04DFF0E2 [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                    SubscribeToBool(FName ParamName, BoolParamCallback Delegate); // 0x04DFF362 [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                    SubscribeToEvent(FName EventName, SoundCallback Delegate); // 0x04DFF71A [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                    SubscribeToStringParam(FName ParamName, StringParamCallback Delegate); // 0x04DFFAD2 [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                    UnsubscribeObject(UObject* Object); // 0x04DFFD68 [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class IAudioComponentGroupExtension : public IInterface
    {
    public:
    };
    // Size: 0x0000C8 (0x000008)
    class UAudioGameplayComponent : public UActorComponent
    {
    public:
        uint8   UnknownData_0000C0[0x000008];   // 0x0000C0 (0x000008)
    };
    // Size: 0x000028 (0x000000)
    class IAudioGameplayCondition : public IInterface
    {
    public:
    
    public: // Functions
        bool    ConditionMet(); // 0x0A2DA856 [RequiredAPI | Native | Event | Public | BlueprintCallable | BlueprintEvent | BlueprintPure | Const]
        bool    ConditionMet_Position(FVector& Position); // 0x04DFD388 [RequiredAPI | Native | Event | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintEvent | BlueprintPure | Const]
    };
    // Size: 0x000048 (0x000010)
    class UAudioGameplayTagCacheSubsystem : public UWorldSubsystem
    {
    public:
        uint8   UnknownData_000038[0x000010];   // 0x000038 (0x000010)
    };
    // Size: 0x000028 (0x000000)
    class IAudioGameplayVolumeInteraction : public IInterface
    {
    public:
    
    public: // Functions
        void    OnListenerEnter(); // 0x01FA6146 [RequiredAPI | Native | Event | Public | BlueprintCallable | BlueprintEvent]
        void    OnListenerExit(); // 0x04DFD50A [RequiredAPI | Native | Event | Public | BlueprintCallable | BlueprintEvent]
    };
    // Size: 0x0000F8 (0x000030)
    class alignas(0x8) UAudioParameterComponent : public UAudioGameplayComponent
    {
    public:
        void**                                  VTable_0000C8;      // 0x0000C8 (0x000008) VTable [17 slots] -> 0x131F20F0
        void**                                  VTable_0000D0;      // 0x0000D0 (0x000008) VTable [3 slots] -> 0x131F2180
        TArray<TWeakObjectPtr<UAudioComponent>> ActiveComponents;   // 0x0000D8 (0x000010)
        TArray<FAudioParameter>                 Parameters;         // 0x0000E8 (0x000010)
    
    public: // Functions
        TArray<FAudioParameter> GetParameters(); // 0x01EBF472 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000070 (0x000048)
    class alignas(0x8) UAudioRequirementPreset : public UDataAsset
    {
    public:
        FGameplayTagQuery   Query;  // 0x000028 (0x000048)
    };
    // Size: 0x000060 (0x000030)
    class alignas(0x8) USoundHandleSubsystem : public UAudioEngineSubsystem
    {
    public:
        void**  VTable_000030;                  // 0x000030 (0x000008) VTable [17 slots] -> 0x131F2470
        void**  VTable_000038;                  // 0x000038 (0x000008) VTable [5 slots] -> 0x131F24D0
        uint8   UnknownData_000040[0x000020];   // 0x000040 (0x000020)
    };
    // Size: 0x000050 (0x000050)
    struct alignas(0x8) FAudioGameplayRequirements
    {
        UAudioRequirementPreset*    Preset; // 0x000000 (0x000008) [Default: 0x16A23710]
        FGameplayTagQuery           Custom; // 0x000008 (0x000048)
    };
}

