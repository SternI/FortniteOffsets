/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AuroraCore_Functions
 * ============================================================
 */

#include "AuroraCore.hpp"

namespace UE
{

    struct UAuroraPlayerControllerComponent___BP_CloseOffersDialog_Params
    {
        bool    bForce; // 0x000000 (0x000001) [Default: true]
    };

    struct UAuroraPlayerControllerComponent___BP_OnFinalizedPurchaseResult_Params
    {
        FInstancedStruct    InReceipt;      // 0x000000 (0x000010) [OutParam]
        bool                bSuccessful;    // 0x000010 (0x000001) [Default: true]
    };

    struct UAuroraPlayerControllerComponent___BP_OnIntentPurchaseOfferFailed_Params
    {
        FGuid   InOfferInstanceId;  // 0x000000 (0x000010) [OutParam]
    };

    struct UAuroraPlayerControllerComponent___BP_OnOwnedProductQuantitiesChanged_Params
    {
        TMap<FString, int64>    InOwnedProductQuantities;   // 0x000000 (0x000010) [OutParam]
    };

    struct UAuroraPlayerControllerComponent___BP_OnPurchasedInvoice_Params
    {
        FInstancedStruct    InInvoice;                      // 0x000000 (0x000010) [OutParam]
        bool                bSuccessful;                    // 0x000010 (0x000001) [Default: true]
        uint8               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FInstancedStruct    InReceipt;                      // 0x000018 (0x000010) [OutParam]
        FString             InErrorCode;                    // 0x000028 (0x000010) [Default: L""]
    };

    struct UAuroraPlayerControllerComponent___BP_ShowOffersDialog_Params
    {
        FGuid                       InCatalogId;    // 0x000000 (0x000010) [OutParam]
        TArray<FInstancedStruct>    InOffers;       // 0x000010 (0x000010) [OutParam]
        FText                       InTitle;        // 0x000020 (0x000010) [OutParam]
    };

    struct UAuroraPlayerControllerComponent___BP_StartPurchaseInvoice_Params
    {
        FInstancedStruct    InInvoice;                      // 0x000000 (0x000010) [OutParam]
        bool                bInSuccessful;                  // 0x000010 (0x000001) [Default: true]
        uint8               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FString             InErrorCode;                    // 0x000018 (0x000010) [Default: L""]
    };

    struct UAuroraPlayerControllerComponent___BP_StartPurchaseInvoiceOfferQueried_Params
    {
        FInstancedStruct    InInvoice;                      // 0x000000 (0x000010) [OutParam]
        bool                bSuccessful;                    // 0x000010 (0x000001) [Default: true]
        uint8               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FInstancedStruct    InOffer;                        // 0x000018 (0x000010) [OutParam]
    };

    struct UAuroraPlayerControllerComponent___ClientCloseOffersDialog_Params
    {
        FGuid   InCatalogId;    // 0x000000 (0x000010)
        bool    bForce;         // 0x000010 (0x000001) [Default: true]
    };

    struct UAuroraPlayerControllerComponent___ClientFinalizePurchaseResult_Params
    {
        FInstancedStruct    InReceipt;      // 0x000000 (0x000010)
        bool                bSuccessful;    // 0x000010 (0x000001) [Default: true]
    };

    struct UAuroraPlayerControllerComponent___ClientIntentPurchaseOfferFailed_Params
    {
        FGuid   InOfferInstanceId;  // 0x000000 (0x000010)
    };

    struct UAuroraPlayerControllerComponent___ClientShowOffersDialog_Params
    {
        FGuid                       InCatalogId;    // 0x000000 (0x000010)
        TArray<FInstancedStruct>    InOffers;       // 0x000010 (0x000010)
        FText                       InTitle;        // 0x000020 (0x000010)
    };

    struct UAuroraPlayerControllerComponent___ClientStartPurchaseInvoice_Params
    {
        FInstancedStruct    InInvoice;                      // 0x000000 (0x000010)
        bool                bInSuccessful;                  // 0x000010 (0x000001) [Default: true]
        uint8               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FString             InErrorCode;                    // 0x000018 (0x000010) [Default: L""]
    };

    struct UAuroraPlayerControllerComponent___CloseOffersDialog_Params
    {
        FGuid   InCatalogId;    // 0x000000 (0x000010) [OutParam]
        bool    bForce;         // 0x000010 (0x000001) [Default: true]
    };

    struct UAuroraPlayerControllerComponent___GetOwnedProductQuantities_Params
    {
        TMap<FString, int64>    ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAuroraPlayerControllerComponent___PurchaseInvoice_Params
    {
        FInstancedStruct    InInvoice;  // 0x000000 (0x000010) [OutParam]
    };

    struct UAuroraPlayerControllerComponent___ServerIntentPurchaseOffer_Params
    {
        FGuid   InOfferInstanceId;  // 0x000000 (0x000010)
    };

    struct UAuroraPlayerControllerComponent___ServerUploadReceipt_Params
    {
        FInstancedStruct    InReceipt;  // 0x000000 (0x000010)
    };

    struct UAuroraPlayerControllerComponent___ShowOffersDialog_Params
    {
        FGuid                       InCatalogId;    // 0x000000 (0x000010) [OutParam]
        TArray<FInstancedStruct>    InOffers;       // 0x000010 (0x000010) [OutParam]
        FText                       InTitle;        // 0x000020 (0x000010) [OutParam]
    };

} // namespace UE

