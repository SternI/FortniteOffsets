/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:09
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimationBudgetAllocator_Functions
 * ============================================================
 */

#include "AnimationBudgetAllocator_Functions.hpp"

namespace UE
{

    void UAnimationBudgetBlueprintLibrary::EnableAnimationBudget(UObject* WorldContextObject, bool bEnabled)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget");
    
        UAnimationBudgetBlueprintLibrary___EnableAnimationBudget_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.bEnabled = bEnabled;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAnimationBudgetBlueprintLibrary::SetAnimationBudgetParameters(UObject* WorldContextObject, FAnimationBudgetAllocatorParameters& InParameters)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters");
    
        UAnimationBudgetBlueprintLibrary___SetAnimationBudgetParameters_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.InParameters = InParameters;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InParameters = Params.InParameters;
    }

    void USkeletalMeshComponentBudgeted::SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator");
    
        USkeletalMeshComponentBudgeted___SetAutoRegisterWithBudgetAllocator_Params Params{};
        Params.bInAutoRegisterWithBudgetAllocator = bInAutoRegisterWithBudgetAllocator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

