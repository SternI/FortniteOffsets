/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimPresetsCore
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class UAnimPreset : public UObject
    {
    public:
    
    public: // Functions
        TSoftClassPtr<UClass>   GetPresetClass(); // 0x0E4087A6 [RequiredAPI | Native | Event | Public | BlueprintCallable | BlueprintEvent | BlueprintPure | Const]
        void                    HandleAnimInstance(UAnimInstance* Instance); // 0x05226FE4 [RequiredAPI | Native | Event | Public | BlueprintCallable | BlueprintEvent | Const]
    };
    // Size: 0x000640 (0x0003E0)
    class alignas(0x8) UNPCRetargetAnimInstance : public UAnimInstance
    {
    public:
        FAnimNode_RetargetPoseFromMesh  RetargetNode;                   // 0x000260 (0x0003D8)
        uint8                           UnknownData_000638[0x000008];   // 0x000638 (0x000008)
    };
    // Size: 0x000490 (0x000010)
    struct FNPCRetargetAnimInstanceProxy : public FAnimInstanceProxy
    {
        uint8   UnknownData_000480[0x000010];   // 0x000480 (0x000010)
    };
}

