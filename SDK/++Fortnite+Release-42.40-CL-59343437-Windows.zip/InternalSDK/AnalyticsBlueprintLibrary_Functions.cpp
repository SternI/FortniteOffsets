/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnalyticsBlueprintLibrary_Functions
 * ============================================================
 */

#include "AnalyticsBlueprintLibrary_Functions.hpp"

namespace UE
{

    void UAnalyticsBlueprintLibrary::EndSession()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.EndSession");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAnalyticsBlueprintLibrary::FlushEvents()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.FlushEvents");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    FString UAnalyticsBlueprintLibrary::GetSessionId()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.GetSessionId");
    
        UAnalyticsBlueprintLibrary___GetSessionId_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FString UAnalyticsBlueprintLibrary::GetUserId()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.GetUserId");
    
        UAnalyticsBlueprintLibrary___GetUserId_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FAnalyticsEventAttr UAnalyticsBlueprintLibrary::MakeEventAttribute(FString AttributeName, FString AttributeValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.MakeEventAttribute");
    
        UAnalyticsBlueprintLibrary___MakeEventAttribute_Params Params{};
        Params.AttributeName = AttributeName;
        Params.AttributeValue = AttributeValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAnalyticsBlueprintLibrary::RecordCurrencyGiven(FString GameCurrencyType, int32 GameCurrencyAmount)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordCurrencyGiven");
    
        UAnalyticsBlueprintLibrary___RecordCurrencyGiven_Params Params{};
        Params.GameCurrencyType = GameCurrencyType;
        Params.GameCurrencyAmount = GameCurrencyAmount;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAnalyticsBlueprintLibrary::RecordCurrencyGivenWithAttributes(FString GameCurrencyType, int32 GameCurrencyAmount, TArray<FAnalyticsEventAttr>& Attributes)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordCurrencyGivenWithAttributes");
    
        UAnalyticsBlueprintLibrary___RecordCurrencyGivenWithAttributes_Params Params{};
        Params.GameCurrencyType = GameCurrencyType;
        Params.GameCurrencyAmount = GameCurrencyAmount;
        Params.Attributes = Attributes;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Attributes = Params.Attributes;
    }

    void UAnalyticsBlueprintLibrary::RecordCurrencyPurchase(FString GameCurrencyType, int32 GameCurrencyAmount, FString RealCurrencyType, float RealMoneyCost, FString PaymentProvider)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordCurrencyPurchase");
    
        UAnalyticsBlueprintLibrary___RecordCurrencyPurchase_Params Params{};
        Params.GameCurrencyType = GameCurrencyType;
        Params.GameCurrencyAmount = GameCurrencyAmount;
        Params.RealCurrencyType = RealCurrencyType;
        Params.RealMoneyCost = RealMoneyCost;
        Params.PaymentProvider = PaymentProvider;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAnalyticsBlueprintLibrary::RecordError(FString Error)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordError");
    
        UAnalyticsBlueprintLibrary___RecordError_Params Params{};
        Params.Error = Error;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAnalyticsBlueprintLibrary::RecordErrorWithAttributes(FString Error, TArray<FAnalyticsEventAttr>& Attributes)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordErrorWithAttributes");
    
        UAnalyticsBlueprintLibrary___RecordErrorWithAttributes_Params Params{};
        Params.Error = Error;
        Params.Attributes = Attributes;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Attributes = Params.Attributes;
    }

    void UAnalyticsBlueprintLibrary::RecordEvent(FString EventName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordEvent");
    
        UAnalyticsBlueprintLibrary___RecordEvent_Params Params{};
        Params.EventName = EventName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAnalyticsBlueprintLibrary::RecordEventWithAttribute(FString EventName, FString AttributeName, FString AttributeValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordEventWithAttribute");
    
        UAnalyticsBlueprintLibrary___RecordEventWithAttribute_Params Params{};
        Params.EventName = EventName;
        Params.AttributeName = AttributeName;
        Params.AttributeValue = AttributeValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAnalyticsBlueprintLibrary::RecordEventWithAttributes(FString EventName, TArray<FAnalyticsEventAttr>& Attributes)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordEventWithAttributes");
    
        UAnalyticsBlueprintLibrary___RecordEventWithAttributes_Params Params{};
        Params.EventName = EventName;
        Params.Attributes = Attributes;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Attributes = Params.Attributes;
    }

    void UAnalyticsBlueprintLibrary::RecordItemPurchase(FString ItemID, FString Currency, int32 PerItemCost, int32 ItemQuantity)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordItemPurchase");
    
        UAnalyticsBlueprintLibrary___RecordItemPurchase_Params Params{};
        Params.ItemID = ItemID;
        Params.Currency = Currency;
        Params.PerItemCost = PerItemCost;
        Params.ItemQuantity = ItemQuantity;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAnalyticsBlueprintLibrary::RecordProgress(FString ProgressType, FString ProgressName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordProgress");
    
        UAnalyticsBlueprintLibrary___RecordProgress_Params Params{};
        Params.ProgressType = ProgressType;
        Params.ProgressName = ProgressName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAnalyticsBlueprintLibrary::RecordProgressWithAttributes(FString ProgressType, FString ProgressName, TArray<FAnalyticsEventAttr>& Attributes)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordProgressWithAttributes");
    
        UAnalyticsBlueprintLibrary___RecordProgressWithAttributes_Params Params{};
        Params.ProgressType = ProgressType;
        Params.ProgressName = ProgressName;
        Params.Attributes = Attributes;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Attributes = Params.Attributes;
    }

    void UAnalyticsBlueprintLibrary::RecordProgressWithFullHierarchyAndAttributes(FString ProgressType, TArray<FString>& ProgressNames, TArray<FAnalyticsEventAttr>& Attributes)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordProgressWithFullHierarchyAndAttributes");
    
        UAnalyticsBlueprintLibrary___RecordProgressWithFullHierarchyAndAttributes_Params Params{};
        Params.ProgressType = ProgressType;
        Params.ProgressNames = ProgressNames;
        Params.Attributes = Attributes;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ProgressNames = Params.ProgressNames;
        Attributes = Params.Attributes;
    }

    void UAnalyticsBlueprintLibrary::RecordSimpleCurrencyPurchase(FString GameCurrencyType, int32 GameCurrencyAmount)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleCurrencyPurchase");
    
        UAnalyticsBlueprintLibrary___RecordSimpleCurrencyPurchase_Params Params{};
        Params.GameCurrencyType = GameCurrencyType;
        Params.GameCurrencyAmount = GameCurrencyAmount;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAnalyticsBlueprintLibrary::RecordSimpleCurrencyPurchaseWithAttributes(FString GameCurrencyType, int32 GameCurrencyAmount, TArray<FAnalyticsEventAttr>& Attributes)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleCurrencyPurchaseWithAttributes");
    
        UAnalyticsBlueprintLibrary___RecordSimpleCurrencyPurchaseWithAttributes_Params Params{};
        Params.GameCurrencyType = GameCurrencyType;
        Params.GameCurrencyAmount = GameCurrencyAmount;
        Params.Attributes = Attributes;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Attributes = Params.Attributes;
    }

    void UAnalyticsBlueprintLibrary::RecordSimpleItemPurchase(FString ItemID, int32 ItemQuantity)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleItemPurchase");
    
        UAnalyticsBlueprintLibrary___RecordSimpleItemPurchase_Params Params{};
        Params.ItemID = ItemID;
        Params.ItemQuantity = ItemQuantity;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAnalyticsBlueprintLibrary::RecordSimpleItemPurchaseWithAttributes(FString ItemID, int32 ItemQuantity, TArray<FAnalyticsEventAttr>& Attributes)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.RecordSimpleItemPurchaseWithAttributes");
    
        UAnalyticsBlueprintLibrary___RecordSimpleItemPurchaseWithAttributes_Params Params{};
        Params.ItemID = ItemID;
        Params.ItemQuantity = ItemQuantity;
        Params.Attributes = Attributes;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Attributes = Params.Attributes;
    }

    void UAnalyticsBlueprintLibrary::SetAge(int32 Age)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetAge");
    
        UAnalyticsBlueprintLibrary___SetAge_Params Params{};
        Params.Age = Age;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAnalyticsBlueprintLibrary::SetBuildInfo(FString BuildInfo)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetBuildInfo");
    
        UAnalyticsBlueprintLibrary___SetBuildInfo_Params Params{};
        Params.BuildInfo = BuildInfo;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAnalyticsBlueprintLibrary::SetGender(FString Gender)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetGender");
    
        UAnalyticsBlueprintLibrary___SetGender_Params Params{};
        Params.Gender = Gender;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAnalyticsBlueprintLibrary::SetLocation(FString Location)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetLocation");
    
        UAnalyticsBlueprintLibrary___SetLocation_Params Params{};
        Params.Location = Location;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAnalyticsBlueprintLibrary::SetSessionId(FString SessionID)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetSessionId");
    
        UAnalyticsBlueprintLibrary___SetSessionId_Params Params{};
        Params.SessionID = SessionID;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAnalyticsBlueprintLibrary::SetUserId(FString UserId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.SetUserId");
    
        UAnalyticsBlueprintLibrary___SetUserId_Params Params{};
        Params.UserId = UserId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UAnalyticsBlueprintLibrary::StartSession()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.StartSession");
    
        UAnalyticsBlueprintLibrary___StartSession_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAnalyticsBlueprintLibrary::StartSessionWithAttributes(TArray<FAnalyticsEventAttr>& Attributes)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnalyticsBlueprintLibrary.AnalyticsBlueprintLibrary.StartSessionWithAttributes");
    
        UAnalyticsBlueprintLibrary___StartSessionWithAttributes_Params Params{};
        Params.Attributes = Attributes;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Attributes = Params.Attributes;
    
        return Params.ReturnValue;
    }

} // namespace UE

