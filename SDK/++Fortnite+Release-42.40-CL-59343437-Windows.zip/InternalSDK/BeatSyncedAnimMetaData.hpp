/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BeatSyncedAnimMetaData
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000068 (0x000040)
    class alignas(0x8) UBeatSyncedAnimMetaData : public UAnimMetaData
    {
    public:
        EBeatAlignment              BeatAlignment;                  // 0x000028 (0x000001) [Default: EBeatAlignment(1)]
        uint8                       UnknownData_000029[0x000003];   // 0x000029 (0x000003)
        float                       BeatB;                          // 0x00002C (0x000004) [Default: -1f]
        float                       Bpm;                            // 0x000030 (0x000004) [Default: -1f]
        float                       FirstBeatAtFrame;               // 0x000034 (0x000004) [Default: 0f]
        EBeatNumber                 PivotBeat;                      // 0x000038 (0x000001) [Default: EBeatNumber(0)]
        uint8                       UnknownData_000039[0x000003];   // 0x000039 (0x000003)
        float                       TransitionBias;                 // 0x00003C (0x000004) [Default: 1f]
        bool                        bAllowDoublingHalving;          // 0x000040 (0x000001) [Default: true]
        bool                        bLoopFromPivot;                 // 0x000041 (0x000001) [Default: false]
        uint8                       UnknownData_000042[0x000006];   // 0x000042 (0x000006)
        TArray<UAnimSequenceBase*>  TempoVariants;                  // 0x000048 (0x000010)
        TArray<FBeatTrackEntry>     BeatTrack;                      // 0x000058 (0x000010)
    };
    // Size: 0x000070 (0x000008)
    class UBeatSyncedEmoteMetaData : public UBeatSyncedAnimMetaData
    {
    public:
        bool    bOverrideGroupEmoteBeatsyncingBehavior; // 0x000068 (0x000001) [Default: false]
        bool    bAllowGroupEmoteLeaderToBeatSync;       // 0x000069 (0x000001) [Default: false]
        bool    bAllowGroupEmoteFollowerToBeatSync;     // 0x00006A (0x000001) [Default: false]
        uint8   UnknownData_00006B[0x000005];           // 0x00006B (0x000005)
    };
    // Size: 0x000030 (0x000008)
    class alignas(0x4) UTimeScaledAnimMetaData : public UAnimMetaData
    {
    public:
        float   PlaybackScale;                  // 0x000028 (0x000004) [Default: 1f]
        uint8   UnknownData_00002C[0x000004];   // 0x00002C (0x000004)
    };
    // Size: 0x000028 (0x000010)
    struct alignas(0x8) FBeatSyncedAnimMusicClockSettings : public FMusicClockSettingsBase
    {
        TWeakObjectPtr<UAnimInstance>   AnimInstance;   // 0x000018 (0x000008)
        TWeakObjectPtr<UAnimMontage>    AnimMontage;    // 0x000020 (0x000008)
    };
    // Size: 0x000020 (0x000018)
    struct alignas(0x8) FBeatSyncedAnimMusicSourceSettings : public FMusicSourceSettings
    {
        UAnimInstance*  AnimInstance;       // 0x000008 (0x000008)
        UAnimMontage*   AnimMontage;        // 0x000010 (0x000008)
        int32           TimeSigNumerator;   // 0x000018 (0x000004)
        int32           TimeSigDenominator; // 0x00001C (0x000004)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FBeatTrackEntry
    {
        float   Seconds;    // 0x000000 (0x000004)
        float   Beat;       // 0x000004 (0x000004)
    };
}

