/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArcadeWeaponCoreUI_Functions
 * ============================================================
 */

#include "ArcadeWeaponCoreUI.hpp"

namespace UE
{

    struct UArcadeWeaponLeaderboardPlayerEntryVM___GetCurrentMatchScore_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344684752]
    };

    struct UArcadeWeaponLeaderboardPlayerEntryVM___GetHighScore_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344684752]
    };

    struct UArcadeWeaponLeaderboardPlayerEntryVM___GetName_Params
    {
        FText   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UArcadeWeaponLeaderboardPlayerEntryVM___GetRank_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344684752]
    };

    struct UArcadeWeaponLeaderboardVM___GetLeaderboardMode_Params
    {
        EArcadeWeaponLeaderboardMode    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EArcadeWeaponLeaderboardMode(16)]
    };

    struct UArcadeWeaponLeaderboardVM___ToggleLeaderboard_Params
    {
        EArcadeWeaponLeaderboardType    InLeaderboardType;  // 0x000000 (0x000001) [Default: EArcadeWeaponLeaderboardType(16)]
    };

} // namespace UE

