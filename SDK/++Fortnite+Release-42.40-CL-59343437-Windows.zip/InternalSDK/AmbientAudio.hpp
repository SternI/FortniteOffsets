/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AmbientAudio
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000278 (0x000008)
    class alignas(0x8) AAmbientAudioParameterActor : public AActor
    {
    public:
        UAudioParameterComponent*   Parameters; // 0x000270 (0x000008) [Default: 0x7FE83957AFD0]
    };
    // Size: 0x0000F8 (0x000030)
    class alignas(0x8) UAmbientAudioComponent : public UAudioGameplayComponent
    {
    public:
        void**                  VTable_0000C8;                  // 0x0000C8 (0x000008) VTable [83 slots] -> 0x134AFCF0
        UAmbientAudioDataAsset* AmbientAsset;                   // 0x0000D0 (0x000008) [Default: nullptr]
        int32                   Priority;                       // 0x0000D8 (0x000004) [Default: 0]
        float                   CrossfadeTime;                  // 0x0000DC (0x000004) [Default: 0.5f]
        FGuid                   AmbientGuid;                    // 0x0000E0 (0x000010)
        FName                   DisplayName;                    // 0x0000F0 (0x000004) [Default: NAME_None]
        uint8                   UnknownData_0000F4[0x000004];   // 0x0000F4 (0x000004)
    
    public: // Functions
        void    SetAmbientAsset(UAmbientAudioDataAsset* InAmbientAsset); // 0x055E642A [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetCrossfadeTime(float InCrossfadeTime); // 0x055E65C4 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetPriority(int32 InPriority); // 0x055E674E [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000040 (0x000018)
    class alignas(0x8) UAmbientAudioDataAsset : public UDataAsset
    {
    public:
        TArray<FInstancedStruct>    SoundArrays;                    // 0x000028 (0x000010)
        float                       TagCrossfadeTime;               // 0x000038 (0x000004) [Default: 10f]
        uint8                       UnknownData_00003C[0x000004];   // 0x00003C (0x000004)
    };
    // Size: 0x000100 (0x0000C8)
    class alignas(0x8) UAmbientAudioSubsystem : public UWorldSubsystem
    {
    public:
        void**                                                  VTable_000038;                  // 0x000038 (0x000008) VTable [9 slots] -> 0x134B02A0
        MULTI_INLINE_DELEGATE(AmbientAudioTagChangeSignature)   OnTagChanged;                   // 0x000040 (0x000010)
        MULTI_INLINE_DELEGATE(AmbientAudioEntryChangeSignature) OnEntryChanged;                 // 0x000050 (0x000010)
        TArray<UAmbientAudioComponent*>                         AmbientComponents;              // 0x000060 (0x000010)
        AAmbientAudioParameterActor*                            ParameterActor;                 // 0x000070 (0x000008) [Default: nullptr]
        uint8                                                   UnknownData_000078[0x000088];   // 0x000078 (0x000088)
    
    public: // Functions
        void                        AddAmbientEntry(FName AmbientName, UAmbientAudioDataAsset* Asset, int32 Priority, float CrossfadeTime); // 0x055E68CE [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        AddGameplayTag(FGameplayTag GameplayTag); // 0x055E6D82 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        UAudioParameterComponent*   GetAudioParameterComponent(); // 0x0E3E9ADE [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        RemoveAmbientEntry(FName AmbientName, float CrossfadeOverride); // 0x055E6F28 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        RemoveGameplayTag(FGameplayTag GameplayTag); // 0x055E71AC [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000078 (0x000078)
    struct alignas(0x8) FAmbientAudioBase
    {
        uint8                       UnknownData_000000[0x000008];   // 0x000000 (0x000008)
        TSoftObjectPtr<USoundBase>  Sound;                          // 0x000008 (0x000020) [Default: 0x1545E848]
        FAudioGameplayRequirements  PlaybackRequirements;           // 0x000028 (0x000050)
    };
    // Size: 0x000078 (0x000000)
    struct FAmbientAudioLoop : public FAmbientAudioBase
    {
    };
    // Size: 0x000098 (0x000020)
    struct alignas(0x8) FAmbientAudioOneShot : public FAmbientAudioBase
    {
        FVector2D   RetriggerTimeRange;     // 0x000078 (0x000010)
        FVector2D   TriggerDistanceRange;   // 0x000088 (0x000010)
    };
    // Size: 0x000008 (0x000008)
    struct FArrayAmbientAudioBase
    {
        uint8   UnknownData_000000[0x000008];   // 0x000000 (0x000008)
    };
    // Size: 0x000018 (0x000010)
    struct alignas(0x8) FArrayAmbientAudioLoop : public FArrayAmbientAudioBase
    {
        TArray<FAmbientAudioLoop>   Sounds; // 0x000008 (0x000010)
    };
    // Size: 0x000018 (0x000010)
    struct alignas(0x8) FArrayAmbientAudioOneShot : public FArrayAmbientAudioBase
    {
        TArray<FAmbientAudioOneShot>    Sounds; // 0x000008 (0x000010)
    };
}

