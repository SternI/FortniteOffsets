/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioSynesthesia_Functions
 * ============================================================
 */

#include "AudioSynesthesia_Functions.hpp"

namespace UE
{

    void UConstantQAnalyzer::GetCenterFrequencies(TArray<float>& OutCenterFrequencies)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.ConstantQAnalyzer.GetCenterFrequencies");
    
        UConstantQAnalyzer___GetCenterFrequencies_Params Params{};
        Params.OutCenterFrequencies = OutCenterFrequencies;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutCenterFrequencies = Params.OutCenterFrequencies;
    }

    int32 UConstantQAnalyzer::GetNumCenterFrequencies()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.ConstantQAnalyzer.GetNumCenterFrequencies");
    
        UConstantQAnalyzer___GetNumCenterFrequencies_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UConstantQNRT::GetChannelConstantQAtTime(float InSeconds, int32 InChannel, TArray<float>& OutConstantQ)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.ConstantQNRT.GetChannelConstantQAtTime");
    
        UConstantQNRT___GetChannelConstantQAtTime_Params Params{};
        Params.InSeconds = InSeconds;
        Params.InChannel = InChannel;
        Params.OutConstantQ = OutConstantQ;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutConstantQ = Params.OutConstantQ;
    }

    void UConstantQNRT::GetNormalizedChannelConstantQAtTime(float InSeconds, int32 InChannel, TArray<float>& OutConstantQ)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.ConstantQNRT.GetNormalizedChannelConstantQAtTime");
    
        UConstantQNRT___GetNormalizedChannelConstantQAtTime_Params Params{};
        Params.InSeconds = InSeconds;
        Params.InChannel = InChannel;
        Params.OutConstantQ = OutConstantQ;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutConstantQ = Params.OutConstantQ;
    }

    void ULKFSNRT::GetChannelLoudnessAtTime(float InSeconds, int32 InChannel, float& OutLoudness)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.LKFSNRT.GetChannelLoudnessAtTime");
    
        ULKFSNRT___GetChannelLoudnessAtTime_Params Params{};
        Params.InSeconds = InSeconds;
        Params.InChannel = InChannel;
        Params.OutLoudness = OutLoudness;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutLoudness = Params.OutLoudness;
    }

    float ULKFSNRT::GetGatedLoudness()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.LKFSNRT.GetGatedLoudness");
    
        ULKFSNRT___GetGatedLoudness_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float ULKFSNRT::GetGatedLoudnessForChannel(int32 InChannel)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.LKFSNRT.GetGatedLoudnessForChannel");
    
        ULKFSNRT___GetGatedLoudnessForChannel_Params Params{};
        Params.InChannel = InChannel;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float ULKFSNRT::GetIntegratedLoudness()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.LKFSNRT.GetIntegratedLoudness");
    
        ULKFSNRT___GetIntegratedLoudness_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float ULKFSNRT::GetIntegratedLoudnessForChannel(int32 InChannel)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.LKFSNRT.GetIntegratedLoudnessForChannel");
    
        ULKFSNRT___GetIntegratedLoudnessForChannel_Params Params{};
        Params.InChannel = InChannel;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void ULKFSNRT::GetLoudnessAtTime(float InSeconds, float& OutLoudness)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.LKFSNRT.GetLoudnessAtTime");
    
        ULKFSNRT___GetLoudnessAtTime_Params Params{};
        Params.InSeconds = InSeconds;
        Params.OutLoudness = OutLoudness;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutLoudness = Params.OutLoudness;
    }

    TArray<FLKFSNRTResults> ULKFSNRT::GetLoudnessData()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.LKFSNRT.GetLoudnessData");
    
        ULKFSNRT___GetLoudnessData_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FLKFSNRTResults ULKFSNRT::GetLoudnessDataAtTime(float InSeconds)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.LKFSNRT.GetLoudnessDataAtTime");
    
        ULKFSNRT___GetLoudnessDataAtTime_Params Params{};
        Params.InSeconds = InSeconds;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FLKFSNRTResults> ULKFSNRT::GetLoudnessDataForChannel(int32 InChannel)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.LKFSNRT.GetLoudnessDataForChannel");
    
        ULKFSNRT___GetLoudnessDataForChannel_Params Params{};
        Params.InChannel = InChannel;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FLKFSNRTResults ULKFSNRT::GetLoudnessDataForChannelAtTime(float InSeconds, int32 InChannel)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.LKFSNRT.GetLoudnessDataForChannelAtTime");
    
        ULKFSNRT___GetLoudnessDataForChannelAtTime_Params Params{};
        Params.InSeconds = InSeconds;
        Params.InChannel = InChannel;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void ULoudnessNRT::GetChannelLoudnessAtTime(float InSeconds, int32 InChannel, float& OutLoudness)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.LoudnessNRT.GetChannelLoudnessAtTime");
    
        ULoudnessNRT___GetChannelLoudnessAtTime_Params Params{};
        Params.InSeconds = InSeconds;
        Params.InChannel = InChannel;
        Params.OutLoudness = OutLoudness;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutLoudness = Params.OutLoudness;
    }

    void ULoudnessNRT::GetLoudnessAtTime(float InSeconds, float& OutLoudness)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.LoudnessNRT.GetLoudnessAtTime");
    
        ULoudnessNRT___GetLoudnessAtTime_Params Params{};
        Params.InSeconds = InSeconds;
        Params.OutLoudness = OutLoudness;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutLoudness = Params.OutLoudness;
    }

    void ULoudnessNRT::GetNormalizedChannelLoudnessAtTime(float InSeconds, int32 InChannel, float& OutLoudness)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.LoudnessNRT.GetNormalizedChannelLoudnessAtTime");
    
        ULoudnessNRT___GetNormalizedChannelLoudnessAtTime_Params Params{};
        Params.InSeconds = InSeconds;
        Params.InChannel = InChannel;
        Params.OutLoudness = OutLoudness;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutLoudness = Params.OutLoudness;
    }

    void ULoudnessNRT::GetNormalizedLoudnessAtTime(float InSeconds, float& OutLoudness)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.LoudnessNRT.GetNormalizedLoudnessAtTime");
    
        ULoudnessNRT___GetNormalizedLoudnessAtTime_Params Params{};
        Params.InSeconds = InSeconds;
        Params.OutLoudness = OutLoudness;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutLoudness = Params.OutLoudness;
    }

    void UOnsetNRT::GetChannelOnsetsBetweenTimes(float InStartSeconds, float InEndSeconds, int32 InChannel, TArray<float>& OutOnsetTimestamps, TArray<float>& OutOnsetStrengths)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.OnsetNRT.GetChannelOnsetsBetweenTimes");
    
        UOnsetNRT___GetChannelOnsetsBetweenTimes_Params Params{};
        Params.InStartSeconds = InStartSeconds;
        Params.InEndSeconds = InEndSeconds;
        Params.InChannel = InChannel;
        Params.OutOnsetTimestamps = OutOnsetTimestamps;
        Params.OutOnsetStrengths = OutOnsetStrengths;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutOnsetTimestamps = Params.OutOnsetTimestamps;
        OutOnsetStrengths = Params.OutOnsetStrengths;
    }

    void UOnsetNRT::GetNormalizedChannelOnsetsBetweenTimes(float InStartSeconds, float InEndSeconds, int32 InChannel, TArray<float>& OutOnsetTimestamps, TArray<float>& OutOnsetStrengths)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.OnsetNRT.GetNormalizedChannelOnsetsBetweenTimes");
    
        UOnsetNRT___GetNormalizedChannelOnsetsBetweenTimes_Params Params{};
        Params.InStartSeconds = InStartSeconds;
        Params.InEndSeconds = InEndSeconds;
        Params.InChannel = InChannel;
        Params.OutOnsetTimestamps = OutOnsetTimestamps;
        Params.OutOnsetStrengths = OutOnsetStrengths;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutOnsetTimestamps = Params.OutOnsetTimestamps;
        OutOnsetStrengths = Params.OutOnsetStrengths;
    }

    void USynesthesiaSpectrumAnalyzer::GetCenterFrequencies(float InSampleRate, TArray<float>& OutCenterFrequencies)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.SynesthesiaSpectrumAnalyzer.GetCenterFrequencies");
    
        USynesthesiaSpectrumAnalyzer___GetCenterFrequencies_Params Params{};
        Params.InSampleRate = InSampleRate;
        Params.OutCenterFrequencies = OutCenterFrequencies;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutCenterFrequencies = Params.OutCenterFrequencies;
    }

    int32 USynesthesiaSpectrumAnalyzer::GetNumCenterFrequencies()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioSynesthesia.SynesthesiaSpectrumAnalyzer.GetNumCenterFrequencies");
    
        USynesthesiaSpectrumAnalyzer___GetNumCenterFrequencies_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

} // namespace UE

