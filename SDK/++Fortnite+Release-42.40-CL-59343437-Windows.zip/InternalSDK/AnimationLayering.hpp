/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimationLayering
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000038 (0x000010)
    class alignas(0x8) UBoneMaskDefinitionDataAsset : public UDataAsset
    {
    public:
        FBoneMaskDefinition BoneMaskDefinition; // 0x000028 (0x000010)
    };
    // Size: 0x0000D8 (0x0000C8)
    struct alignas(0x8) FAnimNode_BoneMask : public FAnimNode_Base
    {
        FPoseLink                               BasePose;                       // 0x000010 (0x000010)
        TArray<FPoseLink>                       BlendPoses;                     // 0x000020 (0x000010)
        TArray<float>                           BlendWeights;                   // 0x000030 (0x000010)
        FBoneMask                               BoneMask;                       // 0x000040 (0x000010)
        UBoneMaskDefinitionDataAsset*           BoneMaskDefinitionDataAsset;    // 0x000050 (0x000008)
        TArray<FBoneMaskBodyPartNameContainer>  BodyParts;                      // 0x000058 (0x000010)
        TEnumAsByte<ECurveBlendOption>          CurveBlendOption;               // 0x000068 (0x000001)
        bool                                    bProcessMeshSpaceAsRootSpace;   // 0x000069 (0x000001)
        uint8                                   UnknownData_00006A[0x000002];   // 0x00006A (0x000002)
        int32                                   LODThreshold;                   // 0x00006C (0x000004)
        bool                                    bUpdateSkeletonDataOnDemand;    // 0x000070 (0x000001)
        uint8                                   UnknownData_000071[0x000067];   // 0x000071 (0x000067)
    };
    // Size: 0x000128 (0x000060)
    struct alignas(0x8) FAnimNode_CopyBoneAdvanced : public FAnimNode_SkeletalControlBase
    {
        FBoneReference                  SourceBone;                     // 0x0000C8 (0x00000C)
        FBoneReference                  TargetBone;                     // 0x0000D4 (0x00000C)
        FVector                         TranslationWeight;              // 0x0000E0 (0x000018)
        float                           RotationWeight;                 // 0x0000F8 (0x000004) [Default: 2.62071e-25f]
        float                           ScaleWeight;                    // 0x0000FC (0x000004) [Default: 0f]
        TEnumAsByte<EBoneControlSpace>  ControlSpace;                   // 0x000100 (0x000001) [Default: 208]
        uint8                           UnknownData_000101[0x000003];   // 0x000101 (0x000003)
        FBoneReference                  TranslationSpaceBone;           // 0x000104 (0x00000C)
        bool                            bTranslationInCustomBoneSpace;  // 0x000110 (0x000001) [Default: false]
        bool                            bPropagateToChildren;           // 0x000111 (0x000001) [Default: false]
        uint8                           UnknownData_000112[0x000016];   // 0x000112 (0x000016)
    };
    // Size: 0x000260 (0x000198)
    struct alignas(0x8) FAnimNode_CopyBoneMotion : public FAnimNode_SkeletalControlBase
    {
        FComponentSpacePoseLink     BasePose;                       // 0x0000C8 (0x000010)
        FComponentSpacePoseLink     BasePoseReference;              // 0x0000D8 (0x000010)
        bool                        bUseBasePose;                   // 0x0000E8 (0x000001)
        uint8                       UnknownData_0000E9[0x000003];   // 0x0000E9 (0x000003)
        FName                       PoseHistoryTag;                 // 0x0000EC (0x000004)
        float                       Delay;                          // 0x0000F0 (0x000004)
        FBoneReference              SourceBone;                     // 0x0000F4 (0x00000C)
        FBoneReference              BoneToModify;                   // 0x000100 (0x00000C)
        FBoneReference              CopySpace;                      // 0x00010C (0x00000C)
        bool                        bUseRootSpace;                  // 0x000118 (0x000001)
        uint8                       UnknownData_000119[0x000003];   // 0x000119 (0x000003)
        FBoneReference              ApplySpace;                     // 0x00011C (0x00000C)
        FRotator                    TranslationOffset;              // 0x000128 (0x000018)
        FRotator                    RotationOffset;                 // 0x000140 (0x000018)
        FVector                     RotationPivot;                  // 0x000158 (0x000018)
        FName                       CurvePrefix;                    // 0x000170 (0x000004)
        FName                       TargetCurveName;                // 0x000174 (0x000004)
        float                       TargetCurveScale;               // 0x000178 (0x000004)
        ECopyBoneMotion_Component   TargetCurveComponent;           // 0x00017C (0x000001)
        TEnumAsByte<EAxis>          TargetCurveRotationAxis;        // 0x00017D (0x000001)
        uint8                       UnknownData_00017E[0x000002];   // 0x00017E (0x000002)
        FName                       TranslationX_CurveName;         // 0x000180 (0x000004)
        FName                       TranslationY_CurveName;         // 0x000184 (0x000004)
        FName                       TranslationZ_CurveName;         // 0x000188 (0x000004)
        FName                       RotationRoll_CurveName;         // 0x00018C (0x000004)
        FName                       RotationPitch_CurveName;        // 0x000190 (0x000004)
        FName                       RotationYaw_CurveName;          // 0x000194 (0x000004)
        FVector                     TranslationScale;               // 0x000198 (0x000018)
        float                       TranslationSmoothingTime;       // 0x0001B0 (0x000004)
        uint8                       UnknownData_0001B4[0x000004];   // 0x0001B4 (0x000004)
        UCurveVector*               TranslationRemapCurve;          // 0x0001B8 (0x000008)
        float                       RotationScale;                  // 0x0001C0 (0x000004)
        float                       RotationSmoothingTime;          // 0x0001C4 (0x000004)
        UCurveFloat*                RotationRemapCurve;             // 0x0001C8 (0x000008)
        bool                        bDeltaSmoothing;                // 0x0001D0 (0x000001)
        uint8                       UnknownData_0001D1[0x00008F];   // 0x0001D1 (0x00008F)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FBoneMask
    {
        TMap<FName, FBoneMaskEntry> BoneMaskMap;    // 0x000000 (0x000010)
    };
    // Size: 0x000038 (0x000038)
    struct alignas(0x8) FBoneMaskBodyPartDefinition
    {
        FName                           Name;                           // 0x000000 (0x000004)
        uint8                           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FBranchFilter>           BranchFilters;                  // 0x000008 (0x000010)
        TArray<FBoneMaskPerBoneData>    SkeletonPoseBoneWeights;        // 0x000018 (0x000010)
        TArray<int32>                   SkeletonPoseChildBoneIndices;   // 0x000028 (0x000010)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FBoneMaskBodyPartNameContainer
    {
        TArray<FName>   Names;  // 0x000000 (0x000010)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FBoneMaskDefinition
    {
        TArray<FBoneMaskBodyPartDefinition> BodyPartDefinitions;    // 0x000000 (0x000010)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FBoneMaskEntry
    {
        float   LocalSpaceWeight;   // 0x000000 (0x000004)
        float   MeshSpaceWeight;    // 0x000004 (0x000004)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FBoneMaskPerBoneData
    {
        int32   SkeletonPoseBoneIndex;  // 0x000000 (0x000004)
        float   BlendWeight;            // 0x000004 (0x000004)
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FBoneMaskUpdateMultiParam
    {
        FName   Name;               // 0x000000 (0x000004) [Default: FName(1029) -> L""]
        float   LocalSpaceWeight;   // 0x000004 (0x000004) [Default: 0f]
        float   MeshSpaceWeight;    // 0x000008 (0x000004) [Default: 0f]
    };
}

