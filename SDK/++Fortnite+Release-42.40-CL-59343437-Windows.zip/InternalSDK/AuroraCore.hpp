/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AuroraCore
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000068 (0x000038)
    class alignas(0x8) UAuroraCoreSubsystem : public UGameInstanceSubsystem
    {
    public:
        FString     PurchaseInterfaceClassName;     // 0x000030 (0x000010) [Default: L"/Script/AuroraPurchaseNullFortnite.AuroraPurchaseNullFortnite"]
        UClass*     PurchaseInterfaceClassOverride; // 0x000040 (0x000008) [Default: nullptr]
        UObject*    PurchaseInterface;              // 0x000048 (0x000008) [Default: nullptr]
        uint8       UnknownData_000050[0x000018];   // 0x000050 (0x000018)
    };
    // Size: 0x0001F0 (0x000130)
    class alignas(0x8) UAuroraPlayerControllerComponent : public UControllerComponent
    {
    public:
        uint8                           UnknownData_0000C0[0x000078];   // 0x0000C0 (0x000078)
        UClass*                         PurchaseImplementationClass;    // 0x000138 (0x000008) [Default: nullptr]
        FAuroraEntitlementQuantities    OwnedEntitlementQuantities;     // 0x000140 (0x000080)
        uint8                           UnknownData_0001C0[0x000030];   // 0x0001C0 (0x000030)
    
    public: // Functions
        void                    BP_CloseOffersDialog(bool bForce); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void                    BP_OnFinalizedPurchaseResult(FInstancedStruct& InReceipt, bool bSuccessful); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
        void                    BP_OnIntentPurchaseOfferFailed(FGuid& InOfferInstanceId); // 0x000545D2 [Event | Protected | HasOutParms | HasDefaults | BlueprintEvent]
        void                    BP_OnOwnedProductQuantitiesChanged(TMap<FString, int64>& InOwnedProductQuantities); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
        void                    BP_OnPurchasedInvoice(FInstancedStruct& InInvoice, bool bSuccessful, FInstancedStruct& InReceipt, FString InErrorCode); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
        void                    BP_ShowOffersDialog(FGuid& InCatalogId, TArray<FInstancedStruct>& InOffers, FText& InTitle); // 0x000545D2 [RequiredAPI | Event | Protected | HasOutParms | HasDefaults | BlueprintEvent]
        void                    BP_StartPurchaseInvoice(FInstancedStruct& InInvoice, bool bInSuccessful, FString InErrorCode); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
        void                    BP_StartPurchaseInvoiceOfferQueried(FInstancedStruct& InInvoice, bool bSuccessful, FInstancedStruct& InOffer); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
        void                    CancelOfferPurchase(); // 0x0E498566 [Final | Native | Public | BlueprintCallable]
        void                    ClientCloseIndividualOfferDialog(); // 0x0E49857C [RequiredAPI | Net | NetReliable | Native | Event | Public | NetClient]
        void                    ClientCloseOffersDialog(FGuid InCatalogId, bool bForce); // 0x056BB4EC [RequiredAPI | Net | NetReliable | Native | Event | Public | HasDefaults | NetClient]
        void                    ClientFinalizePurchaseResult(FInstancedStruct InReceipt, bool bSuccessful); // 0x056BB778 [Net | NetReliable | Native | Event | Protected | NetClient]
        void                    ClientIntentPurchaseOfferFailed(FGuid InOfferInstanceId); // 0x056BBA5E [Net | NetReliable | Native | Event | Protected | HasDefaults | NetClient]
        void                    ClientShowOffersDialog(FGuid InCatalogId, TArray<FInstancedStruct> InOffers, FText InTitle); // 0x056BBBD2 [RequiredAPI | Net | NetReliable | Native | Event | Public | HasDefaults | NetClient]
        void                    ClientStartPurchaseInvoice(FInstancedStruct InInvoice, bool bInSuccessful, FString InErrorCode); // 0x056BC1C4 [Net | NetReliable | Native | Event | Protected | NetClient]
        void                    CloseOffersDialog(FGuid& InCatalogId, bool bForce); // 0x056BC5C2 [RequiredAPI | BlueprintCosmetic | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        TMap<FString, int64>    GetOwnedProductQuantities(); // 0x0E498CA4 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        void                    OnRep_PurchaseImplementationClass(); // 0x0E498CC4 [Final | Native | Protected]
        void                    PurchaseInvoice(FInstancedStruct& InInvoice); // 0x056BC860 [Final | BlueprintCosmetic | Native | Protected | HasOutParms | BlueprintCallable]
        void                    ServerCancelOfferPurchase(); // 0x0E498566 [Net | NetReliable | Native | Event | Public | NetServer]
        void                    ServerIntentPurchaseOffer(FGuid InOfferInstanceId); // 0x056BCA34 [Net | NetReliable | Native | Event | Public | NetServer | HasDefaults | BlueprintCallable]
        void                    ServerOnCloseOffersDialog(); // 0x0E498EF4 [Net | NetReliable | Native | Event | Public | NetServer | BlueprintCallable]
        void                    ServerUploadReceipt(FInstancedStruct InReceipt); // 0x056BD476 [Net | NetReliable | Native | Event | Protected | NetServer]
        void                    ShowOffersDialog(FGuid& InCatalogId, TArray<FInstancedStruct>& InOffers, FText& InTitle); // 0x056BD63C [RequiredAPI | BlueprintCosmetic | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000070 (0x000040)
    class alignas(0x8) UAuroraProjectSettings : public UDeveloperSettings
    {
    public:
        TMap<FSoftClassPath, TSoftObjectPtr<UScriptStruct>> PricingTypeTranslation;                     // 0x000030 (0x000010)
        TMap<FString, FString>                              PlatformToPlatformFamilyMappings;           // 0x000040 (0x000010)
        TMap<FString, FString>                              ExternalLoginTypeToPlatformFamilyMappings;  // 0x000050 (0x000010)
        bool                                                bUseArtificialDelay;                        // 0x000060 (0x000001) [Default: true]
        uint8                                               UnknownData_000061[0x000003];               // 0x000061 (0x000003)
        FVector2f                                           ArtificialDelayRange;                       // 0x000064 (0x000008)
        uint8                                               UnknownData_00006C[0x000004];               // 0x00006C (0x000004)
    };
    // Size: 0x000028 (0x000000)
    class IAuroraPurchase : public IInterface
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class IAuroraPurchaseDebug : public IInterface
    {
    public:
    };
    // Size: 0x000100 (0x000010)
    struct alignas(0x8) FAuroraBundleOffer : public FAuroraOffer
    {
        TArray<FAuroraBundleOfferPair>  Offers; // 0x0000F0 (0x000010)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FAuroraBundleOfferPair
    {
        FInstancedStruct    offer;  // 0x000000 (0x000010)
        int64               Count;  // 0x000010 (0x000008)
    };
    // Size: 0x000090 (0x000090)
    struct alignas(0x8) FAuroraDescription
    {
        FLocalizableMessage Name;               // 0x000000 (0x000030)
        FLocalizableMessage ShortDescription;   // 0x000030 (0x000030)
        FLocalizableMessage Description;        // 0x000060 (0x000030)
    };
    // Size: 0x0000D0 (0x0000D0)
    struct alignas(0x8) FAuroraEntitlement
    {
        FString                     EntitlementIdentifier;          // 0x000000 (0x000010) [Default: L""]
        FAuroraDescription          EntitlementDescription;         // 0x000010 (0x000090)
        TSoftObjectPtr<UTexture2D>  Icon;                           // 0x0000A0 (0x000020) [Default: nullptr]
        int64                       MaxCount;                       // 0x0000C0 (0x000008) [Default: 4295024641ll]
        bool                        bConsumable;                    // 0x0000C8 (0x000001) [Default: true]
        bool                        bPaidRandomItem;                // 0x0000C9 (0x000001) [Default: true]
        bool                        bPaidArea;                      // 0x0000CA (0x000001) [Default: true]
        bool                        bConsequentialToGameplay;       // 0x0000CB (0x000001) [Default: true]
        uint8                       UnknownData_0000CC[0x000004];   // 0x0000CC (0x000004)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FAuroraEntitlementChange
    {
        FString EntitlementIdentifier;  // 0x000000 (0x000010) [Default: L""]
        int64   Quantity;               // 0x000010 (0x000008) [Default: -2959115794157404095ll]
        int64   Change;                 // 0x000018 (0x000008) [Default: 379749280ll]
    };
    // Size: 0x0001C0 (0x0000D0)
    struct alignas(0x8) FAuroraEntitlementOffer : public FAuroraOffer
    {
        FAuroraEntitlement  EntitlementType;    // 0x0000F0 (0x0000D0)
    };
    // Size: 0x000080 (0x000038)
    struct alignas(0x8) FAuroraEntitlementQuantities : public FFastArraySerializer
    {
        TArray<FAuroraEntitlementQuantity>  EntitlementQuantities;          // 0x000048 (0x000010)
        uint8                               UnknownData_000058[0x000028];   // 0x000058 (0x000028)
    };
    // Size: 0x000028 (0x00001C)
    struct alignas(0x8) FAuroraEntitlementQuantity : public FFastArraySerializerItem
    {
        uint8   UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FString EntitlementIdentifier;          // 0x000010 (0x000010)
        int64   Quantity;                       // 0x000020 (0x000008)
    };
    // Size: 0x000001 (0x000001)
    struct FAuroraHideOfferCatalogRequested
    {
        bool    bForce; // 0x000000 (0x000001)
    };
    // Size: 0x000001 (0x000001)
    struct FAuroraInvoice
    {
        uint8   UnknownByte_000000; // 0x000000 (0x000001)
    };
    // Size: 0x000038 (0x000038)
    struct alignas(0x8) FAuroraInvoicePurchased
    {
        FInstancedStruct    Invoice;                        // 0x000000 (0x000010)
        bool                bSuccessful;                    // 0x000010 (0x000001)
        uint8               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FInstancedStruct    Receipt;                        // 0x000018 (0x000010)
        FString             ErrorCode;                      // 0x000028 (0x000010)
    };
    // Size: 0x0000F0 (0x0000F0)
    struct alignas(0x8) FAuroraOffer
    {
        FGuid                       OfferIdentifier;    // 0x000000 (0x000010)
        FString                     OfferType;          // 0x000010 (0x000010)
        FAuroraDescription          OfferDescription;   // 0x000020 (0x000090)
        TSoftObjectPtr<UTexture2D>  Icon;               // 0x0000B0 (0x000020)
        FString                     IconAssetPathName;  // 0x0000D0 (0x000010)
        FInstancedStruct            Price;              // 0x0000E0 (0x000010)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAuroraOfferSelected
    {
        FGuid   OfferInstanceId;    // 0x000000 (0x000010)
    };
    // Size: 0x000001 (0x000001)
    struct FAuroraOnDialogClosed
    {
        uint8   UnknownByte_000000; // 0x000000 (0x000001)
    };
    // Size: 0x000001 (0x000001)
    struct FAuroraOnPurchaseCanceled
    {
        uint8   UnknownByte_000000; // 0x000000 (0x000001)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAuroraOwnedProductQuantitiesChanged
    {
        TMap<FString, int64>    OwnedProductQuantities; // 0x000000 (0x000010)
    };
    // Size: 0x000001 (0x000001)
    struct FAuroraPriceDimension
    {
        uint8   UnknownByte_000000; // 0x000000 (0x000001)
    };
    // Size: 0x000008 (0x000007)
    struct FAuroraPriceDimensionDouble : public FAuroraPriceDimension
    {
    };
    // Size: 0x000008 (0x000007)
    struct FAuroraPriceDimensionInt : public FAuroraPriceDimension
    {
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAuroraPurchaseInvoiceRequested
    {
        FInstancedStruct    Invoice;    // 0x000000 (0x000010)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FAuroraPurchaseResultFinalized
    {
        FInstancedStruct    Receipt;                        // 0x000000 (0x000010)
        bool                bSuccessful;                    // 0x000010 (0x000001)
        uint8               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
    };
    // Size: 0x000001 (0x000001)
    struct FAuroraReceipt
    {
        uint8   UnknownByte_000000; // 0x000000 (0x000001)
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x8) FAuroraShowOfferCatalogRequested
    {
        FGuid                       CatalogId;              // 0x000000 (0x000010)
        TArray<FInstancedStruct>    Offers;                 // 0x000010 (0x000010)
        FText                       Title;                  // 0x000020 (0x000010)
        TMap<FString, int64>        OwnedProductQuantities; // 0x000030 (0x000010)
    };
    // Size: 0x000038 (0x000038)
    struct alignas(0x8) FAuroraStartPurchaseOfferQueried
    {
        FInstancedStruct        Invoice;                        // 0x000000 (0x000010)
        bool                    bSuccessful;                    // 0x000010 (0x000001)
        uint8                   UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FInstancedStruct        offer;                          // 0x000018 (0x000010)
        TMap<FString, int64>    OwnedProductQuantities;         // 0x000028 (0x000010)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FAuroraStartPurchaseRequested
    {
        FInstancedStruct    Invoice;                        // 0x000000 (0x000010)
        bool                bSuccessful;                    // 0x000010 (0x000001)
        uint8               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FString             ErrorCode;                      // 0x000018 (0x000010)
    };
}

