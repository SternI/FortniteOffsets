/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AmbientAudio_Functions
 * ============================================================
 */

#include "AmbientAudio_Functions.hpp"

namespace UE
{

    void UAmbientAudioComponent::SetAmbientAsset(UAmbientAudioDataAsset* InAmbientAsset)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AmbientAudio.AmbientAudioComponent.SetAmbientAsset");
    
        UAmbientAudioComponent___SetAmbientAsset_Params Params{};
        Params.InAmbientAsset = InAmbientAsset;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAmbientAudioComponent::SetCrossfadeTime(float InCrossfadeTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AmbientAudio.AmbientAudioComponent.SetCrossfadeTime");
    
        UAmbientAudioComponent___SetCrossfadeTime_Params Params{};
        Params.InCrossfadeTime = InCrossfadeTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAmbientAudioComponent::SetPriority(int32 InPriority)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AmbientAudio.AmbientAudioComponent.SetPriority");
    
        UAmbientAudioComponent___SetPriority_Params Params{};
        Params.InPriority = InPriority;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAmbientAudioSubsystem::AddAmbientEntry(FName AmbientName, UAmbientAudioDataAsset* Asset, int32 Priority, float CrossfadeTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AmbientAudio.AmbientAudioSubsystem.AddAmbientEntry");
    
        UAmbientAudioSubsystem___AddAmbientEntry_Params Params{};
        Params.AmbientName = AmbientName;
        Params.Asset = Asset;
        Params.Priority = Priority;
        Params.CrossfadeTime = CrossfadeTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAmbientAudioSubsystem::AddGameplayTag(FGameplayTag GameplayTag)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AmbientAudio.AmbientAudioSubsystem.AddGameplayTag");
    
        UAmbientAudioSubsystem___AddGameplayTag_Params Params{};
        Params.GameplayTag = GameplayTag;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UAudioParameterComponent* UAmbientAudioSubsystem::GetAudioParameterComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AmbientAudio.AmbientAudioSubsystem.GetAudioParameterComponent");
    
        UAmbientAudioSubsystem___GetAudioParameterComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAmbientAudioSubsystem::RemoveAmbientEntry(FName AmbientName, float CrossfadeOverride)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AmbientAudio.AmbientAudioSubsystem.RemoveAmbientEntry");
    
        UAmbientAudioSubsystem___RemoveAmbientEntry_Params Params{};
        Params.AmbientName = AmbientName;
        Params.CrossfadeOverride = CrossfadeOverride;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAmbientAudioSubsystem::RemoveGameplayTag(FGameplayTag GameplayTag)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AmbientAudio.AmbientAudioSubsystem.RemoveGameplayTag");
    
        UAmbientAudioSubsystem___RemoveGameplayTag_Params Params{};
        Params.GameplayTag = GameplayTag;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

