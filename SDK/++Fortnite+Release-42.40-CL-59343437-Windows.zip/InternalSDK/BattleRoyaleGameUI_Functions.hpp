/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BattleRoyaleGameUI_Functions
 * ============================================================
 */

#include "BattleRoyaleGameUI.hpp"

namespace UE
{

    struct UBattleRoyaleQuickbarViewModel___HandleSimpleBuildToggled_Params
    {
        bool    bIsEnabled; // 0x000000 (0x000001) [Default: true]
    };

    struct UInstituteChirpEquippedItemViewModel___GetRarity_Params
    {
        EFortRarity ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EFortRarity(80)]
    };

    struct UInstituteChirpGadgetFuelViewModel___InitializePlayerController_Params
    {
        APlayerController*  OwningPlayerController; // 0x000000 (0x000008) [Default: 0x14918040]
    };

    struct UInstituteChirpGadgetFuelViewModel___SetFortItem_Params
    {
        UFortItem*  InItem; // 0x000000 (0x000008) [Default: 0x14918040]
    };

    struct UInstituteChirpQuickbarSlotViewModel___GetNumberOfSlotsTaken_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 345080656]
    };

    struct UInstituteChirpQuickbarSlotViewModel___GetRarity_Params
    {
        EFortRarity ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EFortRarity(80)]
    };

    struct UInstituteChirpQuickbarSlotViewModel___InitializeWithType_Params
    {
        APlayerController*  InPlayerController;             // 0x000000 (0x000008) [Default: 0x14918350]
        EFortQuickBars      InQuickBarType;                 // 0x000008 (0x000001) [Default: EFortQuickBars(49)]
        uint8               UnknownData_000009[0x000003];   // 0x000009 (0x000003)
        int32               InSlot;                         // 0x00000C (0x000004) [Default: 693901533]
    };

    struct UQuickbarGizmoSlotVM___HandleQuickbarContentsChanged_Params
    {
        EFortQuickBars  QuickBarIndex;                  // 0x000000 (0x000001) [Default: EFortQuickBars(128)]
        uint8           UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        TArray<int32>   ChangedSlots;                   // 0x000008 (0x000010) [OutParam]
    };

    struct UQuickbarGizmoSlotVM___HandleQuickbarFullUpdate_Params
    {
        EFortQuickBars  QuickBarIndex;  // 0x000000 (0x000001) [Default: EFortQuickBars(128)]
    };

    struct UQuickbarGizmoSlotVM___HandleQuickBarSlotFocusChanged_Params
    {
        EFortQuickBars  QuickBarIndex;                  // 0x000000 (0x000001) [Default: EFortQuickBars(128)]
        uint8           UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        int32           FocusedSlotIndex;               // 0x000004 (0x000004) [Default: 0]
    };

} // namespace UE

