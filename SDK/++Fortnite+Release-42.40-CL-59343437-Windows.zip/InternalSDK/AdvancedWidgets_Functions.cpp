/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AdvancedWidgets_Functions
 * ============================================================
 */

#include "AdvancedWidgets_Functions.hpp"

namespace UE
{

    float URadialSlider::GetCustomDefaultValue()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.GetCustomDefaultValue");
    
        URadialSlider___GetCustomDefaultValue_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float URadialSlider::GetNormalizedSliderHandlePosition()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.GetNormalizedSliderHandlePosition");
    
        URadialSlider___GetNormalizedSliderHandlePosition_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float URadialSlider::GetValue()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.GetValue");
    
        URadialSlider___GetValue_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void URadialSlider::SetAngularOffset(float InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.SetAngularOffset");
    
        URadialSlider___SetAngularOffset_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void URadialSlider::SetCenterBackgroundColor(FLinearColor InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.SetCenterBackgroundColor");
    
        URadialSlider___SetCenterBackgroundColor_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void URadialSlider::SetCustomDefaultValue(float InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.SetCustomDefaultValue");
    
        URadialSlider___SetCustomDefaultValue_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void URadialSlider::SetHandStartEndRatio(FVector2D InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.SetHandStartEndRatio");
    
        URadialSlider___SetHandStartEndRatio_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void URadialSlider::SetLocked(bool InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.SetLocked");
    
        URadialSlider___SetLocked_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void URadialSlider::SetShowSliderHand(bool InShowSliderHand)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.SetShowSliderHand");
    
        URadialSlider___SetShowSliderHand_Params Params{};
        Params.InShowSliderHand = InShowSliderHand;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void URadialSlider::SetShowSliderHandle(bool InShowSliderHandle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.SetShowSliderHandle");
    
        URadialSlider___SetShowSliderHandle_Params Params{};
        Params.InShowSliderHandle = InShowSliderHandle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void URadialSlider::SetSliderBarColor(FLinearColor InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.SetSliderBarColor");
    
        URadialSlider___SetSliderBarColor_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void URadialSlider::SetSliderHandleColor(FLinearColor InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.SetSliderHandleColor");
    
        URadialSlider___SetSliderHandleColor_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void URadialSlider::SetSliderHandleEndAngle(float InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.SetSliderHandleEndAngle");
    
        URadialSlider___SetSliderHandleEndAngle_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void URadialSlider::SetSliderHandleStartAngle(float InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.SetSliderHandleStartAngle");
    
        URadialSlider___SetSliderHandleStartAngle_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void URadialSlider::SetSliderProgressColor(FLinearColor InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.SetSliderProgressColor");
    
        URadialSlider___SetSliderProgressColor_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void URadialSlider::SetSliderRange(FRuntimeFloatCurve& InSliderRange)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.SetSliderRange");
    
        URadialSlider___SetSliderRange_Params Params{};
        Params.InSliderRange = InSliderRange;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InSliderRange = Params.InSliderRange;
    }

    void URadialSlider::SetStepSize(float InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.SetStepSize");
    
        URadialSlider___SetStepSize_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void URadialSlider::SetUseVerticalDrag(bool InUseVerticalDrag)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.SetUseVerticalDrag");
    
        URadialSlider___SetUseVerticalDrag_Params Params{};
        Params.InUseVerticalDrag = InUseVerticalDrag;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void URadialSlider::SetValue(float InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.SetValue");
    
        URadialSlider___SetValue_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void URadialSlider::SetValueTags(TArray<float>& InValueTags)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdvancedWidgets.RadialSlider.SetValueTags");
    
        URadialSlider___SetValueTags_Params Params{};
        Params.InValueTags = InValueTags;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InValueTags = Params.InValueTags;
    }

} // namespace UE

