/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AndroidFileServer_Functions
 * ============================================================
 */

#include "AndroidFileServer.hpp"

namespace UE
{

    struct UAndroidFileServerBPLibrary___IsFileServerRunning_Params
    {
        TEnumAsByte<EAFSActiveType> ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: 96]
    };

    struct UAndroidFileServerBPLibrary___StartFileServer_Params
    {
        bool    bUSB;                           // 0x000000 (0x000001) [Default: true]
        bool    bNetwork;                       // 0x000001 (0x000001) [Default: true]
        uint8   UnknownData_000002[0x000002];   // 0x000002 (0x000002)
        int32   Port;                           // 0x000004 (0x000004) [Default: 0]
        bool    ReturnValue;                    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAndroidFileServerBPLibrary___StopFileServer_Params
    {
        bool    bUSB;           // 0x000000 (0x000001) [Default: true]
        bool    bNetwork;       // 0x000001 (0x000001) [Default: true]
        bool    ReturnValue;    // 0x000002 (0x000001) [ReturnValue] [Default: true]
    };

} // namespace UE

