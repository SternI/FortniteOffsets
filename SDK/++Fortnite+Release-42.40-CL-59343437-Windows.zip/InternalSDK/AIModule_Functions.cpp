/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:08
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AIModule_Functions
 * ============================================================
 */

#include "AIModule_Functions.hpp"

namespace UE
{

    void AAIController::ClaimTaskResource(UClass* ResourceClass)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.ClaimTaskResource");
    
        AAIController___ClaimTaskResource_Params Params{};
        Params.ResourceClass = ResourceClass;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UAIPerceptionComponent* AAIController::GetAIPerceptionComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.GetAIPerceptionComponent");
    
        AAIController___GetAIPerceptionComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FVector AAIController::GetFocalPoint()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.GetFocalPoint");
    
        AAIController___GetFocalPoint_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FVector AAIController::GetFocalPointOnActor(AActor* Actor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.GetFocalPointOnActor");
    
        AAIController___GetFocalPointOnActor_Params Params{};
        Params.Actor = Actor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    AActor* AAIController::GetFocusActor()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.GetFocusActor");
    
        AAIController___GetFocusActor_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FVector AAIController::GetImmediateMoveDestination()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.GetImmediateMoveDestination");
    
        AAIController___GetImmediateMoveDestination_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TEnumAsByte<EPathFollowingStatus> AAIController::GetMoveStatus()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.GetMoveStatus");
    
        AAIController___GetMoveStatus_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UPathFollowingComponent* AAIController::GetPathFollowingComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.GetPathFollowingComponent");
    
        AAIController___GetPathFollowingComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool AAIController::HasPartialPath()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.HasPartialPath");
    
        AAIController___HasPartialPath_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void AAIController::K2_ClearFocus()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.K2_ClearFocus");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AAIController::K2_SetFocalPoint(FVector FP)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.K2_SetFocalPoint");
    
        AAIController___K2_SetFocalPoint_Params Params{};
        Params.FP = FP;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AAIController::K2_SetFocus(AActor* NewFocus)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.K2_SetFocus");
    
        AAIController___K2_SetFocus_Params Params{};
        Params.NewFocus = NewFocus;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    TEnumAsByte<EPathFollowingRequestResult> AAIController::MoveToActor(AActor* Goal, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bCanStrafe, UClass* FilterClass, bool bAllowPartialPath)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.MoveToActor");
    
        AAIController___MoveToActor_Params Params{};
        Params.Goal = Goal;
        Params.AcceptanceRadius = AcceptanceRadius;
        Params.bStopOnOverlap = bStopOnOverlap;
        Params.bUsePathfinding = bUsePathfinding;
        Params.bCanStrafe = bCanStrafe;
        Params.FilterClass = FilterClass;
        Params.bAllowPartialPath = bAllowPartialPath;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TEnumAsByte<EPathFollowingRequestResult> AAIController::MoveToLocation(FVector& Dest, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bProjectDestinationToNavigation, bool bCanStrafe, UClass* FilterClass, bool bAllowPartialPath)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.MoveToLocation");
    
        AAIController___MoveToLocation_Params Params{};
        Params.Dest = Dest;
        Params.AcceptanceRadius = AcceptanceRadius;
        Params.bStopOnOverlap = bStopOnOverlap;
        Params.bUsePathfinding = bUsePathfinding;
        Params.bProjectDestinationToNavigation = bProjectDestinationToNavigation;
        Params.bCanStrafe = bCanStrafe;
        Params.FilterClass = FilterClass;
        Params.bAllowPartialPath = bAllowPartialPath;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Dest = Params.Dest;
    
        return Params.ReturnValue;
    }

    void AAIController::OnGameplayTaskResourcesClaimed(FGameplayResourceSet NewlyClaimed, FGameplayResourceSet FreshlyReleased)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.OnGameplayTaskResourcesClaimed");
    
        AAIController___OnGameplayTaskResourcesClaimed_Params Params{};
        Params.NewlyClaimed = NewlyClaimed;
        Params.FreshlyReleased = FreshlyReleased;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AAIController::OnUsingBlackBoard(UBlackboardComponent* BlackboardComp, UBlackboardData* BlackboardAsset)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.OnUsingBlackBoard");
    
        AAIController___OnUsingBlackBoard_Params Params{};
        Params.BlackboardComp = BlackboardComp;
        Params.BlackboardAsset = BlackboardAsset;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool AAIController::RunBehaviorTree(UBehaviorTree* BTAsset)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.RunBehaviorTree");
    
        AAIController___RunBehaviorTree_Params Params{};
        Params.BTAsset = BTAsset;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void AAIController::SetMoveBlockDetection(bool bEnable)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.SetMoveBlockDetection");
    
        AAIController___SetMoveBlockDetection_Params Params{};
        Params.bEnable = bEnable;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AAIController::SetPathFollowingComponent(UPathFollowingComponent* NewPFComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.SetPathFollowingComponent");
    
        AAIController___SetPathFollowingComponent_Params Params{};
        Params.NewPFComponent = NewPFComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AAIController::UnclaimTaskResource(UClass* ResourceClass)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.UnclaimTaskResource");
    
        AAIController___UnclaimTaskResource_Params Params{};
        Params.ResourceClass = ResourceClass;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool AAIController::UseBlackboard(UBlackboardData* BlackboardAsset, UBlackboardComponent*& BlackboardComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIController.UseBlackboard");
    
        AAIController___UseBlackboard_Params Params{};
        Params.BlackboardAsset = BlackboardAsset;
        Params.BlackboardComponent = BlackboardComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlackboardComponent = Params.BlackboardComponent;
    
        return Params.ReturnValue;
    }

    bool ANavLinkProxy::HasMovingAgents()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.NavLinkProxy.HasMovingAgents");
    
        ANavLinkProxy___HasMovingAgents_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool ANavLinkProxy::IsSmartLinkEnabled()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.NavLinkProxy.IsSmartLinkEnabled");
    
        ANavLinkProxy___IsSmartLinkEnabled_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void ANavLinkProxy::ReceiveSmartLinkReached(AActor* Agent, FVector& Destination)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.NavLinkProxy.ReceiveSmartLinkReached");
    
        ANavLinkProxy___ReceiveSmartLinkReached_Params Params{};
        Params.Agent = Agent;
        Params.Destination = Destination;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Destination = Params.Destination;
    }

    void ANavLinkProxy::ResumePathFollowing(AActor* Agent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.NavLinkProxy.ResumePathFollowing");
    
        ANavLinkProxy___ResumePathFollowing_Params Params{};
        Params.Agent = Agent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ANavLinkProxy::SetSmartLinkEnabled(bool bEnabled)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.NavLinkProxy.SetSmartLinkEnabled");
    
        ANavLinkProxy___SetSmartLinkEnabled_Params Params{};
        Params.bEnabled = bEnabled;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIAsyncTaskBlueprintProxy::OnMoveCompleted(FAIRequestID RequestID, TEnumAsByte<EPathFollowingResult> MovementResult)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIAsyncTaskBlueprintProxy.OnMoveCompleted");
    
        UAIAsyncTaskBlueprintProxy___OnMoveCompleted_Params Params{};
        Params.RequestID = RequestID;
        Params.MovementResult = MovementResult;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UAIAsyncTaskBlueprintProxy* UAIBlueprintHelperLibrary::CreateMoveToProxyObject(UObject* WorldContextObject, APawn* Pawn, FVector Destination, AActor* TargetActor, float AcceptanceRadius, bool bStopOnOverlap)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIBlueprintHelperLibrary.CreateMoveToProxyObject");
    
        UAIBlueprintHelperLibrary___CreateMoveToProxyObject_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Pawn = Pawn;
        Params.Destination = Destination;
        Params.TargetActor = TargetActor;
        Params.AcceptanceRadius = AcceptanceRadius;
        Params.bStopOnOverlap = bStopOnOverlap;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    AAIController* UAIBlueprintHelperLibrary::GetAIController(AActor* ControlledActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIBlueprintHelperLibrary.GetAIController");
    
        UAIBlueprintHelperLibrary___GetAIController_Params Params{};
        Params.ControlledActor = ControlledActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBlackboardComponent* UAIBlueprintHelperLibrary::GetBlackboard(AActor* Target)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIBlueprintHelperLibrary.GetBlackboard");
    
        UAIBlueprintHelperLibrary___GetBlackboard_Params Params{};
        Params.Target = Target;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UNavigationPath* UAIBlueprintHelperLibrary::GetCurrentPath(AController* Controller)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIBlueprintHelperLibrary.GetCurrentPath");
    
        UAIBlueprintHelperLibrary___GetCurrentPath_Params Params{};
        Params.Controller = Controller;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAIBlueprintHelperLibrary::GetCurrentPathIndex(AController* Controller)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIBlueprintHelperLibrary.GetCurrentPathIndex");
    
        UAIBlueprintHelperLibrary___GetCurrentPathIndex_Params Params{};
        Params.Controller = Controller;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FVector> UAIBlueprintHelperLibrary::GetCurrentPathPoints(AController* Controller)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIBlueprintHelperLibrary.GetCurrentPathPoints");
    
        UAIBlueprintHelperLibrary___GetCurrentPathPoints_Params Params{};
        Params.Controller = Controller;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAIBlueprintHelperLibrary::GetNextNavLinkIndex(AController* Controller)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIBlueprintHelperLibrary.GetNextNavLinkIndex");
    
        UAIBlueprintHelperLibrary___GetNextNavLinkIndex_Params Params{};
        Params.Controller = Controller;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAIBlueprintHelperLibrary::IsValidAIDirection(FVector DirectionVector)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIBlueprintHelperLibrary.IsValidAIDirection");
    
        UAIBlueprintHelperLibrary___IsValidAIDirection_Params Params{};
        Params.DirectionVector = DirectionVector;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAIBlueprintHelperLibrary::IsValidAILocation(FVector Location)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIBlueprintHelperLibrary.IsValidAILocation");
    
        UAIBlueprintHelperLibrary___IsValidAILocation_Params Params{};
        Params.Location = Location;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAIBlueprintHelperLibrary::IsValidAIRotation(FRotator Rotation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIBlueprintHelperLibrary.IsValidAIRotation");
    
        UAIBlueprintHelperLibrary___IsValidAIRotation_Params Params{};
        Params.Rotation = Rotation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAIBlueprintHelperLibrary::LockAIResourcesWithAnimation(UAnimInstance* AnimInstance, bool bLockMovement, bool LockAILogic)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIBlueprintHelperLibrary.LockAIResourcesWithAnimation");
    
        UAIBlueprintHelperLibrary___LockAIResourcesWithAnimation_Params Params{};
        Params.AnimInstance = AnimInstance;
        Params.bLockMovement = bLockMovement;
        Params.LockAILogic = LockAILogic;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIBlueprintHelperLibrary::SendAIMessage(APawn* Target, FName Message, UObject* MessageSource, bool bSuccess)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIBlueprintHelperLibrary.SendAIMessage");
    
        UAIBlueprintHelperLibrary___SendAIMessage_Params Params{};
        Params.Target = Target;
        Params.Message = Message;
        Params.MessageSource = MessageSource;
        Params.bSuccess = bSuccess;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIBlueprintHelperLibrary::SimpleMoveToActor(AController* Controller, AActor* Goal)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIBlueprintHelperLibrary.SimpleMoveToActor");
    
        UAIBlueprintHelperLibrary___SimpleMoveToActor_Params Params{};
        Params.Controller = Controller;
        Params.Goal = Goal;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIBlueprintHelperLibrary::SimpleMoveToLocation(AController* Controller, FVector& Goal)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIBlueprintHelperLibrary.SimpleMoveToLocation");
    
        UAIBlueprintHelperLibrary___SimpleMoveToLocation_Params Params{};
        Params.Controller = Controller;
        Params.Goal = Goal;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Goal = Params.Goal;
    }

    APawn* UAIBlueprintHelperLibrary::SpawnAIFromClass(UObject* WorldContextObject, UClass* PawnClass, UBehaviorTree* BehaviorTree, FVector Location, FRotator Rotation, bool bNoCollisionFail, AActor* Owner)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIBlueprintHelperLibrary.SpawnAIFromClass");
    
        UAIBlueprintHelperLibrary___SpawnAIFromClass_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.PawnClass = PawnClass;
        Params.BehaviorTree = BehaviorTree;
        Params.Location = Location;
        Params.Rotation = Rotation;
        Params.bNoCollisionFail = bNoCollisionFail;
        Params.Owner = Owner;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAIBlueprintHelperLibrary::UnlockAIResourcesWithAnimation(UAnimInstance* AnimInstance, bool bUnlockMovement, bool UnlockAILogic)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIBlueprintHelperLibrary.UnlockAIResourcesWithAnimation");
    
        UAIBlueprintHelperLibrary___UnlockAIResourcesWithAnimation_Params Params{};
        Params.AnimInstance = AnimInstance;
        Params.bUnlockMovement = bUnlockMovement;
        Params.UnlockAILogic = UnlockAILogic;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPerceptionComponent::ForgetAll()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionComponent.ForgetAll");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    bool UAIPerceptionComponent::GetActorsPerception(AActor* Actor, FActorPerceptionBlueprintInfo& Info)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionComponent.GetActorsPerception");
    
        UAIPerceptionComponent___GetActorsPerception_Params Params{};
        Params.Actor = Actor;
        Params.Info = Info;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Info = Params.Info;
    
        return Params.ReturnValue;
    }

    void UAIPerceptionComponent::GetCurrentlyPerceivedActors(UClass* SenseToUse, TArray<AActor*>& OutActors)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionComponent.GetCurrentlyPerceivedActors");
    
        UAIPerceptionComponent___GetCurrentlyPerceivedActors_Params Params{};
        Params.SenseToUse = SenseToUse;
        Params.OutActors = OutActors;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutActors = Params.OutActors;
    }

    void UAIPerceptionComponent::GetKnownPerceivedActors(UClass* SenseToUse, TArray<AActor*>& OutActors)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionComponent.GetKnownPerceivedActors");
    
        UAIPerceptionComponent___GetKnownPerceivedActors_Params Params{};
        Params.SenseToUse = SenseToUse;
        Params.OutActors = OutActors;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutActors = Params.OutActors;
    }

    void UAIPerceptionComponent::GetPerceivedHostileActors(TArray<AActor*>& OutActors)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionComponent.GetPerceivedHostileActors");
    
        UAIPerceptionComponent___GetPerceivedHostileActors_Params Params{};
        Params.OutActors = OutActors;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutActors = Params.OutActors;
    }

    void UAIPerceptionComponent::GetPerceivedHostileActorsBySense(UClass* SenseToUse, TArray<AActor*>& OutActors)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionComponent.GetPerceivedHostileActorsBySense");
    
        UAIPerceptionComponent___GetPerceivedHostileActorsBySense_Params Params{};
        Params.SenseToUse = SenseToUse;
        Params.OutActors = OutActors;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutActors = Params.OutActors;
    }

    bool UAIPerceptionComponent::IsSenseEnabled(UClass* SenseClass)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionComponent.IsSenseEnabled");
    
        UAIPerceptionComponent___IsSenseEnabled_Params Params{};
        Params.SenseClass = SenseClass;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAIPerceptionComponent::OnOwnerEndPlay(AActor* Actor, TEnumAsByte<EEndPlayReason> EndPlayReason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionComponent.OnOwnerEndPlay");
    
        UAIPerceptionComponent___OnOwnerEndPlay_Params Params{};
        Params.Actor = Actor;
        Params.EndPlayReason = EndPlayReason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPerceptionComponent::RequestStimuliListenerUpdate()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionComponent.RequestStimuliListenerUpdate");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAIPerceptionComponent::SetSenseEnabled(UClass* SenseClass, bool bEnable)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionComponent.SetSenseEnabled");
    
        UAIPerceptionComponent___SetSenseEnabled_Params Params{};
        Params.SenseClass = SenseClass;
        Params.bEnable = bEnable;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPerceptionStimuliSourceComponent::RegisterForSense(UClass* SenseClass)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionStimuliSourceComponent.RegisterForSense");
    
        UAIPerceptionStimuliSourceComponent___RegisterForSense_Params Params{};
        Params.SenseClass = SenseClass;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPerceptionStimuliSourceComponent::RegisterWithPerceptionSystem()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionStimuliSourceComponent.RegisterWithPerceptionSystem");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAIPerceptionStimuliSourceComponent::UnregisterFromPerceptionSystem()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromPerceptionSystem");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAIPerceptionStimuliSourceComponent::UnregisterFromSense(UClass* SenseClass)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromSense");
    
        UAIPerceptionStimuliSourceComponent___UnregisterFromSense_Params Params{};
        Params.SenseClass = SenseClass;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UClass* UAIPerceptionSystem::GetSenseClassForStimulus(UObject* WorldContextObject, FAIStimulus& Stimulus)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionSystem.GetSenseClassForStimulus");
    
        UAIPerceptionSystem___GetSenseClassForStimulus_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Stimulus = Stimulus;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Stimulus = Params.Stimulus;
    
        return Params.ReturnValue;
    }

    void UAIPerceptionSystem::OnPerceptionStimuliSourceEndPlay(AActor* Actor, TEnumAsByte<EEndPlayReason> EndPlayReason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionSystem.OnPerceptionStimuliSourceEndPlay");
    
        UAIPerceptionSystem___OnPerceptionStimuliSourceEndPlay_Params Params{};
        Params.Actor = Actor;
        Params.EndPlayReason = EndPlayReason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UAIPerceptionSystem::RegisterPerceptionStimuliSource(UObject* WorldContextObject, UClass* Sense, AActor* Target)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionSystem.RegisterPerceptionStimuliSource");
    
        UAIPerceptionSystem___RegisterPerceptionStimuliSource_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Sense = Sense;
        Params.Target = Target;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAIPerceptionSystem::ReportEvent(UAISenseEvent* PerceptionEvent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionSystem.ReportEvent");
    
        UAIPerceptionSystem___ReportEvent_Params Params{};
        Params.PerceptionEvent = PerceptionEvent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPerceptionSystem::ReportPerceptionEvent(UObject* WorldContextObject, UAISenseEvent* PerceptionEvent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AIPerceptionSystem.ReportPerceptionEvent");
    
        UAIPerceptionSystem___ReportPerceptionEvent_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.PerceptionEvent = PerceptionEvent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAISense_Blueprint::GetAllListenerActors(TArray<AActor*>& ListenerActors)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AISense_Blueprint.GetAllListenerActors");
    
        UAISense_Blueprint___GetAllListenerActors_Params Params{};
        Params.ListenerActors = ListenerActors;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ListenerActors = Params.ListenerActors;
    }

    void UAISense_Blueprint::GetAllListenerComponents(TArray<UAIPerceptionComponent*>& ListenerComponents)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AISense_Blueprint.GetAllListenerComponents");
    
        UAISense_Blueprint___GetAllListenerComponents_Params Params{};
        Params.ListenerComponents = ListenerComponents;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ListenerComponents = Params.ListenerComponents;
    }

    void UAISense_Blueprint::K2_OnNewPawn(APawn* NewPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AISense_Blueprint.K2_OnNewPawn");
    
        UAISense_Blueprint___K2_OnNewPawn_Params Params{};
        Params.NewPawn = NewPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAISense_Blueprint::OnListenerRegistered(AActor* ActorListener, UAIPerceptionComponent* PerceptionComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AISense_Blueprint.OnListenerRegistered");
    
        UAISense_Blueprint___OnListenerRegistered_Params Params{};
        Params.ActorListener = ActorListener;
        Params.PerceptionComponent = PerceptionComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAISense_Blueprint::OnListenerUnregistered(AActor* ActorListener, UAIPerceptionComponent* PerceptionComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AISense_Blueprint.OnListenerUnregistered");
    
        UAISense_Blueprint___OnListenerUnregistered_Params Params{};
        Params.ActorListener = ActorListener;
        Params.PerceptionComponent = PerceptionComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAISense_Blueprint::OnListenerUpdated(AActor* ActorListener, UAIPerceptionComponent* PerceptionComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AISense_Blueprint.OnListenerUpdated");
    
        UAISense_Blueprint___OnListenerUpdated_Params Params{};
        Params.ActorListener = ActorListener;
        Params.PerceptionComponent = PerceptionComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    float UAISense_Blueprint::OnUpdate(TArray<UAISenseEvent*>& EventsToProcess)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AISense_Blueprint.OnUpdate");
    
        UAISense_Blueprint___OnUpdate_Params Params{};
        Params.EventsToProcess = EventsToProcess;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        EventsToProcess = Params.EventsToProcess;
    
        return Params.ReturnValue;
    }

    void UAISense_Damage::ReportDamageEvent(UObject* WorldContextObject, AActor* DamagedActor, AActor* Instigator, float DamageAmount, FVector EventLocation, FVector HitLocation, FName Tag)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AISense_Damage.ReportDamageEvent");
    
        UAISense_Damage___ReportDamageEvent_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.DamagedActor = DamagedActor;
        Params.Instigator = Instigator;
        Params.DamageAmount = DamageAmount;
        Params.EventLocation = EventLocation;
        Params.HitLocation = HitLocation;
        Params.Tag = Tag;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAISense_Hearing::ReportNoiseEvent(UObject* WorldContextObject, FVector NoiseLocation, float Loudness, AActor* Instigator, float MaxRange, FName Tag)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AISense_Hearing.ReportNoiseEvent");
    
        UAISense_Hearing___ReportNoiseEvent_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.NoiseLocation = NoiseLocation;
        Params.Loudness = Loudness;
        Params.Instigator = Instigator;
        Params.MaxRange = MaxRange;
        Params.Tag = Tag;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAISense_Prediction::RequestControllerPredictionEvent(AAIController* Requestor, AActor* PredictedActor, float PredictionTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AISense_Prediction.RequestControllerPredictionEvent");
    
        UAISense_Prediction___RequestControllerPredictionEvent_Params Params{};
        Params.Requestor = Requestor;
        Params.PredictedActor = PredictedActor;
        Params.PredictionTime = PredictionTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAISense_Prediction::RequestPawnPredictionEvent(APawn* Requestor, AActor* PredictedActor, float PredictionTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AISense_Prediction.RequestPawnPredictionEvent");
    
        UAISense_Prediction___RequestPawnPredictionEvent_Params Params{};
        Params.Requestor = Requestor;
        Params.PredictedActor = PredictedActor;
        Params.PredictionTime = PredictionTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAISense_Touch::ReportTouchEvent(UObject* WorldContextObject, AActor* TouchReceiver, AActor* OtherActor, FVector Location)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AISense_Touch.ReportTouchEvent");
    
        UAISense_Touch___ReportTouchEvent_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.TouchReceiver = TouchReceiver;
        Params.OtherActor = OtherActor;
        Params.Location = Location;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAISystem::AIIgnorePlayers()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AISystem.AIIgnorePlayers");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAISystem::AILoggingVerbose()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AISystem.AILoggingVerbose");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    UAITask_MoveTo* UAITask_MoveTo::AIMoveTo(AAIController* Controller, FVector GoalLocation, AActor* GoalActor, float AcceptanceRadius, TEnumAsByte<EAIOptionFlag> StopOnOverlap, TEnumAsByte<EAIOptionFlag> AcceptPartialPath, bool bUsePathfinding, bool bLockAILogic, bool bUseContinuousGoalTracking, TEnumAsByte<EAIOptionFlag> ProjectGoalOnNavigation, TEnumAsByte<EAIOptionFlag> RequireNavigableEndLocation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AITask_MoveTo.AIMoveTo");
    
        UAITask_MoveTo___AIMoveTo_Params Params{};
        Params.Controller = Controller;
        Params.GoalLocation = GoalLocation;
        Params.GoalActor = GoalActor;
        Params.AcceptanceRadius = AcceptanceRadius;
        Params.StopOnOverlap = StopOnOverlap;
        Params.AcceptPartialPath = AcceptPartialPath;
        Params.bUsePathfinding = bUsePathfinding;
        Params.bLockAILogic = bLockAILogic;
        Params.bUseContinuousGoalTracking = bUseContinuousGoalTracking;
        Params.ProjectGoalOnNavigation = ProjectGoalOnNavigation;
        Params.RequireNavigableEndLocation = RequireNavigableEndLocation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAITask_RunEQS* UAITask_RunEQS::RunEQS(AAIController* Controller, UEnvQuery* QueryTemplate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.AITask_RunEQS.RunEQS");
    
        UAITask_RunEQS___RunEQS_Params Params{};
        Params.Controller = Controller;
        Params.QueryTemplate = QueryTemplate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UBTDecorator_BlueprintBase::IsDecoratorExecutionActive()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTDecorator_BlueprintBase.IsDecoratorExecutionActive");
    
        UBTDecorator_BlueprintBase___IsDecoratorExecutionActive_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UBTDecorator_BlueprintBase::IsDecoratorObserverActive()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTDecorator_BlueprintBase.IsDecoratorObserverActive");
    
        UBTDecorator_BlueprintBase___IsDecoratorObserverActive_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UBTDecorator_BlueprintBase::PerformConditionCheck(AActor* OwnerActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTDecorator_BlueprintBase.PerformConditionCheck");
    
        UBTDecorator_BlueprintBase___PerformConditionCheck_Params Params{};
        Params.OwnerActor = OwnerActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UBTDecorator_BlueprintBase::PerformConditionCheckAI(AAIController* OwnerController, APawn* ControlledPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTDecorator_BlueprintBase.PerformConditionCheckAI");
    
        UBTDecorator_BlueprintBase___PerformConditionCheckAI_Params Params{};
        Params.OwnerController = OwnerController;
        Params.ControlledPawn = ControlledPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBTDecorator_BlueprintBase::ReceiveExecutionFinish(AActor* OwnerActor, TEnumAsByte<EBTNodeResult> NodeResult)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinish");
    
        UBTDecorator_BlueprintBase___ReceiveExecutionFinish_Params Params{};
        Params.OwnerActor = OwnerActor;
        Params.NodeResult = NodeResult;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTDecorator_BlueprintBase::ReceiveExecutionFinishAI(AAIController* OwnerController, APawn* ControlledPawn, TEnumAsByte<EBTNodeResult> NodeResult)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinishAI");
    
        UBTDecorator_BlueprintBase___ReceiveExecutionFinishAI_Params Params{};
        Params.OwnerController = OwnerController;
        Params.ControlledPawn = ControlledPawn;
        Params.NodeResult = NodeResult;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTDecorator_BlueprintBase::ReceiveExecutionStart(AActor* OwnerActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStart");
    
        UBTDecorator_BlueprintBase___ReceiveExecutionStart_Params Params{};
        Params.OwnerActor = OwnerActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTDecorator_BlueprintBase::ReceiveExecutionStartAI(AAIController* OwnerController, APawn* ControlledPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStartAI");
    
        UBTDecorator_BlueprintBase___ReceiveExecutionStartAI_Params Params{};
        Params.OwnerController = OwnerController;
        Params.ControlledPawn = ControlledPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTDecorator_BlueprintBase::ReceiveObserverActivated(AActor* OwnerActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivated");
    
        UBTDecorator_BlueprintBase___ReceiveObserverActivated_Params Params{};
        Params.OwnerActor = OwnerActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTDecorator_BlueprintBase::ReceiveObserverActivatedAI(AAIController* OwnerController, APawn* ControlledPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivatedAI");
    
        UBTDecorator_BlueprintBase___ReceiveObserverActivatedAI_Params Params{};
        Params.OwnerController = OwnerController;
        Params.ControlledPawn = ControlledPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTDecorator_BlueprintBase::ReceiveObserverDeactivated(AActor* OwnerActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivated");
    
        UBTDecorator_BlueprintBase___ReceiveObserverDeactivated_Params Params{};
        Params.OwnerActor = OwnerActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTDecorator_BlueprintBase::ReceiveObserverDeactivatedAI(AAIController* OwnerController, APawn* ControlledPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivatedAI");
    
        UBTDecorator_BlueprintBase___ReceiveObserverDeactivatedAI_Params Params{};
        Params.OwnerController = OwnerController;
        Params.ControlledPawn = ControlledPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTDecorator_BlueprintBase::ReceiveTick(AActor* OwnerActor, float DeltaSeconds)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTDecorator_BlueprintBase.ReceiveTick");
    
        UBTDecorator_BlueprintBase___ReceiveTick_Params Params{};
        Params.OwnerActor = OwnerActor;
        Params.DeltaSeconds = DeltaSeconds;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTDecorator_BlueprintBase::ReceiveTickAI(AAIController* OwnerController, APawn* ControlledPawn, float DeltaSeconds)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTDecorator_BlueprintBase.ReceiveTickAI");
    
        UBTDecorator_BlueprintBase___ReceiveTickAI_Params Params{};
        Params.OwnerController = OwnerController;
        Params.ControlledPawn = ControlledPawn;
        Params.DeltaSeconds = DeltaSeconds;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTFunctionLibrary::ClearBlackboardValue(UBTNode* NodeOwner, FBlackboardKeySelector& Key)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.ClearBlackboardValue");
    
        UBTFunctionLibrary___ClearBlackboardValue_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    }

    void UBTFunctionLibrary::ClearBlackboardValueAsVector(UBTNode* NodeOwner, FBlackboardKeySelector& Key)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.ClearBlackboardValueAsVector");
    
        UBTFunctionLibrary___ClearBlackboardValueAsVector_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    }

    AActor* UBTFunctionLibrary::GetBlackboardValueAsActor(UBTNode* NodeOwner, FBlackboardKeySelector& Key)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.GetBlackboardValueAsActor");
    
        UBTFunctionLibrary___GetBlackboardValueAsActor_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    
        return Params.ReturnValue;
    }

    bool UBTFunctionLibrary::GetBlackboardValueAsBool(UBTNode* NodeOwner, FBlackboardKeySelector& Key)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.GetBlackboardValueAsBool");
    
        UBTFunctionLibrary___GetBlackboardValueAsBool_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    
        return Params.ReturnValue;
    }

    UClass* UBTFunctionLibrary::GetBlackboardValueAsClass(UBTNode* NodeOwner, FBlackboardKeySelector& Key)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.GetBlackboardValueAsClass");
    
        UBTFunctionLibrary___GetBlackboardValueAsClass_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    
        return Params.ReturnValue;
    }

    uint8 UBTFunctionLibrary::GetBlackboardValueAsEnum(UBTNode* NodeOwner, FBlackboardKeySelector& Key)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.GetBlackboardValueAsEnum");
    
        UBTFunctionLibrary___GetBlackboardValueAsEnum_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    
        return Params.ReturnValue;
    }

    float UBTFunctionLibrary::GetBlackboardValueAsFloat(UBTNode* NodeOwner, FBlackboardKeySelector& Key)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.GetBlackboardValueAsFloat");
    
        UBTFunctionLibrary___GetBlackboardValueAsFloat_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    
        return Params.ReturnValue;
    }

    int32 UBTFunctionLibrary::GetBlackboardValueAsInt(UBTNode* NodeOwner, FBlackboardKeySelector& Key)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.GetBlackboardValueAsInt");
    
        UBTFunctionLibrary___GetBlackboardValueAsInt_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    
        return Params.ReturnValue;
    }

    FName UBTFunctionLibrary::GetBlackboardValueAsName(UBTNode* NodeOwner, FBlackboardKeySelector& Key)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.GetBlackboardValueAsName");
    
        UBTFunctionLibrary___GetBlackboardValueAsName_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    
        return Params.ReturnValue;
    }

    UObject* UBTFunctionLibrary::GetBlackboardValueAsObject(UBTNode* NodeOwner, FBlackboardKeySelector& Key)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.GetBlackboardValueAsObject");
    
        UBTFunctionLibrary___GetBlackboardValueAsObject_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    
        return Params.ReturnValue;
    }

    FRotator UBTFunctionLibrary::GetBlackboardValueAsRotator(UBTNode* NodeOwner, FBlackboardKeySelector& Key)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.GetBlackboardValueAsRotator");
    
        UBTFunctionLibrary___GetBlackboardValueAsRotator_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    
        return Params.ReturnValue;
    }

    FString UBTFunctionLibrary::GetBlackboardValueAsString(UBTNode* NodeOwner, FBlackboardKeySelector& Key)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.GetBlackboardValueAsString");
    
        UBTFunctionLibrary___GetBlackboardValueAsString_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    
        return Params.ReturnValue;
    }

    FVector UBTFunctionLibrary::GetBlackboardValueAsVector(UBTNode* NodeOwner, FBlackboardKeySelector& Key)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.GetBlackboardValueAsVector");
    
        UBTFunctionLibrary___GetBlackboardValueAsVector_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    
        return Params.ReturnValue;
    }

    UBehaviorTreeComponent* UBTFunctionLibrary::GetOwnerComponent(UBTNode* NodeOwner)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.GetOwnerComponent");
    
        UBTFunctionLibrary___GetOwnerComponent_Params Params{};
        Params.NodeOwner = NodeOwner;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBlackboardComponent* UBTFunctionLibrary::GetOwnersBlackboard(UBTNode* NodeOwner)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.GetOwnersBlackboard");
    
        UBTFunctionLibrary___GetOwnersBlackboard_Params Params{};
        Params.NodeOwner = NodeOwner;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBTFunctionLibrary::SetBlackboardValueAsBool(UBTNode* NodeOwner, FBlackboardKeySelector& Key, bool Value)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.SetBlackboardValueAsBool");
    
        UBTFunctionLibrary___SetBlackboardValueAsBool_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
        Params.Value = Value;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    }

    void UBTFunctionLibrary::SetBlackboardValueAsClass(UBTNode* NodeOwner, FBlackboardKeySelector& Key, UClass* Value)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.SetBlackboardValueAsClass");
    
        UBTFunctionLibrary___SetBlackboardValueAsClass_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
        Params.Value = Value;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    }

    void UBTFunctionLibrary::SetBlackboardValueAsEnum(UBTNode* NodeOwner, FBlackboardKeySelector& Key, uint8 Value)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.SetBlackboardValueAsEnum");
    
        UBTFunctionLibrary___SetBlackboardValueAsEnum_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
        Params.Value = Value;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    }

    void UBTFunctionLibrary::SetBlackboardValueAsFloat(UBTNode* NodeOwner, FBlackboardKeySelector& Key, float Value)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.SetBlackboardValueAsFloat");
    
        UBTFunctionLibrary___SetBlackboardValueAsFloat_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
        Params.Value = Value;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    }

    void UBTFunctionLibrary::SetBlackboardValueAsInt(UBTNode* NodeOwner, FBlackboardKeySelector& Key, int32 Value)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.SetBlackboardValueAsInt");
    
        UBTFunctionLibrary___SetBlackboardValueAsInt_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
        Params.Value = Value;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    }

    void UBTFunctionLibrary::SetBlackboardValueAsName(UBTNode* NodeOwner, FBlackboardKeySelector& Key, FName Value)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.SetBlackboardValueAsName");
    
        UBTFunctionLibrary___SetBlackboardValueAsName_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
        Params.Value = Value;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    }

    void UBTFunctionLibrary::SetBlackboardValueAsObject(UBTNode* NodeOwner, FBlackboardKeySelector& Key, UObject* Value)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.SetBlackboardValueAsObject");
    
        UBTFunctionLibrary___SetBlackboardValueAsObject_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
        Params.Value = Value;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    }

    void UBTFunctionLibrary::SetBlackboardValueAsRotator(UBTNode* NodeOwner, FBlackboardKeySelector& Key, FRotator Value)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.SetBlackboardValueAsRotator");
    
        UBTFunctionLibrary___SetBlackboardValueAsRotator_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
        Params.Value = Value;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    }

    void UBTFunctionLibrary::SetBlackboardValueAsString(UBTNode* NodeOwner, FBlackboardKeySelector& Key, FString Value)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.SetBlackboardValueAsString");
    
        UBTFunctionLibrary___SetBlackboardValueAsString_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
        Params.Value = Value;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    }

    void UBTFunctionLibrary::SetBlackboardValueAsVector(UBTNode* NodeOwner, FBlackboardKeySelector& Key, FVector Value)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.SetBlackboardValueAsVector");
    
        UBTFunctionLibrary___SetBlackboardValueAsVector_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.Key = Key;
        Params.Value = Value;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Key = Params.Key;
    }

    void UBTFunctionLibrary::StartUsingExternalEvent(UBTNode* NodeOwner, AActor* OwningActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.StartUsingExternalEvent");
    
        UBTFunctionLibrary___StartUsingExternalEvent_Params Params{};
        Params.NodeOwner = NodeOwner;
        Params.OwningActor = OwningActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTFunctionLibrary::StopUsingExternalEvent(UBTNode* NodeOwner)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTFunctionLibrary.StopUsingExternalEvent");
    
        UBTFunctionLibrary___StopUsingExternalEvent_Params Params{};
        Params.NodeOwner = NodeOwner;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UBTService_BlueprintBase::IsServiceActive()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTService_BlueprintBase.IsServiceActive");
    
        UBTService_BlueprintBase___IsServiceActive_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBTService_BlueprintBase::ReceiveActivation(AActor* OwnerActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTService_BlueprintBase.ReceiveActivation");
    
        UBTService_BlueprintBase___ReceiveActivation_Params Params{};
        Params.OwnerActor = OwnerActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTService_BlueprintBase::ReceiveActivationAI(AAIController* OwnerController, APawn* ControlledPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTService_BlueprintBase.ReceiveActivationAI");
    
        UBTService_BlueprintBase___ReceiveActivationAI_Params Params{};
        Params.OwnerController = OwnerController;
        Params.ControlledPawn = ControlledPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTService_BlueprintBase::ReceiveDeactivation(AActor* OwnerActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTService_BlueprintBase.ReceiveDeactivation");
    
        UBTService_BlueprintBase___ReceiveDeactivation_Params Params{};
        Params.OwnerActor = OwnerActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTService_BlueprintBase::ReceiveDeactivationAI(AAIController* OwnerController, APawn* ControlledPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTService_BlueprintBase.ReceiveDeactivationAI");
    
        UBTService_BlueprintBase___ReceiveDeactivationAI_Params Params{};
        Params.OwnerController = OwnerController;
        Params.ControlledPawn = ControlledPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTService_BlueprintBase::ReceiveSearchStart(AActor* OwnerActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTService_BlueprintBase.ReceiveSearchStart");
    
        UBTService_BlueprintBase___ReceiveSearchStart_Params Params{};
        Params.OwnerActor = OwnerActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTService_BlueprintBase::ReceiveSearchStartAI(AAIController* OwnerController, APawn* ControlledPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTService_BlueprintBase.ReceiveSearchStartAI");
    
        UBTService_BlueprintBase___ReceiveSearchStartAI_Params Params{};
        Params.OwnerController = OwnerController;
        Params.ControlledPawn = ControlledPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTService_BlueprintBase::ReceiveTick(AActor* OwnerActor, float DeltaSeconds)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTService_BlueprintBase.ReceiveTick");
    
        UBTService_BlueprintBase___ReceiveTick_Params Params{};
        Params.OwnerActor = OwnerActor;
        Params.DeltaSeconds = DeltaSeconds;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTService_BlueprintBase::ReceiveTickAI(AAIController* OwnerController, APawn* ControlledPawn, float DeltaSeconds)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTService_BlueprintBase.ReceiveTickAI");
    
        UBTService_BlueprintBase___ReceiveTickAI_Params Params{};
        Params.OwnerController = OwnerController;
        Params.ControlledPawn = ControlledPawn;
        Params.DeltaSeconds = DeltaSeconds;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTTask_BlueprintBase::FinishAbort()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTTask_BlueprintBase.FinishAbort");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBTTask_BlueprintBase::FinishExecute(bool bSuccess)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTTask_BlueprintBase.FinishExecute");
    
        UBTTask_BlueprintBase___FinishExecute_Params Params{};
        Params.bSuccess = bSuccess;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UBTTask_BlueprintBase::IsTaskAborting()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTTask_BlueprintBase.IsTaskAborting");
    
        UBTTask_BlueprintBase___IsTaskAborting_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UBTTask_BlueprintBase::IsTaskExecuting()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTTask_BlueprintBase.IsTaskExecuting");
    
        UBTTask_BlueprintBase___IsTaskExecuting_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBTTask_BlueprintBase::ReceiveAbort(AActor* OwnerActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTTask_BlueprintBase.ReceiveAbort");
    
        UBTTask_BlueprintBase___ReceiveAbort_Params Params{};
        Params.OwnerActor = OwnerActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTTask_BlueprintBase::ReceiveAbortAI(AAIController* OwnerController, APawn* ControlledPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTTask_BlueprintBase.ReceiveAbortAI");
    
        UBTTask_BlueprintBase___ReceiveAbortAI_Params Params{};
        Params.OwnerController = OwnerController;
        Params.ControlledPawn = ControlledPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTTask_BlueprintBase::ReceiveExecute(AActor* OwnerActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTTask_BlueprintBase.ReceiveExecute");
    
        UBTTask_BlueprintBase___ReceiveExecute_Params Params{};
        Params.OwnerActor = OwnerActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTTask_BlueprintBase::ReceiveExecuteAI(AAIController* OwnerController, APawn* ControlledPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTTask_BlueprintBase.ReceiveExecuteAI");
    
        UBTTask_BlueprintBase___ReceiveExecuteAI_Params Params{};
        Params.OwnerController = OwnerController;
        Params.ControlledPawn = ControlledPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTTask_BlueprintBase::ReceiveTick(AActor* OwnerActor, float DeltaSeconds)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTTask_BlueprintBase.ReceiveTick");
    
        UBTTask_BlueprintBase___ReceiveTick_Params Params{};
        Params.OwnerActor = OwnerActor;
        Params.DeltaSeconds = DeltaSeconds;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTTask_BlueprintBase::ReceiveTickAI(AAIController* OwnerController, APawn* ControlledPawn, float DeltaSeconds)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTTask_BlueprintBase.ReceiveTickAI");
    
        UBTTask_BlueprintBase___ReceiveTickAI_Params Params{};
        Params.OwnerController = OwnerController;
        Params.ControlledPawn = ControlledPawn;
        Params.DeltaSeconds = DeltaSeconds;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTTask_BlueprintBase::SetFinishOnMessage(FName MessageName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTTask_BlueprintBase.SetFinishOnMessage");
    
        UBTTask_BlueprintBase___SetFinishOnMessage_Params Params{};
        Params.MessageName = MessageName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBTTask_BlueprintBase::SetFinishOnMessageWithId(FName MessageName, int32 RequestID)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BTTask_BlueprintBase.SetFinishOnMessageWithId");
    
        UBTTask_BlueprintBase___SetFinishOnMessageWithId_Params Params{};
        Params.MessageName = MessageName;
        Params.RequestID = RequestID;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBehaviorTreeComponent::AddCooldownTagDuration(FGameplayTag CooldownTag, float CooldownDuration, bool bAddToExistingDuration)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BehaviorTreeComponent.AddCooldownTagDuration");
    
        UBehaviorTreeComponent___AddCooldownTagDuration_Params Params{};
        Params.CooldownTag = CooldownTag;
        Params.CooldownDuration = CooldownDuration;
        Params.bAddToExistingDuration = bAddToExistingDuration;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    double UBehaviorTreeComponent::GetTagCooldownEndTime(FGameplayTag CooldownTag)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BehaviorTreeComponent.GetTagCooldownEndTime");
    
        UBehaviorTreeComponent___GetTagCooldownEndTime_Params Params{};
        Params.CooldownTag = CooldownTag;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBehaviorTreeComponent::SetDynamicSubtree(FGameplayTag InjectTag, UBehaviorTree* BehaviorAsset)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BehaviorTreeComponent.SetDynamicSubtree");
    
        UBehaviorTreeComponent___SetDynamicSubtree_Params Params{};
        Params.InjectTag = InjectTag;
        Params.BehaviorAsset = BehaviorAsset;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UBlackboardData* IBlackboardAssetProvider::GetBlackboardAsset()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardAssetProvider.GetBlackboardAsset");
    
        IBlackboardAssetProvider___GetBlackboardAsset_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBlackboardComponent::ClearValue(FName& KeyName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.ClearValue");
    
        UBlackboardComponent___ClearValue_Params Params{};
        Params.KeyName = KeyName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    }

    bool UBlackboardComponent::GetLocationFromEntry(FName& KeyName, FVector& ResultLocation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.GetLocationFromEntry");
    
        UBlackboardComponent___GetLocationFromEntry_Params Params{};
        Params.KeyName = KeyName;
        Params.ResultLocation = ResultLocation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
        ResultLocation = Params.ResultLocation;
    
        return Params.ReturnValue;
    }

    bool UBlackboardComponent::GetRotationFromEntry(FName& KeyName, FRotator& ResultRotation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.GetRotationFromEntry");
    
        UBlackboardComponent___GetRotationFromEntry_Params Params{};
        Params.KeyName = KeyName;
        Params.ResultRotation = ResultRotation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
        ResultRotation = Params.ResultRotation;
    
        return Params.ReturnValue;
    }

    bool UBlackboardComponent::GetValueAsBool(FName& KeyName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.GetValueAsBool");
    
        UBlackboardComponent___GetValueAsBool_Params Params{};
        Params.KeyName = KeyName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    
        return Params.ReturnValue;
    }

    UClass* UBlackboardComponent::GetValueAsClass(FName& KeyName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.GetValueAsClass");
    
        UBlackboardComponent___GetValueAsClass_Params Params{};
        Params.KeyName = KeyName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    
        return Params.ReturnValue;
    }

    uint8 UBlackboardComponent::GetValueAsEnum(FName& KeyName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.GetValueAsEnum");
    
        UBlackboardComponent___GetValueAsEnum_Params Params{};
        Params.KeyName = KeyName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    
        return Params.ReturnValue;
    }

    float UBlackboardComponent::GetValueAsFloat(FName& KeyName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.GetValueAsFloat");
    
        UBlackboardComponent___GetValueAsFloat_Params Params{};
        Params.KeyName = KeyName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    
        return Params.ReturnValue;
    }

    int32 UBlackboardComponent::GetValueAsInt(FName& KeyName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.GetValueAsInt");
    
        UBlackboardComponent___GetValueAsInt_Params Params{};
        Params.KeyName = KeyName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    
        return Params.ReturnValue;
    }

    FName UBlackboardComponent::GetValueAsName(FName& KeyName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.GetValueAsName");
    
        UBlackboardComponent___GetValueAsName_Params Params{};
        Params.KeyName = KeyName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    
        return Params.ReturnValue;
    }

    UObject* UBlackboardComponent::GetValueAsObject(FName& KeyName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.GetValueAsObject");
    
        UBlackboardComponent___GetValueAsObject_Params Params{};
        Params.KeyName = KeyName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    
        return Params.ReturnValue;
    }

    FRotator UBlackboardComponent::GetValueAsRotator(FName& KeyName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.GetValueAsRotator");
    
        UBlackboardComponent___GetValueAsRotator_Params Params{};
        Params.KeyName = KeyName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    
        return Params.ReturnValue;
    }

    FString UBlackboardComponent::GetValueAsString(FName& KeyName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.GetValueAsString");
    
        UBlackboardComponent___GetValueAsString_Params Params{};
        Params.KeyName = KeyName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    
        return Params.ReturnValue;
    }

    FVector UBlackboardComponent::GetValueAsVector(FName& KeyName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.GetValueAsVector");
    
        UBlackboardComponent___GetValueAsVector_Params Params{};
        Params.KeyName = KeyName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    
        return Params.ReturnValue;
    }

    bool UBlackboardComponent::IsVectorValueSet(FName& KeyName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.IsVectorValueSet");
    
        UBlackboardComponent___IsVectorValueSet_Params Params{};
        Params.KeyName = KeyName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    
        return Params.ReturnValue;
    }

    void UBlackboardComponent::SetValueAsBool(FName& KeyName, bool BoolValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.SetValueAsBool");
    
        UBlackboardComponent___SetValueAsBool_Params Params{};
        Params.KeyName = KeyName;
        Params.BoolValue = BoolValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    }

    void UBlackboardComponent::SetValueAsClass(FName& KeyName, UClass* ClassValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.SetValueAsClass");
    
        UBlackboardComponent___SetValueAsClass_Params Params{};
        Params.KeyName = KeyName;
        Params.ClassValue = ClassValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    }

    void UBlackboardComponent::SetValueAsEnum(FName& KeyName, uint8 EnumValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.SetValueAsEnum");
    
        UBlackboardComponent___SetValueAsEnum_Params Params{};
        Params.KeyName = KeyName;
        Params.EnumValue = EnumValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    }

    void UBlackboardComponent::SetValueAsFloat(FName& KeyName, float FloatValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.SetValueAsFloat");
    
        UBlackboardComponent___SetValueAsFloat_Params Params{};
        Params.KeyName = KeyName;
        Params.FloatValue = FloatValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    }

    void UBlackboardComponent::SetValueAsInt(FName& KeyName, int32 IntValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.SetValueAsInt");
    
        UBlackboardComponent___SetValueAsInt_Params Params{};
        Params.KeyName = KeyName;
        Params.IntValue = IntValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    }

    void UBlackboardComponent::SetValueAsName(FName& KeyName, FName NameValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.SetValueAsName");
    
        UBlackboardComponent___SetValueAsName_Params Params{};
        Params.KeyName = KeyName;
        Params.NameValue = NameValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    }

    void UBlackboardComponent::SetValueAsObject(FName& KeyName, UObject* ObjectValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.SetValueAsObject");
    
        UBlackboardComponent___SetValueAsObject_Params Params{};
        Params.KeyName = KeyName;
        Params.ObjectValue = ObjectValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    }

    void UBlackboardComponent::SetValueAsRotator(FName& KeyName, FRotator VectorValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.SetValueAsRotator");
    
        UBlackboardComponent___SetValueAsRotator_Params Params{};
        Params.KeyName = KeyName;
        Params.VectorValue = VectorValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    }

    void UBlackboardComponent::SetValueAsString(FName& KeyName, FString StringValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.SetValueAsString");
    
        UBlackboardComponent___SetValueAsString_Params Params{};
        Params.KeyName = KeyName;
        Params.StringValue = StringValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    }

    void UBlackboardComponent::SetValueAsVector(FName& KeyName, FVector VectorValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BlackboardComponent.SetValueAsVector");
    
        UBlackboardComponent___SetValueAsVector_Params Params{};
        Params.KeyName = KeyName;
        Params.VectorValue = VectorValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KeyName = Params.KeyName;
    }

    bool UBrainComponent::IsPaused()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BrainComponent.IsPaused");
    
        UBrainComponent___IsPaused_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UBrainComponent::IsRunning()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BrainComponent.IsRunning");
    
        UBrainComponent___IsRunning_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBrainComponent::RestartLogic()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BrainComponent.RestartLogic");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBrainComponent::StartLogic()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BrainComponent.StartLogic");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBrainComponent::StopLogic(FString Reason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.BrainComponent.StopLogic");
    
        UBrainComponent___StopLogic_Params Params{};
        Params.Reason = Reason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UCrowdFollowingComponent::SuspendCrowdSteering(bool bSuspend)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.CrowdFollowingComponent.SuspendCrowdSteering");
    
        UCrowdFollowingComponent___SuspendCrowdSteering_Params Params{};
        Params.bSuspend = bSuspend;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UEnvQueryContext_BlueprintBase::ProvideActorsSet(UObject* QuerierObject, AActor* QuerierActor, TArray<AActor*>& ResultingActorsSet)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.EnvQueryContext_BlueprintBase.ProvideActorsSet");
    
        UEnvQueryContext_BlueprintBase___ProvideActorsSet_Params Params{};
        Params.QuerierObject = QuerierObject;
        Params.QuerierActor = QuerierActor;
        Params.ResultingActorsSet = ResultingActorsSet;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ResultingActorsSet = Params.ResultingActorsSet;
    }

    void UEnvQueryContext_BlueprintBase::ProvideLocationsSet(UObject* QuerierObject, AActor* QuerierActor, TArray<FVector>& ResultingLocationSet)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.EnvQueryContext_BlueprintBase.ProvideLocationsSet");
    
        UEnvQueryContext_BlueprintBase___ProvideLocationsSet_Params Params{};
        Params.QuerierObject = QuerierObject;
        Params.QuerierActor = QuerierActor;
        Params.ResultingLocationSet = ResultingLocationSet;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ResultingLocationSet = Params.ResultingLocationSet;
    }

    void UEnvQueryContext_BlueprintBase::ProvideSingleActor(UObject* QuerierObject, AActor* QuerierActor, AActor*& ResultingActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.EnvQueryContext_BlueprintBase.ProvideSingleActor");
    
        UEnvQueryContext_BlueprintBase___ProvideSingleActor_Params Params{};
        Params.QuerierObject = QuerierObject;
        Params.QuerierActor = QuerierActor;
        Params.ResultingActor = ResultingActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ResultingActor = Params.ResultingActor;
    }

    void UEnvQueryContext_BlueprintBase::ProvideSingleLocation(UObject* QuerierObject, AActor* QuerierActor, FVector& ResultingLocation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.EnvQueryContext_BlueprintBase.ProvideSingleLocation");
    
        UEnvQueryContext_BlueprintBase___ProvideSingleLocation_Params Params{};
        Params.QuerierObject = QuerierObject;
        Params.QuerierActor = QuerierActor;
        Params.ResultingLocation = ResultingLocation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ResultingLocation = Params.ResultingLocation;
    }

    void UEnvQueryGenerator_BlueprintBase::AddGeneratedActor(AActor* GeneratedActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedActor");
    
        UEnvQueryGenerator_BlueprintBase___AddGeneratedActor_Params Params{};
        Params.GeneratedActor = GeneratedActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UEnvQueryGenerator_BlueprintBase::AddGeneratedVector(FVector GeneratedVector)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedVector");
    
        UEnvQueryGenerator_BlueprintBase___AddGeneratedVector_Params Params{};
        Params.GeneratedVector = GeneratedVector;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UEnvQueryGenerator_BlueprintBase::DoItemGeneration(TArray<FVector>& ContextLocations)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.EnvQueryGenerator_BlueprintBase.DoItemGeneration");
    
        UEnvQueryGenerator_BlueprintBase___DoItemGeneration_Params Params{};
        Params.ContextLocations = ContextLocations;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ContextLocations = Params.ContextLocations;
    }

    void UEnvQueryGenerator_BlueprintBase::DoItemGenerationFromActors(TArray<AActor*>& ContextActors)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.EnvQueryGenerator_BlueprintBase.DoItemGenerationFromActors");
    
        UEnvQueryGenerator_BlueprintBase___DoItemGenerationFromActors_Params Params{};
        Params.ContextActors = ContextActors;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ContextActors = Params.ContextActors;
    }

    UObject* UEnvQueryGenerator_BlueprintBase::GetQuerier()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.EnvQueryGenerator_BlueprintBase.GetQuerier");
    
        UEnvQueryGenerator_BlueprintBase___GetQuerier_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UEnvQueryInstanceBlueprintWrapper::GetItemScore(int32 ItemIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.EnvQueryInstanceBlueprintWrapper.GetItemScore");
    
        UEnvQueryInstanceBlueprintWrapper___GetItemScore_Params Params{};
        Params.ItemIndex = ItemIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UEnvQueryInstanceBlueprintWrapper::GetQueryResultsAsActors(TArray<AActor*>& ResultActors)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.EnvQueryInstanceBlueprintWrapper.GetQueryResultsAsActors");
    
        UEnvQueryInstanceBlueprintWrapper___GetQueryResultsAsActors_Params Params{};
        Params.ResultActors = ResultActors;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ResultActors = Params.ResultActors;
    
        return Params.ReturnValue;
    }

    bool UEnvQueryInstanceBlueprintWrapper::GetQueryResultsAsLocations(TArray<FVector>& ResultLocations)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.EnvQueryInstanceBlueprintWrapper.GetQueryResultsAsLocations");
    
        UEnvQueryInstanceBlueprintWrapper___GetQueryResultsAsLocations_Params Params{};
        Params.ResultLocations = ResultLocations;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ResultLocations = Params.ResultLocations;
    
        return Params.ReturnValue;
    }

    bool UEnvQueryInstanceBlueprintWrapper::GetQueryResultsAsTransforms(TArray<FTransform>& ResultTransforms)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.EnvQueryInstanceBlueprintWrapper.GetQueryResultsAsTransforms");
    
        UEnvQueryInstanceBlueprintWrapper___GetQueryResultsAsTransforms_Params Params{};
        Params.ResultTransforms = ResultTransforms;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ResultTransforms = Params.ResultTransforms;
    
        return Params.ReturnValue;
    }

    TArray<AActor*> UEnvQueryInstanceBlueprintWrapper::GetResultsAsActors()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsActors");
    
        UEnvQueryInstanceBlueprintWrapper___GetResultsAsActors_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FVector> UEnvQueryInstanceBlueprintWrapper::GetResultsAsLocations()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsLocations");
    
        UEnvQueryInstanceBlueprintWrapper___GetResultsAsLocations_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UEnvQueryInstanceBlueprintWrapper::SetNamedParam(FName ParamName, float Value)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.EnvQueryInstanceBlueprintWrapper.SetNamedParam");
    
        UEnvQueryInstanceBlueprintWrapper___SetNamedParam_Params Params{};
        Params.ParamName = ParamName;
        Params.Value = Value;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UEnvQueryInstanceBlueprintWrapper::EQSQueryDoneSignature(UEnvQueryInstanceBlueprintWrapper* QueryInstance, TEnumAsByte<EEnvQueryStatus> QueryStatus)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.EnvQueryInstanceBlueprintWrapper.EQSQueryDoneSignature");
    
        UEnvQueryInstanceBlueprintWrapper___EQSQueryDoneSignature_Params Params{};
        Params.QueryInstance = QueryInstance;
        Params.QueryStatus = QueryStatus;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UEnvQueryInstanceBlueprintWrapper* UEnvQueryManager::RunEQSQuery(UObject* WorldContextObject, UEnvQuery* QueryTemplate, UObject* Querier, TEnumAsByte<EEnvQueryRunMode> RunMode, UClass* WrapperClass)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.EnvQueryManager.RunEQSQuery");
    
        UEnvQueryManager___RunEQSQuery_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.QueryTemplate = QueryTemplate;
        Params.Querier = Querier;
        Params.RunMode = RunMode;
        Params.WrapperClass = WrapperClass;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UGeneratedNavLinksProxy::ReceiveSmartLinkReached(AActor* Agent, FVector Destination)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.GeneratedNavLinksProxy.ReceiveSmartLinkReached");
    
        UGeneratedNavLinksProxy___ReceiveSmartLinkReached_Params Params{};
        Params.Agent = Agent;
        Params.Destination = Destination;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    int32 UNavLocalGridManager::AddLocalNavigationGridForBox(UObject* WorldContextObject, FVector& Location, FVector Extent, FRotator Rotation, int32 Radius2D, float Height, bool bRebuildGrids)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.NavLocalGridManager.AddLocalNavigationGridForBox");
    
        UNavLocalGridManager___AddLocalNavigationGridForBox_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Location = Location;
        Params.Extent = Extent;
        Params.Rotation = Rotation;
        Params.Radius2D = Radius2D;
        Params.Height = Height;
        Params.bRebuildGrids = bRebuildGrids;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Location = Params.Location;
    
        return Params.ReturnValue;
    }

    int32 UNavLocalGridManager::AddLocalNavigationGridForCapsule(UObject* WorldContextObject, FVector& Location, float CapsuleRadius, float CapsuleHalfHeight, int32 Radius2D, float Height, bool bRebuildGrids)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.NavLocalGridManager.AddLocalNavigationGridForCapsule");
    
        UNavLocalGridManager___AddLocalNavigationGridForCapsule_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Location = Location;
        Params.CapsuleRadius = CapsuleRadius;
        Params.CapsuleHalfHeight = CapsuleHalfHeight;
        Params.Radius2D = Radius2D;
        Params.Height = Height;
        Params.bRebuildGrids = bRebuildGrids;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Location = Params.Location;
    
        return Params.ReturnValue;
    }

    int32 UNavLocalGridManager::AddLocalNavigationGridForPoint(UObject* WorldContextObject, FVector& Location, int32 Radius2D, float Height, bool bRebuildGrids)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.NavLocalGridManager.AddLocalNavigationGridForPoint");
    
        UNavLocalGridManager___AddLocalNavigationGridForPoint_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Location = Location;
        Params.Radius2D = Radius2D;
        Params.Height = Height;
        Params.bRebuildGrids = bRebuildGrids;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Location = Params.Location;
    
        return Params.ReturnValue;
    }

    int32 UNavLocalGridManager::AddLocalNavigationGridForPoints(UObject* WorldContextObject, TArray<FVector>& Locations, int32 Radius2D, float Height, bool bRebuildGrids)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.NavLocalGridManager.AddLocalNavigationGridForPoints");
    
        UNavLocalGridManager___AddLocalNavigationGridForPoints_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Locations = Locations;
        Params.Radius2D = Radius2D;
        Params.Height = Height;
        Params.bRebuildGrids = bRebuildGrids;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Locations = Params.Locations;
    
        return Params.ReturnValue;
    }

    bool UNavLocalGridManager::FindLocalNavigationGridPath(UObject* WorldContextObject, FVector& Start, FVector& End, TArray<FVector>& PathPoints)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.NavLocalGridManager.FindLocalNavigationGridPath");
    
        UNavLocalGridManager___FindLocalNavigationGridPath_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Start = Start;
        Params.End = End;
        Params.PathPoints = PathPoints;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Start = Params.Start;
        End = Params.End;
        PathPoints = Params.PathPoints;
    
        return Params.ReturnValue;
    }

    void UNavLocalGridManager::RemoveLocalNavigationGrid(UObject* WorldContextObject, int32 GridId, bool bRebuildGrids)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.NavLocalGridManager.RemoveLocalNavigationGrid");
    
        UNavLocalGridManager___RemoveLocalNavigationGrid_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.GridId = GridId;
        Params.bRebuildGrids = bRebuildGrids;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UNavLocalGridManager::SetLocalNavigationGridDensity(UObject* WorldContextObject, float CellSize)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.NavLocalGridManager.SetLocalNavigationGridDensity");
    
        UNavLocalGridManager___SetLocalNavigationGridDensity_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.CellSize = CellSize;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TEnumAsByte<EPathFollowingAction> UPathFollowingComponent::GetPathActionType()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.PathFollowingComponent.GetPathActionType");
    
        UPathFollowingComponent___GetPathActionType_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FVector UPathFollowingComponent::GetPathDestination()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.PathFollowingComponent.GetPathDestination");
    
        UPathFollowingComponent___GetPathDestination_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UPathFollowingComponent::OnActorBump(AActor* SelfActor, AActor* OtherActor, FVector NormalImpulse, FHitResult& Hit)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.PathFollowingComponent.OnActorBump");
    
        UPathFollowingComponent___OnActorBump_Params Params{};
        Params.SelfActor = SelfActor;
        Params.OtherActor = OtherActor;
        Params.NormalImpulse = NormalImpulse;
        Params.Hit = Hit;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Hit = Params.Hit;
    }

    void UPathFollowingComponent::OnNavDataRegistered(ANavigationData* NavData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.PathFollowingComponent.OnNavDataRegistered");
    
        UPathFollowingComponent___OnNavDataRegistered_Params Params{};
        Params.NavData = NavData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    float UPawnSensingComponent::GetPeripheralVisionAngle()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.PawnSensingComponent.GetPeripheralVisionAngle");
    
        UPawnSensingComponent___GetPeripheralVisionAngle_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UPawnSensingComponent::GetPeripheralVisionCosine()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.PawnSensingComponent.GetPeripheralVisionCosine");
    
        UPawnSensingComponent___GetPeripheralVisionCosine_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UPawnSensingComponent::SetPeripheralVisionAngle(float NewPeripheralVisionAngle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.PawnSensingComponent.SetPeripheralVisionAngle");
    
        UPawnSensingComponent___SetPeripheralVisionAngle_Params Params{};
        Params.NewPeripheralVisionAngle = NewPeripheralVisionAngle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPawnSensingComponent::SetSensingInterval(float NewSensingInterval)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.PawnSensingComponent.SetSensingInterval");
    
        UPawnSensingComponent___SetSensingInterval_Params Params{};
        Params.NewSensingInterval = NewSensingInterval;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPawnSensingComponent::SetSensingUpdatesEnabled(bool bEnabled)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.PawnSensingComponent.SetSensingUpdatesEnabled");
    
        UPawnSensingComponent___SetSensingUpdatesEnabled_Params Params{};
        Params.bEnabled = bEnabled;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPawnSensingComponent::HearNoiseDelegate(APawn* Instigator, FVector& Location, float Volume)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.PawnSensingComponent.HearNoiseDelegate");
    
        UPawnSensingComponent___HearNoiseDelegate_Params Params{};
        Params.Instigator = Instigator;
        Params.Location = Location;
        Params.Volume = Volume;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Location = Params.Location;
    }

    void UPawnSensingComponent::SeePawnDelegate(APawn* Pawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.PawnSensingComponent.SeePawnDelegate");
    
        UPawnSensingComponent___SeePawnDelegate_Params Params{};
        Params.Pawn = Pawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UValueOrBBKeyBlueprintUtility::GetBool(FValueOrBBKey_Bool& Value, UBehaviorTreeComponent* BehaviorTreeComp)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.ValueOrBBKeyBlueprintUtility.GetBool");
    
        UValueOrBBKeyBlueprintUtility___GetBool_Params Params{};
        Params.Value = Value;
        Params.BehaviorTreeComp = BehaviorTreeComp;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Value = Params.Value;
    
        return Params.ReturnValue;
    }

    UClass* UValueOrBBKeyBlueprintUtility::GetClass(FValueOrBBKey_Class& Value, UBehaviorTreeComponent* BehaviorTreeComp)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.ValueOrBBKeyBlueprintUtility.GetClass");
    
        UValueOrBBKeyBlueprintUtility___GetClass_Params Params{};
        Params.Value = Value;
        Params.BehaviorTreeComp = BehaviorTreeComp;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Value = Params.Value;
    
        return Params.ReturnValue;
    }

    uint8 UValueOrBBKeyBlueprintUtility::GetEnum(FValueOrBBKey_Enum& Value, UBehaviorTreeComponent* BehaviorTreeComp)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.ValueOrBBKeyBlueprintUtility.GetEnum");
    
        UValueOrBBKeyBlueprintUtility___GetEnum_Params Params{};
        Params.Value = Value;
        Params.BehaviorTreeComp = BehaviorTreeComp;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Value = Params.Value;
    
        return Params.ReturnValue;
    }

    float UValueOrBBKeyBlueprintUtility::GetFloat(FValueOrBBKey_Float& Value, UBehaviorTreeComponent* BehaviorTreeComp)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.ValueOrBBKeyBlueprintUtility.GetFloat");
    
        UValueOrBBKeyBlueprintUtility___GetFloat_Params Params{};
        Params.Value = Value;
        Params.BehaviorTreeComp = BehaviorTreeComp;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Value = Params.Value;
    
        return Params.ReturnValue;
    }

    int32 UValueOrBBKeyBlueprintUtility::GetInt32(FValueOrBBKey_Int32& Value, UBehaviorTreeComponent* BehaviorTreeComp)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.ValueOrBBKeyBlueprintUtility.GetInt32");
    
        UValueOrBBKeyBlueprintUtility___GetInt32_Params Params{};
        Params.Value = Value;
        Params.BehaviorTreeComp = BehaviorTreeComp;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Value = Params.Value;
    
        return Params.ReturnValue;
    }

    FName UValueOrBBKeyBlueprintUtility::GetName(FValueOrBBKey_Name& Value, UBehaviorTreeComponent* BehaviorTreeComp)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.ValueOrBBKeyBlueprintUtility.GetName");
    
        UValueOrBBKeyBlueprintUtility___GetName_Params Params{};
        Params.Value = Value;
        Params.BehaviorTreeComp = BehaviorTreeComp;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Value = Params.Value;
    
        return Params.ReturnValue;
    }

    UObject* UValueOrBBKeyBlueprintUtility::GetObject(FValueOrBBKey_Object& Value, UBehaviorTreeComponent* BehaviorTreeComp)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.ValueOrBBKeyBlueprintUtility.GetObject");
    
        UValueOrBBKeyBlueprintUtility___GetObject_Params Params{};
        Params.Value = Value;
        Params.BehaviorTreeComp = BehaviorTreeComp;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Value = Params.Value;
    
        return Params.ReturnValue;
    }

    FRotator UValueOrBBKeyBlueprintUtility::GetRotator(FValueOrBBKey_Rotator& Value, UBehaviorTreeComponent* BehaviorTreeComp)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.ValueOrBBKeyBlueprintUtility.GetRotator");
    
        UValueOrBBKeyBlueprintUtility___GetRotator_Params Params{};
        Params.Value = Value;
        Params.BehaviorTreeComp = BehaviorTreeComp;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Value = Params.Value;
    
        return Params.ReturnValue;
    }

    FString UValueOrBBKeyBlueprintUtility::GetString(FValueOrBBKey_String& Value, UBehaviorTreeComponent* BehaviorTreeComp)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.ValueOrBBKeyBlueprintUtility.GetString");
    
        UValueOrBBKeyBlueprintUtility___GetString_Params Params{};
        Params.Value = Value;
        Params.BehaviorTreeComp = BehaviorTreeComp;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Value = Params.Value;
    
        return Params.ReturnValue;
    }

    FInstancedStruct UValueOrBBKeyBlueprintUtility::GetStruct(FValueOrBBKey_Struct& Value, UBehaviorTreeComponent* BehaviorTreeComp)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.ValueOrBBKeyBlueprintUtility.GetStruct");
    
        UValueOrBBKeyBlueprintUtility___GetStruct_Params Params{};
        Params.Value = Value;
        Params.BehaviorTreeComp = BehaviorTreeComp;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Value = Params.Value;
    
        return Params.ReturnValue;
    }

    FVector UValueOrBBKeyBlueprintUtility::GetVector(FValueOrBBKey_Vector& Value, UBehaviorTreeComponent* BehaviorTreeComp)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIModule.ValueOrBBKeyBlueprintUtility.GetVector");
    
        UValueOrBBKeyBlueprintUtility___GetVector_Params Params{};
        Params.Value = Value;
        Params.BehaviorTreeComp = BehaviorTreeComp;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Value = Params.Value;
    
        return Params.ReturnValue;
    }

} // namespace UE

