/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AccoladesRuntime_Functions
 * ============================================================
 */

#include "AccoladesRuntime.hpp"

namespace UE
{

    struct UFortCheatManager_Accolades___TriggerAccolade_Params
    {
        FString AccoladeName;   // 0x000000 (0x000010) [Default: L"??"]
        int32   TimesToTrigger; // 0x000010 (0x000004) [Default: 426401760]
    };

    struct UFortControllerComponent_AccoladeCollection___ClientNotifyRestored_Params
    {
        EPersistenceFrameworkResult Result; // 0x000000 (0x000001) [Default: EPersistenceFrameworkResult(176)]
    };

    struct UFortControllerComponent_AccoladeCollection___HandleOnCurrentPlaylistLoaded_Params
    {
        FName                   PlaylistName;                   // 0x000000 (0x000004) [Default: FName(344378800) -> L""]
        uint8                   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FGameplayTagContainer   PlaylistContextTags;            // 0x000008 (0x000020) [OutParam]
    };

    struct UFortControllerComponent_AccoladeCollection___OnRep_PinnedAccoladeName_Params
    {
        FName   OldPinnedAccoladeName;  // 0x000000 (0x000004) [Default: FName(344378800) -> L""]
    };

    struct UFortControllerComponent_AccoladeCollection___ServerMarkAccoladesAsSeen_Params
    {
        TArray<FName>   AccoladeNames;  // 0x000000 (0x000010)
    };

    struct UFortControllerComponent_AccoladeCollection___ServerPinAccolade_Params
    {
        FName   AccoladeName;   // 0x000000 (0x000004) [Default: FName(344378800) -> L""]
    };

} // namespace UE

