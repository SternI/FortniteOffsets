/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:08
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AssembledMeshSystem_Functions
 * ============================================================
 */

#include "AssembledMeshSystem.hpp"

namespace UE
{

    struct UAssembledMeshUserComponent___CustomizationCompleted_Params
    {
        int32   PartIndex;  // 0x000000 (0x000004) [Default: 323421584]
    };

    struct UAssembledMeshUserComponent___GetAttachToComponent_Params
    {
        USkeletalMeshComponent* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x13470590]
    };

    struct UAssembledMeshUserComponent___GetMeshPart_Params
    {
        UAssembledMeshSchema*   ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x13470590]
    };

    struct UAssembledMeshUserComponent___GetMeshPartByIndex_Params
    {
        int32                   MeshPartIndex;                  // 0x000000 (0x000004) [Default: 323421584]
        uint8                   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UAssembledMeshSchema*   ReturnValue;                    // 0x000008 (0x000008) [ReturnValue] [Default: 0xBC851BDD00000031]
    };

    struct UAssembledMeshUserComponent___GetNumMeshParts_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 323421584]
    };

    struct UAssembledMeshUserComponent___SetMeshPart_Params
    {
        UAssembledMeshSchema*   InMeshPart; // 0x000000 (0x000008) [Default: 0x13470590]
    };

    struct UAssembledMeshUserComponent___SetMeshParts_Params
    {
        TArray<TSoftObjectPtr<UAssembledMeshSchema>>    InMeshParts;    // 0x000000 (0x000010)
    };

} // namespace UE

