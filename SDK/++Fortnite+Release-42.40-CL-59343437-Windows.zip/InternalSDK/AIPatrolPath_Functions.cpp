/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AIPatrolPath_Functions
 * ============================================================
 */

#include "AIPatrolPath_Functions.hpp"

namespace UE
{

    bool UAIPatrolPathComponent::CanNextPointBeReached()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.CanNextPointBeReached");
    
        UAIPatrolPathComponent___CanNextPointBeReached_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAIPatrolPathComponent::GeneratePathPoints(EFortCreativePatrolPathGroup PatrolPathGroup, bool bGenerationCausedByDuplication)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.GeneratePathPoints");
    
        UAIPatrolPathComponent___GeneratePathPoints_Params Params{};
        Params.PatrolPathGroup = PatrolPathGroup;
        Params.bGenerationCausedByDuplication = bGenerationCausedByDuplication;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    TArray<UAIPatrolPathComponent*> UAIPatrolPathComponent::GetLinkedPatrolPoints()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.GetLinkedPatrolPoints");
    
        UAIPatrolPathComponent___GetLinkedPatrolPoints_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAIPatrolPathComponent::GetNextAvailablePatrolPathIndex(int32& NextAvailableIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.GetNextAvailablePatrolPathIndex");
    
        UAIPatrolPathComponent___GetNextAvailablePatrolPathIndex_Params Params{};
        Params.NextAvailableIndex = NextAvailableIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        NextAvailableIndex = Params.NextAvailableIndex;
    
        return Params.ReturnValue;
    }

    UClass* UAIPatrolPathComponent::GetPatrolFilterOptions()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.GetPatrolFilterOptions");
    
        UAIPatrolPathComponent___GetPatrolFilterOptions_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EPatrollingMode UAIPatrolPathComponent::GetPatrollingMode()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.GetPatrollingMode");
    
        UAIPatrolPathComponent___GetPatrollingMode_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EFortCreativePatrolPathGroup UAIPatrolPathComponent::GetPatrolPathGroup()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.GetPatrolPathGroup");
    
        UAIPatrolPathComponent___GetPatrolPathGroup_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAIPatrolPathComponent::GetPatrolPathIndex()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.GetPatrolPathIndex");
    
        UAIPatrolPathComponent___GetPatrolPathIndex_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAIPatrolPathComponent::GetPatrolPathIndexFromDevice()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.GetPatrolPathIndexFromDevice");
    
        UAIPatrolPathComponent___GetPatrolPathIndexFromDevice_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAIPatrolPathComponent* UAIPatrolPathComponent::GetPatrolPathPoint(int32 InPatrolPathIndex, int32 InPatrolPathPointIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.GetPatrolPathPoint");
    
        UAIPatrolPathComponent___GetPatrolPathPoint_Params Params{};
        Params.InPatrolPathIndex = InPatrolPathIndex;
        Params.InPatrolPathPointIndex = InPatrolPathPointIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAIPatrolPathComponent::GetPatrolPathPointIndex()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.GetPatrolPathPointIndex");
    
        UAIPatrolPathComponent___GetPatrolPathPointIndex_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAIPatrolPathComponent::GetPatrolPathPointIndexFromDevice()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.GetPatrolPathPointIndexFromDevice");
    
        UAIPatrolPathComponent___GetPatrolPathPointIndexFromDevice_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAIPatrolPathComponent::HasValidPatrolPath()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.HasValidPatrolPath");
    
        UAIPatrolPathComponent___HasValidPatrolPath_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAIPatrolPathComponent::NextPatrolPointFailedToReach(AFortAthenaPatrolPoint* PathPoint, AAIController* PatrolInstigator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.NextPatrolPointFailedToReach");
    
        UAIPatrolPathComponent___NextPatrolPointFailedToReach_Params Params{};
        Params.PathPoint = PathPoint;
        Params.PatrolInstigator = PatrolInstigator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPatrolPathComponent::NotifyEditorUserOptionChanged(TArray<FString>& UserOptions)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.NotifyEditorUserOptionChanged");
    
        UAIPatrolPathComponent___NotifyEditorUserOptionChanged_Params Params{};
        Params.UserOptions = UserOptions;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        UserOptions = Params.UserOptions;
    }

    void UAIPatrolPathComponent::OnAnyPropertyChanged()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.OnAnyPropertyChanged");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAIPatrolPathComponent::OnPathExtremitiesChanged(bool bIsStart, bool bIsEnd)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.OnPathExtremitiesChanged");
    
        UAIPatrolPathComponent___OnPathExtremitiesChanged_Params Params{};
        Params.bIsStart = bIsStart;
        Params.bIsEnd = bIsEnd;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPatrolPathComponent::OnPatrolPathActorAssigned()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.OnPatrolPathActorAssigned");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAIPatrolPathComponent::PatrolPathStarted(AAIController* Instigator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.PatrolPathStarted");
    
        UAIPatrolPathComponent___PatrolPathStarted_Params Params{};
        Params.Instigator = Instigator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPatrolPathComponent::PatrolPathStopped(AAIController* Instigator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.PatrolPathStopped");
    
        UAIPatrolPathComponent___PatrolPathStopped_Params Params{};
        Params.Instigator = Instigator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPatrolPathComponent::PatrolPointFailedToReach(AFortAthenaPatrolPoint* PathPoint, AAIController* Instigator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.PatrolPointFailedToReach");
    
        UAIPatrolPathComponent___PatrolPointFailedToReach_Params Params{};
        Params.PathPoint = PathPoint;
        Params.Instigator = Instigator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPatrolPathComponent::PatrolPointReached(AFortAthenaPatrolPoint* PathPoint, AAIController* Instigator, bool bReachedBackward)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.PatrolPointReached");
    
        UAIPatrolPathComponent___PatrolPointReached_Params Params{};
        Params.PathPoint = PathPoint;
        Params.Instigator = Instigator;
        Params.bReachedBackward = bReachedBackward;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPatrolPathComponent::PostFinishSpawningActor()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.PostFinishSpawningActor");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAIPatrolPathComponent::PropagatePatrolPathIndexToDevice(int32 NewPatrolPathIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.PropagatePatrolPathIndexToDevice");
    
        UAIPatrolPathComponent___PropagatePatrolPathIndexToDevice_Params Params{};
        Params.NewPatrolPathIndex = NewPatrolPathIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPatrolPathComponent::PropagatePatrolPathPointIndexToDevice(int32 NewPatrolPathPointIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.PropagatePatrolPathPointIndexToDevice");
    
        UAIPatrolPathComponent___PropagatePatrolPathPointIndexToDevice_Params Params{};
        Params.NewPatrolPathPointIndex = NewPatrolPathPointIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UAIPatrolPathComponent::RemovePoint()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.RemovePoint");
    
        UAIPatrolPathComponent___RemovePoint_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAIPatrolPathComponent::RenderToNextAndPreviousPoint()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.RenderToNextAndPreviousPoint");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAIPatrolPathComponent::RenderToNextPoint()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.RenderToNextPoint");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAIPatrolPathComponent::RequestRenderPath()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.RequestRenderPath");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAIPatrolPathComponent::SetPatrollingMode(EPatrollingMode NewMode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.SetPatrollingMode");
    
        UAIPatrolPathComponent___SetPatrollingMode_Params Params{};
        Params.NewMode = NewMode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPatrolPathComponent::SetPatrolPathEnabled(bool bIsEnabled)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.SetPatrolPathEnabled");
    
        UAIPatrolPathComponent___SetPatrolPathEnabled_Params Params{};
        Params.bIsEnabled = bIsEnabled;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPatrolPathComponent::SetPatrolPathGroup(EFortCreativePatrolPathGroup PatrolPathGroup)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.SetPatrolPathGroup");
    
        UAIPatrolPathComponent___SetPatrolPathGroup_Params Params{};
        Params.PatrolPathGroup = PatrolPathGroup;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIPatrolPathComponent::SetRenderPath(bool bRenderPath)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.SetRenderPath");
    
        UAIPatrolPathComponent___SetRenderPath_Params Params{};
        Params.bRenderPath = bRenderPath;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UAIPatrolPathComponent::ShouldRenderPath()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.ShouldRenderPath");
    
        UAIPatrolPathComponent___ShouldRenderPath_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAIPatrolPathComponent::UpdateEditorComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPatrolPath.AIPatrolPathComponent.UpdateEditorComponent");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

} // namespace UE

