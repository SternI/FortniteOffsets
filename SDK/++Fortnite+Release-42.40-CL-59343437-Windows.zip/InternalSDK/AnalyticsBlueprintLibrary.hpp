/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnalyticsBlueprintLibrary
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class UAnalyticsBlueprintLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static void                EndSession(); // 0x0E3EA260 [Final | Native | Static | Public | BlueprintCallable]
        static void                FlushEvents(); // 0x0E3EA276 [Final | Native | Static | Public | BlueprintCallable]
        static FString             GetSessionId(); // 0x0E3EA28C [Final | Native | Static | Public | BlueprintCallable]
        static FString             GetUserId(); // 0x0E3EA3BC [Final | Native | Static | Public | BlueprintCallable]
        static FAnalyticsEventAttr MakeEventAttribute(FString AttributeName, FString AttributeValue); // 0x055E7A80 [Final | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static void                RecordCurrencyGiven(FString GameCurrencyType, int32 GameCurrencyAmount); // 0x055E7E12 [Final | Native | Static | Public | BlueprintCallable]
        static void                RecordCurrencyGivenWithAttributes(FString GameCurrencyType, int32 GameCurrencyAmount, TArray<FAnalyticsEventAttr>& Attributes); // 0x055E81EC [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                RecordCurrencyPurchase(FString GameCurrencyType, int32 GameCurrencyAmount, FString RealCurrencyType, float RealMoneyCost, FString PaymentProvider); // 0x055E873C [Final | Native | Static | Public | BlueprintCallable]
        static void                RecordError(FString Error); // 0x055E8E94 [Final | Native | Static | Public | BlueprintCallable]
        static void                RecordErrorWithAttributes(FString Error, TArray<FAnalyticsEventAttr>& Attributes); // 0x055E9158 [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                RecordEvent(FString EventName); // 0x055E9590 [Final | Native | Static | Public | BlueprintCallable]
        static void                RecordEventWithAttribute(FString EventName, FString AttributeName, FString AttributeValue); // 0x055E9850 [Final | Native | Static | Public | BlueprintCallable]
        static void                RecordEventWithAttributes(FString EventName, TArray<FAnalyticsEventAttr>& Attributes); // 0x055E9EF6 [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                RecordItemPurchase(FString ItemID, FString Currency, int32 PerItemCost, int32 ItemQuantity); // 0x055EA32E [Final | Native | Static | Public | BlueprintCallable]
        static void                RecordProgress(FString ProgressType, FString ProgressName); // 0x055EA944 [Final | Native | Static | Public | BlueprintCallable]
        static void                RecordProgressWithAttributes(FString ProgressType, FString ProgressName, TArray<FAnalyticsEventAttr>& Attributes); // 0x055EAD2A [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                RecordProgressWithFullHierarchyAndAttributes(FString ProgressType, TArray<FString>& ProgressNames, TArray<FAnalyticsEventAttr>& Attributes); // 0x055EB282 [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                RecordSimpleCurrencyPurchase(FString GameCurrencyType, int32 GameCurrencyAmount); // 0x055EB802 [Final | Native | Static | Public | BlueprintCallable]
        static void                RecordSimpleCurrencyPurchaseWithAttributes(FString GameCurrencyType, int32 GameCurrencyAmount, TArray<FAnalyticsEventAttr>& Attributes); // 0x055EBBDC [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                RecordSimpleItemPurchase(FString ItemID, int32 ItemQuantity); // 0x055EC12C [Final | Native | Static | Public | BlueprintCallable]
        static void                RecordSimpleItemPurchaseWithAttributes(FString ItemID, int32 ItemQuantity, TArray<FAnalyticsEventAttr>& Attributes); // 0x055EC506 [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                SetAge(int32 Age); // 0x055ECA56 [Final | Native | Static | Public | BlueprintCallable]
        static void                SetBuildInfo(FString BuildInfo); // 0x055ECD08 [Final | Native | Static | Public | BlueprintCallable]
        static void                SetGender(FString Gender); // 0x055ECFC8 [Final | Native | Static | Public | BlueprintCallable]
        static void                SetLocation(FString Location); // 0x055ED288 [Final | Native | Static | Public | BlueprintCallable]
        static void                SetSessionId(FString SessionID); // 0x055ED548 [Final | Native | Static | Public | BlueprintCallable]
        static void                SetUserId(FString UserId); // 0x055ED808 [Final | Native | Static | Public | BlueprintCallable]
        static bool                StartSession(); // 0x0E3EA4EC [Final | Native | Static | Public | BlueprintCallable]
        static bool                StartSessionWithAttributes(TArray<FAnalyticsEventAttr>& Attributes); // 0x055EDC5C [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FAnalyticsEventAttr
    {
        FString Name;   // 0x000000 (0x000010)
        FString Value;  // 0x000010 (0x000010)
    };
}

