/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BattleTracksRuntime_Functions
 * ============================================================
 */

#include "BattleTracksRuntime_Functions.hpp"

namespace UE
{

    void UBattleTracksPlayerComponent::BP_HandlePlayerPlaceChanged(int32 Placement)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleTracksRuntime.BattleTracksPlayerComponent.BP_HandlePlayerPlaceChanged");
    
        UBattleTracksPlayerComponent___BP_HandlePlayerPlaceChanged_Params Params{};
        Params.Placement = Placement;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBattleTracksPlayerComponent::BP_HandlePossessedPawnChanged(APawn* OldPawn, APawn* NewPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleTracksRuntime.BattleTracksPlayerComponent.BP_HandlePossessedPawnChanged");
    
        UBattleTracksPlayerComponent___BP_HandlePossessedPawnChanged_Params Params{};
        Params.OldPawn = OldPawn;
        Params.NewPawn = NewPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBattleTracksPlayerComponent::BP_HandleSparksLoadoutFilled()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleTracksRuntime.BattleTracksPlayerComponent.BP_HandleSparksLoadoutFilled");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    TScriptInterface<IFortMusicItem> UBattleTracksPlayerComponent::GetSongInMomentSlot(FGameplayTag& MomentTag)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleTracksRuntime.BattleTracksPlayerComponent.GetSongInMomentSlot");
    
        UBattleTracksPlayerComponent___GetSongInMomentSlot_Params Params{};
        Params.MomentTag = MomentTag;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        MomentTag = Params.MomentTag;
    
        return Params.ReturnValue;
    }

    void UBattleTracksPlayerComponent::HandlePlayerPlaceChanged()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleTracksRuntime.BattleTracksPlayerComponent.HandlePlayerPlaceChanged");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBattleTracksPlayerComponent::HandlePlaySongEvent(FFortBattleTracksPlaySongEvent& Event)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleTracksRuntime.BattleTracksPlayerComponent.HandlePlaySongEvent");
    
        UBattleTracksPlayerComponent___HandlePlaySongEvent_Params Params{};
        Params.Event = Event;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Event = Params.Event;
    }

    void UBattleTracksPlayerComponent::HandlePossessedPawnChanged(APawn* OldPawn, APawn* NewPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleTracksRuntime.BattleTracksPlayerComponent.HandlePossessedPawnChanged");
    
        UBattleTracksPlayerComponent___HandlePossessedPawnChanged_Params Params{};
        Params.OldPawn = OldPawn;
        Params.NewPawn = NewPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBattleTracksPlayerComponent::HandlePrepareSongEvent(FFortBattleTracksPrepareSongEvent& Event)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleTracksRuntime.BattleTracksPlayerComponent.HandlePrepareSongEvent");
    
        UBattleTracksPlayerComponent___HandlePrepareSongEvent_Params Params{};
        Params.Event = Event;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Event = Params.Event;
    }

    void UBattleTracksPlayerComponent::HandleSparksLoadoutFilled()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleTracksRuntime.BattleTracksPlayerComponent.HandleSparksLoadoutFilled");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBattleTracksPlayerComponent::HandleStopSongEvent(FFortBattleTracksStopSongEvent& Event)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleTracksRuntime.BattleTracksPlayerComponent.HandleStopSongEvent");
    
        UBattleTracksPlayerComponent___HandleStopSongEvent_Params Params{};
        Params.Event = Event;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Event = Params.Event;
    }

    void UBattleTracksPlayerComponent::PlayEquippedJamTrack(int32 Index, FFortMusicPlayerParams PlayerParams)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleTracksRuntime.BattleTracksPlayerComponent.PlayEquippedJamTrack");
    
        UBattleTracksPlayerComponent___PlayEquippedJamTrack_Params Params{};
        Params.Index = Index;
        Params.PlayerParams = PlayerParams;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBattleTracksPlayerComponent::PlayMomentTrack(FGameplayTag& MomentTag, FFortMusicPlayerParams PlayerParams)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleTracksRuntime.BattleTracksPlayerComponent.PlayMomentTrack");
    
        UBattleTracksPlayerComponent___PlayMomentTrack_Params Params{};
        Params.MomentTag = MomentTag;
        Params.PlayerParams = PlayerParams;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        MomentTag = Params.MomentTag;
    }

    void UBattleTracksPlayerComponent::PrepareEquippedJamTrack(int32 Index, FFortMusicPlayerParams PlayerParams)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleTracksRuntime.BattleTracksPlayerComponent.PrepareEquippedJamTrack");
    
        UBattleTracksPlayerComponent___PrepareEquippedJamTrack_Params Params{};
        Params.Index = Index;
        Params.PlayerParams = PlayerParams;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBattleTracksPlayerComponent::PrepareMomentTrack(FGameplayTag& MomentTag, FFortMusicPlayerParams PlayerParams)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleTracksRuntime.BattleTracksPlayerComponent.PrepareMomentTrack");
    
        UBattleTracksPlayerComponent___PrepareMomentTrack_Params Params{};
        Params.MomentTag = MomentTag;
        Params.PlayerParams = PlayerParams;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        MomentTag = Params.MomentTag;
    }

    void UBattleTracksPlayerComponent::PrepareSong(TScriptInterface<IFortMusicItem> Song, FFortMusicPlayerParams PlayerParams)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleTracksRuntime.BattleTracksPlayerComponent.PrepareSong");
    
        UBattleTracksPlayerComponent___PrepareSong_Params Params{};
        Params.Song = Song;
        Params.PlayerParams = PlayerParams;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UBattleTracksPlayerComponent::ShouldPrepareVictorySongEarly()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleTracksRuntime.BattleTracksPlayerComponent.ShouldPrepareVictorySongEarly");
    
        UBattleTracksPlayerComponent___ShouldPrepareVictorySongEarly_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBattleTracksPlayerComponent::StopSong(float FadeOutTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleTracksRuntime.BattleTracksPlayerComponent.StopSong");
    
        UBattleTracksPlayerComponent___StopSong_Params Params{};
        Params.FadeOutTime = FadeOutTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

