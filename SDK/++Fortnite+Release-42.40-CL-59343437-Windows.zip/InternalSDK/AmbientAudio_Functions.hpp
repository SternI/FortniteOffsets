/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AmbientAudio_Functions
 * ============================================================
 */

#include "AmbientAudio.hpp"

namespace UE
{

    struct UAmbientAudioComponent___SetAmbientAsset_Params
    {
        UAmbientAudioDataAsset* InAmbientAsset; // 0x000000 (0x000008) [Default: 0x1368F820]
    };

    struct UAmbientAudioComponent___SetCrossfadeTime_Params
    {
        float   InCrossfadeTime;    // 0x000000 (0x000004) [Default: 2.94049e-27f]
    };

    struct UAmbientAudioComponent___SetPriority_Params
    {
        int32   InPriority; // 0x000000 (0x000004) [Default: 325646368]
    };

    struct UAmbientAudioSubsystem___AddAmbientEntry_Params
    {
        FName                   AmbientName;                    // 0x000000 (0x000004) [Default: FName(325648352) -> L""]
        uint8                   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UAmbientAudioDataAsset* Asset;                          // 0x000008 (0x000008) [Default: 0xBC2418DD00000031]
        int32                   Priority;                       // 0x000010 (0x000004) [Default: 392635600]
        float                   CrossfadeTime;                  // 0x000014 (0x000004) [Default: 0f]
    };

    struct UAmbientAudioSubsystem___AddGameplayTag_Params
    {
        FGameplayTag    GameplayTag;    // 0x000000 (0x000004)
    };

    struct UAmbientAudioSubsystem___GetAudioParameterComponent_Params
    {
        UAudioParameterComponent*   ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1368FFE0]
    };

    struct UAmbientAudioSubsystem___RemoveAmbientEntry_Params
    {
        FName   AmbientName;        // 0x000000 (0x000004) [Default: FName(325648352) -> L""]
        float   CrossfadeOverride;  // 0x000004 (0x000004) [Default: 0f]
    };

    struct UAmbientAudioSubsystem___RemoveGameplayTag_Params
    {
        FGameplayTag    GameplayTag;    // 0x000000 (0x000004)
    };

} // namespace UE

