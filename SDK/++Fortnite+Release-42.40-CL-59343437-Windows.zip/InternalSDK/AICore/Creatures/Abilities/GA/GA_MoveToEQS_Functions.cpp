/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:48
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AICore/Creatures/Abilities/GA/GA_MoveToEQS_Functions
 * ============================================================
 */

#include "GA_MoveToEQS_Functions.hpp"

namespace UE
{

    void UGA_MoveToEQS_C::ExecuteUbergraph_GA_MoveToEQS(int32 EntryPoint, TEnumAsByte<EPathFollowingResult> K2Node_CustomEvent_Result_1, AAIController* K2Node_CustomEvent_AIController_1, GenericGameplayTaskDelegate K2Node_CreateDelegate_OutputDelegate, MoveAIDelegate K2Node_CreateDelegate_OutputDelegate_1, MoveAIDelegate K2Node_CreateDelegate_OutputDelegate_2, MoveAIDelegate K2Node_CreateDelegate_OutputDelegate_3, bool CallFunc_IsValid_ReturnValue, bool K2Node_Event_bWasCancelled, bool CallFunc_K2_CommitAbility_ReturnValue, AActor* CallFunc_GetAvatarActorFromActorInfo_ReturnValue, EQSQueryDoneSignature K2Node_CreateDelegate_OutputDelegate_4, UEnvQueryInstanceBlueprintWrapper* K2Node_CustomEvent_QueryInstance_1, TEnumAsByte<EEnvQueryStatus> K2Node_CustomEvent_QueryStatus, bool K2Node_SwitchEnum_CmpSuccess, MoveTaskCompletedSignature K2Node_CreateDelegate_OutputDelegate_5, bool CallFunc_IsValid_ReturnValue_1, UEnvQueryInstanceBlueprintWrapper* CallFunc_RunEQSQuery_ReturnValue, UEnvQueryInstanceBlueprintWrapper* K2Node_CustomEvent_QueryInstance, TArray<FVector> CallFunc_GetQueryResultsAsLocations_ResultLocations, bool CallFunc_GetQueryResultsAsLocations_ReturnValue, FVector CallFunc_Array_Get_Item, UFortAbilityTask_MoveAI* CallFunc_CreateMoveAITask_ReturnValue, MoveTaskCompletedSignature K2Node_CreateDelegate_OutputDelegate_6, bool CallFunc_IsValid_ReturnValue_2, bool CallFunc_IsValid_ReturnValue_3, TEnumAsByte<EPathFollowingResult> K2Node_CustomEvent_Result, AAIController* K2Node_CustomEvent_AIController, bool CallFunc_IsValid_ReturnValue_4)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_MoveToEQS.GA_MoveToEQS_C.ExecuteUbergraph_GA_MoveToEQS");
    
        UGA_MoveToEQS_C___ExecuteUbergraph_GA_MoveToEQS_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.K2Node_CustomEvent_Result_1 = K2Node_CustomEvent_Result_1;
        Params.K2Node_CustomEvent_AIController_1 = K2Node_CustomEvent_AIController_1;
        Params.K2Node_CreateDelegate_OutputDelegate = K2Node_CreateDelegate_OutputDelegate;
        Params.K2Node_CreateDelegate_OutputDelegate_1 = K2Node_CreateDelegate_OutputDelegate_1;
        Params.K2Node_CreateDelegate_OutputDelegate_2 = K2Node_CreateDelegate_OutputDelegate_2;
        Params.K2Node_CreateDelegate_OutputDelegate_3 = K2Node_CreateDelegate_OutputDelegate_3;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.K2Node_Event_bWasCancelled = K2Node_Event_bWasCancelled;
        Params.CallFunc_K2_CommitAbility_ReturnValue = CallFunc_K2_CommitAbility_ReturnValue;
        Params.CallFunc_GetAvatarActorFromActorInfo_ReturnValue = CallFunc_GetAvatarActorFromActorInfo_ReturnValue;
        Params.K2Node_CreateDelegate_OutputDelegate_4 = K2Node_CreateDelegate_OutputDelegate_4;
        Params.K2Node_CustomEvent_QueryInstance_1 = K2Node_CustomEvent_QueryInstance_1;
        Params.K2Node_CustomEvent_QueryStatus = K2Node_CustomEvent_QueryStatus;
        Params.K2Node_SwitchEnum_CmpSuccess = K2Node_SwitchEnum_CmpSuccess;
        Params.K2Node_CreateDelegate_OutputDelegate_5 = K2Node_CreateDelegate_OutputDelegate_5;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
        Params.CallFunc_RunEQSQuery_ReturnValue = CallFunc_RunEQSQuery_ReturnValue;
        Params.K2Node_CustomEvent_QueryInstance = K2Node_CustomEvent_QueryInstance;
        Params.CallFunc_GetQueryResultsAsLocations_ResultLocations = CallFunc_GetQueryResultsAsLocations_ResultLocations;
        Params.CallFunc_GetQueryResultsAsLocations_ReturnValue = CallFunc_GetQueryResultsAsLocations_ReturnValue;
        Params.CallFunc_Array_Get_Item = CallFunc_Array_Get_Item;
        Params.CallFunc_CreateMoveAITask_ReturnValue = CallFunc_CreateMoveAITask_ReturnValue;
        Params.K2Node_CreateDelegate_OutputDelegate_6 = K2Node_CreateDelegate_OutputDelegate_6;
        Params.CallFunc_IsValid_ReturnValue_2 = CallFunc_IsValid_ReturnValue_2;
        Params.CallFunc_IsValid_ReturnValue_3 = CallFunc_IsValid_ReturnValue_3;
        Params.K2Node_CustomEvent_Result = K2Node_CustomEvent_Result;
        Params.K2Node_CustomEvent_AIController = K2Node_CustomEvent_AIController;
        Params.CallFunc_IsValid_ReturnValue_4 = CallFunc_IsValid_ReturnValue_4;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_MoveToEQS_C::K2_ActivateAbility()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_MoveToEQS.GA_MoveToEQS_C.K2_ActivateAbility");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_MoveToEQS_C::K2_OnEndAbility(bool bWasCancelled)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_MoveToEQS.GA_MoveToEQS_C.K2_OnEndAbility");
    
        UGA_MoveToEQS_C___K2_OnEndAbility_Params Params{};
        Params.bWasCancelled = bWasCancelled;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_MoveToEQS_C::OnCancelled_050279F248D554A456C983A3C99B6099()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_MoveToEQS.GA_MoveToEQS_C.OnCancelled_050279F248D554A456C983A3C99B6099");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_MoveToEQS_C::OnComplete_050279F248D554A456C983A3C99B6099()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_MoveToEQS.GA_MoveToEQS_C.OnComplete_050279F248D554A456C983A3C99B6099");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_MoveToEQS_C::OnEQSQueryFinished(UEnvQueryInstanceBlueprintWrapper* QueryInstance, TEnumAsByte<EEnvQueryStatus> QueryStatus)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_MoveToEQS.GA_MoveToEQS_C.OnEQSQueryFinished");
    
        UGA_MoveToEQS_C___OnEQSQueryFinished_Params Params{};
        Params.QueryInstance = QueryInstance;
        Params.QueryStatus = QueryStatus;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_MoveToEQS_C::OnInterrupted_050279F248D554A456C983A3C99B6099()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_MoveToEQS.GA_MoveToEQS_C.OnInterrupted_050279F248D554A456C983A3C99B6099");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_MoveToEQS_C::OnMoveFinished_050279F248D554A456C983A3C99B6099(TEnumAsByte<EPathFollowingResult> Result, AAIController* AIController)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_MoveToEQS.GA_MoveToEQS_C.OnMoveFinished_050279F248D554A456C983A3C99B6099");
    
        UGA_MoveToEQS_C___OnMoveFinished_050279F248D554A456C983A3C99B6099_Params Params{};
        Params.Result = Result;
        Params.AIController = AIController;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_MoveToEQS_C::OnMovementFinished(TEnumAsByte<EPathFollowingResult> Result, AAIController* AIController)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_MoveToEQS.GA_MoveToEQS_C.OnMovementFinished");
    
        UGA_MoveToEQS_C___OnMovementFinished_Params Params{};
        Params.Result = Result;
        Params.AIController = AIController;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_MoveToEQS_C::OnQueryFailed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_MoveToEQS.GA_MoveToEQS_C.OnQueryFailed");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_MoveToEQS_C::OnQuerySuccess(UEnvQueryInstanceBlueprintWrapper* QueryInstance)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_MoveToEQS.GA_MoveToEQS_C.OnQuerySuccess");
    
        UGA_MoveToEQS_C___OnQuerySuccess_Params Params{};
        Params.QueryInstance = QueryInstance;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_MoveToEQS_C::OnRequestFailed_050279F248D554A456C983A3C99B6099()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_MoveToEQS.GA_MoveToEQS_C.OnRequestFailed_050279F248D554A456C983A3C99B6099");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_MoveToEQS_C::RunEQS()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_MoveToEQS.GA_MoveToEQS_C.RunEQS");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

} // namespace UE

