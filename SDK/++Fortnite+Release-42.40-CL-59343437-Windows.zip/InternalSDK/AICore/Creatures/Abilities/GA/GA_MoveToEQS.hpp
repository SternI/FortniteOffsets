/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:48
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AICore/Creatures/Abilities/GA/GA_MoveToEQS
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000B78 (0x000058)
    class alignas(0x8) UGA_MoveToEQS_C : public UFortGameplayAbility
    {
    public:
        FPointerToUberGraphFrame            UberGraphFrame;                     // 0x000B20 (0x000008)
        UEnvQuery*                          EQS;                                // 0x000B28 (0x000008) [Default: nullptr]
        TEnumAsByte<EEnvQueryRunMode>       EQSRunMode;                         // 0x000B30 (0x000001) [Default: 0]
        uint8                               UnknownData_000B31[0x000007];       // 0x000B31 (0x000007)
        UEnvQueryInstanceBlueprintWrapper*  EQSQueryInstance;                   // 0x000B38 (0x000008) [Default: nullptr]
        TEnumAsByte<EPawnActionMoveMode>    MoveAIMode;                         // 0x000B40 (0x000001) [Default: 0]
        uint8                               UnknownData_000B41[0x000007];       // 0x000B41 (0x000007)
        UClass*                             EQSWrapperClass;                    // 0x000B48 (0x000008) [Default: nullptr]
        TEnumAsByte<EPathObstacleAction>    MoveAIPathObstacleAction;           // 0x000B50 (0x000001) [Default: 1]
        uint8                               UnknownData_000B51[0x000003];       // 0x000B51 (0x000003)
        float                               MoveAIAcceptableRadius;             // 0x000B54 (0x000004) [Default: 50f]
        bool                                MoveAIStopAtEnd;                    // 0x000B58 (0x000001) [Default: true]
        TEnumAsByte<EAIOptionFlag>          MoveAIAcceptPartialPath;            // 0x000B59 (0x000001) [Default: 0]
        bool                                MoveAIFinishOnPlayerCollision;      // 0x000B5A (0x000001) [Default: false]
        bool                                MoveAIProjectGoalLocationOnNavMesh; // 0x000B5B (0x000001) [Default: true]
        uint8                               UnknownData_000B5C[0x000004];       // 0x000B5C (0x000004)
        UClass*                             MoveAINavFilterClass;               // 0x000B60 (0x000008) [Default: nullptr]
        FGameplayTag                        MoveAINavFilterTag;                 // 0x000B68 (0x000004)
        TEnumAsByte<EAIOptionFlag>          MoveAIRequireNavigableEndLocation;  // 0x000B6C (0x000001) [Default: 0]
        bool                                MoveAIUseContinuousGoalTracking;    // 0x000B6D (0x000001) [Default: false]
        uint8                               UnknownData_000B6E[0x000002];       // 0x000B6E (0x000002)
        UFortAbilityTask_MoveAI*            MoveAIAsyncTask;                    // 0x000B70 (0x000008) [Default: nullptr]
    
    public: // Functions
        void    ExecuteUbergraph_GA_MoveToEQS(int32 EntryPoint, TEnumAsByte<EPathFollowingResult> K2Node_CustomEvent_Result_1, AAIController* K2Node_CustomEvent_AIController_1, GenericGameplayTaskDelegate K2Node_CreateDelegate_OutputDelegate, MoveAIDelegate K2Node_CreateDelegate_OutputDelegate_1, MoveAIDelegate K2Node_CreateDelegate_OutputDelegate_2, MoveAIDelegate K2Node_CreateDelegate_OutputDelegate_3, bool CallFunc_IsValid_ReturnValue, bool K2Node_Event_bWasCancelled, bool CallFunc_K2_CommitAbility_ReturnValue, AActor* CallFunc_GetAvatarActorFromActorInfo_ReturnValue, EQSQueryDoneSignature K2Node_CreateDelegate_OutputDelegate_4, UEnvQueryInstanceBlueprintWrapper* K2Node_CustomEvent_QueryInstance_1, TEnumAsByte<EEnvQueryStatus> K2Node_CustomEvent_QueryStatus, bool K2Node_SwitchEnum_CmpSuccess, MoveTaskCompletedSignature K2Node_CreateDelegate_OutputDelegate_5, bool CallFunc_IsValid_ReturnValue_1, UEnvQueryInstanceBlueprintWrapper* CallFunc_RunEQSQuery_ReturnValue, UEnvQueryInstanceBlueprintWrapper* K2Node_CustomEvent_QueryInstance, TArray<FVector> CallFunc_GetQueryResultsAsLocations_ResultLocations, bool CallFunc_GetQueryResultsAsLocations_ReturnValue, FVector CallFunc_Array_Get_Item, UFortAbilityTask_MoveAI* CallFunc_CreateMoveAITask_ReturnValue, MoveTaskCompletedSignature K2Node_CreateDelegate_OutputDelegate_6, bool CallFunc_IsValid_ReturnValue_2, bool CallFunc_IsValid_ReturnValue_3, TEnumAsByte<EPathFollowingResult> K2Node_CustomEvent_Result, AAIController* K2Node_CustomEvent_AIController, bool CallFunc_IsValid_ReturnValue_4); // 0x000545D2 [Final | UbergraphFunction]
        void    K2_ActivateAbility(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    K2_OnEndAbility(bool bWasCancelled); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnCancelled_050279F248D554A456C983A3C99B6099(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnComplete_050279F248D554A456C983A3C99B6099(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnEQSQueryFinished(UEnvQueryInstanceBlueprintWrapper* QueryInstance, TEnumAsByte<EEnvQueryStatus> QueryStatus); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnInterrupted_050279F248D554A456C983A3C99B6099(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnMoveFinished_050279F248D554A456C983A3C99B6099(TEnumAsByte<EPathFollowingResult> Result, AAIController* AIController); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnMovementFinished(TEnumAsByte<EPathFollowingResult> Result, AAIController* AIController); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnQueryFailed(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnQuerySuccess(UEnvQueryInstanceBlueprintWrapper* QueryInstance); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnRequestFailed_050279F248D554A456C983A3C99B6099(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    RunEQS(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
    };
}

