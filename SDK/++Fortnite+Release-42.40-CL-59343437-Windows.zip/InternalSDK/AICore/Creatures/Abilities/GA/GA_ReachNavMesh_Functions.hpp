/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:27
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AICore/Creatures/Abilities/GA/GA_ReachNavMesh_Functions
 * ============================================================
 */

#include "GA_ReachNavMesh.hpp"

namespace UE
{

    struct UGA_ReachNavMesh_C___ExecuteUbergraph_GA_ReachNavMesh_Params
    {
        int32                               EntryPoint;                                             // 0x000000 (0x000004) [Default: 329745536]
        TEnumAsByte<EPathFollowingResult>   K2Node_CustomEvent_Result;                              // 0x000004 (0x000001) [Default: 0]
        uint8                               UnknownData_000005[0x000003];                           // 0x000005 (0x000003)
        AAIController*                      K2Node_CustomEvent_AIController;                        // 0x000008 (0x000008) [Default: 0x93C41DDD00280031]
        GenericGameplayTaskDelegate         K2Node_CreateDelegate_OutputDelegate;                   // 0x000010 (0x00000C)
        MoveAIDelegate                      K2Node_CreateDelegate_OutputDelegate_1;                 // 0x00001C (0x00000C)
        MoveAIDelegate                      K2Node_CreateDelegate_OutputDelegate_2;                 // 0x000028 (0x00000C)
        MoveAIDelegate                      K2Node_CreateDelegate_OutputDelegate_3;                 // 0x000034 (0x00000C)
        GenericGameplayTaskDelegate         K2Node_CreateDelegate_OutputDelegate_4;                 // 0x000040 (0x00000C)
        GenericGameplayTaskDelegate         K2Node_CreateDelegate_OutputDelegate_5;                 // 0x00004C (0x00000C)
        bool                                K2Node_Event_bWasCancelled;                             // 0x000058 (0x000001) [Default: true]
        bool                                CallFunc_K2_CommitAbility_ReturnValue;                  // 0x000059 (0x000001) [Default: false]
        uint8                               UnknownData_00005A[0x000006];                           // 0x00005A (0x000006)
        AActor*                             CallFunc_GetAvatarActorFromActorInfo_ReturnValue;       // 0x000060 (0x000008) [Default: nullptr]
        EQSQueryDoneSignature               K2Node_CreateDelegate_OutputDelegate_6;                 // 0x000068 (0x00000C)
        uint8                               UnknownData_000074[0x000004];                           // 0x000074 (0x000004)
        UEnvQueryInstanceBlueprintWrapper*  CallFunc_RunEQSQuery_ReturnValue;                       // 0x000078 (0x000008) [Default: nullptr]
        UEnvQueryInstanceBlueprintWrapper*  K2Node_CustomEvent_QueryInstance;                       // 0x000080 (0x000008) [Default: nullptr]
        TEnumAsByte<EEnvQueryStatus>        K2Node_CustomEvent_QueryStatus;                         // 0x000088 (0x000001) [Default: 2]
        bool                                K2Node_SwitchEnum_CmpSuccess;                           // 0x000089 (0x000001) [Default: false]
        uint8                               UnknownData_00008A[0x000006];                           // 0x00008A (0x000006)
        TArray<FVector>                     CallFunc_GetQueryResultsAsLocations_ResultLocations;    // 0x000090 (0x000010)
        bool                                CallFunc_GetQueryResultsAsLocations_ReturnValue;        // 0x0000A0 (0x000001) [Default: true]
        uint8                               UnknownData_0000A1[0x000007];                           // 0x0000A1 (0x000007)
        FVector                             CallFunc_Array_Get_Item;                                // 0x0000A8 (0x000018)
        UFortAbilityTask_MoveAI*            CallFunc_CreateMoveAITask_ReturnValue;                  // 0x0000C0 (0x000008) [Default: 0x800000007]
        MoveTaskCompletedSignature          K2Node_CreateDelegate_OutputDelegate_7;                 // 0x0000C8 (0x00000C)
        bool                                CallFunc_IsValid_ReturnValue;                           // 0x0000D4 (0x000001) [Default: false]
        uint8                               UnknownData_0000D5[0x000003];                           // 0x0000D5 (0x000003)
        UFortAbilityTask_RotateAIToFace*    CallFunc_RotateAIToFace_ReturnValue;                    // 0x0000D8 (0x000008) [Default: nullptr]
        bool                                CallFunc_IsValid_ReturnValue_1;                         // 0x0000E0 (0x000001) [Default: false]
        bool                                CallFunc_IsValid_ReturnValue_2;                         // 0x0000E1 (0x000001) [Default: false]
        bool                                CallFunc_IsValid_ReturnValue_3;                         // 0x0000E2 (0x000001) [Default: false]
        uint8                               UnknownByte_0000E3;                                     // 0x0000E3 (0x000001)
        EQSQueryDoneSignature               K2Node_CreateDelegate_OutputDelegate_8;                 // 0x0000E4 (0x00000C)
    };

    struct UGA_ReachNavMesh_C___K2_OnEndAbility_Params
    {
        bool    bWasCancelled;  // 0x000000 (0x000001) [Default: true]
    };

    struct UGA_ReachNavMesh_C___OnEQSProcessed_Params
    {
        UEnvQueryInstanceBlueprintWrapper*  QueryInstance;  // 0x000000 (0x000008) [Default: 0x13A78480]
        TEnumAsByte<EEnvQueryStatus>        QueryStatus;    // 0x000008 (0x000001) [Default: 49]
    };

    struct UGA_ReachNavMesh_C___OnMoveFinished_2CCC6DB948407106952B8FAE6A53321C_Params
    {
        TEnumAsByte<EPathFollowingResult>   Result;                         // 0x000000 (0x000001) [Default: 128]
        uint8                               UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        AAIController*                      AIController;                   // 0x000008 (0x000008) [Default: 0x93C41DDD00280031]
    };

} // namespace UE

