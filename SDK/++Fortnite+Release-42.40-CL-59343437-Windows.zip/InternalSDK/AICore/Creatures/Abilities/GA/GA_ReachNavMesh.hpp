/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:27
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AICore/Creatures/Abilities/GA/GA_ReachNavMesh
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000B40 (0x000020)
    class alignas(0x8) UGA_ReachNavMesh_C : public UFortGameplayAbility
    {
    public:
        FPointerToUberGraphFrame            UberGraphFrame;     // 0x000B20 (0x000008)
        UEnvQuery*                          Move_EQS;           // 0x000B28 (0x000008) [Default: nullptr]
        UFortAbilityTask_MoveAI*            MoveToAsyncTask;    // 0x000B30 (0x000008) [Default: nullptr]
        UEnvQueryInstanceBlueprintWrapper*  EQSQueryInstance;   // 0x000B38 (0x000008) [Default: nullptr]
    
    public: // Functions
        void    ExecuteUbergraph_GA_ReachNavMesh(int32 EntryPoint, TEnumAsByte<EPathFollowingResult> K2Node_CustomEvent_Result, AAIController* K2Node_CustomEvent_AIController, GenericGameplayTaskDelegate K2Node_CreateDelegate_OutputDelegate, MoveAIDelegate K2Node_CreateDelegate_OutputDelegate_1, MoveAIDelegate K2Node_CreateDelegate_OutputDelegate_2, MoveAIDelegate K2Node_CreateDelegate_OutputDelegate_3, GenericGameplayTaskDelegate K2Node_CreateDelegate_OutputDelegate_4, GenericGameplayTaskDelegate K2Node_CreateDelegate_OutputDelegate_5, bool K2Node_Event_bWasCancelled, bool CallFunc_K2_CommitAbility_ReturnValue, AActor* CallFunc_GetAvatarActorFromActorInfo_ReturnValue, EQSQueryDoneSignature K2Node_CreateDelegate_OutputDelegate_6, UEnvQueryInstanceBlueprintWrapper* CallFunc_RunEQSQuery_ReturnValue, UEnvQueryInstanceBlueprintWrapper* K2Node_CustomEvent_QueryInstance, TEnumAsByte<EEnvQueryStatus> K2Node_CustomEvent_QueryStatus, bool K2Node_SwitchEnum_CmpSuccess, TArray<FVector> CallFunc_GetQueryResultsAsLocations_ResultLocations, bool CallFunc_GetQueryResultsAsLocations_ReturnValue, FVector CallFunc_Array_Get_Item, UFortAbilityTask_MoveAI* CallFunc_CreateMoveAITask_ReturnValue, MoveTaskCompletedSignature K2Node_CreateDelegate_OutputDelegate_7, bool CallFunc_IsValid_ReturnValue, UFortAbilityTask_RotateAIToFace* CallFunc_RotateAIToFace_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, bool CallFunc_IsValid_ReturnValue_2, bool CallFunc_IsValid_ReturnValue_3, EQSQueryDoneSignature K2Node_CreateDelegate_OutputDelegate_8); // 0x000545D2 [Final | UbergraphFunction]
        void    K2_ActivateAbility(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    K2_OnEndAbility(bool bWasCancelled); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnCancelled_2CCC6DB948407106952B8FAE6A53321C(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnComplete_2CCC6DB948407106952B8FAE6A53321C(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnEQSProcessed(UEnvQueryInstanceBlueprintWrapper* QueryInstance, TEnumAsByte<EEnvQueryStatus> QueryStatus); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnFinished_7F7FBDD74EBB593FF845F0AF0BDF96BD(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnInterrupted_2CCC6DB948407106952B8FAE6A53321C(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnInterrupted_7F7FBDD74EBB593FF845F0AF0BDF96BD(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnMoveFinished_2CCC6DB948407106952B8FAE6A53321C(TEnumAsByte<EPathFollowingResult> Result, AAIController* AIController); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnRequestFailed_2CCC6DB948407106952B8FAE6A53321C(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    StartReachNavMeshEQS(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
    };
}

