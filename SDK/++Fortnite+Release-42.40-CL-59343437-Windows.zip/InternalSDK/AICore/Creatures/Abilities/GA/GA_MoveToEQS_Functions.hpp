/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:48
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AICore/Creatures/Abilities/GA/GA_MoveToEQS_Functions
 * ============================================================
 */

#include "GA_MoveToEQS.hpp"

namespace UE
{

    struct UGA_MoveToEQS_C___ExecuteUbergraph_GA_MoveToEQS_Params
    {
        int32                               EntryPoint;                                             // 0x000000 (0x000004) [Default: 329745536]
        TEnumAsByte<EPathFollowingResult>   K2Node_CustomEvent_Result_1;                            // 0x000004 (0x000001) [Default: 0]
        uint8                               UnknownData_000005[0x000003];                           // 0x000005 (0x000003)
        AAIController*                      K2Node_CustomEvent_AIController_1;                      // 0x000008 (0x000008) [Default: 0x29C61DDD00280031]
        GenericGameplayTaskDelegate         K2Node_CreateDelegate_OutputDelegate;                   // 0x000010 (0x00000C)
        MoveAIDelegate                      K2Node_CreateDelegate_OutputDelegate_1;                 // 0x00001C (0x00000C)
        MoveAIDelegate                      K2Node_CreateDelegate_OutputDelegate_2;                 // 0x000028 (0x00000C)
        MoveAIDelegate                      K2Node_CreateDelegate_OutputDelegate_3;                 // 0x000034 (0x00000C)
        bool                                CallFunc_IsValid_ReturnValue;                           // 0x000040 (0x000001) [Default: true]
        bool                                K2Node_Event_bWasCancelled;                             // 0x000041 (0x000001) [Default: false]
        bool                                CallFunc_K2_CommitAbility_ReturnValue;                  // 0x000042 (0x000001) [Default: false]
        uint8                               UnknownData_000043[0x000005];                           // 0x000043 (0x000005)
        AActor*                             CallFunc_GetAvatarActorFromActorInfo_ReturnValue;       // 0x000048 (0x000008) [Default: nullptr]
        EQSQueryDoneSignature               K2Node_CreateDelegate_OutputDelegate_4;                 // 0x000050 (0x00000C)
        uint8                               UnknownData_00005C[0x000004];                           // 0x00005C (0x000004)
        UEnvQueryInstanceBlueprintWrapper*  K2Node_CustomEvent_QueryInstance_1;                     // 0x000060 (0x000008) [Default: nullptr]
        TEnumAsByte<EEnvQueryStatus>        K2Node_CustomEvent_QueryStatus;                         // 0x000068 (0x000001) [Default: 0]
        bool                                K2Node_SwitchEnum_CmpSuccess;                           // 0x000069 (0x000001) [Default: false]
        uint8                               UnknownData_00006A[0x000002];                           // 0x00006A (0x000002)
        MoveTaskCompletedSignature          K2Node_CreateDelegate_OutputDelegate_5;                 // 0x00006C (0x00000C)
        bool                                CallFunc_IsValid_ReturnValue_1;                         // 0x000078 (0x000001) [Default: false]
        uint8                               UnknownData_000079[0x000007];                           // 0x000079 (0x000007)
        UEnvQueryInstanceBlueprintWrapper*  CallFunc_RunEQSQuery_ReturnValue;                       // 0x000080 (0x000008) [Default: nullptr]
        UEnvQueryInstanceBlueprintWrapper*  K2Node_CustomEvent_QueryInstance;                       // 0x000088 (0x000008) [Default: 0x2]
        TArray<FVector>                     CallFunc_GetQueryResultsAsLocations_ResultLocations;    // 0x000090 (0x000010)
        bool                                CallFunc_GetQueryResultsAsLocations_ReturnValue;        // 0x0000A0 (0x000001) [Default: true]
        uint8                               UnknownData_0000A1[0x000007];                           // 0x0000A1 (0x000007)
        FVector                             CallFunc_Array_Get_Item;                                // 0x0000A8 (0x000018)
        UFortAbilityTask_MoveAI*            CallFunc_CreateMoveAITask_ReturnValue;                  // 0x0000C0 (0x000008) [Default: 0x400000003]
        MoveTaskCompletedSignature          K2Node_CreateDelegate_OutputDelegate_6;                 // 0x0000C8 (0x00000C)
        bool                                CallFunc_IsValid_ReturnValue_2;                         // 0x0000D4 (0x000001) [Default: false]
        bool                                CallFunc_IsValid_ReturnValue_3;                         // 0x0000D5 (0x000001) [Default: false]
        TEnumAsByte<EPathFollowingResult>   K2Node_CustomEvent_Result;                              // 0x0000D6 (0x000001) [Default: 0]
        uint8                               UnknownByte_0000D7;                                     // 0x0000D7 (0x000001)
        AAIController*                      K2Node_CustomEvent_AIController;                        // 0x0000D8 (0x000008) [Default: nullptr]
        bool                                CallFunc_IsValid_ReturnValue_4;                         // 0x0000E0 (0x000001) [Default: false]
    };

    struct UGA_MoveToEQS_C___K2_OnEndAbility_Params
    {
        bool    bWasCancelled;  // 0x000000 (0x000001) [Default: true]
    };

    struct UGA_MoveToEQS_C___OnEQSQueryFinished_Params
    {
        UEnvQueryInstanceBlueprintWrapper*  QueryInstance;  // 0x000000 (0x000008) [Default: 0x13A78480]
        TEnumAsByte<EEnvQueryStatus>        QueryStatus;    // 0x000008 (0x000001) [Default: 49]
    };

    struct UGA_MoveToEQS_C___OnMoveFinished_050279F248D554A456C983A3C99B6099_Params
    {
        TEnumAsByte<EPathFollowingResult>   Result;                         // 0x000000 (0x000001) [Default: 128]
        uint8                               UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        AAIController*                      AIController;                   // 0x000008 (0x000008) [Default: 0x29C61DDD00280031]
    };

    struct UGA_MoveToEQS_C___OnMovementFinished_Params
    {
        TEnumAsByte<EPathFollowingResult>   Result;                         // 0x000000 (0x000001) [Default: 128]
        uint8                               UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        AAIController*                      AIController;                   // 0x000008 (0x000008) [Default: 0x29C61DDD00280031]
    };

    struct UGA_MoveToEQS_C___OnQuerySuccess_Params
    {
        UEnvQueryInstanceBlueprintWrapper*  QueryInstance;  // 0x000000 (0x000008) [Default: 0x13A78480]
    };

} // namespace UE

