/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:40
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AICore/Creatures/NavFilters/NavFilter_ReachNavMesh
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000048 (0x000000)
    class UNavFilter_ReachNavMesh_C : public UNavigationQueryFilter
    {
    public:
    };
}

