/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:37
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BattleRoyaleGameUI/Director/BP_BRGameUI_HUD_Component
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000110 (0x000050)
    class alignas(0x8) UBP_BRGameUI_HUD_Component_C : public UFortDynamicUIDirectorComponent
    {
    public:
        FPointerToUberGraphFrame            UberGraphFrame;         // 0x0000C0 (0x000008)
        TArray<UDynamicUIScene*>            DefaultHUDScenes;       // 0x0000C8 (0x000010)
        UDynamicUIScene*                    QuickbarHudScene;       // 0x0000D8 (0x000008) [Default: 0x7FEA19D9EE00]
        TArray<UDynamicUIScene*>            SquadListBottomScenes;  // 0x0000E0 (0x000010)
        UDynamicUIScene*                    KillFeedScene;          // 0x0000F0 (0x000008) [Default: 0x7FEA19874460]
        UDynamicUIScene*                    ChatOpenScene;          // 0x0000F8 (0x000008) [Default: 0x7FEA19D9EE70]
        UAsyncAction_StartListeningToEvent* ChatActiveHandle;       // 0x000100 (0x000008) [Default: nullptr]
        UDynamicUIScene*                    HitTicksUIScene;        // 0x000108 (0x000008) [Default: 0x7FEA19DA04D0]
    
    public: // Functions
        void    UnregisterChatActiveEvent(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    RemoveSquadListBottomScenes(); // 0x000545D2 [Protected | BlueprintCallable | BlueprintEvent]
        void    RemoveKillFeedScene(); // 0x000545D2 [Protected | BlueprintCallable | BlueprintEvent]
        void    RemoveHitTicksScene(bool CallFunc_GetConsoleVariableBoolValue_ReturnValue); // 0x000545D2 [Protected | BlueprintCallable | BlueprintEvent]
        void    RemoveDefaultHUDScenes(bool CallFunc_IsNewQuickbarEnabled_IsEnabled, bool CallFunc_IsNewHUDEnabled_IsNewHUD); // 0x000545D2 [Protected | BlueprintCallable | BlueprintEvent]
        void    RegisterChatActiveEvent(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    ReceiveEndPlay(TEnumAsByte<EEndPlayReason> EndPlayReason); // 0x000545D2 [Event | Public | BlueprintEvent]
        void    OnSquadListPlacementCVarChanged_Event(bool bSquadListIsBottom); // 0x000545D2 [Protected | BlueprintCallable | BlueprintEvent]
        void    OnReadyToShowUI(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnNewQuickbarCVarChanged_Event(bool bNewValue); // 0x000545D2 [Protected | BlueprintCallable | BlueprintEvent]
        void    OnNewHudCVarChanged_Event(bool bNewValue); // 0x000545D2 [Protected | BlueprintCallable | BlueprintEvent]
        void    OnKillFeedPlacementCVarChanged_Event(bool bNewValue); // 0x000545D2 [Protected | BlueprintCallable | BlueprintEvent]
        void    OnHUDElementVisibilityRefreshed(bool CallFunc_IsNewQuickbarEnabled_IsEnabled, bool CallFunc_IsNewHUDEnabled_IsNewHUD); // 0x000545D2 [Public | BlueprintCallable | BlueprintEvent]
        void    OnEventReceived_9FB9988E4F47300E6C0DA3B575453AD2(UAsyncAction_StartListeningToEvent* ProxyObject); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    ExecuteUbergraph_BP_BRGameUI_HUD_Component(int32 EntryPoint, FBPS_TextChatActiveStateChange Temp_struct_Variable, UBattleRoyaleGameUISubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue, TEnumAsByte<EEndPlayReason> K2Node_Event_EndPlayReason, OnBoolCVarChanged K2Node_CreateDelegate_OutputDelegate, OnBoolCVarChanged K2Node_CreateDelegate_OutputDelegate_1, OnBoolCVarChanged K2Node_CreateDelegate_OutputDelegate_2, OnBoolCVarChanged K2Node_CreateDelegate_OutputDelegate_3, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue, APlayerController* CallFunc_GetOwningLocalPlayerController_ReturnValue, UBattleRoyaleGameUISubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue_1, UAsyncAction_StartListeningToEvent* CallFunc_StartListeningToEvent_ReturnValue, bool CallFunc_IsValid_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, UAsyncAction_StartListeningToEvent* Temp_object_Variable, bool CallFunc_GetPayload_ReturnValue, FBPS_TextChatActiveStateChange Temp_struct_Variable_1, bool CallFunc_IsUsingCompactUI_ReturnValue, OnHUDElementVisibilityRefreshed K2Node_CreateDelegate_OutputDelegate_4, APlayerController* CallFunc_GetOwningLocalPlayerController_ReturnValue_1, UBattleRoyaleGameUISubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue_2, bool CallFunc_IsValid_ReturnValue_2, UControllerComponent_ItemizationInventory* CallFunc_GetComponentByClass_ReturnValue, AFortPlayerControllerGameplay* K2Node_DynamicCast_AsFort_Player_Controller_Gameplay, bool K2Node_DynamicCast_bSuccess, bool CallFunc_IsValid_ReturnValue_3, UInventory* CallFunc_GetRootInventory_ReturnValue, UAsyncAction_StartListeningToEvent* K2Node_CustomEvent_ProxyObject, UFortRootItemizationInventory* K2Node_DynamicCast_AsFort_Root_Itemization_Inventory, bool K2Node_DynamicCast_bSuccess_1, bool CallFunc_IsValid_ReturnValue_4, bool CallFunc_IsValid_ReturnValue_5, UBattleRoyaleGameUISubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue_3, AsyncGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate_5, OnCustomUIChangedDynamic K2Node_CreateDelegate_OutputDelegate_6); // 0x000545D2 [Final | UbergraphFunction]
        void    BP_BRGameUI_HUD_Component_AutoGenFunc(UFortRootItemizationInventory* Inventory); // 0x000545D2 [Public | BlueprintCallable | BlueprintEvent]
        void    AddSquadListBottomScenes(bool CallFunc_IsNewHUDEnabled_IsNewHUD, bool CallFunc_GetConsoleVariableBoolValue_ReturnValue); // 0x000545D2 [Protected | BlueprintCallable | BlueprintEvent]
        void    AddKillFeedScene(bool CallFunc_GetConsoleVariableBoolValue_ReturnValue, bool CallFunc_IsNewHUDEnabled_IsNewHUD); // 0x000545D2 [Protected | BlueprintCallable | BlueprintEvent]
        void    AddDefaultHUDScenes(UDynamicUIScene* Temp_object_Variable, UDynamicUIScene* Temp_object_Variable_1, bool CallFunc_IsNewQuickbarEnabled_IsEnabled, bool CallFunc_IsNewHUDEnabled_IsNewHUD, bool CallFunc_GetConsoleVariableBoolValue_ReturnValue, bool CallFunc_IsUsingCompactUI_ReturnValue, bool Temp_bool_Variable, UDynamicUIScene* K2Node_Select_Default); // 0x000545D2 [Protected | BlueprintCallable | BlueprintEvent]
    };
}

