/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:37
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BattleRoyaleGameUI/Director/BP_BRGameUI_HUD_Component_Functions
 * ============================================================
 */

#include "BP_BRGameUI_HUD_Component_Functions.hpp"

namespace UE
{

    void UBP_BRGameUI_HUD_Component_C::UnregisterChatActiveEvent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.UnregisterChatActiveEvent");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBP_BRGameUI_HUD_Component_C::RemoveSquadListBottomScenes()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.RemoveSquadListBottomScenes");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBP_BRGameUI_HUD_Component_C::RemoveKillFeedScene()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.RemoveKillFeedScene");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBP_BRGameUI_HUD_Component_C::RemoveHitTicksScene(bool CallFunc_GetConsoleVariableBoolValue_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.RemoveHitTicksScene");
    
        UBP_BRGameUI_HUD_Component_C___RemoveHitTicksScene_Params Params{};
        Params.CallFunc_GetConsoleVariableBoolValue_ReturnValue = CallFunc_GetConsoleVariableBoolValue_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_BRGameUI_HUD_Component_C::RemoveDefaultHUDScenes(bool CallFunc_IsNewQuickbarEnabled_IsEnabled, bool CallFunc_IsNewHUDEnabled_IsNewHUD)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.RemoveDefaultHUDScenes");
    
        UBP_BRGameUI_HUD_Component_C___RemoveDefaultHUDScenes_Params Params{};
        Params.CallFunc_IsNewQuickbarEnabled_IsEnabled = CallFunc_IsNewQuickbarEnabled_IsEnabled;
        Params.CallFunc_IsNewHUDEnabled_IsNewHUD = CallFunc_IsNewHUDEnabled_IsNewHUD;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_BRGameUI_HUD_Component_C::RegisterChatActiveEvent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.RegisterChatActiveEvent");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBP_BRGameUI_HUD_Component_C::ReceiveEndPlay(TEnumAsByte<EEndPlayReason> EndPlayReason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.ReceiveEndPlay");
    
        UBP_BRGameUI_HUD_Component_C___ReceiveEndPlay_Params Params{};
        Params.EndPlayReason = EndPlayReason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_BRGameUI_HUD_Component_C::OnSquadListPlacementCVarChanged_Event(bool bSquadListIsBottom)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.OnSquadListPlacementCVarChanged_Event");
    
        UBP_BRGameUI_HUD_Component_C___OnSquadListPlacementCVarChanged_Event_Params Params{};
        Params.bSquadListIsBottom = bSquadListIsBottom;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_BRGameUI_HUD_Component_C::OnReadyToShowUI()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.OnReadyToShowUI");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBP_BRGameUI_HUD_Component_C::OnNewQuickbarCVarChanged_Event(bool bNewValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.OnNewQuickbarCVarChanged_Event");
    
        UBP_BRGameUI_HUD_Component_C___OnNewQuickbarCVarChanged_Event_Params Params{};
        Params.bNewValue = bNewValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_BRGameUI_HUD_Component_C::OnNewHudCVarChanged_Event(bool bNewValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.OnNewHudCVarChanged_Event");
    
        UBP_BRGameUI_HUD_Component_C___OnNewHudCVarChanged_Event_Params Params{};
        Params.bNewValue = bNewValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_BRGameUI_HUD_Component_C::OnKillFeedPlacementCVarChanged_Event(bool bNewValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.OnKillFeedPlacementCVarChanged_Event");
    
        UBP_BRGameUI_HUD_Component_C___OnKillFeedPlacementCVarChanged_Event_Params Params{};
        Params.bNewValue = bNewValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_BRGameUI_HUD_Component_C::OnHUDElementVisibilityRefreshed(bool CallFunc_IsNewQuickbarEnabled_IsEnabled, bool CallFunc_IsNewHUDEnabled_IsNewHUD)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.OnHUDElementVisibilityRefreshed");
    
        UBP_BRGameUI_HUD_Component_C___OnHUDElementVisibilityRefreshed_Params Params{};
        Params.CallFunc_IsNewQuickbarEnabled_IsEnabled = CallFunc_IsNewQuickbarEnabled_IsEnabled;
        Params.CallFunc_IsNewHUDEnabled_IsNewHUD = CallFunc_IsNewHUDEnabled_IsNewHUD;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_BRGameUI_HUD_Component_C::OnEventReceived_9FB9988E4F47300E6C0DA3B575453AD2(UAsyncAction_StartListeningToEvent* ProxyObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.OnEventReceived_9FB9988E4F47300E6C0DA3B575453AD2");
    
        UBP_BRGameUI_HUD_Component_C___OnEventReceived_9FB9988E4F47300E6C0DA3B575453AD2_Params Params{};
        Params.ProxyObject = ProxyObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_BRGameUI_HUD_Component_C::ExecuteUbergraph_BP_BRGameUI_HUD_Component(int32 EntryPoint, FBPS_TextChatActiveStateChange Temp_struct_Variable, UBattleRoyaleGameUISubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue, TEnumAsByte<EEndPlayReason> K2Node_Event_EndPlayReason, OnBoolCVarChanged K2Node_CreateDelegate_OutputDelegate, OnBoolCVarChanged K2Node_CreateDelegate_OutputDelegate_1, OnBoolCVarChanged K2Node_CreateDelegate_OutputDelegate_2, OnBoolCVarChanged K2Node_CreateDelegate_OutputDelegate_3, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue, APlayerController* CallFunc_GetOwningLocalPlayerController_ReturnValue, UBattleRoyaleGameUISubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue_1, UAsyncAction_StartListeningToEvent* CallFunc_StartListeningToEvent_ReturnValue, bool CallFunc_IsValid_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, UAsyncAction_StartListeningToEvent* Temp_object_Variable, bool CallFunc_GetPayload_ReturnValue, FBPS_TextChatActiveStateChange Temp_struct_Variable_1, bool CallFunc_IsUsingCompactUI_ReturnValue, OnHUDElementVisibilityRefreshed K2Node_CreateDelegate_OutputDelegate_4, APlayerController* CallFunc_GetOwningLocalPlayerController_ReturnValue_1, UBattleRoyaleGameUISubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue_2, bool CallFunc_IsValid_ReturnValue_2, UControllerComponent_ItemizationInventory* CallFunc_GetComponentByClass_ReturnValue, AFortPlayerControllerGameplay* K2Node_DynamicCast_AsFort_Player_Controller_Gameplay, bool K2Node_DynamicCast_bSuccess, bool CallFunc_IsValid_ReturnValue_3, UInventory* CallFunc_GetRootInventory_ReturnValue, UAsyncAction_StartListeningToEvent* K2Node_CustomEvent_ProxyObject, UFortRootItemizationInventory* K2Node_DynamicCast_AsFort_Root_Itemization_Inventory, bool K2Node_DynamicCast_bSuccess_1, bool CallFunc_IsValid_ReturnValue_4, bool CallFunc_IsValid_ReturnValue_5, UBattleRoyaleGameUISubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue_3, AsyncGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate_5, OnCustomUIChangedDynamic K2Node_CreateDelegate_OutputDelegate_6)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.ExecuteUbergraph_BP_BRGameUI_HUD_Component");
    
        UBP_BRGameUI_HUD_Component_C___ExecuteUbergraph_BP_BRGameUI_HUD_Component_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.Temp_struct_Variable = Temp_struct_Variable;
        Params.CallFunc_GetGameInstanceSubsystem_ReturnValue = CallFunc_GetGameInstanceSubsystem_ReturnValue;
        Params.K2Node_Event_EndPlayReason = K2Node_Event_EndPlayReason;
        Params.K2Node_CreateDelegate_OutputDelegate = K2Node_CreateDelegate_OutputDelegate;
        Params.K2Node_CreateDelegate_OutputDelegate_1 = K2Node_CreateDelegate_OutputDelegate_1;
        Params.K2Node_CreateDelegate_OutputDelegate_2 = K2Node_CreateDelegate_OutputDelegate_2;
        Params.K2Node_CreateDelegate_OutputDelegate_3 = K2Node_CreateDelegate_OutputDelegate_3;
        Params.CallFunc_GetGlobalEventRouter_ReturnValue = CallFunc_GetGlobalEventRouter_ReturnValue;
        Params.CallFunc_GetOwningLocalPlayerController_ReturnValue = CallFunc_GetOwningLocalPlayerController_ReturnValue;
        Params.CallFunc_GetGameInstanceSubsystem_ReturnValue_1 = CallFunc_GetGameInstanceSubsystem_ReturnValue_1;
        Params.CallFunc_StartListeningToEvent_ReturnValue = CallFunc_StartListeningToEvent_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
        Params.Temp_object_Variable = Temp_object_Variable;
        Params.CallFunc_GetPayload_ReturnValue = CallFunc_GetPayload_ReturnValue;
        Params.Temp_struct_Variable_1 = Temp_struct_Variable_1;
        Params.CallFunc_IsUsingCompactUI_ReturnValue = CallFunc_IsUsingCompactUI_ReturnValue;
        Params.K2Node_CreateDelegate_OutputDelegate_4 = K2Node_CreateDelegate_OutputDelegate_4;
        Params.CallFunc_GetOwningLocalPlayerController_ReturnValue_1 = CallFunc_GetOwningLocalPlayerController_ReturnValue_1;
        Params.CallFunc_GetGameInstanceSubsystem_ReturnValue_2 = CallFunc_GetGameInstanceSubsystem_ReturnValue_2;
        Params.CallFunc_IsValid_ReturnValue_2 = CallFunc_IsValid_ReturnValue_2;
        Params.CallFunc_GetComponentByClass_ReturnValue = CallFunc_GetComponentByClass_ReturnValue;
        Params.K2Node_DynamicCast_AsFort_Player_Controller_Gameplay = K2Node_DynamicCast_AsFort_Player_Controller_Gameplay;
        Params.K2Node_DynamicCast_bSuccess = K2Node_DynamicCast_bSuccess;
        Params.CallFunc_IsValid_ReturnValue_3 = CallFunc_IsValid_ReturnValue_3;
        Params.CallFunc_GetRootInventory_ReturnValue = CallFunc_GetRootInventory_ReturnValue;
        Params.K2Node_CustomEvent_ProxyObject = K2Node_CustomEvent_ProxyObject;
        Params.K2Node_DynamicCast_AsFort_Root_Itemization_Inventory = K2Node_DynamicCast_AsFort_Root_Itemization_Inventory;
        Params.K2Node_DynamicCast_bSuccess_1 = K2Node_DynamicCast_bSuccess_1;
        Params.CallFunc_IsValid_ReturnValue_4 = CallFunc_IsValid_ReturnValue_4;
        Params.CallFunc_IsValid_ReturnValue_5 = CallFunc_IsValid_ReturnValue_5;
        Params.CallFunc_GetGameInstanceSubsystem_ReturnValue_3 = CallFunc_GetGameInstanceSubsystem_ReturnValue_3;
        Params.K2Node_CreateDelegate_OutputDelegate_5 = K2Node_CreateDelegate_OutputDelegate_5;
        Params.K2Node_CreateDelegate_OutputDelegate_6 = K2Node_CreateDelegate_OutputDelegate_6;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_BRGameUI_HUD_Component_C::BP_BRGameUI_HUD_Component_AutoGenFunc(UFortRootItemizationInventory* Inventory)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.BP_BRGameUI_HUD_Component_AutoGenFunc");
    
        UBP_BRGameUI_HUD_Component_C___BP_BRGameUI_HUD_Component_AutoGenFunc_Params Params{};
        Params.Inventory = Inventory;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_BRGameUI_HUD_Component_C::AddSquadListBottomScenes(bool CallFunc_IsNewHUDEnabled_IsNewHUD, bool CallFunc_GetConsoleVariableBoolValue_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.AddSquadListBottomScenes");
    
        UBP_BRGameUI_HUD_Component_C___AddSquadListBottomScenes_Params Params{};
        Params.CallFunc_IsNewHUDEnabled_IsNewHUD = CallFunc_IsNewHUDEnabled_IsNewHUD;
        Params.CallFunc_GetConsoleVariableBoolValue_ReturnValue = CallFunc_GetConsoleVariableBoolValue_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_BRGameUI_HUD_Component_C::AddKillFeedScene(bool CallFunc_GetConsoleVariableBoolValue_ReturnValue, bool CallFunc_IsNewHUDEnabled_IsNewHUD)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.AddKillFeedScene");
    
        UBP_BRGameUI_HUD_Component_C___AddKillFeedScene_Params Params{};
        Params.CallFunc_GetConsoleVariableBoolValue_ReturnValue = CallFunc_GetConsoleVariableBoolValue_ReturnValue;
        Params.CallFunc_IsNewHUDEnabled_IsNewHUD = CallFunc_IsNewHUDEnabled_IsNewHUD;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_BRGameUI_HUD_Component_C::AddDefaultHUDScenes(UDynamicUIScene* Temp_object_Variable, UDynamicUIScene* Temp_object_Variable_1, bool CallFunc_IsNewQuickbarEnabled_IsEnabled, bool CallFunc_IsNewHUDEnabled_IsNewHUD, bool CallFunc_GetConsoleVariableBoolValue_ReturnValue, bool CallFunc_IsUsingCompactUI_ReturnValue, bool Temp_bool_Variable, UDynamicUIScene* K2Node_Select_Default)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BRGameUI_HUD_Component.BP_BRGameUI_HUD_Component_C.AddDefaultHUDScenes");
    
        UBP_BRGameUI_HUD_Component_C___AddDefaultHUDScenes_Params Params{};
        Params.Temp_object_Variable = Temp_object_Variable;
        Params.Temp_object_Variable_1 = Temp_object_Variable_1;
        Params.CallFunc_IsNewQuickbarEnabled_IsEnabled = CallFunc_IsNewQuickbarEnabled_IsEnabled;
        Params.CallFunc_IsNewHUDEnabled_IsNewHUD = CallFunc_IsNewHUDEnabled_IsNewHUD;
        Params.CallFunc_GetConsoleVariableBoolValue_ReturnValue = CallFunc_GetConsoleVariableBoolValue_ReturnValue;
        Params.CallFunc_IsUsingCompactUI_ReturnValue = CallFunc_IsUsingCompactUI_ReturnValue;
        Params.Temp_bool_Variable = Temp_bool_Variable;
        Params.K2Node_Select_Default = K2Node_Select_Default;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

