/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:37
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BattleRoyaleGameUI/Director/BP_BRGameUI_HUD_Component_Functions
 * ============================================================
 */

#include "BP_BRGameUI_HUD_Component.hpp"

namespace UE
{

    struct UBP_BRGameUI_HUD_Component_C___RemoveHitTicksScene_Params
    {
        bool    CallFunc_GetConsoleVariableBoolValue_ReturnValue;   // 0x000000 (0x000001) [Default: false]
    };

    struct UBP_BRGameUI_HUD_Component_C___RemoveDefaultHUDScenes_Params
    {
        bool    CallFunc_IsNewQuickbarEnabled_IsEnabled;    // 0x000000 (0x000001) [Default: false]
        bool    CallFunc_IsNewHUDEnabled_IsNewHUD;          // 0x000001 (0x000001) [Default: true]
    };

    struct UBP_BRGameUI_HUD_Component_C___ReceiveEndPlay_Params
    {
        TEnumAsByte<EEndPlayReason> EndPlayReason;  // 0x000000 (0x000001) [Default: 0]
    };

    struct UBP_BRGameUI_HUD_Component_C___OnSquadListPlacementCVarChanged_Event_Params
    {
        bool    bSquadListIsBottom; // 0x000000 (0x000001) [Default: false]
    };

    struct UBP_BRGameUI_HUD_Component_C___OnNewQuickbarCVarChanged_Event_Params
    {
        bool    bNewValue;  // 0x000000 (0x000001) [Default: false]
    };

    struct UBP_BRGameUI_HUD_Component_C___OnNewHudCVarChanged_Event_Params
    {
        bool    bNewValue;  // 0x000000 (0x000001) [Default: false]
    };

    struct UBP_BRGameUI_HUD_Component_C___OnKillFeedPlacementCVarChanged_Event_Params
    {
        bool    bNewValue;  // 0x000000 (0x000001) [Default: false]
    };

    struct UBP_BRGameUI_HUD_Component_C___OnHUDElementVisibilityRefreshed_Params
    {
        bool    CallFunc_IsNewQuickbarEnabled_IsEnabled;    // 0x000000 (0x000001) [Default: false]
        bool    CallFunc_IsNewHUDEnabled_IsNewHUD;          // 0x000001 (0x000001) [Default: true]
    };

    struct UBP_BRGameUI_HUD_Component_C___OnEventReceived_9FB9988E4F47300E6C0DA3B575453AD2_Params
    {
        UAsyncAction_StartListeningToEvent* ProxyObject;    // 0x000000 (0x000008) [Default: 0x1447E500]
    };

    struct UBP_BRGameUI_HUD_Component_C___ExecuteUbergraph_BP_BRGameUI_HUD_Component_Params
    {
        int32                                       EntryPoint;                                             // 0x000000 (0x000004) [Default: 340256000]
        FBPS_TextChatActiveStateChange              Temp_struct_Variable;                                   // 0x000004 (0x000001)
        uint8                                       UnknownData_000005[0x000003];                           // 0x000005 (0x000003)
        UBattleRoyaleGameUISubsystem*               CallFunc_GetGameInstanceSubsystem_ReturnValue;          // 0x000008 (0x000008) [Default: 0xA23E1CDD00280031]
        TEnumAsByte<EEndPlayReason>                 K2Node_Event_EndPlayReason;                             // 0x000010 (0x000001) [Default: 64]
        uint8                                       UnknownData_000011[0x000003];                           // 0x000011 (0x000003)
        OnBoolCVarChanged                           K2Node_CreateDelegate_OutputDelegate;                   // 0x000014 (0x00000C)
        OnBoolCVarChanged                           K2Node_CreateDelegate_OutputDelegate_1;                 // 0x000020 (0x00000C)
        OnBoolCVarChanged                           K2Node_CreateDelegate_OutputDelegate_2;                 // 0x00002C (0x00000C)
        OnBoolCVarChanged                           K2Node_CreateDelegate_OutputDelegate_3;                 // 0x000038 (0x00000C)
        uint8                                       UnknownData_000044[0x000004];                           // 0x000044 (0x000004)
        UGameplayEventRouterComponent*              CallFunc_GetGlobalEventRouter_ReturnValue;              // 0x000048 (0x000008) [Default: nullptr]
        APlayerController*                          CallFunc_GetOwningLocalPlayerController_ReturnValue;    // 0x000050 (0x000008) [Default: nullptr]
        UBattleRoyaleGameUISubsystem*               CallFunc_GetGameInstanceSubsystem_ReturnValue_1;        // 0x000058 (0x000008) [Default: nullptr]
        UAsyncAction_StartListeningToEvent*         CallFunc_StartListeningToEvent_ReturnValue;             // 0x000060 (0x000008) [Default: nullptr]
        bool                                        CallFunc_IsValid_ReturnValue;                           // 0x000068 (0x000001) [Default: false]
        bool                                        CallFunc_IsValid_ReturnValue_1;                         // 0x000069 (0x000001) [Default: false]
        uint8                                       UnknownData_00006A[0x000006];                           // 0x00006A (0x000006)
        UAsyncAction_StartListeningToEvent*         Temp_object_Variable;                                   // 0x000070 (0x000008) [Default: nullptr]
        bool                                        CallFunc_GetPayload_ReturnValue;                        // 0x000078 (0x000001) [Default: false]
        FBPS_TextChatActiveStateChange              Temp_struct_Variable_1;                                 // 0x000079 (0x000001)
        bool                                        CallFunc_IsUsingCompactUI_ReturnValue;                  // 0x00007A (0x000001) [Default: false]
        uint8                                       UnknownByte_00007B;                                     // 0x00007B (0x000001)
        OnHUDElementVisibilityRefreshed             K2Node_CreateDelegate_OutputDelegate_4;                 // 0x00007C (0x00000C)
        APlayerController*                          CallFunc_GetOwningLocalPlayerController_ReturnValue_1;  // 0x000088 (0x000008) [Default: 0xFFFFFFF]
        UBattleRoyaleGameUISubsystem*               CallFunc_GetGameInstanceSubsystem_ReturnValue_2;        // 0x000090 (0x000008) [Default: 0xFFFFFFFF]
        bool                                        CallFunc_IsValid_ReturnValue_2;                         // 0x000098 (0x000001) [Default: true]
        uint8                                       UnknownData_000099[0x000007];                           // 0x000099 (0x000007)
        UControllerComponent_ItemizationInventory*  CallFunc_GetComponentByClass_ReturnValue;               // 0x0000A0 (0x000008) [Default: nullptr]
        AFortPlayerControllerGameplay*              K2Node_DynamicCast_AsFort_Player_Controller_Gameplay;   // 0x0000A8 (0x000008) [Default: nullptr]
        bool                                        K2Node_DynamicCast_bSuccess;                            // 0x0000B0 (0x000001) [Default: false]
        bool                                        CallFunc_IsValid_ReturnValue_3;                         // 0x0000B1 (0x000001) [Default: false]
        uint8                                       UnknownData_0000B2[0x000006];                           // 0x0000B2 (0x000006)
        UInventory*                                 CallFunc_GetRootInventory_ReturnValue;                  // 0x0000B8 (0x000008) [Default: nullptr]
        UAsyncAction_StartListeningToEvent*         K2Node_CustomEvent_ProxyObject;                         // 0x0000C0 (0x000008) [Default: 0x7FEBD993A300]
        UFortRootItemizationInventory*              K2Node_DynamicCast_AsFort_Root_Itemization_Inventory;   // 0x0000C8 (0x000008) [Default: 0x7FE95BDC2E00]
        bool                                        K2Node_DynamicCast_bSuccess_1;                          // 0x0000D0 (0x000001) [Default: true]
        bool                                        CallFunc_IsValid_ReturnValue_4;                         // 0x0000D1 (0x000001) [Default: false]
        bool                                        CallFunc_IsValid_ReturnValue_5;                         // 0x0000D2 (0x000001) [Default: false]
        uint8                                       UnknownData_0000D3[0x000005];                           // 0x0000D3 (0x000005)
        UBattleRoyaleGameUISubsystem*               CallFunc_GetGameInstanceSubsystem_ReturnValue_3;        // 0x0000D8 (0x000008) [Default: 0x7FEA19D9EE00]
        AsyncGameplayEventDelegate                  K2Node_CreateDelegate_OutputDelegate_5;                 // 0x0000E0 (0x00000C)
        OnCustomUIChangedDynamic                    K2Node_CreateDelegate_OutputDelegate_6;                 // 0x0000EC (0x00000C)
    };

    struct UBP_BRGameUI_HUD_Component_C___BP_BRGameUI_HUD_Component_AutoGenFunc_Params
    {
        UFortRootItemizationInventory*  Inventory;  // 0x000000 (0x000008) [Default: 0x1447E500]
    };

    struct UBP_BRGameUI_HUD_Component_C___AddSquadListBottomScenes_Params
    {
        bool    CallFunc_IsNewHUDEnabled_IsNewHUD;                  // 0x000000 (0x000001) [Default: false]
        bool    CallFunc_GetConsoleVariableBoolValue_ReturnValue;   // 0x000001 (0x000001) [Default: true]
    };

    struct UBP_BRGameUI_HUD_Component_C___AddKillFeedScene_Params
    {
        bool    CallFunc_GetConsoleVariableBoolValue_ReturnValue;   // 0x000000 (0x000001) [Default: false]
        bool    CallFunc_IsNewHUDEnabled_IsNewHUD;                  // 0x000001 (0x000001) [Default: true]
    };

    struct UBP_BRGameUI_HUD_Component_C___AddDefaultHUDScenes_Params
    {
        UDynamicUIScene*    Temp_object_Variable;                               // 0x000000 (0x000008) [Default: 0x1447E500]
        UDynamicUIScene*    Temp_object_Variable_1;                             // 0x000008 (0x000008) [Default: 0xA23E1CDD00280031]
        bool                CallFunc_IsNewQuickbarEnabled_IsEnabled;            // 0x000010 (0x000001) [Default: true]
        bool                CallFunc_IsNewHUDEnabled_IsNewHUD;                  // 0x000011 (0x000001) [Default: true]
        bool                CallFunc_GetConsoleVariableBoolValue_ReturnValue;   // 0x000012 (0x000001) [Default: true]
        bool                CallFunc_IsUsingCompactUI_ReturnValue;              // 0x000013 (0x000001) [Default: true]
        bool                Temp_bool_Variable;                                 // 0x000014 (0x000001) [Default: true]
        uint8               UnknownData_000015[0x000003];                       // 0x000015 (0x000003)
        UDynamicUIScene*    K2Node_Select_Default;                              // 0x000018 (0x000008) [Default: 0x7FE99A5EB6E0]
    };

} // namespace UE

