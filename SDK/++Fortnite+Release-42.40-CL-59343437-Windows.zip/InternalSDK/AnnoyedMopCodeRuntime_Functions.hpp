/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnnoyedMopCodeRuntime_Functions
 * ============================================================
 */

#include "AnnoyedMopCodeRuntime.hpp"

namespace UE
{

    struct AFortProjectileAnnoyedMop___InitializeCollisionSegments_Params
    {
        TArray<UCapsuleComponent*>                  SegmentInitializers;    // 0x000000 (0x000010) [OutParam]
        UFortProjectileSegmentedCollisionComponent* SegmentedCollisionComp; // 0x000010 (0x000008) [Default: 0x19700810]
    };

    struct AFortProjectileAnnoyedMop___InitializeFXComponent_Params
    {
        UNiagaraComponent*  FXComponent;    // 0x000000 (0x000008) [Default: 0x14893580]
    };

    struct AFortProjectileAnnoyedMop___UpdateSize_Params
    {
        float   DeltaSeconds;   // 0x000000 (0x000004) [Default: 1.38546e-26f]
        float   GrowthSpeed;    // 0x000004 (0x000004) [Default: 0f]
        float   ReturnValue;    // 0x000008 (0x000004) [ReturnValue] [Default: 6.86636e-44f]
    };

    struct UAnnoyedMopProjectileComponent___InitializeFXComponent_Params
    {
        UNiagaraComponent*  FXComponent;    // 0x000000 (0x000008) [Default: 0x14892C80]
    };

    struct UAnnoyedMopProjectileComponent___UpdateSize_Params
    {
        float   DeltaSeconds;   // 0x000000 (0x000004) [Default: 1.3851e-26f]
        float   GrowthSpeed;    // 0x000004 (0x000004) [Default: 0f]
        float   ReturnValue;    // 0x000008 (0x000004) [ReturnValue] [Default: 6.86636e-44f]
    };

} // namespace UE

