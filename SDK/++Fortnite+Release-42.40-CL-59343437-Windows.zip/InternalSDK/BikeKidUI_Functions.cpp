/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BikeKidUI_Functions
 * ============================================================
 */

#include "BikeKidUI_Functions.hpp"

namespace UE
{

    void ABikeKidUIDirector::BP_OnBikeKidDeployed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidUIDirector.BP_OnBikeKidDeployed");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ABikeKidUIDirector::BP_OnBikeKidDismissed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidUIDirector.BP_OnBikeKidDismissed");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    AFortBikeKid* UBikeKidHUD::GetControlledBikeKid()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidHUD.GetControlledBikeKid");
    
        UBikeKidHUD___GetControlledBikeKid_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UBikeKidHUD::GetTargetConfirmationTime()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidHUD.GetTargetConfirmationTime");
    
        UBikeKidHUD___GetTargetConfirmationTime_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBikeKidHUD::OnBikeKidDismissAbilityUsed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidHUD.OnBikeKidDismissAbilityUsed");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBikeKidHUD::OnBikeKidEnergyChanged(float EnergyPercentage)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidHUD.OnBikeKidEnergyChanged");
    
        UBikeKidHUD___OnBikeKidEnergyChanged_Params Params{};
        Params.EnergyPercentage = EnergyPercentage;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBikeKidHUD::OnBikeKidHealthUpdated(float HealthPercentage, float CurrentHealth)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidHUD.OnBikeKidHealthUpdated");
    
        UBikeKidHUD___OnBikeKidHealthUpdated_Params Params{};
        Params.HealthPercentage = HealthPercentage;
        Params.CurrentHealth = CurrentHealth;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBikeKidHUD::OnBikeKidMarkAbilityEnd()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidHUD.OnBikeKidMarkAbilityEnd");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBikeKidHUD::OnBikeKidMarkAbilityUsed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidHUD.OnBikeKidMarkAbilityUsed");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBikeKidHUD::OnBikeKidSignalDataUpdated(float DistanceFromPlayer, float SignalPercentage)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidHUD.OnBikeKidSignalDataUpdated");
    
        UBikeKidHUD___OnBikeKidSignalDataUpdated_Params Params{};
        Params.DistanceFromPlayer = DistanceFromPlayer;
        Params.SignalPercentage = SignalPercentage;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBikeKidHUD::OnBikeKidSpeedBoostAbilityEnd()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidHUD.OnBikeKidSpeedBoostAbilityEnd");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBikeKidHUD::OnBikeKidSpeedBoostAbilityUsed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidHUD.OnBikeKidSpeedBoostAbilityUsed");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBikeKidHUD::OnOwningPlayerDamaged()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidHUD.OnOwningPlayerDamaged");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBikeKidHUD::OnReticleChangeAbilityActivated(FGameplayTag UpdatedTag)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidHUD.OnReticleChangeAbilityActivated");
    
        UBikeKidHUD___OnReticleChangeAbilityActivated_Params Params{};
        Params.UpdatedTag = UpdatedTag;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBikeKidHUD::OnTargetingStatusChanged(FBikeKidStatusData& StatusData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidHUD.OnTargetingStatusChanged");
    
        UBikeKidHUD___OnTargetingStatusChanged_Params Params{};
        Params.StatusData = StatusData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        StatusData = Params.StatusData;
    }

    void UBikeKidTetherIndicator::BP_OnEnterSignalLossRange()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidTetherIndicator.BP_OnEnterSignalLossRange");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBikeKidTetherIndicator::BP_OnEnterWarningRange()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidTetherIndicator.BP_OnEnterWarningRange");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBikeKidTetherIndicator::BP_OnExitWarningRange()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidTetherIndicator.BP_OnExitWarningRange");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBikeKidTetherIndicator::BP_WhileInWarningRange(float SignalIntensityPercentage)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidTetherIndicator.BP_WhileInWarningRange");
    
        UBikeKidTetherIndicator___BP_WhileInWarningRange_Params Params{};
        Params.SignalIntensityPercentage = SignalIntensityPercentage;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    AFortBikeKid* UBikeKidTetherIndicator::GetControlledBikeKid()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidUI.BikeKidTetherIndicator.GetControlledBikeKid");
    
        UBikeKidTetherIndicator___GetControlledBikeKid_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

} // namespace UE

