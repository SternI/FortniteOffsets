/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimationWarpingRuntime_Functions
 * ============================================================
 */

#include "AnimationWarpingRuntime.hpp"

namespace UE
{

    struct UAnimationWarpingLibrary___ApplyDeltaToOffsetRootBone_Params
    {
        FOffsetRootBoneAnimNodeReference    OffsetRootBoneNode;             // 0x000000 (0x000010) [OutParam]
        FVector                             TranslationWorld;               // 0x000010 (0x000018)
        uint8                               UnknownData_000028[0x000008];   // 0x000028 (0x000008)
        FQuat                               RotationWorld;                  // 0x000030 (0x000020)
    };

    struct UAnimationWarpingLibrary___ConvertToOffsetRootBoneNodePure_Params
    {
        FAnimNodeReference                  Node;               // 0x000000 (0x000010) [OutParam]
        FOffsetRootBoneAnimNodeReference    OffsetRootBoneNode; // 0x000010 (0x000010) [OutParam]
        bool                                Result;             // 0x000020 (0x000001) [OutParam] [Default: true]
    };

    struct UAnimationWarpingLibrary___GetCurveValueFromAnimation_Params
    {
        UAnimSequenceBase*  Animation;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        FName               CurveName;      // 0x000008 (0x000004) [Default: FName(49) -> L""]
        float               time;           // 0x00000C (0x000004) [Default: 5.02809e-37f]
        float               OutValue;       // 0x000010 (0x000004) [OutParam] [Default: 7.5778e-25f]
        bool                ReturnValue;    // 0x000014 (0x000001) [ReturnValue] [Default: false]
    };

    struct UAnimationWarpingLibrary___GetFloatValueFromCurve_Params
    {
        UCurveFloat*    InCurve;        // 0x000000 (0x000008) [Default: 0x130A5F60]
        float           time;           // 0x000008 (0x000004) [Default: 6.86636e-44f]
        float           OutValue;       // 0x00000C (0x000004) [OutParam] [Default: 5.02809e-37f]
        bool            ReturnValue;    // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAnimationWarpingLibrary___GetOffsetRootTransform_Params
    {
        FAnimNodeReference  Node;           // 0x000000 (0x000010) [OutParam]
        FTransform          ReturnValue;    // 0x000010 (0x000060) [ReturnValue]
    };

    struct UAnimationWarpingLibrary___GetVectorValueFromCurve_Params
    {
        UCurveVector*   InCurve;                        // 0x000000 (0x000008) [Default: 0x130A5F60]
        float           time;                           // 0x000008 (0x000004) [Default: 6.86636e-44f]
        uint8           UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FVector         OutValue;                       // 0x000010 (0x000018) [OutParam]
        bool            ReturnValue;                    // 0x000028 (0x000001) [ReturnValue] [Default: true]
    };

} // namespace UE

