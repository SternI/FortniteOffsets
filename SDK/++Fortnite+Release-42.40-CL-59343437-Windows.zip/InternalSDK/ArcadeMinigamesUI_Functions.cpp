/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArcadeMinigamesUI_Functions
 * ============================================================
 */

#include "ArcadeMinigamesUI_Functions.hpp"

namespace UE
{

    void UArcadeMinigame2DWidget::EndGame()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMinigame2DWidget.EndGame");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UArcadeMinigame2DWidget::SetPaused(bool bPause)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMinigame2DWidget.SetPaused");
    
        UArcadeMinigame2DWidget___SetPaused_Params Params{};
        Params.bPause = bPause;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UArcadeMinigame2DWidget::SetScoreFont(FName& FontName, int32 DefaultSize)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMinigame2DWidget.SetScoreFont");
    
        UArcadeMinigame2DWidget___SetScoreFont_Params Params{};
        Params.FontName = FontName;
        Params.DefaultSize = DefaultSize;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        FontName = Params.FontName;
    }

    void UArcadeMinigame2DWidget::StartGame()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMinigame2DWidget.StartGame");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    bool UArcadeMinigameWidget::HasAnyControlAction()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMinigameWidget.HasAnyControlAction");
    
        UArcadeMinigameWidget___HasAnyControlAction_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UArcadeMinigameWidget::HasMovementControl()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMinigameWidget.HasMovementControl");
    
        UArcadeMinigameWidget___HasMovementControl_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UArcadeMinigameWidget::HasPrimaryControl()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMinigameWidget.HasPrimaryControl");
    
        UArcadeMinigameWidget___HasPrimaryControl_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UArcadeMinigameWidget::HasSecondaryControl()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMinigameWidget.HasSecondaryControl");
    
        UArcadeMinigameWidget___HasSecondaryControl_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UArcadeMobileControlOverlayWidget::HasExitControl()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMobileControlOverlayWidget.HasExitControl");
    
        UArcadeMobileControlOverlayWidget___HasExitControl_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UArcadeMobileControlOverlayWidget::HasMovementControl()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMobileControlOverlayWidget.HasMovementControl");
    
        UArcadeMobileControlOverlayWidget___HasMovementControl_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UArcadeMobileControlOverlayWidget::HasPrimaryControl()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMobileControlOverlayWidget.HasPrimaryControl");
    
        UArcadeMobileControlOverlayWidget___HasPrimaryControl_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UArcadeMobileControlOverlayWidget::HasSecondaryControl()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMobileControlOverlayWidget.HasSecondaryControl");
    
        UArcadeMobileControlOverlayWidget___HasSecondaryControl_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UArcadeMobileControlOverlayWidget::InjectMovement(FVector2D Value)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMobileControlOverlayWidget.InjectMovement");
    
        UArcadeMobileControlOverlayWidget___InjectMovement_Params Params{};
        Params.Value = Value;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UArcadeMobileControlOverlayWidget::OnExitButtonPressed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMobileControlOverlayWidget.OnExitButtonPressed");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UArcadeMobileControlOverlayWidget::OnPrimaryButtonPressed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMobileControlOverlayWidget.OnPrimaryButtonPressed");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UArcadeMobileControlOverlayWidget::OnPrimaryButtonReleased()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMobileControlOverlayWidget.OnPrimaryButtonReleased");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UArcadeMobileControlOverlayWidget::OnSecondaryButtonPressed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMobileControlOverlayWidget.OnSecondaryButtonPressed");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UArcadeMobileControlOverlayWidget::OnSecondaryButtonReleased()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMobileControlOverlayWidget.OnSecondaryButtonReleased");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    FVector2D UArcadeMobileJoystickWidget::GetCurrentValue()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeMobileJoystickWidget.GetCurrentValue");
    
        UArcadeMobileJoystickWidget___GetCurrentValue_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UArcadeVolleyWidget::OnMatchEnded(int32 WinnerPlayerIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeVolleyWidget.OnMatchEnded");
    
        UArcadeVolleyWidget___OnMatchEnded_Params Params{};
        Params.WinnerPlayerIndex = WinnerPlayerIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UArcadeVolleyWidget::OnPlayerScored(int32 PlayerIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeVolleyWidget.OnPlayerScored");
    
        UArcadeVolleyWidget___OnPlayerScored_Params Params{};
        Params.PlayerIndex = PlayerIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UArcadeVolleyWidget::OnServed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.ArcadeVolleyWidget.OnServed");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBoostBallGameStage::StartMatch()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.BoostBallGameStage.StartMatch");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBoostBallScreen::HandlePrimaryPressed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.BoostBallScreen.HandlePrimaryPressed");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBoostBallScreen::HandlePrimaryReleased()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.BoostBallScreen.HandlePrimaryReleased");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBoostBallScreen::HandleSecondaryPressed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.BoostBallScreen.HandleSecondaryPressed");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBoostBallScreen::HandleSecondaryReleased()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.BoostBallScreen.HandleSecondaryReleased");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBoostBallScreen::SetStickInput(FVector2D Stick)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesUI.BoostBallScreen.SetStickInput");
    
        UBoostBallScreen___SetStickInput_Params Params{};
        Params.Stick = Stick;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

