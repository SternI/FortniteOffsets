/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AuroraFortniteUI_Functions
 * ============================================================
 */

#include "AuroraFortniteUI_Functions.hpp"

namespace UE
{

    void AAuroraFortniteUIDirector::OnOfferPurchaseCanceled()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.AuroraFortniteUIDirector.OnOfferPurchaseCanceled");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AAuroraFortniteUIDirector::OnOfferPurchaseConfirmed(FInstancedStruct& Invoice)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.AuroraFortniteUIDirector.OnOfferPurchaseConfirmed");
    
        AAuroraFortniteUIDirector___OnOfferPurchaseConfirmed_Params Params{};
        Params.Invoice = Invoice;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Invoice = Params.Invoice;
    }

    void AAuroraFortniteUIDirector::OnOfferSelected(FGuid& OfferId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.AuroraFortniteUIDirector.OnOfferSelected");
    
        AAuroraFortniteUIDirector___OnOfferSelected_Params Params{};
        Params.OfferId = OfferId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OfferId = Params.OfferId;
    }

    void UAuroraFortniteTransitionableWidget::BroadcastTransitionCompleted()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.AuroraFortniteTransitionableWidget.BroadcastTransitionCompleted");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAuroraFortniteTransitionableWidget::OnHide()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.AuroraFortniteTransitionableWidget.OnHide");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAuroraFortniteTransitionableWidget::OnShow()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.AuroraFortniteTransitionableWidget.OnShow");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAuroraFortniteTransitionableWidget::UpdateIsTransitioning(bool bInIsTransitioning)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.AuroraFortniteTransitionableWidget.UpdateIsTransitioning");
    
        UAuroraFortniteTransitionableWidget___UpdateIsTransitioning_Params Params{};
        Params.bInIsTransitioning = bInIsTransitioning;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UFortAuroraOfferVM* UFortAuroraOfferVM::CreateAuroraOfferVM(FInstancedStruct& OfferData, TMap<FString, int64>& OwnedProductQuantities, AFortPlayerController* InOwningPlayer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraOfferVM.CreateAuroraOfferVM");
    
        UFortAuroraOfferVM___CreateAuroraOfferVM_Params Params{};
        Params.OfferData = OfferData;
        Params.OwnedProductQuantities = OwnedProductQuantities;
        Params.InOwningPlayer = InOwningPlayer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OfferData = Params.OfferData;
        OwnedProductQuantities = Params.OwnedProductQuantities;
    
        return Params.ReturnValue;
    }

    FText UFortAuroraOfferVM::GetDisplayType()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraOfferVM.GetDisplayType");
    
        UFortAuroraOfferVM___GetDisplayType_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FText UFortAuroraOfferVM::GetLegalText()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraOfferVM.GetLegalText");
    
        UFortAuroraOfferVM___GetLegalText_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortAuroraShopVM::BroadcastInspectedOfferCanceled()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraShopVM.BroadcastInspectedOfferCanceled");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortAuroraShopVM::BroadcastInspectedOfferPurchaseConfirmed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraShopVM.BroadcastInspectedOfferPurchaseConfirmed");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortAuroraShopVM::BroadcastOnOfferSelected(FGuid& OfferId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraShopVM.BroadcastOnOfferSelected");
    
        UFortAuroraShopVM___BroadcastOnOfferSelected_Params Params{};
        Params.OfferId = OfferId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OfferId = Params.OfferId;
    }

    FText UFortAuroraShopVM::GetLastErrorCode()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraShopVM.GetLastErrorCode");
    
        UFortAuroraShopVM___GetLastErrorCode_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UFortAuroraShopVM::IsInTestMode()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraShopVM.IsInTestMode");
    
        UFortAuroraShopVM___IsInTestMode_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UFortAuroraShopVM::IsMtxPurchaseFlowEnabled()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraShopVM.IsMtxPurchaseFlowEnabled");
    
        UFortAuroraShopVM___IsMtxPurchaseFlowEnabled_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortAuroraShopVM::ReportInspectedOffer()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraShopVM.ReportInspectedOffer");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortAuroraShopVM::ResetCatalogOffers()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraShopVM.ResetCatalogOffers");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortAuroraShopVM::ResetInspectedOfferAndStates()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraShopVM.ResetInspectedOfferAndStates");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortAuroraShopVM::ResetLastPurchasedOffer()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraShopVM.ResetLastPurchasedOffer");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortAuroraShopVM::SetCatalogOffers(FGuid& InCatalogId, TArray<FInstancedStruct>& Offers, FText& Title, TMap<FString, int64>& OwnedProductQuantities)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraShopVM.SetCatalogOffers");
    
        UFortAuroraShopVM___SetCatalogOffers_Params Params{};
        Params.InCatalogId = InCatalogId;
        Params.Offers = Offers;
        Params.Title = Title;
        Params.OwnedProductQuantities = OwnedProductQuantities;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InCatalogId = Params.InCatalogId;
        Offers = Params.Offers;
        Title = Params.Title;
        OwnedProductQuantities = Params.OwnedProductQuantities;
    }

    void UFortAuroraShopVM::SetInspectedOffer(FInstancedStruct& Invoice, FInstancedStruct& offer, TMap<FString, int64>& OwnedProductQuantities)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraShopVM.SetInspectedOffer");
    
        UFortAuroraShopVM___SetInspectedOffer_Params Params{};
        Params.Invoice = Invoice;
        Params.offer = offer;
        Params.OwnedProductQuantities = OwnedProductQuantities;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Invoice = Params.Invoice;
        offer = Params.offer;
        OwnedProductQuantities = Params.OwnedProductQuantities;
    }

    void UFortAuroraShopVM::SetInspectionState(EFortAuroraOfferRequestState State)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraShopVM.SetInspectionState");
    
        UFortAuroraShopVM___SetInspectionState_Params Params{};
        Params.State = State;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortAuroraShopVM::SetPurchaseState(EFortAuroraOfferRequestState State)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraShopVM.SetPurchaseState");
    
        UFortAuroraShopVM___SetPurchaseState_Params Params{};
        Params.State = State;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UFortAuroraShopVM::ShouldForceAllowTestPurchases()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraShopVM.ShouldForceAllowTestPurchases");
    
        UFortAuroraShopVM___ShouldForceAllowTestPurchases_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortAuroraShopVM::UpdateLastErrorCode(FString InErrorCode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraShopVM.UpdateLastErrorCode");
    
        UFortAuroraShopVM___UpdateLastErrorCode_Params Params{};
        Params.InErrorCode = InErrorCode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortAuroraShopVM::UpdateOwnedProductQuantities(TMap<FString, int64>& OwnedProductQuantities)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteUI.FortAuroraShopVM.UpdateOwnedProductQuantities");
    
        UFortAuroraShopVM___UpdateOwnedProductQuantities_Params Params{};
        Params.OwnedProductQuantities = OwnedProductQuantities;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OwnedProductQuantities = Params.OwnedProductQuantities;
    }

} // namespace UE

