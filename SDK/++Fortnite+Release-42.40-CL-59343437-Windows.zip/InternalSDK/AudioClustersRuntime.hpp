/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioClustersRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000038 (0x000010)
    class alignas(0x8) UAudioClusterBehavior : public UObject
    {
    public:
        FInstancedStruct    ClusterData;    // 0x000028 (0x000010)
    
    public: // Functions
        void    OnActorAdded(AActor* Actor); // 0x05226FE4 [Native | Event | Public | BlueprintEvent]
        void    OnActorRemoved(AActor* Actor); // 0x04FB1C28 [Native | Event | Public | BlueprintEvent]
        void    OnPositionUpdated(FVector& NewPosition); // 0x07FE93E4 [Native | Event | Public | HasOutParms | HasDefaults | BlueprintEvent]
        void    OnSizeUpdated(int32 NewSize); // 0x07FE9562 [Native | Event | Public | BlueprintEvent]
        void    OnStart(int32 InitialSize); // 0x07FE96D6 [Native | Event | Public | BlueprintEvent]
        void    OnStop(); // 0x0C993BB2 [Native | Event | Public | BlueprintEvent]
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x8) UAudioClusterConfigurations : public UDataAsset
    {
    public:
        TArray<FAudioClusterConfiguration>  ClusterConfigs; // 0x000028 (0x000010)
    };
    // Size: 0x000028 (0x000000)
    class UAudioClusterFunctionLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static bool                                IsAudioClusterConfigurationsHandleValid(UObject* WorldContextObject, FAudioClusterConfigurationsHandle& Handle); // 0x07FE98DE [Final | RequiredAPI | BlueprintCosmetic | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FAudioClusterConfigurationsHandle   RegisterClusterConfigurations(UObject* WorldContextObject, UAudioClusterConfigurations* Configurations); // 0x07FE9B8C [Final | RequiredAPI | BlueprintCosmetic | Native | Static | Public | BlueprintCallable]
        static void                                UnregisterClusterConfigurations(UObject* WorldContextObject, FAudioClusterConfigurationsHandle& Handle); // 0x07FEA770 [Final | RequiredAPI | BlueprintCosmetic | Native | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000100 (0x0000C8)
    class alignas(0x8) UAudioClustersSubsystem : public UWorldSubsystem
    {
    public:
        void**  VTable_000038;                  // 0x000038 (0x000008) VTable [7 slots] -> 0x1470BED0
        uint8   UnknownData_000040[0x0000C0];   // 0x000040 (0x0000C0)
    };
    // Size: 0x000070 (0x000048)
    class alignas(0x8) UGameFeatureAction_ConfigureAudioClusters : public UGameFeatureAction
    {
    public:
        TSoftObjectPtr<UAudioClusterConfigurations> Configurations;                 // 0x000028 (0x000020) [Default: nullptr]
        UAudioClusterConfigurations*                LoadedConfigurations;           // 0x000048 (0x000008) [Default: nullptr]
        uint8                                       UnknownData_000050[0x000020];   // 0x000050 (0x000020)
    };
    // Size: 0x000008 (0x000008)
    struct FAudioClusterAlgorithmTemplate
    {
        uint8   UnknownData_000000[0x000008];   // 0x000000 (0x000008)
    };
    // Size: 0x000028 (0x000020)
    struct alignas(0x8) FAudioClusterAlgorithmTemplate_DynamicSector : public FAudioClusterAlgorithmTemplate
    {
        double                                  SectorWidth;                    // 0x000008 (0x000008)
        double                                  SectorMinRadius;                // 0x000010 (0x000008)
        double                                  SectorMaxRadius;                // 0x000018 (0x000008)
        EDynamicSectorRadialDistanceStrategy    RadialDistanceStrategy;         // 0x000020 (0x000001)
        uint8                                   UnknownData_000021[0x000003];   // 0x000021 (0x000003)
        float                                   UpdateLagSpeed;                 // 0x000024 (0x000004)
    };
    // Size: 0x000028 (0x000020)
    struct alignas(0x8) FAudioClusterAlgorithmTemplate_StaticSector : public FAudioClusterAlgorithmTemplate
    {
        int32   NumSectors;                     // 0x000008 (0x000004)
        float   FirstSectorStartAngle;          // 0x00000C (0x000004)
        double  SectorMinRadius;                // 0x000010 (0x000008)
        double  SectorMaxRadius;                // 0x000018 (0x000008)
        float   MinTimeInSector;                // 0x000020 (0x000004)
        uint8   UnknownData_000024[0x000004];   // 0x000024 (0x000004)
    };
    // Size: 0x000020 (0x000018)
    struct alignas(0x8) FAudioClusterAlgorithm_Cone : public FAudioClusterAlgorithmTemplate
    {
        double  SectorWidth;        // 0x000008 (0x000008) [Default: 2.3157e-291]
        double  SectorMinRadius;    // 0x000010 (0x000008) [Default: 1.87621e-315]
        double  SectorMaxRadius;    // 0x000018 (0x000008) [Default: 1.87611e-315]
    };
    // Size: 0x000008 (0x000008)
    struct FAudioClusterCondition
    {
        uint8   UnknownData_000000[0x000008];   // 0x000000 (0x000008)
    };
    // Size: 0x000010 (0x000008)
    struct alignas(0x4) FAudioClusterCondition_ActorTag : public FAudioClusterCondition
    {
        FName   Name;                           // 0x000008 (0x000004)
        uint8   UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
    };
    // Size: 0x000018 (0x000010)
    struct alignas(0x8) FAudioClusterCondition_All : public FAudioClusterCondition
    {
        TArray<FInstancedStruct>    Conditions; // 0x000008 (0x000010)
    };
    // Size: 0x000018 (0x000010)
    struct alignas(0x8) FAudioClusterCondition_Any : public FAudioClusterCondition
    {
        TArray<FInstancedStruct>    Conditions; // 0x000008 (0x000010)
    };
    // Size: 0x000018 (0x000010)
    struct alignas(0x8) FAudioClusterCondition_None : public FAudioClusterCondition
    {
        TArray<FInstancedStruct>    Conditions; // 0x000008 (0x000010)
    };
    // Size: 0x000028 (0x000020)
    struct alignas(0x8) FAudioClusterCondition_SubclassOf : public FAudioClusterCondition
    {
        TSoftClassPtr<UClass>   ParentClass;    // 0x000008 (0x000020)
    };
    // Size: 0x000050 (0x000048)
    struct alignas(0x8) FAudioClusterCondition_TagQuery : public FAudioClusterCondition
    {
        FGameplayTagQuery   Query;  // 0x000008 (0x000048)
    };
    // Size: 0x000080 (0x000080)
    struct alignas(0x8) FAudioClusterConfiguration
    {
        FGameplayTag                                    Name;                           // 0x000000 (0x000004)
        uint8                                           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FPerPlatformBool                                Enabled;                        // 0x000008 (0x000018)
        int32                                           MinQualityLevel;                // 0x000020 (0x000004)
        uint8                                           UnknownData_000024[0x000004];   // 0x000024 (0x000004)
        TMap<TSoftClassPtr<UClass>, FInstancedStruct>   TrackedActorClasses;            // 0x000028 (0x000010)
        FInstancedStruct                                GlobalFilter;                   // 0x000038 (0x000010)
        int32                                           MinSize;                        // 0x000048 (0x000004)
        uint8                                           UnknownData_00004C[0x000004];   // 0x00004C (0x000004)
        FPerPlatformInt                                 AlgorithmUpdateRateMs;          // 0x000050 (0x000018)
        FInstancedStruct                                AlgorithmTemplate;              // 0x000068 (0x000010)
        UAudioClusterBehavior*                          ClusterBehavior;                // 0x000078 (0x000008)
    };
    // Size: 0x000020 (0x000020)
    struct FAudioClusterConfigurationsHandle
    {
        uint8   UnknownData_000000[0x000020];   // 0x000000 (0x000020)
    };
    // Size: 0x000008 (0x000008)
    struct FAudioClusterData
    {
        uint8   UnknownData_000000[0x000008];   // 0x000000 (0x000008)
    };
    // Size: 0x000010 (0x000008)
    struct alignas(0x4) FAudioClusterData_StaticSector : public FAudioClusterData
    {
        int32   ClusterSectorIndex;             // 0x000008 (0x000004)
        uint8   UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
    };
}

