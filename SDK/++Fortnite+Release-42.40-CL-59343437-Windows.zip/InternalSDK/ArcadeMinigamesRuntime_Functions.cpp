/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArcadeMinigamesRuntime_Functions
 * ============================================================
 */

#include "ArcadeMinigamesRuntime_Functions.hpp"

namespace UE
{

    void UFortControllerComponent_ArcadeMinigame::BeginSession(UDynamicUIScene* Scene)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesRuntime.FortControllerComponent_ArcadeMinigame.BeginSession");
    
        UFortControllerComponent_ArcadeMinigame___BeginSession_Params Params{};
        Params.Scene = Scene;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortControllerComponent_ArcadeMinigame::ClientStartLocalArcade(UDynamicUIScene* Scene)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesRuntime.FortControllerComponent_ArcadeMinigame.ClientStartLocalArcade");
    
        UFortControllerComponent_ArcadeMinigame___ClientStartLocalArcade_Params Params{};
        Params.Scene = Scene;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortControllerComponent_ArcadeMinigame::ClientStopLocalArcade()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesRuntime.FortControllerComponent_ArcadeMinigame.ClientStopLocalArcade");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortControllerComponent_ArcadeMinigame::EndSession()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesRuntime.FortControllerComponent_ArcadeMinigame.EndSession");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    UFortControllerComponent_ArcadeMinigame* UFortControllerComponent_ArcadeMinigame::GetArcadeMinigameComponentForPlayer(APlayerController* PlayerController)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesRuntime.FortControllerComponent_ArcadeMinigame.GetArcadeMinigameComponentForPlayer");
    
        UFortControllerComponent_ArcadeMinigame___GetArcadeMinigameComponentForPlayer_Params Params{};
        Params.PlayerController = PlayerController;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UFortControllerComponent_ArcadeMinigame::IsInSession()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesRuntime.FortControllerComponent_ArcadeMinigame.IsInSession");
    
        UFortControllerComponent_ArcadeMinigame___IsInSession_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortControllerComponent_ArcadeMinigame::OnPawnDBNOStateChanged(AFortPawn* FortPawn, bool bInIsDBNO)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesRuntime.FortControllerComponent_ArcadeMinigame.OnPawnDBNOStateChanged");
    
        UFortControllerComponent_ArcadeMinigame___OnPawnDBNOStateChanged_Params Params{};
        Params.FortPawn = FortPawn;
        Params.bInIsDBNO = bInIsDBNO;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortControllerComponent_ArcadeMinigame::ServerRequestEndSession()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeMinigamesRuntime.FortControllerComponent_ArcadeMinigame.ServerRequestEndSession");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

} // namespace UE

