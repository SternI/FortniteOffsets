/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioClustersRuntime_Functions
 * ============================================================
 */

#include "AudioClustersRuntime_Functions.hpp"

namespace UE
{

    void UAudioClusterBehavior::OnActorAdded(AActor* Actor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioClustersRuntime.AudioClusterBehavior.OnActorAdded");
    
        UAudioClusterBehavior___OnActorAdded_Params Params{};
        Params.Actor = Actor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioClusterBehavior::OnActorRemoved(AActor* Actor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioClustersRuntime.AudioClusterBehavior.OnActorRemoved");
    
        UAudioClusterBehavior___OnActorRemoved_Params Params{};
        Params.Actor = Actor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioClusterBehavior::OnPositionUpdated(FVector& NewPosition)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioClustersRuntime.AudioClusterBehavior.OnPositionUpdated");
    
        UAudioClusterBehavior___OnPositionUpdated_Params Params{};
        Params.NewPosition = NewPosition;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        NewPosition = Params.NewPosition;
    }

    void UAudioClusterBehavior::OnSizeUpdated(int32 NewSize)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioClustersRuntime.AudioClusterBehavior.OnSizeUpdated");
    
        UAudioClusterBehavior___OnSizeUpdated_Params Params{};
        Params.NewSize = NewSize;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioClusterBehavior::OnStart(int32 InitialSize)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioClustersRuntime.AudioClusterBehavior.OnStart");
    
        UAudioClusterBehavior___OnStart_Params Params{};
        Params.InitialSize = InitialSize;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioClusterBehavior::OnStop()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioClustersRuntime.AudioClusterBehavior.OnStop");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    bool UAudioClusterFunctionLibrary::IsAudioClusterConfigurationsHandleValid(UObject* WorldContextObject, FAudioClusterConfigurationsHandle& Handle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioClustersRuntime.AudioClusterFunctionLibrary.IsAudioClusterConfigurationsHandleValid");
    
        UAudioClusterFunctionLibrary___IsAudioClusterConfigurationsHandleValid_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Handle = Handle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Handle = Params.Handle;
    
        return Params.ReturnValue;
    }

    FAudioClusterConfigurationsHandle UAudioClusterFunctionLibrary::RegisterClusterConfigurations(UObject* WorldContextObject, UAudioClusterConfigurations* Configurations)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioClustersRuntime.AudioClusterFunctionLibrary.RegisterClusterConfigurations");
    
        UAudioClusterFunctionLibrary___RegisterClusterConfigurations_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Configurations = Configurations;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioClusterFunctionLibrary::UnregisterClusterConfigurations(UObject* WorldContextObject, FAudioClusterConfigurationsHandle& Handle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioClustersRuntime.AudioClusterFunctionLibrary.UnregisterClusterConfigurations");
    
        UAudioClusterFunctionLibrary___UnregisterClusterConfigurations_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Handle = Handle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Handle = Params.Handle;
    }

} // namespace UE

