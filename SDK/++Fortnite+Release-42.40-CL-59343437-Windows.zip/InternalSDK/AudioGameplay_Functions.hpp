/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:09
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioGameplay_Functions
 * ============================================================
 */

#include "AudioGameplay.hpp"

namespace UE
{

    struct UAudioAssetUserData___GetAllTags_Params
    {
        USoundBase*             InSound;        // 0x000000 (0x000008) [Default: 0x133D06F0]
        FGameplayTagContainer   ReturnValue;    // 0x000008 (0x000020) [ReturnValue]
    };

    struct UAudioAssetUserData___GetFilteredTags_Params
    {
        USoundBase*             InSound;                        // 0x000000 (0x000008) [Default: 0x133D06F0]
        FGameplayTag            InTag;                          // 0x000008 (0x000004)
        uint8                   UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FGameplayTagContainer   ReturnValue;                    // 0x000010 (0x000020) [ReturnValue]
    };

    struct UAudioAssetUserData___HasTag_Params
    {
        USoundBase*     InSound;        // 0x000000 (0x000008) [Default: 0x133D06F0]
        FGameplayTag    InTag;          // 0x000008 (0x000004)
        bool            bExactMatch;    // 0x00000C (0x000001) [Default: true]
        bool            ReturnValue;    // 0x00000D (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioComponentGroup___AddExtension_Params
    {
        TScriptInterface<IAudioComponentGroupExtension> NewExtension;   // 0x000000 (0x000010)
    };

    struct UAudioComponentGroup___AddExternalComponent_Params
    {
        UAudioComponent*    ComponentToAdd; // 0x000000 (0x000008) [Default: 0x133D0B00]
    };

    struct UAudioComponentGroup___BroadcastEvent_Params
    {
        FName   EventName;  // 0x000000 (0x000004) [Default: FName(322767616) -> L""]
    };

    struct UAudioComponentGroup___GetBoolParamValue_Params
    {
        FName   ParamName;      // 0x000000 (0x000004) [Default: FName(322767616) -> L""]
        bool    ReturnValue;    // 0x000004 (0x000001) [ReturnValue] [Default: false]
    };

    struct UAudioComponentGroup___GetFloatParamValue_Params
    {
        FName   ParamName;      // 0x000000 (0x000004) [Default: FName(322767616) -> L""]
        float   ReturnValue;    // 0x000004 (0x000004) [ReturnValue] [Default: 0f]
    };

    struct UAudioComponentGroup___GetStringParamValue_Params
    {
        FName   ParamName;                      // 0x000000 (0x000004) [Default: FName(322767616) -> L""]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FString ReturnValue;                    // 0x000008 (0x000010) [ReturnValue] [Default: L""]
    };

    struct UAudioComponentGroup___IsPlayingAny_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: false]
    };

    struct UAudioComponentGroup___IsVirtualized_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: false]
    };

    struct UAudioComponentGroup___RemoveExtension_Params
    {
        TScriptInterface<IAudioComponentGroupExtension> NewExtension;   // 0x000000 (0x000010)
    };

    struct UAudioComponentGroup___RemoveExternalComponent_Params
    {
        UAudioComponent*    ComponentToRemove;  // 0x000000 (0x000008) [Default: 0x133D0B00]
    };

    struct UAudioComponentGroup___SetLowPassFilter_Params
    {
        float   InFrequency;    // 0x000000 (0x000004) [Default: 2.38606e-27f]
    };

    struct UAudioComponentGroup___SetPitchMultiplier_Params
    {
        float   InPitch;    // 0x000000 (0x000004) [Default: 2.38606e-27f]
    };

    struct UAudioComponentGroup___SetVolumeMultiplier_Params
    {
        float   InVolume;   // 0x000000 (0x000004) [Default: 2.38606e-27f]
    };

    struct UAudioComponentGroup___StaticGetOrCreateComponentGroup_Params
    {
        AActor*                 Actor;          // 0x000000 (0x000008) [Default: 0x133D0B00]
        UAudioComponentGroup*   ReturnValue;    // 0x000008 (0x000008) [ReturnValue] [Default: 0x776E18DD00000031]
    };

    struct UAudioComponentGroup___StopSound_Params
    {
        USoundBase* Sound;      // 0x000000 (0x000008) [Default: 0x133D0B00]
        float       FadeTime;   // 0x000008 (0x000004) [Default: 6.86636e-44f]
    };

    struct UAudioComponentGroup___SubscribeToBool_Params
    {
        FName               ParamName;  // 0x000000 (0x000004) [Default: FName(322767616) -> L""]
        BoolParamCallback   Delegate;   // 0x000004 (0x00000C)
    };

    struct UAudioComponentGroup___SubscribeToEvent_Params
    {
        FName           EventName;  // 0x000000 (0x000004) [Default: FName(322767616) -> L""]
        SoundCallback   Delegate;   // 0x000004 (0x00000C)
    };

    struct UAudioComponentGroup___SubscribeToStringParam_Params
    {
        FName               ParamName;  // 0x000000 (0x000004) [Default: FName(322767616) -> L""]
        StringParamCallback Delegate;   // 0x000004 (0x00000C)
    };

    struct UAudioComponentGroup___UnsubscribeObject_Params
    {
        UObject*    Object; // 0x000000 (0x000008) [Default: 0x133D0B00]
    };

    struct IAudioGameplayCondition___ConditionMet_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct IAudioGameplayCondition___ConditionMet_Position_Params
    {
        FVector Position;       // 0x000000 (0x000018) [OutParam]
        bool    ReturnValue;    // 0x000018 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioParameterComponent___GetParameters_Params
    {
        TArray<FAudioParameter> ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

} // namespace UE

