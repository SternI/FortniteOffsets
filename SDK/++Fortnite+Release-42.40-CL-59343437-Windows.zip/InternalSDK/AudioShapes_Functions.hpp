/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioShapes_Functions
 * ============================================================
 */

#include "AudioShapes.hpp"

namespace UE
{

    struct UAudioShapeBoxComponent___SetBoxTransform_Params
    {
        FTransform  InTransform;    // 0x000000 (0x000060) [OutParam]
    };

    struct UAudioShapeComponent___IsAudioShapeReady_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioShapeComponent___IsShapeActive_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioShapeComponent___UpdateAudioShape_Params
    {
        TArray<APlayerController*>  InLocalControllers; // 0x000000 (0x000010) [OutParam]
    };

    struct UAudioShapeCylinderComponent___SetHalfHeight_Params
    {
        float   InHalfHeight;   // 0x000000 (0x000004) [Default: 2.9769e-27f]
    };

    struct UAudioShapeCylinderComponent___SetRadius_Params
    {
        float   InRadius;   // 0x000000 (0x000004) [Default: 2.9769e-27f]
    };

    struct UAudioShapeLineComponent___SetEndPoint_Params
    {
        FVector InEndPoint; // 0x000000 (0x000018) [OutParam]
    };

    struct UAudioShapeLineComponent___SetStartPoint_Params
    {
        FVector InStartPoint;   // 0x000000 (0x000018) [OutParam]
    };

    struct UAudioShapeLineListComponent___AddPoint_Params
    {
        FVector InPoint;        // 0x000000 (0x000018) [OutParam]
        int32   ReturnValue;    // 0x000018 (0x000004) [ReturnValue] [Default: 393201792]
    };

    struct UAudioShapeLineListComponent___GetPoints_Params
    {
        TArray<FVector> OutPoints;  // 0x000000 (0x000010) [OutParam]
    };

    struct UAudioShapeLineListComponent___RemovePoint_Params
    {
        int32   InIndex;        // 0x000000 (0x000004) [Default: 325838384]
        bool    ReturnValue;    // 0x000004 (0x000001) [ReturnValue] [Default: false]
    };

    struct UAudioShapeLineListComponent___UpdatePoint_Params
    {
        int32   InIndex;                        // 0x000000 (0x000004) [Default: 325838384]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FVector InPoint;                        // 0x000008 (0x000018) [OutParam]
        bool    ReturnValue;                    // 0x000020 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioShapePrimitiveComponent___GetEdgeAudioComponent_Params
    {
        UAudioComponent*    ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x136BEBF0]
    };

    struct UAudioShapePrimitiveComponent___GetInsideAudioComponent_Params
    {
        UAudioComponent*    ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x136BEBF0]
    };

    struct UAudioShapePrimitiveComponent___GetIsPlayerInside_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioShapeSphereComponent___SetRadius_Params
    {
        float   InRadius;   // 0x000000 (0x000004) [Default: 2.97804e-27f]
    };

    struct UAudioShapeSplineComponent___GetAudioComponent_Params
    {
        UAudioComponent*    ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x136BF710]
    };

    struct UAudioShapeSplineComponent___SetSpline_Params
    {
        USplineComponent*   NewSpline;  // 0x000000 (0x000008) [Default: 0x136BF710]
    };

} // namespace UE

