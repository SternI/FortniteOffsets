/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AIPromptUI
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0000F0 (0x000048)
    class UPersonaPermissionButtonVM : public UUIKitDialogButtonViewModel
    {
    public:
        uint8   UnknownData_0000A8[0x000048];   // 0x0000A8 (0x000048)
    };
    // Size: 0x000180 (0x000108)
    class alignas(0x8) UPersonaPermissionVM : public UFortPerUserViewModel
    {
    public:
        MULTI_INLINE_DELEGATE(OnPersonaConsentInProgress)   OnConsentRequestedInProgressEvent;  // 0x000078 (0x000010)
        MULTI_INLINE_DELEGATE(OnPersonaConsentSuccess)      OnConsentRequestedSuccessEvent;     // 0x000088 (0x000010)
        MULTI_INLINE_DELEGATE(OnPersonaConsentFailure)      OnConsentRequestedFailureEvent;     // 0x000098 (0x000010)
        MULTI_INLINE_DELEGATE(OnPersonaPermissionGranted)   OnPermissionGranted;                // 0x0000A8 (0x000010)
        uint8                                               UnknownData_0000B8[0x000008];       // 0x0000B8 (0x000008)
        FText                                               Title;                              // 0x0000C0 (0x000010)
        FText                                               Description;                        // 0x0000D0 (0x000010)
        FText                                               DescriptionParentalControl;         // 0x0000E0 (0x000010)
        FText                                               DescriptionCabined;                 // 0x0000F0 (0x000010)
        FText                                               RequestText;                        // 0x000100 (0x000010)
        FText                                               PINText;                            // 0x000110 (0x000010)
        FText                                               Back;                               // 0x000120 (0x000010)
        FText                                               ConsentRequestInProgressText;       // 0x000130 (0x000010)
        FText                                               ConsentRequestSuccessText;          // 0x000140 (0x000010)
        FText                                               ConsentRequestFailureText;          // 0x000150 (0x000010)
        TArray<UPersonaPermissionButtonVM*>                 Buttons;                            // 0x000160 (0x000010)
        uint8                                               UnknownData_000170[0x000008];       // 0x000170 (0x000008)
        UAmpleHammerPINModalHelper*                         PINModalHelper;                     // 0x000178 (0x000008) [Default: nullptr]
    
    public: // Functions
        bool    OnButtonClicked(int32 ButtonIndex); // 0x08201918 [Final | Native | Public | BlueprintCallable]
    };
}

