/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AdHocSquadsRuntime_Functions
 * ============================================================
 */

#include "AdHocSquadsRuntime.hpp"

namespace UE
{

    struct UAdHocSquadPawnOutlineComponent___HandlePlayerSquadChanged_Params
    {
        AFortPlayerStateAthena* InPlayerState;      // 0x000000 (0x000008) [Default: 0x1488F290]
        uint8                   PreviousSquadId;    // 0x000008 (0x000001) [Default: 49]
    };

    struct UAdHocSquadPawnOutlineComponent___OnRep_AdHocSquadId_Params
    {
        uint8   PreviousAdHocSquadId;   // 0x000000 (0x000001) [Default: 144]
    };

} // namespace UE

