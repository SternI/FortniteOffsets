/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AndroidFileServer_Functions
 * ============================================================
 */

#include "AndroidFileServer_Functions.hpp"

namespace UE
{

    TEnumAsByte<EAFSActiveType> UAndroidFileServerBPLibrary::IsFileServerRunning()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AndroidFileServer.AndroidFileServerBPLibrary.IsFileServerRunning");
    
        UAndroidFileServerBPLibrary___IsFileServerRunning_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAndroidFileServerBPLibrary::StartFileServer(bool bUSB, bool bNetwork, int32 Port)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AndroidFileServer.AndroidFileServerBPLibrary.StartFileServer");
    
        UAndroidFileServerBPLibrary___StartFileServer_Params Params{};
        Params.bUSB = bUSB;
        Params.bNetwork = bNetwork;
        Params.Port = Port;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAndroidFileServerBPLibrary::StopFileServer(bool bUSB, bool bNetwork)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AndroidFileServer.AndroidFileServerBPLibrary.StopFileServer");
    
        UAndroidFileServerBPLibrary___StopFileServer_Params Params{};
        Params.bUSB = bUSB;
        Params.bNetwork = bNetwork;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

} // namespace UE

