/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArmoryRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FFortWeaponComponentData
    {
        TWeakObjectPtr<AFortWeapon>                     WeakWeapon;         // 0x000000 (0x000008) [Default: nullptr]
        TWeakObjectPtr<UFortRootItemizationInventory>   WeakRootInventory;  // 0x000008 (0x000008) [Default: nullptr]
        FGuid                                           ItemID;             // 0x000010 (0x000010)
    };
}

