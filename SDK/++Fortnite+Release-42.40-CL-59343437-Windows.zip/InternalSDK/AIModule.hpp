/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:08
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AIModule
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000390 (0x000088)
    class alignas(0x8) AAIController : public AController
    {
    public:
        void**                                          VTable_000308;                          // 0x000308 (0x000008) VTable [3 slots] -> 0x132AD130
        void**                                          VTable_000310;                          // 0x000310 (0x000008) VTable [9 slots] -> 0x132AD150
        void**                                          VTable_000318;                          // 0x000318 (0x000008) VTable [5 slots] -> 0x132AD1A0
        void**                                          VTable_000320;                          // 0x000320 (0x000008) VTable [3 slots] -> 0x132AD1D0
        uint8                                           UnknownData_000328[0x000018];           // 0x000328 (0x000018)
        uint8                                           bStartAILogicOnPossess : 1;             // 0x000340 (0x000001) : 0x0 [Default: true]
        uint8                                           bStopAILogicOnUnposses : 1;             // 0x000340 (0x000001) : 0x0 [Default: true]
        uint8                                           bLOSflag : 1;                           // 0x000340 (0x000001) : 0x0 [Default: true]
        uint8                                           bSkipExtraLOSChecks : 1;                // 0x000340 (0x000001) : 0x0 [Default: true]
        uint8                                           bAllowStrafe : 1;                       // 0x000340 (0x000001) : 0x0 [Default: true]
        uint8                                           bWantsPlayerState : 1;                  // 0x000340 (0x000001) : 0x0 [Default: true]
        uint8                                           bSetControlRotationFromPawnOrientation : 1; // 0x000340 (0x000001) : 0x0 [Default: true]
        uint8                                           bSkipRootComponentUpdate : 1;           // 0x000340 (0x000001) : 0x0 [Default: true]
        uint8                                           UnknownBit_000340_1 : 1;                // 0x000340 (0x000001) : 0x1
        uint8                                           UnknownBit_000340_2 : 1;                // 0x000340 (0x000001) : 0x2
        uint8                                           UnknownBit_000340_3 : 1;                // 0x000340 (0x000001) : 0x3
        uint8                                           UnknownBit_000340_4 : 1;                // 0x000340 (0x000001) : 0x4
        uint8                                           UnknownBit_000340_5 : 1;                // 0x000340 (0x000001) : 0x5
        uint8                                           UnknownBit_000340_6 : 1;                // 0x000340 (0x000001) : 0x6
        uint8                                           UnknownBit_000340_7 : 1;                // 0x000340 (0x000001) : 0x7
        uint8                                           UnknownData_000341[0x000007];           // 0x000341 (0x000007)
        UPathFollowingComponent*                        PathFollowingComponent;                 // 0x000348 (0x000008) [Default: 0x7FE8386AFA00]
        UBrainComponent*                                BrainComponent;                         // 0x000350 (0x000008) [Default: nullptr]
        UAIPerceptionComponent*                         PerceptionComponent;                    // 0x000358 (0x000008) [Default: nullptr]
        UBlackboardComponent*                           Blackboard;                             // 0x000360 (0x000008) [Default: nullptr]
        UGameplayTasksComponent*                        CachedGameplayTasksComponent;           // 0x000368 (0x000008) [Default: nullptr]
        UClass*                                         DefaultNavigationFilterClass;           // 0x000370 (0x000008) [Default: nullptr]
        MULTI_INLINE_DELEGATE(AIMoveCompletedSignature) ReceiveMoveCompleted;                   // 0x000378 (0x000010)
        uint8                                           UnknownData_000388[0x000008];           // 0x000388 (0x000008)
    
    public: // Functions
        void                                        ClaimTaskResource(UClass* ResourceClass); // 0x050113D4 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        UAIPerceptionComponent*                     GetAIPerceptionComponent(); // 0x0DB4C2C4 [Final | Native | Public | BlueprintCallable | BlueprintPure]
        FVector                                     GetFocalPoint(); // 0x0DB4C2E0 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        FVector                                     GetFocalPointOnActor(AActor* Actor); // 0x0501154A [RequiredAPI | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        AActor*                                     GetFocusActor(); // 0x0DB4C440 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FVector                                     GetImmediateMoveDestination(); // 0x0DB4C532 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        TEnumAsByte<EPathFollowingStatus>           GetMoveStatus(); // 0x0DB4C5FE [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UPathFollowingComponent*                    GetPathFollowingComponent(); // 0x0DB4C640 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                                        HasPartialPath(); // 0x0DB4C65C [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                                        K2_ClearFocus(); // 0x0DB4C698 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                                        K2_SetFocalPoint(FVector FP); // 0x050116DA [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void                                        K2_SetFocus(AActor* NewFocus); // 0x0501185A [Final | RequiredAPI | Native | Public | BlueprintCallable]
        TEnumAsByte<EPathFollowingRequestResult>    MoveToActor(AActor* Goal, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bCanStrafe, UClass* FilterClass, bool bAllowPartialPath); // 0x050119D2 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        TEnumAsByte<EPathFollowingRequestResult>    MoveToLocation(FVector& Dest, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bProjectDestinationToNavigation, bool bCanStrafe, UClass* FilterClass, bool bAllowPartialPath); // 0x050120D8 [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        void                                        OnGameplayTaskResourcesClaimed(FGameplayResourceSet NewlyClaimed, FGameplayResourceSet FreshlyReleased); // 0x05012918 [RequiredAPI | Native | Public]
        void                                        OnUsingBlackBoard(UBlackboardComponent* BlackboardComp, UBlackboardData* BlackboardAsset); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        bool                                        RunBehaviorTree(UBehaviorTree* BTAsset); // 0x05012BA0 [RequiredAPI | Native | Public | BlueprintCallable]
        void                                        SetMoveBlockDetection(bool bEnable); // 0x05012D1C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                                        SetPathFollowingComponent(UPathFollowingComponent* NewPFComponent); // 0x05012EB0 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                                        UnclaimTaskResource(UClass* ResourceClass); // 0x05013038 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        bool                                        UseBlackboard(UBlackboardData* BlackboardAsset, UBlackboardComponent*& BlackboardComponent); // 0x050131AE [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000390 (0x000000)
    class ADetourCrowdAIController : public AAIController
    {
    public:
    };
    // Size: 0x0006D0 (0x0000A0)
    class alignas(0x8) AEQSTestingPawn : public ACharacter
    {
    public:
        void**                          VTable_000630;                  // 0x000630 (0x000008) VTable [7 slots] -> 0x132C4610
        UEnvQuery*                      QueryTemplate;                  // 0x000638 (0x000008) [Default: nullptr]
        TArray<FEnvNamedValue>          QueryParams;                    // 0x000640 (0x000010)
        TArray<FAIDynamicParam>         QueryConfig;                    // 0x000650 (0x000010)
        float                           TimeLimitPerStep;               // 0x000660 (0x000004) [Default: -1f]
        int32                           StepToDebugDraw;                // 0x000664 (0x000004) [Default: 0]
        EEnvQueryHightlightMode         HighlightMode;                  // 0x000668 (0x000001) [Default: EEnvQueryHightlightMode(0)]
        uint8                           UnknownData_000669[0x000003];   // 0x000669 (0x000003)
        uint8                           bDrawLabels : 1;                // 0x00066C (0x000001) : 0x0 [Default: true]
        uint8                           bDrawFailedItems : 1;           // 0x00066C (0x000001) : 0x0 [Default: true]
        uint8                           bReRunQueryOnlyOnFinishedMove : 1; // 0x00066C (0x000001) : 0x0 [Default: true]
        uint8                           bShouldBeVisibleInGame : 1;     // 0x00066C (0x000001) : 0x0 [Default: true]
        uint8                           bTickDuringGame : 1;            // 0x00066C (0x000001) : 0x0 [Default: true]
        uint8                           bRunQueryOnSelectionChanged : 1; // 0x00066C (0x000001) : 0x0 [Default: true]
        uint8                           bDrawItemOrientation : 1;       // 0x00066C (0x000001) : 0x0 [Default: true]
        uint8                           UnknownBit_00066C_1 : 1;        // 0x00066C (0x000001) : 0x1
        uint8                           UnknownBit_00066C_2 : 1;        // 0x00066C (0x000001) : 0x2
        uint8                           UnknownBit_00066C_3 : 1;        // 0x00066C (0x000001) : 0x3
        uint8                           UnknownBit_00066C_4 : 1;        // 0x00066C (0x000001) : 0x4
        uint8                           UnknownBit_00066C_5 : 1;        // 0x00066C (0x000001) : 0x5
        uint8                           UnknownBit_00066C_6 : 1;        // 0x00066C (0x000001) : 0x6
        uint8                           UnknownBit_00066C_7 : 1;        // 0x00066C (0x000001) : 0x7
        uint8                           UnknownData_00066D[0x000003];   // 0x00066D (0x000003)
        TEnumAsByte<EEnvQueryRunMode>   QueryingMode;                   // 0x000670 (0x000001) [Default: 3]
        uint8                           UnknownData_000671[0x000007];   // 0x000671 (0x000007)
        FNavAgentProperties             NavAgentProperties;             // 0x000678 (0x000030)
        uint8                           UnknownData_0006A8[0x000010];   // 0x0006A8 (0x000010)
        TArray<FEnvQueryInstance>       StepResults;                    // 0x0006B8 (0x000010)
        uint8                           UnknownData_0006C8[0x000008];   // 0x0006C8 (0x000008)
    };
    // Size: 0x000390 (0x000000)
    class AGridPathAIController : public AAIController
    {
    public:
    };
    // Size: 0x0002C0 (0x000050)
    class alignas(0x8) ANavLinkProxy : public AActor
    {
    public:
        void**                                              VTable_000270;                  // 0x000270 (0x000008) VTable [20 slots] -> 0x132CE4A0
        void**                                              VTable_000278;                  // 0x000278 (0x000008) VTable [16 slots] -> 0x132CE4C0
        TArray<FNavigationLink>                             PointLinks;                     // 0x000280 (0x000010)
        TArray<FNavigationSegmentLink>                      SegmentLinks;                   // 0x000290 (0x000010)
        UNavLinkCustomComponent*                            SmartLinkComp;                  // 0x0002A0 (0x000008) [Default: 0x7FE838E9CFD0]
        bool                                                bSmartLinkIsRelevant;           // 0x0002A8 (0x000001) [Default: false]
        uint8                                               UnknownData_0002A9[0x000007];   // 0x0002A9 (0x000007)
        MULTI_INLINE_DELEGATE(SmartLinkReachedSignature)    OnSmartLinkReached;             // 0x0002B0 (0x000010)
    
    public: // Functions
        bool    HasMovingAgents(); // 0x0DB970E2 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool    IsSmartLinkEnabled(); // 0x0DB9710E [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    ReceiveSmartLinkReached(AActor* Agent, FVector& Destination); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | HasDefaults | BlueprintEvent]
        void    ResumePathFollowing(AActor* Agent); // 0x0504BB42 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetSmartLinkEnabled(bool bEnabled); // 0x0504BCB0 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000068 (0x000040)
    class alignas(0x8) UAIAsyncTaskBlueprintProxy : public UObject
    {
    public:
        MULTI_INLINE_DELEGATE(OAISimpleDelegate)    OnSuccess;                      // 0x000028 (0x000010)
        MULTI_INLINE_DELEGATE(OAISimpleDelegate)    OnFail;                         // 0x000038 (0x000010)
        uint8                                       UnknownData_000048[0x000020];   // 0x000048 (0x000020)
    
    public: // Functions
        void    OnMoveCompleted(FAIRequestID RequestID, TEnumAsByte<EPathFollowingResult> MovementResult); // 0x05011158 [Final | RequiredAPI | Native | Public]
    };
    // Size: 0x000028 (0x000000)
    class UAIBlueprintHelperLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static UAIAsyncTaskBlueprintProxy* CreateMoveToProxyObject(UObject* WorldContextObject, APawn* Pawn, FVector Destination, AActor* TargetActor, float AcceptanceRadius, bool bStopOnOverlap); // 0x05028504 [Final | RequiredAPI | Native | Static | Public | HasDefaults | BlueprintCallable]
        static AAIController*              GetAIController(AActor* ControlledActor); // 0x05029014 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static UBlackboardComponent*       GetBlackboard(AActor* Target); // 0x05029182 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static UNavigationPath*            GetCurrentPath(AController* Controller); // 0x050292F0 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static int32                       GetCurrentPathIndex(AController* Controller); // 0x0502945E [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static TArray<FVector>             GetCurrentPathPoints(AController* Controller); // 0x050295DE [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static int32                       GetNextNavLinkIndex(AController* Controller); // 0x0502976A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static bool                        IsValidAIDirection(FVector DirectionVector); // 0x050298D8 [Final | RequiredAPI | Native | Static | Public | HasDefaults | BlueprintCallable | BlueprintPure]
        static bool                        IsValidAILocation(FVector Location); // 0x05029AA6 [Final | RequiredAPI | Native | Static | Public | HasDefaults | BlueprintCallable | BlueprintPure]
        static bool                        IsValidAIRotation(FRotator Rotation); // 0x05029C42 [Final | RequiredAPI | Native | Static | Public | HasDefaults | BlueprintCallable | BlueprintPure]
        static void                        LockAIResourcesWithAnimation(UAnimInstance* AnimInstance, bool bLockMovement, bool LockAILogic); // 0x05029DD8 [Final | RequiredAPI | BlueprintAuthorityOnly | Native | Static | Public | BlueprintCallable]
        static void                        SendAIMessage(APawn* Target, FName Message, UObject* MessageSource, bool bSuccess); // 0x0502A16A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                        SimpleMoveToActor(AController* Controller, AActor* Goal); // 0x0502A55A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                        SimpleMoveToLocation(AController* Controller, FVector& Goal); // 0x0502B326 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static APawn*                      SpawnAIFromClass(UObject* WorldContextObject, UClass* PawnClass, UBehaviorTree* BehaviorTree, FVector Location, FRotator Rotation, bool bNoCollisionFail, AActor* Owner); // 0x0502BFC4 [Final | RequiredAPI | Native | Static | Public | HasDefaults | BlueprintCallable]
        static void                        UnlockAIResourcesWithAnimation(UAnimInstance* AnimInstance, bool bUnlockMovement, bool UnlockAILogic); // 0x0502C6DE [Final | RequiredAPI | BlueprintAuthorityOnly | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class UAIDataProvider : public UObject
    {
    public:
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x4) UAIDataProvider_QueryParams : public UAIDataProvider
    {
    public:
        FName   ParamName;                      // 0x000028 (0x000004) [Default: NAME_None]
        float   FloatValue;                     // 0x00002C (0x000004) [Default: 0f]
        int32   IntValue;                       // 0x000030 (0x000004) [Default: 0]
        bool    BoolValue;                      // 0x000034 (0x000001) [Default: false]
        uint8   UnknownData_000035[0x000003];   // 0x000035 (0x000003)
    };
    // Size: 0x000048 (0x000010)
    class alignas(0x4) UAIDataProvider_Random : public UAIDataProvider_QueryParams
    {
    public:
        float   min;                            // 0x000038 (0x000004) [Default: 0f]
        float   max;                            // 0x00003C (0x000004) [Default: 1f]
        uint8   bInteger : 1;                   // 0x000040 (0x000001) : 0x0 [Default: false]
        uint8   UnknownBit_000040_1 : 1;        // 0x000040 (0x000001) : 0x1
        uint8   UnknownBit_000040_2 : 1;        // 0x000040 (0x000001) : 0x2
        uint8   UnknownBit_000040_3 : 1;        // 0x000040 (0x000001) : 0x3
        uint8   UnknownBit_000040_4 : 1;        // 0x000040 (0x000001) : 0x4
        uint8   UnknownBit_000040_5 : 1;        // 0x000040 (0x000001) : 0x5
        uint8   UnknownBit_000040_6 : 1;        // 0x000040 (0x000001) : 0x6
        uint8   UnknownBit_000040_7 : 1;        // 0x000040 (0x000001) : 0x7
        uint8   UnknownData_000041[0x000007];   // 0x000041 (0x000007)
    };
    // Size: 0x000028 (0x000000)
    class UAIHotSpotManager : public UObject
    {
    public:
    };
    // Size: 0x000168 (0x0000A8)
    class alignas(0x8) UAIPerceptionComponent : public UActorComponent
    {
    public:
        TArray<UAISenseConfig*>                                     SensesConfig;                   // 0x0000C0 (0x000010)
        UClass*                                                     DominantSense;                  // 0x0000D0 (0x000008) [Default: nullptr]
        uint8                                                       UnknownData_0000D8[0x000008];   // 0x0000D8 (0x000008)
        AAIController*                                              AIOwner;                        // 0x0000E0 (0x000008) [Default: nullptr]
        uint8                                                       UnknownData_0000E8[0x000040];   // 0x0000E8 (0x000040)
        MULTI_INLINE_DELEGATE(PerceptionUpdatedDelegate)            OnPerceptionUpdated;            // 0x000128 (0x000010)
        MULTI_INLINE_DELEGATE(ActorPerceptionForgetUpdatedDelegate) OnTargetPerceptionForgotten;    // 0x000138 (0x000010)
        MULTI_INLINE_DELEGATE(ActorPerceptionUpdatedDelegate)       OnTargetPerceptionUpdated;      // 0x000148 (0x000010)
        MULTI_INLINE_DELEGATE(ActorPerceptionInfoUpdatedDelegate)   OnTargetPerceptionInfoUpdated;  // 0x000158 (0x000010)
    
    public: // Functions
        void    ForgetAll(); // 0x0DBA0D4C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        bool    GetActorsPerception(AActor* Actor, FActorPerceptionBlueprintInfo& Info); // 0x0504F090 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void    GetCurrentlyPerceivedActors(UClass* SenseToUse, TArray<AActor*>& OutActors); // 0x0504F436 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        void    GetKnownPerceivedActors(UClass* SenseToUse, TArray<AActor*>& OutActors); // 0x0504F6DC [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        void    GetPerceivedHostileActors(TArray<AActor*>& OutActors); // 0x0504F982 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        void    GetPerceivedHostileActorsBySense(UClass* SenseToUse, TArray<AActor*>& OutActors); // 0x0504FB14 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        bool    IsSenseEnabled(UClass* SenseClass); // 0x0504FDD6 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    OnOwnerEndPlay(AActor* Actor, TEnumAsByte<EEndPlayReason> EndPlayReason); // 0x0504FF54 [Final | RequiredAPI | Native | Public]
        void    RequestStimuliListenerUpdate(); // 0x0DBA10DC [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetSenseEnabled(UClass* SenseClass, bool bEnable); // 0x050501E0 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class IAIPerceptionListenerInterface : public IInterface
    {
    public:
    };
    // Size: 0x0000D8 (0x000018)
    class alignas(0x8) UAIPerceptionStimuliSourceComponent : public UActorComponent
    {
    public:
        uint8           bAutoRegisterAsSource : 1;      // 0x0000C0 (0x000001) : 0x0 [Default: false]
        uint8           UnknownBit_0000C0_1 : 1;        // 0x0000C0 (0x000001) : 0x1
        uint8           UnknownBit_0000C0_2 : 1;        // 0x0000C0 (0x000001) : 0x2
        uint8           UnknownBit_0000C0_3 : 1;        // 0x0000C0 (0x000001) : 0x3
        uint8           UnknownBit_0000C0_4 : 1;        // 0x0000C0 (0x000001) : 0x4
        uint8           UnknownBit_0000C0_5 : 1;        // 0x0000C0 (0x000001) : 0x5
        uint8           UnknownBit_0000C0_6 : 1;        // 0x0000C0 (0x000001) : 0x6
        uint8           UnknownBit_0000C0_7 : 1;        // 0x0000C0 (0x000001) : 0x7
        uint8           UnknownData_0000C1[0x000007];   // 0x0000C1 (0x000007)
        TArray<UClass*> RegisterAsSourceForSenses;      // 0x0000C8 (0x000010)
    
    public: // Functions
        void    RegisterForSense(UClass* SenseClass); // 0x05051C92 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    RegisterWithPerceptionSystem(); // 0x0DBA34BC [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    UnregisterFromPerceptionSystem(); // 0x0DBA35FA [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    UnregisterFromSense(UClass* SenseClass); // 0x05051E08 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x0000E0 (0x0000A8)
    class alignas(0x8) UAIPerceptionSystem : public UAISubsystem
    {
    public:
        uint8               UnknownData_000038[0x000010];   // 0x000038 (0x000010)
        TArray<UAISense*>   Senses;                         // 0x000048 (0x000010)
        float               PerceptionAgingRate;            // 0x000058 (0x000004) [Default: 0.3f]
        uint8               UnknownData_00005C[0x000084];   // 0x00005C (0x000084)
    
    public: // Functions
        static UClass* GetSenseClassForStimulus(UObject* WorldContextObject, FAIStimulus& Stimulus); // 0x05051F7E [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        void    OnPerceptionStimuliSourceEndPlay(AActor* Actor, TEnumAsByte<EEndPlayReason> EndPlayReason); // 0x05052294 [Final | RequiredAPI | Native | Protected]
        static bool    RegisterPerceptionStimuliSource(UObject* WorldContextObject, UClass* Sense, AActor* Target); // 0x05052518 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        void    ReportEvent(UAISenseEvent* PerceptionEvent); // 0x050528B2 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        static void    ReportPerceptionEvent(UObject* WorldContextObject, UAISenseEvent* PerceptionEvent); // 0x05052A20 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class IAIResourceInterface : public IInterface
    {
    public:
    };
    // Size: 0x000038 (0x000000)
    class UAIResource_Logic : public UGameplayTaskResource
    {
    public:
    };
    // Size: 0x000038 (0x000000)
    class UAIResource_Movement : public UGameplayTaskResource
    {
    public:
    };
    // Size: 0x000078 (0x000050)
    class alignas(0x8) UAISense : public UObject
    {
    public:
        EAISenseNotifyType      NotifyType;                     // 0x000028 (0x000001) [Default: EAISenseNotifyType(0)]
        uint8                   UnknownData_000029[0x000003];   // 0x000029 (0x000003)
        uint8                   bWantsNewPawnNotification : 1;  // 0x00002C (0x000001) : 0x0 [Default: false]
        uint8                   bAutoRegisterAllPawnsAsSources : 1; // 0x00002C (0x000001) : 0x0 [Default: false]
        uint8                   UnknownBit_00002C_1 : 1;        // 0x00002C (0x000001) : 0x1
        uint8                   UnknownBit_00002C_2 : 1;        // 0x00002C (0x000001) : 0x2
        uint8                   UnknownBit_00002C_3 : 1;        // 0x00002C (0x000001) : 0x3
        uint8                   UnknownBit_00002C_4 : 1;        // 0x00002C (0x000001) : 0x4
        uint8                   UnknownBit_00002C_5 : 1;        // 0x00002C (0x000001) : 0x5
        uint8                   UnknownBit_00002C_6 : 1;        // 0x00002C (0x000001) : 0x6
        uint8                   UnknownBit_00002C_7 : 1;        // 0x00002C (0x000001) : 0x7
        uint8                   UnknownData_00002D[0x000003];   // 0x00002D (0x000003)
        UAIPerceptionSystem*    PerceptionSystemInstance;       // 0x000030 (0x000008) [Default: nullptr]
        uint8                   UnknownData_000038[0x000040];   // 0x000038 (0x000040)
    };
    // Size: 0x000120 (0x000000)
    class UAISenseBlueprintListener : public UUserDefinedStruct
    {
    public:
    };
    // Size: 0x000048 (0x000020)
    class alignas(0x4) UAISenseConfig : public UObject
    {
    public:
        FColor  DebugColor;                     // 0x000028 (0x000004)
        float   MaxAge;                         // 0x00002C (0x000004) [Default: 0f]
        uint8   bStartsEnabled : 1;             // 0x000030 (0x000001) : 0x0 [Default: true]
        uint8   UnknownBit_000030_1 : 1;        // 0x000030 (0x000001) : 0x1
        uint8   UnknownBit_000030_2 : 1;        // 0x000030 (0x000001) : 0x2
        uint8   UnknownBit_000030_3 : 1;        // 0x000030 (0x000001) : 0x3
        uint8   UnknownBit_000030_4 : 1;        // 0x000030 (0x000001) : 0x4
        uint8   UnknownBit_000030_5 : 1;        // 0x000030 (0x000001) : 0x5
        uint8   UnknownBit_000030_6 : 1;        // 0x000030 (0x000001) : 0x6
        uint8   UnknownBit_000030_7 : 1;        // 0x000030 (0x000001) : 0x7
        uint8   UnknownData_000031[0x000017];   // 0x000031 (0x000017)
    };
    // Size: 0x000050 (0x000008)
    class alignas(0x8) UAISenseConfig_Blueprint : public UAISenseConfig
    {
    public:
        UClass* Implementation; // 0x000048 (0x000008) [Default: nullptr]
    };
    // Size: 0x000050 (0x000008)
    class alignas(0x8) UAISenseConfig_Damage : public UAISenseConfig
    {
    public:
        UClass* Implementation; // 0x000048 (0x000008) [Default: 0x17340680]
    };
    // Size: 0x000060 (0x000018)
    class alignas(0x8) UAISenseConfig_Hearing : public UAISenseConfig
    {
    public:
        UClass*                     Implementation;                 // 0x000048 (0x000008) [Default: 0x17340810]
        float                       HearingRange;                   // 0x000050 (0x000004) [Default: 3000f]
        float                       LoSHearingRange;                // 0x000054 (0x000004) [Default: 0f]
        uint8                       bUseLoSHearing : 1;             // 0x000058 (0x000001) : 0x0 [Default: false]
        uint8                       UnknownBit_000058_1 : 1;        // 0x000058 (0x000001) : 0x1
        uint8                       UnknownBit_000058_2 : 1;        // 0x000058 (0x000001) : 0x2
        uint8                       UnknownBit_000058_3 : 1;        // 0x000058 (0x000001) : 0x3
        uint8                       UnknownBit_000058_4 : 1;        // 0x000058 (0x000001) : 0x4
        uint8                       UnknownBit_000058_5 : 1;        // 0x000058 (0x000001) : 0x5
        uint8                       UnknownBit_000058_6 : 1;        // 0x000058 (0x000001) : 0x6
        uint8                       UnknownBit_000058_7 : 1;        // 0x000058 (0x000001) : 0x7
        uint8                       UnknownData_000059[0x000003];   // 0x000059 (0x000003)
        FAISenseAffiliationFilter   DetectionByAffiliation;         // 0x00005C (0x000004)
    };
    // Size: 0x000048 (0x000000)
    class UAISenseConfig_Prediction : public UAISenseConfig
    {
    public:
    };
    // Size: 0x000070 (0x000028)
    class alignas(0x8) UAISenseConfig_Sight : public UAISenseConfig
    {
    public:
        UClass*                     Implementation;                         // 0x000048 (0x000008) [Default: 0x17340B30]
        float                       SightRadius;                            // 0x000050 (0x000004) [Default: 3000f]
        float                       LoseSightRadius;                        // 0x000054 (0x000004) [Default: 3500f]
        float                       PeripheralVisionAngleDegrees;           // 0x000058 (0x000004) [Default: 90f]
        FAISenseAffiliationFilter   DetectionByAffiliation;                 // 0x00005C (0x000004)
        float                       AutoSuccessRangeFromLastSeenLocation;   // 0x000060 (0x000004) [Default: -1f]
        float                       PointOfViewBackwardOffset;              // 0x000064 (0x000004) [Default: 0f]
        float                       NearClippingRadius;                     // 0x000068 (0x000004) [Default: 0f]
        uint8                       UnknownData_00006C[0x000004];           // 0x00006C (0x000004)
    };
    // Size: 0x000048 (0x000000)
    class UAISenseConfig_Team : public UAISenseConfig
    {
    public:
    };
    // Size: 0x000050 (0x000008)
    class alignas(0x4) UAISenseConfig_Touch : public UAISenseConfig
    {
    public:
        FAISenseAffiliationFilter   DetectionByAffiliation;         // 0x000048 (0x000004)
        uint8                       UnknownData_00004C[0x000004];   // 0x00004C (0x000004)
    };
    // Size: 0x000028 (0x000000)
    class UAISenseEvent : public UObject
    {
    public:
    };
    // Size: 0x000078 (0x000050)
    class alignas(0x8) UAISenseEvent_Damage : public UAISenseEvent
    {
    public:
        FAIDamageEvent  Event;  // 0x000028 (0x000050)
    };
    // Size: 0x000060 (0x000038)
    class alignas(0x8) UAISenseEvent_Hearing : public UAISenseEvent
    {
    public:
        FAINoiseEvent   Event;  // 0x000028 (0x000038)
    };
    // Size: 0x0000A0 (0x000028)
    class alignas(0x8) UAISense_Blueprint : public UAISense
    {
    public:
        UClass*                         ListenerDataType;   // 0x000078 (0x000008) [Default: nullptr]
        TArray<UAIPerceptionComponent*> ListenerContainer;  // 0x000080 (0x000010)
        TArray<UAISenseEvent*>          UnprocessedEvents;  // 0x000090 (0x000010)
    
    public: // Functions
        void    GetAllListenerActors(TArray<AActor*>& ListenerActors); // 0x050542A4 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        void    GetAllListenerComponents(TArray<UAIPerceptionComponent*>& ListenerComponents); // 0x05054430 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        void    K2_OnNewPawn(APawn* NewPawn); // 0x000545D2 [RequiredAPI | Event | Public | BlueprintEvent]
        void    OnListenerRegistered(AActor* ActorListener, UAIPerceptionComponent* PerceptionComponent); // 0x000545D2 [RequiredAPI | Event | Public | BlueprintEvent]
        void    OnListenerUnregistered(AActor* ActorListener, UAIPerceptionComponent* PerceptionComponent); // 0x000545D2 [RequiredAPI | Event | Public | BlueprintEvent]
        void    OnListenerUpdated(AActor* ActorListener, UAIPerceptionComponent* PerceptionComponent); // 0x000545D2 [RequiredAPI | Event | Public | BlueprintEvent]
        float   OnUpdate(TArray<UAISenseEvent*>& EventsToProcess); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
    };
    // Size: 0x000088 (0x000010)
    class alignas(0x8) UAISense_Damage : public UAISense
    {
    public:
        TArray<FAIDamageEvent>  RegisteredEvents;   // 0x000078 (0x000010)
    
    public: // Functions
        static void    ReportDamageEvent(UObject* WorldContextObject, AActor* DamagedActor, AActor* Instigator, float DamageAmount, FVector EventLocation, FVector HitLocation, FName Tag); // 0x05054692 [Final | RequiredAPI | Native | Static | Public | HasDefaults | BlueprintCallable]
    };
    // Size: 0x0000A0 (0x000028)
    class alignas(0x8) UAISense_Hearing : public UAISense
    {
    public:
        TArray<FAINoiseEvent>   NoiseEvents;                    // 0x000078 (0x000010)
        float                   SpeedOfSoundSq;                 // 0x000088 (0x000004) [Default: 0f]
        uint8                   UnknownData_00008C[0x000014];   // 0x00008C (0x000014)
    
    public: // Functions
        static void    ReportNoiseEvent(UObject* WorldContextObject, FVector NoiseLocation, float Loudness, AActor* Instigator, float MaxRange, FName Tag); // 0x05054D44 [Final | RequiredAPI | Native | Static | Public | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000088 (0x000010)
    class alignas(0x8) UAISense_Prediction : public UAISense
    {
    public:
        TArray<FAIPredictionEvent>  RegisteredEvents;   // 0x000078 (0x000010)
    
    public: // Functions
        static void    RequestControllerPredictionEvent(AAIController* Requestor, AActor* PredictedActor, float PredictionTime); // 0x050552D6 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void    RequestPawnPredictionEvent(APawn* Requestor, AActor* PredictedActor, float PredictionTime); // 0x05055660 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000128 (0x0000B0)
    class alignas(0x8) UAISense_Sight : public UAISense
    {
    public:
        uint8   UnknownData_000078[0x000058];                   // 0x000078 (0x000058)
        int32   MaxTracesPerTick;                               // 0x0000D0 (0x000004) [Default: 6]
        int32   MaxAsyncTracesPerTick;                          // 0x0000D4 (0x000004) [Default: 10]
        int32   MinQueriesPerTimeSliceCheck;                    // 0x0000D8 (0x000004) [Default: 40]
        uint8   UnknownData_0000DC[0x000004];                   // 0x0000DC (0x000004)
        double  MaxTimeSlicePerTick;                            // 0x0000E0 (0x000008) [Default: 0.005]
        float   HighImportanceQueryDistanceThreshold;           // 0x0000E8 (0x000004) [Default: 300f]
        uint8   UnknownData_0000EC[0x000004];                   // 0x0000EC (0x000004)
        float   MaxQueryImportance;                             // 0x0000F0 (0x000004) [Default: 60f]
        float   SightLimitQueryImportance;                      // 0x0000F4 (0x000004) [Default: 10f]
        float   PendingQueriesBudgetReductionRatio;             // 0x0000F8 (0x000004) [Default: 0.5f]
        bool    bUseAsynchronousTraceForDefaultSightQueries;    // 0x0000FC (0x000001) [Default: true]
        uint8   UnknownData_0000FD[0x00002B];                   // 0x0000FD (0x00002B)
    };
    // Size: 0x000088 (0x000010)
    class alignas(0x8) UAISense_Team : public UAISense
    {
    public:
        TArray<FAITeamStimulusEvent>    RegisteredEvents;   // 0x000078 (0x000010)
    };
    // Size: 0x000098 (0x000020)
    class alignas(0x8) UAISense_Touch : public UAISense
    {
    public:
        TArray<FAITouchEvent>   RegisteredEvents;               // 0x000078 (0x000010)
        uint8                   UnknownData_000088[0x000010];   // 0x000088 (0x000010)
    
    public: // Functions
        static void    ReportTouchEvent(UObject* WorldContextObject, AActor* TouchReceiver, AActor* OtherActor, FVector Location); // 0x05057F16 [Final | RequiredAPI | Native | Static | Public | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class IAISightTargetInterface : public IInterface
    {
    public:
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x8) UAISubsystem : public UObject
    {
    public:
        void**      VTable_000028;  // 0x000028 (0x000008) VTable [9 slots] -> 0x132AD700
        UAISystem*  AISystem;       // 0x000030 (0x000008) [Default: nullptr]
    };
    // Size: 0x000138 (0x0000E0)
    class alignas(0x8) UAISystem : public UAISystemBase
    {
    public:
        FSoftClassPath                      PerceptionSystemClassName;                      // 0x000058 (0x000018)
        FSoftClassPath                      HotSpotManagerClassName;                        // 0x000070 (0x000018)
        FSoftClassPath                      EnvQueryManagerClassName;                       // 0x000088 (0x000018)
        float                               AcceptanceRadius;                               // 0x0000A0 (0x000004) [Default: 5f]
        float                               PathfollowingRegularPathPointAcceptanceRadius;  // 0x0000A4 (0x000004) [Default: 0f]
        float                               PathfollowingNavLinkAcceptanceRadius;           // 0x0000A8 (0x000004) [Default: 0f]
        bool                                bFinishMoveOnGoalOverlap;                       // 0x0000AC (0x000001) [Default: true]
        bool                                bAcceptPartialPaths;                            // 0x0000AD (0x000001) [Default: true]
        bool                                bAllowStrafing;                                 // 0x0000AE (0x000001) [Default: false]
        bool                                bAllowControllersAsEQSQuerier;                  // 0x0000AF (0x000001) [Default: false]
        bool                                bEnableDebuggerPlugin;                          // 0x0000B0 (0x000001) [Default: false]
        bool                                bForgetStaleActors;                             // 0x0000B1 (0x000001) [Default: false]
        bool                                bAddBlackboardSelfKey;                          // 0x0000B2 (0x000001) [Default: true]
        bool                                bClearBBEntryOnBTEQSFail;                       // 0x0000B3 (0x000001) [Default: false]
        bool                                bBlackboardKeyDecoratorAllowsNoneAsValue;       // 0x0000B4 (0x000001) [Default: false]
        uint8                               UnknownData_0000B5[0x000003];                   // 0x0000B5 (0x000003)
        TSoftObjectPtr<UBlackboardData>     DefaultBlackboard;                              // 0x0000B8 (0x000020) [Default: nullptr]
        TEnumAsByte<ECollisionChannel>      DefaultSightCollisionChannel;                   // 0x0000D8 (0x000001) [Default: 3]
        uint8                               UnknownData_0000D9[0x000007];                   // 0x0000D9 (0x000007)
        UBehaviorTreeManager*               BehaviorTreeManager;                            // 0x0000E0 (0x000008) [Default: nullptr]
        UEnvQueryManager*                   EnvironmentQueryManager;                        // 0x0000E8 (0x000008) [Default: nullptr]
        UAIPerceptionSystem*                PerceptionSystem;                               // 0x0000F0 (0x000008) [Default: nullptr]
        TArray<UAIAsyncTaskBlueprintProxy*> AllProxyObjects;                                // 0x0000F8 (0x000010)
        UAIHotSpotManager*                  HotspotManager;                                 // 0x000108 (0x000008) [Default: nullptr]
        UNavLocalGridManager*               NavLocalGrids;                                  // 0x000110 (0x000008) [Default: nullptr]
        uint8                               UnknownData_000118[0x000020];                   // 0x000118 (0x000020)
    
    public: // Functions
        void    AIIgnorePlayers(); // 0x0CA1782A [RequiredAPI | Exec | Native | Public]
        void    AILoggingVerbose(); // 0x0CA17326 [RequiredAPI | Exec | Native | Public]
    };
    // Size: 0x000068 (0x000008)
    class alignas(0x8) UAITask : public UGameplayTask
    {
    public:
        AAIController*  OwnerController;    // 0x000060 (0x000008) [Default: nullptr]
    };
    // Size: 0x000068 (0x000000)
    class UAITask_LockLogic : public UAITask
    {
    public:
    };
    // Size: 0x000130 (0x0000C8)
    class alignas(0x8) UAITask_MoveTo : public UAITask
    {
    public:
        uint8                                               UnknownData_000068[0x000018];   // 0x000068 (0x000018)
        MULTI_INLINE_DELEGATE(GenericGameplayTaskDelegate)  OnRequestFailed;                // 0x000080 (0x000010)
        MULTI_INLINE_DELEGATE(MoveTaskCompletedSignature)   OnMoveFinished;                 // 0x000090 (0x000010)
        FAIMoveRequest                                      MoveRequest;                    // 0x0000A0 (0x000050)
        uint8                                               UnknownData_0000F0[0x000040];   // 0x0000F0 (0x000040)
    
    public: // Functions
        static UAITask_MoveTo* AIMoveTo(AAIController* Controller, FVector GoalLocation, AActor* GoalActor, float AcceptanceRadius, TEnumAsByte<EAIOptionFlag> StopOnOverlap, TEnumAsByte<EAIOptionFlag> AcceptPartialPath, bool bUsePathfinding, bool bLockAILogic, bool bUseContinuousGoalTracking, TEnumAsByte<EAIOptionFlag> ProjectGoalOnNavigation, TEnumAsByte<EAIOptionFlag> RequireNavigableEndLocation); // 0x050589BA [Final | RequiredAPI | Native | Static | Public | HasDefaults | BlueprintCallable]
    };
    // Size: 0x0000E0 (0x000078)
    class UAITask_RunEQS : public UAITask
    {
    public:
        uint8   UnknownData_000068[0x000078];   // 0x000068 (0x000078)
    
    public: // Functions
        static UAITask_RunEQS* RunEQS(AAIController* Controller, UEnvQuery* QueryTemplate); // 0x05059440 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000060 (0x000008)
    class UBTAuxiliaryNode : public UBTNode
    {
    public:
        uint8   UnknownData_000058[0x000008];   // 0x000058 (0x000008)
    };
    // Size: 0x000080 (0x000028)
    class alignas(0x8) UBTCompositeNode : public UBTNode
    {
    public:
        TArray<FBTCompositeChild>   Children;                       // 0x000058 (0x000010)
        TArray<UBTService*>         Services;                       // 0x000068 (0x000010)
        uint8                       bApplyDecoratorScope : 1;       // 0x000078 (0x000001) : 0x0 [Default: false]
        uint8                       UnknownBit_000078_1 : 1;        // 0x000078 (0x000001) : 0x1
        uint8                       UnknownBit_000078_2 : 1;        // 0x000078 (0x000001) : 0x2
        uint8                       UnknownBit_000078_3 : 1;        // 0x000078 (0x000001) : 0x3
        uint8                       UnknownBit_000078_4 : 1;        // 0x000078 (0x000001) : 0x4
        uint8                       UnknownBit_000078_5 : 1;        // 0x000078 (0x000001) : 0x5
        uint8                       UnknownBit_000078_6 : 1;        // 0x000078 (0x000001) : 0x6
        uint8                       UnknownBit_000078_7 : 1;        // 0x000078 (0x000001) : 0x7
        uint8                       UnknownData_000079[0x000007];   // 0x000079 (0x000007)
    };
    // Size: 0x000080 (0x000000)
    class UBTComposite_Selector : public UBTCompositeNode
    {
    public:
    };
    // Size: 0x000080 (0x000000)
    class UBTComposite_Sequence : public UBTCompositeNode
    {
    public:
    };
    // Size: 0x000088 (0x000008)
    class UBTComposite_SimpleParallel : public UBTCompositeNode
    {
    public:
        TEnumAsByte<EBTParallelMode>    FinishMode;                     // 0x000080 (0x000001) [Default: 0]
        uint8                           UnknownData_000081[0x000007];   // 0x000081 (0x000007)
    };
    // Size: 0x000068 (0x000008)
    class UBTDecorator : public UBTAuxiliaryNode
    {
    public:
        uint8                           bInverseCondition : 1;          // 0x000060 (0x000001) : 0x0 [Default: true]
        uint8                           UnknownBit_000060_1 : 1;        // 0x000060 (0x000001) : 0x1
        uint8                           UnknownBit_000060_2 : 1;        // 0x000060 (0x000001) : 0x2
        uint8                           UnknownBit_000060_3 : 1;        // 0x000060 (0x000001) : 0x3
        uint8                           UnknownBit_000060_4 : 1;        // 0x000060 (0x000001) : 0x4
        uint8                           UnknownBit_000060_5 : 1;        // 0x000060 (0x000001) : 0x5
        uint8                           UnknownBit_000060_6 : 1;        // 0x000060 (0x000001) : 0x6
        uint8                           UnknownBit_000060_7 : 1;        // 0x000060 (0x000001) : 0x7
        uint8                           UnknownData_000061[0x000003];   // 0x000061 (0x000003)
        TEnumAsByte<EBTFlowAbortMode>   FlowAbortMode;                  // 0x000064 (0x000001) [Default: 0]
        uint8                           UnknownData_000065[0x000003];   // 0x000065 (0x000003)
    };
    // Size: 0x0000C0 (0x000030)
    class alignas(0x8) UBTDecorator_Blackboard : public UBTDecorator_BlackboardBase
    {
    public:
        int32                               IntValue;                       // 0x000090 (0x000004) [Default: 0]
        float                               FloatValue;                     // 0x000094 (0x000004) [Default: 0f]
        FString                             StringValue;                    // 0x000098 (0x000010) [Default: L""]
        FString                             CachedDescription;              // 0x0000A8 (0x000010) [Default: L""]
        uint8                               OperationType;                  // 0x0000B8 (0x000001) [Default: 0]
        TEnumAsByte<EBTBlackboardRestart>   NotifyObserver;                 // 0x0000B9 (0x000001) [Default: 1]
        uint8                               UnknownData_0000BA[0x000006];   // 0x0000BA (0x000006)
    };
    // Size: 0x000090 (0x000028)
    class alignas(0x8) UBTDecorator_BlackboardBase : public UBTDecorator
    {
    public:
        FBlackboardKeySelector  BlackboardKey;  // 0x000068 (0x000028)
    };
    // Size: 0x0000A0 (0x000038)
    class alignas(0x8) UBTDecorator_BlueprintBase : public UBTDecorator
    {
    public:
        AAIController*  AIOwner;                                // 0x000068 (0x000008) [Default: nullptr]
        AActor*         ActorOwner;                             // 0x000070 (0x000008) [Default: nullptr]
        TArray<FName>   ObservedKeyNames;                       // 0x000078 (0x000010)
        uint8           UnknownData_000088[0x000010];           // 0x000088 (0x000010)
        uint8           bShowPropertyDetails : 1;               // 0x000098 (0x000001) : 0x0 [Default: true]
        uint8           bCheckConditionOnlyBlackBoardChanges : 1; // 0x000098 (0x000001) : 0x0 [Default: true]
        uint8           UnknownBit_000098_1 : 1;                // 0x000098 (0x000001) : 0x1
        uint8           UnknownBit_000098_2 : 1;                // 0x000098 (0x000001) : 0x2
        uint8           UnknownBit_000098_3 : 1;                // 0x000098 (0x000001) : 0x3
        uint8           UnknownBit_000098_4 : 1;                // 0x000098 (0x000001) : 0x4
        uint8           UnknownBit_000098_5 : 1;                // 0x000098 (0x000001) : 0x5
        uint8           UnknownBit_000098_6 : 1;                // 0x000098 (0x000001) : 0x6
        uint8           UnknownBit_000098_7 : 1;                // 0x000098 (0x000001) : 0x7
        uint8           UnknownData_000099[0x000007];           // 0x000099 (0x000007)
    
    public: // Functions
        bool    IsDecoratorExecutionActive(); // 0x0DB6908C [Final | RequiredAPI | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        bool    IsDecoratorObserverActive(); // 0x0DB69134 [Final | RequiredAPI | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        bool    PerformConditionCheck(AActor* OwnerActor); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        bool    PerformConditionCheckAI(AAIController* OwnerController, APawn* ControlledPawn); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveExecutionFinish(AActor* OwnerActor, TEnumAsByte<EBTNodeResult> NodeResult); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveExecutionFinishAI(AAIController* OwnerController, APawn* ControlledPawn, TEnumAsByte<EBTNodeResult> NodeResult); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveExecutionStart(AActor* OwnerActor); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveExecutionStartAI(AAIController* OwnerController, APawn* ControlledPawn); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveObserverActivated(AActor* OwnerActor); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveObserverActivatedAI(AAIController* OwnerController, APawn* ControlledPawn); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveObserverDeactivated(AActor* OwnerActor); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveObserverDeactivatedAI(AAIController* OwnerController, APawn* ControlledPawn); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveTick(AActor* OwnerActor, float DeltaSeconds); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveTickAI(AAIController* OwnerController, APawn* ControlledPawn, float DeltaSeconds); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
    };
    // Size: 0x0000C8 (0x000060)
    class alignas(0x8) UBTDecorator_CheckGameplayTagsOnActor : public UBTDecorator
    {
    public:
        FBlackboardKeySelector      ActorToCheck;                   // 0x000068 (0x000028)
        EGameplayContainerMatchType TagsToMatch;                    // 0x000090 (0x000001) [Default: EGameplayContainerMatchType(0)]
        uint8                       UnknownData_000091[0x000007];   // 0x000091 (0x000007)
        FGameplayTagContainer       GameplayTags;                   // 0x000098 (0x000020)
        FString                     CachedDescription;              // 0x0000B8 (0x000010) [Default: L""]
    };
    // Size: 0x0000C0 (0x000058)
    class alignas(0x8) UBTDecorator_CompareBBEntries : public UBTDecorator
    {
    public:
        TEnumAsByte<EBlackBoardEntryComparison> Operator;                       // 0x000068 (0x000001) [Default: 0]
        uint8                                   UnknownData_000069[0x000007];   // 0x000069 (0x000007)
        FBlackboardKeySelector                  BlackboardKeyA;                 // 0x000070 (0x000028)
        FBlackboardKeySelector                  BlackboardKeyB;                 // 0x000098 (0x000028)
    };
    // Size: 0x0000C0 (0x000000)
    class UBTDecorator_ConditionalLoop : public UBTDecorator_Blackboard
    {
    public:
    };
    // Size: 0x0000F8 (0x000090)
    class alignas(0x8) UBTDecorator_ConeCheck : public UBTDecorator
    {
    public:
        FValueOrBBKey_Float     ConeHalfAngle;  // 0x000068 (0x000018)
        FBlackboardKeySelector  ConeOrigin;     // 0x000080 (0x000028)
        FBlackboardKeySelector  ConeDirection;  // 0x0000A8 (0x000028)
        FBlackboardKeySelector  Observed;       // 0x0000D0 (0x000028)
    };
    // Size: 0x000080 (0x000018)
    class alignas(0x8) UBTDecorator_Cooldown : public UBTDecorator
    {
    public:
        FValueOrBBKey_Float CooldownTime;   // 0x000068 (0x000018)
    };
    // Size: 0x000110 (0x0000A8)
    class alignas(0x8) UBTDecorator_DoesPathExist : public UBTDecorator
    {
    public:
        FBlackboardKeySelector  BlackboardKeyA;                 // 0x000068 (0x000028)
        FBlackboardKeySelector  BlackboardKeyB;                 // 0x000090 (0x000028)
        uint8                   bUseSelf : 1;                   // 0x0000B8 (0x000001) : 0x0 [Default: false]
        uint8                   UnknownBit_0000B8_1 : 1;        // 0x0000B8 (0x000001) : 0x1
        uint8                   UnknownBit_0000B8_2 : 1;        // 0x0000B8 (0x000001) : 0x2
        uint8                   UnknownBit_0000B8_3 : 1;        // 0x0000B8 (0x000001) : 0x3
        uint8                   UnknownBit_0000B8_4 : 1;        // 0x0000B8 (0x000001) : 0x4
        uint8                   UnknownBit_0000B8_5 : 1;        // 0x0000B8 (0x000001) : 0x5
        uint8                   UnknownBit_0000B8_6 : 1;        // 0x0000B8 (0x000001) : 0x6
        uint8                   UnknownBit_0000B8_7 : 1;        // 0x0000B8 (0x000001) : 0x7
        uint8                   UnknownData_0000B9[0x000007];   // 0x0000B9 (0x000007)
        FValueOrBBKey_Enum      PathQueryType;                  // 0x0000C0 (0x000030)
        FValueOrBBKey_Class     FilterClass;                    // 0x0000F0 (0x000020)
    };
    // Size: 0x000068 (0x000000)
    class UBTDecorator_ForceSuccess : public UBTDecorator
    {
    public:
    };
    // Size: 0x000108 (0x000078)
    class alignas(0x8) UBTDecorator_IsAtLocation : public UBTDecorator_BlackboardBase
    {
    public:
        float                       AcceptableRadius;               // 0x000090 (0x000004) [Default: 50f]
        uint8                       UnknownData_000094[0x000004];   // 0x000094 (0x000004)
        FAIDataProviderFloatValue   ParametrizedAcceptableRadius;   // 0x000098 (0x000038)
        FAIDistanceType             GeometricDistanceType;          // 0x0000D0 (0x000001) [Default: FAIDistanceType(0)]
        uint8                       UnknownData_0000D1[0x000003];   // 0x0000D1 (0x000003)
        uint8                       bUseParametrizedRadius : 1;     // 0x0000D4 (0x000001) : 0x0 [Default: false]
        uint8                       UnknownBit_0000D4_1 : 1;        // 0x0000D4 (0x000001) : 0x1
        uint8                       UnknownBit_0000D4_2 : 1;        // 0x0000D4 (0x000001) : 0x2
        uint8                       UnknownBit_0000D4_3 : 1;        // 0x0000D4 (0x000001) : 0x3
        uint8                       UnknownBit_0000D4_4 : 1;        // 0x0000D4 (0x000001) : 0x4
        uint8                       UnknownBit_0000D4_5 : 1;        // 0x0000D4 (0x000001) : 0x5
        uint8                       UnknownBit_0000D4_6 : 1;        // 0x0000D4 (0x000001) : 0x6
        uint8                       UnknownBit_0000D4_7 : 1;        // 0x0000D4 (0x000001) : 0x7
        uint8                       UnknownData_0000D5[0x000003];   // 0x0000D5 (0x000003)
        FValueOrBBKey_Bool          bUseNavAgentGoalLocation;       // 0x0000D8 (0x000018)
        FValueOrBBKey_Bool          bPathFindingBasedTest;          // 0x0000F0 (0x000018)
    };
    // Size: 0x0000B0 (0x000020)
    class alignas(0x8) UBTDecorator_IsBBEntryOfClass : public UBTDecorator_BlackboardBase
    {
    public:
        FValueOrBBKey_Class TestClass;  // 0x000090 (0x000020)
    };
    // Size: 0x0000D8 (0x000070)
    class alignas(0x8) UBTDecorator_KeepInCone : public UBTDecorator
    {
    public:
        FValueOrBBKey_Float     ConeHalfAngle;                  // 0x000068 (0x000018)
        FBlackboardKeySelector  ConeOrigin;                     // 0x000080 (0x000028)
        FBlackboardKeySelector  Observed;                       // 0x0000A8 (0x000028)
        uint8                   bUseSelfAsOrigin : 1;           // 0x0000D0 (0x000001) : 0x0 [Default: false]
        uint8                   bUseSelfAsObserved : 1;         // 0x0000D0 (0x000001) : 0x0 [Default: false]
        uint8                   UnknownBit_0000D0_1 : 1;        // 0x0000D0 (0x000001) : 0x1
        uint8                   UnknownBit_0000D0_2 : 1;        // 0x0000D0 (0x000001) : 0x2
        uint8                   UnknownBit_0000D0_3 : 1;        // 0x0000D0 (0x000001) : 0x3
        uint8                   UnknownBit_0000D0_4 : 1;        // 0x0000D0 (0x000001) : 0x4
        uint8                   UnknownBit_0000D0_5 : 1;        // 0x0000D0 (0x000001) : 0x5
        uint8                   UnknownBit_0000D0_6 : 1;        // 0x0000D0 (0x000001) : 0x6
        uint8                   UnknownBit_0000D0_7 : 1;        // 0x0000D0 (0x000001) : 0x7
        uint8                   UnknownData_0000D1[0x000007];   // 0x0000D1 (0x000007)
    };
    // Size: 0x0000A0 (0x000038)
    class alignas(0x8) UBTDecorator_Loop : public UBTDecorator
    {
    public:
        FValueOrBBKey_Int32 NumLoops;                       // 0x000068 (0x000018)
        bool                bInfiniteLoop;                  // 0x000080 (0x000001) [Default: false]
        uint8               UnknownData_000081[0x000007];   // 0x000081 (0x000007)
        FValueOrBBKey_Float InfiniteLoopTimeoutTime;        // 0x000088 (0x000018)
    };
    // Size: 0x000098 (0x000030)
    class alignas(0x8) UBTDecorator_LoopUntil : public UBTDecorator
    {
    public:
        FValueOrBBKey_Enum  RequiredResult; // 0x000068 (0x000030)
    };
    // Size: 0x000068 (0x000000)
    class UBTDecorator_ReachedMoveGoal : public UBTDecorator
    {
    public:
    };
    // Size: 0x0000A0 (0x000038)
    class alignas(0x8) UBTDecorator_SetTagCooldown : public UBTDecorator
    {
    public:
        FGameplayTag        CooldownTag;                    // 0x000068 (0x000004)
        uint8               UnknownData_00006C[0x000004];   // 0x00006C (0x000004)
        FValueOrBBKey_Float CooldownDuration;               // 0x000070 (0x000018)
        FValueOrBBKey_Bool  bAddToExistingDuration;         // 0x000088 (0x000018)
    };
    // Size: 0x0000B8 (0x000050)
    class alignas(0x8) UBTDecorator_TagCooldown : public UBTDecorator
    {
    public:
        FGameplayTag        CooldownTag;                    // 0x000068 (0x000004)
        uint8               UnknownData_00006C[0x000004];   // 0x00006C (0x000004)
        FValueOrBBKey_Float CooldownDuration;               // 0x000070 (0x000018)
        FValueOrBBKey_Bool  bAddToExistingDuration;         // 0x000088 (0x000018)
        FValueOrBBKey_Bool  bActivatesCooldown;             // 0x0000A0 (0x000018)
    };
    // Size: 0x000080 (0x000018)
    class alignas(0x8) UBTDecorator_TimeLimit : public UBTDecorator
    {
    public:
        FValueOrBBKey_Float TimeLimit;  // 0x000068 (0x000018)
    };
    // Size: 0x000028 (0x000000)
    class UBTFunctionLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static void                    ClearBlackboardValue(UBTNode* NodeOwner, FBlackboardKeySelector& Key); // 0x0501EFBE [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                    ClearBlackboardValueAsVector(UBTNode* NodeOwner, FBlackboardKeySelector& Key); // 0x0501EFBE [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static AActor*                 GetBlackboardValueAsActor(UBTNode* NodeOwner, FBlackboardKeySelector& Key); // 0x0501F2B6 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static bool                    GetBlackboardValueAsBool(UBTNode* NodeOwner, FBlackboardKeySelector& Key); // 0x0501F56E [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static UClass*                 GetBlackboardValueAsClass(UBTNode* NodeOwner, FBlackboardKeySelector& Key); // 0x0501F86E [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static uint8                   GetBlackboardValueAsEnum(UBTNode* NodeOwner, FBlackboardKeySelector& Key); // 0x0501FB70 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static float                   GetBlackboardValueAsFloat(UBTNode* NodeOwner, FBlackboardKeySelector& Key); // 0x0501FE70 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static int32                   GetBlackboardValueAsInt(UBTNode* NodeOwner, FBlackboardKeySelector& Key); // 0x05020174 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FName                   GetBlackboardValueAsName(UBTNode* NodeOwner, FBlackboardKeySelector& Key); // 0x05020474 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static UObject*                GetBlackboardValueAsObject(UBTNode* NodeOwner, FBlackboardKeySelector& Key); // 0x0502077E [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FRotator                GetBlackboardValueAsRotator(UBTNode* NodeOwner, FBlackboardKeySelector& Key); // 0x05020A80 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        static FString                 GetBlackboardValueAsString(UBTNode* NodeOwner, FBlackboardKeySelector& Key); // 0x05020DA4 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FVector                 GetBlackboardValueAsVector(UBTNode* NodeOwner, FBlackboardKeySelector& Key); // 0x050210F2 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        static UBehaviorTreeComponent* GetOwnerComponent(UBTNode* NodeOwner); // 0x05021416 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static UBlackboardComponent*   GetOwnersBlackboard(UBTNode* NodeOwner); // 0x050215B4 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static void                    SetBlackboardValueAsBool(UBTNode* NodeOwner, FBlackboardKeySelector& Key, bool Value); // 0x0502175A [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                    SetBlackboardValueAsClass(UBTNode* NodeOwner, FBlackboardKeySelector& Key, UClass* Value); // 0x05021B24 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                    SetBlackboardValueAsEnum(UBTNode* NodeOwner, FBlackboardKeySelector& Key, uint8 Value); // 0x05021EEA [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                    SetBlackboardValueAsFloat(UBTNode* NodeOwner, FBlackboardKeySelector& Key, float Value); // 0x050222AC [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                    SetBlackboardValueAsInt(UBTNode* NodeOwner, FBlackboardKeySelector& Key, int32 Value); // 0x05022672 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                    SetBlackboardValueAsName(UBTNode* NodeOwner, FBlackboardKeySelector& Key, FName Value); // 0x05022A38 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                    SetBlackboardValueAsObject(UBTNode* NodeOwner, FBlackboardKeySelector& Key, UObject* Value); // 0x05022DFE [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                    SetBlackboardValueAsRotator(UBTNode* NodeOwner, FBlackboardKeySelector& Key, FRotator Value); // 0x050231C4 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static void                    SetBlackboardValueAsString(UBTNode* NodeOwner, FBlackboardKeySelector& Key, FString Value); // 0x050235A2 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                    SetBlackboardValueAsVector(UBTNode* NodeOwner, FBlackboardKeySelector& Key, FVector Value); // 0x050239FE [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static void                    StartUsingExternalEvent(UBTNode* NodeOwner, AActor* OwningActor); // 0x05023DDC [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                    StopUsingExternalEvent(UBTNode* NodeOwner); // 0x04381806 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000058 (0x000030)
    class alignas(0x8) UBTNode : public UObject
    {
    public:
        void**              VTable_000028;                  // 0x000028 (0x000008) VTable [9 slots] -> 0x132B4450
        FString             NodeName;                       // 0x000030 (0x000010) [Default: L""]
        UBehaviorTree*      TreeAsset;                      // 0x000040 (0x000008) [Default: nullptr]
        UBTCompositeNode*   ParentNode;                     // 0x000048 (0x000008) [Default: nullptr]
        uint16              ExecutionIndex;                 // 0x000050 (0x000002) [Default: 0]
        uint16              MemoryOffset;                   // 0x000052 (0x000002) [Default: 0]
        uint8               TreeDepth;                      // 0x000054 (0x000001) [Default: 0]
        uint8               bIsInstanced : 1;               // 0x000055 (0x000001) : 0x0 [Default: false]
        uint8               bIsInjected : 1;                // 0x000055 (0x000001) : 0x0 [Default: false]
        uint8               bCreateNodeInstance : 1;        // 0x000055 (0x000001) : 0x0 [Default: false]
        uint8               bOwnsGameplayTasks : 1;         // 0x000055 (0x000001) : 0x0 [Default: false]
        uint8               UnknownBit_000055_1 : 1;        // 0x000055 (0x000001) : 0x1
        uint8               UnknownBit_000055_2 : 1;        // 0x000055 (0x000001) : 0x2
        uint8               UnknownBit_000055_3 : 1;        // 0x000055 (0x000001) : 0x3
        uint8               UnknownBit_000055_4 : 1;        // 0x000055 (0x000001) : 0x4
        uint8               UnknownBit_000055_5 : 1;        // 0x000055 (0x000001) : 0x5
        uint8               UnknownBit_000055_6 : 1;        // 0x000055 (0x000001) : 0x6
        uint8               UnknownBit_000055_7 : 1;        // 0x000055 (0x000001) : 0x7
        uint8               UnknownData_000056[0x000002];   // 0x000056 (0x000002)
    };
    // Size: 0x000070 (0x000010)
    class alignas(0x4) UBTService : public UBTAuxiliaryNode
    {
    public:
        float   Interval;                       // 0x000060 (0x000004) [Default: 0.5f]
        float   RandomDeviation;                // 0x000064 (0x000004) [Default: 0.1f]
        uint8   bCallTickOnSearchStart : 1;     // 0x000068 (0x000001) : 0x0 [Default: true]
        uint8   bRestartTimerOnEachActivation : 1; // 0x000068 (0x000001) : 0x0 [Default: true]
        uint8   UnknownBit_000068_1 : 1;        // 0x000068 (0x000001) : 0x1
        uint8   UnknownBit_000068_2 : 1;        // 0x000068 (0x000001) : 0x2
        uint8   UnknownBit_000068_3 : 1;        // 0x000068 (0x000001) : 0x3
        uint8   UnknownBit_000068_4 : 1;        // 0x000068 (0x000001) : 0x4
        uint8   UnknownBit_000068_5 : 1;        // 0x000068 (0x000001) : 0x5
        uint8   UnknownBit_000068_6 : 1;        // 0x000068 (0x000001) : 0x6
        uint8   UnknownBit_000068_7 : 1;        // 0x000068 (0x000001) : 0x7
        uint8   UnknownData_000069[0x000007];   // 0x000069 (0x000007)
    };
    // Size: 0x000098 (0x000028)
    class alignas(0x8) UBTService_BlackboardBase : public UBTService
    {
    public:
        FBlackboardKeySelector  BlackboardKey;  // 0x000070 (0x000028)
    };
    // Size: 0x000098 (0x000028)
    class alignas(0x8) UBTService_BlueprintBase : public UBTService
    {
    public:
        AAIController*  AIOwner;                        // 0x000070 (0x000008) [Default: nullptr]
        AActor*         ActorOwner;                     // 0x000078 (0x000008) [Default: nullptr]
        uint8           UnknownData_000080[0x000010];   // 0x000080 (0x000010)
        uint8           bShowPropertyDetails : 1;       // 0x000090 (0x000001) : 0x0 [Default: true]
        uint8           bShowEventDetails : 1;          // 0x000090 (0x000001) : 0x0 [Default: true]
        uint8           UnknownBit_000090_1 : 1;        // 0x000090 (0x000001) : 0x1
        uint8           UnknownBit_000090_2 : 1;        // 0x000090 (0x000001) : 0x2
        uint8           UnknownBit_000090_3 : 1;        // 0x000090 (0x000001) : 0x3
        uint8           UnknownBit_000090_4 : 1;        // 0x000090 (0x000001) : 0x4
        uint8           UnknownBit_000090_5 : 1;        // 0x000090 (0x000001) : 0x5
        uint8           UnknownBit_000090_6 : 1;        // 0x000090 (0x000001) : 0x6
        uint8           UnknownBit_000090_7 : 1;        // 0x000090 (0x000001) : 0x7
        uint8           UnknownData_000091[0x000007];   // 0x000091 (0x000007)
    
    public: // Functions
        bool    IsServiceActive(); // 0x0DB6D862 [Final | RequiredAPI | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        void    ReceiveActivation(AActor* OwnerActor); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveActivationAI(AAIController* OwnerController, APawn* ControlledPawn); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveDeactivation(AActor* OwnerActor); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveDeactivationAI(AAIController* OwnerController, APawn* ControlledPawn); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveSearchStart(AActor* OwnerActor); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveSearchStartAI(AAIController* OwnerController, APawn* ControlledPawn); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveTick(AActor* OwnerActor, float DeltaSeconds); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveTickAI(AAIController* OwnerController, APawn* ControlledPawn, float DeltaSeconds); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
    };
    // Size: 0x0000A0 (0x000008)
    class UBTService_DefaultFocus : public UBTService_BlackboardBase
    {
    public:
        uint8   FocusPriority;                  // 0x000098 (0x000001) [Default: 0]
        uint8   UnknownData_000099[0x000007];   // 0x000099 (0x000007)
    };
    // Size: 0x0000F8 (0x000060)
    class alignas(0x8) UBTService_RunEQS : public UBTService_BlackboardBase
    {
    public:
        FEQSParametrizedQueryExecutionRequest   EQSRequest;                     // 0x000098 (0x000048)
        bool                                    bUpdateBBOnFail;                // 0x0000E0 (0x000001) [Default: false]
        uint8                                   UnknownData_0000E1[0x000017];   // 0x0000E1 (0x000017)
    };
    // Size: 0x000070 (0x000018)
    class alignas(0x8) UBTTaskNode : public UBTNode
    {
    public:
        TArray<UBTService*> Services;                       // 0x000058 (0x000010)
        uint8               bIgnoreRestartSelf : 1;         // 0x000068 (0x000001) : 0x0 [Default: false]
        uint8               UnknownBit_000068_1 : 1;        // 0x000068 (0x000001) : 0x1
        uint8               UnknownBit_000068_2 : 1;        // 0x000068 (0x000001) : 0x2
        uint8               UnknownBit_000068_3 : 1;        // 0x000068 (0x000001) : 0x3
        uint8               UnknownBit_000068_4 : 1;        // 0x000068 (0x000001) : 0x4
        uint8               UnknownBit_000068_5 : 1;        // 0x000068 (0x000001) : 0x5
        uint8               UnknownBit_000068_6 : 1;        // 0x000068 (0x000001) : 0x6
        uint8               UnknownBit_000068_7 : 1;        // 0x000068 (0x000001) : 0x7
        uint8               UnknownData_000069[0x000007];   // 0x000069 (0x000007)
    };
    // Size: 0x000098 (0x000028)
    class alignas(0x8) UBTTask_BlackboardBase : public UBTTaskNode
    {
    public:
        FBlackboardKeySelector  BlackboardKey;  // 0x000070 (0x000028)
    };
    // Size: 0x0000A8 (0x000038)
    class alignas(0x8) UBTTask_BlueprintBase : public UBTTaskNode
    {
    public:
        AAIController*      AIOwner;                        // 0x000070 (0x000008) [Default: nullptr]
        AActor*             ActorOwner;                     // 0x000078 (0x000008) [Default: nullptr]
        FIntervalCountdown  TickInterval;                   // 0x000080 (0x000008)
        uint8               UnknownData_000088[0x000018];   // 0x000088 (0x000018)
        uint8               bShowPropertyDetails : 1;       // 0x0000A0 (0x000001) : 0x0 [Default: true]
        uint8               UnknownBit_0000A0_1 : 1;        // 0x0000A0 (0x000001) : 0x1
        uint8               UnknownBit_0000A0_2 : 1;        // 0x0000A0 (0x000001) : 0x2
        uint8               UnknownBit_0000A0_3 : 1;        // 0x0000A0 (0x000001) : 0x3
        uint8               UnknownBit_0000A0_4 : 1;        // 0x0000A0 (0x000001) : 0x4
        uint8               UnknownBit_0000A0_5 : 1;        // 0x0000A0 (0x000001) : 0x5
        uint8               UnknownBit_0000A0_6 : 1;        // 0x0000A0 (0x000001) : 0x6
        uint8               UnknownBit_0000A0_7 : 1;        // 0x0000A0 (0x000001) : 0x7
        uint8               UnknownData_0000A1[0x000007];   // 0x0000A1 (0x000007)
    
    public: // Functions
        void    FinishAbort(); // 0x0DB6E8F8 [Final | RequiredAPI | Native | Protected | BlueprintCallable]
        void    FinishExecute(bool bSuccess); // 0x05024FF4 [Final | RequiredAPI | Native | Protected | BlueprintCallable]
        bool    IsTaskAborting(); // 0x0DB6EA0C [Final | RequiredAPI | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        bool    IsTaskExecuting(); // 0x0DB6EA2A [Final | RequiredAPI | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        void    ReceiveAbort(AActor* OwnerActor); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveAbortAI(AAIController* OwnerController, APawn* ControlledPawn); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveExecute(AActor* OwnerActor); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveExecuteAI(AAIController* OwnerController, APawn* ControlledPawn); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveTick(AActor* OwnerActor, float DeltaSeconds); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    ReceiveTickAI(AAIController* OwnerController, APawn* ControlledPawn, float DeltaSeconds); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
        void    SetFinishOnMessage(FName MessageName); // 0x05025164 [Final | RequiredAPI | Native | Protected | BlueprintCallable]
        void    SetFinishOnMessageWithId(FName MessageName, int32 RequestID); // 0x050252D0 [Final | RequiredAPI | Native | Protected | BlueprintCallable]
    };
    // Size: 0x0000A0 (0x000030)
    class alignas(0x8) UBTTask_FinishWithResult : public UBTTaskNode
    {
    public:
        FValueOrBBKey_Enum  Result; // 0x000070 (0x000030)
    };
    // Size: 0x000088 (0x000018)
    class alignas(0x8) UBTTask_GameplayTaskBase : public UBTTaskNode
    {
    public:
        FValueOrBBKey_Bool  bWaitForGameplayTask;   // 0x000070 (0x000018)
    };
    // Size: 0x000088 (0x000018)
    class alignas(0x8) UBTTask_MakeNoise : public UBTTaskNode
    {
    public:
        FValueOrBBKey_Float Loudnes;    // 0x000070 (0x000018)
    };
    // Size: 0x0001B0 (0x000000)
    class UBTTask_MoveDirectlyToward : public UBTTask_MoveTo
    {
    public:
    };
    // Size: 0x0001B0 (0x000118)
    class alignas(0x8) UBTTask_MoveTo : public UBTTask_BlackboardBase
    {
    public:
        FValueOrBBKey_Float AcceptableRadius;                   // 0x000098 (0x000018)
        FValueOrBBKey_Class FilterClass;                        // 0x0000B0 (0x000020)
        FValueOrBBKey_Float ObservedBlackboardValueTolerance;   // 0x0000D0 (0x000018)
        FValueOrBBKey_Bool  bAllowStrafe;                       // 0x0000E8 (0x000018)
        FValueOrBBKey_Bool  bAllowPartialPath;                  // 0x000100 (0x000018)
        FValueOrBBKey_Bool  bTrackMovingGoal;                   // 0x000118 (0x000018)
        FValueOrBBKey_Bool  bRequireNavigableEndLocation;       // 0x000130 (0x000018)
        FValueOrBBKey_Bool  bProjectGoalLocation;               // 0x000148 (0x000018)
        FValueOrBBKey_Bool  bReachTestIncludesAgentRadius;      // 0x000160 (0x000018)
        FValueOrBBKey_Bool  bReachTestIncludesGoalRadius;       // 0x000178 (0x000018)
        FValueOrBBKey_Bool  bStartFromPreviousPath;             // 0x000190 (0x000018)
        uint8               bObserveBlackboardValue : 1;        // 0x0001A8 (0x000001) : 0x0 [Default: true]
        uint8               UnknownBit_0001A8_1 : 1;            // 0x0001A8 (0x000001) : 0x1
        uint8               UnknownBit_0001A8_2 : 1;            // 0x0001A8 (0x000001) : 0x2
        uint8               UnknownBit_0001A8_3 : 1;            // 0x0001A8 (0x000001) : 0x3
        uint8               UnknownBit_0001A8_4 : 1;            // 0x0001A8 (0x000001) : 0x4
        uint8               UnknownBit_0001A8_5 : 1;            // 0x0001A8 (0x000001) : 0x5
        uint8               UnknownBit_0001A8_6 : 1;            // 0x0001A8 (0x000001) : 0x6
        uint8               UnknownBit_0001A8_7 : 1;            // 0x0001A8 (0x000001) : 0x7
        uint8               UnknownData_0001A9[0x000007];       // 0x0001A9 (0x000007)
    };
    // Size: 0x0000F0 (0x000080)
    class alignas(0x8) UBTTask_PlayAnimation : public UBTTaskNode
    {
    public:
        FValueOrBBKey_Object    AnimationToPlay;                // 0x000070 (0x000020)
        FValueOrBBKey_Bool      bLooping;                       // 0x000090 (0x000018)
        FValueOrBBKey_Bool      bNonBlocking;                   // 0x0000A8 (0x000018)
        UBehaviorTreeComponent* MyOwnerComp;                    // 0x0000C0 (0x000008) [Default: nullptr]
        USkeletalMeshComponent* CachedSkelMesh;                 // 0x0000C8 (0x000008) [Default: nullptr]
        uint8                   UnknownData_0000D0[0x000020];   // 0x0000D0 (0x000020)
    };
    // Size: 0x000090 (0x000020)
    class alignas(0x8) UBTTask_PlaySound : public UBTTaskNode
    {
    public:
        FValueOrBBKey_Object    SoundToPlay;    // 0x000070 (0x000020)
    };
    // Size: 0x0000B0 (0x000018)
    class alignas(0x8) UBTTask_RotateToFaceBBEntry : public UBTTask_BlackboardBase
    {
    public:
        FValueOrBBKey_Float Precision;  // 0x000098 (0x000018)
    };
    // Size: 0x000078 (0x000008)
    class alignas(0x8) UBTTask_RunBehavior : public UBTTaskNode
    {
    public:
        UBehaviorTree*  BehaviorAsset;  // 0x000070 (0x000008) [Default: nullptr]
    };
    // Size: 0x000088 (0x000018)
    class alignas(0x8) UBTTask_RunBehaviorDynamic : public UBTTaskNode
    {
    public:
        FGameplayTag    InjectionTag;                   // 0x000070 (0x000004)
        uint8           UnknownData_000074[0x000004];   // 0x000074 (0x000004)
        UBehaviorTree*  DefaultBehaviorAsset;           // 0x000078 (0x000008) [Default: nullptr]
        UBehaviorTree*  BehaviorAsset;                  // 0x000080 (0x000008) [Default: nullptr]
    };
    // Size: 0x000100 (0x000068)
    class alignas(0x8) UBTTask_RunEQSQuery : public UBTTask_BlackboardBase
    {
    public:
        bool                                    bUseBBKey;                      // 0x000098 (0x000001) [Default: false]
        uint8                                   UnknownData_000099[0x000007];   // 0x000099 (0x000007)
        FEQSParametrizedQueryExecutionRequest   EQSRequest;                     // 0x0000A0 (0x000048)
        bool                                    bUpdateBBOnFail;                // 0x0000E8 (0x000001) [Default: false]
        uint8                                   UnknownData_0000E9[0x000017];   // 0x0000E9 (0x000017)
    };
    // Size: 0x0000B0 (0x000018)
    class alignas(0x8) UBTTask_SetKeyValueBool : public UBTTask_BlackboardBase
    {
    public:
        FValueOrBBKey_Bool  Value;  // 0x000098 (0x000018)
    };
    // Size: 0x0000C0 (0x000028)
    class alignas(0x8) UBTTask_SetKeyValueClass : public UBTTask_BlackboardBase
    {
    public:
        UClass*             BaseClass;  // 0x000098 (0x000008) [Default: 0x16A236E0]
        FValueOrBBKey_Class Value;      // 0x0000A0 (0x000020)
    };
    // Size: 0x0000D0 (0x000038)
    class alignas(0x8) UBTTask_SetKeyValueEnum : public UBTTask_BlackboardBase
    {
    public:
        UEnum*              EnumType;   // 0x000098 (0x000008) [Default: nullptr]
        FValueOrBBKey_Enum  Value;      // 0x0000A0 (0x000030)
    };
    // Size: 0x0000B0 (0x000018)
    class alignas(0x8) UBTTask_SetKeyValueFloat : public UBTTask_BlackboardBase
    {
    public:
        FValueOrBBKey_Float Value;  // 0x000098 (0x000018)
    };
    // Size: 0x0000B0 (0x000018)
    class alignas(0x8) UBTTask_SetKeyValueInt32 : public UBTTask_BlackboardBase
    {
    public:
        FValueOrBBKey_Int32 Value;  // 0x000098 (0x000018)
    };
    // Size: 0x0000B0 (0x000018)
    class alignas(0x8) UBTTask_SetKeyValueName : public UBTTask_BlackboardBase
    {
    public:
        FValueOrBBKey_Name  Value;  // 0x000098 (0x000018)
    };
    // Size: 0x0000C0 (0x000028)
    class alignas(0x8) UBTTask_SetKeyValueObject : public UBTTask_BlackboardBase
    {
    public:
        UClass*                 BaseClass;  // 0x000098 (0x000008) [Default: 0x16A236E0]
        FValueOrBBKey_Object    Value;      // 0x0000A0 (0x000020)
    };
    // Size: 0x0000C0 (0x000028)
    class alignas(0x8) UBTTask_SetKeyValueRotator : public UBTTask_BlackboardBase
    {
    public:
        FValueOrBBKey_Rotator   Value;  // 0x000098 (0x000028)
    };
    // Size: 0x0000B8 (0x000020)
    class alignas(0x8) UBTTask_SetKeyValueString : public UBTTask_BlackboardBase
    {
    public:
        FValueOrBBKey_String    Value;  // 0x000098 (0x000020)
    };
    // Size: 0x0000C0 (0x000028)
    class alignas(0x8) UBTTask_SetKeyValueStruct : public UBTTask_BlackboardBase
    {
    public:
        UScriptStruct*          StructType; // 0x000098 (0x000008) [Default: nullptr]
        FValueOrBBKey_Struct    Value;      // 0x0000A0 (0x000020)
    };
    // Size: 0x0000C0 (0x000028)
    class alignas(0x8) UBTTask_SetKeyValueVector : public UBTTask_BlackboardBase
    {
    public:
        FValueOrBBKey_Vector    Value;  // 0x000098 (0x000028)
    };
    // Size: 0x0000A8 (0x000038)
    class alignas(0x8) UBTTask_SetTagCooldown : public UBTTaskNode
    {
    public:
        FGameplayTag        CooldownTag;                    // 0x000070 (0x000004)
        uint8               UnknownData_000074[0x000004];   // 0x000074 (0x000004)
        FValueOrBBKey_Bool  bAddToExistingDuration;         // 0x000078 (0x000018)
        FValueOrBBKey_Float CooldownDuration;               // 0x000090 (0x000018)
    };
    // Size: 0x0000A0 (0x000030)
    class alignas(0x8) UBTTask_Wait : public UBTTaskNode
    {
    public:
        FValueOrBBKey_Float WaitTime;           // 0x000070 (0x000018)
        FValueOrBBKey_Float RandomDeviation;    // 0x000088 (0x000018)
    };
    // Size: 0x0000C8 (0x000028)
    class alignas(0x8) UBTTask_WaitBlackboardTime : public UBTTask_Wait
    {
    public:
        FBlackboardKeySelector  BlackboardKey;  // 0x0000A0 (0x000028)
    };
    // Size: 0x000068 (0x000040)
    class alignas(0x8) UBehaviorTree : public UObject
    {
    public:
        void**                      VTable_000028;                  // 0x000028 (0x000008) VTable [3 slots] -> 0x132ADD80
        UBTCompositeNode*           RootNode;                       // 0x000030 (0x000008) [Default: nullptr]
        UBlackboardData*            BlackboardAsset;                // 0x000038 (0x000008) [Default: nullptr]
        TArray<UBTDecorator*>       RootDecorators;                 // 0x000040 (0x000010)
        TArray<FBTDecoratorLogic>   RootDecoratorOps;               // 0x000050 (0x000010)
        uint8                       UnknownData_000060[0x000008];   // 0x000060 (0x000008)
    };
    // Size: 0x000238 (0x000120)
    class alignas(0x8) UBehaviorTreeComponent : public UBrainComponent
    {
    public:
        uint8               UnknownData_000118[0x000020];   // 0x000118 (0x000020)
        TArray<UBTNode*>    NodeInstances;                  // 0x000138 (0x000010)
        uint8               UnknownData_000148[0x0000C8];   // 0x000148 (0x0000C8)
        UBehaviorTree*      DefaultBehaviorTreeAsset;       // 0x000210 (0x000008) [Default: nullptr]
        uint8               UnknownData_000218[0x000020];   // 0x000218 (0x000020)
    
    public: // Functions
        void    AddCooldownTagDuration(FGameplayTag CooldownTag, float CooldownDuration, bool bAddToExistingDuration); // 0x05015876 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        double  GetTagCooldownEndTime(FGameplayTag CooldownTag); // 0x05015E36 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    SetDynamicSubtree(FGameplayTag InjectTag, UBehaviorTree* BehaviorAsset); // 0x050160B8 [RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000050 (0x000028)
    class alignas(0x8) UBehaviorTreeManager : public UObject
    {
    public:
        int32                               MaxDebuggerSteps;               // 0x000028 (0x000004) [Default: 100]
        uint8                               UnknownData_00002C[0x000004];   // 0x00002C (0x000004)
        TArray<FBehaviorTreeTemplateInfo>   LoadedTemplates;                // 0x000030 (0x000010)
        TArray<UBehaviorTreeComponent*>     ActiveComponents;               // 0x000040 (0x000010)
    };
    // Size: 0x000028 (0x000000)
    class UBehaviorTreeTypes : public UObject
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class IBlackboardAssetProvider : public IInterface
    {
    public:
    
    public: // Functions
        UBlackboardData*    GetBlackboardAsset(); // 0x0C989206 [Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000150 (0x000090)
    class alignas(0x8) UBlackboardComponent : public UActorComponent
    {
    public:
        UBrainComponent*            BrainComp;                      // 0x0000C0 (0x000008) [Default: nullptr]
        UBlackboardData*            DefaultBlackboardAsset;         // 0x0000C8 (0x000008) [Default: nullptr]
        UBlackboardData*            BlackboardAsset;                // 0x0000D0 (0x000008) [Default: nullptr]
        uint8                       UnknownData_0000D8[0x000020];   // 0x0000D8 (0x000020)
        TArray<UBlackboardKeyType*> KeyInstances;                   // 0x0000F8 (0x000010)
        uint8                       UnknownData_000108[0x000048];   // 0x000108 (0x000048)
    
    public: // Functions
        void        ClearValue(FName& KeyName); // 0x0501A130 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        bool        GetLocationFromEntry(FName& KeyName, FVector& ResultLocation); // 0x0501A2B0 [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        bool        GetRotationFromEntry(FName& KeyName, FRotator& ResultRotation); // 0x0501A55E [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        bool        GetValueAsBool(FName& KeyName); // 0x0501A80C [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        UClass*     GetValueAsClass(FName& KeyName); // 0x0501A992 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        uint8       GetValueAsEnum(FName& KeyName); // 0x0501AB1A [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        float       GetValueAsFloat(FName& KeyName); // 0x0501ACA0 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        int32       GetValueAsInt(FName& KeyName); // 0x0501AE28 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        FName       GetValueAsName(FName& KeyName); // 0x0501AFAE [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        UObject*    GetValueAsObject(FName& KeyName); // 0x0501B13E [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        FRotator    GetValueAsRotator(FName& KeyName); // 0x0501B2C6 [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        FString     GetValueAsString(FName& KeyName); // 0x0501B460 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        FVector     GetValueAsVector(FName& KeyName); // 0x0501B620 [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        bool        IsVectorValueSet(FName& KeyName); // 0x0501B7BA [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        void        SetValueAsBool(FName& KeyName, bool BoolValue); // 0x0501B940 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void        SetValueAsClass(FName& KeyName, UClass* ClassValue); // 0x0501BBD6 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void        SetValueAsEnum(FName& KeyName, uint8 EnumValue); // 0x0501BE6A [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void        SetValueAsFloat(FName& KeyName, float FloatValue); // 0x0501C0FA [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void        SetValueAsInt(FName& KeyName, int32 IntValue); // 0x0501C38E [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void        SetValueAsName(FName& KeyName, FName NameValue); // 0x0501C620 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void        SetValueAsObject(FName& KeyName, UObject* ObjectValue); // 0x0501C8B2 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void        SetValueAsRotator(FName& KeyName, FRotator VectorValue); // 0x0501CB46 [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        void        SetValueAsString(FName& KeyName, FString StringValue); // 0x0501CDE2 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void        SetValueAsVector(FName& KeyName, FVector VectorValue); // 0x0501D0F2 [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000048 (0x000020)
    class alignas(0x8) UBlackboardData : public UDataAsset
    {
    public:
        UBlackboardData*            Parent;                         // 0x000028 (0x000008) [Default: nullptr]
        TArray<FBlackboardEntry>    Keys;                           // 0x000030 (0x000010)
        uint8                       bHasSynchronizedKeys : 1;       // 0x000040 (0x000001) : 0x0 [Default: false]
        uint8                       UnknownBit_000040_1 : 1;        // 0x000040 (0x000001) : 0x1
        uint8                       UnknownBit_000040_2 : 1;        // 0x000040 (0x000001) : 0x2
        uint8                       UnknownBit_000040_3 : 1;        // 0x000040 (0x000001) : 0x3
        uint8                       UnknownBit_000040_4 : 1;        // 0x000040 (0x000001) : 0x4
        uint8                       UnknownBit_000040_5 : 1;        // 0x000040 (0x000001) : 0x5
        uint8                       UnknownBit_000040_6 : 1;        // 0x000040 (0x000001) : 0x6
        uint8                       UnknownBit_000040_7 : 1;        // 0x000040 (0x000001) : 0x7
        uint8                       UnknownData_000041[0x000007];   // 0x000041 (0x000007)
    };
    // Size: 0x000030 (0x000008)
    class UBlackboardKeyType : public UObject
    {
    public:
        uint8   UnknownData_000028[0x000008];   // 0x000028 (0x000008)
    };
    // Size: 0x000038 (0x000008)
    class UBlackboardKeyType_Bool : public UBlackboardKeyType
    {
    public:
        bool    bDefaultValue;                  // 0x000030 (0x000001) [Default: false]
        uint8   UnknownData_000031[0x000007];   // 0x000031 (0x000007)
    };
    // Size: 0x000040 (0x000010)
    class alignas(0x8) UBlackboardKeyType_Class : public UBlackboardKeyType
    {
    public:
        UClass* BaseClass;      // 0x000030 (0x000008) [Default: 0x16A236E0]
        UClass* DefaultValue;   // 0x000038 (0x000008) [Default: nullptr]
    };
    // Size: 0x000050 (0x000020)
    class alignas(0x8) UBlackboardKeyType_Enum : public UBlackboardKeyType
    {
    public:
        UEnum*  EnumType;                       // 0x000030 (0x000008) [Default: nullptr]
        FString EnumName;                       // 0x000038 (0x000010) [Default: L""]
        uint8   DefaultValue;                   // 0x000048 (0x000001) [Default: 0]
        uint8   UnknownData_000049[0x000003];   // 0x000049 (0x000003)
        uint8   bIsEnumNameValid : 1;           // 0x00004C (0x000001) : 0x0 [Default: false]
        uint8   UnknownBit_00004C_1 : 1;        // 0x00004C (0x000001) : 0x1
        uint8   UnknownBit_00004C_2 : 1;        // 0x00004C (0x000001) : 0x2
        uint8   UnknownBit_00004C_3 : 1;        // 0x00004C (0x000001) : 0x3
        uint8   UnknownBit_00004C_4 : 1;        // 0x00004C (0x000001) : 0x4
        uint8   UnknownBit_00004C_5 : 1;        // 0x00004C (0x000001) : 0x5
        uint8   UnknownBit_00004C_6 : 1;        // 0x00004C (0x000001) : 0x6
        uint8   UnknownBit_00004C_7 : 1;        // 0x00004C (0x000001) : 0x7
        uint8   UnknownData_00004D[0x000003];   // 0x00004D (0x000003)
    };
    // Size: 0x000038 (0x000008)
    class alignas(0x4) UBlackboardKeyType_Float : public UBlackboardKeyType
    {
    public:
        float   DefaultValue;                   // 0x000030 (0x000004) [Default: 0f]
        uint8   UnknownData_000034[0x000004];   // 0x000034 (0x000004)
    };
    // Size: 0x000038 (0x000008)
    class alignas(0x4) UBlackboardKeyType_Int : public UBlackboardKeyType
    {
    public:
        int32   DefaultValue;                   // 0x000030 (0x000004) [Default: 0]
        uint8   UnknownData_000034[0x000004];   // 0x000034 (0x000004)
    };
    // Size: 0x000038 (0x000008)
    class alignas(0x4) UBlackboardKeyType_Name : public UBlackboardKeyType
    {
    public:
        FName   DefaultValue;                   // 0x000030 (0x000004) [Default: NAME_None]
        uint8   UnknownData_000034[0x000004];   // 0x000034 (0x000004)
    };
    // Size: 0x000048 (0x000018)
    class alignas(0x8) UBlackboardKeyType_NativeEnum : public UBlackboardKeyType
    {
    public:
        FString EnumName;   // 0x000030 (0x000010) [Default: L""]
        UEnum*  EnumType;   // 0x000040 (0x000008) [Default: nullptr]
    };
    // Size: 0x000040 (0x000010)
    class alignas(0x8) UBlackboardKeyType_Object : public UBlackboardKeyType
    {
    public:
        UClass*     BaseClass;      // 0x000030 (0x000008) [Default: 0x16A236E0]
        UObject*    DefaultValue;   // 0x000038 (0x000008) [Default: nullptr]
    };
    // Size: 0x000050 (0x000020)
    class alignas(0x8) UBlackboardKeyType_Rotator : public UBlackboardKeyType
    {
    public:
        FRotator    DefaultValue;                   // 0x000030 (0x000018)
        bool        bUseDefaultValue;               // 0x000048 (0x000001) [Default: false]
        uint8       UnknownData_000049[0x000007];   // 0x000049 (0x000007)
    };
    // Size: 0x000050 (0x000020)
    class alignas(0x8) UBlackboardKeyType_String : public UBlackboardKeyType
    {
    public:
        FString StringValue;    // 0x000030 (0x000010) [Default: L""]
        FString DefaultValue;   // 0x000040 (0x000010) [Default: L""]
    };
    // Size: 0x000050 (0x000020)
    class alignas(0x8) UBlackboardKeyType_Struct : public UBlackboardKeyType
    {
    public:
        FInstancedStruct    DefaultValue;   // 0x000030 (0x000010)
        FInstancedStruct    Value;          // 0x000040 (0x000010)
    };
    // Size: 0x000050 (0x000020)
    class alignas(0x8) UBlackboardKeyType_Vector : public UBlackboardKeyType
    {
    public:
        FVector DefaultValue;                   // 0x000030 (0x000018)
        bool    bUseDefaultValue;               // 0x000048 (0x000001) [Default: false]
        uint8   UnknownData_000049[0x000007];   // 0x000049 (0x000007)
    };
    // Size: 0x000118 (0x000058)
    class alignas(0x8) UBrainComponent : public UActorComponent
    {
    public:
        void**                  VTable_0000C0;                  // 0x0000C0 (0x000008) VTable [89 slots] -> 0x132BF990
        UBlackboardComponent*   BlackboardComp;                 // 0x0000C8 (0x000008) [Default: nullptr]
        AAIController*          AIOwner;                        // 0x0000D0 (0x000008) [Default: nullptr]
        uint8                   UnknownData_0000D8[0x000040];   // 0x0000D8 (0x000040)
    
    public: // Functions
        bool    IsPaused(); // 0x0DB76134 [RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool    IsRunning(); // 0x0DB7615E [RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    RestartLogic(); // 0x0DAC6250 [RequiredAPI | Native | Public | BlueprintCallable]
        void    StartLogic(); // 0x0CBFB85A [RequiredAPI | Native | Public | BlueprintCallable]
        void    StopLogic(FString Reason); // 0x0502CA70 [RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class ICrowdAgentInterface : public IInterface
    {
    public:
    };
    // Size: 0x000360 (0x000050)
    class alignas(0x8) UCrowdFollowingComponent : public UPathFollowingComponent
    {
    public:
        void**  VTable_000310;                  // 0x000310 (0x000008) VTable [9 slots] -> 0x132C9820
        uint8   UnknownData_000318[0x000010];   // 0x000318 (0x000010)
        FVector CrowdAgentMoveDirection;        // 0x000328 (0x000018)
        uint8   UnknownData_000340[0x000020];   // 0x000340 (0x000020)
    
    public: // Functions
        void    SuspendCrowdSteering(bool bSuspend); // 0x0504A614 [RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x0000B0 (0x000088)
    class alignas(0x8) UCrowdManager : public UCrowdManagerBase
    {
    public:
        ANavigationData*                        MyNavData;                      // 0x000028 (0x000008) [Default: nullptr]
        TArray<FCrowdAvoidanceConfig>           AvoidanceConfig;                // 0x000030 (0x000010)
        TArray<FCrowdAvoidanceSamplingPattern>  SamplingPatterns;               // 0x000040 (0x000010)
        int32                                   MaxAgents;                      // 0x000050 (0x000004) [Default: 50]
        float                                   MaxAgentRadius;                 // 0x000054 (0x000004) [Default: 100f]
        int32                                   MaxAvoidedAgents;               // 0x000058 (0x000004) [Default: 6]
        int32                                   MaxAvoidedWalls;                // 0x00005C (0x000004) [Default: 8]
        float                                   NavmeshCheckInterval;           // 0x000060 (0x000004) [Default: 1f]
        float                                   PathOptimizationInterval;       // 0x000064 (0x000004) [Default: 0.5f]
        float                                   SeparationDirClamp;             // 0x000068 (0x000004) [Default: -1f]
        float                                   PathOffsetRadiusMultiplier;     // 0x00006C (0x000004) [Default: 1f]
        uint8                                   bResolveCollisions : 1;         // 0x000070 (0x000001) : 0x0 [Default: true]
        uint8                                   UnknownBit_000070_1 : 1;        // 0x000070 (0x000001) : 0x1
        uint8                                   UnknownBit_000070_2 : 1;        // 0x000070 (0x000001) : 0x2
        uint8                                   UnknownBit_000070_3 : 1;        // 0x000070 (0x000001) : 0x3
        uint8                                   UnknownBit_000070_4 : 1;        // 0x000070 (0x000001) : 0x4
        uint8                                   UnknownBit_000070_5 : 1;        // 0x000070 (0x000001) : 0x5
        uint8                                   UnknownBit_000070_6 : 1;        // 0x000070 (0x000001) : 0x6
        uint8                                   UnknownBit_000070_7 : 1;        // 0x000070 (0x000001) : 0x7
        uint8                                   UnknownData_000071[0x00003F];   // 0x000071 (0x00003F)
    };
    // Size: 0x000028 (0x000000)
    class IEQSQueryResultSourceInterface : public IInterface
    {
    public:
    };
    // Size: 0x000620 (0x000050)
    class UEQSRenderingComponent : public UDebugDrawComponent
    {
    public:
        uint8   UnknownData_0005D0[0x000050];   // 0x0005D0 (0x000050)
    };
    // Size: 0x000048 (0x000020)
    class alignas(0x8) UEnvQuery : public UDataAsset
    {
    public:
        FName                       QueryName;                      // 0x000028 (0x000004) [Default: FName(1144959675) -> L"Default__EnvQuery"]
        uint8                       UnknownData_00002C[0x000004];   // 0x00002C (0x000004)
        TArray<UEnvQueryOption*>    Options;                        // 0x000030 (0x000010)
        uint8                       bStripFromClientBuilds : 1;     // 0x000040 (0x000001) : 0x0 [Default: false]
        uint8                       UnknownBit_000040_1 : 1;        // 0x000040 (0x000001) : 0x1
        uint8                       UnknownBit_000040_2 : 1;        // 0x000040 (0x000001) : 0x2
        uint8                       UnknownBit_000040_3 : 1;        // 0x000040 (0x000001) : 0x3
        uint8                       UnknownBit_000040_4 : 1;        // 0x000040 (0x000001) : 0x4
        uint8                       UnknownBit_000040_5 : 1;        // 0x000040 (0x000001) : 0x5
        uint8                       UnknownBit_000040_6 : 1;        // 0x000040 (0x000001) : 0x6
        uint8                       UnknownBit_000040_7 : 1;        // 0x000040 (0x000001) : 0x7
        uint8                       UnknownData_000041[0x000007];   // 0x000041 (0x000007)
    };
    // Size: 0x000028 (0x000000)
    class UEnvQueryContext : public UObject
    {
    public:
    };
    // Size: 0x000030 (0x000008)
    class UEnvQueryContext_BlueprintBase : public UEnvQueryContext
    {
    public:
        uint8   UnknownData_000028[0x000008];   // 0x000028 (0x000008)
    
    public: // Functions
        void    ProvideActorsSet(UObject* QuerierObject, AActor* QuerierActor, TArray<AActor*>& ResultingActorsSet); // 0x000545D2 [Event | Public | HasOutParms | BlueprintEvent | Const]
        void    ProvideLocationsSet(UObject* QuerierObject, AActor* QuerierActor, TArray<FVector>& ResultingLocationSet); // 0x000545D2 [Event | Public | HasOutParms | BlueprintEvent | Const]
        void    ProvideSingleActor(UObject* QuerierObject, AActor* QuerierActor, AActor*& ResultingActor); // 0x000545D2 [Event | Public | HasOutParms | BlueprintEvent | Const]
        void    ProvideSingleLocation(UObject* QuerierObject, AActor* QuerierActor, FVector& ResultingLocation); // 0x000545D2 [Event | Public | HasOutParms | HasDefaults | BlueprintEvent | Const]
    };
    // Size: 0x000028 (0x000000)
    class UEnvQueryContext_Item : public UEnvQueryContext
    {
    public:
    };
    // Size: 0x000058 (0x000030)
    class alignas(0x8) UEnvQueryContext_NavigationData : public UEnvQueryContext
    {
    public:
        FNavAgentProperties NavAgentProperties; // 0x000028 (0x000030)
    };
    // Size: 0x000028 (0x000000)
    class UEnvQueryContext_Querier : public UEnvQueryContext
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class UEnvQueryDebugHelpers : public UObject
    {
    public:
    };
    // Size: 0x000050 (0x000020)
    class alignas(0x8) UEnvQueryGenerator : public UEnvQueryNode
    {
    public:
        FString                             OptionName;                         // 0x000030 (0x000010) [Default: L""]
        UClass*                             ItemType;                           // 0x000040 (0x000008) [Default: nullptr]
        uint8                               bAutoSortTests : 1;                 // 0x000048 (0x000001) : 0x0 [Default: true]
        uint8                               bCanRunAsync : 1;                   // 0x000048 (0x000001) : 0x0 [Default: true]
        uint8                               UnknownBit_000048_1 : 1;            // 0x000048 (0x000001) : 0x1
        uint8                               UnknownBit_000048_2 : 1;            // 0x000048 (0x000001) : 0x2
        uint8                               UnknownBit_000048_3 : 1;            // 0x000048 (0x000001) : 0x3
        uint8                               UnknownBit_000048_4 : 1;            // 0x000048 (0x000001) : 0x4
        uint8                               UnknownBit_000048_5 : 1;            // 0x000048 (0x000001) : 0x5
        uint8                               UnknownBit_000048_6 : 1;            // 0x000048 (0x000001) : 0x6
        uint8                               UnknownBit_000048_7 : 1;            // 0x000048 (0x000001) : 0x7
        uint8                               UnknownData_000049[0x000003];       // 0x000049 (0x000003)
        EEnvQueryResultNormalizationOption  EnvQueryResultNormalizationOption;  // 0x00004C (0x000001) [Default: EEnvQueryResultNormalizationOption(0)]
        uint8                               UnknownData_00004D[0x000003];       // 0x00004D (0x000003)
    };
    // Size: 0x0000D0 (0x000080)
    class alignas(0x8) UEnvQueryGenerator_ActorsOfClass : public UEnvQueryGenerator
    {
    public:
        UClass*                     SearchedActorClass;         // 0x000050 (0x000008) [Default: 0x16BB4C60]
        FAIDataProviderBoolValue    GenerateOnlyActorsInRadius; // 0x000058 (0x000038)
        FAIDataProviderFloatValue   SearchRadius;               // 0x000090 (0x000038)
        UClass*                     SearchCenter;               // 0x0000C8 (0x000008) [Default: 0x17323C20]
    };
    // Size: 0x000080 (0x000030)
    class alignas(0x8) UEnvQueryGenerator_BlueprintBase : public UEnvQueryGenerator
    {
    public:
        FText   GeneratorsActionDescription;    // 0x000050 (0x000010)
        UClass* Context;                        // 0x000060 (0x000008) [Default: 0x17323C20]
        UClass* GeneratedItemType;              // 0x000068 (0x000008) [Default: 0x17330000]
        uint8   UnknownData_000070[0x000010];   // 0x000070 (0x000010)
    
    public: // Functions
        void        AddGeneratedActor(AActor* GeneratedActor); // 0x0503D008 [Final | RequiredAPI | Native | Public | BlueprintCallable | Const]
        void        AddGeneratedVector(FVector GeneratedVector); // 0x0503D2F8 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable | Const]
        void        DoItemGeneration(TArray<FVector>& ContextLocations); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent | Const]
        void        DoItemGenerationFromActors(TArray<AActor*>& ContextActors); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent | Const]
        UObject*    GetQuerier(); // 0x0DB81DAE [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000070 (0x000020)
    class alignas(0x8) UEnvQueryGenerator_Composite : public UEnvQueryGenerator
    {
    public:
        TArray<UEnvQueryGenerator*> Generators;                     // 0x000050 (0x000010)
        uint8                       bAllowDifferentItemTypes : 1;   // 0x000060 (0x000001) : 0x0 [Default: true]
        uint8                       bHasMatchingItemType : 1;       // 0x000060 (0x000001) : 0x0 [Default: true]
        uint8                       UnknownBit_000060_1 : 1;        // 0x000060 (0x000001) : 0x1
        uint8                       UnknownBit_000060_2 : 1;        // 0x000060 (0x000001) : 0x2
        uint8                       UnknownBit_000060_3 : 1;        // 0x000060 (0x000001) : 0x3
        uint8                       UnknownBit_000060_4 : 1;        // 0x000060 (0x000001) : 0x4
        uint8                       UnknownBit_000060_5 : 1;        // 0x000060 (0x000001) : 0x5
        uint8                       UnknownBit_000060_6 : 1;        // 0x000060 (0x000001) : 0x6
        uint8                       UnknownBit_000060_7 : 1;        // 0x000060 (0x000001) : 0x7
        uint8                       UnknownData_000061[0x000007];   // 0x000061 (0x000007)
        UClass*                     ForcedItemType;                 // 0x000068 (0x000008) [Default: nullptr]
    };
    // Size: 0x000180 (0x0000F0)
    class alignas(0x8) UEnvQueryGenerator_Cone : public UEnvQueryGenerator_ProjectedPoints
    {
    public:
        FAIDataProviderFloatValue   AlignedPointsDistance;          // 0x000090 (0x000038)
        FAIDataProviderFloatValue   ConeDegrees;                    // 0x0000C8 (0x000038)
        FAIDataProviderFloatValue   AngleStep;                      // 0x000100 (0x000038)
        FAIDataProviderFloatValue   Range;                          // 0x000138 (0x000038)
        UClass*                     CenterActor;                    // 0x000170 (0x000008) [Default: 0x17323C20]
        uint8                       bIncludeContextLocation : 1;    // 0x000178 (0x000001) : 0x0 [Default: false]
        uint8                       UnknownBit_000178_1 : 1;        // 0x000178 (0x000001) : 0x1
        uint8                       UnknownBit_000178_2 : 1;        // 0x000178 (0x000001) : 0x2
        uint8                       UnknownBit_000178_3 : 1;        // 0x000178 (0x000001) : 0x3
        uint8                       UnknownBit_000178_4 : 1;        // 0x000178 (0x000001) : 0x4
        uint8                       UnknownBit_000178_5 : 1;        // 0x000178 (0x000001) : 0x5
        uint8                       UnknownBit_000178_6 : 1;        // 0x000178 (0x000001) : 0x6
        uint8                       UnknownBit_000178_7 : 1;        // 0x000178 (0x000001) : 0x7
        uint8                       UnknownData_000179[0x000007];   // 0x000179 (0x000007)
    };
    // Size: 0x000098 (0x000008)
    class alignas(0x8) UEnvQueryGenerator_CurrentLocation : public UEnvQueryGenerator_ProjectedPoints
    {
    public:
        UClass* QueryContext;   // 0x000090 (0x000008) [Default: 0x17323C20]
    };
    // Size: 0x000220 (0x000190)
    class alignas(0x8) UEnvQueryGenerator_Donut : public UEnvQueryGenerator_ProjectedPoints
    {
    public:
        FAIDataProviderFloatValue   InnerRadius;                    // 0x000090 (0x000038)
        FAIDataProviderFloatValue   OuterRadius;                    // 0x0000C8 (0x000038)
        FAIDataProviderIntValue     NumberOfRings;                  // 0x000100 (0x000038)
        EEnvQueryPointSpacingMethod PointOnRingSpacingMethod;       // 0x000138 (0x000001) [Default: EEnvQueryPointSpacingMethod(1)]
        uint8                       UnknownData_000139[0x000007];   // 0x000139 (0x000007)
        FAIDataProviderFloatValue   SpaceBetweenPoints;             // 0x000140 (0x000038)
        FAIDataProviderIntValue     PointsPerRing;                  // 0x000178 (0x000038)
        FEnvDirection               ArcDirection;                   // 0x0001B0 (0x000020)
        FAIDataProviderFloatValue   ArcAngle;                       // 0x0001D0 (0x000038)
        bool                        bUseSpiralPattern;              // 0x000208 (0x000001) [Default: false]
        uint8                       UnknownData_000209[0x000007];   // 0x000209 (0x000007)
        UClass*                     Center;                         // 0x000210 (0x000008) [Default: 0x17323C20]
        uint8                       bDefineArc : 1;                 // 0x000218 (0x000001) : 0x0 [Default: false]
        uint8                       UnknownBit_000218_1 : 1;        // 0x000218 (0x000001) : 0x1
        uint8                       UnknownBit_000218_2 : 1;        // 0x000218 (0x000001) : 0x2
        uint8                       UnknownBit_000218_3 : 1;        // 0x000218 (0x000001) : 0x3
        uint8                       UnknownBit_000218_4 : 1;        // 0x000218 (0x000001) : 0x4
        uint8                       UnknownBit_000218_5 : 1;        // 0x000218 (0x000001) : 0x5
        uint8                       UnknownBit_000218_6 : 1;        // 0x000218 (0x000001) : 0x6
        uint8                       UnknownBit_000218_7 : 1;        // 0x000218 (0x000001) : 0x7
        uint8                       UnknownData_000219[0x000007];   // 0x000219 (0x000007)
    };
    // Size: 0x000258 (0x0001C8)
    class alignas(0x8) UEnvQueryGenerator_OnCircle : public UEnvQueryGenerator_ProjectedPoints
    {
    public:
        FAIDataProviderFloatValue   CircleRadius;                                   // 0x000090 (0x000038)
        EEnvQueryPointSpacingMethod PointOnCircleSpacingMethod;                     // 0x0000C8 (0x000001) [Default: EEnvQueryPointSpacingMethod(0)]
        uint8                       UnknownData_0000C9[0x000007];                   // 0x0000C9 (0x000007)
        FAIDataProviderFloatValue   SpaceBetween;                                   // 0x0000D0 (0x000038)
        FAIDataProviderIntValue     NumberOfPoints;                                 // 0x000108 (0x000038)
        FEnvDirection               ArcDirection;                                   // 0x000140 (0x000020)
        FAIDataProviderFloatValue   ArcDirectionOffsetDegrees;                      // 0x000160 (0x000038)
        FAIDataProviderFloatValue   ArcAngle;                                       // 0x000198 (0x000038)
        UClass*                     CircleCenter;                                   // 0x0001D0 (0x000008) [Default: 0x17323C20]
        bool                        bIgnoreAnyContextActorsWhenGeneratingCircle;    // 0x0001D8 (0x000001) [Default: false]
        uint8                       UnknownData_0001D9[0x000007];                   // 0x0001D9 (0x000007)
        FAIDataProviderFloatValue   CircleCenterZOffset;                            // 0x0001E0 (0x000038)
        FEnvTraceData               TraceData;                                      // 0x000218 (0x000038)
        uint8                       bDefineArc : 1;                                 // 0x000250 (0x000001) : 0x0 [Default: false]
        uint8                       UnknownBit_000250_1 : 1;                        // 0x000250 (0x000001) : 0x1
        uint8                       UnknownBit_000250_2 : 1;                        // 0x000250 (0x000001) : 0x2
        uint8                       UnknownBit_000250_3 : 1;                        // 0x000250 (0x000001) : 0x3
        uint8                       UnknownBit_000250_4 : 1;                        // 0x000250 (0x000001) : 0x4
        uint8                       UnknownBit_000250_5 : 1;                        // 0x000250 (0x000001) : 0x5
        uint8                       UnknownBit_000250_6 : 1;                        // 0x000250 (0x000001) : 0x6
        uint8                       UnknownBit_000250_7 : 1;                        // 0x000250 (0x000001) : 0x7
        uint8                       UnknownData_000251[0x000007];                   // 0x000251 (0x000007)
    };
    // Size: 0x000180 (0x000078)
    class alignas(0x8) UEnvQueryGenerator_PathingGrid : public UEnvQueryGenerator_SimpleGrid
    {
    public:
        FAIDataProviderBoolValue    PathToItem;             // 0x000108 (0x000038)
        UClass*                     NavigationFilter;       // 0x000140 (0x000008) [Default: nullptr]
        FAIDataProviderFloatValue   ScanRangeMultiplier;    // 0x000148 (0x000038)
    };
    // Size: 0x0000A8 (0x000058)
    class alignas(0x8) UEnvQueryGenerator_PerceivedActors : public UEnvQueryGenerator
    {
    public:
        UClass*                     AllowedActorClass;              // 0x000050 (0x000008) [Default: nullptr]
        FAIDataProviderFloatValue   SearchRadius;                   // 0x000058 (0x000038)
        UClass*                     ListenerContext;                // 0x000090 (0x000008) [Default: 0x17323C20]
        UClass*                     SenseToUse;                     // 0x000098 (0x000008) [Default: nullptr]
        bool                        bIncludeKnownActors;            // 0x0000A0 (0x000001) [Default: true]
        uint8                       UnknownData_0000A1[0x000007];   // 0x0000A1 (0x000007)
    };
    // Size: 0x000090 (0x000040)
    class alignas(0x8) UEnvQueryGenerator_ProjectedPoints : public UEnvQueryGenerator
    {
    public:
        FEnvTraceData   ProjectionData;         // 0x000050 (0x000038)
        UClass*         NavDataOverrideContext; // 0x000088 (0x000008) [Default: nullptr]
    };
    // Size: 0x000108 (0x000078)
    class alignas(0x8) UEnvQueryGenerator_SimpleGrid : public UEnvQueryGenerator_ProjectedPoints
    {
    public:
        FAIDataProviderFloatValue   GridSize;       // 0x000090 (0x000038)
        FAIDataProviderFloatValue   SpaceBetween;   // 0x0000C8 (0x000038)
        UClass*                     GenerateAround; // 0x000100 (0x000008) [Default: 0x17323C20]
    };
    // Size: 0x000078 (0x000050)
    class alignas(0x8) UEnvQueryInstanceBlueprintWrapper : public UObject
    {
    public:
        void**                                          VTable_000028;                  // 0x000028 (0x000008) VTable [7 slots] -> 0x132C2210
        int32                                           QueryID;                        // 0x000030 (0x000004) [Default: -1]
        uint8                                           UnknownData_000034[0x000024];   // 0x000034 (0x000024)
        UClass*                                         ItemType;                       // 0x000058 (0x000008) [Default: nullptr]
        int32                                           OptionIndex;                    // 0x000060 (0x000004) [Default: 0]
        uint8                                           UnknownData_000064[0x000004];   // 0x000064 (0x000004)
        MULTI_INLINE_DELEGATE(EQSQueryDoneSignature)    OnQueryFinishedEvent;           // 0x000068 (0x000010)
    
    public: // Functions
        float           GetItemScore(int32 ItemIndex); // 0x0502EF2C [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool            GetQueryResultsAsActors(TArray<AActor*>& ResultActors); // 0x0502F0C4 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | Const]
        bool            GetQueryResultsAsLocations(TArray<FVector>& ResultLocations); // 0x0502F258 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | Const]
        bool            GetQueryResultsAsTransforms(TArray<FTransform>& ResultTransforms); // 0x0502F3EC [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | Const]
        TArray<AActor*> GetResultsAsActors(); // 0x0DB7AB70 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FVector> GetResultsAsLocations(); // 0x0DB7ACAE [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void            SetNamedParam(FName ParamName, float Value); // 0x0502F580 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void            EQSQueryDoneSignature(UEnvQueryInstanceBlueprintWrapper* QueryInstance, TEnumAsByte<EEnvQueryStatus> QueryStatus); // 0x000545D2 [MulticastDelegate | Public | Delegate]
    };
    // Size: 0x000030 (0x000008)
    class UEnvQueryItemType : public UObject
    {
    public:
        uint8   UnknownData_000028[0x000008];   // 0x000028 (0x000008)
    };
    // Size: 0x000030 (0x000000)
    class UEnvQueryItemType_Actor : public UEnvQueryItemType_ActorBase
    {
    public:
    };
    // Size: 0x000030 (0x000000)
    class UEnvQueryItemType_ActorBase : public UEnvQueryItemType_VectorBase
    {
    public:
    };
    // Size: 0x000030 (0x000000)
    class UEnvQueryItemType_Direction : public UEnvQueryItemType_VectorBase
    {
    public:
    };
    // Size: 0x000030 (0x000000)
    class UEnvQueryItemType_OrientedPoint : public UEnvQueryItemType_Point
    {
    public:
    };
    // Size: 0x000030 (0x000000)
    class UEnvQueryItemType_Point : public UEnvQueryItemType_VectorBase
    {
    public:
    };
    // Size: 0x000030 (0x000000)
    class UEnvQueryItemType_VectorBase : public UEnvQueryItemType
    {
    public:
    };
    // Size: 0x0000D8 (0x0000A0)
    class alignas(0x8) UEnvQueryManager : public UAISubsystem
    {
    public:
        void**                                      VTable_000038;                      // 0x000038 (0x000008) VTable [5 slots] -> 0x132C2530
        uint8                                       UnknownData_000040[0x000028];       // 0x000040 (0x000028)
        TArray<FEnvQueryInstanceCache>              InstanceCache;                      // 0x000068 (0x000010)
        TArray<UEnvQueryContext*>                   LocalContexts;                      // 0x000078 (0x000010)
        TArray<UEnvQueryInstanceBlueprintWrapper*>  GCShieldedWrappers;                 // 0x000088 (0x000010)
        uint8                                       UnknownData_000098[0x000014];       // 0x000098 (0x000014)
        float                                       MaxAllowedTestingTime;              // 0x0000AC (0x000004) [Default: 0.003f]
        bool                                        bTestQueriesUsingBreadth;           // 0x0000B0 (0x000001) [Default: false]
        uint8                                       UnknownData_0000B1[0x000003];       // 0x0000B1 (0x000003)
        int32                                       QueryCountWarningThreshold;         // 0x0000B4 (0x000004) [Default: 200]
        double                                      QueryCountWarningInterval;          // 0x0000B8 (0x000008) [Default: 60]
        double                                      ExecutionTimeWarningSeconds;        // 0x0000C0 (0x000008) [Default: 0.025]
        double                                      HandlingResultTimeWarningSeconds;   // 0x0000C8 (0x000008) [Default: 0.025]
        double                                      GenerationTimeWarningSeconds;       // 0x0000D0 (0x000008) [Default: 0.01]
    
    public: // Functions
        static UEnvQueryInstanceBlueprintWrapper*  RunEQSQuery(UObject* WorldContextObject, UEnvQuery* QueryTemplate, UObject* Querier, TEnumAsByte<EEnvQueryRunMode> RunMode, UClass* WrapperClass); // 0x0502FB52 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000030 (0x000008)
    class alignas(0x4) UEnvQueryNode : public UObject
    {
    public:
        int32   VerNum;                         // 0x000028 (0x000004) [Default: 0]
        uint8   UnknownData_00002C[0x000004];   // 0x00002C (0x000004)
    };
    // Size: 0x000040 (0x000018)
    class alignas(0x8) UEnvQueryOption : public UObject
    {
    public:
        UEnvQueryGenerator*     Generator;  // 0x000028 (0x000008) [Default: nullptr]
        TArray<UEnvQueryTest*>  Tests;      // 0x000030 (0x000010)
    };
    // Size: 0x0001F8 (0x0001C8)
    class alignas(0x8) UEnvQueryTest : public UEnvQueryNode
    {
    public:
        int32                               TestOrder;                      // 0x000030 (0x000004) [Default: 0]
        TEnumAsByte<EEnvTestPurpose>        TestPurpose;                    // 0x000034 (0x000001) [Default: 2]
        uint8                               UnknownData_000035[0x000003];   // 0x000035 (0x000003)
        FString                             TestComment;                    // 0x000038 (0x000010) [Default: L""]
        TEnumAsByte<EEnvTestFilterOperator> MultipleContextFilterOp;        // 0x000048 (0x000001) [Default: 0]
        TEnumAsByte<EEnvTestScoreOperator>  MultipleContextScoreOp;         // 0x000049 (0x000001) [Default: 0]
        TEnumAsByte<EEnvTestFilterType>     FilterType;                     // 0x00004A (0x000001) [Default: 2]
        uint8                               UnknownData_00004B[0x000005];   // 0x00004B (0x000005)
        FAIDataProviderBoolValue            BoolValue;                      // 0x000050 (0x000038)
        FAIDataProviderFloatValue           FloatValueMin;                  // 0x000088 (0x000038)
        FAIDataProviderFloatValue           FloatValueMax;                  // 0x0000C0 (0x000038)
        uint8                               UnknownByte_0000F8;             // 0x0000F8 (0x000001)
        TEnumAsByte<EEnvTestScoreEquation>  ScoringEquation;                // 0x0000F9 (0x000001) [Default: 0]
        TEnumAsByte<EEnvQueryTestClamping>  ClampMinType;                   // 0x0000FA (0x000001) [Default: 0]
        TEnumAsByte<EEnvQueryTestClamping>  ClampMaxType;                   // 0x0000FB (0x000001) [Default: 0]
        EEQSNormalizationType               NormalizationType;              // 0x0000FC (0x000001) [Default: EEQSNormalizationType(0)]
        uint8                               UnknownData_0000FD[0x000003];   // 0x0000FD (0x000003)
        FAIDataProviderFloatValue           ScoreClampMin;                  // 0x000100 (0x000038)
        FAIDataProviderFloatValue           ScoreClampMax;                  // 0x000138 (0x000038)
        FAIDataProviderFloatValue           ScoringFactor;                  // 0x000170 (0x000038)
        FAIDataProviderFloatValue           ReferenceValue;                 // 0x0001A8 (0x000038)
        bool                                bDefineReferenceValue;          // 0x0001E0 (0x000001) [Default: false]
        uint8                               UnknownData_0001E1[0x00000F];   // 0x0001E1 (0x00000F)
        uint8                               bWorkOnFloatValues : 1;         // 0x0001F0 (0x000001) : 0x0 [Default: true]
        uint8                               UnknownBit_0001F0_1 : 1;        // 0x0001F0 (0x000001) : 0x1
        uint8                               UnknownBit_0001F0_2 : 1;        // 0x0001F0 (0x000001) : 0x2
        uint8                               UnknownBit_0001F0_3 : 1;        // 0x0001F0 (0x000001) : 0x3
        uint8                               UnknownBit_0001F0_4 : 1;        // 0x0001F0 (0x000001) : 0x4
        uint8                               UnknownBit_0001F0_5 : 1;        // 0x0001F0 (0x000001) : 0x5
        uint8                               UnknownBit_0001F0_6 : 1;        // 0x0001F0 (0x000001) : 0x6
        uint8                               UnknownBit_0001F0_7 : 1;        // 0x0001F0 (0x000001) : 0x7
        uint8                               UnknownData_0001F1[0x000007];   // 0x0001F1 (0x000007)
    };
    // Size: 0x000208 (0x000010)
    class alignas(0x8) UEnvQueryTest_Distance : public UEnvQueryTest
    {
    public:
        TEnumAsByte<EEnvTestDistance>   TestMode;                       // 0x0001F8 (0x000001) [Default: 0]
        uint8                           UnknownData_0001F9[0x000007];   // 0x0001F9 (0x000007)
        UClass*                         DistanceTo;                     // 0x000200 (0x000008) [Default: 0x17323C20]
    };
    // Size: 0x000240 (0x000048)
    class alignas(0x8) UEnvQueryTest_Dot : public UEnvQueryTest
    {
    public:
        FEnvDirection   LineA;                          // 0x0001F8 (0x000020)
        FEnvDirection   LineB;                          // 0x000218 (0x000020)
        EEnvTestDot     TestMode;                       // 0x000238 (0x000001) [Default: EEnvTestDot(0)]
        bool            bAbsoluteValue;                 // 0x000239 (0x000001) [Default: false]
        uint8           UnknownData_00023A[0x000006];   // 0x00023A (0x000006)
    };
    // Size: 0x000268 (0x000070)
    class alignas(0x8) UEnvQueryTest_GameplayTags : public UEnvQueryTest
    {
    public:
        FGameplayTagQuery           TagQueryToMatch;                // 0x0001F8 (0x000048)
        bool                        bSearchComponentsForTags;       // 0x000240 (0x000001) [Default: false]
        bool                        bRejectIncompatibleItems;       // 0x000241 (0x000001) [Default: false]
        bool                        bUpdatedToUseQuery;             // 0x000242 (0x000001) [Default: false]
        EGameplayContainerMatchType TagsToMatch;                    // 0x000243 (0x000001) [Default: EGameplayContainerMatchType(0)]
        uint8                       UnknownData_000244[0x000004];   // 0x000244 (0x000004)
        FGameplayTagContainer       GameplayTags;                   // 0x000248 (0x000020)
    };
    // Size: 0x000228 (0x000030)
    class alignas(0x8) UEnvQueryTest_Overlap : public UEnvQueryTest
    {
    public:
        FEnvOverlapData OverlapData;    // 0x0001F8 (0x000030)
    };
    // Size: 0x000288 (0x000090)
    class alignas(0x8) UEnvQueryTest_Pathfinding : public UEnvQueryTest
    {
    public:
        TEnumAsByte<EEnvTestPathfinding>    TestMode;                       // 0x0001F8 (0x000001) [Default: 0]
        uint8                               UnknownData_0001F9[0x000007];   // 0x0001F9 (0x000007)
        UClass*                             Context;                        // 0x000200 (0x000008) [Default: 0x17323C20]
        FAIDataProviderBoolValue            PathFromContext;                // 0x000208 (0x000038)
        FAIDataProviderBoolValue            SkipUnreachable;                // 0x000240 (0x000038)
        UClass*                             FilterClass;                    // 0x000278 (0x000008) [Default: nullptr]
        UClass*                             NavDataOverrideContext;         // 0x000280 (0x000008) [Default: nullptr]
    };
    // Size: 0x0002C0 (0x000038)
    class alignas(0x8) UEnvQueryTest_PathfindingBatch : public UEnvQueryTest_Pathfinding
    {
    public:
        FAIDataProviderFloatValue   ScanRangeMultiplier;    // 0x000288 (0x000038)
    };
    // Size: 0x000230 (0x000038)
    class alignas(0x8) UEnvQueryTest_Project : public UEnvQueryTest
    {
    public:
        FEnvTraceData   ProjectionData; // 0x0001F8 (0x000038)
    };
    // Size: 0x0001F8 (0x000000)
    class UEnvQueryTest_Random : public UEnvQueryTest
    {
    public:
    };
    // Size: 0x0002E0 (0x0000E8)
    class alignas(0x8) UEnvQueryTest_Trace : public UEnvQueryTest
    {
    public:
        FEnvTraceData               TraceData;              // 0x0001F8 (0x000038)
        FAIDataProviderBoolValue    TraceFromContext;       // 0x000230 (0x000038)
        FAIDataProviderFloatValue   ItemHeightOffset;       // 0x000268 (0x000038)
        FAIDataProviderFloatValue   ContextHeightOffset;    // 0x0002A0 (0x000038)
        UClass*                     Context;                // 0x0002D8 (0x000008) [Default: 0x17323C20]
    };
    // Size: 0x000210 (0x000018)
    class alignas(0x8) UEnvQueryTest_Volume : public UEnvQueryTest
    {
    public:
        UClass* VolumeContext;                  // 0x0001F8 (0x000008) [Default: nullptr]
        UClass* VolumeClass;                    // 0x000200 (0x000008) [Default: nullptr]
        uint8   bDoComplexVolumeTest : 1;       // 0x000208 (0x000001) : 0x0 [Default: false]
        uint8   bSkipTestIfNoVolumes : 1;       // 0x000208 (0x000001) : 0x0 [Default: false]
        uint8   UnknownBit_000208_1 : 1;        // 0x000208 (0x000001) : 0x1
        uint8   UnknownBit_000208_2 : 1;        // 0x000208 (0x000001) : 0x2
        uint8   UnknownBit_000208_3 : 1;        // 0x000208 (0x000001) : 0x3
        uint8   UnknownBit_000208_4 : 1;        // 0x000208 (0x000001) : 0x4
        uint8   UnknownBit_000208_5 : 1;        // 0x000208 (0x000001) : 0x5
        uint8   UnknownBit_000208_6 : 1;        // 0x000208 (0x000001) : 0x6
        uint8   UnknownBit_000208_7 : 1;        // 0x000208 (0x000001) : 0x7
        uint8   UnknownData_000209[0x000007];   // 0x000209 (0x000007)
    };
    // Size: 0x000028 (0x000000)
    class UEnvQueryTypes : public UObject
    {
    public:
    };
    // Size: 0x000050 (0x000010)
    class alignas(0x8) UGeneratedNavLinksProxy : public UBaseGeneratedNavLinksProxy
    {
    public:
        MULTI_INLINE_DELEGATE(LinkReachedSignature) OnSmartLinkReached; // 0x000040 (0x000010)
    
    public: // Functions
        void    ReceiveSmartLinkReached(AActor* Agent, FVector Destination); // 0x000545D2 [RequiredAPI | Event | Public | HasDefaults | BlueprintEvent]
    };
    // Size: 0x000028 (0x000000)
    class IGenericTeamAgentInterface : public IInterface
    {
    public:
    };
    // Size: 0x000340 (0x000030)
    class alignas(0x8) UGridPathFollowingComponent : public UPathFollowingComponent
    {
    public:
        UNavLocalGridManager*   GridManager;                    // 0x000310 (0x000008) [Default: nullptr]
        uint8                   UnknownData_000318[0x000028];   // 0x000318 (0x000028)
    };
    // Size: 0x000048 (0x000000)
    class UNavFilter_AIControllerDefault : public UNavigationQueryFilter
    {
    public:
    };
    // Size: 0x000058 (0x000030)
    class UNavLocalGridManager : public UObject
    {
    public:
        uint8   UnknownData_000028[0x000030];   // 0x000028 (0x000030)
    
    public: // Functions
        static int32   AddLocalNavigationGridForBox(UObject* WorldContextObject, FVector& Location, FVector Extent, FRotator Rotation, int32 Radius2D, float Height, bool bRebuildGrids); // 0x0504BE24 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static int32   AddLocalNavigationGridForCapsule(UObject* WorldContextObject, FVector& Location, float CapsuleRadius, float CapsuleHalfHeight, int32 Radius2D, float Height, bool bRebuildGrids); // 0x0504C584 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static int32   AddLocalNavigationGridForPoint(UObject* WorldContextObject, FVector& Location, int32 Radius2D, float Height, bool bRebuildGrids); // 0x0504CC72 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static int32   AddLocalNavigationGridForPoints(UObject* WorldContextObject, TArray<FVector>& Locations, int32 Radius2D, float Height, bool bRebuildGrids); // 0x0504D190 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static bool    FindLocalNavigationGridPath(UObject* WorldContextObject, FVector& Start, FVector& End, TArray<FVector>& PathPoints); // 0x0504D6C4 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static void    RemoveLocalNavigationGrid(UObject* WorldContextObject, int32 GridId, bool bRebuildGrids); // 0x0504DB60 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static bool    SetLocalNavigationGridDensity(UObject* WorldContextObject, float CellSize); // 0x0504DF00 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000310 (0x000250)
    class alignas(0x8) UPathFollowingComponent : public UActorComponent
    {
    public:
        void**                  VTable_0000C0;                  // 0x0000C0 (0x000008) VTable [13 slots] -> 0x132CEF60
        void**                  VTable_0000C8;                  // 0x0000C8 (0x000008) VTable [7 slots] -> 0x132CEF90
        uint8                   UnknownData_0000D0[0x000028];   // 0x0000D0 (0x000028)
        UNavMovementComponent*  MovementComp;                   // 0x0000F8 (0x000008) [Default: nullptr]
        uint8                   UnknownData_000100[0x000020];   // 0x000100 (0x000020)
        ANavigationData*        MyNavData;                      // 0x000120 (0x000008) [Default: nullptr]
        uint8                   UnknownData_000128[0x0001E8];   // 0x000128 (0x0001E8)
    
    public: // Functions
        TEnumAsByte<EPathFollowingAction>   GetPathActionType(); // 0x0DB99FA6 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FVector                             GetPathDestination(); // 0x0DB9A024 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        void                                OnActorBump(AActor* SelfActor, AActor* OtherActor, FVector NormalImpulse, FHitResult& Hit); // 0x0504E9F2 [RequiredAPI | Native | Public | HasOutParms | HasDefaults]
        void                                OnNavDataRegistered(ANavigationData* NavData); // 0x0504EF1A [Final | RequiredAPI | Native | Protected]
    };
    // Size: 0x000028 (0x000000)
    class UPathFollowingManager : public UObject
    {
    public:
    };
    // Size: 0x000108 (0x000048)
    class alignas(0x8) UPawnSensingComponent : public UActorComponent
    {
    public:
        float                                       HearingThreshold;               // 0x0000C0 (0x000004) [Default: 1400f]
        float                                       LOSHearingThreshold;            // 0x0000C4 (0x000004) [Default: 2800f]
        float                                       SightRadius;                    // 0x0000C8 (0x000004) [Default: 5000f]
        float                                       SensingInterval;                // 0x0000CC (0x000004) [Default: 0.5f]
        float                                       HearingMaxSoundAge;             // 0x0000D0 (0x000004) [Default: 1f]
        uint8                                       bEnableSensingUpdates : 1;      // 0x0000D4 (0x000001) : 0x0 [Default: true]
        uint8                                       bOnlySensePlayers : 1;          // 0x0000D4 (0x000001) : 0x0 [Default: true]
        uint8                                       bSeePawns : 1;                  // 0x0000D4 (0x000001) : 0x0 [Default: true]
        uint8                                       bHearNoises : 1;                // 0x0000D4 (0x000001) : 0x0 [Default: true]
        uint8                                       UnknownBit_0000D4_1 : 1;        // 0x0000D4 (0x000001) : 0x1
        uint8                                       UnknownBit_0000D4_2 : 1;        // 0x0000D4 (0x000001) : 0x2
        uint8                                       UnknownBit_0000D4_3 : 1;        // 0x0000D4 (0x000001) : 0x3
        uint8                                       UnknownBit_0000D4_4 : 1;        // 0x0000D4 (0x000001) : 0x4
        uint8                                       UnknownBit_0000D4_5 : 1;        // 0x0000D4 (0x000001) : 0x5
        uint8                                       UnknownBit_0000D4_6 : 1;        // 0x0000D4 (0x000001) : 0x6
        uint8                                       UnknownBit_0000D4_7 : 1;        // 0x0000D4 (0x000001) : 0x7
        uint8                                       UnknownData_0000D5[0x00000B];   // 0x0000D5 (0x00000B)
        MULTI_INLINE_DELEGATE(SeePawnDelegate)      OnSeePawn;                      // 0x0000E0 (0x000010)
        MULTI_INLINE_DELEGATE(HearNoiseDelegate)    OnHearNoise;                    // 0x0000F0 (0x000010)
        float                                       PeripheralVisionAngle;          // 0x000100 (0x000004) [Default: 90f]
        float                                       PeripheralVisionCosine;         // 0x000104 (0x000004) [Default: -4.37114e-08f]
    
    public: // Functions
        float   GetPeripheralVisionAngle(); // 0x0DBA8D62 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float   GetPeripheralVisionCosine(); // 0x0DBA8D80 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    SetPeripheralVisionAngle(float NewPeripheralVisionAngle); // 0x050582FC [RequiredAPI | BlueprintAuthorityOnly | Native | Public | BlueprintCallable]
        void    SetSensingInterval(float NewSensingInterval); // 0x05058472 [RequiredAPI | BlueprintAuthorityOnly | Native | Public | BlueprintCallable]
        void    SetSensingUpdatesEnabled(bool bEnabled); // 0x050585E8 [RequiredAPI | BlueprintAuthorityOnly | Native | Public | BlueprintCallable]
        void    HearNoiseDelegate(APawn* Instigator, FVector& Location, float Volume); // 0x000545D2 [MulticastDelegate | Public | Delegate | HasOutParms | HasDefaults]
        void    SeePawnDelegate(APawn* Pawn); // 0x000545D2 [MulticastDelegate | Public | Delegate]
    };
    // Size: 0x000028 (0x000000)
    class UValueOrBBKeyBlueprintUtility : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static bool                GetBool(FValueOrBBKey_Bool& Value, UBehaviorTreeComponent* BehaviorTreeComp); // 0x0502647C [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static UClass*             GetClass(FValueOrBBKey_Class& Value, UBehaviorTreeComponent* BehaviorTreeComp); // 0x0502674C [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static uint8               GetEnum(FValueOrBBKey_Enum& Value, UBehaviorTreeComponent* BehaviorTreeComp); // 0x05026A08 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static float               GetFloat(FValueOrBBKey_Float& Value, UBehaviorTreeComponent* BehaviorTreeComp); // 0x05026D00 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static int32               GetInt32(FValueOrBBKey_Int32& Value, UBehaviorTreeComponent* BehaviorTreeComp); // 0x05026FD2 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FName               GetName(FValueOrBBKey_Name& Value, UBehaviorTreeComponent* BehaviorTreeComp); // 0x050272A0 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static UObject*            GetObject(FValueOrBBKey_Object& Value, UBehaviorTreeComponent* BehaviorTreeComp); // 0x050275A4 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FRotator            GetRotator(FValueOrBBKey_Rotator& Value, UBehaviorTreeComponent* BehaviorTreeComp); // 0x05027860 [Final | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        static FString             GetString(FValueOrBBKey_String& Value, UBehaviorTreeComponent* BehaviorTreeComp); // 0x05027B28 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FInstancedStruct    GetStruct(FValueOrBBKey_Struct& Value, UBehaviorTreeComponent* BehaviorTreeComp); // 0x05027E30 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FVector             GetVector(FValueOrBBKey_Vector& Value, UBehaviorTreeComponent* BehaviorTreeComp); // 0x0502823C [Final | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
    };
    // Size: 0x000028 (0x000000)
    class UVisualLoggerExtension : public UObject
    {
    public:
    };
    // Size: 0x000050 (0x000050)
    struct alignas(0x8) FAIDamageEvent
    {
        float   Amount;                         // 0x000000 (0x000004) [Default: 5.82081e-25f]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FVector Location;                       // 0x000008 (0x000018)
        FVector HitLocation;                    // 0x000020 (0x000018)
        AActor* DamagedActor;                   // 0x000038 (0x000008) [Default: nullptr]
        AActor* Instigator;                     // 0x000040 (0x000008) [Default: 0xD43C5D5E00000000]
        FName   Tag;                            // 0x000048 (0x000004) [Default: NAME_None]
        uint8   UnknownData_00004C[0x000004];   // 0x00004C (0x000004)
    };
    // Size: 0x000038 (0x000008)
    struct FAIDataProviderBoolValue : public FAIDataProviderTypedValue
    {
        bool    DefaultValue;                   // 0x000030 (0x000001) [Default: true]
        uint8   UnknownData_000031[0x000007];   // 0x000031 (0x000007)
    };
    // Size: 0x000038 (0x000008)
    struct alignas(0x4) FAIDataProviderFloatValue : public FAIDataProviderTypedValue
    {
        float   DefaultValue;                   // 0x000030 (0x000004) [Default: 8.2537e-05f]
        uint8   UnknownData_000034[0x000004];   // 0x000034 (0x000004)
    };
    // Size: 0x000038 (0x000008)
    struct alignas(0x4) FAIDataProviderIntValue : public FAIDataProviderTypedValue
    {
        int32   DefaultValue;                   // 0x000030 (0x000004) [Default: 389168608]
        uint8   UnknownData_000034[0x000004];   // 0x000034 (0x000004)
    };
    // Size: 0x000030 (0x000010)
    struct alignas(0x8) FAIDataProviderStructValue : public FAIDataProviderValue
    {
        uint8   UnknownData_000020[0x000008];   // 0x000020 (0x000008)
        void**  VTable_000028;                  // 0x000028 (0x000008) VTable [393 slots] -> 0x12DCFE60
    };
    // Size: 0x000030 (0x000010)
    struct alignas(0x8) FAIDataProviderTypedValue : public FAIDataProviderValue
    {
        UClass* PropertyType;                   // 0x000020 (0x000008) [Default: 0x1DBD0FB9]
        uint8   UnknownData_000028[0x000008];   // 0x000028 (0x000008)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FAIDataProviderValue
    {
        uint8               UnknownData_000000[0x000008];   // 0x000000 (0x000008)
        void**              VTable_000008;                  // 0x000008 (0x000008) VTable [56 slots] -> 0x1527E678
        UAIDataProvider*    DataBinding;                    // 0x000010 (0x000008) [Default: 0x16A41EC0]
        FName               DataField;                      // 0x000018 (0x000004) [Default: FName(389062384) -> L""]
        uint8               UnknownData_00001C[0x000004];   // 0x00001C (0x000004)
    };
    // Size: 0x000038 (0x000038)
    struct alignas(0x8) FAIDynamicParam
    {
        FName                   ParamName;                      // 0x000000 (0x000004)
        EAIParamType            ParamType;                      // 0x000004 (0x000001)
        uint8                   bAllowBBKey : 1;                // 0x000005 (0x000001) : 0x0
        uint8                   UnknownBit_000005_1 : 1;        // 0x000005 (0x000001) : 0x1
        uint8                   UnknownBit_000005_2 : 1;        // 0x000005 (0x000001) : 0x2
        uint8                   UnknownBit_000005_3 : 1;        // 0x000005 (0x000001) : 0x3
        uint8                   UnknownBit_000005_4 : 1;        // 0x000005 (0x000001) : 0x4
        uint8                   UnknownBit_000005_5 : 1;        // 0x000005 (0x000001) : 0x5
        uint8                   UnknownBit_000005_6 : 1;        // 0x000005 (0x000001) : 0x6
        uint8                   UnknownBit_000005_7 : 1;        // 0x000005 (0x000001) : 0x7
        uint8                   UnknownData_000006[0x000002];   // 0x000006 (0x000002)
        float                   Value;                          // 0x000008 (0x000004)
        uint8                   UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FBlackboardKeySelector  BBKey;                          // 0x000010 (0x000028)
    };
    // Size: 0x000050 (0x000050)
    struct alignas(0x8) FAIMoveRequest
    {
        TWeakObjectPtr<AActor>  GoalActor;                      // 0x000000 (0x000008) [Default: 0x16A23710]
        uint8                   UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        void**                  VTable_000010;                  // 0x000010 (0x000008) VTable [101 slots] -> 0x12DCF560
        uint8                   UnknownData_000018[0x000038];   // 0x000018 (0x000038)
    };
    // Size: 0x000038 (0x000038)
    struct alignas(0x8) FAINoiseEvent
    {
        uint8   UnknownData_000000[0x000008];   // 0x000000 (0x000008)
        FVector NoiseLocation;                  // 0x000008 (0x000018)
        float   Loudness;                       // 0x000020 (0x000004) [Default: 5.81022e-25f]
        float   MaxRange;                       // 0x000024 (0x000004) [Default: 0f]
        AActor* Instigator;                     // 0x000028 (0x000008) [Default: 0xCDB327B9]
        FName   Tag;                            // 0x000030 (0x000004) [Default: FName(389271664) -> L""]
        uint8   UnknownData_000034[0x000004];   // 0x000034 (0x000004)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FAIPredictionEvent
    {
        AActor* Requestor;                      // 0x000000 (0x000008) [Default: 0x173426D0]
        AActor* PredictedActor;                 // 0x000008 (0x000008) [Default: 0x12FB00B0]
        uint8   UnknownData_000010[0x000008];   // 0x000010 (0x000008)
    };
    // Size: 0x000004 (0x000004)
    struct alignas(0x4) FAIRequestID
    {
        uint32  RequestID;  // 0x000000 (0x000004)
    };
    // Size: 0x000004 (0x000004)
    struct FAISenseAffiliationFilter
    {
        uint8   bDetectEnemies : 1;             // 0x000000 (0x000001) : 0x0 [Default: true]
        uint8   bDetectNeutrals : 1;            // 0x000000 (0x000001) : 0x0 [Default: true]
        uint8   bDetectFriendlies : 1;          // 0x000000 (0x000001) : 0x0 [Default: true]
        uint8   UnknownBit_000000_1 : 1;        // 0x000000 (0x000001) : 0x1
        uint8   UnknownBit_000000_2 : 1;        // 0x000000 (0x000001) : 0x2
        uint8   UnknownBit_000000_3 : 1;        // 0x000000 (0x000001) : 0x3
        uint8   UnknownBit_000000_4 : 1;        // 0x000000 (0x000001) : 0x4
        uint8   UnknownBit_000000_5 : 1;        // 0x000000 (0x000001) : 0x5
        uint8   UnknownBit_000000_6 : 1;        // 0x000000 (0x000001) : 0x6
        uint8   UnknownBit_000000_7 : 1;        // 0x000000 (0x000001) : 0x7
        uint8   UnknownData_000001[0x000003];   // 0x000001 (0x000003)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FAISightEvent
    {
        uint8   UnknownData_000000[0x000008];   // 0x000000 (0x000008)
        AActor* SeenActor;                      // 0x000008 (0x000008) [Default: nullptr]
        AActor* Observer;                       // 0x000010 (0x000008) [Default: 0x1545E678]
    };
    // Size: 0x000050 (0x000050)
    struct alignas(0x8) FAIStimulus
    {
        float   Age;                            // 0x000000 (0x000004) [Default: 2.62073e-25f]
        float   ExpirationAge;                  // 0x000004 (0x000004) [Default: 0f]
        float   Strength;                       // 0x000008 (0x000004) [Default: 3.17765e-25f]
        uint8   UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FVector StimulusLocation;               // 0x000010 (0x000018)
        FVector ReceiverLocation;               // 0x000028 (0x000018)
        FName   Tag;                            // 0x000040 (0x000004) [Default: FName(389257153) -> L""]
        uint8   UnknownData_000044[0x000008];   // 0x000044 (0x000008)
        uint8   bSuccessfullySensed : 1;        // 0x00004C (0x000001) : 0x0 [Default: false]
        uint8   UnknownBit_00004C_1 : 1;        // 0x00004C (0x000001) : 0x1
        uint8   UnknownBit_00004C_2 : 1;        // 0x00004C (0x000001) : 0x2
        uint8   UnknownBit_00004C_3 : 1;        // 0x00004C (0x000001) : 0x3
        uint8   UnknownBit_00004C_4 : 1;        // 0x00004C (0x000001) : 0x4
        uint8   UnknownBit_00004C_5 : 1;        // 0x00004C (0x000001) : 0x5
        uint8   UnknownBit_00004C_6 : 1;        // 0x00004C (0x000001) : 0x6
        uint8   UnknownBit_00004C_7 : 1;        // 0x00004C (0x000001) : 0x7
        uint8   UnknownData_00004D[0x000003];   // 0x00004D (0x000003)
    };
    // Size: 0x000050 (0x000050)
    struct alignas(0x8) FAITeamStimulusEvent
    {
        uint8   UnknownData_000000[0x000010];   // 0x000000 (0x000010)
        void**  VTable_000010;                  // 0x000010 (0x000008) VTable [169 slots] -> 0x12DCF340
        uint8   UnknownData_000018[0x000028];   // 0x000018 (0x000028)
        AActor* Broadcaster;                    // 0x000040 (0x000008) [Default: nullptr]
        AActor* Enemy;                          // 0x000048 (0x000008) [Default: 0xD43C5D5E00000000]
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FAITouchEvent
    {
        uint8   UnknownData_000000[0x000008];   // 0x000000 (0x000008)
        void**  VTable_000008;                  // 0x000008 (0x000008) VTable [101 slots] -> 0x12DCF560
        uint8   UnknownData_000010[0x000008];   // 0x000010 (0x000008)
        AActor* TouchReceiver;                  // 0x000018 (0x000008) [Default: 0x16A286C0]
        AActor* OtherActor;                     // 0x000020 (0x000008) [Default: 0x17343AF0]
        uint8   UnknownData_000028[0x000008];   // 0x000028 (0x000008)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FActorPerceptionBlueprintInfo
    {
        AActor*             Target;                         // 0x000000 (0x000008) [Default: 0x17342AE0]
        TArray<FAIStimulus> LastSensedStimuli;              // 0x000008 (0x000010)
        uint8               bIsHostile : 1;                 // 0x000018 (0x000001) : 0x0 [Default: true]
        uint8               bIsFriendly : 1;                // 0x000018 (0x000001) : 0x0 [Default: true]
        uint8               UnknownBit_000018_1 : 1;        // 0x000018 (0x000001) : 0x1
        uint8               UnknownBit_000018_2 : 1;        // 0x000018 (0x000001) : 0x2
        uint8               UnknownBit_000018_3 : 1;        // 0x000018 (0x000001) : 0x3
        uint8               UnknownBit_000018_4 : 1;        // 0x000018 (0x000001) : 0x4
        uint8               UnknownBit_000018_5 : 1;        // 0x000018 (0x000001) : 0x5
        uint8               UnknownBit_000018_6 : 1;        // 0x000018 (0x000001) : 0x6
        uint8               UnknownBit_000018_7 : 1;        // 0x000018 (0x000001) : 0x7
        uint8               UnknownData_000019[0x000007];   // 0x000019 (0x000007)
    };
    // Size: 0x000060 (0x000060)
    struct alignas(0x8) FActorPerceptionUpdateInfo
    {
        int32                   TargetId;                       // 0x000000 (0x000004) [Default: 389295024]
        TWeakObjectPtr<AActor>  Target;                         // 0x000004 (0x000008) [Default: nullptr]
        uint8                   UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FAIStimulus             Stimulus;                       // 0x000010 (0x000050)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FBTCompositeChild
    {
        UBTCompositeNode*           ChildComposite; // 0x000000 (0x000008) [Default: 0x17324440]
        UBTTaskNode*                ChildTask;      // 0x000008 (0x000008) [Default: 0x12FAF340]
        TArray<UBTDecorator*>       Decorators;     // 0x000010 (0x000010)
        TArray<FBTDecoratorLogic>   DecoratorOps;   // 0x000020 (0x000010)
    };
    // Size: 0x000004 (0x000004)
    struct alignas(0x2) FBTDecoratorLogic
    {
        TEnumAsByte<EBTDecoratorLogic>  Operation;          // 0x000000 (0x000001) [Default: 0]
        uint8                           UnknownByte_000001; // 0x000001 (0x000001)
        uint16                          Number;             // 0x000002 (0x000002) [Default: 5938]
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FBehaviorTreeTemplateInfo
    {
        UBehaviorTree*      Asset;                          // 0x000000 (0x000008)
        UBTCompositeNode*   Template;                       // 0x000008 (0x000008)
        uint8               UnknownData_000010[0x000008];   // 0x000010 (0x000008)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FBlackboardEntry
    {
        FName               EntryName;                      // 0x000000 (0x000004)
        uint8               UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UBlackboardKeyType* KeyType;                        // 0x000008 (0x000008)
        uint8               bInstanceSynced : 1;            // 0x000010 (0x000001) : 0x0
        uint8               UnknownBit_000010_1 : 1;        // 0x000010 (0x000001) : 0x1
        uint8               UnknownBit_000010_2 : 1;        // 0x000010 (0x000001) : 0x2
        uint8               UnknownBit_000010_3 : 1;        // 0x000010 (0x000001) : 0x3
        uint8               UnknownBit_000010_4 : 1;        // 0x000010 (0x000001) : 0x4
        uint8               UnknownBit_000010_5 : 1;        // 0x000010 (0x000001) : 0x5
        uint8               UnknownBit_000010_6 : 1;        // 0x000010 (0x000001) : 0x6
        uint8               UnknownBit_000010_7 : 1;        // 0x000010 (0x000001) : 0x7
        uint8               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FBlackboardKeySelector
    {
        TArray<UBlackboardKeyType*> AllowedTypes;                   // 0x000000 (0x000010)
        FName                       SelectedKeyName;                // 0x000010 (0x000004) [Default: FName(389055360) -> L""]
        uint8                       UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        UClass*                     SelectedKeyType;                // 0x000018 (0x000008) [Default: 0x16A23710]
        int32                       SelectedKeyID;                  // 0x000020 (0x000004) [Default: 379772416]
        uint8                       bNoneIsAllowedValue : 1;        // 0x000024 (0x000001) : 0x0 [Default: false]
        uint8                       UnknownBit_000024_1 : 1;        // 0x000024 (0x000001) : 0x1
        uint8                       UnknownBit_000024_2 : 1;        // 0x000024 (0x000001) : 0x2
        uint8                       UnknownBit_000024_3 : 1;        // 0x000024 (0x000001) : 0x3
        uint8                       UnknownBit_000024_4 : 1;        // 0x000024 (0x000001) : 0x4
        uint8                       UnknownBit_000024_5 : 1;        // 0x000024 (0x000001) : 0x5
        uint8                       UnknownBit_000024_6 : 1;        // 0x000024 (0x000001) : 0x6
        uint8                       UnknownBit_000024_7 : 1;        // 0x000024 (0x000001) : 0x7
        uint8                       UnknownData_000025[0x000003];   // 0x000025 (0x000003)
    };
    // Size: 0x000004 (0x000004)
    struct FCompactIndexedHandleBase
    {
        uint8   UnknownData_000000[0x000004];   // 0x000000 (0x000004)
    };
    // Size: 0x000024 (0x000024)
    struct alignas(0x4) FCrowdAvoidanceConfig
    {
        float   VelocityBias;           // 0x000000 (0x000004) [Default: 5.82173e-25f]
        float   DesiredVelocityWeight;  // 0x000004 (0x000004) [Default: 0f]
        float   CurrentVelocityWeight;  // 0x000008 (0x000004) [Default: 1.58372e-27f]
        float   SideBiasWeight;         // 0x00000C (0x000004) [Default: 0f]
        float   ImpactTimeWeight;       // 0x000010 (0x000004) [Default: 2.65154e-25f]
        float   ImpactTimeRange;        // 0x000014 (0x000004) [Default: 0f]
        float   SideBiasThreshold;      // 0x000018 (0x000004) [Default: 5.8191e-25f]
        float   RightSideBias;          // 0x00001C (0x000004) [Default: 0f]
        uint8   CustomPatternIdx;       // 0x000020 (0x000001) [Default: 185]
        uint8   AdaptiveDivisions;      // 0x000021 (0x000001) [Default: 39]
        uint8   AdaptiveRings;          // 0x000022 (0x000001) [Default: 170]
        uint8   AdaptiveDepth;          // 0x000023 (0x000001) [Default: 38]
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FCrowdAvoidanceSamplingPattern
    {
        TArray<float>   Angles; // 0x000000 (0x000010)
        TArray<float>   Radii;  // 0x000010 (0x000010)
    };
    // Size: 0x000048 (0x000048)
    struct alignas(0x8) FEQSParametrizedQueryExecutionRequest
    {
        UEnvQuery*                      QueryTemplate;                  // 0x000000 (0x000008) [Default: 0x16A23710]
        TArray<FAIDynamicParam>         QueryConfig;                    // 0x000008 (0x000010)
        FBlackboardKeySelector          EQSQueryBlackboardKey;          // 0x000018 (0x000028)
        TEnumAsByte<EEnvQueryRunMode>   RunMode;                        // 0x000040 (0x000001) [Default: 185]
        uint8                           UnknownData_000041[0x000003];   // 0x000041 (0x000003)
        uint8                           bUseBBKeyForQueryTemplate : 1;  // 0x000044 (0x000001) : 0x0 [Default: false]
        uint8                           UnknownBit_000044_1 : 1;        // 0x000044 (0x000001) : 0x1
        uint8                           UnknownBit_000044_2 : 1;        // 0x000044 (0x000001) : 0x2
        uint8                           UnknownBit_000044_3 : 1;        // 0x000044 (0x000001) : 0x3
        uint8                           UnknownBit_000044_4 : 1;        // 0x000044 (0x000001) : 0x4
        uint8                           UnknownBit_000044_5 : 1;        // 0x000044 (0x000001) : 0x5
        uint8                           UnknownBit_000044_6 : 1;        // 0x000044 (0x000001) : 0x6
        uint8                           UnknownBit_000044_7 : 1;        // 0x000044 (0x000001) : 0x7
        uint8                           UnknownData_000045[0x000003];   // 0x000045 (0x000003)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FEnvDirection
    {
        UClass*                     LineFrom;                       // 0x000000 (0x000008) [Default: 0x17331EB0]
        UClass*                     LineTo;                         // 0x000008 (0x000008) [Default: 0x12FB0E30]
        UClass*                     Rotation;                       // 0x000010 (0x000008) [Default: 0x16A41D80]
        TEnumAsByte<EEnvDirection>  DirMode;                        // 0x000018 (0x000001) [Default: 1]
        uint8                       UnknownData_000019[0x000007];   // 0x000019 (0x000007)
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FEnvNamedValue
    {
        FName           ParamName;                      // 0x000000 (0x000004) [Default: FName(379729680) -> L""]
        EAIParamType    ParamType;                      // 0x000004 (0x000001) [Default: EAIParamType(0)]
        uint8           UnknownData_000005[0x000003];   // 0x000005 (0x000003)
        float           Value;                          // 0x000008 (0x000004) [Default: 3.17765e-25f]
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FEnvOverlapData
    {
        float                           ExtentX;                        // 0x000000 (0x000004) [Default: 5.78778e-25f]
        float                           ExtentY;                        // 0x000004 (0x000004) [Default: 0f]
        float                           ExtentZ;                        // 0x000008 (0x000004) [Default: 1.58372e-27f]
        uint8                           UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FVector                         ShapeOffset;                    // 0x000010 (0x000018)
        TEnumAsByte<ECollisionChannel>  OverlapChannel;                 // 0x000028 (0x000001) [Default: 176]
        TEnumAsByte<EEnvOverlapShape>   OverlapShape;                   // 0x000029 (0x000001) [Default: 153]
        uint8                           UnknownData_00002A[0x000002];   // 0x00002A (0x000002)
        uint8                           bOnlyBlockingHits : 1;          // 0x00002C (0x000001) : 0x0 [Default: false]
        uint8                           bOverlapComplex : 1;            // 0x00002C (0x000001) : 0x0 [Default: false]
        uint8                           bSkipOverlapQuerier : 1;        // 0x00002C (0x000001) : 0x0 [Default: false]
        uint8                           UnknownBit_00002C_1 : 1;        // 0x00002C (0x000001) : 0x1
        uint8                           UnknownBit_00002C_2 : 1;        // 0x00002C (0x000001) : 0x2
        uint8                           UnknownBit_00002C_3 : 1;        // 0x00002C (0x000001) : 0x3
        uint8                           UnknownBit_00002C_4 : 1;        // 0x00002C (0x000001) : 0x4
        uint8                           UnknownBit_00002C_5 : 1;        // 0x00002C (0x000001) : 0x5
        uint8                           UnknownBit_00002C_6 : 1;        // 0x00002C (0x000001) : 0x6
        uint8                           UnknownBit_00002C_7 : 1;        // 0x00002C (0x000001) : 0x7
        uint8                           UnknownData_00002D[0x000003];   // 0x00002D (0x000003)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FEnvQueryContextData
    {
        UClass* ValueType;                      // 0x000000 (0x000008) [Default: 0x17332530]
        uint8   UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        void**  VTable_000010;                  // 0x000010 (0x000008) VTable [180 slots] -> 0x12DD0AB0
        uint8   UnknownData_000018[0x000008];   // 0x000018 (0x000008)
    };
    // Size: 0x0000F0 (0x0000B0)
    struct alignas(0x8) FEnvQueryInstance : public FEnvQueryResult
    {
        uint8                                       UnknownData_000040[0x000018];   // 0x000040 (0x000018)
        UWorld*                                     World;                          // 0x000058 (0x000008) [Default: 0x549C877F3F5BD889]
        uint8                                       UnknownData_000060[0x000020];   // 0x000060 (0x000020)
        TArray<FEnvQueryInstanceContextCacheItem>   ContextCache;                   // 0x000080 (0x000010)
        TArray<FEnvQueryOptionInstance>             Options;                        // 0x000090 (0x000010)
        uint8                                       UnknownData_0000A0[0x000040];   // 0x0000A0 (0x000040)
        UEnvQueryItemType_VectorBase*               ItemTypeVectorCDO;              // 0x0000E0 (0x000008) [Default: 0x1]
        UEnvQueryItemType_ActorBase*                ItemTypeActorCDO;               // 0x0000E8 (0x000008) [Default: 0x173256D0]
    };
    // Size: 0x000100 (0x000100)
    struct alignas(0x8) FEnvQueryInstanceCache
    {
        UEnvQuery*          Template;                       // 0x000000 (0x000008) [Default: 0x173321F0]
        FEnvQueryInstance   Instance;                       // 0x000008 (0x0000F0)
        uint8               UnknownData_0000F8[0x000008];   // 0x0000F8 (0x000008)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FEnvQueryInstanceContextCacheItem
    {
        UClass*                 Class;          // 0x000000 (0x000008) [Default: 0x173322C0]
        FEnvQueryContextData    ContextData;    // 0x000008 (0x000020)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FEnvQueryManagerConfig
    {
        float   MaxAllowedTestingTime;              // 0x000000 (0x000004) [Default: 5.78829e-25f]
        bool    bTestQueriesUsingBreadth;           // 0x000004 (0x000001) [Default: false]
        uint8   UnknownData_000005[0x000003];       // 0x000005 (0x000003)
        int32   QueryCountWarningThreshold;         // 0x000008 (0x000004) [Default: 379729680]
        uint8   UnknownData_00000C[0x000004];       // 0x00000C (0x000004)
        double  QueryCountWarningInterval;          // 0x000010 (0x000008) [Default: 1.92303e-315]
        double  ExecutionTimeWarningSeconds;        // 0x000018 (0x000008) [Default: 1.57332e-315]
        double  HandlingResultTimeWarningSeconds;   // 0x000020 (0x000008) [Default: 1.87673e-315]
        double  GenerationTimeWarningSeconds;       // 0x000028 (0x000008) [Default: 1.92304e-315]
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FEnvQueryOptionInstance
    {
        UEnvQueryGenerator*     Generator;                      // 0x000000 (0x000008) [Default: 0x17332460]
        TArray<UEnvQueryTest*>  Tests;                          // 0x000008 (0x000010)
        uint8                   UnknownData_000018[0x000008];   // 0x000018 (0x000008)
        UClass*                 ItemType;                       // 0x000020 (0x000008) [Default: 0x173320F1]
        uint8                   UnknownData_000028[0x000008];   // 0x000028 (0x000008)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FEnvQueryRequest
    {
        UEnvQuery*  QueryTemplate;                  // 0x000000 (0x000008) [Default: 0x17332530]
        UObject*    Owner;                          // 0x000008 (0x000008) [Default: 0x12FB0E30]
        UWorld*     World;                          // 0x000010 (0x000008) [Default: 0x16A41D80]
        uint8       UnknownData_000018[0x000010];   // 0x000018 (0x000010)
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x8) FEnvQueryResult
    {
        uint8   UnknownData_000000[0x000008];   // 0x000000 (0x000008)
        void**  VTable_000008;                  // 0x000008 (0x000008) VTable [523 slots] -> 0x12DCFA50
        UClass* ItemType;                       // 0x000010 (0x000008) [Default: 0x16A41BE0]
        uint8   UnknownData_000018[0x000014];   // 0x000018 (0x000014)
        int32   OptionIndex;                    // 0x00002C (0x000004) [Default: 0]
        int32   QueryID;                        // 0x000030 (0x000004) [Default: -606374301]
        uint8   UnknownData_000034[0x00000C];   // 0x000034 (0x00000C)
    };
    // Size: 0x000038 (0x000038)
    struct alignas(0x8) FEnvTraceData
    {
        int32                           VersionNum;                     // 0x000000 (0x000004) [Default: 4259909]
        uint8                           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UClass*                         NavigationFilter;               // 0x000008 (0x000008) [Default: 0x6D006100720061]
        float                           ProjectDown;                    // 0x000010 (0x000004) [Default: 1.11122e-38f]
        float                           ProjectUp;                      // 0x000014 (0x000004) [Default: 9.27554e-39f]
        float                           ExtentX;                        // 0x000018 (0x000004) [Default: 0f]
        float                           ExtentY;                        // 0x00001C (0x000004) [Default: 0f]
        float                           ExtentZ;                        // 0x000020 (0x000004) [Default: -1.96166e+23f]
        float                           PostProjectionVerticalOffset;   // 0x000024 (0x000004) [Default: -8.42527e+32f]
        TEnumAsByte<ETraceTypeQuery>    TraceChannel;                   // 0x000028 (0x000001) [Default: 185]
        TEnumAsByte<ECollisionChannel>  SerializedChannel;              // 0x000029 (0x000001) [Default: 40]
        uint8                           UnknownData_00002A[0x000002];   // 0x00002A (0x000002)
        FName                           TraceProfileName;               // 0x00002C (0x000004) [Default: FName(-668587847) -> L"EAIRequestPriority::Reaction"]
        TEnumAsByte<EEnvTraceShape>     TraceShape;                     // 0x000030 (0x000001) [Default: 185]
        TEnumAsByte<EEnvQueryTrace>     TraceMode;                      // 0x000031 (0x000001) [Default: 40]
        uint8                           UnknownData_000032[0x000002];   // 0x000032 (0x000002)
        uint8                           bTraceComplex : 1;              // 0x000034 (0x000001) : 0x0 [Default: true]
        uint8                           bOnlyBlockingHits : 1;          // 0x000034 (0x000001) : 0x0 [Default: true]
        uint8                           bCanTraceOnNavMesh : 1;         // 0x000034 (0x000001) : 0x0 [Default: true]
        uint8                           bCanTraceOnGeometry : 1;        // 0x000034 (0x000001) : 0x0 [Default: true]
        uint8                           bCanDisableTrace : 1;           // 0x000034 (0x000001) : 0x0 [Default: true]
        uint8                           bCanProjectDown : 1;            // 0x000034 (0x000001) : 0x0 [Default: true]
        uint8                           UnknownBit_000034_1 : 1;        // 0x000034 (0x000001) : 0x1
        uint8                           UnknownBit_000034_2 : 1;        // 0x000034 (0x000001) : 0x2
        uint8                           UnknownBit_000034_3 : 1;        // 0x000034 (0x000001) : 0x3
        uint8                           UnknownBit_000034_4 : 1;        // 0x000034 (0x000001) : 0x4
        uint8                           UnknownBit_000034_5 : 1;        // 0x000034 (0x000001) : 0x5
        uint8                           UnknownBit_000034_6 : 1;        // 0x000034 (0x000001) : 0x6
        uint8                           UnknownBit_000034_7 : 1;        // 0x000034 (0x000001) : 0x7
        uint8                           UnknownData_000035[0x000003];   // 0x000035 (0x000003)
    };
    // Size: 0x000001 (0x000001)
    struct FGenericTeamId
    {
        uint8   TeamId; // 0x000000 (0x000001) [Default: 0]
    };
    // Size: 0x000008 (0x000004)
    struct FIndexedHandleBase : public FSimpleIndexedHandleBase
    {
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FIntervalCountdown
    {
        float   Interval;                       // 0x000000 (0x000004) [Default: 2.62073e-25f]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
    };
    // Size: 0x0000B8 (0x0000B8)
    struct alignas(0x8) FRecastGraphWrapper
    {
        ARecastNavMesh* RecastNavMeshActor;             // 0x000000 (0x000008) [Default: 0x53004900410045]
        uint8           UnknownData_000008[0x0000B0];   // 0x000008 (0x0000B0)
    };
    // Size: 0x000004 (0x000004)
    struct alignas(0x4) FSequentialIDBase
    {
        uint32  Value;  // 0x000000 (0x000004)
    };
    // Size: 0x000004 (0x000004)
    struct FSimpleIndexedHandleBase
    {
        uint8   UnknownData_000000[0x000004];   // 0x000000 (0x000004)
    };
    // Size: 0x000018 (0x000008)
    struct FValueOrBBKey_Bool : public FValueOrBlackboardKeyBase
    {
        bool    DefaultValue;                   // 0x000010 (0x000001) [Default: false]
        uint8   UnknownData_000011[0x000007];   // 0x000011 (0x000007)
    };
    // Size: 0x000020 (0x000010)
    struct alignas(0x8) FValueOrBBKey_Class : public FValueOrBlackboardKeyBase
    {
        UClass* DefaultValue;   // 0x000010 (0x000008) [Default: nullptr]
        UClass* BaseClass;      // 0x000018 (0x000008) [Default: 0x12FAFA50]
    };
    // Size: 0x000030 (0x000020)
    struct alignas(0x8) FValueOrBBKey_Enum : public FValueOrBlackboardKeyBase
    {
        uint8   DefaultValue;                   // 0x000010 (0x000001) [Default: 0]
        uint8   UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        UEnum*  EnumType;                       // 0x000018 (0x000008) [Default: 0x12FAFE60]
        FString NativeEnumTypeName;             // 0x000020 (0x000010) [Default: L""]
    };
    // Size: 0x000018 (0x000008)
    struct alignas(0x4) FValueOrBBKey_Float : public FValueOrBlackboardKeyBase
    {
        float   DefaultValue;                   // 0x000010 (0x000004) [Default: 0f]
        uint8   UnknownData_000014[0x000004];   // 0x000014 (0x000004)
    };
    // Size: 0x000018 (0x000008)
    struct alignas(0x4) FValueOrBBKey_Int32 : public FValueOrBlackboardKeyBase
    {
        int32   DefaultValue;                   // 0x000010 (0x000004) [Default: 0]
        uint8   UnknownData_000014[0x000004];   // 0x000014 (0x000004)
    };
    // Size: 0x000018 (0x000008)
    struct alignas(0x4) FValueOrBBKey_Name : public FValueOrBlackboardKeyBase
    {
        FName   DefaultValue;                   // 0x000010 (0x000004) [Default: NAME_None]
        uint8   UnknownData_000014[0x000004];   // 0x000014 (0x000004)
    };
    // Size: 0x000020 (0x000010)
    struct alignas(0x8) FValueOrBBKey_Object : public FValueOrBlackboardKeyBase
    {
        UObject*    DefaultValue;   // 0x000010 (0x000008) [Default: 0x1545E678]
        UClass*     BaseClass;      // 0x000018 (0x000008) [Default: 0x16A41EC0]
    };
    // Size: 0x000028 (0x000018)
    struct alignas(0x8) FValueOrBBKey_Rotator : public FValueOrBlackboardKeyBase
    {
        FRotator    DefaultValue;   // 0x000010 (0x000018)
    };
    // Size: 0x000020 (0x000010)
    struct alignas(0x8) FValueOrBBKey_String : public FValueOrBlackboardKeyBase
    {
        FString DefaultValue;   // 0x000010 (0x000010) [Default: L""]
    };
    // Size: 0x000020 (0x000010)
    struct alignas(0x8) FValueOrBBKey_Struct : public FValueOrBlackboardKeyBase
    {
        FInstancedStruct    DefaultValue;   // 0x000010 (0x000010)
    };
    // Size: 0x000028 (0x000018)
    struct alignas(0x8) FValueOrBBKey_Vector : public FValueOrBlackboardKeyBase
    {
        FVector DefaultValue;   // 0x000010 (0x000018)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x4) FValueOrBlackboardKeyBase
    {
        uint8   UnknownData_000000[0x000008];   // 0x000000 (0x000008)
        FName   Key;                            // 0x000008 (0x000004) [Default: FName(6357100) -> L""]
        uint8   UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
    };
}

