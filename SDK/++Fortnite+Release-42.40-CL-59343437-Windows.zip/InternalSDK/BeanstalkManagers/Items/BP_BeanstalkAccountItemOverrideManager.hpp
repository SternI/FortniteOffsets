/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:50
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeanstalkManagers/Items/BP_BeanstalkAccountItemOverrideManager
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000070 (0x000000)
    class UBP_BeanstalkAccountItemOverrideManager_C : public UBeanstalkAccountItemDefinitionOverrideManager
    {
    public:
    };
}

