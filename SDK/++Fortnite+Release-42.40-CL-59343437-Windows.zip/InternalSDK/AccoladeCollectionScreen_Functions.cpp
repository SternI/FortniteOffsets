/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AccoladeCollectionScreen_Functions
 * ============================================================
 */

#include "AccoladeCollectionScreen_Functions.hpp"

namespace UE
{

    void UPinnedAccoladeWidget::BP_PopulateAccoladeInfo(FText& Description, int32 Achieved, int32 Total)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AccoladeCollectionScreen.PinnedAccoladeWidget.BP_PopulateAccoladeInfo");
    
        UPinnedAccoladeWidget___BP_PopulateAccoladeInfo_Params Params{};
        Params.Description = Description;
        Params.Achieved = Achieved;
        Params.Total = Total;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Description = Params.Description;
    }

    void UQuestAccoladeDataSource::OnControllerComponentAttached(AFortPlayerController* OwnerController, UFortControllerComponent* AttachedComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AccoladeCollectionScreen.QuestAccoladeDataSource.OnControllerComponentAttached");
    
        UQuestAccoladeDataSource___OnControllerComponentAttached_Params Params{};
        Params.OwnerController = OwnerController;
        Params.AttachedComponent = AttachedComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

