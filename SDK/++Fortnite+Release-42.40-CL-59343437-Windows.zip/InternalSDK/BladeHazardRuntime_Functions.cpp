/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BladeHazardRuntime_Functions
 * ============================================================
 */

#include "BladeHazardRuntime_Functions.hpp"

namespace UE
{

    FVector AFortBladeHazard::GetForceDirectionForHit(FHitResult& Hit)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BladeHazardRuntime.FortBladeHazard.GetForceDirectionForHit");
    
        AFortBladeHazard___GetForceDirectionForHit_Params Params{};
        Params.Hit = Hit;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Hit = Params.Hit;
    
        return Params.ReturnValue;
    }

} // namespace UE

