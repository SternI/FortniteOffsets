/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:16
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AuroraCore/_Verse/VNI/AuroraCoreDeprecated_Functions
 * ============================================================
 */

#include "AuroraCoreDeprecated.hpp"

namespace UE
{

    struct U_Root____InitCDO_Params
    {
        UVerse_message* _ExprResultStack_0; // 0x000000 (0x000008) [Default: 0x12FBEC60]
        UVerse_message* _ExprResultStack_1; // 0x000008 (0x000008) [Default: 0x97F918DD00280031]
    };

    struct U_Root____L_2fFortnite_2ecom_2fMarketplace_N_Rentitlement__change_L_Nt_20where_20t_R_Params
    {
        UStruct*    __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000008) [Default: 0x12FBEC60]
        uint8       RetVal[0x000008];               // 0x000008 (0x000008)
    };

    struct U_Root____L_2fFortnite_2ecom_2fMarketplace_N_RGetEntitlementsChangedEvent_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R_Params
    {
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R   __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000010)
        UObject*                                                RetVal;                         // 0x000010 (0x000008) [ReturnValue] [Default: 0x7FE839890520]
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R   _ExprResult_0;                  // 0x000018 (0x000010)
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R   _ExprResult_1;                  // 0x000028 (0x000010)
    };

    struct U_Root____L_2fFortnite_2ecom_2fMarketplace_N_RRestrictDirectPromptsToPurchase_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_R_Params
    {
        USimulation_player*     __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000008) [Default: 0x12FBEC60]
        TOptional<EVerseTrue>   RetVal;                         // 0x000008 (0x000002) [ReturnValue]
        TOptional<EVerseTrue>   _ExprResultStack_0;             // 0x00000A (0x000002)
        TOptional<EVerseTrue>   _ExprResultStack_1;             // 0x00000C (0x000002)
    };

    struct U_Root____L_2fFortnite_2ecom_2fMarketplace_N_RRestrictPaidRandomItems_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_R_Params
    {
        USimulation_player*     __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000008) [Default: 0x12FBEC60]
        TOptional<EVerseTrue>   RetVal;                         // 0x000008 (0x000002) [ReturnValue]
        TOptional<EVerseTrue>   _ExprResultStack_0;             // 0x00000A (0x000002)
        TOptional<EVerseTrue>   _ExprResultStack_1;             // 0x00000C (0x000002)
    };

    struct U_Root___BuyOffer_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_R_Params
    {
        UConcurrency_task*      __verse_0xC1E81372_CallingTask;         // 0x000000 (0x000008) [Default: 0x12FBEC60]
        int64                   __verse_0xA3A00DDB_CallerResumeState;   // 0x000008 (0x000008) [Default: -7495932767312019407ll]
        int64                   __verse_0x2AC0E4D8_CallerCancelState;   // 0x000010 (0x000008) [Default: 140635374421280ll]
        Ftuple_Lplayer_Moffer_R __verse_0xB2CDDD72_Argument;            // 0x000018 (0x000010)
        UConcurrency_task*      RetVal;                                 // 0x000028 (0x000008) [ReturnValue] [Default: 0x7FE839892DA8]
    };

    struct U_Root___ConsumeEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R_Params
    {
        UConcurrency_task*                                                                      __verse_0xC1E81372_CallingTask;         // 0x000000 (0x000008) [Default: 0x12FBEC60]
        int64                                                                                   __verse_0xA3A00DDB_CallerResumeState;   // 0x000008 (0x000008) [Default: -7495932767312019407ll]
        int64                                                                                   __verse_0x2AC0E4D8_CallerCancelState;   // 0x000010 (0x000008) [Default: 140635374421280ll]
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_20_3d_20_2e_2e_2e_R   __verse_0xB2CDDD72_Argument;            // 0x000018 (0x000020)
        UConcurrency_task*                                                                      RetVal;                                 // 0x000038 (0x000008) [ReturnValue] [Default: 0x96F918DD002C0029]
    };

    struct U_Root___GetPurchasedEntitlements_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R_Params
    {
        UConcurrency_task*                                      __verse_0xC1E81372_CallingTask;         // 0x000000 (0x000008) [Default: 0x12FBEC60]
        int64                                                   __verse_0xA3A00DDB_CallerResumeState;   // 0x000008 (0x000008) [Default: -7495932767312019407ll]
        int64                                                   __verse_0x2AC0E4D8_CallerCancelState;   // 0x000010 (0x000008) [Default: 140635374421280ll]
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R   __verse_0xB2CDDD72_Argument;            // 0x000018 (0x000010)
        UConcurrency_task*                                      RetVal;                                 // 0x000028 (0x000008) [ReturnValue] [Default: 0x7FE839892DA8]
    };

    struct U_Root___GrantEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R_Params
    {
        UConcurrency_task*                                                                      __verse_0xC1E81372_CallingTask;         // 0x000000 (0x000008) [Default: 0x12FBEC60]
        int64                                                                                   __verse_0xA3A00DDB_CallerResumeState;   // 0x000008 (0x000008) [Default: -7495932767312019407ll]
        int64                                                                                   __verse_0x2AC0E4D8_CallerCancelState;   // 0x000010 (0x000008) [Default: 140635374421280ll]
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_20_3d_20_2e_2e_2e_R   __verse_0xB2CDDD72_Argument;            // 0x000018 (0x000020)
        UConcurrency_task*                                                                      RetVal;                                 // 0x000038 (0x000008) [ReturnValue] [Default: 0x96F918DD002C0029]
    };

    struct U_Root___ShowOffersDialog_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_K_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_M_N_QTitle_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_20_3d_20_2e_2e_2e_R_Params
    {
        UConcurrency_task*                                              __verse_0xC1E81372_CallingTask;         // 0x000000 (0x000008) [Default: 0x12FBEC60]
        int64                                                           __verse_0xA3A00DDB_CallerResumeState;   // 0x000008 (0x000008) [Default: -7495932767312019407ll]
        int64                                                           __verse_0x2AC0E4D8_CallerCancelState;   // 0x000010 (0x000008) [Default: 140635374421280ll]
        Ftuple_Lplayer_M_Koffer_M_QTitle_Nmessage_20_3d_20_2e_2e_2e_R   __verse_0xB2CDDD72_Argument;            // 0x000018 (0x000020)
        UConcurrency_task*                                              RetVal;                                 // 0x000038 (0x000008) [ReturnValue] [Default: 0x96F918DD002C0029]
    };

    struct Utask__Root_ShowOffersDialog_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_K_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_M_N_QTitle_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_20_3d_20_2e_2e_2e_R___Update_Params
    {
        int64   RetVal; // 0x000000 (0x000008) [ReturnValue] [Default: 324773760ll]
    };

    struct Utask__Root_BuyOffer_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_R___Update_Params
    {
        int64   RetVal; // 0x000000 (0x000008) [ReturnValue] [Default: 324773760ll]
    };

    struct Utask__Root_GrantEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R___Update_Params
    {
        int64   RetVal; // 0x000000 (0x000008) [ReturnValue] [Default: 324773760ll]
    };

    struct Utask__Root_ConsumeEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R___Update_Params
    {
        int64   RetVal; // 0x000000 (0x000008) [ReturnValue] [Default: 324773760ll]
    };

    struct Utask__Root_GetPurchasedEntitlements_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R___Update_Params
    {
        int64   RetVal; // 0x000000 (0x000008) [ReturnValue] [Default: 324773760ll]
    };

} // namespace UE

