/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:14
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AuroraCore/_Verse/VNI/AuroraCore_Functions
 * ============================================================
 */

#include "AuroraCore_Functions.hpp"

namespace UE
{

    int64 Utask__Root_GetPurchasedEntitlements_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R::Update()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.task__Root$GetPurchasedEntitlements_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R.Update");
    
        Utask__Root_GetPurchasedEntitlements_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R___Update_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    void Ubundle_offer::_Block()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.bundle_offer._Block");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Ubundle_offer::_InitCDO(TArray<Ftuple_Loffer_Mint_R> _ExprResult_0, TArray<EVerseFalse> __verse_0xFFC68BC5_Array_1, TArray<Ftuple_Loffer_Mint_R> _ForResult_1, int64 _ForIndex_2, int64 _ForLength_3, EVerseFalse __verse_0xFB88B569_Item_4, bool _ExprResult_4, TArray<Ftuple_Loffer_Mint_R> _ExprResult_5, TArray<EVerseFalse> __verse_0xFFC68BC5_Array_6, TArray<Ftuple_Loffer_Mint_R> _ForResult_6, int64 _ForIndex_7, int64 _ForLength_8, EVerseFalse __verse_0xFB88B569_Item_9, bool _ExprResult_9)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.bundle_offer._InitCDO");
    
        Ubundle_offer____InitCDO_Params Params{};
        Params._ExprResult_0 = _ExprResult_0;
        Params.__verse_0xFFC68BC5_Array_1 = __verse_0xFFC68BC5_Array_1;
        Params._ForResult_1 = _ForResult_1;
        Params._ForIndex_2 = _ForIndex_2;
        Params._ForLength_3 = _ForLength_3;
        Params.__verse_0xFB88B569_Item_4 = __verse_0xFB88B569_Item_4;
        Params._ExprResult_4 = _ExprResult_4;
        Params._ExprResult_5 = _ExprResult_5;
        Params.__verse_0xFFC68BC5_Array_6 = __verse_0xFFC68BC5_Array_6;
        Params._ForResult_6 = _ForResult_6;
        Params._ForIndex_7 = _ForIndex_7;
        Params._ForLength_8 = _ForLength_8;
        Params.__verse_0xFB88B569_Item_9 = __verse_0xFB88B569_Item_9;
        Params._ExprResult_9 = _ExprResult_9;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void Ubundle_offer::_InitInstance()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.bundle_offer._InitInstance");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Uentitlement::_Block()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.entitlement._Block");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Uentitlement::_InitCDO()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.entitlement._InitCDO");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Uentitlement::_InitInstance()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.entitlement._InitInstance");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Uentitlement_change::_Block()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.entitlement_change._Block");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Uentitlement_change::_InitCDO()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.entitlement_change._InitCDO");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Uentitlement_change::_InitInstance()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.entitlement_change._InitInstance");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Uprice_dimension::_Block()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.price_dimension._Block");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Uprice_dimension::_InitCDO()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.price_dimension._InitCDO");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Uprice_dimension::_InitInstance()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.price_dimension._InitInstance");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Uoffer::_Block()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.offer._Block");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Uoffer::_InitCDO()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.offer._InitCDO");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Uoffer::_InitInstance()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.offer._InitInstance");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    TOptional<int64> Uoffer::_L_2fUnrealEngine_2ecom_2fMarketplace_2foffer_N_RGetMinPurchaseAge_L_N_Kchar_M_N_Kchar_M_N_Kchar_R(Ftuple_L_Kchar_M_Kchar_M_Kchar_R __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.offer._L_2fUnrealEngine_2ecom_2fMarketplace_2foffer_N_RGetMinPurchaseAge_L_N_Kchar_M_N_Kchar_M_N_Kchar_R");
    
        Uoffer____L_2fUnrealEngine_2ecom_2fMarketplace_2foffer_N_RGetMinPurchaseAge_L_N_Kchar_M_N_Kchar_M_N_Kchar_R_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    void Uentitlement_offer::_Block()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.entitlement_offer._Block");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Uentitlement_offer::_InitCDO()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.entitlement_offer._InitCDO");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Uentitlement_offer::_InitInstance()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.entitlement_offer._InitInstance");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    int64 Utask__Root_ShowOffersDialog_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_K_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_M_N_QTitle_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_20_3d_20_2e_2e_2e_R::Update()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.task__Root$ShowOffersDialog_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_K_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_M_N_QTitle_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_20_3d_20_2e_2e_2e_R.Update");
    
        Utask__Root_ShowOffersDialog_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_K_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_M_N_QTitle_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_20_3d_20_2e_2e_2e_R___Update_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    int64 Utask__Root_BuyOffer_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_R::Update()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.task__Root$BuyOffer_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_R.Update");
    
        Utask__Root_BuyOffer_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_R___Update_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    int64 Utask__Root_GrantEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R::Update()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.task__Root$GrantEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R.Update");
    
        Utask__Root_GrantEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R___Update_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    int64 Utask__Root_ConsumeEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R::Update()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore.task__Root$ConsumeEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R.Update");
    
        Utask__Root_ConsumeEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R___Update_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    void U_Root::_InitCDO(UVerse_message* _ExprResultStack_0, UVerse_message* _ExprResultStack_1)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore._Root._InitCDO");
    
        U_Root____InitCDO_Params Params{};
        Params._ExprResultStack_0 = _ExprResultStack_0;
        Params._ExprResultStack_1 = _ExprResultStack_1;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void U_Root::_L_2fUnrealEngine_2ecom_2fMarketplace_N_Rentitlement__change_L_Nt_20where_20t_R(UStruct* __verse_0xB2CDDD72_Argument, uint8 RetVal[0x000008])
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore._Root._L_2fUnrealEngine_2ecom_2fMarketplace_N_Rentitlement__change_L_Nt_20where_20t_R");
    
        U_Root____L_2fUnrealEngine_2ecom_2fMarketplace_N_Rentitlement__change_L_Nt_20where_20t_R_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
        Params.RetVal[0x000008] = RetVal[0x000008];
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UObject* U_Root::_L_2fUnrealEngine_2ecom_2fMarketplace_N_RGetEntitlementsChangedEvent_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R(Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore._Root._L_2fUnrealEngine_2ecom_2fMarketplace_N_RGetEntitlementsChangedEvent_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R");
    
        U_Root____L_2fUnrealEngine_2ecom_2fMarketplace_N_RGetEntitlementsChangedEvent_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    TOptional<EVerseTrue> U_Root::_L_2fUnrealEngine_2ecom_2fMarketplace_N_RRestrictDirectPromptsToPurchase_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_R(USimulation_player* __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore._Root._L_2fUnrealEngine_2ecom_2fMarketplace_N_RRestrictDirectPromptsToPurchase_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_R");
    
        U_Root____L_2fUnrealEngine_2ecom_2fMarketplace_N_RRestrictDirectPromptsToPurchase_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_R_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    TOptional<EVerseTrue> U_Root::_L_2fUnrealEngine_2ecom_2fMarketplace_N_RRestrictPaidRandomItems_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_R(USimulation_player* __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore._Root._L_2fUnrealEngine_2ecom_2fMarketplace_N_RRestrictPaidRandomItems_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_R");
    
        U_Root____L_2fUnrealEngine_2ecom_2fMarketplace_N_RRestrictPaidRandomItems_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_R_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    UConcurrency_task* U_Root::BuyOffer_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lplayer_Moffer_R __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore._Root.BuyOffer_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_R");
    
        U_Root___BuyOffer_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_R_Params Params{};
        Params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
        Params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
        Params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    UConcurrency_task* U_Root::ConsumeEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_20_3d_20_2e_2e_2e_R __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore._Root.ConsumeEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R");
    
        U_Root___ConsumeEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R_Params Params{};
        Params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
        Params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
        Params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    UConcurrency_task* U_Root::GetPurchasedEntitlements_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore._Root.GetPurchasedEntitlements_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R");
    
        U_Root___GetPurchasedEntitlements_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R_Params Params{};
        Params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
        Params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
        Params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    UConcurrency_task* U_Root::GrantEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_20_3d_20_2e_2e_2e_R __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore._Root.GrantEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R");
    
        U_Root___GrantEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R_Params Params{};
        Params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
        Params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
        Params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    UConcurrency_task* U_Root::ShowOffersDialog_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_K_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_M_N_QTitle_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_20_3d_20_2e_2e_2e_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lplayer_M_Koffer_M_QTitle_Nmessage_20_3d_20_2e_2e_2e_R __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraCore._Root.ShowOffersDialog_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_K_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_M_N_QTitle_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_20_3d_20_2e_2e_2e_R");
    
        U_Root___ShowOffersDialog_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_K_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_M_N_QTitle_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_20_3d_20_2e_2e_2e_R_Params Params{};
        Params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
        Params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
        Params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

} // namespace UE

