/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:14
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AuroraCore/_Verse/VNI/AuroraCore_Functions
 * ============================================================
 */

#include "AuroraCore.hpp"

namespace UE
{

    struct Utask__Root_GetPurchasedEntitlements_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R___Update_Params
    {
        int64   RetVal; // 0x000000 (0x000008) [ReturnValue] [Default: 324773760ll]
    };

    struct Ubundle_offer____InitCDO_Params
    {
        TArray<Ftuple_Loffer_Mint_R>    _ExprResult_0;                  // 0x000000 (0x000010)
        TArray<EVerseFalse>             __verse_0xFFC68BC5_Array_1;     // 0x000010 (0x000010)
        TArray<Ftuple_Loffer_Mint_R>    _ForResult_1;                   // 0x000020 (0x000010)
        int64                           _ForIndex_2;                    // 0x000030 (0x000008) [Default: 0ll]
        int64                           _ForLength_3;                   // 0x000038 (0x000008) [Default: 0ll]
        EVerseFalse                     __verse_0xFB88B569_Item_4;      // 0x000040 (0x000001) [Default: EVerseFalse(0)]
        bool                            _ExprResult_4;                  // 0x000041 (0x000001) [Default: false]
        uint8                           UnknownData_000042[0x000006];   // 0x000042 (0x000006)
        TArray<Ftuple_Loffer_Mint_R>    _ExprResult_5;                  // 0x000048 (0x000010)
        TArray<EVerseFalse>             __verse_0xFFC68BC5_Array_6;     // 0x000058 (0x000010)
        TArray<Ftuple_Loffer_Mint_R>    _ForResult_6;                   // 0x000068 (0x000010)
        int64                           _ForIndex_7;                    // 0x000078 (0x000008) [Default: 140635373193592ll]
        int64                           _ForLength_8;                   // 0x000080 (0x000008) [Default: 509001403ll]
        EVerseFalse                     __verse_0xFB88B569_Item_9;      // 0x000088 (0x000001) [Default: EVerseFalse(240)]
        bool                            _ExprResult_9;                  // 0x000089 (0x000001) [Default: true]
    };

    struct Uoffer____L_2fUnrealEngine_2ecom_2fMarketplace_2foffer_N_RGetMinPurchaseAge_L_N_Kchar_M_N_Kchar_M_N_Kchar_R_Params
    {
        Ftuple_L_Kchar_M_Kchar_M_Kchar_R    __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000030)
        TOptional<int64>                    RetVal;                         // 0x000030 (0x000010) [ReturnValue]
    };

    struct Utask__Root_ShowOffersDialog_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_K_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_M_N_QTitle_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_20_3d_20_2e_2e_2e_R___Update_Params
    {
        int64   RetVal; // 0x000000 (0x000008) [ReturnValue] [Default: 324773760ll]
    };

    struct Utask__Root_BuyOffer_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_R___Update_Params
    {
        int64   RetVal; // 0x000000 (0x000008) [ReturnValue] [Default: 324773760ll]
    };

    struct Utask__Root_GrantEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R___Update_Params
    {
        int64   RetVal; // 0x000000 (0x000008) [ReturnValue] [Default: 324773760ll]
    };

    struct Utask__Root_ConsumeEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R___Update_Params
    {
        int64   RetVal; // 0x000000 (0x000008) [ReturnValue] [Default: 324773760ll]
    };

    struct U_Root____InitCDO_Params
    {
        UVerse_message* _ExprResultStack_0; // 0x000000 (0x000008) [Default: 0x135C1260]
        UVerse_message* _ExprResultStack_1; // 0x000008 (0x000008) [Default: 0x2B0818DD00280031]
    };

    struct U_Root____L_2fUnrealEngine_2ecom_2fMarketplace_N_Rentitlement__change_L_Nt_20where_20t_R_Params
    {
        UStruct*    __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000008) [Default: 0x135C1260]
        uint8       RetVal[0x000008];               // 0x000008 (0x000008)
    };

    struct U_Root____L_2fUnrealEngine_2ecom_2fMarketplace_N_RGetEntitlementsChangedEvent_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R_Params
    {
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R   __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000010)
        UObject*                                                RetVal;                         // 0x000010 (0x000008) [ReturnValue] [Default: 0x7FE8397649C0]
    };

    struct U_Root____L_2fUnrealEngine_2ecom_2fMarketplace_N_RRestrictDirectPromptsToPurchase_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_R_Params
    {
        USimulation_player*     __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000008) [Default: 0x135C1260]
        TOptional<EVerseTrue>   RetVal;                         // 0x000008 (0x000002) [ReturnValue]
    };

    struct U_Root____L_2fUnrealEngine_2ecom_2fMarketplace_N_RRestrictPaidRandomItems_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_R_Params
    {
        USimulation_player*     __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000008) [Default: 0x135C1260]
        TOptional<EVerseTrue>   RetVal;                         // 0x000008 (0x000002) [ReturnValue]
    };

    struct U_Root___BuyOffer_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_R_Params
    {
        UConcurrency_task*      __verse_0xC1E81372_CallingTask;         // 0x000000 (0x000008) [Default: 0x135C1260]
        int64                   __verse_0xA3A00DDB_CallerResumeState;   // 0x000008 (0x000008) [Default: 3100755680914047025ll]
        int64                   __verse_0x2AC0E4D8_CallerCancelState;   // 0x000010 (0x000008) [Default: 140635373193664ll]
        Ftuple_Lplayer_Moffer_R __verse_0xB2CDDD72_Argument;            // 0x000018 (0x000010)
        UConcurrency_task*      RetVal;                                 // 0x000028 (0x000008) [ReturnValue] [Default: 0x7FE839769AA8]
    };

    struct U_Root___ConsumeEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R_Params
    {
        UConcurrency_task*                                                                      __verse_0xC1E81372_CallingTask;         // 0x000000 (0x000008) [Default: 0x135C1260]
        int64                                                                                   __verse_0xA3A00DDB_CallerResumeState;   // 0x000008 (0x000008) [Default: 3100755680914047025ll]
        int64                                                                                   __verse_0x2AC0E4D8_CallerCancelState;   // 0x000010 (0x000008) [Default: 140635373193664ll]
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_20_3d_20_2e_2e_2e_R   __verse_0xB2CDDD72_Argument;            // 0x000018 (0x000020)
        UConcurrency_task*                                                                      RetVal;                                 // 0x000038 (0x000008) [ReturnValue] [Default: 0x2A0818DD002C0029]
    };

    struct U_Root___GetPurchasedEntitlements_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R_Params
    {
        UConcurrency_task*                                      __verse_0xC1E81372_CallingTask;         // 0x000000 (0x000008) [Default: 0x135C1260]
        int64                                                   __verse_0xA3A00DDB_CallerResumeState;   // 0x000008 (0x000008) [Default: 3100755680914047025ll]
        int64                                                   __verse_0x2AC0E4D8_CallerCancelState;   // 0x000010 (0x000008) [Default: 140635373193664ll]
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R   __verse_0xB2CDDD72_Argument;            // 0x000018 (0x000010)
        UConcurrency_task*                                      RetVal;                                 // 0x000028 (0x000008) [ReturnValue] [Default: 0x7FE839769AA8]
    };

    struct U_Root___GrantEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R_Params
    {
        UConcurrency_task*                                                                      __verse_0xC1E81372_CallingTask;         // 0x000000 (0x000008) [Default: 0x135C1260]
        int64                                                                                   __verse_0xA3A00DDB_CallerResumeState;   // 0x000008 (0x000008) [Default: 3100755680914047025ll]
        int64                                                                                   __verse_0x2AC0E4D8_CallerCancelState;   // 0x000010 (0x000008) [Default: 140635373193664ll]
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_20_3d_20_2e_2e_2e_R   __verse_0xB2CDDD72_Argument;            // 0x000018 (0x000020)
        UConcurrency_task*                                                                      RetVal;                                 // 0x000038 (0x000008) [ReturnValue] [Default: 0x2A0818DD002C0029]
    };

    struct U_Root___ShowOffersDialog_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_K_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_M_N_QTitle_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_20_3d_20_2e_2e_2e_R_Params
    {
        UConcurrency_task*                                              __verse_0xC1E81372_CallingTask;         // 0x000000 (0x000008) [Default: 0x135C1260]
        int64                                                           __verse_0xA3A00DDB_CallerResumeState;   // 0x000008 (0x000008) [Default: 3100755680914047025ll]
        int64                                                           __verse_0x2AC0E4D8_CallerCancelState;   // 0x000010 (0x000008) [Default: 140635373193664ll]
        Ftuple_Lplayer_M_Koffer_M_QTitle_Nmessage_20_3d_20_2e_2e_2e_R   __verse_0xB2CDDD72_Argument;            // 0x000018 (0x000020)
        UConcurrency_task*                                              RetVal;                                 // 0x000038 (0x000008) [ReturnValue] [Default: 0x2A0818DD002C0029]
    };

} // namespace UE

