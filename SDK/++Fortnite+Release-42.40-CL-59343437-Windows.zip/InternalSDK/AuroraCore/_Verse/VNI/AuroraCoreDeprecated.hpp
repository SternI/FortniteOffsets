/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:16
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AuroraCore/_Verse/VNI/AuroraCoreDeprecated
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000030 (0x000008)
    class alignas(0x8) U_Root : public UObject
    {
    public:
        UVerse_message* __verse_0x4FD1B8FE_DefaultOffersDialogTitle;    // 0x000028 (0x000008) [Default: 0x7FE839892DA8]
    
    public: // Functions
        void                    _InitCDO(UVerse_message* _ExprResultStack_0, UVerse_message* _ExprResultStack_1); // 0x000545D2 [FUNC_None]
        static void                    _L_2fFortnite_2ecom_2fMarketplace_N_Rentitlement__change_L_Nt_20where_20t_R(UStruct* __verse_0xB2CDDD72_Argument, uint8 RetVal[0x000008]); // 0x000545D2 [Final | Static | Public | HasOutParms | BlueprintCallable]
        static UObject*                _L_2fFortnite_2ecom_2fMarketplace_N_RGetEntitlementsChangedEvent_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R(Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R __verse_0xB2CDDD72_Argument, Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R _ExprResult_0, Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R _ExprResult_1); // 0x000545D2 [Final | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static TOptional<EVerseTrue>   _L_2fFortnite_2ecom_2fMarketplace_N_RRestrictDirectPromptsToPurchase_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_R(USimulation_player* __verse_0xB2CDDD72_Argument, TOptional<EVerseTrue> _ExprResultStack_0, TOptional<EVerseTrue> _ExprResultStack_1); // 0x000545D2 [Final | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static TOptional<EVerseTrue>   _L_2fFortnite_2ecom_2fMarketplace_N_RRestrictPaidRandomItems_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_R(USimulation_player* __verse_0xB2CDDD72_Argument, TOptional<EVerseTrue> _ExprResultStack_0, TOptional<EVerseTrue> _ExprResultStack_1); // 0x000545D2 [Final | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static UConcurrency_task*      BuyOffer_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lplayer_Moffer_R __verse_0xB2CDDD72_Argument); // 0x000545D2 [Final | Static | Public | HasOutParms | BlueprintCallable]
        static UConcurrency_task*      ConsumeEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_20_3d_20_2e_2e_2e_R __verse_0xB2CDDD72_Argument); // 0x000545D2 [Final | Static | Public | HasOutParms | BlueprintCallable]
        static UConcurrency_task*      GetPurchasedEntitlements_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R __verse_0xB2CDDD72_Argument); // 0x000545D2 [Final | Static | Public | HasOutParms | BlueprintCallable]
        static UConcurrency_task*      GrantEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_20_3d_20_2e_2e_2e_R __verse_0xB2CDDD72_Argument); // 0x000545D2 [Final | Static | Public | HasOutParms | BlueprintCallable]
        static UConcurrency_task*      ShowOffersDialog_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_K_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_M_N_QTitle_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_20_3d_20_2e_2e_2e_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lplayer_M_Koffer_M_QTitle_Nmessage_20_3d_20_2e_2e_2e_R __verse_0xB2CDDD72_Argument); // 0x000545D2 [Final | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000150 (0x000090)
    class alignas(0x8) Utask__Root_ShowOffersDialog_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_K_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_M_N_QTitle_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_20_3d_20_2e_2e_2e_R : public UConcurrency_task
    {
    public:
        Ftuple_Lplayer_M_Koffer_M_QTitle_Nmessage_20_3d_20_2e_2e_2e_R   __verse_0xB2CDDD72_Argument;    // 0x0000C0 (0x000020)
        UConcurrency_task*                                              _AsyncTask_0;                   // 0x0000E0 (0x000008) [Default: nullptr]
        Ftuple_Lplayer_M_Koffer_M_QTitle_Nmessage_R                     _ExprResult_1;                  // 0x0000E8 (0x000020)
        TOptional<UVerse_message*>                                      _ExprResult_2;                  // 0x000108 (0x000008)
        int64                                                           _AsyncResult_3;                 // 0x000110 (0x000008) [Default: 0ll]
        UConcurrency_task*                                              _AsyncTask_4;                   // 0x000118 (0x000008) [Default: nullptr]
        Ftuple_Lplayer_M_Koffer_M_QTitle_Nmessage_R                     _ExprResult_5;                  // 0x000120 (0x000020)
        TOptional<UVerse_message*>                                      _ExprResult_6;                  // 0x000140 (0x000008)
        int64                                                           _AsyncResult_7;                 // 0x000148 (0x000008) [Default: 0ll]
    
    public: // Functions
        int64   Update(); // 0x000545D2 [Public | HasOutParms]
    };
    // Size: 0x000118 (0x000058)
    class alignas(0x8) Utask__Root_BuyOffer_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_R : public UConcurrency_task
    {
    public:
        Ftuple_Lplayer_Moffer_R __verse_0xB2CDDD72_Argument;    // 0x0000C0 (0x000010)
        bool                    _RetVal;                        // 0x0000D0 (0x000001) [Default: false]
        uint8                   UnknownData_0000D1[0x000007];   // 0x0000D1 (0x000007)
        UConcurrency_task*      _AsyncTask_0;                   // 0x0000D8 (0x000008) [Default: nullptr]
        Ftuple_Lplayer_Moffer_R _ExprResult_1;                  // 0x0000E0 (0x000010)
        int64                   _AsyncResult_2;                 // 0x0000F0 (0x000008) [Default: 0ll]
        UConcurrency_task*      _AsyncTask_3;                   // 0x0000F8 (0x000008) [Default: nullptr]
        Ftuple_Lplayer_Moffer_R _ExprResult_4;                  // 0x000100 (0x000010)
        int64                   _AsyncResult_5;                 // 0x000110 (0x000008) [Default: 0ll]
    
    public: // Functions
        int64   Update(); // 0x000545D2 [Public | HasOutParms]
    };
    // Size: 0x000168 (0x0000A8)
    class alignas(0x8) Utask__Root_GrantEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R : public UConcurrency_task
    {
    public:
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_20_3d_20_2e_2e_2e_R   __verse_0xB2CDDD72_Argument;    // 0x0000C0 (0x000020)
        bool                                                                                    _RetVal;                        // 0x0000E0 (0x000001) [Default: false]
        uint8                                                                                   UnknownData_0000E1[0x000007];   // 0x0000E1 (0x000007)
        UConcurrency_task*                                                                      _AsyncTask_0;                   // 0x0000E8 (0x000008) [Default: nullptr]
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_R                     _ExprResult_1;                  // 0x0000F0 (0x000020)
        TOptional<int64>                                                                        _ExprResult_2;                  // 0x000110 (0x000010)
        int64                                                                                   _AsyncResult_3;                 // 0x000120 (0x000008) [Default: 0ll]
        UConcurrency_task*                                                                      _AsyncTask_4;                   // 0x000128 (0x000008) [Default: nullptr]
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_R                     _ExprResult_5;                  // 0x000130 (0x000020)
        TOptional<int64>                                                                        _ExprResult_6;                  // 0x000150 (0x000010)
        int64                                                                                   _AsyncResult_7;                 // 0x000160 (0x000008) [Default: 0ll]
    
    public: // Functions
        int64   Update(); // 0x000545D2 [Public | HasOutParms]
    };
    // Size: 0x000168 (0x0000A8)
    class alignas(0x8) Utask__Root_ConsumeEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R : public UConcurrency_task
    {
    public:
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_20_3d_20_2e_2e_2e_R   __verse_0xB2CDDD72_Argument;    // 0x0000C0 (0x000020)
        bool                                                                                    _RetVal;                        // 0x0000E0 (0x000001) [Default: false]
        uint8                                                                                   UnknownData_0000E1[0x000007];   // 0x0000E1 (0x000007)
        UConcurrency_task*                                                                      _AsyncTask_0;                   // 0x0000E8 (0x000008) [Default: nullptr]
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_R                     _ExprResult_1;                  // 0x0000F0 (0x000020)
        TOptional<int64>                                                                        _ExprResult_2;                  // 0x000110 (0x000010)
        int64                                                                                   _AsyncResult_3;                 // 0x000120 (0x000008) [Default: 0ll]
        UConcurrency_task*                                                                      _AsyncTask_4;                   // 0x000128 (0x000008) [Default: nullptr]
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_R                     _ExprResult_5;                  // 0x000130 (0x000020)
        TOptional<int64>                                                                        _ExprResult_6;                  // 0x000150 (0x000010)
        int64                                                                                   _AsyncResult_7;                 // 0x000160 (0x000008) [Default: 0ll]
    
    public: // Functions
        int64   Update(); // 0x000545D2 [Public | HasOutParms]
    };
    // Size: 0x000120 (0x000060)
    class alignas(0x8) Utask__Root_GetPurchasedEntitlements_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R : public UConcurrency_task
    {
    public:
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R   __verse_0xB2CDDD72_Argument;    // 0x0000C0 (0x000010)
        TArray<Ftuple_Lentitlement_Mint_R>                      _RetVal;                        // 0x0000D0 (0x000010)
        UConcurrency_task*                                      _AsyncTask_0;                   // 0x0000E0 (0x000008) [Default: nullptr]
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R   _ExprResult_1;                  // 0x0000E8 (0x000010)
        int64                                                   _AsyncResult_2;                 // 0x0000F8 (0x000008) [Default: 0ll]
        UConcurrency_task*                                      _AsyncTask_3;                   // 0x000100 (0x000008) [Default: nullptr]
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R   _ExprResult_4;                  // 0x000108 (0x000010)
        int64                                                   _AsyncResult_5;                 // 0x000118 (0x000008) [Default: 0ll]
    
    public: // Functions
        int64   Update(); // 0x000545D2 [Public | HasOutParms]
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) Ftuple_Lentitlement_Mint_R
    {
        Uentitlement*   __verse_0x18E3F084_Elem0;   // 0x000000 (0x000008)
        int64           __verse_0x7D844C3C_Elem1;   // 0x000008 (0x000008)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) Ftuple_Lplayer_M_Koffer_M_QTitle_Nmessage_20_3d_20_2e_2e_2e_R
    {
        USimulation_player*         __verse_0x18E3F084_Elem0;   // 0x000000 (0x000008)
        TArray<Uoffer*>             __verse_0x7D844C3C_Elem1;   // 0x000008 (0x000010)
        TOptional<UVerse_message*>  __verse_0x932BF92E_Elem2;   // 0x000018 (0x000008)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) Ftuple_Lplayer_M_Koffer_M_QTitle_Nmessage_R
    {
        USimulation_player*         __verse_0x18E3F084_Elem0;   // 0x000000 (0x000008)
        TArray<Uoffer*>             __verse_0x7D844C3C_Elem1;   // 0x000008 (0x000010)
        TOptional<UVerse_message*>  __verse_0x932BF92E_Elem2;   // 0x000018 (0x000008)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) Ftuple_Lplayer_Moffer_R
    {
        USimulation_player* __verse_0x18E3F084_Elem0;   // 0x000000 (0x000008)
        Uoffer*             __verse_0x7D844C3C_Elem1;   // 0x000008 (0x000008)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_20_3d_20_2e_2e_2e_R
    {
        USimulation_player* __verse_0x18E3F084_Elem0;           // 0x000000 (0x000008)
        uint8               __verse_0x7D844C3C_Elem1[0x000008]; // 0x000008 (0x000008)
        TOptional<int64>    __verse_0x932BF92E_Elem2;           // 0x000010 (0x000010)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_R
    {
        USimulation_player* __verse_0x18E3F084_Elem0;           // 0x000000 (0x000008)
        uint8               __verse_0x7D844C3C_Elem1[0x000008]; // 0x000008 (0x000008)
        TOptional<int64>    __verse_0x932BF92E_Elem2;           // 0x000010 (0x000010)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R
    {
        USimulation_player* __verse_0x18E3F084_Elem0;           // 0x000000 (0x000008)
        uint8               __verse_0x7D844C3C_Elem1[0x000008]; // 0x000008 (0x000008)
    };
}

