/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:14
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AuroraCore/_Verse/VNI/AuroraCore
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0000E0 (0x000020)
    class alignas(0x8) Utask__Root_GetPurchasedEntitlements_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R : public UConcurrency_task
    {
    public:
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R   __verse_0xB2CDDD72_Argument;    // 0x0000C0 (0x000010)
        TArray<Ftuple_Lentitlement_Mint_R>                      _RetVal;                        // 0x0000D0 (0x000010)
    
    public: // Functions
        int64   Update(); // 0x0E4A0B0C [Native | Public | HasOutParms]
    };
    // Size: 0x000060 (0x000010)
    class alignas(0x8) Ubundle_offer : public Uoffer
    {
    public:
        TArray<Ftuple_Loffer_Mint_R>    __verse_0x7030F180_Offers;  // 0x000050 (0x000010)
    
    public: // Functions
        void    _Block(); // 0x000545D2 [FUNC_None]
        void    _InitCDO(TArray<Ftuple_Loffer_Mint_R> _ExprResult_0, TArray<EVerseFalse> __verse_0xFFC68BC5_Array_1, TArray<Ftuple_Loffer_Mint_R> _ForResult_1, int64 _ForIndex_2, int64 _ForLength_3, EVerseFalse __verse_0xFB88B569_Item_4, bool _ExprResult_4, TArray<Ftuple_Loffer_Mint_R> _ExprResult_5, TArray<EVerseFalse> __verse_0xFFC68BC5_Array_6, TArray<Ftuple_Loffer_Mint_R> _ForResult_6, int64 _ForIndex_7, int64 _ForLength_8, EVerseFalse __verse_0xFB88B569_Item_9, bool _ExprResult_9); // 0x000545D2 [HasDefaults]
        void    _InitInstance(); // 0x000545D2 [FUNC_None]
    };
    // Size: 0x000058 (0x000030)
    class alignas(0x8) Uentitlement : public UObject
    {
    public:
        UAssets_texture*    __verse_0xDAD1E0ED_Icon;                    // 0x000028 (0x000008) [Default: nullptr]
        UVerse_message*     __verse_0x199276B6_Name;                    // 0x000030 (0x000008) [Default: nullptr]
        UVerse_message*     __verse_0x338C210E_Description;             // 0x000038 (0x000008) [Default: nullptr]
        UVerse_message*     __verse_0xA8574D75_ShortDescription;        // 0x000040 (0x000008) [Default: nullptr]
        int64               __verse_0xABEF1D90_MaxCount;                // 0x000048 (0x000008) [Default: 1ll]
        bool                __verse_0x7B060C09_Consumable;              // 0x000050 (0x000001) [Default: false]
        bool                __verse_0x3A5D04A2_PaidRandomItem;          // 0x000051 (0x000001) [Default: false]
        bool                __verse_0xB6997E92_PaidArea;                // 0x000052 (0x000001) [Default: false]
        bool                __verse_0x4B6015C8_ConsequentialToGameplay; // 0x000053 (0x000001) [Default: false]
        uint8               UnknownData_000054[0x000004];               // 0x000054 (0x000004)
    
    public: // Functions
        void    _Block(); // 0x000545D2 [FUNC_None]
        void    _InitCDO(); // 0x000545D2 [FUNC_None]
        void    _InitInstance(); // 0x000545D2 [FUNC_None]
    };
    // Size: 0x000048 (0x000020)
    class alignas(0x8) Uentitlement_change : public UObject
    {
    public:
        uint8   __verse_0x745EDADD_Entitlement[0x000010];   // 0x000028 (0x000010)
        int64   __verse_0xFABA4328_Quantity;                // 0x000038 (0x000008) [Default: 0ll]
        int64   __verse_0x81B240EF_Change;                  // 0x000040 (0x000008) [Default: 0ll]
    
    public: // Functions
        void    _Block(); // 0x000545D2 [FUNC_None]
        void    _InitCDO(); // 0x000545D2 [FUNC_None]
        void    _InitInstance(); // 0x000545D2 [FUNC_None]
    };
    // Size: 0x000028 (0x000000)
    class Uprice_dimension : public UObject
    {
    public:
    
    public: // Functions
        void    _Block(); // 0x000545D2 [FUNC_None]
        void    _InitCDO(); // 0x000545D2 [FUNC_None]
        void    _InitInstance(); // 0x000545D2 [FUNC_None]
    };
    // Size: 0x000050 (0x000028)
    class alignas(0x8) Uoffer : public UObject
    {
    public:
        UAssets_texture*    __verse_0xDAD1E0ED_Icon;                // 0x000028 (0x000008) [Default: nullptr]
        UVerse_message*     __verse_0x199276B6_Name;                // 0x000030 (0x000008) [Default: nullptr]
        UVerse_message*     __verse_0x338C210E_Description;         // 0x000038 (0x000008) [Default: nullptr]
        UVerse_message*     __verse_0xA8574D75_ShortDescription;    // 0x000040 (0x000008) [Default: nullptr]
        Uprice_dimension*   __verse_0x34F04A65_Price;               // 0x000048 (0x000008) [Default: nullptr]
    
    public: // Functions
        void                _Block(); // 0x000545D2 [FUNC_None]
        void                _InitCDO(); // 0x000545D2 [FUNC_None]
        void                _InitInstance(); // 0x000545D2 [FUNC_None]
        TOptional<int64>    _L_2fUnrealEngine_2ecom_2fMarketplace_2foffer_N_RGetMinPurchaseAge_L_N_Kchar_M_N_Kchar_M_N_Kchar_R(Ftuple_L_Kchar_M_Kchar_M_Kchar_R __verse_0xB2CDDD72_Argument); // 0x000545D2 [Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000058 (0x000008)
    class alignas(0x8) Uentitlement_offer : public Uoffer
    {
    public:
        uint8   __verse_0x576DA619_EntitlementType[0x000008];   // 0x000050 (0x000008)
    
    public: // Functions
        void    _Block(); // 0x000545D2 [FUNC_None]
        void    _InitCDO(); // 0x000545D2 [FUNC_None]
        void    _InitInstance(); // 0x000545D2 [FUNC_None]
    };
    // Size: 0x0000E0 (0x000020)
    class alignas(0x8) Utask__Root_ShowOffersDialog_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_K_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_M_N_QTitle_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_20_3d_20_2e_2e_2e_R : public UConcurrency_task
    {
    public:
        Ftuple_Lplayer_M_Koffer_M_QTitle_Nmessage_20_3d_20_2e_2e_2e_R   __verse_0xB2CDDD72_Argument;    // 0x0000C0 (0x000020)
    
    public: // Functions
        int64   Update(); // 0x0E4A0B24 [Native | Public | HasOutParms]
    };
    // Size: 0x0000D1 (0x000011)
    class alignas(0x8) Utask__Root_BuyOffer_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_R : public UConcurrency_task
    {
    public:
        Ftuple_Lplayer_Moffer_R __verse_0xB2CDDD72_Argument;    // 0x0000C0 (0x000010)
        bool                    _RetVal;                        // 0x0000D0 (0x000001) [Default: false]
    
    public: // Functions
        int64   Update(); // 0x0E4A0B00 [Native | Public | HasOutParms]
    };
    // Size: 0x0000E1 (0x000021)
    class alignas(0x8) Utask__Root_GrantEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R : public UConcurrency_task
    {
    public:
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_20_3d_20_2e_2e_2e_R   __verse_0xB2CDDD72_Argument;    // 0x0000C0 (0x000020)
        bool                                                                                    _RetVal;                        // 0x0000E0 (0x000001) [Default: false]
    
    public: // Functions
        int64   Update(); // 0x0E4A0B06 [Native | Public | HasOutParms]
    };
    // Size: 0x0000E1 (0x000021)
    class alignas(0x8) Utask__Root_ConsumeEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R : public UConcurrency_task
    {
    public:
        Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_20_3d_20_2e_2e_2e_R   __verse_0xB2CDDD72_Argument;    // 0x0000C0 (0x000020)
        bool                                                                                    _RetVal;                        // 0x0000E0 (0x000001) [Default: false]
    
    public: // Functions
        int64   Update(); // 0x0E4A0B1E [Native | Public | HasOutParms]
    };
    // Size: 0x000030 (0x000008)
    class alignas(0x8) U_Root : public UObject
    {
    public:
        UVerse_message* __verse_0x4FD1B8FE_DefaultOffersDialogTitle;    // 0x000028 (0x000008) [Default: 0x7FE839769AA8]
    
    public: // Functions
        void                    _InitCDO(UVerse_message* _ExprResultStack_0, UVerse_message* _ExprResultStack_1); // 0x000545D2 [FUNC_None]
        static void                    _L_2fUnrealEngine_2ecom_2fMarketplace_N_Rentitlement__change_L_Nt_20where_20t_R(UStruct* __verse_0xB2CDDD72_Argument, uint8 RetVal[0x000008]); // 0x000545D2 [Final | Static | Public | HasOutParms | BlueprintCallable]
        static UObject*                _L_2fUnrealEngine_2ecom_2fMarketplace_N_RGetEntitlementsChangedEvent_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R(Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R __verse_0xB2CDDD72_Argument); // 0x0E4A0B12 [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
        static TOptional<EVerseTrue>   _L_2fUnrealEngine_2ecom_2fMarketplace_N_RRestrictDirectPromptsToPurchase_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_R(USimulation_player* __verse_0xB2CDDD72_Argument); // 0x0E4A0AF4 [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
        static TOptional<EVerseTrue>   _L_2fUnrealEngine_2ecom_2fMarketplace_N_RRestrictPaidRandomItems_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_R(USimulation_player* __verse_0xB2CDDD72_Argument); // 0x0E4A0AE8 [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
        static UConcurrency_task*      BuyOffer_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lplayer_Moffer_R __verse_0xB2CDDD72_Argument); // 0x000545D2 [Final | Static | Public | HasOutParms | BlueprintCallable]
        static UConcurrency_task*      ConsumeEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_20_3d_20_2e_2e_2e_R __verse_0xB2CDDD72_Argument); // 0x000545D2 [Final | Static | Public | HasOutParms | BlueprintCallable]
        static UConcurrency_task*      GetPurchasedEntitlements_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_20where_20entitlement__type_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R __verse_0xB2CDDD72_Argument); // 0x000545D2 [Final | Static | Public | HasOutParms | BlueprintCallable]
        static UConcurrency_task*      GrantEntitlement_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_Nentitlement__type_M_N_QCount_Nint_20_3d_20_2e_2e_2e_20where_20entitlement__type_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_20_3d_20_2e_2e_2e_R __verse_0xB2CDDD72_Argument); // 0x000545D2 [Final | Static | Public | HasOutParms | BlueprintCallable]
        static UConcurrency_task*      ShowOffersDialog_L_N_L_2fVerse_2eorg_2fSimulation_N_Rplayer_M_N_K_L_2fUnrealEngine_2ecom_2fMarketplace_N_Roffer_M_N_QTitle_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_20_3d_20_2e_2e_2e_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lplayer_M_Koffer_M_QTitle_Nmessage_20_3d_20_2e_2e_2e_R __verse_0xB2CDDD72_Argument); // 0x000545D2 [Final | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) Ftuple_L_Kchar_M_Kchar_M_Kchar_R
    {
        uint8   __verse_0x18E3F084_Elem0[0x000010]; // 0x000000 (0x000010)
        uint8   __verse_0x7D844C3C_Elem1[0x000010]; // 0x000010 (0x000010)
        uint8   __verse_0x932BF92E_Elem2[0x000010]; // 0x000020 (0x000010)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) Ftuple_Lentitlement_Mint_R
    {
        Uentitlement*   __verse_0x18E3F084_Elem0;   // 0x000000 (0x000008)
        int64           __verse_0x7D844C3C_Elem1;   // 0x000008 (0x000008)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) Ftuple_Loffer_Mint_R
    {
        Uoffer* __verse_0x18E3F084_Elem0;   // 0x000000 (0x000008)
        int64   __verse_0x7D844C3C_Elem1;   // 0x000008 (0x000008)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) Ftuple_Lplayer_M_Koffer_M_QTitle_Nmessage_20_3d_20_2e_2e_2e_R
    {
        USimulation_player*         __verse_0x18E3F084_Elem0;   // 0x000000 (0x000008)
        TArray<Uoffer*>             __verse_0x7D844C3C_Elem1;   // 0x000008 (0x000010)
        TOptional<UVerse_message*>  __verse_0x932BF92E_Elem2;   // 0x000018 (0x000008)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) Ftuple_Lplayer_Moffer_R
    {
        USimulation_player* __verse_0x18E3F084_Elem0;   // 0x000000 (0x000008)
        Uoffer*             __verse_0x7D844C3C_Elem1;   // 0x000008 (0x000008)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_M_QCount_Nint_20_3d_20_2e_2e_2e_R
    {
        USimulation_player* __verse_0x18E3F084_Elem0;           // 0x000000 (0x000008)
        uint8               __verse_0x7D844C3C_Elem1[0x000008]; // 0x000008 (0x000008)
        TOptional<int64>    __verse_0x932BF92E_Elem2;           // 0x000010 (0x000010)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) Ftuple_Lplayer_Mtype_Lentitlement_M_20entitlement_R_R
    {
        USimulation_player* __verse_0x18E3F084_Elem0;           // 0x000000 (0x000008)
        uint8               __verse_0x7D844C3C_Elem1[0x000008]; // 0x000008 (0x000008)
    };
}

