/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BeanstalkCosmeticsRuntime_Functions
 * ============================================================
 */

#include "BeanstalkCosmeticsRuntime.hpp"

namespace UE
{

    struct ABeanFortPlayerMannequin___BP_UpdateCosmeticMaterials_Params
    {
        UBeanCosmeticItemDefinitionBase*    BeanCD;             // 0x000000 (0x000008) [Default: 0x1494CAB0]
        UMaterialInstanceDynamic*           MaterialBody;       // 0x000008 (0x000008) [Default: 0x56318DD00000031]
        UMaterialInstanceDynamic*           MaterialCostume;    // 0x000010 (0x000008) [Default: 0x19883400]
        UMaterialInstanceDynamic*           MaterialHead;       // 0x000018 (0x000008) [Default: 0x198830E0]
    };

    struct UBeanAthenaCharacterItemDefinitionOverride___GetBeanCharacterFromCID_Params
    {
        TSoftObjectPtr<UAthenaCharacterItemDefinition>  CID;            // 0x000000 (0x000020) [Default: 0x1494DE00]
        UAthenaCharacterItemDefinition*                 ReturnValue;    // 0x000020 (0x000008) [ReturnValue] [Default: 0x89F88EBB]
    };

    struct UBeanAthenaCharacterItemDefinitionOverride___GetBIDOFromCID_Params
    {
        TSoftObjectPtr<UAthenaCharacterItemDefinition>  CID;            // 0x000000 (0x000020) [Default: 0x1494DE00]
        UBeanAthenaCharacterItemDefinitionOverride*     ReturnValue;    // 0x000020 (0x000008) [ReturnValue] [Default: 0x89F88EBB]
    };

    struct UFortCosmeticStep_ApplyBeanCD___BP_UpdateCosmeticMaterials_Params
    {
        UBeanCosmeticItemDefinitionBase*    BeanCD;             // 0x000000 (0x000008) [Default: 0x1494D660]
        UMaterialInstanceDynamic*           MaterialBody;       // 0x000008 (0x000008) [Default: 0x6F6318DD00000031]
        UMaterialInstanceDynamic*           MaterialCostume;    // 0x000010 (0x000008) [Default: 0x198838D0]
        UMaterialInstanceDynamic*           MaterialHead;       // 0x000018 (0x000008) [Default: 0x198830E0]
    };

} // namespace UE

