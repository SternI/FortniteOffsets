/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:25
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AutoAimWeapon/B_AutoAimWeaponPawnComponent_Base_Functions
 * ============================================================
 */

#include "B_AutoAimWeaponPawnComponent_Base.hpp"

namespace UE
{

    struct UB_AutoAimWeaponPawnComponent_Base_C___ExecuteUbergraph_B_AutoAimWeaponPawnComponent_Base_Params
    {
        int32   EntryPoint;                         // 0x000000 (0x000004) [Default: 345033760]
        uint8   UnknownData_000004[0x000004];       // 0x000004 (0x000004)
        AActor* CallFunc_GetOwner_ReturnValue;      // 0x000008 (0x000008) [Default: 0xA6FE1EDD00280031]
        bool    CallFunc_HasAuthority_ReturnValue;  // 0x000010 (0x000001) [Default: true]
    };

} // namespace UE

