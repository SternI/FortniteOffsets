/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:25
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AutoAimWeapon/B_AutoAimWeaponPawnComponent_Base_Functions
 * ============================================================
 */

#include "B_AutoAimWeaponPawnComponent_Base_Functions.hpp"

namespace UE
{

    void UB_AutoAimWeaponPawnComponent_Base_C::DestroyComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_AutoAimWeaponPawnComponent_Base.B_AutoAimWeaponPawnComponent_Base_C.DestroyComponent");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UB_AutoAimWeaponPawnComponent_Base_C::ExecuteUbergraph_B_AutoAimWeaponPawnComponent_Base(int32 EntryPoint, AActor* CallFunc_GetOwner_ReturnValue, bool CallFunc_HasAuthority_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_AutoAimWeaponPawnComponent_Base.B_AutoAimWeaponPawnComponent_Base_C.ExecuteUbergraph_B_AutoAimWeaponPawnComponent_Base");
    
        UB_AutoAimWeaponPawnComponent_Base_C___ExecuteUbergraph_B_AutoAimWeaponPawnComponent_Base_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.CallFunc_GetOwner_ReturnValue = CallFunc_GetOwner_ReturnValue;
        Params.CallFunc_HasAuthority_ReturnValue = CallFunc_HasAuthority_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

