/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:25
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AutoAimWeapon/B_AutoAimWeaponPawnComponent_Base
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0001B0 (0x000008)
    class alignas(0x8) UB_AutoAimWeaponPawnComponent_Base_C : public UAutoAimWeaponPawnComponent
    {
    public:
        FPointerToUberGraphFrame    UberGraphFrame; // 0x0001A8 (0x000008)
    
    public: // Functions
        void    DestroyComponent(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    ExecuteUbergraph_B_AutoAimWeaponPawnComponent_Base(int32 EntryPoint, AActor* CallFunc_GetOwner_ReturnValue, bool CallFunc_HasAuthority_ReturnValue); // 0x000545D2 [Final | UbergraphFunction]
    };
}

