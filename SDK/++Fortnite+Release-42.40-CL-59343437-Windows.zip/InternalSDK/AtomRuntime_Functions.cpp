/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AtomRuntime_Functions
 * ============================================================
 */

#include "AtomRuntime_Functions.hpp"

namespace UE
{

    int32 UAtomColorComponent::GetColorLUTIndex()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomColorComponent.GetColorLUTIndex");
    
        UAtomColorComponent___GetColorLUTIndex_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAtomColorComponent::SetColorLUTAtlas(UAtomColorLUTAtlas* InColorLUTAtlas)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomColorComponent.SetColorLUTAtlas");
    
        UAtomColorComponent___SetColorLUTAtlas_Params Params{};
        Params.InColorLUTAtlas = InColorLUTAtlas;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAtomColorComponent::SetColorLUTTexture(UTexture2D* InColorLUTTexture)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomColorComponent.SetColorLUTTexture");
    
        UAtomColorComponent___SetColorLUTTexture_Params Params{};
        Params.InColorLUTTexture = InColorLUTTexture;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    int32 UAtomColorLUTAtlas::FindOrAddLUTIndex(UTexture2D* InTexture)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomColorLUTAtlas.FindOrAddLUTIndex");
    
        UAtomColorLUTAtlas___FindOrAddLUTIndex_Params Params{};
        Params.InTexture = InTexture;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAtomColorLUTAtlas::GetAtlasSize()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomColorLUTAtlas.GetAtlasSize");
    
        UAtomColorLUTAtlas___GetAtlasSize_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAtomColorLUTAtlas::GetLUTIndex(UTexture2D* InTexture)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomColorLUTAtlas.GetLUTIndex");
    
        UAtomColorLUTAtlas___GetLUTIndex_Params Params{};
        Params.InTexture = InTexture;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAtomColorThemeComponent::ApplyColorTheme()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomColorThemeComponent.ApplyColorTheme");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    TArray<FName> UAtomColorThemeComponent::GetAtomColorThemeLibraries()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomColorThemeComponent.GetAtomColorThemeLibraries");
    
        UAtomColorThemeComponent___GetAtomColorThemeLibraries_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAtomColorThemeComponent::GetColorThemeIndex()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomColorThemeComponent.GetColorThemeIndex");
    
        UAtomColorThemeComponent___GetColorThemeIndex_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FName> UAtomColorThemeComponent::GetThemeNames()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomColorThemeComponent.GetThemeNames");
    
        UAtomColorThemeComponent___GetThemeNames_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAtomColorThemeComponent::SetColorThemeByName(FName Name)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomColorThemeComponent.SetColorThemeByName");
    
        UAtomColorThemeComponent___SetColorThemeByName_Params Params{};
        Params.Name = Name;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAtomColorThemeComponent::SetColorThemeByTexture(UTexture2D* Texture)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomColorThemeComponent.SetColorThemeByTexture");
    
        UAtomColorThemeComponent___SetColorThemeByTexture_Params Params{};
        Params.Texture = Texture;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAtomColorThemeLibrary::GetAtlasDynamicTextureSize()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomColorThemeLibrary.GetAtlasDynamicTextureSize");
    
        UAtomColorThemeLibrary___GetAtlasDynamicTextureSize_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAtomColorThemeLibrary::GetAtlasSize()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomColorThemeLibrary.GetAtlasSize");
    
        UAtomColorThemeLibrary___GetAtlasSize_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAtomColorThemeLibrary::GetNumberOfStaticThemesRows()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomColorThemeLibrary.GetNumberOfStaticThemesRows");
    
        UAtomColorThemeLibrary___GetNumberOfStaticThemesRows_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAtomColorThemeLibrary::IsLUTTextureCompatible(UTexture2D* LUTTexture)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomColorThemeLibrary.IsLUTTextureCompatible");
    
        UAtomColorThemeLibrary___IsLUTTextureCompatible_Params Params{};
        Params.LUTTexture = LUTTexture;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FVector UAtomConnectivityQueryBlueprintLibrary::GetClosestConnectionPointInActors(TArray<AActor*>& Actors, FVector& Location)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomConnectivityQueryBlueprintLibrary.GetClosestConnectionPointInActors");
    
        UAtomConnectivityQueryBlueprintLibrary___GetClosestConnectionPointInActors_Params Params{};
        Params.Actors = Actors;
        Params.Location = Location;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Actors = Params.Actors;
        Location = Params.Location;
    
        return Params.ReturnValue;
    }

    FString UAtomModel::GetChildIdentifier(int32 InChildIdx)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomModel.GetChildIdentifier");
    
        UAtomModel___GetChildIdentifier_Params Params{};
        Params.InChildIdx = InChildIdx;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<TSoftObjectPtr<UStaticMesh>> UAtomModel::GetGeneratedMergedMeshes()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomModel.GetGeneratedMergedMeshes");
    
        UAtomModel___GetGeneratedMergedMeshes_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FString UAtomModel::GetModelName()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomModel.GetModelName");
    
        UAtomModel___GetModelName_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FString UAtomModel::GetModelPath()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomModel.GetModelPath");
    
        UAtomModel___GetModelPath_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FAtomModelPartsCollection UAtomModel::GetPartsCollection()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomModel.GetPartsCollection");
    
        UAtomModel___GetPartsCollection_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAtomModel::GetPrimitivesForChildArray(int32 InChildIdx, TArray<FAtomModelPrimitiveInstance>& OutPrimitives)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomModel.GetPrimitivesForChildArray");
    
        UAtomModel___GetPrimitivesForChildArray_Params Params{};
        Params.InChildIdx = InChildIdx;
        Params.OutPrimitives = OutPrimitives;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutPrimitives = Params.OutPrimitives;
    }

    FVector UAtomModel::GetRootGroupPivot()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomModel.GetRootGroupPivot");
    
        UAtomModel___GetRootGroupPivot_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UTexture* UAtomModel::GetTextureForDecorationTextureName(FString TextureName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomModel.GetTextureForDecorationTextureName");
    
        UAtomModel___GetTextureForDecorationTextureName_Params Params{};
        Params.TextureName = TextureName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAtomModelComponent::ModelSupportsMaterialInstancePayload()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomModelComponent.ModelSupportsMaterialInstancePayload");
    
        UAtomModelComponent___ModelSupportsMaterialInstancePayload_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EFieldConnectResult UAtomModelPartsCollectionConnectivity::GetTechnicHoleConnectivityState(FAtomPartConnectivityFieldReference& TechnicHolePartConnectivityRef, FAtomPartConnectivityFieldReference& ConnectedPartConnectivityRef)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomModelPartsCollectionConnectivity.GetTechnicHoleConnectivityState");
    
        UAtomModelPartsCollectionConnectivity___GetTechnicHoleConnectivityState_Params Params{};
        Params.TechnicHolePartConnectivityRef = TechnicHolePartConnectivityRef;
        Params.ConnectedPartConnectivityRef = ConnectedPartConnectivityRef;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        TechnicHolePartConnectivityRef = Params.TechnicHolePartConnectivityRef;
        ConnectedPartConnectivityRef = Params.ConnectedPartConnectivityRef;
    
        return Params.ReturnValue;
    }

    TArray<EFieldConnectResult> UAtomModelPartsCollectionConnectivity::GetTechnicPinConnectivityStates(FAtomPartConnectivityFieldReference& TechnicPinPartConnectivityRef, TArray<FAtomPartConnectivityFieldReference>& ConnectedPartsConnectivityRef)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomModelPartsCollectionConnectivity.GetTechnicPinConnectivityStates");
    
        UAtomModelPartsCollectionConnectivity___GetTechnicPinConnectivityStates_Params Params{};
        Params.TechnicPinPartConnectivityRef = TechnicPinPartConnectivityRef;
        Params.ConnectedPartsConnectivityRef = ConnectedPartsConnectivityRef;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        TechnicPinPartConnectivityRef = Params.TechnicPinPartConnectivityRef;
        ConnectedPartsConnectivityRef = Params.ConnectedPartsConnectivityRef;
    
        return Params.ReturnValue;
    }

    void UAtomModelProcessor::IncrementProgress(int32 NumSteps, FString Message)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomModelProcessor.IncrementProgress");
    
        UAtomModelProcessor___IncrementProgress_Params Params{};
        Params.NumSteps = NumSteps;
        Params.Message = Message;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    FString UAtomModelProcessor::OnGetProcessModelTargetAssetPath(UAtomModel* Model, FAtomModelPartsCollection& AtomModelPartsCollection)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomModelProcessor.OnGetProcessModelTargetAssetPath");
    
        UAtomModelProcessor___OnGetProcessModelTargetAssetPath_Params Params{};
        Params.Model = Model;
        Params.AtomModelPartsCollection = AtomModelPartsCollection;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        AtomModelPartsCollection = Params.AtomModelPartsCollection;
    
        return Params.ReturnValue;
    }

    FString UAtomModelProcessor::OnGetProcessPrimitiveTargetAssetPath(UAtomModel* Model, UAtomPrimitive* Primitive, FAtomModelPartsCollection& AtomModelPartsCollection, FAtomOnProcessPrimitiveSettings& Settings)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomModelProcessor.OnGetProcessPrimitiveTargetAssetPath");
    
        UAtomModelProcessor___OnGetProcessPrimitiveTargetAssetPath_Params Params{};
        Params.Model = Model;
        Params.Primitive = Primitive;
        Params.AtomModelPartsCollection = AtomModelPartsCollection;
        Params.Settings = Settings;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        AtomModelPartsCollection = Params.AtomModelPartsCollection;
        Settings = Params.Settings;
    
        return Params.ReturnValue;
    }

    FString UAtomModelProcessor::OnGetTargetAssetPath(UAtomModel* Model, UAtomPrimitive* Primitive, FAtomModelPartsCollection& AtomModelPartsCollection)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomModelProcessor.OnGetTargetAssetPath");
    
        UAtomModelProcessor___OnGetTargetAssetPath_Params Params{};
        Params.Model = Model;
        Params.Primitive = Primitive;
        Params.AtomModelPartsCollection = AtomModelPartsCollection;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        AtomModelPartsCollection = Params.AtomModelPartsCollection;
    
        return Params.ReturnValue;
    }

    FAtomProcessorResult UAtomModelProcessor::OnProcessModel(UAtomModel* Model, FAtomModelPartsCollection& AtomModelPartsCollection, TArray<TSoftObjectPtr<UObject>>& ExistingObjects)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomModelProcessor.OnProcessModel");
    
        UAtomModelProcessor___OnProcessModel_Params Params{};
        Params.Model = Model;
        Params.AtomModelPartsCollection = AtomModelPartsCollection;
        Params.ExistingObjects = ExistingObjects;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        AtomModelPartsCollection = Params.AtomModelPartsCollection;
        ExistingObjects = Params.ExistingObjects;
    
        return Params.ReturnValue;
    }

    FAtomProcessorResult UAtomModelProcessor::OnProcessPrimitive(UAtomModel* DummyModel, UAtomPrimitive* Primitive, FAtomModelPartsCollection& AtomModelPartsCollection, FAtomOnProcessPrimitiveSettings& Settings)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomModelProcessor.OnProcessPrimitive");
    
        UAtomModelProcessor___OnProcessPrimitive_Params Params{};
        Params.DummyModel = DummyModel;
        Params.Primitive = Primitive;
        Params.AtomModelPartsCollection = AtomModelPartsCollection;
        Params.Settings = Settings;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        AtomModelPartsCollection = Params.AtomModelPartsCollection;
        Settings = Params.Settings;
    
        return Params.ReturnValue;
    }

    void UAtomPartsCollectionBlueprintLibrary::AddPartInstance(FAtomModelPartsCollection& PartCollection, FAtomModelPartInstanceInfo& PartInstance)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.AddPartInstance");
    
        UAtomPartsCollectionBlueprintLibrary___AddPartInstance_Params Params{};
        Params.PartCollection = PartCollection;
        Params.PartInstance = PartInstance;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PartCollection = Params.PartCollection;
        PartInstance = Params.PartInstance;
    }

    FString UAtomPartsCollectionBlueprintLibrary::Conv_ModelPartGuidToString(FAtomModelPartGuid& InModelPartGuid)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.Conv_ModelPartGuidToString");
    
        UAtomPartsCollectionBlueprintLibrary___Conv_ModelPartGuidToString_Params Params{};
        Params.InModelPartGuid = InModelPartGuid;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InModelPartGuid = Params.InModelPartGuid;
    
        return Params.ReturnValue;
    }

    FAtomModelPartGuid UAtomPartsCollectionBlueprintLibrary::Conv_StringToModelPartGuid(FString InString)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.Conv_StringToModelPartGuid");
    
        UAtomPartsCollectionBlueprintLibrary___Conv_StringToModelPartGuid_Params Params{};
        Params.InString = InString;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FAtomModelPartColorInfo UAtomPartsCollectionBlueprintLibrary::CreateColorInfoFromColorId(int32 ColorId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.CreateColorInfoFromColorId");
    
        UAtomPartsCollectionBlueprintLibrary___CreateColorInfoFromColorId_Params Params{};
        Params.ColorId = ColorId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAtomModelPartsCollectionConnectivity* UAtomPartsCollectionBlueprintLibrary::CreatePartsCollectionConnectivity(FAtomModelPartsCollection& PartsCollection, UAtomModel* Model, float Scale)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.CreatePartsCollectionConnectivity");
    
        UAtomPartsCollectionBlueprintLibrary___CreatePartsCollectionConnectivity_Params Params{};
        Params.PartsCollection = PartsCollection;
        Params.Model = Model;
        Params.Scale = Scale;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PartsCollection = Params.PartsCollection;
    
        return Params.ReturnValue;
    }

    FAtomModelPartsCollection UAtomPartsCollectionBlueprintLibrary::FilterCommonPartsToStyle(FAtomModelPartsCollection& PartsCollection, FName GeometryStyle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.FilterCommonPartsToStyle");
    
        UAtomPartsCollectionBlueprintLibrary___FilterCommonPartsToStyle_Params Params{};
        Params.PartsCollection = PartsCollection;
        Params.GeometryStyle = GeometryStyle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PartsCollection = Params.PartsCollection;
    
        return Params.ReturnValue;
    }

    FAtomModelPartsCollection UAtomPartsCollectionBlueprintLibrary::FilterGroup(UAtomModel* Model, FAtomModelPartsCollection& PartsCollectionToFilter, FString GroupName, FString NewPartsCollectionName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.FilterGroup");
    
        UAtomPartsCollectionBlueprintLibrary___FilterGroup_Params Params{};
        Params.Model = Model;
        Params.PartsCollectionToFilter = PartsCollectionToFilter;
        Params.GroupName = GroupName;
        Params.NewPartsCollectionName = NewPartsCollectionName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PartsCollectionToFilter = Params.PartsCollectionToFilter;
    
        return Params.ReturnValue;
    }

    FAtomModelPartsCollection UAtomPartsCollectionBlueprintLibrary::FilterNonTransparent(FAtomModelPartsCollection& PartsCollectionToFilter, FString NewPartsCollectionName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.FilterNonTransparent");
    
        UAtomPartsCollectionBlueprintLibrary___FilterNonTransparent_Params Params{};
        Params.PartsCollectionToFilter = PartsCollectionToFilter;
        Params.NewPartsCollectionName = NewPartsCollectionName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PartsCollectionToFilter = Params.PartsCollectionToFilter;
    
        return Params.ReturnValue;
    }

    FAtomModelPartsCollection UAtomPartsCollectionBlueprintLibrary::FilterSelectionSet(FAtomModelPartsCollection& PartsCollectionToFilter, FString SelectionSetName, FString NewPartsCollectionName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.FilterSelectionSet");
    
        UAtomPartsCollectionBlueprintLibrary___FilterSelectionSet_Params Params{};
        Params.PartsCollectionToFilter = PartsCollectionToFilter;
        Params.SelectionSetName = SelectionSetName;
        Params.NewPartsCollectionName = NewPartsCollectionName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PartsCollectionToFilter = Params.PartsCollectionToFilter;
    
        return Params.ReturnValue;
    }

    FAtomModelPartsCollection UAtomPartsCollectionBlueprintLibrary::FilterTransparent(FAtomModelPartsCollection& PartsCollectionToFilter, FString NewPartsCollectionName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.FilterTransparent");
    
        UAtomPartsCollectionBlueprintLibrary___FilterTransparent_Params Params{};
        Params.PartsCollectionToFilter = PartsCollectionToFilter;
        Params.NewPartsCollectionName = NewPartsCollectionName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PartsCollectionToFilter = Params.PartsCollectionToFilter;
    
        return Params.ReturnValue;
    }

    int32 UAtomPartsCollectionBlueprintLibrary::GetModelPartGuidHash(FAtomModelPartGuid& InModelPartGuid)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.GetModelPartGuidHash");
    
        UAtomPartsCollectionBlueprintLibrary___GetModelPartGuidHash_Params Params{};
        Params.InModelPartGuid = InModelPartGuid;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InModelPartGuid = Params.InModelPartGuid;
    
        return Params.ReturnValue;
    }

    FString UAtomPartsCollectionBlueprintLibrary::GetName(FAtomModelPartsCollection& PartsCollection)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.GetName");
    
        UAtomPartsCollectionBlueprintLibrary___GetName_Params Params{};
        Params.PartsCollection = PartsCollection;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PartsCollection = Params.PartsCollection;
    
        return Params.ReturnValue;
    }

    TArray<FAtomModelPartInstanceInfo> UAtomPartsCollectionBlueprintLibrary::GetParts(FAtomModelPartsCollection& PartsCollection)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.GetParts");
    
        UAtomPartsCollectionBlueprintLibrary___GetParts_Params Params{};
        Params.PartsCollection = PartsCollection;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PartsCollection = Params.PartsCollection;
    
        return Params.ReturnValue;
    }

    TArray<FAtomCommonPartAndTransform> UAtomPartsCollectionBlueprintLibrary::GetPrimitiveCommonParts(UAtomPrimitive* Primitive, double Scale)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.GetPrimitiveCommonParts");
    
        UAtomPartsCollectionBlueprintLibrary___GetPrimitiveCommonParts_Params Params{};
        Params.Primitive = Primitive;
        Params.Scale = Scale;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAtomPartsCollectionBlueprintLibrary::InitializeCommonParts(UAtomModelPartsCollectionConnectivity* PartsCollectionConnectivity, int32 CommonPartOptimizationFlags)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.InitializeCommonParts");
    
        UAtomPartsCollectionBlueprintLibrary___InitializeCommonParts_Params Params{};
        Params.PartsCollectionConnectivity = PartsCollectionConnectivity;
        Params.CommonPartOptimizationFlags = CommonPartOptimizationFlags;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UAtomPartsCollectionBlueprintLibrary::PrimitiveHasConsistentCommonPartStyles(UAtomPrimitive* Primitive)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.PrimitiveHasConsistentCommonPartStyles");
    
        UAtomPartsCollectionBlueprintLibrary___PrimitiveHasConsistentCommonPartStyles_Params Params{};
        Params.Primitive = Primitive;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAtomPartsCollectionBlueprintLibrary::RemovePartInstance(FAtomModelPartsCollection& PartCollection, FAtomModelPartGuid& PartInstanceId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.RemovePartInstance");
    
        UAtomPartsCollectionBlueprintLibrary___RemovePartInstance_Params Params{};
        Params.PartCollection = PartCollection;
        Params.PartInstanceId = PartInstanceId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PartCollection = Params.PartCollection;
        PartInstanceId = Params.PartInstanceId;
    }

    void UAtomPartsCollectionBlueprintLibrary::ReplacePartInstance(FAtomModelPartsCollection& PartCollection, FAtomModelPartInstanceInfo& SourcePartInstance, FAtomModelPartGuid& TargetPartInstanceId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.ReplacePartInstance");
    
        UAtomPartsCollectionBlueprintLibrary___ReplacePartInstance_Params Params{};
        Params.PartCollection = PartCollection;
        Params.SourcePartInstance = SourcePartInstance;
        Params.TargetPartInstanceId = TargetPartInstanceId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PartCollection = Params.PartCollection;
        SourcePartInstance = Params.SourcePartInstance;
        TargetPartInstanceId = Params.TargetPartInstanceId;
    }

    void UAtomPartsCollectionBlueprintLibrary::SetName(FAtomModelPartsCollection& PartsCollection, FString Name)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPartsCollectionBlueprintLibrary.SetName");
    
        UAtomPartsCollectionBlueprintLibrary___SetName_Params Params{};
        Params.PartsCollection = PartsCollection;
        Params.Name = Name;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PartsCollection = Params.PartsCollection;
    }

    void UAtomPlacementResultHelperLibrary::Break(FAtomPlacementResult& PlacementResult, FTransform& OutTransformDelta, TArray<TScriptInterface<IAtomRejectionReason>>& OutRejectionReasons)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPlacementResultHelperLibrary.Break");
    
        UAtomPlacementResultHelperLibrary___Break_Params Params{};
        Params.PlacementResult = PlacementResult;
        Params.OutTransformDelta = OutTransformDelta;
        Params.OutRejectionReasons = OutRejectionReasons;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PlacementResult = Params.PlacementResult;
        OutTransformDelta = Params.OutTransformDelta;
        OutRejectionReasons = Params.OutRejectionReasons;
    }

    bool IAtomPlacementTool::BeginUpdatingPlacement(FPlacementOperation& NewPlacementOperation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPlacementTool.BeginUpdatingPlacement");
    
        IAtomPlacementTool___BeginUpdatingPlacement_Params Params{};
        Params.NewPlacementOperation = NewPlacementOperation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        NewPlacementOperation = Params.NewPlacementOperation;
    
        return Params.ReturnValue;
    }

    void IAtomPlacementTool::EndUpdatingPlacement(bool bCancelled)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPlacementTool.EndUpdatingPlacement");
    
        IAtomPlacementTool___EndUpdatingPlacement_Params Params{};
        Params.bCancelled = bCancelled;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    TArray<TScriptInterface<IAtomRejectionReason>> IAtomPlacementTool::GetPlacementRejectionReasons()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPlacementTool.GetPlacementRejectionReasons");
    
        IAtomPlacementTool___GetPlacementRejectionReasons_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool IAtomPlacementTool::RegisterAndConnectActor(AActor* Actor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPlacementTool.RegisterAndConnectActor");
    
        IAtomPlacementTool___RegisterAndConnectActor_Params Params{};
        Params.Actor = Actor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool IAtomPlacementTool::UpdatePlacement(FPlacementContextData& ContextData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPlacementTool.UpdatePlacement");
    
        IAtomPlacementTool___UpdatePlacement_Params Params{};
        Params.ContextData = ContextData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ContextData = Params.ContextData;
    
        return Params.ReturnValue;
    }

    FBoxSphereBounds UAtomPrimitive::GetBounds(float Scale)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitive.GetBounds");
    
        UAtomPrimitive___GetBounds_Params Params{};
        Params.Scale = Scale;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FVector UAtomPrimitive::GetCenterOfMass(float Scale)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitive.GetCenterOfMass");
    
        UAtomPrimitive___GetCenterOfMass_Params Params{};
        Params.Scale = Scale;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAtomPrimitive::GetDecorationSurfaceIndex(FString SurfaceName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitive.GetDecorationSurfaceIndex");
    
        UAtomPrimitive___GetDecorationSurfaceIndex_Params Params{};
        Params.SurfaceName = SurfaceName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAtomPrimitive::GetExportStyleMaxLOD(FString ExportStyle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitive.GetExportStyleMaxLOD");
    
        UAtomPrimitive___GetExportStyleMaxLOD_Params Params{};
        Params.ExportStyle = ExportStyle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometryContainer* UAtomPrimitive::GetGeometryContainerForBestExportStyle(TArray<FString>& GeometryStylePriorityList, int32 LODIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitive.GetGeometryContainerForBestExportStyle");
    
        UAtomPrimitive___GetGeometryContainerForBestExportStyle_Params Params{};
        Params.GeometryStylePriorityList = GeometryStylePriorityList;
        Params.LODIndex = LODIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        GeometryStylePriorityList = Params.GeometryStylePriorityList;
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometryContainer* UAtomPrimitive::GetGeometryContainerForExportStyle(FString ExportStyleName, FString FallbackExportStyleName, int32 LODIndex, bool bUseFallbacks)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitive.GetGeometryContainerForExportStyle");
    
        UAtomPrimitive___GetGeometryContainerForExportStyle_Params Params{};
        Params.ExportStyleName = ExportStyleName;
        Params.FallbackExportStyleName = FallbackExportStyleName;
        Params.LODIndex = LODIndex;
        Params.bUseFallbacks = bUseFallbacks;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FName UAtomPrimitive::GetMainGroupName(int32 MainGroupId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitive.GetMainGroupName");
    
        UAtomPrimitive___GetMainGroupName_Params Params{};
        Params.MainGroupId = MainGroupId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FName UAtomPrimitive::GetSubMainGroupName(int32 SubMainGroupId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitive.GetSubMainGroupName");
    
        UAtomPrimitive___GetSubMainGroupName_Params Params{};
        Params.SubMainGroupId = SubMainGroupId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAtomPrimitive::IsFlexElement()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitive.IsFlexElement");
    
        UAtomPrimitive___IsFlexElement_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UTexture* UAtomPrimitive::LoadDetailTextureForExportStyle(FString ExportStyle, int32 LOD, EAtomPrimitiveDetailTextureType TextureType)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitive.LoadDetailTextureForExportStyle");
    
        UAtomPrimitive___LoadDetailTextureForExportStyle_Params Params{};
        Params.ExportStyle = ExportStyle;
        Params.LOD = LOD;
        Params.TextureType = TextureType;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UTexture* UAtomPrimitive::LoadDetailTextureForExportStyleAndSection(FString ExportStyle, int32 LOD, EAtomPrimitiveDetailTextureType TextureType, EPrimitiveGeometrySectionFlag Section)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitive.LoadDetailTextureForExportStyleAndSection");
    
        UAtomPrimitive___LoadDetailTextureForExportStyleAndSection_Params Params{};
        Params.ExportStyle = ExportStyle;
        Params.LOD = LOD;
        Params.TextureType = TextureType;
        Params.Section = Section;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAtomPrimitiveBlueprintLibrary::GetDefaultPrimitiveScale()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveBlueprintLibrary.GetDefaultPrimitiveScale");
    
        UAtomPrimitiveBlueprintLibrary___GetDefaultPrimitiveScale_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometry::Append(UAtomPrimitiveGeometry* GeometryToAppend, FTransform3f& Transform)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.Append");
    
        UAtomPrimitiveGeometry___Append_Params Params{};
        Params.GeometryToAppend = GeometryToAppend;
        Params.Transform = Transform;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Transform = Params.Transform;
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometry::AppendAndWeld(UAtomPrimitiveGeometry* GeometryToAppend, FTransform3f& Transform)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.AppendAndWeld");
    
        UAtomPrimitiveGeometry___AppendAndWeld_Params Params{};
        Params.GeometryToAppend = GeometryToAppend;
        Params.Transform = Transform;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Transform = Params.Transform;
    
        return Params.ReturnValue;
    }

    void UAtomPrimitiveGeometry::AttachVerticesToBoneIndex(int32 BoneIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.AttachVerticesToBoneIndex");
    
        UAtomPrimitiveGeometry___AttachVerticesToBoneIndex_Params Params{};
        Params.BoneIndex = BoneIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAtomPrimitiveGeometry::AttachVerticesToNamedBone(FString BoneName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.AttachVerticesToNamedBone");
    
        UAtomPrimitiveGeometry___AttachVerticesToNamedBone_Params Params{};
        Params.BoneName = BoneName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometry::BakeScale(float Scale)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.BakeScale");
    
        UAtomPrimitiveGeometry___BakeScale_Params Params{};
        Params.Scale = Scale;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometry::BakeTransform(FTransform3f& Transform)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.BakeTransform");
    
        UAtomPrimitiveGeometry___BakeTransform_Params Params{};
        Params.Transform = Transform;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Transform = Params.Transform;
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometry::BakeTransforms(TArray<FTransform3f>& Transforms)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.BakeTransforms");
    
        UAtomPrimitiveGeometry___BakeTransforms_Params Params{};
        Params.Transforms = Transforms;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Transforms = Params.Transforms;
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometry::ConvertVertexColorsLinearToSRGB()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.ConvertVertexColorsLinearToSRGB");
    
        UAtomPrimitiveGeometry___ConvertVertexColorsLinearToSRGB_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometry::CopyNormalMapsToUV0()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.CopyNormalMapsToUV0");
    
        UAtomPrimitiveGeometry___CopyNormalMapsToUV0_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometry::CreateAtomGeometryFromCommonPart(FString ExportStyleName, EAtomCommonPartType CommonPartType, int32 LODIndex, FString CommonPartsMeshPath)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.CreateAtomGeometryFromCommonPart");
    
        UAtomPrimitiveGeometry___CreateAtomGeometryFromCommonPart_Params Params{};
        Params.ExportStyleName = ExportStyleName;
        Params.CommonPartType = CommonPartType;
        Params.LODIndex = LODIndex;
        Params.CommonPartsMeshPath = CommonPartsMeshPath;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometry::CreateEmptyAtomGeometry(int32 NumberOfUVChannels)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.CreateEmptyAtomGeometry");
    
        UAtomPrimitiveGeometry___CreateEmptyAtomGeometry_Params Params{};
        Params.NumberOfUVChannels = NumberOfUVChannels;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometry::DuplicateGeometry()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.DuplicateGeometry");
    
        UAtomPrimitiveGeometry___DuplicateGeometry_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAtomPrimitiveGeometry::GetBoneIndexForName(FString BoneName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.GetBoneIndexForName");
    
        UAtomPrimitiveGeometry___GetBoneIndexForName_Params Params{};
        Params.BoneName = BoneName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAtomPrimitiveGeometry::GetCommonPartBestExportStyle(TArray<FString>& GeometryStylePriorityList, EAtomCommonPartType CommonPartType, FString& OutGeometryStyle, FString CommonPartsMeshPath)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.GetCommonPartBestExportStyle");
    
        UAtomPrimitiveGeometry___GetCommonPartBestExportStyle_Params Params{};
        Params.GeometryStylePriorityList = GeometryStylePriorityList;
        Params.CommonPartType = CommonPartType;
        Params.OutGeometryStyle = OutGeometryStyle;
        Params.CommonPartsMeshPath = CommonPartsMeshPath;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        GeometryStylePriorityList = Params.GeometryStylePriorityList;
        OutGeometryStyle = Params.OutGeometryStyle;
    
        return Params.ReturnValue;
    }

    TArray<FString> UAtomPrimitiveGeometry::GetMaterialNames()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.GetMaterialNames");
    
        UAtomPrimitiveGeometry___GetMaterialNames_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAtomPrimitiveGeometry::GetNumberOfCommonPartLODs(FString ExportStyleName, EAtomCommonPartType CommonPartType, FString CommonPartsMeshPath)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.GetNumberOfCommonPartLODs");
    
        UAtomPrimitiveGeometry___GetNumberOfCommonPartLODs_Params Params{};
        Params.ExportStyleName = ExportStyleName;
        Params.CommonPartType = CommonPartType;
        Params.CommonPartsMeshPath = CommonPartsMeshPath;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometry::SetMaterialName(FString Name, int32 PolygonGroupIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.SetMaterialName");
    
        UAtomPrimitiveGeometry___SetMaterialName_Params Params{};
        Params.Name = Name;
        Params.PolygonGroupIndex = PolygonGroupIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometry::SetTiledUVs(float TileSize)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.SetTiledUVs");
    
        UAtomPrimitiveGeometry___SetTiledUVs_Params Params{};
        Params.TileSize = TileSize;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometry::SetVertexColor(FColor& Color)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.SetVertexColor");
    
        UAtomPrimitiveGeometry___SetVertexColor_Params Params{};
        Params.Color = Color;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Color = Params.Color;
    
        return Params.ReturnValue;
    }

    TArray<UAtomPrimitiveGeometry*> UAtomPrimitiveGeometry::SplitByPolygonGroup(bool bIgnoreEmptyGroups)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.SplitByPolygonGroup");
    
        UAtomPrimitiveGeometry___SplitByPolygonGroup_Params Params{};
        Params.bIgnoreEmptyGroups = bIgnoreEmptyGroups;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UStaticMesh* UAtomPrimitiveGeometry::ToSimplifiedStaticMesh(float Scale, UObject* Outer, FString Name, bool bFastBuild)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometry.ToSimplifiedStaticMesh");
    
        UAtomPrimitiveGeometry___ToSimplifiedStaticMesh_Params Params{};
        Params.Scale = Scale;
        Params.Outer = Outer;
        Params.Name = Name;
        Params.bFastBuild = bFastBuild;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FString> UAtomPrimitiveGeometryContainer::GetAllOtherPartNames()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetAllOtherPartNames");
    
        UAtomPrimitiveGeometryContainer___GetAllOtherPartNames_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FString> UAtomPrimitiveGeometryContainer::GetAllUncommonPartNames()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetAllUncommonPartNames");
    
        UAtomPrimitiveGeometryContainer___GetAllUncommonPartNames_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FAtomPrimitiveGeometryAndTransform> UAtomPrimitiveGeometryContainer::GetCapsGeometry(int32 ColorChangeIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetCapsGeometry");
    
        UAtomPrimitiveGeometryContainer___GetCapsGeometry_Params Params{};
        Params.ColorChangeIndex = ColorChangeIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FAtomPrimitiveGeometryAndTransform> UAtomPrimitiveGeometryContainer::GetCollisionGeometry()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetCollisionGeometry");
    
        UAtomPrimitiveGeometryContainer___GetCollisionGeometry_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FTransform> UAtomPrimitiveGeometryContainer::GetDefaultBoneTransforms(float Scale)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetDefaultBoneTransforms");
    
        UAtomPrimitiveGeometryContainer___GetDefaultBoneTransforms_Params Params{};
        Params.Scale = Scale;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FAtomPrimitiveGeometryAndTransform> UAtomPrimitiveGeometryContainer::GetDetailsGeometry(int32 ColorChangeIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetDetailsGeometry");
    
        UAtomPrimitiveGeometryContainer___GetDetailsGeometry_Params Params{};
        Params.ColorChangeIndex = ColorChangeIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FString UAtomPrimitiveGeometryContainer::GetExportStyleName()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetExportStyleName");
    
        UAtomPrimitiveGeometryContainer___GetExportStyleName_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometryContainer::GetGeometry(EPrimitiveGeometryComplexity PrimitiveGeometryComplexity)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetGeometry");
    
        UAtomPrimitiveGeometryContainer___GetGeometry_Params Params{};
        Params.PrimitiveGeometryComplexity = PrimitiveGeometryComplexity;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FString UAtomPrimitiveGeometryContainer::GetGeometryOtherPartName(EAtomPrimitiveGeometryOtherPartType OtherPartType)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetGeometryOtherPartName");
    
        UAtomPrimitiveGeometryContainer___GetGeometryOtherPartName_Params Params{};
        Params.OtherPartType = OtherPartType;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometryContainer::GetGeometrySection(int32 PrimitiveGeometrySectionFlag)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetGeometrySection");
    
        UAtomPrimitiveGeometryContainer___GetGeometrySection_Params Params{};
        Params.PrimitiveGeometrySectionFlag = PrimitiveGeometrySectionFlag;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometryContainer::GetGeometrySectionWithFilter(int32 PrimitiveGeometrySectionFlag, FAtomPrimitiveGeometrySectionFilterParams& FilterParams)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetGeometrySectionWithFilter");
    
        UAtomPrimitiveGeometryContainer___GetGeometrySectionWithFilter_Params Params{};
        Params.PrimitiveGeometrySectionFlag = PrimitiveGeometrySectionFlag;
        Params.FilterParams = FilterParams;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        FilterParams = Params.FilterParams;
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometryContainer::GetGeometrySectionWithMaterialNames(int32 PrimitiveGeometrySectionFlags, FString ShellMaterial, FString UndersideMaterial)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetGeometrySectionWithMaterialNames");
    
        UAtomPrimitiveGeometryContainer___GetGeometrySectionWithMaterialNames_Params Params{};
        Params.PrimitiveGeometrySectionFlags = PrimitiveGeometrySectionFlags;
        Params.ShellMaterial = ShellMaterial;
        Params.UndersideMaterial = UndersideMaterial;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FString UAtomPrimitiveGeometryContainer::GetGeometryUncommonPartName(EAtomPrimitiveGeometryUncommonPartType UncommonPartType)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetGeometryUncommonPartName");
    
        UAtomPrimitiveGeometryContainer___GetGeometryUncommonPartName_Params Params{};
        Params.UncommonPartType = UncommonPartType;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometryContainer::GetGeometryWithMaterialNames(EPrimitiveGeometryComplexity PrimitiveGeometryComplexity, FString ShellMaterial, FString UndersideMaterial)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetGeometryWithMaterialNames");
    
        UAtomPrimitiveGeometryContainer___GetGeometryWithMaterialNames_Params Params{};
        Params.PrimitiveGeometryComplexity = PrimitiveGeometryComplexity;
        Params.ShellMaterial = ShellMaterial;
        Params.UndersideMaterial = UndersideMaterial;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAtomPrimitiveGeometryContainer::GetLOD()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetLOD");
    
        UAtomPrimitiveGeometryContainer___GetLOD_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FAtomPrimitiveGeometryAndTransform> UAtomPrimitiveGeometryContainer::GetOtherCapsGeometry(int32 ColorChangeIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetOtherCapsGeometry");
    
        UAtomPrimitiveGeometryContainer___GetOtherCapsGeometry_Params Params{};
        Params.ColorChangeIndex = ColorChangeIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FAtomPrimitiveGeometryAndTransform> UAtomPrimitiveGeometryContainer::GetOtherPartsGeometry(int32 ColorChangeIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetOtherPartsGeometry");
    
        UAtomPrimitiveGeometryContainer___GetOtherPartsGeometry_Params Params{};
        Params.ColorChangeIndex = ColorChangeIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FAtomPrimitiveGeometryAndTransform> UAtomPrimitiveGeometryContainer::GetOtherPartsGeometryWithFilter(FAtomPrimitiveGeometrySectionFilterParams& FilterParams)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetOtherPartsGeometryWithFilter");
    
        UAtomPrimitiveGeometryContainer___GetOtherPartsGeometryWithFilter_Params Params{};
        Params.FilterParams = FilterParams;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        FilterParams = Params.FilterParams;
    
        return Params.ReturnValue;
    }

    TArray<FAtomPrimitiveGeometryAndTransform> UAtomPrimitiveGeometryContainer::GetScaledCapsGeometry(float Scale)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetScaledCapsGeometry");
    
        UAtomPrimitiveGeometryContainer___GetScaledCapsGeometry_Params Params{};
        Params.Scale = Scale;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FAtomPrimitiveGeometryAndTransform> UAtomPrimitiveGeometryContainer::GetScaledCollisionGeometry(float Scale)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetScaledCollisionGeometry");
    
        UAtomPrimitiveGeometryContainer___GetScaledCollisionGeometry_Params Params{};
        Params.Scale = Scale;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FAtomPrimitiveGeometryAndTransform> UAtomPrimitiveGeometryContainer::GetScaledDetailsGeometry(float Scale)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetScaledDetailsGeometry");
    
        UAtomPrimitiveGeometryContainer___GetScaledDetailsGeometry_Params Params{};
        Params.Scale = Scale;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAtomPrimitiveGeometry* UAtomPrimitiveGeometryContainer::GetScaledGeometry(EPrimitiveGeometryComplexity PrimitiveGeometryComplexity, float Scale)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetScaledGeometry");
    
        UAtomPrimitiveGeometryContainer___GetScaledGeometry_Params Params{};
        Params.PrimitiveGeometryComplexity = PrimitiveGeometryComplexity;
        Params.Scale = Scale;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FAtomPrimitiveGeometryAndTransform UAtomPrimitiveGeometryContainer::GetScaledShellGeometry(float Scale)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetScaledShellGeometry");
    
        UAtomPrimitiveGeometryContainer___GetScaledShellGeometry_Params Params{};
        Params.Scale = Scale;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAtomPrimitiveGeometryContainer::GetSectionTextureName(EPrimitiveGeometrySectionFlag SectionType, EAtomPrimitiveDetailTextureType TextureType, FString& OutTextureName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetSectionTextureName");
    
        UAtomPrimitiveGeometryContainer___GetSectionTextureName_Params Params{};
        Params.SectionType = SectionType;
        Params.TextureType = TextureType;
        Params.OutTextureName = OutTextureName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutTextureName = Params.OutTextureName;
    
        return Params.ReturnValue;
    }

    FAtomPrimitiveGeometryAndTransform UAtomPrimitiveGeometryContainer::GetShellGeometry(int32 ColorChangeIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetShellGeometry");
    
        UAtomPrimitiveGeometryContainer___GetShellGeometry_Params Params{};
        Params.ColorChangeIndex = ColorChangeIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FAtomPrimitiveGeometryAndTransform> UAtomPrimitiveGeometryContainer::GetTechnicCapsGeometry(int32 ColorChangeIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetTechnicCapsGeometry");
    
        UAtomPrimitiveGeometryContainer___GetTechnicCapsGeometry_Params Params{};
        Params.ColorChangeIndex = ColorChangeIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FAtomPrimitiveGeometryAndTransform> UAtomPrimitiveGeometryContainer::GetTechnicConnectorsGeometry(int32 ColorChangeIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetTechnicConnectorsGeometry");
    
        UAtomPrimitiveGeometryContainer___GetTechnicConnectorsGeometry_Params Params{};
        Params.ColorChangeIndex = ColorChangeIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FAtomPrimitiveGeometryAndTransform> UAtomPrimitiveGeometryContainer::GetUncommonPartsGeometry(int32 ColorChangeIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetUncommonPartsGeometry");
    
        UAtomPrimitiveGeometryContainer___GetUncommonPartsGeometry_Params Params{};
        Params.ColorChangeIndex = ColorChangeIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FAtomPrimitiveGeometryAndTransform> UAtomPrimitiveGeometryContainer::GetUncommonPartsGeometryWithFilter(FAtomPrimitiveGeometrySectionFilterParams& FilterParams)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.GetUncommonPartsGeometryWithFilter");
    
        UAtomPrimitiveGeometryContainer___GetUncommonPartsGeometryWithFilter_Params Params{};
        Params.FilterParams = FilterParams;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        FilterParams = Params.FilterParams;
    
        return Params.ReturnValue;
    }

    bool UAtomPrimitiveGeometryContainer::HasCollisionGeometry()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.HasCollisionGeometry");
    
        UAtomPrimitiveGeometryContainer___HasCollisionGeometry_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FAtomPrimitiveCollisionGeometry UAtomPrimitiveGeometryContainer::MakePrimitiveCollisionGeometry(float Scale)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomPrimitiveGeometryContainer.MakePrimitiveCollisionGeometry");
    
        UAtomPrimitiveGeometryContainer___MakePrimitiveCollisionGeometry_Params Params{};
        Params.Scale = Scale;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FAtomProcessorResult UAtomProcessorBlueprintLibrary::AppendAtomProcessorResult(FAtomProcessorResult& Result, FAtomProcessorResult& ResultToAppend)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomProcessorBlueprintLibrary.AppendAtomProcessorResult");
    
        UAtomProcessorBlueprintLibrary___AppendAtomProcessorResult_Params Params{};
        Params.Result = Result;
        Params.ResultToAppend = ResultToAppend;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Result = Params.Result;
        ResultToAppend = Params.ResultToAppend;
    
        return Params.ReturnValue;
    }

    UAtomModelProcessor* UAtomProcessorBlueprintLibrary::GetModelProcessor(FAtomModelProcessorInstance& ProcessorInstance)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomProcessorBlueprintLibrary.GetModelProcessor");
    
        UAtomProcessorBlueprintLibrary___GetModelProcessor_Params Params{};
        Params.ProcessorInstance = ProcessorInstance;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ProcessorInstance = Params.ProcessorInstance;
    
        return Params.ReturnValue;
    }

    UClass* UAtomProcessorBlueprintLibrary::GetProcessorClass(FAtomModelProcessorInstance& ProcessorInstance)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomProcessorBlueprintLibrary.GetProcessorClass");
    
        UAtomProcessorBlueprintLibrary___GetProcessorClass_Params Params{};
        Params.ProcessorInstance = ProcessorInstance;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ProcessorInstance = Params.ProcessorInstance;
    
        return Params.ReturnValue;
    }

    bool UAtomProcessorBlueprintLibrary::IsValid(FAtomModelProcessorInstance& ProcessorInstance)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomProcessorBlueprintLibrary.IsValid");
    
        UAtomProcessorBlueprintLibrary___IsValid_Params Params{};
        Params.ProcessorInstance = ProcessorInstance;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ProcessorInstance = Params.ProcessorInstance;
    
        return Params.ReturnValue;
    }

    void UAtomProcessorBlueprintLibrary::SetModelProcessor(FAtomModelProcessorInstance& ProcessorInstance, UAtomModelProcessor* ModelProcessor, bool bUseCustomSettings)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomProcessorBlueprintLibrary.SetModelProcessor");
    
        UAtomProcessorBlueprintLibrary___SetModelProcessor_Params Params{};
        Params.ProcessorInstance = ProcessorInstance;
        Params.ModelProcessor = ModelProcessor;
        Params.bUseCustomSettings = bUseCustomSettings;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ProcessorInstance = Params.ProcessorInstance;
    }

    FString IAtomRejectionReason::GetRejectionMessage()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomRejectionReason.GetRejectionMessage");
    
        IAtomRejectionReason___GetRejectionMessage_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TMap<int32, FAtomColorInfo> UAtomRuntimeBlueprintLibrary::GetAllColorInfo()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomRuntimeBlueprintLibrary.GetAllColorInfo");
    
        UAtomRuntimeBlueprintLibrary___GetAllColorInfo_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAtomRuntimeBlueprintLibrary::GetBitPackForColor(FColor& Color)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomRuntimeBlueprintLibrary.GetBitPackForColor");
    
        UAtomRuntimeBlueprintLibrary___GetBitPackForColor_Params Params{};
        Params.Color = Color;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Color = Params.Color;
    
        return Params.ReturnValue;
    }

    int32 UAtomRuntimeBlueprintLibrary::GetBitPackForColorId(int32 AtomColorId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomRuntimeBlueprintLibrary.GetBitPackForColorId");
    
        UAtomRuntimeBlueprintLibrary___GetBitPackForColorId_Params Params{};
        Params.AtomColorId = AtomColorId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAtomRuntimeBlueprintLibrary::GetBitPackForLUTMaterial(int32 ColorId, FGuid& PrimitiveUUID, int32 VariantId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomRuntimeBlueprintLibrary.GetBitPackForLUTMaterial");
    
        UAtomRuntimeBlueprintLibrary___GetBitPackForLUTMaterial_Params Params{};
        Params.ColorId = ColorId;
        Params.PrimitiveUUID = PrimitiveUUID;
        Params.VariantId = VariantId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PrimitiveUUID = Params.PrimitiveUUID;
    
        return Params.ReturnValue;
    }

    void UAtomRuntimeBlueprintLibrary::GetCommonPartAssetDescriptionFromStaticMesh(UStaticMesh* StaticMesh, FAtomCommonPartAssetDescription& OutDescription, EGetCommonPartDescriptionResult& OutIsValid)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomRuntimeBlueprintLibrary.GetCommonPartAssetDescriptionFromStaticMesh");
    
        UAtomRuntimeBlueprintLibrary___GetCommonPartAssetDescriptionFromStaticMesh_Params Params{};
        Params.StaticMesh = StaticMesh;
        Params.OutDescription = OutDescription;
        Params.OutIsValid = OutIsValid;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutDescription = Params.OutDescription;
        OutIsValid = Params.OutIsValid;
    }

    EAtomCommonPartCategory UAtomRuntimeBlueprintLibrary::GetCommonPartCategoryFromType(EAtomCommonPartType CommonPartType)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomRuntimeBlueprintLibrary.GetCommonPartCategoryFromType");
    
        UAtomRuntimeBlueprintLibrary___GetCommonPartCategoryFromType_Params Params{};
        Params.CommonPartType = CommonPartType;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAtomRuntimeBlueprintLibrary::GetCommonPartDescriptionFromType(EAtomCommonPartType CommonPartType, FAtomCommonPartDescription& OutDescription)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomRuntimeBlueprintLibrary.GetCommonPartDescriptionFromType");
    
        UAtomRuntimeBlueprintLibrary___GetCommonPartDescriptionFromType_Params Params{};
        Params.CommonPartType = CommonPartType;
        Params.OutDescription = OutDescription;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutDescription = Params.OutDescription;
    }

    FAtomColorInfo UAtomRuntimeBlueprintLibrary::GetInfoForColorId(int32 ColorId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomRuntimeBlueprintLibrary.GetInfoForColorId");
    
        UAtomRuntimeBlueprintLibrary___GetInfoForColorId_Params Params{};
        Params.ColorId = ColorId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UDataTable* UAtomRuntimeSettings::GetAtomEditorModeColorDataTable()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomRuntimeSettings.GetAtomEditorModeColorDataTable");
    
        UAtomRuntimeSettings___GetAtomEditorModeColorDataTable_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UDataTable* UAtomRuntimeSettings::GetColorDataTable()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.AtomRuntimeSettings.GetColorDataTable");
    
        UAtomRuntimeSettings___GetColorDataTable_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UConnectivityBlueprintLibrary::AreActorsConnected(AActor* ActorA, AActor* ActorB, UConnectivityRegistration* ConnectivityRegistration)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.ConnectivityBlueprintLibrary.AreActorsConnected");
    
        UConnectivityBlueprintLibrary___AreActorsConnected_Params Params{};
        Params.ActorA = ActorA;
        Params.ActorB = ActorB;
        Params.ConnectivityRegistration = ConnectivityRegistration;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool IDirectPlacement::TryDirectPlacement(FPlacementOperation& InPlacementOperation, FPlacementContextData& InPlacementContextData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.DirectPlacement.TryDirectPlacement");
    
        IDirectPlacement___TryDirectPlacement_Params Params{};
        Params.InPlacementOperation = InPlacementOperation;
        Params.InPlacementContextData = InPlacementContextData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InPlacementOperation = Params.InPlacementOperation;
        InPlacementContextData = Params.InPlacementContextData;
    
        return Params.ReturnValue;
    }

    AActor* UDirectSnapPlacementTool::PickActorToDrag(FRay& CastRay)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.DirectSnapPlacementTool.PickActorToDrag");
    
        UDirectSnapPlacementTool___PickActorToDrag_Params Params{};
        Params.CastRay = CastRay;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        CastRay = Params.CastRay;
    
        return Params.ReturnValue;
    }

    AActor* IDragPlacement::PickActorToDrag(FRay& CastRay)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.DragPlacement.PickActorToDrag");
    
        IDragPlacement___PickActorToDrag_Params Params{};
        Params.CastRay = CastRay;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        CastRay = Params.CastRay;
    
        return Params.ReturnValue;
    }

    FPlacementOperation UPlacementOperationBlueprintLibrary::MakeDragPlacementOperation(TArray<AActor*>& Actors, FTransform& StartTransform, FVector& DragLocation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.PlacementOperationBlueprintLibrary.MakeDragPlacementOperation");
    
        UPlacementOperationBlueprintLibrary___MakeDragPlacementOperation_Params Params{};
        Params.Actors = Actors;
        Params.StartTransform = StartTransform;
        Params.DragLocation = DragLocation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Actors = Params.Actors;
        StartTransform = Params.StartTransform;
        DragLocation = Params.DragLocation;
    
        return Params.ReturnValue;
    }

    FPlacementOperation UPlacementOperationBlueprintLibrary::MakePlacementOperation(TArray<AActor*>& Actors, FTransform& StartTransform)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.PlacementOperationBlueprintLibrary.MakePlacementOperation");
    
        UPlacementOperationBlueprintLibrary___MakePlacementOperation_Params Params{};
        Params.Actors = Actors;
        Params.StartTransform = StartTransform;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Actors = Params.Actors;
        StartTransform = Params.StartTransform;
    
        return Params.ReturnValue;
    }

    AActor* UWorldConnectivityBlueprintLibrary::GetActor(UObject* WorldContext, FWorldConnectivityHandle& Handle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivityBlueprintLibrary.GetActor");
    
        UWorldConnectivityBlueprintLibrary___GetActor_Params Params{};
        Params.WorldContext = WorldContext;
        Params.Handle = Handle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Handle = Params.Handle;
    
        return Params.ReturnValue;
    }

    FVector UWorldConnectivityBlueprintLibrary::GetFieldCenter(UObject* WorldContext, FPlanarFieldInfo& Field)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivityBlueprintLibrary.GetFieldCenter");
    
        UWorldConnectivityBlueprintLibrary___GetFieldCenter_Params Params{};
        Params.WorldContext = WorldContext;
        Params.Field = Field;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Field = Params.Field;
    
        return Params.ReturnValue;
    }

    FTransform UWorldConnectivityBlueprintLibrary::GetTransform(UObject* WorldContext, FWorldConnectivityHandle& Handle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivityBlueprintLibrary.GetTransform");
    
        UWorldConnectivityBlueprintLibrary___GetTransform_Params Params{};
        Params.WorldContext = WorldContext;
        Params.Handle = Handle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Handle = Params.Handle;
    
        return Params.ReturnValue;
    }

    bool UWorldConnectivityBlueprintLibrary::IsValid(FWorldConnectivityHandle& Handle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivityBlueprintLibrary.IsValid");
    
        UWorldConnectivityBlueprintLibrary___IsValid_Params Params{};
        Params.Handle = Handle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Handle = Params.Handle;
    
        return Params.ReturnValue;
    }

    void UWorldConnectivitySubsystem::DisconnectAllObjectConnections(FWorldConnectivityHandle Object)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.DisconnectAllObjectConnections");
    
        UWorldConnectivitySubsystem___DisconnectAllObjectConnections_Params Params{};
        Params.Object = Object;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UWorldConnectivitySubsystem::DisconnectObjects(FWorldConnectivityHandle ObjectA, FWorldConnectivityHandle ObjectB)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.DisconnectObjects");
    
        UWorldConnectivitySubsystem___DisconnectObjects_Params Params{};
        Params.ObjectA = ObjectA;
        Params.ObjectB = ObjectB;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    AActor* UWorldConnectivitySubsystem::GetActor(FWorldConnectivityHandle Handle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.GetActor");
    
        UWorldConnectivitySubsystem___GetActor_Params Params{};
        Params.Handle = Handle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAtomModel* UWorldConnectivitySubsystem::GetAtomModel(AActor* Actor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.GetAtomModel");
    
        UWorldConnectivitySubsystem___GetAtomModel_Params Params{};
        Params.Actor = Actor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAtomModelAssetUserData* UWorldConnectivitySubsystem::GetAtomModelAssetUserData(UObject* Object)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.GetAtomModelAssetUserData");
    
        UWorldConnectivitySubsystem___GetAtomModelAssetUserData_Params Params{};
        Params.Object = Object;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FPlanarFieldInfo UWorldConnectivitySubsystem::GetClosestFieldToPoint(FWorldConnectivityHandle Handle, FVector& WorldLocation, EConnectionFieldGender Type, bool& bSuccess)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.GetClosestFieldToPoint");
    
        UWorldConnectivitySubsystem___GetClosestFieldToPoint_Params Params{};
        Params.Handle = Handle;
        Params.WorldLocation = WorldLocation;
        Params.Type = Type;
        Params.bSuccess = bSuccess;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        WorldLocation = Params.WorldLocation;
        bSuccess = Params.bSuccess;
    
        return Params.ReturnValue;
    }

    TArray<FWorldConnectivityHandle> UWorldConnectivitySubsystem::GetConnectedObjects(FWorldConnectivityHandle Object)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.GetConnectedObjects");
    
        UWorldConnectivitySubsystem___GetConnectedObjects_Params Params{};
        Params.Object = Object;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FWorldConnectivityHandle> UWorldConnectivitySubsystem::GetConnectedObjectsRecursively(FWorldConnectivityHandle Object)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.GetConnectedObjectsRecursively");
    
        UWorldConnectivitySubsystem___GetConnectedObjectsRecursively_Params Params{};
        Params.Object = Object;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FWorldConnectivityHandle UWorldConnectivitySubsystem::GetConnectivityHandle(AActor* Actor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.GetConnectivityHandle");
    
        UWorldConnectivitySubsystem___GetConnectivityHandle_Params Params{};
        Params.Actor = Actor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FWorldConnectivityHandle> UWorldConnectivitySubsystem::GetConnectivityHandles(AActor* Actor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.GetConnectivityHandles");
    
        UWorldConnectivitySubsystem___GetConnectivityHandles_Params Params{};
        Params.Actor = Actor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FVector UWorldConnectivitySubsystem::GetOverlapPenetrationDepth(AStaticMeshActor* Actor1, AStaticMeshActor* Actor2, FVector Offset)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.GetOverlapPenetrationDepth");
    
        UWorldConnectivitySubsystem___GetOverlapPenetrationDepth_Params Params{};
        Params.Actor1 = Actor1;
        Params.Actor2 = Actor2;
        Params.Offset = Offset;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FVector UWorldConnectivitySubsystem::GetPlanarFieldCenter(FPlanarFieldInfo& Field)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.GetPlanarFieldCenter");
    
        UWorldConnectivitySubsystem___GetPlanarFieldCenter_Params Params{};
        Params.Field = Field;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Field = Params.Field;
    
        return Params.ReturnValue;
    }

    TArray<FPlanarFieldInfo> UWorldConnectivitySubsystem::GetPlanarFields(FWorldConnectivityHandle Handle, EConnectionFieldGender Type)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.GetPlanarFields");
    
        UWorldConnectivitySubsystem___GetPlanarFields_Params Params{};
        Params.Handle = Handle;
        Params.Type = Type;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FTransform UWorldConnectivitySubsystem::GetTransform(FWorldConnectivityHandle Handle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.GetTransform");
    
        UWorldConnectivitySubsystem___GetTransform_Params Params{};
        Params.Handle = Handle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    double UWorldConnectivitySubsystem::PlanarGridStepSize()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.PlanarGridStepSize");
    
        UWorldConnectivitySubsystem___PlanarGridStepSize_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UWorldConnectivitySubsystem::RegisterAtomActor(AActor* Actor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.RegisterAtomActor");
    
        UWorldConnectivitySubsystem___RegisterAtomActor_Params Params{};
        Params.Actor = Actor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UWorldConnectivitySubsystem::RegisterConnectivityActor(AActor* Actor, UAtomModel* Model)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.RegisterConnectivityActor");
    
        UWorldConnectivitySubsystem___RegisterConnectivityActor_Params Params{};
        Params.Actor = Actor;
        Params.Model = Model;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UWorldConnectivitySubsystem::RegisterCustomConnectivityActor(AActor* Actor, FSerializedConnectivityObjects& ConnectivityObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.RegisterCustomConnectivityActor");
    
        UWorldConnectivitySubsystem___RegisterCustomConnectivityActor_Params Params{};
        Params.Actor = Actor;
        Params.ConnectivityObject = ConnectivityObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ConnectivityObject = Params.ConnectivityObject;
    }

    void UWorldConnectivitySubsystem::RegisterModelActor(AActor* Actor, FSerializedConnectivityObjects& Connections)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.RegisterModelActor");
    
        UWorldConnectivitySubsystem___RegisterModelActor_Params Params{};
        Params.Actor = Actor;
        Params.Connections = Connections;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Connections = Params.Connections;
    }

    TArray<FConnectivityQueryResult> UWorldConnectivitySubsystem::RunPlanarConnectivityQuery(AActor* AtomActorToPlace, AActor* AtomActorToConnect, FVector& QueryStartLocation, FVector& QueryEndLocation, TEnumAsByte<ECollisionChannel> QueryCollisionChannel, int32 QueryRadius, bool bPerformConnectionOnSuccess)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.RunPlanarConnectivityQuery");
    
        UWorldConnectivitySubsystem___RunPlanarConnectivityQuery_Params Params{};
        Params.AtomActorToPlace = AtomActorToPlace;
        Params.AtomActorToConnect = AtomActorToConnect;
        Params.QueryStartLocation = QueryStartLocation;
        Params.QueryEndLocation = QueryEndLocation;
        Params.QueryCollisionChannel = QueryCollisionChannel;
        Params.QueryRadius = QueryRadius;
        Params.bPerformConnectionOnSuccess = bPerformConnectionOnSuccess;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        QueryStartLocation = Params.QueryStartLocation;
        QueryEndLocation = Params.QueryEndLocation;
    
        return Params.ReturnValue;
    }

    bool UWorldConnectivitySubsystem::TryConnectObjectAtLocation(FWorldConnectivityHandle ObjectToConnect, FTransform& DesiredObjectTransform, TArray<FWorldConnectivityHandle>& ConnectionCandidates, bool PerformConnection)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.TryConnectObjectAtLocation");
    
        UWorldConnectivitySubsystem___TryConnectObjectAtLocation_Params Params{};
        Params.ObjectToConnect = ObjectToConnect;
        Params.DesiredObjectTransform = DesiredObjectTransform;
        Params.ConnectionCandidates = ConnectionCandidates;
        Params.PerformConnection = PerformConnection;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        DesiredObjectTransform = Params.DesiredObjectTransform;
        ConnectionCandidates = Params.ConnectionCandidates;
    
        return Params.ReturnValue;
    }

    void UWorldConnectivitySubsystem::UnregisterConnectivityActor(AActor* Actor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AtomRuntime.WorldConnectivitySubsystem.UnregisterConnectivityActor");
    
        UWorldConnectivitySubsystem___UnregisterConnectivityActor_Params Params{};
        Params.Actor = Actor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

