/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BattleRoyaleFrontend_Functions
 * ============================================================
 */

#include "BattleRoyaleFrontend.hpp"

namespace UE
{

    struct UBattleRoyaleFrontendExperienceFlow___HandleVideoTerminalError_Params
    {
        EBaseMediaTerminalErrorReason   Reason; // 0x000000 (0x000001) [Default: EBaseMediaTerminalErrorReason(224)]
    };

} // namespace UE

