/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BeanstalkDevicesCoreRuntime_Functions
 * ============================================================
 */

#include "BeanstalkDevicesCoreRuntime_Functions.hpp"

namespace UE
{

    void ABeanObstacleTickManager::OnTickableComponentEndPlay(AActor* Actor, TEnumAsByte<EEndPlayReason> EndPlayReason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkDevicesCoreRuntime.BeanObstacleTickManager.OnTickableComponentEndPlay");
    
        ABeanObstacleTickManager___OnTickableComponentEndPlay_Params Params{};
        Params.Actor = Actor;
        Params.EndPlayReason = EndPlayReason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    FVector UBeanDeviceFunctionLibrary::CalculateKnockbackForce(FBeanKnockbackForceCalculator& KnockbackForceCalculator, FVector SourceLocation, FVector TargetLocation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkDevicesCoreRuntime.BeanDeviceFunctionLibrary.CalculateKnockbackForce");
    
        UBeanDeviceFunctionLibrary___CalculateKnockbackForce_Params Params{};
        Params.KnockbackForceCalculator = KnockbackForceCalculator;
        Params.SourceLocation = SourceLocation;
        Params.TargetLocation = TargetLocation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        KnockbackForceCalculator = Params.KnockbackForceCalculator;
    
        return Params.ReturnValue;
    }

    void UBeanObstacleImpactComponent::OnAffectedComponentHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, FHitResult& Hit)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkDevicesCoreRuntime.BeanObstacleImpactComponent.OnAffectedComponentHit");
    
        UBeanObstacleImpactComponent___OnAffectedComponentHit_Params Params{};
        Params.HitComponent = HitComponent;
        Params.OtherActor = OtherActor;
        Params.OtherComp = OtherComp;
        Params.NormalImpulse = NormalImpulse;
        Params.Hit = Hit;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Hit = Params.Hit;
    }

    void UBeanObstacleImpactComponent::OnSleepStateChanged(bool bIsSleeping)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkDevicesCoreRuntime.BeanObstacleImpactComponent.OnSleepStateChanged");
    
        UBeanObstacleImpactComponent___OnSleepStateChanged_Params Params{};
        Params.bIsSleeping = bIsSleeping;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UBeanObstacleMeshSelectorComponent::SetSelectedMeshIndex(int32 MeshIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkDevicesCoreRuntime.BeanObstacleMeshSelectorComponent.SetSelectedMeshIndex");
    
        UBeanObstacleMeshSelectorComponent___SetSelectedMeshIndex_Params Params{};
        Params.MeshIndex = MeshIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UBeanObstacleMovementComponent::IsMotionLocked()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkDevicesCoreRuntime.BeanObstacleMovementComponent.IsMotionLocked");
    
        UBeanObstacleMovementComponent___IsMotionLocked_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UBeanObstacleMovementComponent::IsRewinding()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkDevicesCoreRuntime.BeanObstacleMovementComponent.IsRewinding");
    
        UBeanObstacleMovementComponent___IsRewinding_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBeanObstacleMovementComponent::OnRep_ObstacleMotionRuntimeState(FBeanObstacleMotionRuntimeState& OldRuntimeState)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkDevicesCoreRuntime.BeanObstacleMovementComponent.OnRep_ObstacleMotionRuntimeState");
    
        UBeanObstacleMovementComponent___OnRep_ObstacleMotionRuntimeState_Params Params{};
        Params.OldRuntimeState = OldRuntimeState;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OldRuntimeState = Params.OldRuntimeState;
    }

    void UBeanObstacleMovementComponent::OnSleepStateChanged(bool bIsSleeping)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkDevicesCoreRuntime.BeanObstacleMovementComponent.OnSleepStateChanged");
    
        UBeanObstacleMovementComponent___OnSleepStateChanged_Params Params{};
        Params.bIsSleeping = bIsSleeping;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanObstacleMovementComponent::SetIsMotionLocked(bool bNewIsLocked, bool bResetToInitial)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkDevicesCoreRuntime.BeanObstacleMovementComponent.SetIsMotionLocked");
    
        UBeanObstacleMovementComponent___SetIsMotionLocked_Params Params{};
        Params.bNewIsLocked = bNewIsLocked;
        Params.bResetToInitial = bResetToInitial;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanObstacleMovementComponent::SetIsRewinding(bool bNewRewind)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkDevicesCoreRuntime.BeanObstacleMovementComponent.SetIsRewinding");
    
        UBeanObstacleMovementComponent___SetIsRewinding_Params Params{};
        Params.bNewRewind = bNewRewind;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanObstacleOptimizerComponent::OnOptimizerBeginOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, FHitResult& SweepResult)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkDevicesCoreRuntime.BeanObstacleOptimizerComponent.OnOptimizerBeginOverlap");
    
        UBeanObstacleOptimizerComponent___OnOptimizerBeginOverlap_Params Params{};
        Params.OverlappedComp = OverlappedComp;
        Params.OtherActor = OtherActor;
        Params.OtherComp = OtherComp;
        Params.OtherBodyIndex = OtherBodyIndex;
        Params.bFromSweep = bFromSweep;
        Params.SweepResult = SweepResult;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SweepResult = Params.SweepResult;
    }

    void UBeanObstacleOptimizerComponent::OnOptimizerEndOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkDevicesCoreRuntime.BeanObstacleOptimizerComponent.OnOptimizerEndOverlap");
    
        UBeanObstacleOptimizerComponent___OnOptimizerEndOverlap_Params Params{};
        Params.OverlappedComponent = OverlappedComponent;
        Params.OtherActor = OtherActor;
        Params.OtherComp = OtherComp;
        Params.OtherBodyIndex = OtherBodyIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanObstacleOptimizerComponent::OnOriginalOwnerEndPlay(AActor* Actor, TEnumAsByte<EEndPlayReason> EndPlayReason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkDevicesCoreRuntime.BeanObstacleOptimizerComponent.OnOriginalOwnerEndPlay");
    
        UBeanObstacleOptimizerComponent___OnOriginalOwnerEndPlay_Params Params{};
        Params.Actor = Actor;
        Params.EndPlayReason = EndPlayReason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanObstacleOptimizerComponent::RecalculateEstimatedBounds()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkDevicesCoreRuntime.BeanObstacleOptimizerComponent.RecalculateEstimatedBounds");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBeanObstacleOptimizerComponent::OnSleepStateChanged(bool bIsSleeping)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkDevicesCoreRuntime.BeanObstacleOptimizerComponent.OnSleepStateChanged");
    
        UBeanObstacleOptimizerComponent___OnSleepStateChanged_Params Params{};
        Params.bIsSleeping = bIsSleeping;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

