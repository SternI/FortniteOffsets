/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AscenderCodeRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000FD0 (0x0003C8)
    class alignas(0x8) AFortAscenderZipline : public AFortAthenaSplineZipline
    {
    public:
        MULTI_INLINE_DELEGATE(OnAscenderSetupComplete)  OnAscenderSetupComplete;                    // 0x000C08 (0x000010)
        FName                                           SplineTopAttachPointName;                   // 0x000C18 (0x000004) [Default: NAME_None]
        bool                                            bAutoFindSplineEndLocation;                 // 0x000C1C (0x000001) [Default: true]
        uint8                                           UnknownData_000C1D[0x000003];               // 0x000C1D (0x000003)
        float                                           SplineOffsetFromGround;                     // 0x000C20 (0x000004) [Default: 150f]
        float                                           CableOffsetFromSplineEnd;                   // 0x000C24 (0x000004) [Default: -100f]
        float                                           SplineLength;                               // 0x000C28 (0x000004) [Default: 5000f]
        uint8                                           UnknownData_000C2C[0x000004];               // 0x000C2C (0x000004)
        UStaticMesh*                                    SplineStaticMesh;                           // 0x000C30 (0x000008) [Default: nullptr]
        TEnumAsByte<ESplineMeshAxis>                    MeshForwardAxis;                            // 0x000C38 (0x000001) [Default: 2]
        bool                                            bHandleReturning;                           // 0x000C39 (0x000001) [Default: false]
        uint8                                           UnknownData_000C3A[0x000002];               // 0x000C3A (0x000002)
        float                                           HandleReturnSpeed;                          // 0x000C3C (0x000004) [Default: 500f]
        bool                                            bCableDropping;                             // 0x000C40 (0x000001) [Default: false]
        uint8                                           UnknownData_000C41[0x000003];               // 0x000C41 (0x000003)
        float                                           CableDropSpeed;                             // 0x000C44 (0x000004) [Default: 500f]
        bool                                            bLockPawnRotationWhileUsing;                // 0x000C48 (0x000001) [Default: true]
        bool                                            bApplyHolsterWhileUsing;                    // 0x000C49 (0x000001) [Default: true]
        uint8                                           UnknownData_000C4A[0x000002];               // 0x000C4A (0x000002)
        float                                           YawRotationOffsetWhileUsingHandle;          // 0x000C4C (0x000004) [Default: 180f]
        float                                           YawRotationOffsetWhileSlidingDown;          // 0x000C50 (0x000004) [Default: 180f]
        uint8                                           UnknownData_000C54[0x000004];               // 0x000C54 (0x000004)
        FGameplayTagContainer                           CancelAbilitiesWithTags;                    // 0x000C58 (0x000020)
        bool                                            bUseComplexSplineCollision;                 // 0x000C78 (0x000001) [Default: false]
        uint8                                           UnknownData_000C79[0x000003];               // 0x000C79 (0x000003)
        float                                           SimpleSplineCollisionRadius;                // 0x000C7C (0x000004) [Default: 125f]
        float                                           SimpleSplineCollisionHeightExtension;       // 0x000C80 (0x000004) [Default: 75f]
        float                                           ReachedTopLaunchAngle;                      // 0x000C84 (0x000004) [Default: 0f]
        FScalableFloat                                  DescendMinDistanceFromBottom;               // 0x000C88 (0x000028)
        FScalableFloat                                  AscendReachedEndHorizontalLaunchSpeed;      // 0x000CB0 (0x000028)
        FScalableFloat                                  AscendReachedEndVerticalLaunchSpeed;        // 0x000CD8 (0x000028)
        FScalableFloat                                  AscendMMEReachedEndHorizontalLaunchSpeed;   // 0x000D00 (0x000028)
        FScalableFloat                                  AscendMMEReachedEndVerticalLaunchSpeed;     // 0x000D28 (0x000028)
        FScalableFloat                                  AscendJumpedOffHorizontalLaunchSpeed;       // 0x000D50 (0x000028)
        FScalableFloat                                  AscendJumpedOffVerticalLaunchSpeed;         // 0x000D78 (0x000028)
        FScalableFloat                                  DescendReachedEndHorizontalLaunchSpeed;     // 0x000DA0 (0x000028)
        FScalableFloat                                  DescendReachedEndVerticalLaunchSpeed;       // 0x000DC8 (0x000028)
        FScalableFloat                                  DescendJumpedOffHorizontalLaunchSpeed;      // 0x000DF0 (0x000028)
        FScalableFloat                                  DescendJumpedOffVerticalLaunchSpeed;        // 0x000E18 (0x000028)
        FScalableFloat                                  HandleActorHitPlayerHorizontalLaunchSpeed;  // 0x000E40 (0x000028)
        FScalableFloat                                  HandleActorHitPlayerVerticalLaunchSpeed;    // 0x000E68 (0x000028)
        FVector                                         HandleDestroyBuildingsOverlapExtents;       // 0x000E90 (0x000018)
        FVector                                         PlayerDestroyBuildingsOverlapExtents;       // 0x000EA8 (0x000018)
        bool                                            bUseBakedEndLocation;                       // 0x000EC0 (0x000001) [Default: false]
        uint8                                           UnknownData_000EC1[0x000007];               // 0x000EC1 (0x000007)
        FVector                                         BakedEndLocation;                           // 0x000EC8 (0x000018)
        FVector                                         InitialSplineEndLocation;                   // 0x000EE0 (0x000018)
        FVector                                         CurrentSplineEndLocation;                   // 0x000EF8 (0x000018)
        FVector                                         TargetSplineEndLocation;                    // 0x000F10 (0x000018)
        FVector                                         CurrentHandleLocation;                      // 0x000F28 (0x000018)
        TWeakObjectPtr<UPrimitiveComponent>             CurrentInteractComponent;                   // 0x000F40 (0x000008) [Default: nullptr]
        TWeakObjectPtr<AFortPlayerPawn>                 PawnUsingHandle;                            // 0x000F48 (0x000008) [Default: nullptr]
        TWeakObjectPtr<AFortPlayerPawn>                 PreviousPawnUsingHandle;                    // 0x000F50 (0x000008) [Default: nullptr]
        USplineMeshComponent*                           SplineMesh;                                 // 0x000F58 (0x000008) [Default: nullptr]
        UCapsuleComponent*                              SimpleSplineMeshCollision;                  // 0x000F60 (0x000008) [Default: nullptr]
        TWeakObjectPtr<ABuildingActor>                  FloorActor;                                 // 0x000F68 (0x000008) [Default: nullptr]
        TArray<TWeakObjectPtr<AFortPlayerPawn>>         RotationLockedPawns;                        // 0x000F70 (0x000010)
        uint8                                           UnknownData_000F80[0x000040];               // 0x000F80 (0x000040)
        UFortLinkToActorComponent*                      LinkToActorComponent;                       // 0x000FC0 (0x000008) [Default: 0x7FE838B47FD0]
        UFortZiplineLinkComponent*                      ZiplineLinkComponent;                       // 0x000FC8 (0x000008) [Default: 0x7FE838B486C0]
    
    public: // Functions
        void                    ApplyStructureDamage(ABuildingSMActor* BuildingActor, AActor* DamageSource); // 0x000545D2 [Event | Public | BlueprintCallable | BlueprintEvent | Const]
        void                    BP_HandlePlayerStartedUsingHandle(AFortPlayerPawn* player); // 0x000545D2 [Event | Public | BlueprintEvent]
        void                    BP_HandlePlayerStoppedUsingHandle(AFortPlayerPawn* player); // 0x000545D2 [Event | Public | BlueprintEvent]
        void                    BP_HandleStartedLoweringCable(); // 0x000545D2 [Event | Public | BlueprintEvent]
        void                    BP_HandleStartedLoweringHandle(); // 0x000545D2 [Event | Public | BlueprintEvent]
        void                    BP_HandleStoppedLoweringCable(); // 0x000545D2 [Event | Public | BlueprintEvent]
        void                    BP_HandleStoppedLoweringHandle(); // 0x000545D2 [Event | Public | BlueprintEvent]
        void                    BP_HandleUpdatedLoweringCable(); // 0x000545D2 [Event | Public | BlueprintEvent]
        void                    BP_HandleUpdatedLoweringHandle(); // 0x000545D2 [Event | Public | BlueprintEvent]
        void                    BP_OnVolumeReady(); // 0x000545D2 [Event | Public | BlueprintEvent]
        void                    FindNewFloor(); // 0x10CD60F8 [Final | RequiredAPI | Native | Protected | BlueprintCallable]
        UPrimitiveComponent*    GetHandleComponent(); // 0x000545D2 [Event | Public | BlueprintCallable | BlueprintEvent | BlueprintPure | Const]
        UPrimitiveComponent*    GetInteractComponentOverride(AFortPlayerPawn* InteractingPawn, UPrimitiveComponent* InteractComponent); // 0x07F91664 [RequiredAPI | Native | Event | Public | BlueprintEvent | Const]
        AFortPlayerPawn*        GetPawnUsingHandle(); // 0x02113CBC [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UPrimitiveComponent*    GetTopComponent(); // 0x000545D2 [Event | Public | BlueprintCallable | BlueprintEvent | BlueprintPure | Const]
        void                    HandleFloorActorDestroyed(AActor* Actor); // 0x07F918F6 [Final | Native | Protected]
        void                    HandleFloorActorHealthChanged(); // 0x10CD6542 [Final | Native | Protected]
        void                    HandlePawnUsingHandleDied(AFortPawn* DeadPawn); // 0x07F91A60 [Final | Native | Protected]
        bool                    IsUsingHandle(AFortPawn* PawnToCheck); // 0x07F91BE4 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                    OnRep_InitialSplineEndLocation(); // 0x0B0078D4 [Final | Native | Protected]
        void                    OnRep_PawnUsingHandle(); // 0x01BBF046 [Final | Native | Protected]
        void                    OnRep_TargetSplineEndLocation(); // 0x0BA37D2E [Final | Native | Protected]
        void                    OnSpawningFromSaveFinish(); // 0x10CD67DE [Final | Native | Protected]
        void                    SetupAscender(bool bFromConstruction, bool bFromReplication); // 0x07F91D76 [Final | Native | Protected | BlueprintCallable]
        void                    SetupEventForSpatialGameplayVolume(); // 0x10CD68F6 [Final | Native | Protected | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class UFortCheatManager_AscenderZipline : public UChildCheatManager
    {
    public:
    
    public: // Functions
        void    RemoveAscenders(bool bRemoveAscendersOn); // 0x040ED1DC [Final | Exec | Native | Public]
    };
    // Size: 0x0000E0 (0x000020)
    class alignas(0x8) UFortPawnComponent_AscenderMontageProvider : public UPawnComponent
    {
    public:
        UAnimMontage*   M_Ascending;    // 0x0000C0 (0x000008) [Default: nullptr]
        UAnimMontage*   M_Descending;   // 0x0000C8 (0x000008) [Default: nullptr]
        UAnimMontage*   F_Ascending;    // 0x0000D0 (0x000008) [Default: nullptr]
        UAnimMontage*   F_Descending;   // 0x0000D8 (0x000008) [Default: nullptr]
    
    public: // Functions
        UAnimMontage*   GetSuitableMontage(bool bAscending); // 0x07F92A54 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure]
    };
}

