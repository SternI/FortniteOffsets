/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimationLocomotionLibraryRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class UAnimCharacterMovementLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FVector PredictGroundMovementPivotLocation(FVector& Acceleration, FVector& Velocity, float GroundFriction); // 0x07ED98C0 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        static FVector PredictGroundMovementStopLocation(FVector& Velocity, bool bUseSeparateBrakingFriction, float BrakingFriction, float GroundFriction, float BrakingFrictionFactor, float BrakingDecelerationWalking); // 0x07ED9C82 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
    };
    // Size: 0x000028 (0x000000)
    class UAnimDistanceMatchingLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FSequenceEvaluatorReference AdvanceTimeByDistanceMatching(FAnimUpdateContext& UpdateContext, FSequenceEvaluatorReference& SequenceEvaluator, float DistanceTraveled, FName DistanceCurveName, FVector2D PlayRateClamp); // 0x07EDA2EC [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static FSequenceEvaluatorReference DistanceMatchToTarget(FSequenceEvaluatorReference& SequenceEvaluator, float DistanceToTarget, FName DistanceCurveName); // 0x07EDA92C [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FSequencePlayerReference    SetPlayrateToMatchSpeed(FSequencePlayerReference& SequencePlayer, float SpeedToMatch, FVector2D PlayRateClamp); // 0x07EDAD06 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
}

