/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioSynesthesia_Functions
 * ============================================================
 */

#include "AudioSynesthesia.hpp"

namespace UE
{

    struct UConstantQAnalyzer___GetCenterFrequencies_Params
    {
        TArray<float>   OutCenterFrequencies;   // 0x000000 (0x000010) [OutParam]
    };

    struct UConstantQAnalyzer___GetNumCenterFrequencies_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344923952]
    };

    struct UConstantQNRT___GetChannelConstantQAtTime_Params
    {
        float           InSeconds;      // 0x000000 (0x000004) [Default: 1.44528e-26f]
        int32           InChannel;      // 0x000004 (0x000004) [Default: 0]
        TArray<float>   OutConstantQ;   // 0x000008 (0x000010) [OutParam]
    };

    struct UConstantQNRT___GetNormalizedChannelConstantQAtTime_Params
    {
        float           InSeconds;      // 0x000000 (0x000004) [Default: 1.44528e-26f]
        int32           InChannel;      // 0x000004 (0x000004) [Default: 0]
        TArray<float>   OutConstantQ;   // 0x000008 (0x000010) [OutParam]
    };

    struct ULKFSNRT___GetChannelLoudnessAtTime_Params
    {
        float   InSeconds;      // 0x000000 (0x000004) [Default: 1.44561e-26f]
        int32   InChannel;      // 0x000004 (0x000004) [Default: 0]
        float   OutLoudness;    // 0x000008 (0x000004) [OutParam] [Default: 6.86636e-44f]
    };

    struct ULKFSNRT___GetGatedLoudness_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.44561e-26f]
    };

    struct ULKFSNRT___GetGatedLoudnessForChannel_Params
    {
        int32   InChannel;      // 0x000000 (0x000004) [Default: 344926848]
        float   ReturnValue;    // 0x000004 (0x000004) [ReturnValue] [Default: 0f]
    };

    struct ULKFSNRT___GetIntegratedLoudness_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.44561e-26f]
    };

    struct ULKFSNRT___GetIntegratedLoudnessForChannel_Params
    {
        int32   InChannel;      // 0x000000 (0x000004) [Default: 344926848]
        float   ReturnValue;    // 0x000004 (0x000004) [ReturnValue] [Default: 0f]
    };

    struct ULKFSNRT___GetLoudnessAtTime_Params
    {
        float   InSeconds;      // 0x000000 (0x000004) [Default: 1.44561e-26f]
        float   OutLoudness;    // 0x000004 (0x000004) [OutParam] [Default: 0f]
    };

    struct ULKFSNRT___GetLoudnessData_Params
    {
        TArray<FLKFSNRTResults> ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct ULKFSNRT___GetLoudnessDataAtTime_Params
    {
        float           InSeconds;      // 0x000000 (0x000004) [Default: 1.44561e-26f]
        FLKFSNRTResults ReturnValue;    // 0x000004 (0x000014) [ReturnValue]
    };

    struct ULKFSNRT___GetLoudnessDataForChannel_Params
    {
        int32                   InChannel;                      // 0x000000 (0x000004) [Default: 344926848]
        uint8                   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FLKFSNRTResults> ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct ULKFSNRT___GetLoudnessDataForChannelAtTime_Params
    {
        float           InSeconds;      // 0x000000 (0x000004) [Default: 1.44561e-26f]
        int32           InChannel;      // 0x000004 (0x000004) [Default: 0]
        FLKFSNRTResults ReturnValue;    // 0x000008 (0x000014) [ReturnValue]
    };

    struct ULoudnessNRT___GetChannelLoudnessAtTime_Params
    {
        float   InSeconds;      // 0x000000 (0x000004) [Default: 1.44584e-26f]
        int32   InChannel;      // 0x000004 (0x000004) [Default: 0]
        float   OutLoudness;    // 0x000008 (0x000004) [OutParam] [Default: 6.86636e-44f]
    };

    struct ULoudnessNRT___GetLoudnessAtTime_Params
    {
        float   InSeconds;      // 0x000000 (0x000004) [Default: 1.44584e-26f]
        float   OutLoudness;    // 0x000004 (0x000004) [OutParam] [Default: 0f]
    };

    struct ULoudnessNRT___GetNormalizedChannelLoudnessAtTime_Params
    {
        float   InSeconds;      // 0x000000 (0x000004) [Default: 1.44584e-26f]
        int32   InChannel;      // 0x000004 (0x000004) [Default: 0]
        float   OutLoudness;    // 0x000008 (0x000004) [OutParam] [Default: 6.86636e-44f]
    };

    struct ULoudnessNRT___GetNormalizedLoudnessAtTime_Params
    {
        float   InSeconds;      // 0x000000 (0x000004) [Default: 1.44584e-26f]
        float   OutLoudness;    // 0x000004 (0x000004) [OutParam] [Default: 0f]
    };

    struct UOnsetNRT___GetChannelOnsetsBetweenTimes_Params
    {
        float           InStartSeconds;                 // 0x000000 (0x000004) [Default: 1.44605e-26f]
        float           InEndSeconds;                   // 0x000004 (0x000004) [Default: 0f]
        int32           InChannel;                      // 0x000008 (0x000004) [Default: 49]
        uint8           UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        TArray<float>   OutOnsetTimestamps;             // 0x000010 (0x000010) [OutParam]
        TArray<float>   OutOnsetStrengths;              // 0x000020 (0x000010) [OutParam]
    };

    struct UOnsetNRT___GetNormalizedChannelOnsetsBetweenTimes_Params
    {
        float           InStartSeconds;                 // 0x000000 (0x000004) [Default: 1.44605e-26f]
        float           InEndSeconds;                   // 0x000004 (0x000004) [Default: 0f]
        int32           InChannel;                      // 0x000008 (0x000004) [Default: 49]
        uint8           UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        TArray<float>   OutOnsetTimestamps;             // 0x000010 (0x000010) [OutParam]
        TArray<float>   OutOnsetStrengths;              // 0x000020 (0x000010) [OutParam]
    };

    struct USynesthesiaSpectrumAnalyzer___GetCenterFrequencies_Params
    {
        float           InSampleRate;                   // 0x000000 (0x000004) [Default: 1.44615e-26f]
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<float>   OutCenterFrequencies;           // 0x000008 (0x000010) [OutParam]
    };

    struct USynesthesiaSpectrumAnalyzer___GetNumCenterFrequencies_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344930384]
    };

} // namespace UE

