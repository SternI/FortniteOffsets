/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:12
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AssetRegistry
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class IAssetRegistry : public IInterface
    {
    public:
    
    public: // Functions
        bool        GetAllAssets(TArray<FAssetData>& OutAssetData, bool bIncludeOnlyOnDiskAssets); // 0x03FA1494 [Native | Public | HasOutParms | BlueprintCallable | Const]
        void        GetAllCachedPaths(TArray<FString>& OutPathList); // 0x03FA175A [Native | Public | HasOutParms | BlueprintCallable | Const]
        bool        GetAncestorClassNames(FTopLevelAssetPath ClassPathName, TArray<FTopLevelAssetPath>& OutAncestorClassNames); // 0x03FA18F8 [Native | Public | HasOutParms | BlueprintCallable | Const]
        FAssetData  GetAssetByObjectPath(FName ObjectPath, bool bIncludeOnlyOnDiskAssets); // 0x03FA1BA8 [Native | Public | BlueprintCallable | Const]
        bool        GetAssets(FARFilter& Filter, TArray<FAssetData>& OutAssetData, bool bSkipARFilteredAssets); // 0x03FA1ECC [Native | Public | HasOutParms | BlueprintCallable | Const]
        bool        GetAssetsByClass(FTopLevelAssetPath ClassPathName, TArray<FAssetData>& OutAssetData, bool bSearchSubClasses); // 0x03FA22EC [Native | Public | HasOutParms | BlueprintCallable | Const]
        bool        GetAssetsByPackageName(FName PackageName, TArray<FAssetData>& OutAssetData, bool bIncludeOnlyOnDiskAssets, bool bSkipARFilteredAssets); // 0x03FA26C4 [Native | Public | HasOutParms | BlueprintCallable | Const]
        bool        GetAssetsByPath(FName PackagePath, TArray<FAssetData>& OutAssetData, bool bRecursive, bool bIncludeOnlyOnDiskAssets); // 0x03FA2BB8 [Native | Public | HasOutParms | BlueprintCallable | Const]
        bool        GetAssetsByPaths(TArray<FName> PackagePaths, TArray<FAssetData>& OutAssetData, bool bRecursive, bool bIncludeOnlyOnDiskAssets); // 0x03FA30AC [Native | Public | HasOutParms | BlueprintCallable | Const]
        void        GetDerivedClassNames(TArray<FTopLevelAssetPath>& ClassNames, TSet<FTopLevelAssetPath>& ExcludedClassNames, TSet<FTopLevelAssetPath>& OutDerivedClassNames); // 0x03FA3624 [Native | Public | HasOutParms | BlueprintCallable | Const]
        bool        GetInMemoryAssets(FARFilter& Filter, TArray<FAssetData>& OutAssetData, bool bSkipARFilteredAssets); // 0x03FA3A44 [Native | Public | HasOutParms | BlueprintCallable | Const]
        void        GetSubPaths(FString InBasePath, TArray<FString>& OutPathList, bool bInRecurse); // 0x03FA3E64 [Native | Public | HasOutParms | BlueprintCallable | Const]
        bool        HasAssets(FName PackagePath, bool bRecursive); // 0x03FA4244 [Native | Public | BlueprintCallable | Const]
        bool        IsLoadingAssets(); // 0x0C8E59E8 [Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool        IsSearchAllAssets(); // 0x0C8E5A12 [Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool        IsSearchAsync(); // 0x0C8E5A3C [Native | Public | BlueprintCallable | BlueprintPure | Const]
        FAssetData  K2_GetAssetByObjectPath(FSoftObjectPath& ObjectPath, bool bIncludeOnlyOnDiskAssets, bool bSkipARFilteredAssets); // 0x03FA44D4 [RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | Const]
        bool        K2_GetDependencies(FName PackageName, FAssetRegistryDependencyOptions& DependencyOptions, TArray<FName>& OutDependencies); // 0x03FA4956 [Native | Public | HasOutParms | BlueprintCallable | Const]
        bool        K2_GetReferencers(FName PackageName, FAssetRegistryDependencyOptions& ReferenceOptions, TArray<FName>& OutReferencers); // 0x03FA4D42 [Native | Public | HasOutParms | BlueprintCallable | Const]
        void        PrioritizeSearchPath(FString PathToPrioritize); // 0x03FA512E [Native | Public | BlueprintCallable]
        void        RunAssetsThroughFilter(TArray<FAssetData>& AssetDataList, FARFilter& Filter); // 0x03FA52B2 [Native | Public | HasOutParms | BlueprintCallable | Const]
        void        ScanFilesSynchronous(TArray<FString>& InFilePaths, bool bForceRescan); // 0x03FA55C8 [Native | Public | HasOutParms | BlueprintCallable]
        void        ScanModifiedAssetFiles(TArray<FString>& InFilePaths); // 0x03FA5886 [Native | Public | HasOutParms | BlueprintCallable]
        void        ScanPathsSynchronous(TArray<FString>& InPaths, bool bForceRescan, bool bIgnoreDenyListScanFilters); // 0x03FA5A24 [Native | Public | HasOutParms | BlueprintCallable]
        void        SearchAllAssets(bool bSynchronousSearch); // 0x03FA5DFC [Native | Public | BlueprintCallable]
        void        UseFilterToExcludeAssets(TArray<FAssetData>& AssetDataList, FARFilter& Filter); // 0x03FA5F74 [Native | Public | HasOutParms | BlueprintCallable | Const]
        void        WaitForCompletion(); // 0x0C8E5A66 [Native | Public | BlueprintCallable]
        void        WaitForPackage(FString PackageName); // 0x03FA628A [Native | Public | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class UAssetRegistryHelpers : public UObject
    {
    public:
    
    public: // Functions
        static FAssetData                          CreateAssetData(UObject* InAsset, bool bAllowBlueprintClass); // 0x03F875CE [Final | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static UClass*                             FindAssetNativeClass(FAssetData& AssetData); // 0x03F878E2 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static UObject*                            GetAsset(FAssetData& InAssetData); // 0x03F87BE4 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static TScriptInterface<IAssetRegistry>    GetAssetRegistry(); // 0x0C8CF718 [Final | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static void                                GetBlueprintAssets(FARFilter& InFilter, TArray<FAssetData>& OutAssetData); // 0x03F87DAA [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static UClass*                             GetClass(FAssetData& InAssetData); // 0x03F88090 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static void                                GetDerivedClassAssetData(TArray<FTopLevelAssetPath>& InBaseClasses, TArray<FAssetData>& OutDerivedClassAssetData); // 0x03F8824C [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FString                             GetExportTextName(FAssetData& InAssetData); // 0x03F88512 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FString                             GetFullName(FAssetData& InAssetData); // 0x03F88714 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static bool                                GetTagValue(FAssetData& InAssetData, FName& InTagName, FString& OutTagValue); // 0x03F88916 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static bool                                IsAssetLoaded(FAssetData& InAssetData); // 0x03F88DB6 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static bool                                IsRedirector(FAssetData& InAssetData); // 0x03F88F82 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static bool                                IsUAsset(FAssetData& InAssetData); // 0x03F8915C [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static bool                                IsValid(FAssetData& InAssetData); // 0x03F89312 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FARFilter                           SetFilterTagsAndValues(FARFilter& InFilter, TArray<FTagAndValue>& InTagsAndValues); // 0x03F894D2 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static void                                SortByAssetName(TArray<FAssetData>& Assets, EAssetRegistrySortOrder SortOrder); // 0x03F897F4 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                                SortByPredicate(TArray<FAssetData>& Assets, SortingPredicate SortingPredicate, EAssetRegistrySortOrder SortOrder); // 0x03F89A98 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FSoftObjectPath                     ToSoftObjectPath(FAssetData& InAssetData); // 0x03F89E66 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        bool                                SortingPredicate(FAssetData& Left, FAssetData& Right); // 0x000545D2 [Public | Delegate | HasOutParms]
    };
    // Size: 0x000B50 (0x000B28)
    class alignas(0x8) UAssetRegistryImpl : public UObject
    {
    public:
        void**  VTable_000028;                  // 0x000028 (0x000008) VTable [156 slots] -> 0x12EA1870
        uint8   UnknownData_000030[0x000B20];   // 0x000030 (0x000B20)
    };
    // Size: 0x000007 (0x000007)
    struct FAssetRegistryDependencyOptions
    {
        bool    bIncludeSoftPackageReferences;          // 0x000000 (0x000001) [Default: true]
        bool    bIncludeHardPackageReferences;          // 0x000001 (0x000001) [Default: true]
        bool    bIncludeGamePackageReferences;          // 0x000002 (0x000001) [Default: true]
        bool    bIncludeEditorOnlyPackageReferences;    // 0x000003 (0x000001) [Default: true]
        bool    bIncludeSearchableNames;                // 0x000004 (0x000001) [Default: false]
        bool    bIncludeSoftManagementReferences;       // 0x000005 (0x000001) [Default: false]
        bool    bIncludeHardManagementReferences;       // 0x000006 (0x000001) [Default: false]
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FTagAndValue
    {
        FName   Tag;                            // 0x000000 (0x000004) [Default: NAME_None]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FString Value;                          // 0x000008 (0x000010) [Default: L""]
    };
}

