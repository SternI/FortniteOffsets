/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:09
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimGraphRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class UAnimExecutionContextLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FAnimComponentSpacePoseContext  ConvertToComponentSpacePoseContext(FAnimExecutionContext& Context, EAnimExecutionContextConversionResult& Result); // 0x049C0CF2 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FAnimInitializationContext      ConvertToInitializationContext(FAnimExecutionContext& Context, EAnimExecutionContextConversionResult& Result); // 0x049C1002 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FAnimPoseContext                ConvertToPoseContext(FAnimExecutionContext& Context, EAnimExecutionContextConversionResult& Result); // 0x049C1312 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FAnimUpdateContext              ConvertToUpdateContext(FAnimExecutionContext& Context, EAnimExecutionContextConversionResult& Result); // 0x049C1622 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static UAnimInstance*                  GetAnimInstance(FAnimExecutionContext& Context); // 0x049C1932 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FAnimNodeReference              GetAnimNodeReference(UAnimInstance* Instance, int32 Index); // 0x049C1ADC [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static float                           GetCurrentWeight(FAnimUpdateContext& Context); // 0x049C1E8E [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static float                           GetDeltaTime(FAnimUpdateContext& Context); // 0x049C2038 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static bool                            IsActive(FAnimExecutionContext& Context); // 0x049C21E2 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
    };
    // Size: 0x000028 (0x000000)
    class UAnimNodeRigidBodyLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FRigidBodyAnimNodeReference ConvertToRigidBodyAnimNode(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result); // 0x049E0F38 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                        ConvertToRigidBodyAnimNodePure(FAnimNodeReference& Node, FRigidBodyAnimNodeReference& RigidBodyAnimNode, bool& Result); // 0x049E1230 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FRigidBodyAnimNodeReference SetOverridePhysicsAsset(FRigidBodyAnimNodeReference& Node, UPhysicsAsset* PhysicsAsset); // 0x049E1644 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000040 (0x000008)
    class alignas(0x4) UAnimNotify_PlayMontageNotify : public UAnimNotify
    {
    public:
        FName   NotifyName;                     // 0x000038 (0x000004) [Default: NAME_None]
        uint8   UnknownData_00003C[0x000004];   // 0x00003C (0x000004)
    };
    // Size: 0x000038 (0x000008)
    class alignas(0x4) UAnimNotify_PlayMontageNotifyWindow : public UAnimNotifyState
    {
    public:
        FName   NotifyName;                     // 0x000030 (0x000004) [Default: NAME_None]
        uint8   UnknownData_000034[0x000004];   // 0x000034 (0x000004)
    };
    // Size: 0x000270 (0x000010)
    class alignas(0x8) UAnimSequencerInstance : public UAnimInstance
    {
    public:
        void**  VTable_000260;                  // 0x000260 (0x000008) VTable [11 slots] -> 0x130F90A0
        uint8   UnknownData_000268[0x000008];   // 0x000268 (0x000008)
    };
    // Size: 0x000028 (0x000000)
    class UAnimationStateMachineLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static void    ConvertToAnimationStateMachine(FAnimNodeReference& Node, FAnimationStateMachineReference& AnimationState, EAnimNodeReferenceConversionResult& Result); // 0x049BE328 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void    ConvertToAnimationStateMachinePure(FAnimNodeReference& Node, FAnimationStateMachineReference& AnimationState, bool& Result); // 0x049BE72C [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static void    ConvertToAnimationStateResult(FAnimNodeReference& Node, FAnimationStateResultReference& AnimationState, EAnimNodeReferenceConversionResult& Result); // 0x049BEB2E [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void    ConvertToAnimationStateResultPure(FAnimNodeReference& Node, FAnimationStateResultReference& AnimationState, bool& Result); // 0x049BEF30 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static float   GetRelevantAnimTimeRemaining(FAnimUpdateContext& UpdateContext, FAnimationStateResultReference& Node); // 0x049BF332 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static float   GetRelevantAnimTimeRemainingFraction(FAnimUpdateContext& UpdateContext, FAnimationStateResultReference& Node); // 0x049BF630 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FName   GetState(FAnimUpdateContext& UpdateContext, FAnimationStateMachineReference& Node); // 0x049BF92E [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static bool    IsStateBlendingIn(FAnimUpdateContext& UpdateContext, FAnimationStateResultReference& Node); // 0x049BFC28 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static bool    IsStateBlendingOut(FAnimUpdateContext& UpdateContext, FAnimationStateResultReference& Node); // 0x049BFF1E [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static void    SetState(FAnimUpdateContext& UpdateContext, FAnimationStateMachineReference& Node, FName TargetState, float duration, TEnumAsByte<ETransitionLogicType> BlendType, UBlendProfile* BlendProfile, EAlphaBlendOption AlphaBlendOption, UCurveFloat* CustomBlendCurve); // 0x049C0214 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class UBlendListBaseLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FBlendListBaseReference ConvertToBlendListBase(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result); // 0x049CA828 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                    ResetNode(FBlendListBaseReference& BlendListBase); // 0x049CAB20 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class UBlendSpaceLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FBlendSpaceReference    ConvertToBlendSpace(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result); // 0x049CACB6 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                    ConvertToBlendSpacePure(FAnimNodeReference& Node, FBlendSpaceReference& BlendSpace, bool& Result); // 0x049CAFAE [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FVector                 GetFilteredPosition(FBlendSpaceReference& BlendSpace); // 0x049CB3C2 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        static FVector                 GetPosition(FBlendSpaceReference& BlendSpace); // 0x049CB582 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        static void                    SnapToPosition(FBlendSpaceReference& BlendSpace, FVector NewPosition); // 0x049CB742 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class UBlendSpacePlayerLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FBlendSpacePlayerReference  ConvertToBlendSpacePlayer(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result); // 0x049CBB52 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                        ConvertToBlendSpacePlayerPure(FAnimNodeReference& Node, FBlendSpacePlayerReference& BlendSpacePlayer, bool& Result); // 0x049CBE4A [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static float                       GetAccumulatedTime(FBlendSpacePlayerReference& BlendSpacePlayer); // 0x049CC25E [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static UBlendSpace*                GetBlendSpace(FBlendSpacePlayerReference& BlendSpacePlayer); // 0x049CC410 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static bool                        GetLoop(FBlendSpacePlayerReference& BlendSpacePlayer); // 0x049CC5C0 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static float                       GetPlayRate(FBlendSpacePlayerReference& BlendSpacePlayer); // 0x049CC76A [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FVector                     GetPosition(FBlendSpacePlayerReference& BlendSpacePlayer); // 0x049CC91C [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        static float                       GetStartPosition(FBlendSpacePlayerReference& BlendSpacePlayer); // 0x049CCADC [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FBlendSpacePlayerReference  SetAccumulatedTime(FBlendSpacePlayerReference& BlendSpacePlayer, float time); // 0x049CCC8E [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FBlendSpacePlayerReference  SetBlendSpace(FBlendSpacePlayerReference& BlendSpacePlayer, UBlendSpace* BlendSpace); // 0x049CCF52 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FBlendSpacePlayerReference  SetBlendSpaceWithInertialBlending(FAnimUpdateContext& UpdateContext, FBlendSpacePlayerReference& BlendSpacePlayer, UBlendSpace* BlendSpace, float BlendTime); // 0x049CD214 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FBlendSpacePlayerReference  SetLoop(FBlendSpacePlayerReference& BlendSpacePlayer, bool bLoop); // 0x049CD744 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FBlendSpacePlayerReference  SetPlayRate(FBlendSpacePlayerReference& BlendSpacePlayer, float PlayRate); // 0x049CDA06 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FBlendSpacePlayerReference  SetResetPlayTimeWhenBlendSpaceChanges(FBlendSpacePlayerReference& BlendSpacePlayer, bool bReset); // 0x049CDCCA [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static bool                        ShouldResetPlayTimeWhenBlendSpaceChanges(FBlendSpacePlayerReference& BlendSpacePlayer); // 0x049CDF8C [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static void                        SnapToPosition(FBlendSpacePlayerReference& BlendSpacePlayer, FVector NewPosition); // 0x049CE136 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class UKismetAnimationLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static float       CalculateDirection(FVector& Velocity, FRotator& BaseRotation); // 0x049E6656 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        static float       K2_CalculateVelocityFromPositionHistory(float DeltaSeconds, FVector Position, FPositionHistory& History, int32 NumberOfSamples, float VelocityMin, float VelocityMax); // 0x049E68FA [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static float       K2_CalculateVelocityFromSockets(float DeltaSeconds, USkeletalMeshComponent* Component, FName SocketOrBoneName, FName ReferenceSocketOrBone, TEnumAsByte<ERelativeTransformSpace> SocketSpace, FVector OffsetInBoneSpace, FPositionHistory& History, int32 NumberOfSamples, float VelocityMin, float VelocityMax, EEasingFuncType EasingType, FRuntimeFloatCurve& CustomCurve); // 0x049E737E [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static FVector     K2_DirectionBetweenSockets(USkeletalMeshComponent* Component, FName SocketOrBoneNameFrom, FName SocketOrBoneNameTo); // 0x049E8674 [Final | RequiredAPI | Native | Static | Public | HasDefaults | BlueprintCallable | BlueprintPure]
        static float       K2_DistanceBetweenTwoSocketsAndMapRange(USkeletalMeshComponent* Component, FName SocketOrBoneNameA, TEnumAsByte<ERelativeTransformSpace> SocketSpaceA, FName SocketOrBoneNameB, TEnumAsByte<ERelativeTransformSpace> SocketSpaceB, bool bRemapRange, float InRangeMin, float InRangeMax, float OutRangeMin, float OutRangeMax); // 0x049E8A94 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static float       K2_EndProfilingTimer(bool bLog, FString LogPrefix); // 0x049E9426 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static FTransform  K2_LookAt(FTransform& CurrentTransform, FVector& TargetPosition, FVector LookAtVector, bool bUseUpVector, FVector UpVector, float ClampConeInDegree); // 0x049E99CA [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        static float       K2_MakePerlinNoiseAndRemap(float Value, float RangeOutMin, float RangeOutMax); // 0x049EA0C8 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static FVector     K2_MakePerlinNoiseVectorAndRemap(float X, float Y, float Z, float RangeOutMinX, float RangeOutMaxX, float RangeOutMinY, float RangeOutMaxY, float RangeOutMinZ, float RangeOutMaxZ); // 0x049EA512 [Final | RequiredAPI | Native | Static | Public | HasDefaults | BlueprintCallable | BlueprintPure]
        static void        K2_StartProfilingTimer(); // 0x0D385DA8 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void        K2_TwoBoneIK(FVector& RootPos, FVector& JointPos, FVector& EndPos, FVector& JointTarget, FVector& Effector, FVector& OutJointPos, FVector& OutEndPos, bool bAllowStretching, float StartStretchRatio, float MaxStretchScale); // 0x049EAE22 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
    };
    // Size: 0x000028 (0x000000)
    class ULayeredBoneBlendLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static void                        ConvertToLayeredBlendPerBonePure(FAnimNodeReference& Node, FLayeredBoneBlendReference& LayeredBoneBlend, bool& Result); // 0x049EB8AE [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FLayeredBoneBlendReference  ConvertToLayeredBoneBlend(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result); // 0x049EBCC2 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static int32                       GetNumPoses(FLayeredBoneBlendReference& LayeredBoneBlend); // 0x049EBFBA [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FLayeredBoneBlendReference  SetBlendMask(FAnimUpdateContext& UpdateContext, FLayeredBoneBlendReference& LayeredBoneBlend, int32 PoseIndex, FName BlendMaskName); // 0x049EC168 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class ULinkedAnimGraphLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FLinkedAnimGraphReference   ConvertToLinkedAnimGraph(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result); // 0x049EC7CA [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                        ConvertToLinkedAnimGraphPure(FAnimNodeReference& Node, FLinkedAnimGraphReference& LinkedAnimGraph, bool& Result); // 0x049ECA7A [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static UAnimInstance*              GetLinkedAnimInstance(FLinkedAnimGraphReference& Node); // 0x049ECE38 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static bool                        HasLinkedAnimInstance(FLinkedAnimGraphReference& Node); // 0x049ECFE6 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
    };
    // Size: 0x000028 (0x000000)
    class UMirrorAnimLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FMirrorAnimNodeReference    ConvertToMirrorNode(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result); // 0x049ED18E [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                        ConvertToMirrorNodePure(FAnimNodeReference& Node, FMirrorAnimNodeReference& MirrorNode, bool& Result); // 0x049ED486 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static bool                        GetMirror(FMirrorAnimNodeReference& MirrorNode); // 0x049ED89A [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static UMirrorDataTable*           GetMirrorDataTable(FMirrorAnimNodeReference& MirrorNode); // 0x049EDA44 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static float                       GetMirrorTransitionBlendTime(FMirrorAnimNodeReference& MirrorNode); // 0x049EDBF4 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FMirrorAnimNodeReference    SetMirror(FMirrorAnimNodeReference& MirrorNode, bool bInMirror); // 0x049EDDA6 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FMirrorAnimNodeReference    SetMirrorTransitionBlendTime(FMirrorAnimNodeReference& MirrorNode, float InBlendTime); // 0x049EE068 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class UModifyCurveAnimLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FModifyCurveAnimNodeReference   ConvertToModifyCurveNode(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result); // 0x049EE474 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                            ConvertToModifyCurveNodePure(FAnimNodeReference& Node, FModifyCurveAnimNodeReference& ModifyCurveNode, bool& Result); // 0x049EE76C [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static float                           GetAlpha(FModifyCurveAnimNodeReference& ModifyCurveNode); // 0x049EEB80 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static EModifyCurveApplyMode           GetApplyMode(FModifyCurveAnimNodeReference& ModifyCurveNode); // 0x049EED32 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FModifyCurveAnimNodeReference   SetAlpha(FModifyCurveAnimNodeReference& ModifyCurveNode, float InAlpha); // 0x049EEEDC [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FModifyCurveAnimNodeReference   SetApplyMode(FModifyCurveAnimNodeReference& ModifyCurveNode, EModifyCurveApplyMode InMode); // 0x049EF1A0 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FModifyCurveAnimNodeReference   SetCurveMap(FModifyCurveAnimNodeReference& ModifyCurveNode, TMap<FName, float>& InCurveMap); // 0x049EF45C [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x0000A8 (0x000080)
    class alignas(0x8) UPlayMontageCallbackProxy : public UObject
    {
    public:
        MULTI_INLINE_DELEGATE(OnMontagePlayDelegate)    OnCompleted;                    // 0x000028 (0x000010)
        MULTI_INLINE_DELEGATE(OnMontagePlayDelegate)    OnBlendOut;                     // 0x000038 (0x000010)
        MULTI_INLINE_DELEGATE(OnMontagePlayDelegate)    OnInterrupted;                  // 0x000048 (0x000010)
        MULTI_INLINE_DELEGATE(OnMontagePlayDelegate)    OnNotifyBegin;                  // 0x000058 (0x000010)
        MULTI_INLINE_DELEGATE(OnMontagePlayDelegate)    OnNotifyEnd;                    // 0x000068 (0x000010)
        uint8                                           UnknownData_000078[0x000030];   // 0x000078 (0x000030)
    
    public: // Functions
        static UPlayMontageCallbackProxy*  CreateProxyObjectForPlayMontage(USkeletalMeshComponent* InSkeletalMeshComponent, UAnimMontage* MontageToPlay, float PlayRate, float StartingPosition, FName StartingSection, bool bShouldStopAllMontages); // 0x049EF8BE [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        void                        OnMontageBlendingOut(UAnimMontage* Montage, bool bInterrupted); // 0x049EFF6C [Final | RequiredAPI | Native | Protected]
        void                        OnMontageEnded(UAnimMontage* Montage, bool bInterrupted); // 0x049F01F0 [Final | RequiredAPI | Native | Protected]
        void                        OnNotifyBeginReceived(FName NotifyName, FBranchingPointNotifyPayload& BranchingPointNotifyPayload); // 0x049F0474 [Final | RequiredAPI | Native | Protected | HasOutParms]
        void                        OnNotifyEndReceived(FName NotifyName, FBranchingPointNotifyPayload& BranchingPointNotifyPayload); // 0x049F0738 [Final | RequiredAPI | Native | Protected | HasOutParms]
    };
    // Size: 0x000028 (0x000000)
    class USequenceEvaluatorLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FSequenceEvaluatorReference AdvanceTime(FAnimUpdateContext& UpdateContext, FSequenceEvaluatorReference& SequenceEvaluator, float PlayRate); // 0x049F0C26 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FSequenceEvaluatorReference ConvertToSequenceEvaluator(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result); // 0x049F102E [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                        ConvertToSequenceEvaluatorPure(FAnimNodeReference& Node, FSequenceEvaluatorReference& SequenceEvaluator, bool& Result); // 0x049F1326 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static float                       GetAccumulatedTime(FSequenceEvaluatorReference& SequenceEvaluator); // 0x049F173A [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static UAnimSequenceBase*          GetSequence(FSequenceEvaluatorReference& SequenceEvaluator); // 0x049F18EC [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FSequenceEvaluatorReference SetExplicitFrame(FSequenceEvaluatorReference& SequenceEvaluator, int32 Frame); // 0x049F1A9C [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FSequenceEvaluatorReference SetExplicitTime(FSequenceEvaluatorReference& SequenceEvaluator, float time); // 0x049F1D5C [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FSequenceEvaluatorReference SetSequence(FSequenceEvaluatorReference& SequenceEvaluator, UAnimSequenceBase* Sequence); // 0x049F2020 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FSequenceEvaluatorReference SetSequenceWithInertialBlending(FAnimUpdateContext& UpdateContext, FSequenceEvaluatorReference& SequenceEvaluator, UAnimSequenceBase* Sequence, float BlendTime); // 0x049F22E2 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class USequencePlayerLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static float                       ComputePlayRateFromDuration(FSequencePlayerReference& SequencePlayer, float duration); // 0x049F295A [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FSequencePlayerReference    ConvertToSequencePlayer(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result); // 0x049F2C3E [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                        ConvertToSequencePlayerPure(FAnimNodeReference& Node, FSequencePlayerReference& SequencePlayer, bool& Result); // 0x049F2EEE [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static float                       GetAccumulatedTime(FSequencePlayerReference& SequencePlayer); // 0x049F32AC [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static bool                        GetLoopAnimation(FSequencePlayerReference& SequencePlayer); // 0x049F345E [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static float                       GetPlayRate(FSequencePlayerReference& SequencePlayer); // 0x049F3608 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FSequencePlayerReference    GetSequence(FSequencePlayerReference& SequencePlayer, UAnimSequenceBase*& SequenceBase); // 0x049F37BA [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static UAnimSequenceBase*          GetSequencePure(FSequencePlayerReference& SequencePlayer); // 0x049F3AAA [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static float                       GetStartPosition(FSequencePlayerReference& SequencePlayer); // 0x049F3C5A [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FSequencePlayerReference    SetAccumulatedTime(FSequencePlayerReference& SequencePlayer, float time); // 0x049F3E0C [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FSequencePlayerReference    SetPlayRate(FSequencePlayerReference& SequencePlayer, float PlayRate); // 0x049F40D0 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FSequencePlayerReference    SetSequence(FSequencePlayerReference& SequencePlayer, UAnimSequenceBase* Sequence); // 0x049F4394 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FSequencePlayerReference    SetSequenceWithInertialBlending(FAnimUpdateContext& UpdateContext, FSequencePlayerReference& SequencePlayer, UAnimSequenceBase* Sequence, float BlendTime); // 0x049F4656 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FSequencePlayerReference    SetStartPosition(FSequencePlayerReference& SequencePlayer, float StartPosition); // 0x049F4B86 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class ISequencerAnimationOverride : public IInterface
    {
    public:
    
    public: // Functions
        bool            AllowsCinematicOverride(); // 0x0D36D5DA [RequiredAPI | Native | Event | Public | BlueprintEvent | Const]
        TArray<FName>   GetSequencerAnimSlotNames(); // 0x0D36D600 [RequiredAPI | Native | Event | Public | BlueprintEvent | Const]
    };
    // Size: 0x000028 (0x000000)
    class ISequencerAnimationSupport : public IInterface
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class USkeletalControlLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FSkeletalControlReference   ConvertToSkeletalControl(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result); // 0x049F4F78 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                        ConvertToSkeletalControlPure(FAnimNodeReference& Node, FSkeletalControlReference& SkeletalControl, bool& Result); // 0x049F5270 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static float                       GetAlpha(FSkeletalControlReference& SkeletalControl); // 0x049F5684 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FSkeletalControlReference   SetAlpha(FSkeletalControlReference& SkeletalControl, float Alpha); // 0x049F5836 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x8) FAngularRangeLimit
    {
        FVector         LimitMin;                       // 0x000000 (0x000018)
        FVector         LimitMax;                       // 0x000018 (0x000018)
        FBoneReference  bone;                           // 0x000030 (0x00000C)
        uint8           UnknownData_00003C[0x000004];   // 0x00003C (0x000004)
    };
    // Size: 0x0000F0 (0x0000F0)
    struct FAnimLegIKData
    {
        uint8   UnknownData_000000[0x0000F0];   // 0x000000 (0x0000F0)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FAnimLegIKDefinition
    {
        FBoneReference      IKFootBone;                 // 0x000000 (0x00000C)
        FBoneReference      FKFootBone;                 // 0x00000C (0x00000C)
        int32               NumBonesInLimb;             // 0x000018 (0x000004) [Default: 379749280]
        float               MinRotationAngle;           // 0x00001C (0x000004) [Default: 0f]
        TEnumAsByte<EAxis>  FootBoneForwardAxis;        // 0x000020 (0x000001) [Default: 80]
        TEnumAsByte<EAxis>  HingeRotationAxis;          // 0x000021 (0x000001) [Default: 44]
        bool                bEnableRotationLimit;       // 0x000022 (0x000001) [Default: true]
        bool                bEnableKneeTwistCorrection; // 0x000023 (0x000001) [Default: true]
        FName               TwistOffsetCurveName;       // 0x000024 (0x000004) [Default: NAME_None]
    };
    // Size: 0x0001D0 (0x000158)
    struct alignas(0x8) FAnimNode_AimOffsetLookAt : public FAnimNode_BlendSpacePlayer
    {
        uint8       UnknownData_000078[0x0000C8];   // 0x000078 (0x0000C8)
        FPoseLink   BasePose;                       // 0x000140 (0x000010)
        int32       LODThreshold;                   // 0x000150 (0x000004)
        FName       SourceSocketName;               // 0x000154 (0x000004)
        FName       PivotSocketName;                // 0x000158 (0x000004)
        uint8       UnknownData_00015C[0x000004];   // 0x00015C (0x000004)
        FVector     LookAtLocation;                 // 0x000160 (0x000018)
        FVector     SocketAxis;                     // 0x000178 (0x000018)
        float       Alpha;                          // 0x000190 (0x000004)
        uint8       UnknownData_000194[0x00003C];   // 0x000194 (0x00003C)
    };
    // Size: 0x000580 (0x0004B8)
    struct alignas(0x8) FAnimNode_AnimDynamics : public FAnimNode_SkeletalControlBase
    {
        float                           LinearDampingOverride;          // 0x0000C8 (0x000004)
        float                           AngularDampingOverride;         // 0x0000CC (0x000004)
        uint8                           UnknownData_0000D0[0x000120];   // 0x0000D0 (0x000120)
        FBoneReference                  RelativeSpaceBone;              // 0x0001F0 (0x00000C)
        FBoneReference                  BoundBone;                      // 0x0001FC (0x00000C)
        FBoneReference                  ChainEnd;                       // 0x000208 (0x00000C)
        uint8                           UnknownData_000214[0x000004];   // 0x000214 (0x000004)
        TArray<FAnimPhysBodyDefinition> PhysicsBodyDefinitions;         // 0x000218 (0x000010)
        float                           GravityScale;                   // 0x000228 (0x000004)
        uint8                           UnknownData_00022C[0x000004];   // 0x00022C (0x000004)
        FVector                         GravityOverride;                // 0x000230 (0x000018)
        float                           LinearSpringConstant;           // 0x000248 (0x000004)
        float                           AngularSpringConstant;          // 0x00024C (0x000004)
        float                           WorldSpaceMinimumScale;         // 0x000250 (0x000004)
        float                           WindScale;                      // 0x000254 (0x000004)
        FVector                         ComponentLinearAccScale;        // 0x000258 (0x000018)
        FVector                         ComponentLinearVelScale;        // 0x000270 (0x000018)
        FVector                         ComponentAppliedLinearAccClamp; // 0x000288 (0x000018)
        FAnimPhysSimSpaceSettings       SimSpaceSettings;               // 0x0002A0 (0x000028)
        float                           AngularBiasOverride;            // 0x0002C8 (0x000004)
        int32                           NumSolverIterationsPreUpdate;   // 0x0002CC (0x000004)
        int32                           NumSolverIterationsPostUpdate;  // 0x0002D0 (0x000004)
        uint8                           UnknownData_0002D4[0x000004];   // 0x0002D4 (0x000004)
        TArray<FAnimPhysSphericalLimit> SphericalLimits;                // 0x0002D8 (0x000010)
        FVector                         ExternalForce;                  // 0x0002E8 (0x000018)
        TArray<FAnimPhysPlanarLimit>    PlanarLimits;                   // 0x000300 (0x000010)
        AnimPhysSimSpaceType            SimulationSpace;                // 0x000310 (0x000001)
        uint8                           UnknownData_000311[0x000002];   // 0x000311 (0x000002)
        uint8                           bUseSphericalLimits : 1;        // 0x000313 (0x000001) : 0x0
        uint8                           bUsePlanarLimit : 1;            // 0x000313 (0x000001) : 0x0
        uint8                           bDoUpdate : 1;                  // 0x000313 (0x000001) : 0x0
        uint8                           bDoEval : 1;                    // 0x000313 (0x000001) : 0x0
        uint8                           bOverrideLinearDamping : 1;     // 0x000313 (0x000001) : 0x0
        uint8                           bOverrideAngularBias : 1;       // 0x000313 (0x000001) : 0x0
        uint8                           bOverrideAngularDamping : 1;    // 0x000313 (0x000001) : 0x0
        uint8                           bEnableWind : 1;                // 0x000313 (0x000001) : 0x0
        uint8                           UnknownBit_000313_1 : 1;        // 0x000313 (0x000001) : 0x1
        uint8                           UnknownBit_000313_2 : 1;        // 0x000313 (0x000001) : 0x2
        uint8                           UnknownBit_000313_3 : 1;        // 0x000313 (0x000001) : 0x3
        uint8                           UnknownBit_000313_4 : 1;        // 0x000313 (0x000001) : 0x4
        uint8                           UnknownBit_000313_5 : 1;        // 0x000313 (0x000001) : 0x5
        uint8                           UnknownBit_000313_6 : 1;        // 0x000313 (0x000001) : 0x6
        uint8                           UnknownBit_000313_7 : 1;        // 0x000313 (0x000001) : 0x7
        uint8                           bUseGravityOverride : 1;        // 0x000314 (0x000001) : 0x0
        uint8                           bGravityOverrideInSimSpace : 1; // 0x000314 (0x000001) : 0x0
        uint8                           bLinearSpring : 1;              // 0x000314 (0x000001) : 0x0
        uint8                           bAngularSpring : 1;             // 0x000314 (0x000001) : 0x0
        uint8                           bChain : 1;                     // 0x000314 (0x000001) : 0x0
        uint8                           UnknownBit_000314_1 : 1;        // 0x000314 (0x000001) : 0x1
        uint8                           UnknownBit_000314_2 : 1;        // 0x000314 (0x000001) : 0x2
        uint8                           UnknownBit_000314_3 : 1;        // 0x000314 (0x000001) : 0x3
        uint8                           UnknownBit_000314_4 : 1;        // 0x000314 (0x000001) : 0x4
        uint8                           UnknownBit_000314_5 : 1;        // 0x000314 (0x000001) : 0x5
        uint8                           UnknownBit_000314_6 : 1;        // 0x000314 (0x000001) : 0x6
        uint8                           UnknownBit_000314_7 : 1;        // 0x000314 (0x000001) : 0x7
        uint8                           UnknownData_000315[0x00000B];   // 0x000315 (0x00000B)
        FRotationRetargetingInfo        RetargetingSettings;            // 0x000320 (0x000160)
        uint8                           UnknownData_000480[0x000100];   // 0x000480 (0x000100)
    };
    // Size: 0x0000C8 (0x0000B8)
    struct alignas(0x8) FAnimNode_ApplyAdditive : public FAnimNode_Base
    {
        FPoseLink               base;                           // 0x000010 (0x000010)
        FPoseLink               Additive;                       // 0x000020 (0x000010)
        float                   Alpha;                          // 0x000030 (0x000004)
        FInputScaleBias         AlphaScaleBias;                 // 0x000034 (0x000008)
        int32                   LODThreshold;                   // 0x00003C (0x000004)
        FInputAlphaBoolBlend    AlphaBoolBlend;                 // 0x000040 (0x000048)
        FName                   AlphaCurveName;                 // 0x000088 (0x000004)
        FInputScaleBiasClamp    AlphaScaleBiasClamp;            // 0x00008C (0x000030)
        uint8                   UnknownData_0000BC[0x000004];   // 0x0000BC (0x000004)
        EAnimAlphaInputType     AlphaInputType;                 // 0x0000C0 (0x000001)
        bool                    bAlphaBoolEnabled;              // 0x0000C1 (0x000001)
        uint8                   UnknownData_0000C2[0x000006];   // 0x0000C2 (0x000006)
    };
    // Size: 0x0000E8 (0x000020)
    struct alignas(0x8) FAnimNode_ApplyLimits : public FAnimNode_SkeletalControlBase
    {
        TArray<FAngularRangeLimit>  AngularRangeLimits; // 0x0000C8 (0x000010)
        TArray<FVector>             AngularOffsets;     // 0x0000D8 (0x000010)
    };
    // Size: 0x000068 (0x000058)
    struct alignas(0x8) FAnimNode_BlendBoneByChannel : public FAnimNode_Base
    {
        FPoseLink                           A;                              // 0x000010 (0x000010)
        FPoseLink                           B;                              // 0x000020 (0x000010)
        TArray<FBlendBoneByChannelEntry>    BoneDefinitions;                // 0x000030 (0x000010)
        uint8                               UnknownData_000040[0x000010];   // 0x000040 (0x000010)
        float                               Alpha;                          // 0x000050 (0x000004) [Default: 0f]
        uint8                               UnknownData_000054[0x000004];   // 0x000054 (0x000004)
        FInputScaleBias                     AlphaScaleBias;                 // 0x000058 (0x000008)
        TEnumAsByte<EBoneControlSpace>      TransformsSpace;                // 0x000060 (0x000001) [Default: 0]
        uint8                               UnknownData_000061[0x000003];   // 0x000061 (0x000003)
        int32                               LODThreshold;                   // 0x000064 (0x000004) [Default: 0]
    };
    // Size: 0x000058 (0x000048)
    struct alignas(0x8) FAnimNode_BlendListBase : public FAnimNode_Base
    {
        TArray<FPoseLink>   BlendPose;                      // 0x000010 (0x000010)
        uint8               UnknownData_000020[0x000030];   // 0x000020 (0x000030)
        int32               LODThreshold;                   // 0x000050 (0x000004) [Default: 0]
        uint8               UnknownData_000054[0x000004];   // 0x000054 (0x000004)
    };
    // Size: 0x000058 (0x000000)
    struct FAnimNode_BlendListByBool : public FAnimNode_BlendListBase
    {
    };
    // Size: 0x000058 (0x000000)
    struct FAnimNode_BlendListByEnum : public FAnimNode_BlendListBase
    {
    };
    // Size: 0x000058 (0x000000)
    struct FAnimNode_BlendListByInt : public FAnimNode_BlendListBase
    {
    };
    // Size: 0x000080 (0x000008)
    struct alignas(0x4) FAnimNode_BlendSpaceEvaluator : public FAnimNode_BlendSpacePlayer
    {
        float   NormalizedTime;                 // 0x000078 (0x000004)
        bool    bTeleportToNormalizedTime;      // 0x00007C (0x000001)
        uint8   UnknownData_00007D[0x000003];   // 0x00007D (0x000003)
    };
    // Size: 0x000060 (0x000000)
    struct FAnimNode_BlendSpaceGraph : public FAnimNode_BlendSpaceGraphBase
    {
    };
    // Size: 0x000060 (0x000050)
    struct alignas(0x8) FAnimNode_BlendSpaceGraphBase : public FAnimNode_Base
    {
        float                       X;                              // 0x000010 (0x000004)
        float                       Y;                              // 0x000014 (0x000004)
        FName                       GroupName;                      // 0x000018 (0x000004)
        TEnumAsByte<EAnimGroupRole> GroupRole;                      // 0x00001C (0x000001)
        uint8                       UnknownData_00001D[0x000003];   // 0x00001D (0x000003)
        UBlendSpace*                BlendSpace;                     // 0x000020 (0x000008)
        TArray<FPoseLink>           SamplePoseLinks;                // 0x000028 (0x000010)
        uint8                       UnknownData_000038[0x000028];   // 0x000038 (0x000028)
    };
    // Size: 0x000078 (0x000008)
    struct alignas(0x8) FAnimNode_BlendSpacePlayer : public FAnimNode_BlendSpacePlayerBase
    {
        UBlendSpace*    BlendSpace; // 0x000070 (0x000008)
    };
    // Size: 0x000070 (0x000030)
    struct alignas(0x8) FAnimNode_BlendSpacePlayerBase : public FAnimNode_AssetPlayerBase
    {
        uint8           UnknownData_000040[0x000028];   // 0x000040 (0x000028)
        UBlendSpace*    PreviousBlendSpace;             // 0x000068 (0x000008)
    };
    // Size: 0x000098 (0x000028)
    struct alignas(0x8) FAnimNode_BlendSpacePlayer_Standalone : public FAnimNode_BlendSpacePlayerBase
    {
        FName                       GroupName;                                      // 0x000070 (0x000004) [Default: NAME_None]
        TEnumAsByte<EAnimGroupRole> GroupRole;                                      // 0x000074 (0x000001) [Default: 0]
        bool                        bOverridePositionWhenJoiningSyncGroupAsLeader;  // 0x000075 (0x000001) [Default: false]
        EAnimSyncMethod             Method;                                         // 0x000076 (0x000001) [Default: EAnimSyncMethod(0)]
        bool                        bIgnoreForRelevancyTest;                        // 0x000077 (0x000001) [Default: false]
        float                       X;                                              // 0x000078 (0x000004) [Default: 2.88054e-24f]
        float                       Y;                                              // 0x00007C (0x000004) [Default: 4.58855e-41f]
        float                       PlayRate;                                       // 0x000080 (0x000004) [Default: 3.08286e-44f]
        bool                        bLoop;                                          // 0x000084 (0x000001) [Default: true]
        bool                        bResetPlayTimeWhenBlendSpaceChanges;            // 0x000085 (0x000001) [Default: false]
        uint8                       UnknownData_000086[0x000002];                   // 0x000086 (0x000002)
        float                       StartPosition;                                  // 0x000088 (0x000004) [Default: -9.09507e+14f]
        uint8                       UnknownData_00008C[0x000004];                   // 0x00008C (0x000004)
        UBlendSpace*                BlendSpace;                                     // 0x000090 (0x000008) [Default: 0x170BB9C0]
    };
    // Size: 0x000020 (0x000000)
    struct FAnimNode_BlendSpaceSampleResult : public FAnimNode_Root
    {
    };
    // Size: 0x000120 (0x000058)
    struct alignas(0x8) FAnimNode_BoneDrivenController : public FAnimNode_SkeletalControlBase
    {
        FBoneReference              SourceBone;                     // 0x0000C8 (0x00000C)
        uint8                       UnknownData_0000D4[0x000004];   // 0x0000D4 (0x000004)
        UCurveFloat*                DrivingCurve;                   // 0x0000D8 (0x000008)
        float                       Multiplier;                     // 0x0000E0 (0x000004)
        uint8                       UnknownData_0000E4[0x000004];   // 0x0000E4 (0x000004)
        double                      RangeMin;                       // 0x0000E8 (0x000008)
        double                      RangeMax;                       // 0x0000F0 (0x000008)
        double                      RemappedMin;                    // 0x0000F8 (0x000008)
        double                      RemappedMax;                    // 0x000100 (0x000008)
        FName                       ParameterName;                  // 0x000108 (0x000004)
        FBoneReference              TargetBone;                     // 0x00010C (0x00000C)
        EDrivenDestinationMode      DestinationMode;                // 0x000118 (0x000001)
        EDrivenBoneModificationMode ModificationMode;               // 0x000119 (0x000001)
        TEnumAsByte<EComponentType> SourceComponent;                // 0x00011A (0x000001)
        uint8                       bUseRange : 1;                  // 0x00011B (0x000001) : 0x0
        uint8                       bAffectTargetTranslationX : 1;  // 0x00011B (0x000001) : 0x0
        uint8                       bAffectTargetTranslationY : 1;  // 0x00011B (0x000001) : 0x0
        uint8                       bAffectTargetTranslationZ : 1;  // 0x00011B (0x000001) : 0x0
        uint8                       bAffectTargetRotationX : 1;     // 0x00011B (0x000001) : 0x0
        uint8                       bAffectTargetRotationY : 1;     // 0x00011B (0x000001) : 0x0
        uint8                       bAffectTargetRotationZ : 1;     // 0x00011B (0x000001) : 0x0
        uint8                       bAffectTargetScaleX : 1;        // 0x00011B (0x000001) : 0x0
        uint8                       UnknownBit_00011B_1 : 1;        // 0x00011B (0x000001) : 0x1
        uint8                       UnknownBit_00011B_2 : 1;        // 0x00011B (0x000001) : 0x2
        uint8                       UnknownBit_00011B_3 : 1;        // 0x00011B (0x000001) : 0x3
        uint8                       UnknownBit_00011B_4 : 1;        // 0x00011B (0x000001) : 0x4
        uint8                       UnknownBit_00011B_5 : 1;        // 0x00011B (0x000001) : 0x5
        uint8                       UnknownBit_00011B_6 : 1;        // 0x00011B (0x000001) : 0x6
        uint8                       UnknownBit_00011B_7 : 1;        // 0x00011B (0x000001) : 0x7
        uint8                       bAffectTargetScaleY : 1;        // 0x00011C (0x000001) : 0x0
        uint8                       bAffectTargetScaleZ : 1;        // 0x00011C (0x000001) : 0x0
        uint8                       UnknownBit_00011C_1 : 1;        // 0x00011C (0x000001) : 0x1
        uint8                       UnknownBit_00011C_2 : 1;        // 0x00011C (0x000001) : 0x2
        uint8                       UnknownBit_00011C_3 : 1;        // 0x00011C (0x000001) : 0x3
        uint8                       UnknownBit_00011C_4 : 1;        // 0x00011C (0x000001) : 0x4
        uint8                       UnknownBit_00011C_5 : 1;        // 0x00011C (0x000001) : 0x5
        uint8                       UnknownBit_00011C_6 : 1;        // 0x00011C (0x000001) : 0x6
        uint8                       UnknownBit_00011C_7 : 1;        // 0x00011C (0x000001) : 0x7
        uint8                       UnknownData_00011D[0x000003];   // 0x00011D (0x000003)
    };
    // Size: 0x0001B0 (0x0000E8)
    struct alignas(0x8) FAnimNode_CCDIK : public FAnimNode_SkeletalControlBase
    {
        FVector                         EffectorLocation;               // 0x0000C8 (0x000018)
        TEnumAsByte<EBoneControlSpace>  EffectorLocationSpace;          // 0x0000E0 (0x000001) [Default: 0]
        uint8                           UnknownData_0000E1[0x00000F];   // 0x0000E1 (0x00000F)
        FBoneSocketTarget               EffectorTarget;                 // 0x0000F0 (0x000080)
        FBoneReference                  TipBone;                        // 0x000170 (0x00000C)
        FBoneReference                  RootBone;                       // 0x00017C (0x00000C)
        float                           Precision;                      // 0x000188 (0x000004) [Default: 0f]
        int32                           MaxIterations;                  // 0x00018C (0x000004) [Default: 0]
        bool                            bStartFromTail;                 // 0x000190 (0x000001) [Default: false]
        bool                            bEnableRotationLimit;           // 0x000191 (0x000001) [Default: false]
        uint8                           UnknownData_000192[0x000006];   // 0x000192 (0x000006)
        TArray<float>                   RotationLimitPerJoints;         // 0x000198 (0x000010)
        uint8                           UnknownData_0001A8[0x000008];   // 0x0001A8 (0x000008)
    };
    // Size: 0x000038 (0x000028)
    struct alignas(0x8) FAnimNode_CallFunction : public FAnimNode_Base
    {
        FPoseLink               Source;                         // 0x000010 (0x000010)
        uint8                   UnknownData_000020[0x000014];   // 0x000020 (0x000014)
        EAnimFunctionCallSite   CallSite;                       // 0x000034 (0x000004)
    };
    // Size: 0x000108 (0x000040)
    struct alignas(0x8) FAnimNode_Constraint : public FAnimNode_SkeletalControlBase
    {
        FBoneReference      BoneToModify;                   // 0x0000C8 (0x00000C)
        uint8               UnknownData_0000D4[0x000004];   // 0x0000D4 (0x000004)
        TArray<FConstraint> ConstraintSetup;                // 0x0000D8 (0x000010)
        TArray<float>       ConstraintWeights;              // 0x0000E8 (0x000010)
        uint8               UnknownData_0000F8[0x000010];   // 0x0000F8 (0x000010)
    };
    // Size: 0x0000E8 (0x000020)
    struct alignas(0x8) FAnimNode_CopyBone : public FAnimNode_SkeletalControlBase
    {
        FBoneReference                  SourceBone;                     // 0x0000C8 (0x00000C)
        FBoneReference                  TargetBone;                     // 0x0000D4 (0x00000C)
        bool                            bCopyTranslation;               // 0x0000E0 (0x000001) [Default: false]
        bool                            bCopyRotation;                  // 0x0000E1 (0x000001) [Default: false]
        bool                            bCopyScale;                     // 0x0000E2 (0x000001) [Default: false]
        TEnumAsByte<EBoneControlSpace>  ControlSpace;                   // 0x0000E3 (0x000001) [Default: 0]
        uint8                           UnknownData_0000E4[0x000004];   // 0x0000E4 (0x000004)
    };
    // Size: 0x0000F0 (0x000028)
    struct alignas(0x8) FAnimNode_CopyBoneDelta : public FAnimNode_SkeletalControlBase
    {
        FBoneReference      SourceBone;             // 0x0000C8 (0x00000C)
        FBoneReference      TargetBone;             // 0x0000D4 (0x00000C)
        bool                bCopyTranslation;       // 0x0000E0 (0x000001)
        bool                bCopyRotation;          // 0x0000E1 (0x000001)
        bool                bCopyScale;             // 0x0000E2 (0x000001)
        CopyBoneDeltaMode   CopyMode;               // 0x0000E3 (0x000001)
        float               TranslationMultiplier;  // 0x0000E4 (0x000004)
        float               RotationMultiplier;     // 0x0000E8 (0x000004)
        float               ScaleMultiplier;        // 0x0000EC (0x000004)
    };
    // Size: 0x0000F0 (0x0000E0)
    struct alignas(0x8) FAnimNode_CopyPoseFromMesh : public FAnimNode_Base
    {
        TWeakObjectPtr<USkeletalMeshComponent>  SourceMeshComponent;            // 0x000010 (0x000008)
        uint8                                   bUseAttachedParent : 1;         // 0x000018 (0x000001) : 0x0
        uint8                                   bCopyCurves : 1;                // 0x000018 (0x000001) : 0x0
        uint8                                   UnknownBit_000018_1 : 1;        // 0x000018 (0x000001) : 0x1
        uint8                                   UnknownBit_000018_2 : 1;        // 0x000018 (0x000001) : 0x2
        uint8                                   UnknownBit_000018_3 : 1;        // 0x000018 (0x000001) : 0x3
        uint8                                   UnknownBit_000018_4 : 1;        // 0x000018 (0x000001) : 0x4
        uint8                                   UnknownBit_000018_5 : 1;        // 0x000018 (0x000001) : 0x5
        uint8                                   UnknownBit_000018_6 : 1;        // 0x000018 (0x000001) : 0x6
        uint8                                   UnknownBit_000018_7 : 1;        // 0x000018 (0x000001) : 0x7
        bool                                    bCopyCustomAttributes;          // 0x000019 (0x000001)
        uint8                                   bUseMeshPose : 1;               // 0x00001A (0x000001) : 0x0
        uint8                                   UnknownBit_00001A_1 : 1;        // 0x00001A (0x000001) : 0x1
        uint8                                   UnknownBit_00001A_2 : 1;        // 0x00001A (0x000001) : 0x2
        uint8                                   UnknownBit_00001A_3 : 1;        // 0x00001A (0x000001) : 0x3
        uint8                                   UnknownBit_00001A_4 : 1;        // 0x00001A (0x000001) : 0x4
        uint8                                   UnknownBit_00001A_5 : 1;        // 0x00001A (0x000001) : 0x5
        uint8                                   UnknownBit_00001A_6 : 1;        // 0x00001A (0x000001) : 0x6
        uint8                                   UnknownBit_00001A_7 : 1;        // 0x00001A (0x000001) : 0x7
        uint8                                   UnknownByte_00001B;             // 0x00001B (0x000001)
        FName                                   RootBoneToCopy;                 // 0x00001C (0x000004)
        uint8                                   UnknownData_000020[0x0000D0];   // 0x000020 (0x0000D0)
    };
    // Size: 0x000038 (0x000028)
    struct alignas(0x8) FAnimNode_CurveSource : public FAnimNode_Base
    {
        FPoseLink                               SourcePose;     // 0x000010 (0x000010)
        FName                                   SourceBinding;  // 0x000020 (0x000004) [Default: NAME_None]
        float                                   Alpha;          // 0x000024 (0x000004) [Default: 0f]
        TScriptInterface<ICurveSourceInterface> CurveSource;    // 0x000028 (0x000010)
    };
    // Size: 0x0001E0 (0x000118)
    struct alignas(0x8) FAnimNode_Fabrik : public FAnimNode_SkeletalControlBase
    {
        uint8                               UnknownData_0000C8[0x000008];   // 0x0000C8 (0x000008)
        FTransform                          EffectorTransform;              // 0x0000D0 (0x000060)
        FBoneSocketTarget                   EffectorTarget;                 // 0x000130 (0x000080)
        FBoneReference                      TipBone;                        // 0x0001B0 (0x00000C)
        FBoneReference                      RootBone;                       // 0x0001BC (0x00000C)
        float                               Precision;                      // 0x0001C8 (0x000004)
        int32                               MaxIterations;                  // 0x0001CC (0x000004)
        TEnumAsByte<EBoneControlSpace>      EffectorTransformSpace;         // 0x0001D0 (0x000001)
        TEnumAsByte<EBoneRotationSource>    EffectorRotationSource;         // 0x0001D1 (0x000001)
        uint8                               UnknownData_0001D2[0x00000E];   // 0x0001D2 (0x00000E)
    };
    // Size: 0x000128 (0x000060)
    struct alignas(0x8) FAnimNode_HandIKRetargeting : public FAnimNode_SkeletalControlBase
    {
        FBoneReference          RightHandFK;                    // 0x0000C8 (0x00000C)
        FBoneReference          LeftHandFK;                     // 0x0000D4 (0x00000C)
        FBoneReference          RightHandIK;                    // 0x0000E0 (0x00000C)
        FBoneReference          LeftHandIK;                     // 0x0000EC (0x00000C)
        TArray<FBoneReference>  IKBonesToMove;                  // 0x0000F8 (0x000010)
        FVector                 PerAxisAlpha;                   // 0x000108 (0x000018)
        float                   HandFKWeight;                   // 0x000120 (0x000004) [Default: 7.34685e-40f]
        uint8                   UnknownData_000124[0x000004];   // 0x000124 (0x000004)
    };
    // Size: 0x0000E8 (0x0000D8)
    struct alignas(0x8) FAnimNode_LayeredBoneBlend : public FAnimNode_Base
    {
        FPoseLink                       BasePose;                           // 0x000010 (0x000010)
        TArray<FPoseLink>               BlendPoses;                         // 0x000020 (0x000010)
        ELayeredBoneBlendMode           BlendMode;                          // 0x000030 (0x000001)
        uint8                           UnknownData_000031[0x000007];       // 0x000031 (0x000007)
        TArray<UBlendProfile*>          BlendMasks;                         // 0x000038 (0x000010)
        TArray<FInputBlendPose>         LayerSetup;                         // 0x000048 (0x000010)
        TArray<float>                   BlendWeights;                       // 0x000058 (0x000010)
        uint8                           UnknownData_000068[0x000020];       // 0x000068 (0x000020)
        TArray<FPerBoneBlendWeight>     PerBoneBlendWeights;                // 0x000088 (0x000010)
        uint8                           UnknownData_000098[0x000020];       // 0x000098 (0x000020)
        FGuid                           SkeletonGuid;                       // 0x0000B8 (0x000010)
        FGuid                           VirtualBoneGuid;                    // 0x0000C8 (0x000010)
        uint8                           UnknownData_0000D8[0x000004];       // 0x0000D8 (0x000004)
        int32                           LODThreshold;                       // 0x0000DC (0x000004)
        bool                            bMeshSpaceRotationBlend;            // 0x0000E0 (0x000001)
        bool                            bRootSpaceRotationBlend;            // 0x0000E1 (0x000001)
        bool                            bMeshSpaceScaleBlend;               // 0x0000E2 (0x000001)
        TEnumAsByte<ECurveBlendOption>  CurveBlendOption;                   // 0x0000E3 (0x000001)
        bool                            bBlendRootMotionBasedOnRootBone;    // 0x0000E4 (0x000001)
        bool                            bUpdateBasePoseFirst;               // 0x0000E5 (0x000001)
        uint8                           UnknownData_0000E6[0x000002];       // 0x0000E6 (0x000002)
    };
    // Size: 0x000100 (0x000038)
    struct alignas(0x8) FAnimNode_LegIK : public FAnimNode_SkeletalControlBase
    {
        float                           ReachPrecision;                 // 0x0000C8 (0x000004) [Default: 0f]
        int32                           MaxIterations;                  // 0x0000CC (0x000004) [Default: 0]
        float                           SoftPercentLength;              // 0x0000D0 (0x000004) [Default: 0f]
        float                           SoftAlpha;                      // 0x0000D4 (0x000004) [Default: 0f]
        TArray<FAnimLegIKDefinition>    LegsDefinition;                 // 0x0000D8 (0x000010)
        uint8                           UnknownData_0000E8[0x000018];   // 0x0000E8 (0x000018)
    };
    // Size: 0x000240 (0x000178)
    struct alignas(0x8) FAnimNode_LookAt : public FAnimNode_SkeletalControlBase
    {
        FBoneReference                      BoneToModify;                   // 0x0000C8 (0x00000C)
        uint8                               UnknownData_0000D4[0x00000C];   // 0x0000D4 (0x00000C)
        FBoneSocketTarget                   LookAtTarget;                   // 0x0000E0 (0x000080)
        FVector                             LookAtLocation;                 // 0x000160 (0x000018)
        FAxis                               LookAt_Axis;                    // 0x000178 (0x000020)
        bool                                bUseLookUpAxis;                 // 0x000198 (0x000001) [Default: false]
        TEnumAsByte<EInterpolationBlend>    InterpolationType;              // 0x000199 (0x000001) [Default: 3]
        uint8                               UnknownData_00019A[0x000006];   // 0x00019A (0x000006)
        FAxis                               LookUp_Axis;                    // 0x0001A0 (0x000020)
        float                               LookAtClamp;                    // 0x0001C0 (0x000004) [Default: -7.90697e+18f]
        float                               InterpolationTime;              // 0x0001C4 (0x000004) [Default: 0f]
        float                               InterpolationTriggerThreashold; // 0x0001C8 (0x000004) [Default: 0f]
        uint8                               UnknownData_0001CC[0x000074];   // 0x0001CC (0x000074)
    };
    // Size: 0x000038 (0x000028)
    struct alignas(0x8) FAnimNode_MakeDynamicAdditive : public FAnimNode_Base
    {
        FPoseLink   base;                           // 0x000010 (0x000010)
        FPoseLink   Additive;                       // 0x000020 (0x000010)
        bool        bMeshSpaceAdditive;             // 0x000030 (0x000001) [Default: false]
        uint8       UnknownData_000031[0x000007];   // 0x000031 (0x000007)
    };
    // Size: 0x000010 (0x000000)
    struct FAnimNode_MeshSpaceRefPose : public FAnimNode_Base
    {
    };
    // Size: 0x000078 (0x000000)
    struct FAnimNode_Mirror : public FAnimNode_MirrorBase
    {
    };
    // Size: 0x000078 (0x000068)
    struct alignas(0x8) FAnimNode_MirrorBase : public FAnimNode_Base
    {
        FPoseLink   Source;                         // 0x000010 (0x000010)
        uint8       UnknownData_000020[0x000058];   // 0x000020 (0x000058)
    };
    // Size: 0x000098 (0x000020)
    struct alignas(0x8) FAnimNode_Mirror_Standalone : public FAnimNode_MirrorBase
    {
        bool                bMirror;                        // 0x000078 (0x000001) [Default: true]
        uint8               UnknownData_000079[0x000007];   // 0x000079 (0x000007)
        UMirrorDataTable*   MirrorDataTable;                // 0x000080 (0x000008) [Default: 0x7FE8D84ECD61]
        float               BlendTime;                      // 0x000088 (0x000004) [Default: 4.55419e-25f]
        EMirrorBlendType    BlendType;                      // 0x00008C (0x000001) [Default: EMirrorBlendType(0)]
        bool                bResetChild;                    // 0x00008D (0x000001) [Default: false]
        bool                bBoneMirroring;                 // 0x00008E (0x000001) [Default: false]
        bool                bCurveMirroring;                // 0x00008F (0x000001) [Default: false]
        bool                bAttributeMirroring;            // 0x000090 (0x000001) [Default: true]
        uint8               UnknownData_000091[0x000007];   // 0x000091 (0x000007)
    };
    // Size: 0x000128 (0x000060)
    struct alignas(0x8) FAnimNode_ModifyBone : public FAnimNode_SkeletalControlBase
    {
        FBoneReference                      BoneToModify;                   // 0x0000C8 (0x00000C)
        uint8                               UnknownData_0000D4[0x000004];   // 0x0000D4 (0x000004)
        FVector                             Translation;                    // 0x0000D8 (0x000018)
        FRotator                            Rotation;                       // 0x0000F0 (0x000018)
        FVector                             Scale;                          // 0x000108 (0x000018)
        TEnumAsByte<EBoneModificationMode>  TranslationMode;                // 0x000120 (0x000001)
        TEnumAsByte<EBoneModificationMode>  RotationMode;                   // 0x000121 (0x000001)
        TEnumAsByte<EBoneModificationMode>  ScaleMode;                      // 0x000122 (0x000001)
        TEnumAsByte<EBoneControlSpace>      TranslationSpace;               // 0x000123 (0x000001)
        TEnumAsByte<EBoneControlSpace>      RotationSpace;                  // 0x000124 (0x000001)
        TEnumAsByte<EBoneControlSpace>      ScaleSpace;                     // 0x000125 (0x000001)
        uint8                               UnknownData_000126[0x000002];   // 0x000126 (0x000002)
    };
    // Size: 0x000078 (0x000068)
    struct alignas(0x8) FAnimNode_ModifyCurve : public FAnimNode_Base
    {
        FPoseLink               SourcePose;                     // 0x000010 (0x000010)
        TMap<FName, float>      CurveMap;                       // 0x000020 (0x000010)
        TArray<float>           CurveValues;                    // 0x000030 (0x000010)
        TArray<FName>           CurveNames;                     // 0x000040 (0x000010)
        uint8                   UnknownData_000050[0x000020];   // 0x000050 (0x000020)
        float                   Alpha;                          // 0x000070 (0x000004)
        EModifyCurveApplyMode   ApplyMode;                      // 0x000074 (0x000001)
        uint8                   UnknownData_000075[0x000003];   // 0x000075 (0x000003)
    };
    // Size: 0x000050 (0x000040)
    struct alignas(0x8) FAnimNode_MultiWayBlend : public FAnimNode_Base
    {
        TArray<FPoseLink>   Poses;                          // 0x000010 (0x000010)
        TArray<float>       DesiredAlphas;                  // 0x000020 (0x000010)
        uint8               UnknownData_000030[0x000010];   // 0x000030 (0x000010)
        FInputScaleBias     AlphaScaleBias;                 // 0x000040 (0x000008)
        bool                bAdditiveNode;                  // 0x000048 (0x000001)
        bool                bNormalizeAlpha;                // 0x000049 (0x000001)
        uint8               UnknownData_00004A[0x000006];   // 0x00004A (0x000006)
    };
    // Size: 0x000120 (0x000058)
    struct alignas(0x8) FAnimNode_ObserveBone : public FAnimNode_SkeletalControlBase
    {
        FBoneReference                  BoneToObserve;                  // 0x0000C8 (0x00000C)
        TEnumAsByte<EBoneControlSpace>  DisplaySpace;                   // 0x0000D4 (0x000001) [Default: 0]
        bool                            bRelativeToRefPose;             // 0x0000D5 (0x000001) [Default: false]
        uint8                           UnknownData_0000D6[0x000002];   // 0x0000D6 (0x000002)
        FVector                         Translation;                    // 0x0000D8 (0x000018)
        FRotator                        Rotation;                       // 0x0000F0 (0x000018)
        FVector                         Scale;                          // 0x000108 (0x000018)
    };
    // Size: 0x0000E8 (0x000040)
    struct alignas(0x8) FAnimNode_PoseBlendNode : public FAnimNode_PoseHandler
    {
        FPoseLink           SourcePose;                             // 0x0000A8 (0x000010)
        EAlphaBlendOption   BlendOption;                            // 0x0000B8 (0x000001)
        uint8               UnknownData_0000B9[0x000007];           // 0x0000B9 (0x000007)
        UCurveFloat*        CustomCurve;                            // 0x0000C0 (0x000008)
        bool                bIgnorePoseAssetSourceAnimationCurves;  // 0x0000C8 (0x000001)
        uint8               UnknownData_0000C9[0x000003];           // 0x0000C9 (0x000003)
        int32               LODThreshold;                           // 0x0000CC (0x000004)
        uint8               UnknownData_0000D0[0x000018];           // 0x0000D0 (0x000018)
    };
    // Size: 0x0000B8 (0x000010)
    struct alignas(0x4) FAnimNode_PoseByName : public FAnimNode_PoseHandler
    {
        FName   PoseName;                       // 0x0000A8 (0x000004) [Default: NAME_None]
        float   PoseWeight;                     // 0x0000AC (0x000004) [Default: 0f]
        uint8   UnknownData_0000B0[0x000008];   // 0x0000B0 (0x000008)
    };
    // Size: 0x0001A8 (0x000100)
    struct alignas(0x8) FAnimNode_PoseDriver : public FAnimNode_PoseHandler
    {
        FPoseLink                   SourcePose;                     // 0x0000A8 (0x000010)
        TArray<FBoneReference>      SourceBones;                    // 0x0000B8 (0x000010)
        FBoneReference              EvalSpaceBone;                  // 0x0000C8 (0x00000C)
        bool                        bEvalFromRefPose;               // 0x0000D4 (0x000001)
        uint8                       UnknownData_0000D5[0x000003];   // 0x0000D5 (0x000003)
        TArray<FBoneReference>      OnlyDriveBones;                 // 0x0000D8 (0x000010)
        TArray<FPoseDriverTarget>   PoseTargets;                    // 0x0000E8 (0x000010)
        FRBFParams                  RBFParams;                      // 0x0000F8 (0x000038)
        EPoseDriverSource           DriveSource;                    // 0x000130 (0x000001)
        EPoseDriverOutput           DriveOutput;                    // 0x000131 (0x000001)
        uint8                       UnknownData_000132[0x000042];   // 0x000132 (0x000042)
        int32                       LODThreshold;                   // 0x000174 (0x000004)
        uint8                       UnknownData_000178[0x000030];   // 0x000178 (0x000030)
    };
    // Size: 0x0000A8 (0x000068)
    struct alignas(0x8) FAnimNode_PoseHandler : public FAnimNode_AssetPlayerBase
    {
        UPoseAsset* PoseAsset;                      // 0x000040 (0x000008) [Default: nullptr]
        uint8       UnknownData_000048[0x000060];   // 0x000048 (0x000060)
    };
    // Size: 0x000080 (0x000070)
    struct alignas(0x8) FAnimNode_PoseSnapshot : public FAnimNode_Base
    {
        FName               SnapshotName;                   // 0x000010 (0x000004)
        uint8               UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        FPoseSnapshot       Snapshot;                       // 0x000018 (0x000030)
        ESnapshotSourceMode Mode;                           // 0x000048 (0x000001)
        uint8               UnknownData_000049[0x000037];   // 0x000049 (0x000037)
    };
    // Size: 0x000078 (0x000068)
    struct alignas(0x8) FAnimNode_RandomPlayer : public FAnimNode_AssetPlayerRelevancyBase
    {
        TArray<FRandomPlayerSequenceEntry>  Entries;                        // 0x000010 (0x000010)
        uint8                               UnknownData_000020[0x000008];   // 0x000020 (0x000008)
        void**                              VTable_000028;                  // 0x000028 (0x000008) VTable [180 slots] -> 0x12DD0AB0
        uint8                               UnknownData_000030[0x000040];   // 0x000030 (0x000040)
        float                               BlendWeight;                    // 0x000070 (0x000004) [Default: 0f]
        bool                                bShuffleMode;                   // 0x000074 (0x000001) [Default: false]
        uint8                               UnknownData_000075[0x000003];   // 0x000075 (0x000003)
    };
    // Size: 0x000010 (0x000000)
    struct FAnimNode_RefPose : public FAnimNode_Base
    {
    };
    // Size: 0x000078 (0x000068)
    struct alignas(0x8) FAnimNode_RemoveCurve : public FAnimNode_Base
    {
        FPoseLink           SourcePose;                     // 0x000010 (0x000010)
        bool                bEnabled;                       // 0x000020 (0x000001)
        ERemoveCurveMode    RemoveMode;                     // 0x000021 (0x000001)
        uint8               UnknownData_000022[0x000006];   // 0x000022 (0x000006)
        TSet<FName>         Curves;                         // 0x000028 (0x000010)
        bool                bAffectMorphTargetCurves;       // 0x000038 (0x000001)
        bool                bAffectMaterialCurves;          // 0x000039 (0x000001)
        bool                bAffectRegularCurves;           // 0x00003A (0x000001)
        uint8               UnknownData_00003B[0x000005];   // 0x00003B (0x000005)
        TArray<FName>       MorphTargetCurveNames;          // 0x000040 (0x000010)
        TArray<FName>       MaterialCurveNames;             // 0x000050 (0x000010)
        uint8               UnknownData_000060[0x000018];   // 0x000060 (0x000018)
    };
    // Size: 0x0000D8 (0x000010)
    struct FAnimNode_ResetRoot : public FAnimNode_SkeletalControlBase
    {
        uint8   UnknownData_0000C8[0x000010];   // 0x0000C8 (0x000010)
    };
    // Size: 0x0008B0 (0x0007E8)
    struct alignas(0x8) FAnimNode_RigidBody : public FAnimNode_SkeletalControlBase
    {
        UPhysicsAsset*                  OverridePhysicsAsset;                           // 0x0000C8 (0x000008) [Default: nullptr]
        bool                            bDefaultToSkeletalMeshPhysicsAsset;             // 0x0000D0 (0x000001) [Default: false]
        bool                            bUseDefaultAsSimulated;                         // 0x0000D1 (0x000001) [Default: false]
        uint8                           UnknownData_0000D2[0x000136];                   // 0x0000D2 (0x000136)
        bool                            bUseLocalLODThresholdOnly;                      // 0x000208 (0x000001) [Default: false]
        uint8                           UnknownData_000209[0x000007];                   // 0x000209 (0x000007)
        FVector                         OverrideWorldGravity;                           // 0x000210 (0x000018)
        FVector                         ExternalForce;                                  // 0x000228 (0x000018)
        FVector                         ComponentLinearAccScale;                        // 0x000240 (0x000018)
        FVector                         ComponentLinearVelScale;                        // 0x000258 (0x000018)
        FVector                         ComponentAppliedLinearAccClamp;                 // 0x000270 (0x000018)
        FSimSpaceSettings               SimSpaceSettings;                               // 0x000288 (0x000068)
        float                           CachedBoundsScale;                              // 0x0002F0 (0x000004) [Default: 0f]
        FBoneReference                  BaseBoneRef;                                    // 0x0002F4 (0x00000C)
        TEnumAsByte<ECollisionChannel>  OverlapChannel;                                 // 0x000300 (0x000001) [Default: 0]
        ESimulationSpace                SimulationSpace;                                // 0x000301 (0x000001) [Default: ESimulationSpace(0)]
        bool                            bForceDisableCollisionBetweenConstraintBodies;  // 0x000302 (0x000001) [Default: false]
        bool                            bUseExternalClothCollision;                     // 0x000303 (0x000001) [Default: false]
        uint8                           UnknownByte_000304;                             // 0x000304 (0x000001)
        uint8                           bEnableWorldGeometry : 1;                       // 0x000305 (0x000001) : 0x0 [Default: false]
        uint8                           bOverrideWorldGravity : 1;                      // 0x000305 (0x000001) : 0x0 [Default: false]
        uint8                           bTransferBoneVelocities : 1;                    // 0x000305 (0x000001) : 0x0 [Default: false]
        uint8                           bFreezeIncomingPoseOnStart : 1;                 // 0x000305 (0x000001) : 0x0 [Default: false]
        uint8                           bClampLinearTranslationLimitToRefPose : 1;      // 0x000305 (0x000001) : 0x0 [Default: false]
        uint8                           bAllowPoseScalePropagation : 1;                 // 0x000305 (0x000001) : 0x0 [Default: false]
        uint8                           UnknownBit_000305_1 : 1;                        // 0x000305 (0x000001) : 0x1
        uint8                           UnknownBit_000305_2 : 1;                        // 0x000305 (0x000001) : 0x2
        uint8                           UnknownBit_000305_3 : 1;                        // 0x000305 (0x000001) : 0x3
        uint8                           UnknownBit_000305_4 : 1;                        // 0x000305 (0x000001) : 0x4
        uint8                           UnknownBit_000305_5 : 1;                        // 0x000305 (0x000001) : 0x5
        uint8                           UnknownBit_000305_6 : 1;                        // 0x000305 (0x000001) : 0x6
        uint8                           UnknownBit_000305_7 : 1;                        // 0x000305 (0x000001) : 0x7
        uint8                           UnknownData_000306[0x000002];                   // 0x000306 (0x000002)
        float                           WorldSpaceMinimumScale;                         // 0x000308 (0x000004) [Default: 0f]
        float                           EvaluationResetTime;                            // 0x00030C (0x000004) [Default: 0f]
        float                           BoundsVelocityMultiplier;                       // 0x000310 (0x000004) [Default: 0f]
        float                           MaxVelocityBoundsExpansion;                     // 0x000314 (0x000004) [Default: 0f]
        bool                            bAllowCCD;                                      // 0x000318 (0x000001) [Default: false]
        uint8                           UnknownByte_000319;                             // 0x000319 (0x000001)
        ESimulationTiming               SimulationTiming;                               // 0x00031A (0x000001) [Default: ESimulationTiming(0)]
        uint8                           UnknownData_00031B[0x000595];                   // 0x00031B (0x000595)
    };
    // Size: 0x0000B0 (0x0000A0)
    struct alignas(0x8) FAnimNode_RotateRootBone : public FAnimNode_Base
    {
        FPoseLink               BasePose;                       // 0x000010 (0x000010)
        float                   Pitch;                          // 0x000020 (0x000004)
        float                   Yaw;                            // 0x000024 (0x000004)
        FInputScaleBiasClamp    PitchScaleBiasClamp;            // 0x000028 (0x000030)
        FInputScaleBiasClamp    YawScaleBiasClamp;              // 0x000058 (0x000030)
        FRotator                MeshToComponent;                // 0x000088 (0x000018)
        bool                    bRotateRootMotionAttribute;     // 0x0000A0 (0x000001)
        uint8                   UnknownData_0000A1[0x00000F];   // 0x0000A1 (0x00000F)
    };
    // Size: 0x0000E8 (0x000020)
    struct alignas(0x8) FAnimNode_RotationMultiplier : public FAnimNode_SkeletalControlBase
    {
        FBoneReference          TargetBone;                     // 0x0000C8 (0x00000C)
        FBoneReference          SourceBone;                     // 0x0000D4 (0x00000C)
        float                   Multiplier;                     // 0x0000E0 (0x000004) [Default: 0f]
        TEnumAsByte<EBoneAxis>  RotationAxisToRefer;            // 0x0000E4 (0x000001) [Default: 0]
        bool                    bIsAdditive;                    // 0x0000E5 (0x000001) [Default: false]
        uint8                   UnknownData_0000E6[0x000002];   // 0x0000E6 (0x000002)
    };
    // Size: 0x000128 (0x0000B0)
    struct alignas(0x8) FAnimNode_RotationOffsetBlendSpace : public FAnimNode_BlendSpacePlayer
    {
        FPoseLink               BasePose;                       // 0x000078 (0x000010)
        bool                    bApplyAdditiveInRootSpace;      // 0x000088 (0x000001)
        uint8                   UnknownData_000089[0x000003];   // 0x000089 (0x000003)
        int32                   LODThreshold;                   // 0x00008C (0x000004)
        float                   Alpha;                          // 0x000090 (0x000004)
        FInputScaleBias         AlphaScaleBias;                 // 0x000094 (0x000008)
        uint8                   UnknownData_00009C[0x000004];   // 0x00009C (0x000004)
        FInputAlphaBoolBlend    AlphaBoolBlend;                 // 0x0000A0 (0x000048)
        FName                   AlphaCurveName;                 // 0x0000E8 (0x000004)
        FInputScaleBiasClamp    AlphaScaleBiasClamp;            // 0x0000EC (0x000030)
        uint8                   UnknownData_00011C[0x000004];   // 0x00011C (0x000004)
        EAnimAlphaInputType     AlphaInputType;                 // 0x000120 (0x000001)
        bool                    bAlphaBoolEnabled;              // 0x000121 (0x000001)
        uint8                   UnknownData_000122[0x000006];   // 0x000122 (0x000006)
    };
    // Size: 0x000110 (0x0000B0)
    struct alignas(0x8) FAnimNode_RotationOffsetBlendSpaceGraph : public FAnimNode_BlendSpaceGraphBase
    {
        FPoseLink               BasePose;                       // 0x000060 (0x000010)
        bool                    bApplyAdditiveInRootSpace;      // 0x000070 (0x000001) [Default: false]
        uint8                   UnknownData_000071[0x000003];   // 0x000071 (0x000003)
        int32                   LODThreshold;                   // 0x000074 (0x000004) [Default: 0]
        float                   Alpha;                          // 0x000078 (0x000004) [Default: -933230f]
        FInputScaleBias         AlphaScaleBias;                 // 0x00007C (0x000008)
        uint8                   UnknownData_000084[0x000004];   // 0x000084 (0x000004)
        FInputAlphaBoolBlend    AlphaBoolBlend;                 // 0x000088 (0x000048)
        FName                   AlphaCurveName;                 // 0x0000D0 (0x000004) [Default: FName(185773746) -> L""]
        FInputScaleBiasClamp    AlphaScaleBiasClamp;            // 0x0000D4 (0x000030)
        uint8                   UnknownData_000104[0x000004];   // 0x000104 (0x000004)
        EAnimAlphaInputType     AlphaInputType;                 // 0x000108 (0x000001) [Default: EAnimAlphaInputType(0)]
        bool                    bAlphaBoolEnabled;              // 0x000109 (0x000001) [Default: false]
        uint8                   UnknownData_00010A[0x000006];   // 0x00010A (0x000006)
    };
    // Size: 0x000080 (0x000070)
    struct alignas(0x8) FAnimNode_ScaleChainLength : public FAnimNode_Base
    {
        FPoseLink                   InputPose;                      // 0x000010 (0x000010)
        float                       DefaultChainLength;             // 0x000020 (0x000004)
        FBoneReference              ChainStartBone;                 // 0x000024 (0x00000C)
        FBoneReference              ChainEndBone;                   // 0x000030 (0x00000C)
        uint8                       UnknownData_00003C[0x000004];   // 0x00003C (0x000004)
        FVector                     TargetLocation;                 // 0x000040 (0x000018)
        float                       Alpha;                          // 0x000058 (0x000004)
        uint8                       UnknownData_00005C[0x000004];   // 0x00005C (0x000004)
        FInputScaleBias             AlphaScaleBias;                 // 0x000060 (0x000008)
        EScaleChainInitialLength    ChainInitialLength;             // 0x000068 (0x000001)
        uint8                       UnknownData_000069[0x000017];   // 0x000069 (0x000017)
    };
    // Size: 0x000048 (0x000000)
    struct FAnimNode_SequenceEvaluator : public FAnimNode_SequenceEvaluatorBase
    {
    };
    // Size: 0x000048 (0x000008)
    struct FAnimNode_SequenceEvaluatorBase : public FAnimNode_AssetPlayerBase
    {
        uint8   UnknownData_000040[0x000008];   // 0x000040 (0x000008)
    };
    // Size: 0x000070 (0x000028)
    struct alignas(0x8) FAnimNode_SequenceEvaluator_Standalone : public FAnimNode_SequenceEvaluatorBase
    {
        FName                               GroupName;                      // 0x000048 (0x000004)
        TEnumAsByte<EAnimGroupRole>         GroupRole;                      // 0x00004C (0x000001)
        EAnimSyncMethod                     Method;                         // 0x00004D (0x000001)
        bool                                bIgnoreForRelevancyTest;        // 0x00004E (0x000001)
        uint8                               UnknownByte_00004F;             // 0x00004F (0x000001)
        UAnimSequenceBase*                  Sequence;                       // 0x000050 (0x000008)
        float                               ExplicitTime;                   // 0x000058 (0x000004)
        bool                                bUseExplicitFrame;              // 0x00005C (0x000001)
        uint8                               UnknownData_00005D[0x000003];   // 0x00005D (0x000003)
        int32                               ExplicitFrame;                  // 0x000060 (0x000004)
        bool                                bShouldLoop;                    // 0x000064 (0x000001)
        bool                                bTeleportToExplicitTime;        // 0x000065 (0x000001)
        TEnumAsByte<ESequenceEvalReinit>    ReinitializationBehavior;       // 0x000066 (0x000001)
        uint8                               UnknownByte_000067;             // 0x000067 (0x000001)
        float                               StartPosition;                  // 0x000068 (0x000004)
        uint8                               UnknownData_00006C[0x000004];   // 0x00006C (0x000004)
    };
    // Size: 0x0000C8 (0x0000B8)
    struct alignas(0x8) FAnimNode_SkeletalControlBase : public FAnimNode_Base
    {
        FComponentSpacePoseLink ComponentPose;                  // 0x000010 (0x000010)
        int32                   LODThreshold;                   // 0x000020 (0x000004) [Default: 1]
        float                   ActualAlpha;                    // 0x000024 (0x000004) [Default: 0f]
        EAnimAlphaInputType     AlphaInputType;                 // 0x000028 (0x000001) [Default: EAnimAlphaInputType(2)]
        bool                    bAlphaBoolEnabled;              // 0x000029 (0x000001) [Default: false]
        uint8                   UnknownData_00002A[0x000002];   // 0x00002A (0x000002)
        float                   Alpha;                          // 0x00002C (0x000004) [Default: 0f]
        FInputScaleBias         AlphaScaleBias;                 // 0x000030 (0x000008)
        FInputAlphaBoolBlend    AlphaBoolBlend;                 // 0x000038 (0x000048)
        FName                   AlphaCurveName;                 // 0x000080 (0x000004) [Default: FName(386655760) -> L""]
        FInputScaleBiasClamp    AlphaScaleBiasClamp;            // 0x000084 (0x000030)
        uint8                   UnknownData_0000B4[0x000014];   // 0x0000B4 (0x000014)
    };
    // Size: 0x000048 (0x000038)
    struct alignas(0x8) FAnimNode_Slot : public FAnimNode_Base
    {
        FPoseLink   Source;                         // 0x000010 (0x000010)
        FName       SlotName;                       // 0x000020 (0x000004) [Default: FName(1) -> L""]
        bool        bAlwaysUpdateSourcePose;        // 0x000024 (0x000001) [Default: false]
        uint8       UnknownData_000025[0x000023];   // 0x000025 (0x000023)
    };
    // Size: 0x000258 (0x000190)
    struct alignas(0x8) FAnimNode_SplineIK : public FAnimNode_SkeletalControlBase
    {
        FBoneReference      StartBone;                      // 0x0000C8 (0x00000C)
        FBoneReference      EndBone;                        // 0x0000D4 (0x00000C)
        ESplineBoneAxis     BoneAxis;                       // 0x0000E0 (0x000001)
        bool                bAutoCalculateSpline;           // 0x0000E1 (0x000001)
        uint8               UnknownData_0000E2[0x000002];   // 0x0000E2 (0x000002)
        int32               PointCount;                     // 0x0000E4 (0x000004)
        TArray<FTransform>  ControlPoints;                  // 0x0000E8 (0x000010)
        float               Roll;                           // 0x0000F8 (0x000004)
        float               TwistStart;                     // 0x0000FC (0x000004)
        float               TwistEnd;                       // 0x000100 (0x000004)
        uint8               UnknownData_000104[0x000004];   // 0x000104 (0x000004)
        FAlphaBlend         TwistBlend;                     // 0x000108 (0x000030)
        float               Stretch;                        // 0x000138 (0x000004)
        float               Offset;                         // 0x00013C (0x000004)
        uint8               UnknownData_000140[0x000118];   // 0x000140 (0x000118)
    };
    // Size: 0x000180 (0x0000B8)
    struct alignas(0x8) FAnimNode_SpringBone : public FAnimNode_SkeletalControlBase
    {
        FBoneReference  SpringBone;                     // 0x0000C8 (0x00000C)
        uint8           UnknownData_0000D4[0x000004];   // 0x0000D4 (0x000004)
        double          MaxDisplacement;                // 0x0000D8 (0x000008)
        double          SpringStiffness;                // 0x0000E0 (0x000008)
        double          SpringDamping;                  // 0x0000E8 (0x000008)
        double          ErrorResetThresh;               // 0x0000F0 (0x000008)
        uint8           UnknownData_0000F8[0x00006C];   // 0x0000F8 (0x00006C)
        uint8           bLimitDisplacement : 1;         // 0x000164 (0x000001) : 0x0
        uint8           bTranslateX : 1;                // 0x000164 (0x000001) : 0x0
        uint8           bTranslateY : 1;                // 0x000164 (0x000001) : 0x0
        uint8           bTranslateZ : 1;                // 0x000164 (0x000001) : 0x0
        uint8           bRotateX : 1;                   // 0x000164 (0x000001) : 0x0
        uint8           bRotateY : 1;                   // 0x000164 (0x000001) : 0x0
        uint8           bRotateZ : 1;                   // 0x000164 (0x000001) : 0x0
        uint8           UnknownBit_000164_1 : 1;        // 0x000164 (0x000001) : 0x1
        uint8           UnknownBit_000164_2 : 1;        // 0x000164 (0x000001) : 0x2
        uint8           UnknownBit_000164_3 : 1;        // 0x000164 (0x000001) : 0x3
        uint8           UnknownBit_000164_4 : 1;        // 0x000164 (0x000001) : 0x4
        uint8           UnknownBit_000164_5 : 1;        // 0x000164 (0x000001) : 0x5
        uint8           UnknownBit_000164_6 : 1;        // 0x000164 (0x000001) : 0x6
        uint8           UnknownBit_000164_7 : 1;        // 0x000164 (0x000001) : 0x7
        uint8           bOverrideOwnerVelocity : 1;     // 0x000165 (0x000001) : 0x0
        uint8           UnknownBit_000165_1 : 1;        // 0x000165 (0x000001) : 0x1
        uint8           UnknownBit_000165_2 : 1;        // 0x000165 (0x000001) : 0x2
        uint8           UnknownBit_000165_3 : 1;        // 0x000165 (0x000001) : 0x3
        uint8           UnknownBit_000165_4 : 1;        // 0x000165 (0x000001) : 0x4
        uint8           UnknownBit_000165_5 : 1;        // 0x000165 (0x000001) : 0x5
        uint8           UnknownBit_000165_6 : 1;        // 0x000165 (0x000001) : 0x6
        uint8           UnknownBit_000165_7 : 1;        // 0x000165 (0x000001) : 0x7
        uint8           UnknownData_000166[0x000002];   // 0x000166 (0x000002)
        FVector         OwnerVelocityOverride;          // 0x000168 (0x000018)
    };
    // Size: 0x000028 (0x000018)
    struct alignas(0x8) FAnimNode_Sync : public FAnimNode_Base
    {
        FPoseLink                   Source;                         // 0x000010 (0x000010)
        FName                       GroupName;                      // 0x000020 (0x000004)
        TEnumAsByte<EAnimGroupRole> GroupRole;                      // 0x000024 (0x000001)
        uint8                       UnknownData_000025[0x000003];   // 0x000025 (0x000003)
    };
    // Size: 0x000260 (0x000198)
    struct alignas(0x8) FAnimNode_Trail : public FAnimNode_SkeletalControlBase
    {
        uint8                           UnknownData_0000C8[0x000068];       // 0x0000C8 (0x000068)
        FBoneReference                  TrailBone;                          // 0x000130 (0x00000C)
        int32                           ChainLength;                        // 0x00013C (0x000004)
        TEnumAsByte<EAxis>              ChainBoneAxis;                      // 0x000140 (0x000001)
        uint8                           bInvertChainBoneAxis : 1;           // 0x000141 (0x000001) : 0x0
        uint8                           bLimitStretch : 1;                  // 0x000141 (0x000001) : 0x0
        uint8                           bLimitRotation : 1;                 // 0x000141 (0x000001) : 0x0
        uint8                           bUsePlanarLimit : 1;                // 0x000141 (0x000001) : 0x0
        uint8                           bActorSpaceFakeVel : 1;             // 0x000141 (0x000001) : 0x0
        uint8                           bReorientParentToChild : 1;         // 0x000141 (0x000001) : 0x0
        uint8                           UnknownBit_000141_1 : 1;            // 0x000141 (0x000001) : 0x1
        uint8                           UnknownBit_000141_2 : 1;            // 0x000141 (0x000001) : 0x2
        uint8                           UnknownBit_000141_3 : 1;            // 0x000141 (0x000001) : 0x3
        uint8                           UnknownBit_000141_4 : 1;            // 0x000141 (0x000001) : 0x4
        uint8                           UnknownBit_000141_5 : 1;            // 0x000141 (0x000001) : 0x5
        uint8                           UnknownBit_000141_6 : 1;            // 0x000141 (0x000001) : 0x6
        uint8                           UnknownBit_000141_7 : 1;            // 0x000141 (0x000001) : 0x7
        uint8                           UnknownData_000142[0x000002];       // 0x000142 (0x000002)
        float                           MaxDeltaTime;                       // 0x000144 (0x000004)
        float                           RelaxationSpeedScale;               // 0x000148 (0x000004)
        uint8                           UnknownData_00014C[0x000004];       // 0x00014C (0x000004)
        FRuntimeFloatCurve              TrailRelaxationSpeed;               // 0x000150 (0x000048)
        FInputScaleBiasClamp            RelaxationSpeedScaleInputProcessor; // 0x000198 (0x000030)
        TArray<FRotationLimit>          RotationLimits;                     // 0x0001C8 (0x000010)
        TArray<FVector>                 RotationOffsets;                    // 0x0001D8 (0x000010)
        TArray<FAnimPhysPlanarLimit>    PlanarLimits;                       // 0x0001E8 (0x000010)
        float                           StretchLimit;                       // 0x0001F8 (0x000004)
        uint8                           UnknownData_0001FC[0x000004];       // 0x0001FC (0x000004)
        FVector                         FakeVelocity;                       // 0x000200 (0x000018)
        FBoneReference                  BaseJoint;                          // 0x000218 (0x00000C)
        float                           LastBoneRotationAnimAlphaBlend;     // 0x000224 (0x000004)
        uint8                           UnknownData_000228[0x000038];       // 0x000228 (0x000038)
    };
    // Size: 0x000160 (0x000098)
    struct alignas(0x8) FAnimNode_TwistCorrectiveNode : public FAnimNode_SkeletalControlBase
    {
        FReferenceBoneFrame BaseFrame;                      // 0x0000C8 (0x000030)
        FReferenceBoneFrame TwistFrame;                     // 0x0000F8 (0x000030)
        FAxis               TwistPlaneNormalAxis;           // 0x000128 (0x000020)
        float               RangeMax;                       // 0x000148 (0x000004)
        float               RemappedMin;                    // 0x00014C (0x000004)
        float               RemappedMax;                    // 0x000150 (0x000004)
        FName               CurveName;                      // 0x000154 (0x000004)
        uint8               UnknownData_000158[0x000008];   // 0x000158 (0x000008)
    };
    // Size: 0x000260 (0x000198)
    struct alignas(0x8) FAnimNode_TwoBoneIK : public FAnimNode_SkeletalControlBase
    {
        FBoneReference                  IKBone;                         // 0x0000C8 (0x00000C)
        uint8                           UnknownData_0000D4[0x000004];   // 0x0000D4 (0x000004)
        double                          StartStretchRatio;              // 0x0000D8 (0x000008)
        double                          MaxStretchScale;                // 0x0000E0 (0x000008)
        FVector                         EffectorLocation;               // 0x0000E8 (0x000018)
        uint8                           UnknownData_000100[0x000010];   // 0x000100 (0x000010)
        FBoneSocketTarget               EffectorTarget;                 // 0x000110 (0x000080)
        FVector                         JointTargetLocation;            // 0x000190 (0x000018)
        uint8                           UnknownData_0001A8[0x000008];   // 0x0001A8 (0x000008)
        FBoneSocketTarget               JointTarget;                    // 0x0001B0 (0x000080)
        FAxis                           TwistAxis;                      // 0x000230 (0x000020)
        TEnumAsByte<EBoneControlSpace>  EffectorLocationSpace;          // 0x000250 (0x000001)
        TEnumAsByte<EBoneControlSpace>  JointTargetLocationSpace;       // 0x000251 (0x000001)
        uint8                           bAllowStretching : 1;           // 0x000252 (0x000001) : 0x0
        uint8                           bTakeRotationFromEffectorSpace : 1; // 0x000252 (0x000001) : 0x0
        uint8                           bMaintainEffectorRelRot : 1;    // 0x000252 (0x000001) : 0x0
        uint8                           bAllowTwist : 1;                // 0x000252 (0x000001) : 0x0
        uint8                           UnknownBit_000252_1 : 1;        // 0x000252 (0x000001) : 0x1
        uint8                           UnknownBit_000252_2 : 1;        // 0x000252 (0x000001) : 0x2
        uint8                           UnknownBit_000252_3 : 1;        // 0x000252 (0x000001) : 0x3
        uint8                           UnknownBit_000252_4 : 1;        // 0x000252 (0x000001) : 0x4
        uint8                           UnknownBit_000252_5 : 1;        // 0x000252 (0x000001) : 0x5
        uint8                           UnknownBit_000252_6 : 1;        // 0x000252 (0x000001) : 0x6
        uint8                           UnknownBit_000252_7 : 1;        // 0x000252 (0x000001) : 0x7
        uint8                           UnknownData_000253[0x00000D];   // 0x000253 (0x00000D)
    };
    // Size: 0x0000C0 (0x0000B0)
    struct alignas(0x8) FAnimNode_TwoWayBlend : public FAnimNode_Base
    {
        FPoseLink               A;                              // 0x000010 (0x000010)
        FPoseLink               B;                              // 0x000020 (0x000010)
        EAnimAlphaInputType     AlphaInputType;                 // 0x000030 (0x000001)
        uint8                   bAlphaBoolEnabled : 1;          // 0x000031 (0x000001) : 0x0
        uint8                   bResetChildOnActivation : 1;    // 0x000031 (0x000001) : 0x0
        uint8                   bAlwaysUpdateChildren : 1;      // 0x000031 (0x000001) : 0x0
        uint8                   UnknownBit_000031_1 : 1;        // 0x000031 (0x000001) : 0x1
        uint8                   UnknownBit_000031_2 : 1;        // 0x000031 (0x000001) : 0x2
        uint8                   UnknownBit_000031_3 : 1;        // 0x000031 (0x000001) : 0x3
        uint8                   UnknownBit_000031_4 : 1;        // 0x000031 (0x000001) : 0x4
        uint8                   UnknownBit_000031_5 : 1;        // 0x000031 (0x000001) : 0x5
        uint8                   UnknownBit_000031_6 : 1;        // 0x000031 (0x000001) : 0x6
        uint8                   UnknownBit_000031_7 : 1;        // 0x000031 (0x000001) : 0x7
        uint8                   UnknownData_000032[0x000002];   // 0x000032 (0x000002)
        float                   Alpha;                          // 0x000034 (0x000004)
        FInputScaleBias         AlphaScaleBias;                 // 0x000038 (0x000008)
        FInputAlphaBoolBlend    AlphaBoolBlend;                 // 0x000040 (0x000048)
        FName                   AlphaCurveName;                 // 0x000088 (0x000004)
        FInputScaleBiasClamp    AlphaScaleBiasClamp;            // 0x00008C (0x000030)
        uint8                   UnknownData_0000BC[0x000004];   // 0x0000BC (0x000004)
    };
    // Size: 0x0000D0 (0x0000D0)
    struct alignas(0x8) FAnimPhysBodyDefinition
    {
        FBoneReference              BoundBone;                      // 0x000000 (0x00000C)
        uint8                       UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FVector                     BoxExtents;                     // 0x000010 (0x000018)
        FVector                     LocalJointOffset;               // 0x000028 (0x000018)
        FAnimPhysConstraintSetup    ConstraintSetup;                // 0x000040 (0x000088)
        AnimPhysCollisionType       CollisionType;                  // 0x0000C8 (0x000001)
        uint8                       UnknownData_0000C9[0x000003];   // 0x0000C9 (0x000003)
        float                       SphereCollisionRadius;          // 0x0000CC (0x000004)
    };
    // Size: 0x000088 (0x000088)
    struct alignas(0x8) FAnimPhysConstraintSetup
    {
        AnimPhysLinearConstraintType    LinearXLimitType;               // 0x000000 (0x000001)
        AnimPhysLinearConstraintType    LinearYLimitType;               // 0x000001 (0x000001)
        AnimPhysLinearConstraintType    LinearZLimitType;               // 0x000002 (0x000001)
        uint8                           UnknownData_000003[0x000005];   // 0x000003 (0x000005)
        FVector                         LinearAxesMin;                  // 0x000008 (0x000018)
        FVector                         LinearAxesMax;                  // 0x000020 (0x000018)
        AnimPhysAngularConstraintType   AngularConstraintType;          // 0x000038 (0x000001)
        AnimPhysTwistAxis               TwistAxis;                      // 0x000039 (0x000001)
        AnimPhysTwistAxis               AngularTargetAxis;              // 0x00003A (0x000001)
        uint8                           UnknownByte_00003B;             // 0x00003B (0x000001)
        float                           ConeAngle;                      // 0x00003C (0x000004)
        FVector                         AngularLimitsMin;               // 0x000040 (0x000018)
        FVector                         AngularLimitsMax;               // 0x000058 (0x000018)
        FVector                         AngularTarget;                  // 0x000070 (0x000018)
    };
    // Size: 0x000070 (0x000070)
    struct alignas(0x8) FAnimPhysPlanarLimit
    {
        FBoneReference  DrivingBone;                    // 0x000000 (0x00000C)
        uint8           UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FTransform      PlaneTransform;                 // 0x000010 (0x000060)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FAnimPhysSimSpaceSettings
    {
        float   SimSpaceAngularAlpha;           // 0x000000 (0x000004)
        float   MaxAngularVelocity;             // 0x000004 (0x000004)
        float   MaxAngularAcceleration;         // 0x000008 (0x000004)
        uint8   UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FVector ExternalAngularVelocity;        // 0x000010 (0x000018)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FAnimPhysSphericalLimit
    {
        FBoneReference      DrivingBone;                    // 0x000000 (0x00000C)
        uint8               UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FVector             SphereLocalOffset;              // 0x000010 (0x000018)
        float               LimitRadius;                    // 0x000028 (0x000004)
        ESphericalLimitType LimitType;                      // 0x00002C (0x000001)
        uint8               UnknownData_00002D[0x000003];   // 0x00002D (0x000003)
    };
    // Size: 0x000860 (0x0003E0)
    struct FAnimSequencerInstanceProxy : public FAnimInstanceProxy
    {
        uint8   UnknownData_000480[0x0003E0];   // 0x000480 (0x0003E0)
    };
    // Size: 0x000010 (0x000000)
    struct FAnimationStateMachineReference : public FAnimNodeReference
    {
    };
    // Size: 0x000010 (0x000000)
    struct FAnimationStateResultReference : public FAnimNodeReference
    {
    };
    // Size: 0x00001C (0x00001C)
    struct alignas(0x8) FBlendBoneByChannelEntry
    {
        FBoneReference  SourceBone;         // 0x000000 (0x00000C)
        FBoneReference  TargetBone;         // 0x00000C (0x00000C)
        bool            bBlendTranslation;  // 0x000018 (0x000001)
        bool            bBlendRotation;     // 0x000019 (0x000001)
        bool            bBlendScale;        // 0x00001A (0x000001)
        uint8           UnknownByte_00001B; // 0x00001B (0x000001)
    };
    // Size: 0x000010 (0x000000)
    struct FBlendListBaseReference : public FAnimNodeReference
    {
    };
    // Size: 0x000010 (0x000000)
    struct FBlendSpacePlayerReference : public FAnimNodeReference
    {
    };
    // Size: 0x000010 (0x000000)
    struct FBlendSpaceReference : public FAnimNodeReference
    {
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FConstraint
    {
        FBoneReference              TargetBone;                     // 0x000000 (0x00000C)
        EConstraintOffsetOption     OffsetOption;                   // 0x00000C (0x000001)
        ETransformConstraintType    TransformType;                  // 0x00000D (0x000001)
        FFilterOptionPerAxis        PerAxis;                        // 0x00000E (0x000003)
        uint8                       UnknownData_000011[0x000007];   // 0x000011 (0x000007)
    };
    // Size: 0x000050 (0x000050)
    struct FIKChain
    {
        uint8   UnknownData_000000[0x000050];   // 0x000000 (0x000050)
    };
    // Size: 0x000070 (0x000070)
    struct alignas(0x8) FIKChainLink
    {
        uint8   UnknownData_000000[0x000008];   // 0x000000 (0x000008)
        void**  VTable_000008;                  // 0x000008 (0x000008) VTable [108 slots] -> 0x1527E848
        uint8   UnknownData_000010[0x000060];   // 0x000010 (0x000060)
    };
    // Size: 0x000080 (0x000080)
    struct alignas(0x8) FIKFootPelvisPullDownSolver
    {
        FVectorRK4SpringInterpolator    PelvisAdjustmentInterp;         // 0x000000 (0x000008)
        uint8                           UnknownData_000008[0x000058];   // 0x000008 (0x000058)
        double                          PelvisAdjustmentInterpAlpha;    // 0x000060 (0x000008) [Default: 0]
        double                          PelvisAdjustmentMaxDistance;    // 0x000068 (0x000008) [Default: 0]
        double                          PelvisAdjustmentErrorTolerance; // 0x000070 (0x000008) [Default: 0]
        int32                           PelvisAdjustmentMaxIter;        // 0x000078 (0x000004) [Default: 0]
        uint8                           UnknownData_00007C[0x000004];   // 0x00007C (0x000004)
    };
    // Size: 0x000010 (0x000000)
    struct FLayeredBoneBlendReference : public FAnimNodeReference
    {
    };
    // Size: 0x000010 (0x000000)
    struct FLinkedAnimGraphReference : public FAnimNodeReference
    {
    };
    // Size: 0x000010 (0x000000)
    struct FMirrorAnimNodeReference : public FAnimNodeReference
    {
    };
    // Size: 0x000010 (0x000000)
    struct FModifyCurveAnimNodeReference : public FAnimNodeReference
    {
    };
    // Size: 0x000080 (0x000080)
    struct alignas(0x8) FPoseDriverTarget
    {
        TArray<FPoseDriverTransform>    BoneTransforms;                 // 0x000000 (0x000010)
        FRotator                        TargetRotation;                 // 0x000010 (0x000018)
        float                           TargetScale;                    // 0x000028 (0x000004)
        ERBFDistanceMethod              DistanceMethod;                 // 0x00002C (0x000001)
        ERBFFunctionType                FunctionType;                   // 0x00002D (0x000001)
        bool                            bApplyCustomCurve;              // 0x00002E (0x000001)
        uint8                           UnknownByte_00002F;             // 0x00002F (0x000001)
        FRichCurve                      CustomCurve;                    // 0x000030 (0x000040)
        FName                           DrivenName;                     // 0x000070 (0x000004)
        uint8                           UnknownData_000074[0x000004];   // 0x000074 (0x000004)
        bool                            bIsHidden;                      // 0x000078 (0x000001)
        uint8                           UnknownData_000079[0x000007];   // 0x000079 (0x000007)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FPoseDriverTransform
    {
        FVector     TargetTranslation;  // 0x000000 (0x000018)
        FRotator    TargetRotation;     // 0x000018 (0x000018)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FPositionHistory
    {
        TArray<FVector> Positions;                      // 0x000000 (0x000010)
        float           Range;                          // 0x000010 (0x000004)
        uint8           UnknownData_000014[0x00001C];   // 0x000014 (0x00001C)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FRBFEntry
    {
        TArray<float>   Values; // 0x000000 (0x000010)
    };
    // Size: 0x000038 (0x000038)
    struct alignas(0x8) FRBFParams
    {
        int32                   TargetDimensions;               // 0x000000 (0x000004) [Default: 0]
        ERBFSolverType          SolverType;                     // 0x000004 (0x000001) [Default: ERBFSolverType(0)]
        uint8                   UnknownData_000005[0x000003];   // 0x000005 (0x000003)
        float                   Radius;                         // 0x000008 (0x000004) [Default: 0f]
        bool                    bAutomaticRadius;               // 0x00000C (0x000001) [Default: false]
        ERBFFunctionType        Function;                       // 0x00000D (0x000001) [Default: ERBFFunctionType(0)]
        ERBFDistanceMethod      DistanceMethod;                 // 0x00000E (0x000001) [Default: ERBFDistanceMethod(0)]
        TEnumAsByte<EBoneAxis>  TwistAxis;                      // 0x00000F (0x000001) [Default: 0]
        float                   WeightThreshold;                // 0x000010 (0x000004) [Default: 0f]
        ERBFNormalizeMethod     NormalizeMethod;                // 0x000014 (0x000001) [Default: ERBFNormalizeMethod(0)]
        uint8                   UnknownData_000015[0x000003];   // 0x000015 (0x000003)
        FVector                 MedianReference;                // 0x000018 (0x000018)
        float                   MedianMin;                      // 0x000030 (0x000004) [Default: 0f]
        float                   MedianMax;                      // 0x000034 (0x000004) [Default: 0f]
    };
    // Size: 0x000060 (0x000050)
    struct alignas(0x8) FRBFTarget : public FRBFEntry
    {
        float               ScaleFactor;                    // 0x000010 (0x000004)
        bool                bApplyCustomCurve;              // 0x000014 (0x000001)
        uint8               UnknownData_000015[0x000003];   // 0x000015 (0x000003)
        FRichCurve          CustomCurve;                    // 0x000018 (0x000040)
        ERBFDistanceMethod  DistanceMethod;                 // 0x000058 (0x000001)
        ERBFFunctionType    FunctionType;                   // 0x000059 (0x000001)
        uint8               UnknownData_00005A[0x000006];   // 0x00005A (0x000006)
    };
    // Size: 0x000050 (0x000050)
    struct alignas(0x8) FRandomPlayerSequenceEntry
    {
        UAnimSequenceBase*  Sequence;                       // 0x000000 (0x000008)
        float               ChanceToPlay;                   // 0x000008 (0x000004)
        int32               MinLoopCount;                   // 0x00000C (0x000004)
        int32               MaxLoopCount;                   // 0x000010 (0x000004)
        float               MinPlayrate;                    // 0x000014 (0x000004)
        float               MaxPlayrate;                    // 0x000018 (0x000004)
        uint8               UnknownData_00001C[0x000004];   // 0x00001C (0x000004)
        FAlphaBlend         BlendIn;                        // 0x000020 (0x000030)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FReferenceBoneFrame
    {
        FBoneReference  bone;                           // 0x000000 (0x00000C)
        uint8           UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FAxis           Axis;                           // 0x000010 (0x000020)
    };
    // Size: 0x000010 (0x000000)
    struct FRigidBodyAnimNodeReference : public FAnimNodeReference
    {
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FRotationLimit
    {
        FVector LimitMin;   // 0x000000 (0x000018)
        FVector LimitMax;   // 0x000018 (0x000018)
    };
    // Size: 0x000160 (0x000160)
    struct alignas(0x8) FRotationRetargetingInfo
    {
        bool                bEnabled;                       // 0x000000 (0x000001)
        uint8               UnknownData_000001[0x00000F];   // 0x000001 (0x00000F)
        FTransform          Source;                         // 0x000010 (0x000060)
        FTransform          Target;                         // 0x000070 (0x000060)
        ERotationComponent  RotationComponent;              // 0x0000D0 (0x000001)
        uint8               UnknownData_0000D1[0x000007];   // 0x0000D1 (0x000007)
        FVector             TwistAxis;                      // 0x0000D8 (0x000018)
        bool                bUseAbsoluteAngle;              // 0x0000F0 (0x000001)
        uint8               UnknownData_0000F1[0x000003];   // 0x0000F1 (0x000003)
        float               SourceMinimum;                  // 0x0000F4 (0x000004)
        float               SourceMaximum;                  // 0x0000F8 (0x000004)
        float               TargetMinimum;                  // 0x0000FC (0x000004)
        float               TargetMaximum;                  // 0x000100 (0x000004)
        EEasingFuncType     EasingType;                     // 0x000104 (0x000001)
        uint8               UnknownData_000105[0x000003];   // 0x000105 (0x000003)
        FRuntimeFloatCurve  CustomCurve;                    // 0x000108 (0x000048)
        bool                bFlipEasing;                    // 0x000150 (0x000001)
        uint8               UnknownData_000151[0x000003];   // 0x000151 (0x000003)
        float               EasingWeight;                   // 0x000154 (0x000004)
        bool                bClamp;                         // 0x000158 (0x000001)
        uint8               UnknownData_000159[0x000007];   // 0x000159 (0x000007)
    };
    // Size: 0x000010 (0x000000)
    struct FSequenceEvaluatorReference : public FAnimNodeReference
    {
    };
    // Size: 0x000010 (0x000000)
    struct FSequencePlayerReference : public FAnimNodeReference
    {
    };
    // Size: 0x000068 (0x000068)
    struct alignas(0x8) FSimSpaceSettings
    {
        float   WorldAlpha;                     // 0x000000 (0x000004)
        float   VelocityScaleZ;                 // 0x000004 (0x000004)
        float   DampingAlpha;                   // 0x000008 (0x000004)
        float   MaxLinearVelocity;              // 0x00000C (0x000004)
        float   MaxAngularVelocity;             // 0x000010 (0x000004)
        float   MaxLinearAcceleration;          // 0x000014 (0x000004)
        float   MaxAngularAcceleration;         // 0x000018 (0x000004)
        uint8   UnknownData_00001C[0x000004];   // 0x00001C (0x000004)
        FVector ExternalLinearDragV;            // 0x000020 (0x000018)
        FVector ExternalLinearVelocity;         // 0x000038 (0x000018)
        FVector ExternalAngularVelocity;        // 0x000050 (0x000018)
    };
    // Size: 0x000010 (0x000000)
    struct FSkeletalControlReference : public FAnimNodeReference
    {
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FSplineIKCachedBoneData
    {
        FBoneReference  bone;               // 0x000000 (0x00000C)
        int32           RefSkeletonIndex;   // 0x00000C (0x000004)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FWarpingVectorValue
    {
        EWarpingVectorMode  Mode;                           // 0x000000 (0x000001)
        uint8               UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        FVector             Value;                          // 0x000008 (0x000018)
    };
}

