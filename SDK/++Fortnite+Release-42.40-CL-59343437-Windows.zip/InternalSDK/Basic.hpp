/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:32
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : Basic
 * ============================================================
 */

#pragma once

namespace UE
{
    using int8   = char;
    using uint8  = unsigned char;
    
    using int16  = short;
    using uint16 = unsigned short;
    
    using int32  = int;
    using uint32 = unsigned int;
    
    using int64  = long long;
    using uint64 = unsigned long long;
    
    
    #define SIZE_CHECK(Class, ExpectedSize) static_assert(sizeof(Class) == (ExpectedSize), "Size mismatch: " #Class)
    #define OFFSET_CHECK(Class, Member, ExpectedOffset) static_assert(offsetof(Class, Member) == (ExpectedOffset), "Offset mismatch: " #Class "::" #Member)
    
    #define MULTI_INLINE_DELEGATE(Name) TMulticastScriptDelegate<decltype(Name)>
    #define MULTI_SPARSE_DELEGATE(Name) uint8
}

