/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AIPromptUI_Functions
 * ============================================================
 */

#include "AIPromptUI.hpp"

namespace UE
{

    struct UPersonaPermissionVM___OnButtonClicked_Params
    {
        int32   ButtonIndex;    // 0x000000 (0x000004) [Default: 345740944]
        bool    ReturnValue;    // 0x000004 (0x000001) [ReturnValue] [Default: false]
    };

} // namespace UE

