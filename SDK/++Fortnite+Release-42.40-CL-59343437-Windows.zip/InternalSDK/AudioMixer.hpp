/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:10
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioMixer
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000088 (0x000058)
    class UAudioBusSubsystem : public UAudioEngineSubsystem
    {
    public:
        uint8   UnknownData_000030[0x000058];   // 0x000030 (0x000058)
    };
    // Size: 0x000128 (0x0000F8)
    class alignas(0x8) UAudioDeviceNotificationSubsystem : public UEngineSubsystem
    {
    public:
        void**                                              VTable_000030;                  // 0x000030 (0x000008) VTable [11 slots] -> 0x13087A00
        MULTI_INLINE_DELEGATE(OnAudioDefaultDeviceChanged)  DefaultCaptureDeviceChanged;    // 0x000038 (0x000010)
        uint8                                               UnknownData_000048[0x000018];   // 0x000048 (0x000018)
        MULTI_INLINE_DELEGATE(OnAudioDefaultDeviceChanged)  DefaultRenderDeviceChanged;     // 0x000060 (0x000010)
        uint8                                               UnknownData_000070[0x000018];   // 0x000070 (0x000018)
        MULTI_INLINE_DELEGATE(OnAudioDeviceChange)          DeviceAdded;                    // 0x000088 (0x000010)
        uint8                                               UnknownData_000098[0x000018];   // 0x000098 (0x000018)
        MULTI_INLINE_DELEGATE(OnAudioDeviceChange)          DeviceRemoved;                  // 0x0000B0 (0x000010)
        uint8                                               UnknownData_0000C0[0x000018];   // 0x0000C0 (0x000018)
        MULTI_INLINE_DELEGATE(OnAudioDeviceStateChanged)    DeviceStateChanged;             // 0x0000D8 (0x000010)
        uint8                                               UnknownData_0000E8[0x000018];   // 0x0000E8 (0x000018)
        MULTI_INLINE_DELEGATE(OnAudioDeviceChange)          DeviceSwitched;                 // 0x000100 (0x000010)
        uint8                                               UnknownData_000110[0x000018];   // 0x000110 (0x000018)
    };
    // Size: 0x000068 (0x000040)
    class UAudioGenerator : public UObject
    {
    public:
        uint8   UnknownData_000028[0x000040];   // 0x000028 (0x000040)
    };
    // Size: 0x000028 (0x000000)
    class UAudioMixerBlueprintLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static void                                                AddMasterSubmixEffect(UObject* WorldContextObject, USoundEffectSubmixPreset* SubmixEffectPreset); // 0x048DACD0 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                AddSourceEffectToPresetChain(UObject* WorldContextObject, USoundEffectSourcePresetChain* PresetChain, FSourceEffectChainEntry Entry); // 0x048DB09A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static int32                                               AddSubmixEffect(UObject* WorldContextObject, USoundSubmix* SoundSubmix, USoundEffectSubmixPreset* SubmixEffectPreset); // 0x048DB630 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                ClearMasterSubmixEffects(UObject* WorldContextObject); // 0x048DB9C2 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                ClearSubmixEffectChainOverride(UObject* WorldContextObject, USoundSubmix* SoundSubmix, float FadeTimeSec); // 0x048DBB28 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                ClearSubmixEffects(UObject* WorldContextObject, USoundSubmix* SoundSubmix); // 0x048DBEDE [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static FString                                             Conv_AudioOutputDeviceInfoToString(FAudioOutputDeviceInfo& Info); // 0x048DC16E [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static void                                                GetAvailableAudioOutputDevices(UObject* WorldContextObject, OnAudioOutputDevicesObtained& OnObtainDevicesEvent); // 0x048DC37C [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                                                GetCurrentAudioOutputDeviceName(UObject* WorldContextObject, OnMainAudioOutputDeviceObtained& OnObtainCurrentDeviceEvent); // 0x048DC626 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                                                GetMagnitudeForFrequencies(UObject* WorldContextObject, TArray<float>& Frequencies, TArray<float>& Magnitudes, USoundSubmix* SubmixToAnalyze); // 0x048DC8CA [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static int32                                               GetNumberOfEntriesInSourceEffectChain(UObject* WorldContextObject, USoundEffectSourcePresetChain* PresetChain); // 0x048DCE5C [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                GetPhaseForFrequencies(UObject* WorldContextObject, TArray<float>& Frequencies, TArray<float>& Phases, USoundSubmix* SubmixToAnalyze); // 0x048DD1DA [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static bool                                                IsAudioBusActive(UObject* WorldContextObject, UAudioBus* AudioBus); // 0x048DD77A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static TArray<FSoundSubmixSpectralAnalysisBandSettings>    MakeFullSpectrumSpectralAnalysisBandSettings(int32 InNumBands, float InMinimumFrequency, float InMaximumFrequency, int32 InAttackTimeMsec, int32 InReleaseTimeMsec); // 0x048DDB9C [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static TArray<FSoundSubmixSpectralAnalysisBandSettings>    MakeMusicalSpectralAnalysisBandSettings(int32 InNumSemitones, EMusicalNoteName InStartingMusicalNote, int32 InStartingOctave, int32 InAttackTimeMsec, int32 InReleaseTimeMsec); // 0x048DE0C0 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static TArray<FSoundSubmixSpectralAnalysisBandSettings>    MakePresetSpectralAnalysisBandSettings(EAudioSpectrumBandPresetType InBandPresetType, int32 InNumBands, int32 InAttackTimeMsec, int32 InReleaseTimeMsec); // 0x048DE5E0 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static void                                                PauseRecordingOutput(UObject* WorldContextObject, USoundSubmix* SubmixToPause); // 0x048DEA5E [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                PrimeSoundCueForPlayback(USoundCue* SoundCue); // 0x048DEDEC [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                PrimeSoundForPlayback(USoundWave* SoundWave, OnSoundLoadComplete OnLoadCompletion); // 0x048DEF6C [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                RegisterAudioBusToSubmix(UObject* WorldContextObject, USoundSubmix* SoundSubmix, UAudioBus* AudioBus); // 0x048DF3AA [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                RemoveMasterSubmixEffect(UObject* WorldContextObject, USoundEffectSubmixPreset* SubmixEffectPreset); // 0x048DFC24 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                RemoveSourceEffectFromPresetChain(UObject* WorldContextObject, USoundEffectSourcePresetChain* PresetChain, int32 EntryIndex); // 0x048DFF7E [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                RemoveSubmixEffect(UObject* WorldContextObject, USoundSubmix* SoundSubmix, USoundEffectSubmixPreset* SubmixEffectPreset); // 0x048E0466 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                RemoveSubmixEffectAtIndex(UObject* WorldContextObject, USoundSubmix* SoundSubmix, int32 SubmixChainIndex); // 0x048E081A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                RemoveSubmixEffectPreset(UObject* WorldContextObject, USoundSubmix* SoundSubmix, USoundEffectSubmixPreset* SubmixEffectPreset); // 0x048E0466 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                RemoveSubmixEffectPresetAtIndex(UObject* WorldContextObject, USoundSubmix* SoundSubmix, int32 SubmixChainIndex); // 0x048E081A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                ReplaceSoundEffectSubmix(UObject* WorldContextObject, USoundSubmix* InSoundSubmix, int32 SubmixChainIndex, USoundEffectSubmixPreset* SubmixEffectPreset); // 0x048E0BC2 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                ReplaceSubmixEffect(UObject* WorldContextObject, USoundSubmix* InSoundSubmix, int32 SubmixChainIndex, USoundEffectSubmixPreset* SubmixEffectPreset); // 0x048E0BC2 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                ResumeRecordingOutput(UObject* WorldContextObject, USoundSubmix* SubmixToPause); // 0x048E0F9E [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                SetBypassSourceEffectChainEntry(UObject* WorldContextObject, USoundEffectSourcePresetChain* PresetChain, int32 EntryIndex, bool bBypassed); // 0x048E132C [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                SetSubmixEffectChainOverride(UObject* WorldContextObject, USoundSubmix* SoundSubmix, TArray<USoundEffectSubmixPreset*> SubmixEffectPresetChain, float FadeTimeSec); // 0x048E194E [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                StartAnalyzingOutput(UObject* WorldContextObject, USoundSubmix* SubmixToAnalyze, EFFTSize FFTSize, EFFTPeakInterpolationMethod InterpolationMethod, EFFTWindowType WindowType, float HopSize, EAudioSpectrumType SpectrumType); // 0x048E1DB6 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                StartAudioBus(UObject* WorldContextObject, UAudioBus* AudioBus); // 0x048E2526 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                StartRecordingOutput(UObject* WorldContextObject, float ExpectedDuration, USoundSubmix* SubmixToRecord); // 0x048E2A78 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                StopAnalyzingOutput(UObject* WorldContextObject, USoundSubmix* SubmixToStopAnalyzing); // 0x048E2F3A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                StopAudioBus(UObject* WorldContextObject, UAudioBus* AudioBus); // 0x048E326A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static USoundWave*                                         StopRecordingOutput(UObject* WorldContextObject, EAudioRecordingExportType ExportType, FString Name, FString Path, USoundSubmix* SubmixToRecord, USoundWave* ExistingSoundWaveToOverwrite); // 0x048E3664 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                SwapAudioOutputDevice(UObject* WorldContextObject, FString NewDeviceId, OnCompletedDeviceSwap& OnCompletedDeviceSwap); // 0x048E407C [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static float                                               TrimAudioCache(float InMegabytesToFree); // 0x048E444A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                                UnregisterAudioBusFromSubmix(UObject* WorldContextObject, USoundSubmix* SoundSubmix, UAudioBus* AudioBus); // 0x048E4660 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000208 (0x0001E0)
    class alignas(0x8) UQuartzClockHandle : public UObject
    {
    public:
        void**  VTable_000028;                  // 0x000028 (0x000008) VTable [27 slots] -> 0x1308CDE0
        void**  VTable_000030;                  // 0x000030 (0x000008) VTable [21 slots] -> 0x1308CE10
        void**  VTable_000038;                  // 0x000038 (0x000008) VTable [19 slots] -> 0x1308CE20
        void**  VTable_000040;                  // 0x000040 (0x000008) VTable [17 slots] -> 0x1308CE30
        uint8   UnknownData_000048[0x0001C0];   // 0x000048 (0x0001C0)
    
    public: // Functions
        float                       GetBeatProgressPercent(EQuartzCommandQuantization QuantizationBoundary, float PhaseOffset, float MSOffset); // 0x0490343C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        float                       GetBeatsPerMinute(UObject* WorldContextObject); // 0x049037D2 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FQuartzTransportTimeStamp   GetCurrentTimestamp(UObject* WorldContextObject); // 0x04903966 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        float                       GetDurationOfQuantizationTypeInSeconds(UObject* WorldContextObject, EQuartzCommandQuantization& QuantizationType, float Multiplier); // 0x04903AEA [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        float                       GetEstimatedRunTime(UObject* WorldContextObject); // 0x04903E9A [Final | RequiredAPI | Native | Public | BlueprintCallable]
        float                       GetMillisecondsPerTick(UObject* WorldContextObject); // 0x04904014 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float                       GetSecondsPerTick(UObject* WorldContextObject); // 0x049041A8 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float                       GetThirtySecondNotesPerMinute(UObject* WorldContextObject); // 0x0490433C [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float                       GetTicksPerSecond(UObject* WorldContextObject); // 0x049044D0 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                        IsClockRunning(UObject* WorldContextObject); // 0x04904642 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        NotifyOnQuantizationBoundary(UObject* WorldContextObject, FQuartzQuantizationBoundary InQuantizationBoundary, OnQuartzCommandEventBP& InDelegate, float InMsOffset); // 0x049047BA [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        PauseClock(UObject* WorldContextObject, UQuartzClockHandle*& ClockHandle); // 0x04904CC4 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        ResetTransport(UObject* WorldContextObject, OnQuartzCommandEventBP& InDelegate); // 0x04904FA2 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        ResetTransportQuantized(UObject* WorldContextObject, FQuartzQuantizationBoundary InQuantizationBoundary, OnQuartzCommandEventBP& InDelegate, UQuartzClockHandle*& ClockHandle); // 0x0490524A [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        ResumeClock(UObject* WorldContextObject, UQuartzClockHandle*& ClockHandle); // 0x04905774 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        SetBeatsPerMinute(UObject* WorldContextObject, FQuartzQuantizationBoundary& QuantizationBoundary, OnQuartzCommandEventBP& Delegate, UQuartzClockHandle*& ClockHandle, float BeatsPerMinute); // 0x04905A52 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        SetMillisecondsPerTick(UObject* WorldContextObject, FQuartzQuantizationBoundary& QuantizationBoundary, OnQuartzCommandEventBP& Delegate, UQuartzClockHandle*& ClockHandle, float MillisecondsPerTick); // 0x04906300 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        SetSecondsPerTick(UObject* WorldContextObject, FQuartzQuantizationBoundary& QuantizationBoundary, OnQuartzCommandEventBP& Delegate, UQuartzClockHandle*& ClockHandle, float SecondsPerTick); // 0x04906B22 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        SetThirtySecondNotesPerMinute(UObject* WorldContextObject, FQuartzQuantizationBoundary& QuantizationBoundary, OnQuartzCommandEventBP& Delegate, UQuartzClockHandle*& ClockHandle, float ThirtySecondsNotesPerMinute); // 0x049073DC [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        SetTicksPerSecond(UObject* WorldContextObject, FQuartzQuantizationBoundary& QuantizationBoundary, OnQuartzCommandEventBP& Delegate, UQuartzClockHandle*& ClockHandle, float TicksPerSecond); // 0x04907BFA [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        StartClock(UObject* WorldContextObject, UQuartzClockHandle*& ClockHandle); // 0x04905774 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        StartOtherClock(UObject* WorldContextObject, FName OtherClockName, FQuartzQuantizationBoundary InQuantizationBoundary, OnQuartzCommandEventBP& InDelegate); // 0x04908454 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        StopClock(UObject* WorldContextObject, bool CancelPendingEvents, UQuartzClockHandle*& ClockHandle); // 0x04908E20 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        SubscribeToAllQuantizationEvents(UObject* WorldContextObject, OnQuartzMetronomeEventBP& OnQuantizationEvent, UQuartzClockHandle*& ClockHandle); // 0x0490920A [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        SubscribeToQuantizationEvent(UObject* WorldContextObject, EQuartzCommandQuantization InQuantizationBoundary, OnQuartzMetronomeEventBP& OnQuantizationEvent, UQuartzClockHandle*& ClockHandle); // 0x0490960C [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        UnsubscribeFromAllTimeDivisions(UObject* WorldContextObject, UQuartzClockHandle*& ClockHandle); // 0x04909CD4 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        UnsubscribeFromTimeDivision(UObject* WorldContextObject, EQuartzCommandQuantization InQuantizationBoundary, UQuartzClockHandle*& ClockHandle); // 0x04909F7E [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000070 (0x000028)
    class UQuartzSubsystem : public UTickableWorldSubsystem
    {
    public:
        uint8   UnknownData_000048[0x000028];   // 0x000048 (0x000028)
    
    public: // Functions
        UQuartzClockHandle*         CreateNewClock(UObject* WorldContextObject, FName ClockName, FQuartzClockSettings InSettings, bool bOverrideSettingsIfClockExists, bool bUseAudioEngineClockManager); // 0x0490AB88 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        DeleteClockByHandle(UObject* WorldContextObject, UQuartzClockHandle*& InClockHandle); // 0x0490B3A8 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        DeleteClockByName(UObject* WorldContextObject, FName ClockName); // 0x0490B66C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        bool                        DoesClockExist(UObject* WorldContextObject, FName ClockName); // 0x0490B8EC [Final | RequiredAPI | Native | Public | BlueprintCallable]
        float                       GetAudioRenderThreadToGameThreadAverageLatency(); // 0x0D1A36DE [Final | RequiredAPI | Native | Public | BlueprintCallable]
        float                       GetAudioRenderThreadToGameThreadMaxLatency(); // 0x0D1A371E [Final | RequiredAPI | Native | Public | BlueprintCallable]
        float                       GetAudioRenderThreadToGameThreadMinLatency(); // 0x0D1A374A [Final | RequiredAPI | Native | Public | BlueprintCallable]
        FQuartzTransportTimeStamp   GetCurrentClockTimestamp(UObject* WorldContextObject, FName& InClockName); // 0x0490BB6C [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        float                       GetDurationOfQuantizationTypeInSeconds(UObject* WorldContextObject, FName ClockName, EQuartzCommandQuantization& QuantizationType, float Multiplier); // 0x0490BE0C [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        float                       GetEstimatedClockRunTime(UObject* WorldContextObject, FName& InClockName); // 0x0490C248 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        float                       GetGameThreadToAudioRenderThreadAverageLatency(UObject* WorldContextObject); // 0x0490C4DE [Final | RequiredAPI | Native | Public | BlueprintCallable]
        float                       GetGameThreadToAudioRenderThreadMaxLatency(UObject* WorldContextObject); // 0x0490C6B0 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        float                       GetGameThreadToAudioRenderThreadMinLatency(UObject* WorldContextObject); // 0x0490C6B0 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        UQuartzClockHandle*         GetHandleForClock(UObject* WorldContextObject, FName ClockName); // 0x0490C882 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        float                       GetRoundTripAverageLatency(UObject* WorldContextObject); // 0x0490CB0A [Final | RequiredAPI | Native | Public | BlueprintCallable]
        float                       GetRoundTripMaxLatency(UObject* WorldContextObject); // 0x0490CC82 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        float                       GetRoundTripMinLatency(UObject* WorldContextObject); // 0x0490CDFA [Final | RequiredAPI | Native | Public | BlueprintCallable]
        bool                        IsClockRunning(UObject* WorldContextObject, FName ClockName); // 0x0490CF72 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        bool                        IsQuartzEnabled(); // 0x0CB033BC [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        SetQuartzSubsystemTickableWhenPaused(bool bInTickableWhenPaused); // 0x0490D1F2 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x0002D8 (0x000038)
    class alignas(0x8) UScrubbedSound : public USoundWave
    {
    public:
        uint8       UnknownData_0002A0[0x000030];   // 0x0002A0 (0x000030)
        USoundWave* SoundWaveToScrub;               // 0x0002D0 (0x000008) [Default: nullptr]
    
    public: // Functions
        float   GetPlayheadTime(); // 0x0D19DA48 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    SetGrainDurationRange(FVector2D& InGrainDurationRangeSeconds); // 0x04901CDC [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        void    SetIsScrubbing(bool bInIsScrubbing); // 0x04901E54 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetIsScrubbingWhileStationary(bool bInScrubWhileStationary); // 0x04901FD8 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetPlayheadTime(float InPlayheadTimeSeconds); // 0x0490215C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetSoundWave(USoundWave* InSoundWave); // 0x049022CA [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000150 (0x0000E8)
    class alignas(0x8) USubmixEffectDynamicsProcessorPreset : public USoundEffectSubmixPreset
    {
    public:
        uint8                                   UnknownData_000068[0x000088];   // 0x000068 (0x000088)
        FSubmixEffectDynamicsProcessorSettings  Settings;                       // 0x0000F0 (0x000060)
    
    public: // Functions
        void    ResetKey(); // 0x0D19CBE4 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetAudioBus(UAudioBus* AudioBus); // 0x048FFD68 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetExternalSubmix(USoundSubmix* Submix); // 0x048FFED6 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetSettings(FSubmixEffectDynamicsProcessorSettings& Settings); // 0x04900044 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000110 (0x0000A8)
    class alignas(0x8) USubmixEffectReverbPreset : public USoundEffectSubmixPreset
    {
    public:
        uint8                       UnknownData_000068[0x000068];   // 0x000068 (0x000068)
        FSubmixEffectReverbSettings Settings;                       // 0x0000D0 (0x000040)
    
    public: // Functions
        void    SetSettings(FSubmixEffectReverbSettings& InSettings); // 0x04901152 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void    SetSettingsWithReverbEffect(UReverbEffect* InReverbEffect, float WetLevel, float DryLevel); // 0x04901356 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x0000B0 (0x000048)
    class alignas(0x8) USubmixEffectSubmixEQPreset : public USoundEffectSubmixPreset
    {
    public:
        uint8                           UnknownData_000068[0x000038];   // 0x000068 (0x000038)
        FSubmixEffectSubmixEQSettings   Settings;                       // 0x0000A0 (0x000010)
    
    public: // Functions
        void    SetSettings(FSubmixEffectSubmixEQSettings& InSettings); // 0x04900762 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000620 (0x0003E0)
    class alignas(0x8) USynthComponent : public USceneComponent
    {
    public:
        uint8                                       bAutoDestroy : 1;               // 0x000240 (0x000001) : 0x0 [Default: true]
        uint8                                       bStopWhenOwnerDestroyed : 1;    // 0x000240 (0x000001) : 0x0 [Default: true]
        uint8                                       bAllowSpatialization : 1;       // 0x000240 (0x000001) : 0x0 [Default: true]
        uint8                                       bOverrideAttenuation : 1;       // 0x000240 (0x000001) : 0x0 [Default: true]
        uint8                                       UnknownBit_000240_1 : 1;        // 0x000240 (0x000001) : 0x1
        uint8                                       UnknownBit_000240_2 : 1;        // 0x000240 (0x000001) : 0x2
        uint8                                       UnknownBit_000240_3 : 1;        // 0x000240 (0x000001) : 0x3
        uint8                                       UnknownBit_000240_4 : 1;        // 0x000240 (0x000001) : 0x4
        uint8                                       UnknownBit_000240_5 : 1;        // 0x000240 (0x000001) : 0x5
        uint8                                       UnknownBit_000240_6 : 1;        // 0x000240 (0x000001) : 0x6
        uint8                                       UnknownBit_000240_7 : 1;        // 0x000240 (0x000001) : 0x7
        uint8                                       UnknownData_000241[0x000003];   // 0x000241 (0x000003)
        uint8                                       bEnableBusSends : 1;            // 0x000244 (0x000001) : 0x0 [Default: true]
        uint8                                       bEnableBaseSubmix : 1;          // 0x000244 (0x000001) : 0x0 [Default: true]
        uint8                                       bEnableSubmixSends : 1;         // 0x000244 (0x000001) : 0x0 [Default: true]
        uint8                                       UnknownBit_000244_1 : 1;        // 0x000244 (0x000001) : 0x1
        uint8                                       UnknownBit_000244_2 : 1;        // 0x000244 (0x000001) : 0x2
        uint8                                       UnknownBit_000244_3 : 1;        // 0x000244 (0x000001) : 0x3
        uint8                                       UnknownBit_000244_4 : 1;        // 0x000244 (0x000001) : 0x4
        uint8                                       UnknownBit_000244_5 : 1;        // 0x000244 (0x000001) : 0x5
        uint8                                       UnknownBit_000244_6 : 1;        // 0x000244 (0x000001) : 0x6
        uint8                                       UnknownBit_000244_7 : 1;        // 0x000244 (0x000001) : 0x7
        uint8                                       UnknownData_000245[0x000003];   // 0x000245 (0x000003)
        USoundAttenuation*                          AttenuationSettings;            // 0x000248 (0x000008) [Default: nullptr]
        FSoundAttenuationSettings                   AttenuationOverrides;           // 0x000250 (0x000290)
        USoundConcurrency*                          ConcurrencySettings;            // 0x0004E0 (0x000008) [Default: nullptr]
        TSet<USoundConcurrency*>                    ConcurrencySet;                 // 0x0004E8 (0x000010)
        FSoundModulationDefaultRoutingSettings      ModulationRouting;              // 0x0004F8 (0x000068)
        USoundClass*                                SoundClass;                     // 0x000560 (0x000008) [Default: nullptr]
        USoundEffectSourcePresetChain*              SourceEffectChain;              // 0x000568 (0x000008) [Default: nullptr]
        USoundSubmixBase*                           SoundSubmix;                    // 0x000570 (0x000008) [Default: nullptr]
        TArray<FSoundSubmixSendInfo>                SoundSubmixSends;               // 0x000578 (0x000010)
        TArray<FSoundSourceBusSendInfo>             BusSends;                       // 0x000588 (0x000010)
        TArray<FSoundSourceBusSendInfo>             PreEffectBusSends;              // 0x000598 (0x000010)
        uint8                                       bIsUISound : 1;                 // 0x0005A8 (0x000001) : 0x0 [Default: true]
        uint8                                       bIsPreviewSound : 1;            // 0x0005A8 (0x000001) : 0x0 [Default: true]
        uint8                                       UnknownBit_0005A8_1 : 1;        // 0x0005A8 (0x000001) : 0x1
        uint8                                       UnknownBit_0005A8_2 : 1;        // 0x0005A8 (0x000001) : 0x2
        uint8                                       UnknownBit_0005A8_3 : 1;        // 0x0005A8 (0x000001) : 0x3
        uint8                                       UnknownBit_0005A8_4 : 1;        // 0x0005A8 (0x000001) : 0x4
        uint8                                       UnknownBit_0005A8_5 : 1;        // 0x0005A8 (0x000001) : 0x5
        uint8                                       UnknownBit_0005A8_6 : 1;        // 0x0005A8 (0x000001) : 0x6
        uint8                                       UnknownBit_0005A8_7 : 1;        // 0x0005A8 (0x000001) : 0x7
        uint8                                       UnknownData_0005A9[0x000003];   // 0x0005A9 (0x000003)
        int32                                       EnvelopeFollowerAttackTime;     // 0x0005AC (0x000004) [Default: 0]
        int32                                       EnvelopeFollowerReleaseTime;    // 0x0005B0 (0x000004) [Default: 0]
        uint8                                       UnknownData_0005B4[0x000004];   // 0x0005B4 (0x000004)
        MULTI_INLINE_DELEGATE(OnSynthEnvelopeValue) OnAudioEnvelopeValue;           // 0x0005B8 (0x000010)
        uint8                                       UnknownData_0005C8[0x000020];   // 0x0005C8 (0x000020)
        USynthSound*                                Synth;                          // 0x0005E8 (0x000008) [Default: nullptr]
        UAudioComponent*                            AudioComponent;                 // 0x0005F0 (0x000008) [Default: nullptr]
        uint8                                       UnknownData_0005F8[0x000028];   // 0x0005F8 (0x000028)
    
    public: // Functions
        void                        AdjustVolume(float AdjustVolumeDuration, float AdjustVolumeLevel, EAudioFaderCurve FadeCurve); // 0x048FD89A [Final | RequiredAPI | Native | Public | BlueprintCallable | Const]
        void                        FadeIn(float FadeInDuration, float FadeVolumeLevel, float StartTime, EAudioFaderCurve FadeCurve); // 0x048FDC40 [Final | RequiredAPI | Native | Public | BlueprintCallable | Const]
        void                        FadeOut(float FadeOutDuration, float FadeVolumeLevel, EAudioFaderCurve FadeCurve); // 0x048FE0FC [Final | RequiredAPI | Native | Public | BlueprintCallable | Const]
        TSet<USoundModulatorBase*>  GetModulators(EModulationDestination Destination); // 0x048FE4A0 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure]
        bool                        IsPlaying(); // 0x0D19C766 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                        SetAudioBusSendPostEffect(UAudioBus* AudioBus, float AudioBusSendLevel); // 0x048FE67A [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        SetAudioBusSendPreEffect(UAudioBus* AudioBus, float AudioBusSendLevel); // 0x048FE910 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        SetLowPassFilterEnabled(bool InLowPassFilterEnabled); // 0x048FEBA6 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        SetLowPassFilterFrequency(float InLowPassFilterFrequency); // 0x0410A44E [RequiredAPI | Native | Public | BlueprintCallable]
        void                        SetModulationRouting(TSet<USoundModulatorBase*>& Modulators, EModulationDestination Destination, EModulationRouting RoutingMethod); // 0x048FED26 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        SetOutputToBusOnly(bool bInOutputToBusOnly); // 0x048FF0F4 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        SetSourceBusSendPostEffect(USoundSourceBus* SoundSourceBus, float SourceBusSendLevel); // 0x048FF274 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        SetSourceBusSendPreEffect(USoundSourceBus* SoundSourceBus, float SourceBusSendLevel); // 0x048FF50C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        SetSubmixSend(USoundSubmixBase* Submix, float SendLevel); // 0x048FF7A4 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        SetVolumeMultiplier(float VolumeMultiplier); // 0x048FFA36 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        Start(); // 0x0198D02C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        Stop(); // 0x0D19C7F2 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000310 (0x000020)
    class alignas(0x8) USynthSound : public USoundWaveProcedural
    {
    public:
        TWeakObjectPtr<USynthComponent> OwningSynthComponent;           // 0x0002F0 (0x000008) [Default: nullptr]
        uint8                           UnknownData_0002F8[0x000018];   // 0x0002F8 (0x000018)
    };
    // Size: 0x000048 (0x000048)
    struct alignas(0x8) FAudioOutputDeviceInfo
    {
        FString                         Name;                           // 0x000000 (0x000010)
        FString                         DeviceID;                       // 0x000010 (0x000010)
        int32                           NumChannels;                    // 0x000020 (0x000004)
        int32                           SampleRate;                     // 0x000024 (0x000004)
        EAudioMixerStreamDataFormatType Format;                         // 0x000028 (0x000001)
        uint8                           UnknownData_000029[0x000007];   // 0x000029 (0x000007)
        TArray<EAudioMixerChannelType>  OutputChannelArray;             // 0x000030 (0x000010)
        uint8                           bIsSystemDefault : 1;           // 0x000040 (0x000001) : 0x0
        uint8                           bIsCurrentDevice : 1;           // 0x000040 (0x000001) : 0x0
        uint8                           UnknownBit_000040_1 : 1;        // 0x000040 (0x000001) : 0x1
        uint8                           UnknownBit_000040_2 : 1;        // 0x000040 (0x000001) : 0x2
        uint8                           UnknownBit_000040_3 : 1;        // 0x000040 (0x000001) : 0x3
        uint8                           UnknownBit_000040_4 : 1;        // 0x000040 (0x000001) : 0x4
        uint8                           UnknownBit_000040_5 : 1;        // 0x000040 (0x000001) : 0x5
        uint8                           UnknownBit_000040_6 : 1;        // 0x000040 (0x000001) : 0x6
        uint8                           UnknownBit_000040_7 : 1;        // 0x000040 (0x000001) : 0x7
        uint8                           UnknownData_000041[0x000007];   // 0x000041 (0x000007)
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FSubmixEffectDynamicProcessorFilterSettings
    {
        uint8   bEnabled : 1;                   // 0x000000 (0x000001) : 0x0 [Default: true]
        uint8   UnknownBit_000000_1 : 1;        // 0x000000 (0x000001) : 0x1
        uint8   UnknownBit_000000_2 : 1;        // 0x000000 (0x000001) : 0x2
        uint8   UnknownBit_000000_3 : 1;        // 0x000000 (0x000001) : 0x3
        uint8   UnknownBit_000000_4 : 1;        // 0x000000 (0x000001) : 0x4
        uint8   UnknownBit_000000_5 : 1;        // 0x000000 (0x000001) : 0x5
        uint8   UnknownBit_000000_6 : 1;        // 0x000000 (0x000001) : 0x6
        uint8   UnknownBit_000000_7 : 1;        // 0x000000 (0x000001) : 0x7
        uint8   UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        float   Cutoff;                         // 0x000004 (0x000004) [Default: 0f]
        float   GainDb;                         // 0x000008 (0x000004) [Default: 0f]
    };
    // Size: 0x000060 (0x000060)
    struct alignas(0x8) FSubmixEffectDynamicsProcessorSettings
    {
        ESubmixEffectDynamicsProcessorType          DynamicsProcessorType;          // 0x000000 (0x000001) [Default: ESubmixEffectDynamicsProcessorType(160)]
        ESubmixEffectDynamicsPeakMode               PeakMode;                       // 0x000001 (0x000001) [Default: ESubmixEffectDynamicsPeakMode(195)]
        ESubmixEffectDynamicsChannelLinkMode        LinkMode;                       // 0x000002 (0x000001) [Default: ESubmixEffectDynamicsChannelLinkMode(251)]
        uint8                                       UnknownByte_000003;             // 0x000003 (0x000001)
        float                                       InputGainDb;                    // 0x000004 (0x000004) [Default: 0f]
        float                                       ThresholdDb;                    // 0x000008 (0x000004) [Default: 3.99656e-26f]
        float                                       Ratio;                          // 0x00000C (0x000004) [Default: 0f]
        float                                       KneeBandwidthDb;                // 0x000010 (0x000004) [Default: 2.6515e-25f]
        float                                       LookAheadMsec;                  // 0x000014 (0x000004) [Default: 0f]
        float                                       AttackTimeMsec;                 // 0x000018 (0x000004) [Default: 4.0586e-25f]
        float                                       ReleaseTimeMsec;                // 0x00001C (0x000004) [Default: 0f]
        ESubmixEffectDynamicsKeySource              KeySource;                      // 0x000020 (0x000001) [Default: ESubmixEffectDynamicsKeySource(185)]
        uint8                                       UnknownData_000021[0x000007];   // 0x000021 (0x000007)
        UAudioBus*                                  ExternalAudioBus;               // 0x000028 (0x000008) [Default: nullptr]
        USoundSubmix*                               ExternalSubmix;                 // 0x000030 (0x000008) [Default: 0xCFDB7663]
        uint8                                       bChannelLinked : 1;             // 0x000038 (0x000001) : 0x0 [Default: false]
        uint8                                       bAnalogMode : 1;                // 0x000038 (0x000001) : 0x0 [Default: false]
        uint8                                       bBypass : 1;                    // 0x000038 (0x000001) : 0x0 [Default: false]
        uint8                                       bKeyAudition : 1;               // 0x000038 (0x000001) : 0x0 [Default: false]
        uint8                                       UnknownBit_000038_1 : 1;        // 0x000038 (0x000001) : 0x1
        uint8                                       UnknownBit_000038_2 : 1;        // 0x000038 (0x000001) : 0x2
        uint8                                       UnknownBit_000038_3 : 1;        // 0x000038 (0x000001) : 0x3
        uint8                                       UnknownBit_000038_4 : 1;        // 0x000038 (0x000001) : 0x4
        uint8                                       UnknownBit_000038_5 : 1;        // 0x000038 (0x000001) : 0x5
        uint8                                       UnknownBit_000038_6 : 1;        // 0x000038 (0x000001) : 0x6
        uint8                                       UnknownBit_000038_7 : 1;        // 0x000038 (0x000001) : 0x7
        uint8                                       UnknownData_000039[0x000003];   // 0x000039 (0x000003)
        float                                       KeyGainDb;                      // 0x00003C (0x000004) [Default: 0f]
        float                                       OutputGainDb;                   // 0x000040 (0x000004) [Default: 0f]
        FSubmixEffectDynamicProcessorFilterSettings KeyHighshelf;                   // 0x000044 (0x00000C)
        FSubmixEffectDynamicProcessorFilterSettings KeyLowshelf;                    // 0x000050 (0x00000C)
        uint8                                       UnknownData_00005C[0x000004];   // 0x00005C (0x000004)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x4) FSubmixEffectEQBand
    {
        float   Frequency;                      // 0x000000 (0x000004) [Default: 4.06752e-25f]
        float   Bandwidth;                      // 0x000004 (0x000004) [Default: 0f]
        float   GainDb;                         // 0x000008 (0x000004) [Default: 3.99656e-26f]
        uint8   bEnabled : 1;                   // 0x00000C (0x000001) : 0x0 [Default: false]
        uint8   UnknownBit_00000C_1 : 1;        // 0x00000C (0x000001) : 0x1
        uint8   UnknownBit_00000C_2 : 1;        // 0x00000C (0x000001) : 0x2
        uint8   UnknownBit_00000C_3 : 1;        // 0x00000C (0x000001) : 0x3
        uint8   UnknownBit_00000C_4 : 1;        // 0x00000C (0x000001) : 0x4
        uint8   UnknownBit_00000C_5 : 1;        // 0x00000C (0x000001) : 0x5
        uint8   UnknownBit_00000C_6 : 1;        // 0x00000C (0x000001) : 0x6
        uint8   UnknownBit_00000C_7 : 1;        // 0x00000C (0x000001) : 0x7
        uint8   UnknownData_00000D[0x000003];   // 0x00000D (0x000003)
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x4) FSubmixEffectReverbSettings
    {
        bool    bBypassEarlyReflections;        // 0x000000 (0x000001) [Default: true]
        uint8   UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        float   ReflectionsDelay;               // 0x000004 (0x000004) [Default: 0f]
        float   GainHF;                         // 0x000008 (0x000004) [Default: 3.99656e-26f]
        float   ReflectionsGain;                // 0x00000C (0x000004) [Default: 0f]
        bool    bBypassLateReflections;         // 0x000010 (0x000001) [Default: true]
        uint8   UnknownData_000011[0x000003];   // 0x000011 (0x000003)
        float   LateDelay;                      // 0x000014 (0x000004) [Default: 0f]
        float   DecayTime;                      // 0x000018 (0x000004) [Default: 4.05866e-25f]
        float   Density;                        // 0x00001C (0x000004) [Default: 0f]
        float   Diffusion;                      // 0x000020 (0x000004) [Default: -2.66372e+31f]
        float   AirAbsorptionGainHF;            // 0x000024 (0x000004) [Default: 0f]
        float   DecayHFRatio;                   // 0x000028 (0x000004) [Default: 0f]
        float   LateGain;                       // 0x00002C (0x000004) [Default: 0f]
        float   Gain;                           // 0x000030 (0x000004) [Default: -7.36394e+09f]
        float   WetLevel;                       // 0x000034 (0x000004) [Default: 0f]
        float   DryLevel;                       // 0x000038 (0x000004) [Default: 0f]
        bool    bBypass;                        // 0x00003C (0x000001) [Default: false]
        uint8   UnknownData_00003D[0x000003];   // 0x00003D (0x000003)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FSubmixEffectSubmixEQSettings
    {
        TArray<FSubmixEffectEQBand> EqBands;    // 0x000000 (0x000010)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FSwapAudioOutputResult
    {
        FString                             CurrentDeviceId;                // 0x000000 (0x000010)
        FString                             RequestedDeviceId;              // 0x000010 (0x000010)
        ESwapAudioOutputDeviceResultState   Result;                         // 0x000020 (0x000001)
        uint8                               UnknownData_000021[0x000007];   // 0x000021 (0x000007)
    };
}

