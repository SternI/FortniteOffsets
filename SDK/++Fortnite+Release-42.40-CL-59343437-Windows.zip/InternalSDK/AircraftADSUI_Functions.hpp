/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AircraftADSUI_Functions
 * ============================================================
 */

#include "AircraftADSUI.hpp"

namespace UE
{

    struct UAircraftADSPOIVM___IsGolden_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAircraftADSPOIVM___IsPOISelected_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAircraftADSPOIVM___POIName_Params
    {
        FText   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAircraftADSPOIVM___SetPOIVolume_Params
    {
        AFortPoiVolume* InPOIVolume;    // 0x000000 (0x000008) [Default: 0x14890310]
    };

    struct UFortPlayerControllerComponent_AircraftADSUI___HandleEnterAircraft_Params
    {
        AController*    Controller; // 0x000000 (0x000008) [Default: 0x14890630]
    };

    struct UFortPlayerControllerComponent_AircraftADSUI___HandleExitAircraft_Params
    {
        AController*    Controller; // 0x000000 (0x000008) [Default: 0x14890630]
    };

    struct UFortPlayerControllerComponent_AircraftADSUI___IsPOIBubbleEnabled_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UFortPlayerControllerComponent_AircraftADSUI___OnPOIVolumeSelectionChanged_Params
    {
        AFortPoiVolume* POIVolume;  // 0x000000 (0x000008) [Default: 0x14890630]
    };

} // namespace UE

