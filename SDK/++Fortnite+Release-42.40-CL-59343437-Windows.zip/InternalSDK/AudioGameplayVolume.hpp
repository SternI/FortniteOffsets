/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioGameplayVolume
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0002D8 (0x000030)
    class alignas(0x8) AAudioGameplayVolume : public AVolume
    {
    public:
        UAudioGameplayVolumeComponent*                  AGVComponent;                   // 0x0002A8 (0x000008) [Default: 0x7FE838FAAD80]
        bool                                            bEnabled;                       // 0x0002B0 (0x000001) [Default: true]
        uint8                                           UnknownData_0002B1[0x000007];   // 0x0002B1 (0x000007)
        MULTI_INLINE_DELEGATE(AudioGameplayVolumeEvent) OnListenerEnterEvent;           // 0x0002B8 (0x000010)
        MULTI_INLINE_DELEGATE(AudioGameplayVolumeEvent) OnListenerExitEvent;            // 0x0002C8 (0x000010)
    
    public: // Functions
        void    OnListenerEnter(); // 0x00DABAFC [RequiredAPI | Native | Event | Public | BlueprintEvent]
        void    OnListenerExit(); // 0x00DCE4E0 [RequiredAPI | Native | Event | Public | BlueprintEvent]
        void    OnRep_bEnabled(); // 0x0E45CBBA [RequiredAPI | Native | Protected]
        void    SetEnabled(bool bEnable); // 0x0567A054 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000050 (0x000008)
    class alignas(0x8) UAGVConditionProxy : public UAudioGameplayVolumeProxy
    {
    public:
        UObject*    ObjectPtr;  // 0x000048 (0x000008) [Default: nullptr]
    };
    // Size: 0x000058 (0x000010)
    class alignas(0x8) UAGVPrimitiveComponentProxy : public UAudioGameplayVolumeProxy
    {
    public:
        TArray<UPrimitiveComponent*>    Primitives; // 0x000048 (0x000010)
    };
    // Size: 0x0000E0 (0x000010)
    class alignas(0x4) UAttenuationVolumeComponent : public UAudioGameplayVolumeMutator
    {
    public:
        float   ExteriorVolume; // 0x0000D0 (0x000004) [Default: 1f]
        float   ExteriorTime;   // 0x0000D4 (0x000004) [Default: 0.5f]
        float   InteriorVolume; // 0x0000D8 (0x000004) [Default: 1f]
        float   InteriorTime;   // 0x0000DC (0x000004) [Default: 0.5f]
    
    public: // Functions
        void    SetExteriorVolume(float Volume, float InterpolateTime); // 0x05679B28 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetInteriorVolume(float Volume, float InterpolateTime); // 0x05679DBE [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x0000F0 (0x000028)
    class alignas(0x8) UAudioGameplayVolumeComponent : public UAudioGameplayComponent
    {
    public:
        MULTI_INLINE_DELEGATE(OnAudioGameplayVolumeProxyStateChange)    OnProxyEnter;   // 0x0000C8 (0x000010)
        MULTI_INLINE_DELEGATE(OnAudioGameplayVolumeProxyStateChange)    OnProxyExit;    // 0x0000D8 (0x000010)
        UAudioGameplayVolumeProxy*                                      Proxy;          // 0x0000E8 (0x000008) [Default: nullptr]
    };
    // Size: 0x0000D0 (0x000008)
    class alignas(0x8) UAudioGameplayVolumeComponentBase : public UAudioGameplayComponent
    {
    public:
        void**  VTable_0000C8;  // 0x0000C8 (0x000008) VTable [4 slots] -> 0x134D91E0
    };
    // Size: 0x0000D0 (0x000008)
    class alignas(0x4) UAudioGameplayVolumeMutator : public UAudioGameplayComponent
    {
    public:
        int32   Priority;                       // 0x0000C8 (0x000004) [Default: 0]
        uint8   UnknownData_0000CC[0x000004];   // 0x0000CC (0x000004)
    
    public: // Functions
        void    SetPriority(int32 InPriority); // 0x0567A1C4 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000048 (0x000020)
    class UAudioGameplayVolumeProxy : public UObject
    {
    public:
        uint8   UnknownData_000028[0x000020];   // 0x000028 (0x000020)
    };
    // Size: 0x0000D0 (0x0000A0)
    class alignas(0x8) UAudioGameplayVolumeSubsystem : public UAudioEngineSubsystem
    {
    public:
        void**                                          VTable_000030;                  // 0x000030 (0x000008) VTable [12 slots] -> 0x134D9CA0
        TArray<UAudioGameplayVolumeProxy*>              TransientProxyList;             // 0x000038 (0x000010)
        TMap<uint32, UAudioGameplayVolumeComponent*>    AGVComponents;                  // 0x000048 (0x000010)
        uint8                                           UnknownData_000058[0x000078];   // 0x000058 (0x000078)
    };
    // Size: 0x0000E0 (0x000010)
    class alignas(0x4) UFilterVolumeComponent : public UAudioGameplayVolumeMutator
    {
    public:
        float   ExteriorLPF;        // 0x0000D0 (0x000004) [Default: 20000f]
        float   ExteriorLPFTime;    // 0x0000D4 (0x000004) [Default: 0.5f]
        float   InteriorLPF;        // 0x0000D8 (0x000004) [Default: 20000f]
        float   InteriorLPFTime;    // 0x0000DC (0x000004) [Default: 0.5f]
    
    public: // Functions
        void    SetExteriorLPF(float Volume, float InterpolateTime); // 0x05679B28 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetInteriorLPF(float Volume, float InterpolateTime); // 0x05679DBE [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x0000F0 (0x000020)
    class alignas(0x8) UReverbVolumeComponent : public UAudioGameplayVolumeMutator
    {
    public:
        FReverbSettings ReverbSettings; // 0x0000D0 (0x000020)
    
    public: // Functions
        void    SetReverbSettings(FReverbSettings& NewReverbSettings); // 0x0567AF6A [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x0000E0 (0x000010)
    class alignas(0x8) USubmixOverrideVolumeComponent : public UAudioGameplayVolumeMutator
    {
    public:
        TArray<FAudioVolumeSubmixOverrideSettings>  SubmixOverrideSettings; // 0x0000D0 (0x000010)
    
    public: // Functions
        void    SetSubmixOverrideSettings(TArray<FAudioVolumeSubmixOverrideSettings>& NewSubmixOverrideSettings); // 0x0567B1CC [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x0000E0 (0x000010)
    class alignas(0x8) USubmixSendVolumeComponent : public UAudioGameplayVolumeMutator
    {
    public:
        TArray<FAudioVolumeSubmixSendSettings>  SubmixSendSettings; // 0x0000D0 (0x000010)
    
    public: // Functions
        void    SetSubmixSendSettings(TArray<FAudioVolumeSubmixSendSettings>& NewSubmixSendSettings); // 0x0567B9F6 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
    };
}

