/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AdvancedWidgets_Functions
 * ============================================================
 */

#include "AdvancedWidgets.hpp"

namespace UE
{

    struct URadialSlider___GetCustomDefaultValue_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.44867e-26f]
    };

    struct URadialSlider___GetNormalizedSliderHandlePosition_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.44867e-26f]
    };

    struct URadialSlider___GetValue_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.44867e-26f]
    };

    struct URadialSlider___SetAngularOffset_Params
    {
        float   InValue;    // 0x000000 (0x000004) [Default: 1.44867e-26f]
    };

    struct URadialSlider___SetCenterBackgroundColor_Params
    {
        FLinearColor    InValue;    // 0x000000 (0x000010)
    };

    struct URadialSlider___SetCustomDefaultValue_Params
    {
        float   InValue;    // 0x000000 (0x000004) [Default: 1.44867e-26f]
    };

    struct URadialSlider___SetHandStartEndRatio_Params
    {
        FVector2D   InValue;    // 0x000000 (0x000010)
    };

    struct URadialSlider___SetLocked_Params
    {
        bool    InValue;    // 0x000000 (0x000001) [Default: true]
    };

    struct URadialSlider___SetShowSliderHand_Params
    {
        bool    InShowSliderHand;   // 0x000000 (0x000001) [Default: true]
    };

    struct URadialSlider___SetShowSliderHandle_Params
    {
        bool    InShowSliderHandle; // 0x000000 (0x000001) [Default: true]
    };

    struct URadialSlider___SetSliderBarColor_Params
    {
        FLinearColor    InValue;    // 0x000000 (0x000010)
    };

    struct URadialSlider___SetSliderHandleColor_Params
    {
        FLinearColor    InValue;    // 0x000000 (0x000010)
    };

    struct URadialSlider___SetSliderHandleEndAngle_Params
    {
        float   InValue;    // 0x000000 (0x000004) [Default: 1.44867e-26f]
    };

    struct URadialSlider___SetSliderHandleStartAngle_Params
    {
        float   InValue;    // 0x000000 (0x000004) [Default: 1.44867e-26f]
    };

    struct URadialSlider___SetSliderProgressColor_Params
    {
        FLinearColor    InValue;    // 0x000000 (0x000010)
    };

    struct URadialSlider___SetSliderRange_Params
    {
        FRuntimeFloatCurve  InSliderRange;  // 0x000000 (0x000048) [OutParam]
    };

    struct URadialSlider___SetStepSize_Params
    {
        float   InValue;    // 0x000000 (0x000004) [Default: 1.44867e-26f]
    };

    struct URadialSlider___SetUseVerticalDrag_Params
    {
        bool    InUseVerticalDrag;  // 0x000000 (0x000001) [Default: true]
    };

    struct URadialSlider___SetValue_Params
    {
        float   InValue;    // 0x000000 (0x000004) [Default: 1.44867e-26f]
    };

    struct URadialSlider___SetValueTags_Params
    {
        TArray<float>   InValueTags;    // 0x000000 (0x000010) [OutParam]
    };

} // namespace UE

