/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AppleImageUtils_Functions
 * ============================================================
 */

#include "AppleImageUtils_Functions.hpp"

namespace UE
{

    UAppleImageUtilsBaseAsyncTaskBlueprintProxy* UAppleImageUtilsBaseAsyncTaskBlueprintProxy::CreateProxyObjectForConvertToHEIF(UTexture* SourceImage, int32 Quality, bool bWantColor, bool bUseGpu, float Scale, ETextureRotationDirection Rotate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy.CreateProxyObjectForConvertToHEIF");
    
        UAppleImageUtilsBaseAsyncTaskBlueprintProxy___CreateProxyObjectForConvertToHEIF_Params Params{};
        Params.SourceImage = SourceImage;
        Params.Quality = Quality;
        Params.bWantColor = bWantColor;
        Params.bUseGpu = bUseGpu;
        Params.Scale = Scale;
        Params.Rotate = Rotate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAppleImageUtilsBaseAsyncTaskBlueprintProxy* UAppleImageUtilsBaseAsyncTaskBlueprintProxy::CreateProxyObjectForConvertToJPEG(UTexture* SourceImage, int32 Quality, bool bWantColor, bool bUseGpu, float Scale, ETextureRotationDirection Rotate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy.CreateProxyObjectForConvertToJPEG");
    
        UAppleImageUtilsBaseAsyncTaskBlueprintProxy___CreateProxyObjectForConvertToJPEG_Params Params{};
        Params.SourceImage = SourceImage;
        Params.Quality = Quality;
        Params.bWantColor = bWantColor;
        Params.bUseGpu = bUseGpu;
        Params.Scale = Scale;
        Params.Rotate = Rotate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAppleImageUtilsBaseAsyncTaskBlueprintProxy* UAppleImageUtilsBaseAsyncTaskBlueprintProxy::CreateProxyObjectForConvertToPNG(UTexture* SourceImage, bool bWantColor, bool bUseGpu, float Scale, ETextureRotationDirection Rotate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy.CreateProxyObjectForConvertToPNG");
    
        UAppleImageUtilsBaseAsyncTaskBlueprintProxy___CreateProxyObjectForConvertToPNG_Params Params{};
        Params.SourceImage = SourceImage;
        Params.bWantColor = bWantColor;
        Params.bUseGpu = bUseGpu;
        Params.Scale = Scale;
        Params.Rotate = Rotate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAppleImageUtilsBaseAsyncTaskBlueprintProxy* UAppleImageUtilsBaseAsyncTaskBlueprintProxy::CreateProxyObjectForConvertToTIFF(UTexture* SourceImage, bool bWantColor, bool bUseGpu, float Scale, ETextureRotationDirection Rotate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy.CreateProxyObjectForConvertToTIFF");
    
        UAppleImageUtilsBaseAsyncTaskBlueprintProxy___CreateProxyObjectForConvertToTIFF_Params Params{};
        Params.SourceImage = SourceImage;
        Params.bWantColor = bWantColor;
        Params.bUseGpu = bUseGpu;
        Params.Scale = Scale;
        Params.Rotate = Rotate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

} // namespace UE

