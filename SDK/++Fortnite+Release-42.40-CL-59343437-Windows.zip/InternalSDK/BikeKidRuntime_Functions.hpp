/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BikeKidRuntime_Functions
 * ============================================================
 */

#include "BikeKidRuntime.hpp"

namespace UE
{

    struct AFortAthenaMutator_BikeKid___OnViewTargetChanged_Params
    {
        AFortPlayerController*  PlayerController;   // 0x000000 (0x000008) [Default: 0x1495B150]
        AActor*                 OldViewTarget;      // 0x000008 (0x000008) [Default: 0xD06318DD00000031]
        AActor*                 NewViewTarget;      // 0x000010 (0x000008) [Default: 0x1989A550]
    };

    struct AFortBikeKid___BP_OnBikeKidDismissed_Params
    {
        FGameplayTag    DismissalReason;    // 0x000000 (0x000004) [OutParam]
    };

    struct AFortBikeKid___GameplayCue_Damage_Params
    {
        TEnumAsByte<EGameplayCueEvent>  EventType;                      // 0x000000 (0x000001) [Default: 240]
        uint8                           UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        FGameplayCueParameters          Parameters;                     // 0x000008 (0x0000D0)
    };

    struct AFortBikeKid___GetBikeKidMovementComponent_Params
    {
        UFortBikeKidMovementComponent*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1495C3F0]
    };

    struct AFortBikeKid___GetControllingPlayerPawn_Params
    {
        AFortPawn*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1495C3F0]
    };

    struct AFortBikeKid___GetDeltaRotator_Params
    {
        FRotator    ReturnValue;    // 0x000000 (0x000018) [ReturnValue]
    };

    struct AFortBikeKid___GetForwardAndRightDotProducts_Native_Params
    {
        float   OutForwardDot;  // 0x000000 (0x000004) [OutParam] [Default: 1.51224e-26f]
        float   OutRightDot;    // 0x000004 (0x000004) [OutParam] [Default: 0f]
    };

    struct AFortBikeKid___GetHealthPercentage_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.51224e-26f]
    };

    struct AFortBikeKid___GetLaunchDelayRemaining_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.51224e-26f]
    };

    struct AFortBikeKid___IsInLaunchDelay_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct AFortBikeKid___OnCapsuleComponentHit_Params
    {
        UPrimitiveComponent*    HitComponent;   // 0x000000 (0x000008) [Default: 0x1495C3F0]
        AActor*                 OtherActor;     // 0x000008 (0x000008) [Default: 0xCF6318DD00000031]
        UPrimitiveComponent*    OtherComp;      // 0x000010 (0x000008) [Default: 0x1989D6A0]
        FVector                 NormalImpulse;  // 0x000018 (0x000018)
        FHitResult              Hit;            // 0x000030 (0x0000F8) [OutParam]
    };

    struct AFortBikeKid___OnDamagePlayEffects_Params
    {
        float                           Damage;                         // 0x000000 (0x000004) [Default: 1.51224e-26f]
        uint8                           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FGameplayTagContainer           DamageTags;                     // 0x000008 (0x000020) [OutParam]
        FVector                         Momentum;                       // 0x000028 (0x000018)
        FHitResult                      HitInfo;                        // 0x000040 (0x0000F8) [OutParam]
        AFortPawn*                      InstigatedBy;                   // 0x000138 (0x000008) [Default: nullptr]
        AActor*                         DamageCauser;                   // 0x000140 (0x000008) [Default: nullptr]
        FGameplayEffectContextHandle    EffectContext;                  // 0x000148 (0x000018)
    };

    struct AFortBikeKid___OnDeathPlayEffects_Params
    {
        float                           Damage;                         // 0x000000 (0x000004) [Default: 1.51224e-26f]
        uint8                           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FGameplayTagContainer           DamageTags;                     // 0x000008 (0x000020) [OutParam]
        FVector                         Momentum;                       // 0x000028 (0x000018)
        FHitResult                      HitInfo;                        // 0x000040 (0x0000F8) [OutParam]
        AFortPawn*                      InstigatedBy;                   // 0x000138 (0x000008) [Default: nullptr]
        AActor*                         DamageCauser;                   // 0x000140 (0x000008) [Default: nullptr]
        FGameplayEffectContextHandle    EffectContext;                  // 0x000148 (0x000018)
    };

    struct AFortBikeKid___OnRep_ControllingPlayerPawn_Params
    {
        AFortPawn*  OldPawn;    // 0x000000 (0x000008) [Default: 0x1495C3F0]
    };

    struct AFortBikeKid___OnRotationInputReceived_Params
    {
        FRotator    RotationInput;  // 0x000000 (0x000018) [OutParam]
    };

    struct AFortBikeKid___SetTeamMatesIndicator_Params
    {
        bool    bState; // 0x000000 (0x000001) [Default: true]
    };

    struct UFortBikeKidControllingComponent___BP_OnBikeKidDestroyed_Params
    {
        FGameplayTag    DismissalReason;    // 0x000000 (0x000004) [OutParam]
    };

    struct UFortBikeKidControllingComponent___BP_OnDestructionStarted_Params
    {
        bool            bInstantDestruction;            // 0x000000 (0x000001) [Default: true]
        uint8           UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        FGameplayTag    DismissalReason;                // 0x000004 (0x000004)
    };

    struct UFortBikeKidControllingComponent___BP_OnDismissal_Params
    {
        FGameplayTag    DismissalReason;    // 0x000000 (0x000004)
    };

    struct UFortBikeKidControllingComponent___BP_StartedControlling_Params
    {
        AFortBikeKid*   InBikeKid;  // 0x000000 (0x000008) [Default: 0x1495DA10]
    };

    struct UFortBikeKidControllingComponent___ClampRotationInput_Params
    {
        FRotator    InOutRotationInput; // 0x000000 (0x000018) [OutParam]
    };

    struct UFortBikeKidControllingComponent___GetControlledBikeKid_Params
    {
        AFortBikeKid*   ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1495DA10]
    };

    struct UFortBikeKidControllingComponent___NotifyClientBikeKidDestruction_Params
    {
        FGameplayTag    DestructionReason;  // 0x000000 (0x000004)
    };

    struct UFortBikeKidControllingComponent___OnPlayerInterruptionTagsChanged_Params
    {
        FGameplayTag    Tag;        // 0x000000 (0x000004)
        int32           NewCount;   // 0x000004 (0x000004) [Default: 0]
    };

    struct UFortBikeKidControllingComponent___OnWeaponEquipped_Params
    {
        AFortWeapon*    NewWeapon;  // 0x000000 (0x000008) [Default: 0x1495DA10]
        AFortWeapon*    PrevWeapon; // 0x000008 (0x000008) [Default: 0xC46318DD00000031]
    };

    struct UFortBikeKidControllingComponent___PlayerInputMassageAxis_Params
    {
        float               InOutNewVal;                    // 0x000000 (0x000004) [OutParam] [Default: 1.51312e-26f]
        uint8               UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UFortPlayerInput*   PlayerInput;                    // 0x000008 (0x000008) [Default: 0xC46318DD00000031]
        FKey                Key;                            // 0x000010 (0x000018) [OutParam]
        float               DeltaTime;                      // 0x000028 (0x000004) [Default: 1.51334e-26f]
    };

    struct UFortBikeKidControllingComponent___PlayerInputMassageVectorAxis_Params
    {
        FVector             InOutNewVal;    // 0x000000 (0x000018) [OutParam]
        UFortPlayerInput*   PlayerInput;    // 0x000018 (0x000008) [Default: 0x19896E30]
        FKey                Key;            // 0x000020 (0x000018) [OutParam]
        float               DeltaTime;      // 0x000038 (0x000004) [Default: 1.76039e-27f]
    };

    struct UFortBikeKidControllingComponent___PlayerInputOverrideGamepadLookRates_Params
    {
        FRotator            InOutLookRatesBase;     // 0x000000 (0x000018) [OutParam]
        FRotator            InOutLookRatesFinal;    // 0x000018 (0x000018) [OutParam]
        UFortPlayerInput*   PlayerInput;            // 0x000030 (0x000008) [Default: 0x130A96B0]
        float               DeltaTime;              // 0x000038 (0x000004) [Default: 1.76039e-27f]
    };

    struct UFortBikeKidControllingComponent___PlayerInputOverrideTouchLookAccelerationMultiplier_Params
    {
        float               InOutMultiplier;                // 0x000000 (0x000004) [OutParam] [Default: 1.51312e-26f]
        uint8               UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UFortPlayerInput*   PlayerInput;                    // 0x000008 (0x000008) [Default: 0xC46318DD00000031]
    };

    struct UFortBikeKidControllingComponent___PlayerInputProcessTouch_Params
    {
        float               InOutLookYawDelta;      // 0x000000 (0x000004) [OutParam] [Default: 1.51312e-26f]
        float               InOutLookPitchDelta;    // 0x000004 (0x000004) [OutParam] [Default: 0f]
        UFortPlayerInput*   PlayerInput;            // 0x000008 (0x000008) [Default: 0xC46318DD00000031]
        FVector2D           TouchLookInput;         // 0x000010 (0x000010) [OutParam]
        float               DeltaTime;              // 0x000020 (0x000004) [Default: -0.000380626f]
    };

    struct UFortBikeKidControllingComponent___StartControllingBikeKid_Params
    {
        AFortBikeKid*   BikeKidToControl;   // 0x000000 (0x000008) [Default: 0x1495DA10]
    };

    struct UFortBikeKidControllingComponent___TryToStopControllingBikeKid_Params
    {
        FBikeKidDismissalData   DeferredDestroyData;    // 0x000000 (0x000010) [OutParam]
    };

    struct UFortBikeKidMovementComponent___SetHitBoxComponent_Params
    {
        UBoxComponent*  HitBox; // 0x000000 (0x000008) [Default: 0x1495E110]
    };

    struct UFortChargingSet_BikeKidEnergy___OnRep_Energy_Params
    {
        FFortGameplayAttributeData  OldValue;   // 0x000000 (0x000028) [OutParam]
    };

    struct UFortGameplayAbility_BikeKid_Dismiss___GetControlledBikeKid_Params
    {
        AFortBikeKid*   ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14958C30]
    };

    struct UFortGameplayAbility_BikeKid_MarkPotentialTargets___OnStartHighlightingTarget_Params
    {
        AActor* Target; // 0x000000 (0x000008) [Default: 0x14959150]
    };

    struct UFortGameplayAbility_BikeKid_MarkPotentialTargets___OnStoppedHighlightingTarget_Params
    {
        AActor* Target; // 0x000000 (0x000008) [Default: 0x14959150]
    };

    struct UFortGameplayAbility_BikeKid_PassiveMark___BP_OnTargetStatusChanged_Params
    {
        AActor* ActiveTarget;   // 0x000000 (0x000008) [Default: 0x14959820]
    };

    struct UFortGameplayAbility_BikeKid_PassiveMark___OnActorIndicatorExpired_Params
    {
        AActor* IndicatedActor; // 0x000000 (0x000008) [Default: 0x14959820]
    };

    struct UFortGameplayAbility_BikeKid_SpeedBoost___OnBoostedIntoActor_Params
    {
        FHitResult  HitResult;  // 0x000000 (0x0000F8) [OutParam]
    };

    struct UFortGameplayAbility_BikeKid_SpeedBoost___OnDoorBashed_Params
    {
        FHitResult                      HitResult;  // 0x000000 (0x0000F8) [OutParam]
        UFortBuildingWallDoorComponent* BashedDoor; // 0x0000F8 (0x000008) [Default: nullptr]
    };

    struct UFortGameplayAbility_BikeKid_TargetingBase___BP_OnTargetsFound_Params
    {
        FTargetingRequestHandle TargetingHandle;    // 0x000000 (0x000004) [OutParam]
    };

} // namespace UE

