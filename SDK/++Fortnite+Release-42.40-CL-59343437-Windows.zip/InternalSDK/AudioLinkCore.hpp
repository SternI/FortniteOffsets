/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:12
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioLinkCore
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000038 (0x000010)
    class UAudioLinkSettingsAbstract : public UObject
    {
    public:
        uint8   UnknownData_000028[0x000010];   // 0x000028 (0x000010)
    };
}

