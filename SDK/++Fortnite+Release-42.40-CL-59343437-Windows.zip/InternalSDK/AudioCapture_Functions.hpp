/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioCapture_Functions
 * ============================================================
 */

#include "AudioCapture.hpp"

namespace UE
{

    struct UAudioCapture___GetAudioCaptureDeviceInfo_Params
    {
        FAudioCaptureDeviceInfo OutInfo;        // 0x000000 (0x00000C) [OutParam]
        bool                    ReturnValue;    // 0x00000C (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioCapture___IsCapturingAudio_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioCaptureBlueprintLibrary___Conv_AudioInputDeviceInfoToString_Params
    {
        FAudioInputDeviceInfo   Info;           // 0x000000 (0x000030) [OutParam]
        FString                 ReturnValue;    // 0x000030 (0x000010) [ReturnValue] [Default: L""]
    };

    struct UAudioCaptureBlueprintLibrary___GetAvailableAudioInputDevices_Params
    {
        UObject*                    WorldContextObject;     // 0x000000 (0x000008) [Default: 0x130A5F60]
        OnAudioInputDevicesObtained OnObtainDevicesEvent;   // 0x000008 (0x00000C) [OutParam]
    };

    struct UAudioCaptureFunctionLibrary___CreateAudioCapture_Params
    {
        UAudioCapture*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x130A5F60]
    };

} // namespace UE

