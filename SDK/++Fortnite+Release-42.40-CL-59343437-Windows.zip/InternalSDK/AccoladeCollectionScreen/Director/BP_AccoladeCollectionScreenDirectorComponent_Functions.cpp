/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:49
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AccoladeCollectionScreen/Director/BP_AccoladeCollectionScreenDirectorComponent_Functions
 * ============================================================
 */

#include "BP_AccoladeCollectionScreenDirectorComponent_Functions.hpp"

namespace UE
{

    void UBP_AccoladeCollectionScreenDirectorComponent_C::ExecuteUbergraph_BP_AccoladeCollectionScreenDirectorComponent(int32 EntryPoint, TEnumAsByte<EEndPlayReason> K2Node_Event_EndPlayReason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AccoladeCollectionScreenDirectorComponent.BP_AccoladeCollectionScreenDirectorComponent_C.ExecuteUbergraph_BP_AccoladeCollectionScreenDirectorComponent");
    
        UBP_AccoladeCollectionScreenDirectorComponent_C___ExecuteUbergraph_BP_AccoladeCollectionScreenDirectorComponent_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.K2Node_Event_EndPlayReason = K2Node_Event_EndPlayReason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_AccoladeCollectionScreenDirectorComponent_C::OnReadyToShowUI()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AccoladeCollectionScreenDirectorComponent.BP_AccoladeCollectionScreenDirectorComponent_C.OnReadyToShowUI");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBP_AccoladeCollectionScreenDirectorComponent_C::ReceiveEndPlay(TEnumAsByte<EEndPlayReason> EndPlayReason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AccoladeCollectionScreenDirectorComponent.BP_AccoladeCollectionScreenDirectorComponent_C.ReceiveEndPlay");
    
        UBP_AccoladeCollectionScreenDirectorComponent_C___ReceiveEndPlay_Params Params{};
        Params.EndPlayReason = EndPlayReason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

