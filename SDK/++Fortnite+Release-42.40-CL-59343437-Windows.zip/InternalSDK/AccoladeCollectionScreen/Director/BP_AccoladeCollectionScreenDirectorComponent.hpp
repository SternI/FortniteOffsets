/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:49
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AccoladeCollectionScreen/Director/BP_AccoladeCollectionScreenDirectorComponent
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0000D0 (0x000010)
    class alignas(0x8) UBP_AccoladeCollectionScreenDirectorComponent_C : public UFortDynamicUIDirectorComponent
    {
    public:
        FPointerToUberGraphFrame    UberGraphFrame;         // 0x0000C0 (0x000008)
        UDynamicUIScene*            PinnedAccoladeScene;    // 0x0000C8 (0x000008) [Default: 0x7FEA18DB12A0]
    
    public: // Functions
        void    ExecuteUbergraph_BP_AccoladeCollectionScreenDirectorComponent(int32 EntryPoint, TEnumAsByte<EEndPlayReason> K2Node_Event_EndPlayReason); // 0x000545D2 [Final | UbergraphFunction]
        void    OnReadyToShowUI(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    ReceiveEndPlay(TEnumAsByte<EEndPlayReason> EndPlayReason); // 0x000545D2 [Event | Public | BlueprintEvent]
    };
}

