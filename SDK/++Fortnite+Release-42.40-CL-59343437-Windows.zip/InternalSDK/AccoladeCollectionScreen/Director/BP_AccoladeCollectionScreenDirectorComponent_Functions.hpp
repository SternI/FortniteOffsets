/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:49
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AccoladeCollectionScreen/Director/BP_AccoladeCollectionScreenDirectorComponent_Functions
 * ============================================================
 */

#include "BP_AccoladeCollectionScreenDirectorComponent.hpp"

namespace UE
{

    struct UBP_AccoladeCollectionScreenDirectorComponent_C___ExecuteUbergraph_BP_AccoladeCollectionScreenDirectorComponent_Params
    {
        int32                       EntryPoint;                 // 0x000000 (0x000004) [Default: 340256000]
        TEnumAsByte<EEndPlayReason> K2Node_Event_EndPlayReason; // 0x000004 (0x000001) [Default: 0]
    };

    struct UBP_AccoladeCollectionScreenDirectorComponent_C___ReceiveEndPlay_Params
    {
        TEnumAsByte<EEndPlayReason> EndPlayReason;  // 0x000000 (0x000001) [Default: 0]
    };

} // namespace UE

