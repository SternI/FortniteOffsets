/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:27
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AccoladeCollectionScreen/Injectors/WBP_QuestAccoladeEntry
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0016B0 (0x00004F)
    class alignas(0x8) UWBP_QuestAccoladeEntry_C : public UWBP_CustomEntry_C
    {
    public:
        uint8                               UnknownData_001661[0x000007];   // 0x001661 (0x000007)
        FPointerToUberGraphFrame            UberGraphFrame;                 // 0x001668 (0x000008)
        UCommonTextBlock*                   Text_Count;                     // 0x001670 (0x000008) [Default: nullptr]
        UImage*                             Image_35;                       // 0x001678 (0x000008) [Default: nullptr]
        UBorder*                            Border_Count;                   // 0x001680 (0x000008) [Default: nullptr]
        UQuestUIAccoladeEntryVM*            QuestUIAccoladeEntryVM;         // 0x001688 (0x000008) [Default: nullptr]
        TSoftObjectPtr<UMaterialInterface>  EntryMaterial;                  // 0x001690 (0x000020) [Default: nullptr]
    
    public: // Functions
        void    SetTier(EFortAccoladeTierType Tier, double CallFunc_Conv_ByteToDouble_ReturnValue, UMaterialInstanceDynamic* CallFunc_GetDynamicMaterial_ReturnValue, float CallFunc_SetScalarParameterValue_Value_ImplicitCast); // 0x000545D2 [Protected | BlueprintCallable | BlueprintEvent]
        void    SetQuestUIAccoladeEntryVM(UQuestUIAccoladeEntryVM* ViewModel, TScriptInterface<INotifyFieldValueChanged> CallFunc_SetViewModelByNameOnAllViews_ViewModel_CastInput, bool CallFunc_SetViewModelByNameOnAllViews_ReturnValue); // 0x000545D2 [Final | Public | BlueprintCallable | BlueprintEvent]
        void    SetEntryIcon(TSoftObjectPtr<UObject> Icon); // 0x000545D2 [Protected | BlueprintCallable | BlueprintEvent]
        void    SetCustomEntryVM(UQuestUICustomEntryVM* CustomEntryVM, UQuestUIAccoladeEntryVM* K2Node_DynamicCast_AsQuest_UI_Accolade_Entry_View_Model, bool K2Node_DynamicCast_bSuccess); // 0x000545D2 [Public | BlueprintCallable | BlueprintEvent]
        void    SetCompletedCount(int32 Count, ESlateVisibility Temp_byte_Variable, int64 CallFunc_Conv_IntToInt64_ReturnValue, FFormatArgumentData K2Node_MakeStruct_FormatArgumentData, bool CallFunc_Greater_IntInt_ReturnValue, TArray<FFormatArgumentData> K2Node_MakeArray_Array, FText CallFunc_Format_ReturnValue, ESlateVisibility Temp_byte_Variable_1, bool Temp_bool_Variable, ESlateVisibility K2Node_Select_Default); // 0x000545D2 [Protected | HasDefaults | BlueprintCallable | BlueprintEvent]
        void    PreConstruct(bool IsDesignTime); // 0x000545D2 [BlueprintCosmetic | Event | Public | BlueprintEvent]
        void    ExecuteUbergraph_WBP_QuestAccoladeEntry(int32 EntryPoint, bool K2Node_Event_IsDesignTime); // 0x000545D2 [Final | UbergraphFunction]
    };
}

