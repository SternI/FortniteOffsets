/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:27
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AccoladeCollectionScreen/Injectors/BP_QuestAccoladeInjector
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000130 (0x000000)
    class UBP_QuestAccoladeInjector_C : public UQuestAccoladeInjector
    {
    public:
    };
}

