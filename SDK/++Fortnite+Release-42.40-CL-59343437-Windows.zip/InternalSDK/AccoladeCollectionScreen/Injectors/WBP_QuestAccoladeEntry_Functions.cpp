/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:27
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AccoladeCollectionScreen/Injectors/WBP_QuestAccoladeEntry_Functions
 * ============================================================
 */

#include "WBP_QuestAccoladeEntry_Functions.hpp"

namespace UE
{

    void UWBP_QuestAccoladeEntry_C::SetTier(EFortAccoladeTierType Tier, double CallFunc_Conv_ByteToDouble_ReturnValue, UMaterialInstanceDynamic* CallFunc_GetDynamicMaterial_ReturnValue, float CallFunc_SetScalarParameterValue_Value_ImplicitCast)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("WBP_QuestAccoladeEntry.WBP_QuestAccoladeEntry_C.SetTier");
    
        UWBP_QuestAccoladeEntry_C___SetTier_Params Params{};
        Params.Tier = Tier;
        Params.CallFunc_Conv_ByteToDouble_ReturnValue = CallFunc_Conv_ByteToDouble_ReturnValue;
        Params.CallFunc_GetDynamicMaterial_ReturnValue = CallFunc_GetDynamicMaterial_ReturnValue;
        Params.CallFunc_SetScalarParameterValue_Value_ImplicitCast = CallFunc_SetScalarParameterValue_Value_ImplicitCast;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UWBP_QuestAccoladeEntry_C::SetQuestUIAccoladeEntryVM(UQuestUIAccoladeEntryVM* ViewModel, TScriptInterface<INotifyFieldValueChanged> CallFunc_SetViewModelByNameOnAllViews_ViewModel_CastInput, bool CallFunc_SetViewModelByNameOnAllViews_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("WBP_QuestAccoladeEntry.WBP_QuestAccoladeEntry_C.SetQuestUIAccoladeEntryVM");
    
        UWBP_QuestAccoladeEntry_C___SetQuestUIAccoladeEntryVM_Params Params{};
        Params.ViewModel = ViewModel;
        Params.CallFunc_SetViewModelByNameOnAllViews_ViewModel_CastInput = CallFunc_SetViewModelByNameOnAllViews_ViewModel_CastInput;
        Params.CallFunc_SetViewModelByNameOnAllViews_ReturnValue = CallFunc_SetViewModelByNameOnAllViews_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UWBP_QuestAccoladeEntry_C::SetEntryIcon(TSoftObjectPtr<UObject> Icon)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("WBP_QuestAccoladeEntry.WBP_QuestAccoladeEntry_C.SetEntryIcon");
    
        UWBP_QuestAccoladeEntry_C___SetEntryIcon_Params Params{};
        Params.Icon = Icon;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UWBP_QuestAccoladeEntry_C::SetCustomEntryVM(UQuestUICustomEntryVM* CustomEntryVM, UQuestUIAccoladeEntryVM* K2Node_DynamicCast_AsQuest_UI_Accolade_Entry_View_Model, bool K2Node_DynamicCast_bSuccess)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("WBP_QuestAccoladeEntry.WBP_QuestAccoladeEntry_C.SetCustomEntryVM");
    
        UWBP_QuestAccoladeEntry_C___SetCustomEntryVM_Params Params{};
        Params.CustomEntryVM = CustomEntryVM;
        Params.K2Node_DynamicCast_AsQuest_UI_Accolade_Entry_View_Model = K2Node_DynamicCast_AsQuest_UI_Accolade_Entry_View_Model;
        Params.K2Node_DynamicCast_bSuccess = K2Node_DynamicCast_bSuccess;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UWBP_QuestAccoladeEntry_C::SetCompletedCount(int32 Count, ESlateVisibility Temp_byte_Variable, int64 CallFunc_Conv_IntToInt64_ReturnValue, FFormatArgumentData K2Node_MakeStruct_FormatArgumentData, bool CallFunc_Greater_IntInt_ReturnValue, TArray<FFormatArgumentData> K2Node_MakeArray_Array, FText CallFunc_Format_ReturnValue, ESlateVisibility Temp_byte_Variable_1, bool Temp_bool_Variable, ESlateVisibility K2Node_Select_Default)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("WBP_QuestAccoladeEntry.WBP_QuestAccoladeEntry_C.SetCompletedCount");
    
        UWBP_QuestAccoladeEntry_C___SetCompletedCount_Params Params{};
        Params.Count = Count;
        Params.Temp_byte_Variable = Temp_byte_Variable;
        Params.CallFunc_Conv_IntToInt64_ReturnValue = CallFunc_Conv_IntToInt64_ReturnValue;
        Params.K2Node_MakeStruct_FormatArgumentData = K2Node_MakeStruct_FormatArgumentData;
        Params.CallFunc_Greater_IntInt_ReturnValue = CallFunc_Greater_IntInt_ReturnValue;
        Params.K2Node_MakeArray_Array = K2Node_MakeArray_Array;
        Params.CallFunc_Format_ReturnValue = CallFunc_Format_ReturnValue;
        Params.Temp_byte_Variable_1 = Temp_byte_Variable_1;
        Params.Temp_bool_Variable = Temp_bool_Variable;
        Params.K2Node_Select_Default = K2Node_Select_Default;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UWBP_QuestAccoladeEntry_C::PreConstruct(bool IsDesignTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("WBP_QuestAccoladeEntry.WBP_QuestAccoladeEntry_C.PreConstruct");
    
        UWBP_QuestAccoladeEntry_C___PreConstruct_Params Params{};
        Params.IsDesignTime = IsDesignTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UWBP_QuestAccoladeEntry_C::ExecuteUbergraph_WBP_QuestAccoladeEntry(int32 EntryPoint, bool K2Node_Event_IsDesignTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("WBP_QuestAccoladeEntry.WBP_QuestAccoladeEntry_C.ExecuteUbergraph_WBP_QuestAccoladeEntry");
    
        UWBP_QuestAccoladeEntry_C___ExecuteUbergraph_WBP_QuestAccoladeEntry_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.K2Node_Event_IsDesignTime = K2Node_Event_IsDesignTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

