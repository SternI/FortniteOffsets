/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:27
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AccoladeCollectionScreen/Injectors/WBP_QuestAccoladeEntry_Functions
 * ============================================================
 */

#include "WBP_QuestAccoladeEntry.hpp"

namespace UE
{

    struct UWBP_QuestAccoladeEntry_C___SetTier_Params
    {
        EFortAccoladeTierType       Tier;                                                   // 0x000000 (0x000001) [Default: EFortAccoladeTierType(64)]
        uint8                       UnknownData_000001[0x000007];                           // 0x000001 (0x000007)
        double                      CallFunc_Conv_ByteToDouble_ReturnValue;                 // 0x000008 (0x000008) [Default: 6.20792e-38]
        UMaterialInstanceDynamic*   CallFunc_GetDynamicMaterial_ReturnValue;                // 0x000010 (0x000008) [Default: 0x7FEE184A2000]
        float                       CallFunc_SetScalarParameterValue_Value_ImplicitCast;    // 0x000018 (0x000004) [Default: -2.55478e-23f]
    };

    struct UWBP_QuestAccoladeEntry_C___SetQuestUIAccoladeEntryVM_Params
    {
        UQuestUIAccoladeEntryVM*                    ViewModel;                                                  // 0x000000 (0x000008) [Default: 0x147FC240]
        TScriptInterface<INotifyFieldValueChanged>  CallFunc_SetViewModelByNameOnAllViews_ViewModel_CastInput;  // 0x000008 (0x000010)
        bool                                        CallFunc_SetViewModelByNameOnAllViews_ReturnValue;          // 0x000018 (0x000001) [Default: true]
    };

    struct UWBP_QuestAccoladeEntry_C___SetEntryIcon_Params
    {
        TSoftObjectPtr<UObject> Icon;   // 0x000000 (0x000020) [Default: 0x147FC240]
    };

    struct UWBP_QuestAccoladeEntry_C___SetCustomEntryVM_Params
    {
        UQuestUICustomEntryVM*      CustomEntryVM;                                              // 0x000000 (0x000008) [Default: 0x147FC240]
        UQuestUIAccoladeEntryVM*    K2Node_DynamicCast_AsQuest_UI_Accolade_Entry_View_Model;    // 0x000008 (0x000008) [Default: 0x38351FDD00280031]
        bool                        K2Node_DynamicCast_bSuccess;                                // 0x000010 (0x000001) [Default: false]
    };

    struct UWBP_QuestAccoladeEntry_C___SetCompletedCount_Params
    {
        int32                       Count;                                  // 0x000000 (0x000004) [Default: 343917120]
        ESlateVisibility            Temp_byte_Variable;                     // 0x000004 (0x000001) [Default: ESlateVisibility(0)]
        uint8                       UnknownData_000005[0x000003];           // 0x000005 (0x000003)
        int64                       CallFunc_Conv_IntToInt64_ReturnValue;   // 0x000008 (0x000008) [Default: 4050178473940484145ll]
        FFormatArgumentData         K2Node_MakeStruct_FormatArgumentData;   // 0x000010 (0x000048)
        bool                        CallFunc_Greater_IntInt_ReturnValue;    // 0x000058 (0x000001) [Default: false]
        uint8                       UnknownData_000059[0x000007];           // 0x000059 (0x000007)
        TArray<FFormatArgumentData> K2Node_MakeArray_Array;                 // 0x000060 (0x000010)
        FText                       CallFunc_Format_ReturnValue;            // 0x000070 (0x000010)
        ESlateVisibility            Temp_byte_Variable_1;                   // 0x000080 (0x000001) [Default: ESlateVisibility(0)]
        bool                        Temp_bool_Variable;                     // 0x000081 (0x000001) [Default: false]
        ESlateVisibility            K2Node_Select_Default;                  // 0x000082 (0x000001) [Default: ESlateVisibility(0)]
    };

    struct UWBP_QuestAccoladeEntry_C___PreConstruct_Params
    {
        bool    IsDesignTime;   // 0x000000 (0x000001) [Default: true]
    };

    struct UWBP_QuestAccoladeEntry_C___ExecuteUbergraph_WBP_QuestAccoladeEntry_Params
    {
        int32   EntryPoint;                 // 0x000000 (0x000004) [Default: 343917120]
        bool    K2Node_Event_IsDesignTime;  // 0x000004 (0x000001) [Default: false]
    };

} // namespace UE

