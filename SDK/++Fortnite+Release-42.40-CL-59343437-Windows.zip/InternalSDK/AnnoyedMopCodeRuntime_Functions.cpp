/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnnoyedMopCodeRuntime_Functions
 * ============================================================
 */

#include "AnnoyedMopCodeRuntime_Functions.hpp"

namespace UE
{

    void AFortProjectileAnnoyedMop::InitializeCollisionSegments(TArray<UCapsuleComponent*>& SegmentInitializers, UFortProjectileSegmentedCollisionComponent* SegmentedCollisionComp)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnoyedMopCodeRuntime.FortProjectileAnnoyedMop.InitializeCollisionSegments");
    
        AFortProjectileAnnoyedMop___InitializeCollisionSegments_Params Params{};
        Params.SegmentInitializers = SegmentInitializers;
        Params.SegmentedCollisionComp = SegmentedCollisionComp;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SegmentInitializers = Params.SegmentInitializers;
    }

    void AFortProjectileAnnoyedMop::InitializeFXComponent(UNiagaraComponent* FXComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnoyedMopCodeRuntime.FortProjectileAnnoyedMop.InitializeFXComponent");
    
        AFortProjectileAnnoyedMop___InitializeFXComponent_Params Params{};
        Params.FXComponent = FXComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    float AFortProjectileAnnoyedMop::UpdateSize(float DeltaSeconds, float GrowthSpeed)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnoyedMopCodeRuntime.FortProjectileAnnoyedMop.UpdateSize");
    
        AFortProjectileAnnoyedMop___UpdateSize_Params Params{};
        Params.DeltaSeconds = DeltaSeconds;
        Params.GrowthSpeed = GrowthSpeed;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAnnoyedMopProjectileComponent::InitializeFXComponent(UNiagaraComponent* FXComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnoyedMopCodeRuntime.AnnoyedMopProjectileComponent.InitializeFXComponent");
    
        UAnnoyedMopProjectileComponent___InitializeFXComponent_Params Params{};
        Params.FXComponent = FXComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    float UAnnoyedMopProjectileComponent::UpdateSize(float DeltaSeconds, float GrowthSpeed)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnnoyedMopCodeRuntime.AnnoyedMopProjectileComponent.UpdateSize");
    
        UAnnoyedMopProjectileComponent___UpdateSize_Params Params{};
        Params.DeltaSeconds = DeltaSeconds;
        Params.GrowthSpeed = GrowthSpeed;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

} // namespace UE

