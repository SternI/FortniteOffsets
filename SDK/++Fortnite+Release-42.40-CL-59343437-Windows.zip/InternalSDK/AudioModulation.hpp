/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:08
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioModulation
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000040 (0x000018)
    class alignas(0x8) UAudioModulationDestination : public UObject
    {
    public:
        USoundModulatorBase*    Modulator;                      // 0x000028 (0x000008) [Default: nullptr]
        uint8                   UnknownData_000030[0x000010];   // 0x000030 (0x000010)
    
    public: // Functions
        bool                    ClearModulator(); // 0x0DD98E02 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        USoundModulatorBase*    GetModulator(); // 0x0C98454A [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float                   GetValue(); // 0x0DD98EAE [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                    SetModulator(USoundModulatorBase* InModulator); // 0x05112558 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000040 (0x000010)
    class alignas(0x8) UAudioModulationSettings : public UDeveloperSettings
    {
    public:
        TArray<FSoftObjectPath> Parameters; // 0x000030 (0x000010)
    };
    // Size: 0x000028 (0x000000)
    class UAudioModulationStatics : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static void                                        ActivateBus(UObject* WorldContextObject, USoundControlBus* Bus); // 0x051126CE [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                        ActivateBusMix(UObject* WorldContextObject, USoundControlBusMix* Mix); // 0x0511296A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                        ActivateGenerator(UObject* WorldContextObject, USoundModulationGenerator* Generator); // 0x05112BE8 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                        ClearAllGlobalBusMixValues(UObject* WorldContextObject, float FadeTime); // 0x05112F2A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                        ClearGlobalBusMixValue(UObject* WorldContextObject, USoundControlBus* Bus, float FadeTime); // 0x051131A2 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static USoundModulationGeneratorADEnvelope*        CreateADEnvelopeGenerator(UObject* WorldContextObject, FName Name, FSoundModulationADEnvelopeParams& Params); // 0x0511352C [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static USoundControlBus*                           CreateBus(UObject* WorldContextObject, FName Name, USoundModulationParameter* Parameter, bool Activate); // 0x051138D8 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static USoundControlBusMix*                        CreateBusMix(UObject* WorldContextObject, FName Name, TArray<FSoundControlBusMixStage> Stages, bool Activate, double duration, bool bRetriggerOnActivation); // 0x05113DEA [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static USoundControlBusMix*                        CreateBusMixFromValue(UObject* WorldContextObject, FName Name, TArray<USoundControlBus*>& Buses, float Value, float AttackTime, float ReleaseTime, bool bActivate); // 0x051146D8 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static FSoundControlBusMixStage                    CreateBusMixStage(UObject* WorldContextObject, USoundControlBus* Bus, float Value, float AttackTime, float ReleaseTime); // 0x05114DDE [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static USoundModulationGeneratorEnvelopeFollower*  CreateEnvelopeFollowerGenerator(UObject* WorldContextObject, FName Name, FEnvelopeFollowerGeneratorParams Params); // 0x051154B8 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static USoundModulationGeneratorLFO*               CreateLFOGenerator(UObject* WorldContextObject, FName Name, FSoundModulationLFOParams Params); // 0x051158A8 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static UAudioModulationDestination*                CreateModulationDestination(UObject* WorldContextObject, FName Name, USoundModulatorBase* Modulator); // 0x05115C64 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static USoundModulationParameter*                  CreateModulationParameter(UObject* WorldContextObject, FName Name, UClass* ParamClass, float DefaultValue); // 0x05115FF4 [Final | RequiredAPI | Native | Static | Public]
        static void                                        DeactivateAllBusMixes(UObject* WorldContextObject); // 0x0511640A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                        DeactivateBus(UObject* WorldContextObject, USoundControlBus* Bus); // 0x05116570 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                        DeactivateBusMix(UObject* WorldContextObject, USoundControlBusMix* Mix); // 0x051167E8 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                        DeactivateGenerator(UObject* WorldContextObject, USoundModulationGenerator* Generator); // 0x05116A66 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static TSet<USoundModulatorBase*>                  GetModulatorsFromDestination(FSoundModulationDestinationSettings& Destination); // 0x05116CDE [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static float                                       GetModulatorValue(UObject* WorldContextObject, USoundModulatorBase* Modulator); // 0x05116F52 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static bool                                        IsControlBusMixActive(UObject* WorldContextObject, USoundControlBusMix* Mix); // 0x051171DA [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static TArray<FSoundControlBusMixStage>            LoadMixFromProfile(UObject* WorldContextObject, USoundControlBusMix* Mix, bool bActivate, int32 ProfileIndex); // 0x0511745A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                        SaveMixToProfile(UObject* WorldContextObject, USoundControlBusMix* Mix, int32 ProfileIndex); // 0x051178E8 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                        SetGlobalBusMixValue(UObject* WorldContextObject, USoundControlBus* Bus, float Value, float FadeTime); // 0x05117C72 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                        UpdateMix(UObject* WorldContextObject, USoundControlBusMix* Mix, TArray<FSoundControlBusMixStage> Stages, float FadeTime, double duration, bool bRetriggerOnActivation); // 0x0511811A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                        UpdateMixByFilter(UObject* WorldContextObject, USoundControlBusMix* Mix, FString AddressFilter, UClass* ParamClassFilter, USoundModulationParameter* ParamFilter, float Value, float FadeTime); // 0x05118704 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                        UpdateMixFromObject(UObject* WorldContextObject, USoundControlBusMix* Mix, float FadeTime); // 0x05118E46 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                                        UpdateModulator(UObject* WorldContextObject, USoundModulatorBase* Modulator); // 0x051191D0 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class UAudioModulationStyle : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FColor  GetControlBusColor(); // 0x0DD972D2 [Final | Native | Static | Public | HasDefaults | BlueprintCallable]
        static FColor  GetControlBusMixColor(); // 0x0DD972EA [Final | Native | Static | Public | HasDefaults | BlueprintCallable]
        static FColor  GetModulationGeneratorColor(); // 0x0DD97302 [Final | Native | Static | Public | HasDefaults | BlueprintCallable]
        static FColor  GetParameterColor(); // 0x0DD9731A [Final | Native | Static | Public | HasDefaults | BlueprintCallable]
        static FColor  GetPatchColor(); // 0x0DD97332 [Final | Native | Static | Public | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000040 (0x000010)
    class UAudioModulationSubsystem : public UAudioEngineSubsystem
    {
    public:
        uint8   UnknownData_000030[0x000010];   // 0x000030 (0x000010)
    };
    // Size: 0x000218 (0x0000D8)
    class alignas(0x8) UMovieSceneAudioControlBusMixSection : public UMovieSceneSection
    {
    public:
        void**                  VTable_000140;  // 0x000140 (0x000008) VTable [5 slots] -> 0x1332BF80
        FMovieSceneBoolChannel  BusValue;       // 0x000148 (0x0000C8)
        USoundControlBusMix*    MixBus;         // 0x000210 (0x000008) [Default: nullptr]
    };
    // Size: 0x000060 (0x000020)
    class UMovieSceneAudioControlBusMixSystem : public UMovieSceneEntitySystem
    {
    public:
        uint8   UnknownData_000040[0x000020];   // 0x000040 (0x000020)
    };
    // Size: 0x000108 (0x000010)
    class alignas(0x8) UMovieSceneAudioControlBusMixTrack : public UMovieSceneNameableTrack
    {
    public:
        TArray<UMovieSceneSection*> MixSections;    // 0x0000F8 (0x000010)
    };
    // Size: 0x000220 (0x0000E0)
    class alignas(0x8) UMovieSceneAudioControlBusSection : public UMovieSceneSection
    {
    public:
        void**                  VTable_000140;  // 0x000140 (0x000008) VTable [5 slots] -> 0x1332C940
        FMovieSceneFloatChannel BusValue;       // 0x000148 (0x0000D0)
        USoundControlBus*       ControlBus;     // 0x000218 (0x000008) [Default: nullptr]
    };
    // Size: 0x000050 (0x000010)
    class alignas(0x8) UMovieSceneAudioControlBusSystem : public UMovieSceneEntitySystem
    {
    public:
        TMap<UMovieSceneAudioControlBusSection*, FAudioControlBusSectionData>   ModulatorsByObjectKey;  // 0x000040 (0x000010)
    };
    // Size: 0x000108 (0x000010)
    class alignas(0x8) UMovieSceneAudioControlBusTrack : public UMovieSceneNameableTrack
    {
    public:
        TArray<UMovieSceneSection*> AudioSections;  // 0x0000F8 (0x000010)
    };
    // Size: 0x000060 (0x000030)
    class alignas(0x8) USoundControlBus : public USoundModulatorBase
    {
    public:
        bool                                bBypass;                        // 0x000030 (0x000001) [Default: false]
        uint8                               UnknownData_000031[0x000007];   // 0x000031 (0x000007)
        FString                             Address;                        // 0x000038 (0x000010) [Default: L""]
        TArray<USoundModulationGenerator*>  Generators;                     // 0x000048 (0x000010)
        USoundModulationParameter*          Parameter;                      // 0x000058 (0x000008) [Default: nullptr]
    };
    // Size: 0x000050 (0x000028)
    class alignas(0x8) USoundControlBusMix : public UObject
    {
    public:
        uint32                              ProfileIndex;                   // 0x000028 (0x000004) [Default: 0u]
        uint8                               UnknownData_00002C[0x000004];   // 0x00002C (0x000004)
        double                              duration;                       // 0x000030 (0x000008) [Default: -1]
        bool                                bRetriggerOnActivation;         // 0x000038 (0x000001) [Default: false]
        uint8                               UnknownData_000039[0x000007];   // 0x000039 (0x000007)
        TArray<FSoundControlBusMixStage>    MixStages;                      // 0x000040 (0x000010)
    
    public: // Functions
        void    ActivateMix(); // 0x0DD9B426 [Final | Native | Protected]
        void    DeactivateAllMixes(); // 0x0DD9B490 [Final | Native | Protected]
        void    DeactivateMix(); // 0x0DD9B4FA [Final | Native | Protected]
        void    LoadMixFromProfile(); // 0x0DD9B564 [Final | Native | Protected]
        void    SaveMixToProfile(); // 0x0DD9B5E2 [Final | Native | Protected]
        void    SoloMix(); // 0x0DD9B5FE [Final | Native | Protected]
    };
    // Size: 0x000030 (0x000000)
    class USoundModulationGenerator : public USoundModulatorBase
    {
    public:
    };
    // Size: 0x000048 (0x000018)
    class alignas(0x8) USoundModulationGeneratorADEnvelope : public USoundModulationGenerator
    {
    public:
        FSoundModulationADEnvelopeParams    Params;                         // 0x000030 (0x000014)
        uint8                               UnknownData_000044[0x000004];   // 0x000044 (0x000004)
    };
    // Size: 0x000050 (0x000020)
    class alignas(0x8) USoundModulationGeneratorEnvelopeFollower : public USoundModulationGenerator
    {
    public:
        FEnvelopeFollowerGeneratorParams    Params; // 0x000030 (0x000020)
    };
    // Size: 0x000050 (0x000020)
    class alignas(0x8) USoundModulationGeneratorLFO : public USoundModulationGenerator
    {
    public:
        FSoundModulationLFOParams   Params; // 0x000030 (0x000020)
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x8) USoundModulationParameter : public UObject
    {
    public:
        void**                              VTable_000028;  // 0x000028 (0x000008) VTable [799 slots] -> 0x1332DA50
        FSoundModulationParameterSettings   Settings;       // 0x000030 (0x000008)
    };
    // Size: 0x000040 (0x000008)
    class alignas(0x4) USoundModulationParameterAdditive : public USoundModulationParameter
    {
    public:
        float   UnitMin;    // 0x000038 (0x000004) [Default: 0f]
        float   UnitMax;    // 0x00003C (0x000004) [Default: 1f]
    };
    // Size: 0x000040 (0x000008)
    class alignas(0x4) USoundModulationParameterBipolar : public USoundModulationParameter
    {
    public:
        float   UnitRange;                      // 0x000038 (0x000004) [Default: 2f]
        uint8   UnknownData_00003C[0x000004];   // 0x00003C (0x000004)
    };
    // Size: 0x000038 (0x000000)
    class USoundModulationParameterFilterFrequency : public USoundModulationParameterFrequencyBase
    {
    public:
    };
    // Size: 0x000040 (0x000008)
    class alignas(0x4) USoundModulationParameterFrequency : public USoundModulationParameterFrequencyBase
    {
    public:
        float   UnitMin;    // 0x000038 (0x000004) [Default: 20f]
        float   UnitMax;    // 0x00003C (0x000004) [Default: 20000f]
    };
    // Size: 0x000038 (0x000000)
    class USoundModulationParameterFrequencyBase : public USoundModulationParameter
    {
    public:
    };
    // Size: 0x000038 (0x000000)
    class USoundModulationParameterHPFFrequency : public USoundModulationParameterFilterFrequency
    {
    public:
    };
    // Size: 0x000038 (0x000000)
    class USoundModulationParameterLPFFrequency : public USoundModulationParameterFilterFrequency
    {
    public:
    };
    // Size: 0x000040 (0x000008)
    class alignas(0x4) USoundModulationParameterScaled : public USoundModulationParameter
    {
    public:
        float   UnitMin;    // 0x000038 (0x000004) [Default: 0f]
        float   UnitMax;    // 0x00003C (0x000004) [Default: 1f]
    };
    // Size: 0x000040 (0x000008)
    class alignas(0x4) USoundModulationParameterVolume : public USoundModulationParameter
    {
    public:
        float   MinVolume;      // 0x000038 (0x000004) [Default: -100f]
        float   VolumeLimit;    // 0x00003C (0x000004) [Default: 20f]
    };
    // Size: 0x000050 (0x000020)
    class alignas(0x8) USoundModulationPatch : public USoundModulatorBase
    {
    public:
        FSoundControlModulationPatch    PatchSettings;  // 0x000030 (0x000020)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAudioControlBusSectionData
    {
        USoundControlBusMix*    ControlBusMix;                  // 0x000000 (0x000008)
        uint8                   UnknownData_000008[0x000008];   // 0x000008 (0x000008)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FEnvelopeFollowerGeneratorParams
    {
        bool        bBypass;                        // 0x000000 (0x000001)
        bool        bInvert;                        // 0x000001 (0x000001)
        uint8       UnknownData_000002[0x000006];   // 0x000002 (0x000006)
        UAudioBus*  AudioBus;                       // 0x000008 (0x000008)
        float       Gain;                           // 0x000010 (0x000004)
        float       AttackTime;                     // 0x000014 (0x000004)
        float       ReleaseTime;                    // 0x000018 (0x000004)
        uint8       UnknownData_00001C[0x000004];   // 0x00001C (0x000004)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x8) FMovieSceneAudioControlBusComponentData
    {
        UMovieSceneAudioControlBusSection*  Section;    // 0x000000 (0x000008)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x8) FMovieSceneAudioControlBusMixComponentData
    {
        UMovieSceneAudioControlBusMixSection*   Section;    // 0x000000 (0x000008)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FSoundControlBusMixStage
    {
        USoundControlBus*           Bus;    // 0x000000 (0x000008)
        FSoundModulationMixValue    Value;  // 0x000008 (0x000020)
    };
    // Size: 0x000090 (0x000090)
    struct alignas(0x8) FSoundControlModulationInput
    {
        uint8                       bSampleAndHold : 1;             // 0x000000 (0x000001) : 0x0
        uint8                       UnknownBit_000000_1 : 1;        // 0x000000 (0x000001) : 0x1
        uint8                       UnknownBit_000000_2 : 1;        // 0x000000 (0x000001) : 0x2
        uint8                       UnknownBit_000000_3 : 1;        // 0x000000 (0x000001) : 0x3
        uint8                       UnknownBit_000000_4 : 1;        // 0x000000 (0x000001) : 0x4
        uint8                       UnknownBit_000000_5 : 1;        // 0x000000 (0x000001) : 0x5
        uint8                       UnknownBit_000000_6 : 1;        // 0x000000 (0x000001) : 0x6
        uint8                       UnknownBit_000000_7 : 1;        // 0x000000 (0x000001) : 0x7
        uint8                       UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        FSoundModulationTransform   Transform;                      // 0x000008 (0x000080)
        USoundControlBus*           Bus;                            // 0x000088 (0x000008)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FSoundControlModulationPatch
    {
        bool                                    bBypass;                        // 0x000000 (0x000001)
        uint8                                   UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        USoundModulationParameter*              OutputParameter;                // 0x000008 (0x000008)
        TArray<FSoundControlModulationInput>    Inputs;                         // 0x000010 (0x000010)
    };
    // Size: 0x000014 (0x000014)
    struct alignas(0x4) FSoundModulationADEnvelopeParams
    {
        float   AttackTime;                     // 0x000000 (0x000004)
        float   DecayTime;                      // 0x000004 (0x000004)
        float   AttackCurve;                    // 0x000008 (0x000004)
        float   DecayCurve;                     // 0x00000C (0x000004)
        bool    bLooping;                       // 0x000010 (0x000001)
        bool    bBypass;                        // 0x000011 (0x000001)
        uint8   UnknownData_000012[0x000002];   // 0x000012 (0x000002)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x4) FSoundModulationLFOParams
    {
        ESoundModulationLFOShape    Shape;                          // 0x000000 (0x000001)
        uint8                       UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        float                       ExponentialFactor;              // 0x000004 (0x000004)
        float                       Width;                          // 0x000008 (0x000004)
        float                       Amplitude;                      // 0x00000C (0x000004)
        float                       Frequency;                      // 0x000010 (0x000004)
        float                       Offset;                         // 0x000014 (0x000004)
        float                       Phase;                          // 0x000018 (0x000004)
        bool                        bLooping;                       // 0x00001C (0x000001)
        bool                        bBypass;                        // 0x00001D (0x000001)
        uint8                       UnknownData_00001E[0x000002];   // 0x00001E (0x000002)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x4) FSoundModulationMixValue
    {
        float   TargetValue;                    // 0x000000 (0x000004) [Default: 0f]
        float   AttackTime;                     // 0x000004 (0x000004) [Default: 0f]
        float   ReleaseTime;                    // 0x000008 (0x000004) [Default: 0f]
        uint8   UnknownData_00000C[0x000014];   // 0x00000C (0x000014)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FSoundModulationParameterSettings
    {
        float   ValueNormalized;                // 0x000000 (0x000004)
        bool    bClampToNormalizedRange;        // 0x000004 (0x000001)
        uint8   UnknownData_000005[0x000003];   // 0x000005 (0x000003)
    };
    // Size: 0x000080 (0x000000)
    struct FSoundModulationTransform : public FWaveTableTransform
    {
    };
}

