/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/Area51GunRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000380 (0x000020)
    class alignas(0x8) UArea51LayerAnimInstance : public UFortItemLayerAnimInstance_ChargedWeapon
    {
    public:
        double  CurrentJumpValue;               // 0x000360 (0x000008) [Default: 0]
        double  CurrentOverheat;                // 0x000368 (0x000008) [Default: 0]
        bool    bLaserActive_Standing;          // 0x000370 (0x000001) [Default: false]
        bool    bLaserActive_Crouching;         // 0x000371 (0x000001) [Default: false]
        uint8   UnknownData_000372[0x00000E];   // 0x000372 (0x00000E)
    };
    // Size: 0x000028 (0x000000)
    class IArea51WeaponAnimInterface : public IInterface
    {
    public:
    
    public: // Functions
        void    GetAnimData(EArea51BeamStates& BeamState); // 0x06444B42 [Native | Event | Public | HasOutParms | BlueprintEvent]
    };
    // Size: 0x000208 (0x0001E0)
    class alignas(0x8) UChainLightningArc : public UObject
    {
    public:
        FVector                                             StartLocation;                  // 0x000028 (0x000018)
        FVector                                             EndLocation;                    // 0x000040 (0x000018)
        FVector                                             StartNormal;                    // 0x000058 (0x000018)
        FVector                                             EndNormal;                      // 0x000070 (0x000018)
        FVector                                             PreviousTargetLocation;         // 0x000088 (0x000018)
        TWeakObjectPtr<UFortActorComponent_ChainLightning>  OwningComponent;                // 0x0000A0 (0x000008) [Default: nullptr]
        TArray<UChainLightningArc*>                         ChildArcs;                      // 0x0000A8 (0x000010)
        TWeakObjectPtr<AActor>                              TargetActor;                    // 0x0000B8 (0x000008) [Default: nullptr]
        TWeakObjectPtr<UChainLightningArc>                  ParentArc;                      // 0x0000C0 (0x000008) [Default: nullptr]
        uint8                                               UnknownData_0000C8[0x000140];   // 0x0000C8 (0x000140)
    
    public: // Functions
        AActor* GetTargetActor(); // 0x10C4E228 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000578 (0x0004B8)
    class alignas(0x8) UFortActorComponent_ChainLightning : public UActorComponent
    {
    public:
        FScalableFloat                      AddEquippedWeaponTagsToDamage;          // 0x0000C0 (0x000028)
        UClass*                             ChainLightningTargetGE;                 // 0x0000E8 (0x000008) [Default: nullptr]
        FScalableFloat                      InitialTargetingUpdateRate;             // 0x0000F0 (0x000028)
        FScalableFloat                      InitialCosmeticArcEndpointRadiusMin;    // 0x000118 (0x000028)
        FScalableFloat                      InitialCosmeticArcEndpointRadiusMax;    // 0x000140 (0x000028)
        FScalableFloat                      InitialCosmeticArcMaxLength;            // 0x000168 (0x000028)
        FScalableFloat                      InitialCosmeticArcStartpointRadius;     // 0x000190 (0x000028)
        FScalableFloat                      InitialCosmeticArcAnglePrecision;       // 0x0001B8 (0x000028)
        FScalableFloat                      InitialCosmeticArcTraceHeightMax;       // 0x0001E0 (0x000028)
        FScalableFloat                      InitialCosmeticArcTraceHeightMin;       // 0x000208 (0x000028)
        FScalableFloat                      ServerChainTickRate;                    // 0x000230 (0x000028)
        FScalableFloat                      ClientChainTickRate;                    // 0x000258 (0x000028)
        FScalableFloat                      NDCUpdateRate;                          // 0x000280 (0x000028)
        FScalableFloat                      MaxInitialTargets;                      // 0x0002A8 (0x000028)
        FScalableFloat                      ClientSideArcDamage;                    // 0x0002D0 (0x000028)
        FScalableFloat                      TickDamageOnArcAttachment;              // 0x0002F8 (0x000028)
        FScalableFloat                      ComponentTraceLength;                   // 0x000320 (0x000028)
        FScalableFloat                      MaxNumComponentTraces;                  // 0x000348 (0x000028)
        FScalableFloat                      MaxNumChainsLOSPerTick;                 // 0x000370 (0x000028)
        TArray<FChainLightningArcConfig>    ArcLayerConfigs;                        // 0x000398 (0x000010)
        UTargetingPreset*                   InitialTargetingPreset;                 // 0x0003A8 (0x000008) [Default: nullptr]
        UTargetingPreset*                   ArcTargetingPreset;                     // 0x0003B0 (0x000008) [Default: nullptr]
        TEnumAsByte<ECollisionChannel>      LineOfSightCollisionChannel;            // 0x0003B8 (0x000001) [Default: 0]
        uint8                               UnknownData_0003B9[0x000007];           // 0x0003B9 (0x000007)
        FScalableFloat                      LineOfSightImpactBackoffDistance;       // 0x0003C0 (0x000028)
        UNiagaraDataChannelAsset*           ArcLightningFxDataChannel;              // 0x0003E8 (0x000008) [Default: nullptr]
        TWeakObjectPtr<AActor>              TargetingInstigator;                    // 0x0003F0 (0x000008) [Default: nullptr]
        TArray<UChainLightningArc*>         ActiveChains;                           // 0x0003F8 (0x000010)
        TArray<FChainLightningArcData>      ActiveArcData;                          // 0x000408 (0x000010)
        uint8                               UnknownData_000418[0x000060];           // 0x000418 (0x000060)
        bool                                bLightningActive;                       // 0x000478 (0x000001) [Default: false]
        uint8                               UnknownData_000479[0x0000FF];           // 0x000479 (0x0000FF)
    
    public: // Functions
        void    ActivateLightning(FVector StartLocation, FVector HitNormal, AActor* InstigatorActor); // 0x07F3B91C [Native | Public | HasDefaults | BlueprintCallable]
        void    DeactivateLightning(); // 0x0E788430 [Native | Public | BlueprintCallable]
        void    DebugTraceServerAndClient(FVector TraceStart, FVector TraceEnd, bool bServerCalled); // 0x07F3BCDE [Net | NetReliable | Native | Event | Public | HasDefaults | NetClient | Const]
        FVector GetSourceLocation(); // 0x10C4E256 [Native | Public | HasDefaults | BlueprintCallable]
        bool    IsLightningActive(); // 0x0FBBE6A8 [Native | Public | BlueprintCallable]
        void    OnRep_ActiveArcData(); // 0x10C4E2C6 [Final | Native | Protected]
        void    ServerApplyDamageEffect(FHitResult Target, TArray<uint8> Context); // 0x07F3C0A4 [Net | NetReliable | Native | Event | Protected | NetServer]
        void    SetSourceLocation(FVector NewLocation, FVector NewHitNormal); // 0x07F3C3FA [Native | Public | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000148 (0x000000)
    class UTargetingSelectionTask_AOE_Area51Gun : public UTargetingSelectionTask_AOE
    {
    public:
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FChainLightningArcConfig
    {
        FScalableFloat  MaxChildArcs;   // 0x000000 (0x000028)
    };
    // Size: 0x000078 (0x000078)
    struct alignas(0x8) FChainLightningArcData
    {
        TWeakObjectPtr<AActor>  TargetActor;    // 0x000000 (0x000008)
        FVector                 StartLocation;  // 0x000008 (0x000018)
        FVector                 EndLocation;    // 0x000020 (0x000018)
        FVector                 StartNormal;    // 0x000038 (0x000018)
        FVector                 EndNormal;      // 0x000050 (0x000018)
        FGuid                   ArcId;          // 0x000068 (0x000010)
    };
}

