/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnalyticsBlueprintLibrary_Functions
 * ============================================================
 */

#include "AnalyticsBlueprintLibrary.hpp"

namespace UE
{

    struct UAnalyticsBlueprintLibrary___GetSessionId_Params
    {
        FString ReturnValue;    // 0x000000 (0x000010) [ReturnValue] [Default: L"??"]
    };

    struct UAnalyticsBlueprintLibrary___GetUserId_Params
    {
        FString ReturnValue;    // 0x000000 (0x000010) [ReturnValue] [Default: L"??"]
    };

    struct UAnalyticsBlueprintLibrary___MakeEventAttribute_Params
    {
        FString             AttributeName;  // 0x000000 (0x000010) [Default: L"??"]
        FString             AttributeValue; // 0x000010 (0x000010) [Default: L""]
        FAnalyticsEventAttr ReturnValue;    // 0x000020 (0x000020) [ReturnValue]
    };

    struct UAnalyticsBlueprintLibrary___RecordCurrencyGiven_Params
    {
        FString GameCurrencyType;   // 0x000000 (0x000010) [Default: L"??"]
        int32   GameCurrencyAmount; // 0x000010 (0x000004) [Default: 392653360]
    };

    struct UAnalyticsBlueprintLibrary___RecordCurrencyGivenWithAttributes_Params
    {
        FString                     GameCurrencyType;               // 0x000000 (0x000010) [Default: L"??"]
        int32                       GameCurrencyAmount;             // 0x000010 (0x000004) [Default: 392653360]
        uint8                       UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        TArray<FAnalyticsEventAttr> Attributes;                     // 0x000018 (0x000010) [OutParam]
    };

    struct UAnalyticsBlueprintLibrary___RecordCurrencyPurchase_Params
    {
        FString GameCurrencyType;               // 0x000000 (0x000010) [Default: L"??"]
        int32   GameCurrencyAmount;             // 0x000010 (0x000004) [Default: 392653360]
        uint8   UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        FString RealCurrencyType;               // 0x000018 (0x000010) [Default: L""]
        float   RealMoneyCost;                  // 0x000028 (0x000004) [Default: 1.79365e-27f]
        uint8   UnknownData_00002C[0x000004];   // 0x00002C (0x000004)
        FString PaymentProvider;                // 0x000030 (0x000010) [Default: L""]
    };

    struct UAnalyticsBlueprintLibrary___RecordError_Params
    {
        FString Error;  // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UAnalyticsBlueprintLibrary___RecordErrorWithAttributes_Params
    {
        FString                     Error;      // 0x000000 (0x000010) [Default: L"??"]
        TArray<FAnalyticsEventAttr> Attributes; // 0x000010 (0x000010) [OutParam]
    };

    struct UAnalyticsBlueprintLibrary___RecordEvent_Params
    {
        FString EventName;  // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UAnalyticsBlueprintLibrary___RecordEventWithAttribute_Params
    {
        FString EventName;      // 0x000000 (0x000010) [Default: L"??"]
        FString AttributeName;  // 0x000010 (0x000010) [Default: L""]
        FString AttributeValue; // 0x000020 (0x000010) [Default: L""]
    };

    struct UAnalyticsBlueprintLibrary___RecordEventWithAttributes_Params
    {
        FString                     EventName;  // 0x000000 (0x000010) [Default: L"??"]
        TArray<FAnalyticsEventAttr> Attributes; // 0x000010 (0x000010) [OutParam]
    };

    struct UAnalyticsBlueprintLibrary___RecordItemPurchase_Params
    {
        FString ItemID;         // 0x000000 (0x000010) [Default: L"??"]
        FString Currency;       // 0x000010 (0x000010) [Default: L""]
        int32   PerItemCost;    // 0x000020 (0x000004) [Default: 1992602555]
        int32   ItemQuantity;   // 0x000024 (0x000004) [Default: 0]
    };

    struct UAnalyticsBlueprintLibrary___RecordProgress_Params
    {
        FString ProgressType;   // 0x000000 (0x000010) [Default: L"??"]
        FString ProgressName;   // 0x000010 (0x000010) [Default: L""]
    };

    struct UAnalyticsBlueprintLibrary___RecordProgressWithAttributes_Params
    {
        FString                     ProgressType;   // 0x000000 (0x000010) [Default: L"??"]
        FString                     ProgressName;   // 0x000010 (0x000010) [Default: L""]
        TArray<FAnalyticsEventAttr> Attributes;     // 0x000020 (0x000010) [OutParam]
    };

    struct UAnalyticsBlueprintLibrary___RecordProgressWithFullHierarchyAndAttributes_Params
    {
        FString                     ProgressType;   // 0x000000 (0x000010) [Default: L"??"]
        TArray<FString>             ProgressNames;  // 0x000010 (0x000010) [OutParam]
        TArray<FAnalyticsEventAttr> Attributes;     // 0x000020 (0x000010) [OutParam]
    };

    struct UAnalyticsBlueprintLibrary___RecordSimpleCurrencyPurchase_Params
    {
        FString GameCurrencyType;   // 0x000000 (0x000010) [Default: L"??"]
        int32   GameCurrencyAmount; // 0x000010 (0x000004) [Default: 392653360]
    };

    struct UAnalyticsBlueprintLibrary___RecordSimpleCurrencyPurchaseWithAttributes_Params
    {
        FString                     GameCurrencyType;               // 0x000000 (0x000010) [Default: L"??"]
        int32                       GameCurrencyAmount;             // 0x000010 (0x000004) [Default: 392653360]
        uint8                       UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        TArray<FAnalyticsEventAttr> Attributes;                     // 0x000018 (0x000010) [OutParam]
    };

    struct UAnalyticsBlueprintLibrary___RecordSimpleItemPurchase_Params
    {
        FString ItemID;         // 0x000000 (0x000010) [Default: L"??"]
        int32   ItemQuantity;   // 0x000010 (0x000004) [Default: 392653360]
    };

    struct UAnalyticsBlueprintLibrary___RecordSimpleItemPurchaseWithAttributes_Params
    {
        FString                     ItemID;                         // 0x000000 (0x000010) [Default: L"??"]
        int32                       ItemQuantity;                   // 0x000010 (0x000004) [Default: 392653360]
        uint8                       UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        TArray<FAnalyticsEventAttr> Attributes;                     // 0x000018 (0x000010) [OutParam]
    };

    struct UAnalyticsBlueprintLibrary___SetAge_Params
    {
        int32   Age;    // 0x000000 (0x000004) [Default: 319446880]
    };

    struct UAnalyticsBlueprintLibrary___SetBuildInfo_Params
    {
        FString BuildInfo;  // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UAnalyticsBlueprintLibrary___SetGender_Params
    {
        FString Gender; // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UAnalyticsBlueprintLibrary___SetLocation_Params
    {
        FString Location;   // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UAnalyticsBlueprintLibrary___SetSessionId_Params
    {
        FString SessionID;  // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UAnalyticsBlueprintLibrary___SetUserId_Params
    {
        FString UserId; // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UAnalyticsBlueprintLibrary___StartSession_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAnalyticsBlueprintLibrary___StartSessionWithAttributes_Params
    {
        TArray<FAnalyticsEventAttr> Attributes;     // 0x000000 (0x000010) [OutParam]
        bool                        ReturnValue;    // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

} // namespace UE

