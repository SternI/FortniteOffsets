/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArcadeWeaponUI_Functions
 * ============================================================
 */

#include "ArcadeWeaponUI.hpp"

namespace UE
{

    struct UArcadeWeaponInGameUIHitPointsVM___GetIsTrickShot_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UArcadeWeaponInGameUIHitPointsVM___GetScoreText_Params
    {
        FText   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UArcadeWeaponInGameUIHitPointsVM___GetScoreTextRenderTranslation_Params
    {
        FVector2D   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UArcadeWeaponUIScoreVM___GetCurrentMatchScore_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344687312]
    };

    struct UArcadeWeaponUIScoreVM___GetCurrentStreak_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344687312]
    };

} // namespace UE

