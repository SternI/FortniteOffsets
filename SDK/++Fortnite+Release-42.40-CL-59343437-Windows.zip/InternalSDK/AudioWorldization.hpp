/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioWorldization
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0002C8 (0x000058)
    class alignas(0x8) AAudioWorldizationReflectionProbe : public AActor
    {
    public:
        void**                          VTable_000270;                  // 0x000270 (0x000008) VTable [157 slots] -> 0x134E1320
        USubmixSendVolumeComponent*     SubmixSends;                    // 0x000278 (0x000008) [Default: 0x7FE83956EBB0]
        USubmixOverrideVolumeComponent* SubmixEffects;                  // 0x000280 (0x000008) [Default: 0x7FE83956ED70]
        UAudioGameplayVolumeComponent*  AGVComponent;                   // 0x000288 (0x000008) [Default: 0x7FE83956EE50]
        uint8                           UnknownData_000290[0x000038];   // 0x000290 (0x000038)
    };
    // Size: 0x0000A8 (0x000080)
    class alignas(0x8) UAudioWorldizationData : public UDataAsset
    {
    public:
        FAudioWorldizationSettings  Settings;   // 0x000028 (0x000080)
    };
    // Size: 0x000100 (0x0000D0)
    class alignas(0x8) UAudioWorldizationDefaultSettings : public UDeveloperSettings
    {
    public:
        FAudioWorldizationGlobalSettings    GlobalSettings;         // 0x000030 (0x000040)
        FAudioWorldizationSettings          DefaultSettings;        // 0x000070 (0x000080)
        TArray<FSoftObjectPath>             ModulationParameters;   // 0x0000F0 (0x000010)
    };
    // Size: 0x0000E8 (0x000018)
    class alignas(0x8) UAudioWorldizationSendsVolumeComponent : public UAudioGameplayVolumeComponentBase
    {
    public:
        FName                           Identifier;                     // 0x0000D0 (0x000004) [Default: NAME_None]
        uint8                           UnknownData_0000D4[0x000004];   // 0x0000D4 (0x000004)
        TArray<FAudioWorldizationSend>  Sends;                          // 0x0000D8 (0x000010)
    };
    // Size: 0x0003E0 (0x000398)
    class alignas(0x8) UAudioWorldizationSubsystem : public UTickableWorldSubsystem
    {
    public:
        MULTI_INLINE_DELEGATE(OnWorldizationDisabled)   OnWorldizationEnabled;          // 0x000048 (0x000010)
        USoundControlBus*                               EnclosureBus;                   // 0x000058 (0x000008) [Default: nullptr]
        USoundControlBus*                               WallDistanceBus;                // 0x000060 (0x000008) [Default: nullptr]
        USoundControlBus*                               ListenerAzimuthBus;             // 0x000068 (0x000008) [Default: nullptr]
        uint8                                           UnknownData_000070[0x000008];   // 0x000070 (0x000008)
        FAudioWorldizationSettings                      CurrentSettings;                // 0x000078 (0x000080)
        AAudioWorldizationReflectionProbe*              VolumeActor;                    // 0x0000F8 (0x000008) [Default: nullptr]
        UAudioWorldizationTracePolicyBase*              TracePolicy;                    // 0x000100 (0x000008) [Default: nullptr]
        UAudioWorldizationTraceDirectionPolicyBase*     TraceDirectionPolicy;           // 0x000108 (0x000008) [Default: nullptr]
        uint8                                           UnknownData_000110[0x000230];   // 0x000110 (0x000230)
        TArray<FAudioWorldizationSettings>              SettingsStack;                  // 0x000340 (0x000010)
        TArray<USoundControlBus*>                       QuadrantEnclosureBuses;         // 0x000350 (0x000010)
        TArray<USoundControlBus*>                       QuadrantWallDistanceBuses;      // 0x000360 (0x000010)
        FTransform                                      CachedTraceOrigin;              // 0x000370 (0x000060)
        uint8                                           UnknownData_0003D0[0x000010];   // 0x0003D0 (0x000010)
    
    public: // Functions
        TMap<FGameplayTag, int32>   GetActorTagCounts(); // 0x0E45EDF6 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        FGameplayTagContainer       GetActorTags(); // 0x0E45EE76 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        float                       GetEnclosureFactor(); // 0x0E45EF0E [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float                       GetWallDistanceRatio(); // 0x0E45EF70 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                        IsAGVDisabled(); // 0x0E45EFD2 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                        OverrideEffectSends(FName InIdentifier, TArray<FAudioWorldizationSend>& InSends); // 0x05680B9C [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        RemoveEffectSendOverride(FName InIdentifier); // 0x05680E48 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        RemoveWorldizationSettings(FName InIdentifier); // 0x05680FB8 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        SetDefaultSettings(); // 0x0E45EFEC [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        SetEnabled(bool bNewEnabled); // 0x05681248 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        SetWorldizationSettings(FAudioWorldizationSettings& InSettings); // 0x056814FC [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000030 (0x000008)
    class UAudioWorldizationTraceDirectionPolicyBase : public UObject
    {
    public:
        uint8   UnknownData_000028[0x000008];   // 0x000028 (0x000008)
    };
    // Size: 0x000030 (0x000000)
    class UAudioWorldizationTraceDirectionPolicyDefault : public UAudioWorldizationTraceDirectionPolicyBase
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class UAudioWorldizationTracePolicyBase : public UObject
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class UAudioWorldizationTracePolicyDefault : public UAudioWorldizationTracePolicyBase
    {
    public:
    };
    // Size: 0x0000D8 (0x000008)
    class alignas(0x8) UAudioWorldizationVolumeComponent : public UAudioGameplayVolumeComponentBase
    {
    public:
        UAudioWorldizationData* Settings;   // 0x0000D0 (0x000008) [Default: nullptr]
    };
    // Size: 0x000068 (0x000010)
    class alignas(0x4) UAudioWorldizationVolumeProxy : public UAGVPrimitiveComponentProxy
    {
    public:
        uint8                                   UnknownData_000058[0x000008];   // 0x000058 (0x000008)
        float                                   EnclosureTarget;                // 0x000060 (0x000004) [Default: 0f]
        EAudioWorldizationThresholdOperation    Requirement;                    // 0x000064 (0x000001) [Default: EAudioWorldizationThresholdOperation(4)]
        uint8                                   UnknownData_000065[0x000003];   // 0x000065 (0x000003)
    };
    // Size: 0x000050 (0x000028)
    class alignas(0x8) UGameFeatureAction_SetAudioWorldizationEffectSends : public UGameFeatureAction
    {
    public:
        FName                           Identifier;                     // 0x000028 (0x000004) [Default: NAME_None]
        uint8                           UnknownData_00002C[0x000004];   // 0x00002C (0x000004)
        TArray<FAudioWorldizationSend>  Sends;                          // 0x000030 (0x000010)
        uint8                           UnknownData_000040[0x000010];   // 0x000040 (0x000010)
    };
    // Size: 0x0000B8 (0x000090)
    class alignas(0x8) UGameFeatureAction_SetAudioWorldizationSettings : public UGameFeatureAction
    {
    public:
        FAudioWorldizationSettings  Settings;                       // 0x000028 (0x000080)
        uint8                       UnknownData_0000A8[0x000010];   // 0x0000A8 (0x000010)
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FAudioSphereTraceResult
    {
        bool    bBlocking;                      // 0x000000 (0x000001) [Default: true]
        uint8   UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        float   Distance;                       // 0x000004 (0x000004) [Default: 0f]
        uint8   UnknownData_000008[0x000004];   // 0x000008 (0x000004)
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x8) FAudioWorldizationGlobalSettings
    {
        float                                       EffectCrossfadeTime;            // 0x000000 (0x000004)
        FName                                       IgnoreTraceActorTag;            // 0x000004 (0x000004)
        USoundControlBus*                           EnclosureBus;                   // 0x000008 (0x000008)
        USoundControlBus*                           WallDistanceBus;                // 0x000010 (0x000008)
        USoundControlBus*                           ListenerAzimuthBus;             // 0x000018 (0x000008)
        TArray<FAudioWorldizationQuadrantSettings>  Quadrants;                      // 0x000020 (0x000010)
        TArray<USoundControlBus*>                   VolumeModulationForOldAGVSetup; // 0x000030 (0x000010)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAudioWorldizationQuadrantSettings
    {
        USoundControlBus*   WallDistanceBus;    // 0x000000 (0x000008)
        USoundControlBus*   EnclosureBus;       // 0x000008 (0x000008)
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x8) FAudioWorldizationSend
    {
        TSoftObjectPtr<USoundSubmix>                        Submix;             // 0x000000 (0x000020)
        TSet<TSoftObjectPtr<USoundModulatorBase>>           VolumeModulators;   // 0x000020 (0x000010)
        TArray<TSoftObjectPtr<USoundEffectSubmixPreset>>    EffectChain;        // 0x000030 (0x000010)
    };
    // Size: 0x000080 (0x000080)
    struct alignas(0x8) FAudioWorldizationSettings
    {
        FName                                   Identifier;                     // 0x000000 (0x000004)
        uint8                                   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FAudioWorldizationSend>          Sends;                          // 0x000008 (0x000010)
        float                                   EnclosureSmoothSpeed;           // 0x000018 (0x000004)
        float                                   WallDistanceSmoothSpeed;        // 0x00001C (0x000004)
        float                                   TraceRadius;                    // 0x000020 (0x000004)
        float                                   CrossfadeTime;                  // 0x000024 (0x000004)
        int32                                   TracePoints;                    // 0x000028 (0x000004)
        int32                                   TracesPerFrame;                 // 0x00002C (0x000004)
        float                                   SideQuadrantDegrees;            // 0x000030 (0x000004)
        float                                   UpQuadrantDegrees;              // 0x000034 (0x000004)
        FVector                                 TraceOrigin;                    // 0x000038 (0x000018)
        TEnumAsByte<ECollisionChannel>          TraceChannel;                   // 0x000050 (0x000001)
        uint8                                   UnknownData_000051[0x000007];   // 0x000051 (0x000007)
        TArray<TEnumAsByte<ECollisionChannel>>  ResponseChannels;               // 0x000058 (0x000010)
        UClass*                                 TracePolicy;                    // 0x000068 (0x000008)
        UClass*                                 TraceDirectionPolicy;           // 0x000070 (0x000008)
        bool                                    bCollectActorAssetTags;         // 0x000078 (0x000001)
        uint8                                   UnknownData_000079[0x000007];   // 0x000079 (0x000007)
    };
}

