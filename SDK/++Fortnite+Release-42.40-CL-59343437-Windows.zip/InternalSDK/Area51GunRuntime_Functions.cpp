/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/Area51GunRuntime_Functions
 * ============================================================
 */

#include "Area51GunRuntime_Functions.hpp"

namespace UE
{

    void IArea51WeaponAnimInterface::GetAnimData(EArea51BeamStates& BeamState)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("Area51GunRuntime.Area51WeaponAnimInterface.GetAnimData");
    
        IArea51WeaponAnimInterface___GetAnimData_Params Params{};
        Params.BeamState = BeamState;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BeamState = Params.BeamState;
    }

    AActor* UChainLightningArc::GetTargetActor()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("Area51GunRuntime.ChainLightningArc.GetTargetActor");
    
        UChainLightningArc___GetTargetActor_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortActorComponent_ChainLightning::ActivateLightning(FVector StartLocation, FVector HitNormal, AActor* InstigatorActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("Area51GunRuntime.FortActorComponent_ChainLightning.ActivateLightning");
    
        UFortActorComponent_ChainLightning___ActivateLightning_Params Params{};
        Params.StartLocation = StartLocation;
        Params.HitNormal = HitNormal;
        Params.InstigatorActor = InstigatorActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortActorComponent_ChainLightning::DeactivateLightning()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("Area51GunRuntime.FortActorComponent_ChainLightning.DeactivateLightning");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortActorComponent_ChainLightning::DebugTraceServerAndClient(FVector TraceStart, FVector TraceEnd, bool bServerCalled)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("Area51GunRuntime.FortActorComponent_ChainLightning.DebugTraceServerAndClient");
    
        UFortActorComponent_ChainLightning___DebugTraceServerAndClient_Params Params{};
        Params.TraceStart = TraceStart;
        Params.TraceEnd = TraceEnd;
        Params.bServerCalled = bServerCalled;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    FVector UFortActorComponent_ChainLightning::GetSourceLocation()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("Area51GunRuntime.FortActorComponent_ChainLightning.GetSourceLocation");
    
        UFortActorComponent_ChainLightning___GetSourceLocation_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UFortActorComponent_ChainLightning::IsLightningActive()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("Area51GunRuntime.FortActorComponent_ChainLightning.IsLightningActive");
    
        UFortActorComponent_ChainLightning___IsLightningActive_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortActorComponent_ChainLightning::OnRep_ActiveArcData()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("Area51GunRuntime.FortActorComponent_ChainLightning.OnRep_ActiveArcData");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortActorComponent_ChainLightning::ServerApplyDamageEffect(FHitResult Target, TArray<uint8> Context)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("Area51GunRuntime.FortActorComponent_ChainLightning.ServerApplyDamageEffect");
    
        UFortActorComponent_ChainLightning___ServerApplyDamageEffect_Params Params{};
        Params.Target = Target;
        Params.Context = Context;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortActorComponent_ChainLightning::SetSourceLocation(FVector NewLocation, FVector NewHitNormal)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("Area51GunRuntime.FortActorComponent_ChainLightning.SetSourceLocation");
    
        UFortActorComponent_ChainLightning___SetSourceLocation_Params Params{};
        Params.NewLocation = NewLocation;
        Params.NewHitNormal = NewHitNormal;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

