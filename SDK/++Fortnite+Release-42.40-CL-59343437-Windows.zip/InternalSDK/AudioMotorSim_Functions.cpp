/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioMotorSim_Functions
 * ============================================================
 */

#include "AudioMotorSim_Functions.hpp"

namespace UE
{

    void UAudioMotorModelComponent::AddMotorAudioComponent(TScriptInterface<IAudioMotorSimOutput> InComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorModelComponent.AddMotorAudioComponent");
    
        UAudioMotorModelComponent___AddMotorAudioComponent_Params Params{};
        Params.InComponent = InComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMotorModelComponent::AddMotorSimComponent(TScriptInterface<IAudioMotorSim> InComponent, int32 SortOrder)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorModelComponent.AddMotorSimComponent");
    
        UAudioMotorModelComponent___AddMotorSimComponent_Params Params{};
        Params.InComponent = InComponent;
        Params.SortOrder = SortOrder;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMotorModelComponent::ConfigureMotorSimComponents(TArray<FInstancedStruct>& InConfigData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorModelComponent.ConfigureMotorSimComponents");
    
        UAudioMotorModelComponent___ConfigureMotorSimComponents_Params Params{};
        Params.InConfigData = InConfigData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InConfigData = Params.InConfigData;
    }

    FAudioMotorSimInputContext UAudioMotorModelComponent::GetCachedInputData()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorModelComponent.GetCachedInputData");
    
        UAudioMotorModelComponent___GetCachedInputData_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAudioMotorModelComponent::GetGear()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorModelComponent.GetGear");
    
        UAudioMotorModelComponent___GetGear_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAudioMotorModelComponent::GetRpm()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorModelComponent.GetRpm");
    
        UAudioMotorModelComponent___GetRpm_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FAudioMotorSimRuntimeContext UAudioMotorModelComponent::GetRuntimeInfo()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorModelComponent.GetRuntimeInfo");
    
        UAudioMotorModelComponent___GetRuntimeInfo_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioMotorModelComponent::RemoveAllMotorSimComponents()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorModelComponent.RemoveAllMotorSimComponents");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioMotorModelComponent::RemoveMotorAudioComponent(TScriptInterface<IAudioMotorSimOutput> InComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorModelComponent.RemoveMotorAudioComponent");
    
        UAudioMotorModelComponent___RemoveMotorAudioComponent_Params Params{};
        Params.InComponent = InComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMotorModelComponent::RemoveMotorSimComponent(TScriptInterface<IAudioMotorSim> InComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorModelComponent.RemoveMotorSimComponent");
    
        UAudioMotorModelComponent___RemoveMotorSimComponent_Params Params{};
        Params.InComponent = InComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMotorModelComponent::Reset()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorModelComponent.Reset");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioMotorModelComponent::StartOutput()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorModelComponent.StartOutput");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioMotorModelComponent::StopOutput()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorModelComponent.StopOutput");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioMotorModelComponent::Update(FAudioMotorSimInputContext& Input)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorModelComponent.Update");
    
        UAudioMotorModelComponent___Update_Params Params{};
        Params.Input = Input;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Input = Params.Input;
    }

    void IAudioMotorSim::ConfigMotorSim(FInstancedStruct& InConfigData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorSim.ConfigMotorSim");
    
        IAudioMotorSim___ConfigMotorSim_Params Params{};
        Params.InConfigData = InConfigData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InConfigData = Params.InConfigData;
    }

    bool IAudioMotorSim::GetEnabled()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorSim.GetEnabled");
    
        IAudioMotorSim___GetEnabled_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void IAudioMotorSim::Reset()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorSim.Reset");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioMotorSimComponent::BP_Reset()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorSimComponent.BP_Reset");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    bool UAudioMotorSimComponent::BP_Update(FAudioMotorSimInputContext& Input, FAudioMotorSimRuntimeContext& RuntimeInfo)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorSimComponent.BP_Update");
    
        UAudioMotorSimComponent___BP_Update_Params Params{};
        Params.Input = Input;
        Params.RuntimeInfo = RuntimeInfo;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Input = Params.Input;
        RuntimeInfo = Params.RuntimeInfo;
    
        return Params.ReturnValue;
    }

    void UAudioMotorSimComponent::SetEnabled(bool bNewEnabled)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMotorSim.AudioMotorSimComponent.SetEnabled");
    
        UAudioMotorSimComponent___SetEnabled_Params Params{};
        Params.bNewEnabled = bNewEnabled;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

