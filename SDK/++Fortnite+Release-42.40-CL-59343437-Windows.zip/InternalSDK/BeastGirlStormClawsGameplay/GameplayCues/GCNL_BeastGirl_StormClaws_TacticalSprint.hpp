/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:48
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/GameplayCues/GCNL_BeastGirl_StormClaws_TacticalSprint
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000C48 (0x000000)
    class AGCNL_BeastGirl_StormClaws_TacticalSprint_C : public AFortGameplayCueNotify_Loop
    {
    public:
    };
}

