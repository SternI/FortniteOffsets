/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/Camera/CameraMode_BeastGirl_TacSprint
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x002080 (0x000000)
    class UCameraMode_BeastGirl_TacSprint_C : public UAthena_PlayerCameraModeBase_C
    {
    public:
    };
}

