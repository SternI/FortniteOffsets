/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:48
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/Camera/CameraShake_BeastGirl_TacticalSprint_Loop
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000200 (0x000000)
    class UCameraShake_BeastGirl_TacticalSprint_Loop_C : public ULegacyCameraShake
    {
    public:
    };
}

