/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/FMM_GuidedMotion_BeastGirl_StormSlam_Down
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000630 (0x000090)
    class alignas(0x8) UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C : public UFortMovementMode_ExtGuidedMotion
    {
    public:
        FPointerToUberGraphFrame    UberGraphFrame;     // 0x0005A0 (0x000008)
        FVector                     TargetDirection;    // 0x0005A8 (0x000018)
        FScalableFloat              HF_SlamVelocity;    // 0x0005C0 (0x000028)
        FRuntimeFloatCurve          GravityCurve;       // 0x0005E8 (0x000048)
    
    public: // Functions
        void    AdjustRootMotionVelocity(FMMERuntimeContext& RuntimeContext, FVector& InOutVelocity, UFortMovementMode_GuidedMotionRuntimeData* CallFunc_GetRuntimeDataFromContext_ReturnValue, bool CallFunc_IsValid_ReturnValue, float CallFunc_GetValueAtLevel_ReturnValue, FVector CallFunc_Conv_DoubleToVector_ReturnValue, float CallFunc_GetRuntimeFloatCurveValue_ReturnValue, FVector CallFunc_Conv_DoubleToVector_ReturnValue_1, FVector CallFunc_Multiply_VectorVector_ReturnValue, FVector CallFunc_Multiply_VectorVector_ReturnValue_1, FVector CallFunc_Add_VectorVector_ReturnValue, FVector CallFunc_Normal_ReturnValue, FVector CallFunc_Multiply_VectorVector_ReturnValue_2, double CallFunc_Conv_DoubleToVector_InDouble_ImplicitCast, double CallFunc_Conv_DoubleToVector_InDouble_ImplicitCast_1); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintCallable | BlueprintEvent]
        void    BP_OnExtensionActivate(FMMERuntimeContext& RuntimeContext); // 0x000545D2 [Event | Public | HasOutParms | BlueprintEvent]
        void    BP_OnExtensionDeactivate(FMMERuntimeContext& RuntimeContext); // 0x000545D2 [Event | Public | HasOutParms | BlueprintEvent]
        void    ExecuteUbergraph_FMM_GuidedMotion_BeastGirl_StormSlam_Down(int32 EntryPoint, FRotator CallFunc_GetNetSyncedBaseAimRotation_ReturnValue, FMMERuntimeContext K2Node_Event_RuntimeContext_1, FVector CallFunc_GetForwardVector_ReturnValue, FMMERuntimeContext K2Node_Event_RuntimeContext); // 0x000545D2 [Final | UbergraphFunction | HasDefaults]
        FVector GetDirection_ConstantForce(UFortMovementMode_GuidedMotionRuntimeData* GuidedMotionRuntimeData, float CallFunc_GetRuntimeFloatCurveValue_ReturnValue, FVector CallFunc_Conv_DoubleToVector_ReturnValue, FVector CallFunc_Multiply_VectorVector_ReturnValue, FVector CallFunc_Multiply_VectorVector_ReturnValue_1, FVector CallFunc_Add_VectorVector_ReturnValue, FVector CallFunc_Normal_ReturnValue, double CallFunc_Conv_DoubleToVector_InDouble_ImplicitCast); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintCallable | BlueprintEvent | Const]
        float   GetStrength_ConstantForce(UFortMovementMode_GuidedMotionRuntimeData* GuidedMotionRuntimeData, float CallFunc_GetValueAtLevel_ReturnValue); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintCallable | BlueprintEvent | Const]
    };
}

