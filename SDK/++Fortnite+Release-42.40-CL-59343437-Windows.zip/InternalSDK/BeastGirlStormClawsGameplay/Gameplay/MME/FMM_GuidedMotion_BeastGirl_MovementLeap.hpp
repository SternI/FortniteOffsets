/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/FMM_GuidedMotion_BeastGirl_MovementLeap
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0006F0 (0x000050)
    class alignas(0x8) UFMM_GuidedMotion_BeastGirl_MovementLeap_C : public UFMM_GuidedMotion_BeastGirl_Leap_Impulse_C
    {
    public:
        FScalableFloat  HF_TacSprintLeapMult;   // 0x0006A0 (0x000028)
        FScalableFloat  HF_ForwardLeapMult;     // 0x0006C8 (0x000028)
    
    public: // Functions
        void    CalculateLeap(UFortMovementMode_GuidedMotionRuntimeData* RuntimeData, FVector& StartPos, FVector& EndPos, double& Arc, FVector CallFunc_GetSyncronizedMovementInput_MovementInput, float CallFunc_GetValueAtLevel_ReturnValue, double CallFunc_VSize_ReturnValue, bool CallFunc_Greater_DoubleDouble_ReturnValue, float CallFunc_GetValueAtLevel_ReturnValue_1, TScriptInterface<IGameplayTagAssetInterface> CallFunc_Conv_ObjectToGameplayTagAssetInterface_ReturnValue, FVector CallFunc_K2_GetActorLocation_ReturnValue, bool CallFunc_HasMatchingGameplayTag_ReturnValue, FVector CallFunc_GetActorForwardVector_ReturnValue, double CallFunc_SelectFloat_ReturnValue, FVector CallFunc_SelectVector_ReturnValue, FVector CallFunc_Conv_DoubleToVector_ReturnValue, double CallFunc_SelectFloat_ReturnValue_1, FVector CallFunc_Multiply_VectorVector_ReturnValue, FVector CallFunc_Add_VectorVector_ReturnValue, FVector CallFunc_Add_VectorVector_ReturnValue_1, double CallFunc_SelectFloat_B_ImplicitCast, double CallFunc_SelectFloat_A_ImplicitCast); // 0x000545D2 [Public | HasOutParms | BlueprintCallable | BlueprintEvent | BlueprintPure | Const]
        FVector GetLaunchVelocity(UFortMovementMode_GuidedMotionRuntimeData* Runtime_Data, FVector CallFunc_Conv_DoubleToVector_ReturnValue, FVector CallFunc_CalculateLeap_StartPos, FVector CallFunc_CalculateLeap_EndPos, double CallFunc_CalculateLeap_Arc, FVector CallFunc_SuggestProjectileVelocity_CustomArc_OutLaunchVelocity, bool CallFunc_SuggestProjectileVelocity_CustomArc_ReturnValue, FVector CallFunc_Divide_VectorVector_ReturnValue, FVector CallFunc_Add_VectorVector_ReturnValue, float CallFunc_SuggestProjectileVelocity_CustomArc_ArcParam_ImplicitCast); // 0x000545D2 [Public | HasOutParms | BlueprintCallable | BlueprintEvent | BlueprintPure | Const]
        void    GetSyncronizedMovementInput(UFortMovementMode_GuidedMotionRuntimeData* RuntimeData, FVector& MovementInput, int32 CallFunc_Array_Length_ReturnValue, bool CallFunc_GreaterEqual_IntInt_ReturnValue, FVector CallFunc_MakeVector_ReturnValue, double CallFunc_MakeVector_Z_ImplicitCast, double CallFunc_MakeVector_Y_ImplicitCast, double CallFunc_MakeVector_X_ImplicitCast); // 0x000545D2 [Public | HasOutParms | BlueprintCallable | BlueprintEvent | BlueprintPure | Const]
    };
}

