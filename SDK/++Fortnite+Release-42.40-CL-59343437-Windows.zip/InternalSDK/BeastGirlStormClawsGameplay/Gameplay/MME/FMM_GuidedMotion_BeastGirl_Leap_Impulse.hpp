/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/FMM_GuidedMotion_BeastGirl_Leap_Impulse
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0006A0 (0x000000)
    class UFMM_GuidedMotion_BeastGirl_Leap_Impulse_C : public UFMM_GuidedMotion_Leap_C
    {
    public:
    };
}

