/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/FMM_BeastGirl_TacSprint_MME_Functions
 * ============================================================
 */

#include "FMM_BeastGirl_TacSprint_MME_Functions.hpp"

namespace UE
{

    bool UFMM_BeastGirl_TacSprint_MME_C::CanApplyHolster(FName& HolsterId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("FMM_BeastGirl_TacSprint_MME.FMM_BeastGirl_TacSprint_MME_C.CanApplyHolster");
    
        UFMM_BeastGirl_TacSprint_MME_C___CanApplyHolster_Params Params{};
        Params.HolsterId = HolsterId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        HolsterId = Params.HolsterId;
    
        return Params.ReturnValue;
    }

} // namespace UE

