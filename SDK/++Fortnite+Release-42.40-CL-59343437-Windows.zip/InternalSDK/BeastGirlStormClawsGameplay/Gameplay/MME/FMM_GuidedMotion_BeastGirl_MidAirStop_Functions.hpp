/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/FMM_GuidedMotion_BeastGirl_MidAirStop_Functions
 * ============================================================
 */

#include "FMM_GuidedMotion_BeastGirl_MidAirStop.hpp"

namespace UE
{

    struct UFMM_GuidedMotion_BeastGirl_MidAirStop_C___BP_OnExtensionActivate_Params
    {
        FMMERuntimeContext  RuntimeContext; // 0x000000 (0x000010) [OutParam]
    };

    struct UFMM_GuidedMotion_BeastGirl_MidAirStop_C___ExecuteUbergraph_FMM_GuidedMotion_BeastGirl_MidAirStop_Params
    {
        int32               EntryPoint;                                 // 0x000000 (0x000004) [Default: 336014496]
        uint8               UnknownData_000004[0x000004];               // 0x000004 (0x000004)
        FVector             CallFunc_Conv_DoubleToVector_ReturnValue;   // 0x000008 (0x000018)
        FMMERuntimeContext  K2Node_Event_RuntimeContext;                // 0x000020 (0x000010)
        FVector             CallFunc_GetActorForwardVector_ReturnValue; // 0x000030 (0x000018)
        FVector             CallFunc_GetActorRightVector_ReturnValue;   // 0x000048 (0x000018)
        FVector             CallFunc_GetVelocity_ReturnValue;           // 0x000060 (0x000018)
        FVector             CallFunc_RotateAngleAxis_ReturnValue;       // 0x000078 (0x000018)
        bool                CallFunc_IsValid_ReturnValue;               // 0x000090 (0x000001) [Default: true]
        uint8               UnknownData_000091[0x000007];               // 0x000091 (0x000007)
        FVector             CallFunc_Multiply_VectorVector_ReturnValue; // 0x000098 (0x000018)
        FVector             CallFunc_Add_VectorVector_ReturnValue;      // 0x0000B0 (0x000018)
        FVector             CallFunc_ClampVectorSize_ReturnValue;       // 0x0000C8 (0x000018)
    };

    struct UFMM_GuidedMotion_BeastGirl_MidAirStop_C___GetDirection_ConstantForce_Params
    {
        UFortMovementMode_GuidedMotionRuntimeData*  GuidedMotionRuntimeData;                // 0x000000 (0x000008) [Default: 0x14072CA0]
        FVector                                     ReturnValue;                            // 0x000008 (0x000018) [ReturnValue]
        FVector                                     CallFunc_ClampVectorSize_ReturnValue;   // 0x000020 (0x000018)
    };

    struct UFMM_GuidedMotion_BeastGirl_MidAirStop_C___GetStrength_ConstantForce_Params
    {
        UFortMovementMode_GuidedMotionRuntimeData*  GuidedMotionRuntimeData;                        // 0x000000 (0x000008) [Default: 0x14072CA0]
        float                                       ReturnValue;                                    // 0x000008 (0x000004) [ReturnValue] [Default: 3.67349e-39f]
        float                                       CallFunc_GetStrength_ConstantForce_ReturnValue; // 0x00000C (0x000004) [Default: 182.074f]
    };

} // namespace UE

