/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/MME_Leap_Impulse_Functions
 * ============================================================
 */

#include "MME_Leap_Impulse.hpp"

namespace UE
{

    struct UMME_Leap_Impulse_C___BP_OnExtensionPush_Params
    {
        FMMERuntimeContext  RuntimeContext; // 0x000000 (0x000010) [OutParam]
    };

    struct UMME_Leap_Impulse_C___BP_UpdateBeforeCharacterMovement_Params
    {
        float                               ElapsedTime;    // 0x000000 (0x000004) [Default: 6.82674e-27f]
        float                               DeltaTime;      // 0x000004 (0x000004) [Default: 0f]
        EFortMovementModeExt_UpdateResult   ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: EFortMovementModeExt_UpdateResult(49)]
    };

    struct UMME_Leap_Impulse_C___ExecuteUbergraph_MME_Leap_Impulse_Params
    {
        int32               EntryPoint;                     // 0x000000 (0x000004) [Default: 336017328]
        FMMERuntimeContext  K2Node_Event_RuntimeContext;    // 0x000004 (0x000010)
    };

} // namespace UE

