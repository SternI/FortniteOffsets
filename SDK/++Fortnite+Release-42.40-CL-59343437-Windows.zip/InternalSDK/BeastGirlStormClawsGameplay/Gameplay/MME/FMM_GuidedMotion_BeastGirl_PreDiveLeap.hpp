/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/FMM_GuidedMotion_BeastGirl_PreDiveLeap
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0006A0 (0x000000)
    class UFMM_GuidedMotion_BeastGirl_PreDiveLeap_C : public UFMM_GuidedMotion_BeastGirl_Leap_Impulse_C
    {
    public:
    
    public: // Functions
        FVector GetLaunchVelocity(UFortMovementMode_GuidedMotionRuntimeData* Runtime_Data, FVector CallFunc_SelectVector_ReturnValue, double CallFunc_BreakVector_X, double CallFunc_BreakVector_Y, double CallFunc_BreakVector_Z, int32 CallFunc_Array_Length_ReturnValue, double CallFunc_FClamp_ReturnValue, bool CallFunc_GreaterEqual_IntInt_ReturnValue, FVector CallFunc_MakeVector_ReturnValue, FVector CallFunc_Add_VectorVector_ReturnValue); // 0x000545D2 [Public | HasOutParms | BlueprintCallable | BlueprintEvent | BlueprintPure | Const]
    };
}

