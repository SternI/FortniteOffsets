/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/MME_Leap_Impulse
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0001E1 (0x000010)
    class alignas(0x8) UMME_Leap_Impulse_C : public UMME_Leap_C
    {
    public:
        uint8                       UnknownData_0001D1[0x000007];   // 0x0001D1 (0x000007)
        FPointerToUberGraphFrame    UberGraphFrame;                 // 0x0001D8 (0x000008)
        bool                        AppliedImpulse;                 // 0x0001E0 (0x000001) [Default: false]
    
    public: // Functions
        void                                BP_OnExtensionPush(FMMERuntimeContext& RuntimeContext); // 0x000545D2 [Event | Public | HasOutParms | BlueprintEvent]
        EFortMovementModeExt_UpdateResult   BP_UpdateBeforeCharacterMovement(float ElapsedTime, float DeltaTime); // 0x000545D2 [Event | Public | HasOutParms | BlueprintCallable | BlueprintEvent]
        void                                ExecuteUbergraph_MME_Leap_Impulse(int32 EntryPoint, FMMERuntimeContext K2Node_Event_RuntimeContext); // 0x000545D2 [Final | UbergraphFunction | HasDefaults]
    };
}

