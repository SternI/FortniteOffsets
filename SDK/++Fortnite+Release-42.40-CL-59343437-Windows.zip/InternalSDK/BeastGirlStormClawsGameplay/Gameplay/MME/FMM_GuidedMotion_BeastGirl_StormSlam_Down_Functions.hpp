/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/FMM_GuidedMotion_BeastGirl_StormSlam_Down_Functions
 * ============================================================
 */

#include "FMM_GuidedMotion_BeastGirl_StormSlam_Down.hpp"

namespace UE
{

    struct UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C___AdjustRootMotionVelocity_Params
    {
        FMMERuntimeContext                          RuntimeContext;                                         // 0x000000 (0x000010) [OutParam]
        FVector                                     InOutVelocity;                                          // 0x000010 (0x000018) [OutParam]
        UFortMovementMode_GuidedMotionRuntimeData*  CallFunc_GetRuntimeDataFromContext_ReturnValue;         // 0x000028 (0x000008) [Default: nullptr]
        bool                                        CallFunc_IsValid_ReturnValue;                           // 0x000030 (0x000001) [Default: false]
        uint8                                       UnknownData_000031[0x000003];                           // 0x000031 (0x000003)
        float                                       CallFunc_GetValueAtLevel_ReturnValue;                   // 0x000034 (0x000004) [Default: 0f]
        FVector                                     CallFunc_Conv_DoubleToVector_ReturnValue;               // 0x000038 (0x000018)
        float                                       CallFunc_GetRuntimeFloatCurveValue_ReturnValue;         // 0x000050 (0x000004) [Default: 0f]
        uint8                                       UnknownData_000054[0x000004];                           // 0x000054 (0x000004)
        FVector                                     CallFunc_Conv_DoubleToVector_ReturnValue_1;             // 0x000058 (0x000018)
        FVector                                     CallFunc_Multiply_VectorVector_ReturnValue;             // 0x000070 (0x000018)
        FVector                                     CallFunc_Multiply_VectorVector_ReturnValue_1;           // 0x000088 (0x000018)
        FVector                                     CallFunc_Add_VectorVector_ReturnValue;                  // 0x0000A0 (0x000018)
        FVector                                     CallFunc_Normal_ReturnValue;                            // 0x0000B8 (0x000018)
        FVector                                     CallFunc_Multiply_VectorVector_ReturnValue_2;           // 0x0000D0 (0x000018)
        double                                      CallFunc_Conv_DoubleToVector_InDouble_ImplicitCast;     // 0x0000E8 (0x000008) [Default: 6.94844e-310]
        double                                      CallFunc_Conv_DoubleToVector_InDouble_ImplicitCast_1;   // 0x0000F0 (0x000008) [Default: 1.6976e-313]
    };

    struct UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C___BP_OnExtensionActivate_Params
    {
        FMMERuntimeContext  RuntimeContext; // 0x000000 (0x000010) [OutParam]
    };

    struct UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C___BP_OnExtensionDeactivate_Params
    {
        FMMERuntimeContext  RuntimeContext; // 0x000000 (0x000010) [OutParam]
    };

    struct UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C___ExecuteUbergraph_FMM_GuidedMotion_BeastGirl_StormSlam_Down_Params
    {
        int32               EntryPoint;                                         // 0x000000 (0x000004) [Default: 336014496]
        uint8               UnknownData_000004[0x000004];                       // 0x000004 (0x000004)
        FRotator            CallFunc_GetNetSyncedBaseAimRotation_ReturnValue;   // 0x000008 (0x000018)
        FMMERuntimeContext  K2Node_Event_RuntimeContext_1;                      // 0x000020 (0x000010)
        FVector             CallFunc_GetForwardVector_ReturnValue;              // 0x000030 (0x000018)
        FMMERuntimeContext  K2Node_Event_RuntimeContext;                        // 0x000048 (0x000010)
    };

    struct UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C___GetDirection_ConstantForce_Params
    {
        UFortMovementMode_GuidedMotionRuntimeData*  GuidedMotionRuntimeData;                            // 0x000000 (0x000008) [Default: 0x14072CA0]
        FVector                                     ReturnValue;                                        // 0x000008 (0x000018) [ReturnValue]
        float                                       CallFunc_GetRuntimeFloatCurveValue_ReturnValue;     // 0x000020 (0x000004) [Default: 5.40182e+10f]
        uint8                                       UnknownData_000024[0x000004];                       // 0x000024 (0x000004)
        FVector                                     CallFunc_Conv_DoubleToVector_ReturnValue;           // 0x000028 (0x000018)
        FVector                                     CallFunc_Multiply_VectorVector_ReturnValue;         // 0x000040 (0x000018)
        FVector                                     CallFunc_Multiply_VectorVector_ReturnValue_1;       // 0x000058 (0x000018)
        FVector                                     CallFunc_Add_VectorVector_ReturnValue;              // 0x000070 (0x000018)
        FVector                                     CallFunc_Normal_ReturnValue;                        // 0x000088 (0x000018)
        double                                      CallFunc_Conv_DoubleToVector_InDouble_ImplicitCast; // 0x0000A0 (0x000008) [Default: 0]
    };

    struct UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C___GetStrength_ConstantForce_Params
    {
        UFortMovementMode_GuidedMotionRuntimeData*  GuidedMotionRuntimeData;                // 0x000000 (0x000008) [Default: 0x14072CA0]
        float                                       ReturnValue;                            // 0x000008 (0x000004) [ReturnValue] [Default: 3.67349e-39f]
        float                                       CallFunc_GetValueAtLevel_ReturnValue;   // 0x00000C (0x000004) [Default: -1.06563e-08f]
    };

} // namespace UE

