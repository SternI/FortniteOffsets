/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/FMM_GuidedMotion_BeastGirl_MovementLeap_Functions
 * ============================================================
 */

#include "FMM_GuidedMotion_BeastGirl_MovementLeap_Functions.hpp"

namespace UE
{

    void UFMM_GuidedMotion_BeastGirl_MovementLeap_C::CalculateLeap(UFortMovementMode_GuidedMotionRuntimeData* RuntimeData, FVector& StartPos, FVector& EndPos, double& Arc, FVector CallFunc_GetSyncronizedMovementInput_MovementInput, float CallFunc_GetValueAtLevel_ReturnValue, double CallFunc_VSize_ReturnValue, bool CallFunc_Greater_DoubleDouble_ReturnValue, float CallFunc_GetValueAtLevel_ReturnValue_1, TScriptInterface<IGameplayTagAssetInterface> CallFunc_Conv_ObjectToGameplayTagAssetInterface_ReturnValue, FVector CallFunc_K2_GetActorLocation_ReturnValue, bool CallFunc_HasMatchingGameplayTag_ReturnValue, FVector CallFunc_GetActorForwardVector_ReturnValue, double CallFunc_SelectFloat_ReturnValue, FVector CallFunc_SelectVector_ReturnValue, FVector CallFunc_Conv_DoubleToVector_ReturnValue, double CallFunc_SelectFloat_ReturnValue_1, FVector CallFunc_Multiply_VectorVector_ReturnValue, FVector CallFunc_Add_VectorVector_ReturnValue, FVector CallFunc_Add_VectorVector_ReturnValue_1, double CallFunc_SelectFloat_B_ImplicitCast, double CallFunc_SelectFloat_A_ImplicitCast)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("FMM_GuidedMotion_BeastGirl_MovementLeap.FMM_GuidedMotion_BeastGirl_MovementLeap_C.CalculateLeap");
    
        UFMM_GuidedMotion_BeastGirl_MovementLeap_C___CalculateLeap_Params Params{};
        Params.RuntimeData = RuntimeData;
        Params.StartPos = StartPos;
        Params.EndPos = EndPos;
        Params.Arc = Arc;
        Params.CallFunc_GetSyncronizedMovementInput_MovementInput = CallFunc_GetSyncronizedMovementInput_MovementInput;
        Params.CallFunc_GetValueAtLevel_ReturnValue = CallFunc_GetValueAtLevel_ReturnValue;
        Params.CallFunc_VSize_ReturnValue = CallFunc_VSize_ReturnValue;
        Params.CallFunc_Greater_DoubleDouble_ReturnValue = CallFunc_Greater_DoubleDouble_ReturnValue;
        Params.CallFunc_GetValueAtLevel_ReturnValue_1 = CallFunc_GetValueAtLevel_ReturnValue_1;
        Params.CallFunc_Conv_ObjectToGameplayTagAssetInterface_ReturnValue = CallFunc_Conv_ObjectToGameplayTagAssetInterface_ReturnValue;
        Params.CallFunc_K2_GetActorLocation_ReturnValue = CallFunc_K2_GetActorLocation_ReturnValue;
        Params.CallFunc_HasMatchingGameplayTag_ReturnValue = CallFunc_HasMatchingGameplayTag_ReturnValue;
        Params.CallFunc_GetActorForwardVector_ReturnValue = CallFunc_GetActorForwardVector_ReturnValue;
        Params.CallFunc_SelectFloat_ReturnValue = CallFunc_SelectFloat_ReturnValue;
        Params.CallFunc_SelectVector_ReturnValue = CallFunc_SelectVector_ReturnValue;
        Params.CallFunc_Conv_DoubleToVector_ReturnValue = CallFunc_Conv_DoubleToVector_ReturnValue;
        Params.CallFunc_SelectFloat_ReturnValue_1 = CallFunc_SelectFloat_ReturnValue_1;
        Params.CallFunc_Multiply_VectorVector_ReturnValue = CallFunc_Multiply_VectorVector_ReturnValue;
        Params.CallFunc_Add_VectorVector_ReturnValue = CallFunc_Add_VectorVector_ReturnValue;
        Params.CallFunc_Add_VectorVector_ReturnValue_1 = CallFunc_Add_VectorVector_ReturnValue_1;
        Params.CallFunc_SelectFloat_B_ImplicitCast = CallFunc_SelectFloat_B_ImplicitCast;
        Params.CallFunc_SelectFloat_A_ImplicitCast = CallFunc_SelectFloat_A_ImplicitCast;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        StartPos = Params.StartPos;
        EndPos = Params.EndPos;
        Arc = Params.Arc;
    }

    FVector UFMM_GuidedMotion_BeastGirl_MovementLeap_C::GetLaunchVelocity(UFortMovementMode_GuidedMotionRuntimeData* Runtime_Data, FVector CallFunc_Conv_DoubleToVector_ReturnValue, FVector CallFunc_CalculateLeap_StartPos, FVector CallFunc_CalculateLeap_EndPos, double CallFunc_CalculateLeap_Arc, FVector CallFunc_SuggestProjectileVelocity_CustomArc_OutLaunchVelocity, bool CallFunc_SuggestProjectileVelocity_CustomArc_ReturnValue, FVector CallFunc_Divide_VectorVector_ReturnValue, FVector CallFunc_Add_VectorVector_ReturnValue, float CallFunc_SuggestProjectileVelocity_CustomArc_ArcParam_ImplicitCast)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("FMM_GuidedMotion_BeastGirl_MovementLeap.FMM_GuidedMotion_BeastGirl_MovementLeap_C.GetLaunchVelocity");
    
        UFMM_GuidedMotion_BeastGirl_MovementLeap_C___GetLaunchVelocity_Params Params{};
        Params.Runtime_Data = Runtime_Data;
        Params.CallFunc_Conv_DoubleToVector_ReturnValue = CallFunc_Conv_DoubleToVector_ReturnValue;
        Params.CallFunc_CalculateLeap_StartPos = CallFunc_CalculateLeap_StartPos;
        Params.CallFunc_CalculateLeap_EndPos = CallFunc_CalculateLeap_EndPos;
        Params.CallFunc_CalculateLeap_Arc = CallFunc_CalculateLeap_Arc;
        Params.CallFunc_SuggestProjectileVelocity_CustomArc_OutLaunchVelocity = CallFunc_SuggestProjectileVelocity_CustomArc_OutLaunchVelocity;
        Params.CallFunc_SuggestProjectileVelocity_CustomArc_ReturnValue = CallFunc_SuggestProjectileVelocity_CustomArc_ReturnValue;
        Params.CallFunc_Divide_VectorVector_ReturnValue = CallFunc_Divide_VectorVector_ReturnValue;
        Params.CallFunc_Add_VectorVector_ReturnValue = CallFunc_Add_VectorVector_ReturnValue;
        Params.CallFunc_SuggestProjectileVelocity_CustomArc_ArcParam_ImplicitCast = CallFunc_SuggestProjectileVelocity_CustomArc_ArcParam_ImplicitCast;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFMM_GuidedMotion_BeastGirl_MovementLeap_C::GetSyncronizedMovementInput(UFortMovementMode_GuidedMotionRuntimeData* RuntimeData, FVector& MovementInput, int32 CallFunc_Array_Length_ReturnValue, bool CallFunc_GreaterEqual_IntInt_ReturnValue, FVector CallFunc_MakeVector_ReturnValue, double CallFunc_MakeVector_Z_ImplicitCast, double CallFunc_MakeVector_Y_ImplicitCast, double CallFunc_MakeVector_X_ImplicitCast)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("FMM_GuidedMotion_BeastGirl_MovementLeap.FMM_GuidedMotion_BeastGirl_MovementLeap_C.GetSyncronizedMovementInput");
    
        UFMM_GuidedMotion_BeastGirl_MovementLeap_C___GetSyncronizedMovementInput_Params Params{};
        Params.RuntimeData = RuntimeData;
        Params.MovementInput = MovementInput;
        Params.CallFunc_Array_Length_ReturnValue = CallFunc_Array_Length_ReturnValue;
        Params.CallFunc_GreaterEqual_IntInt_ReturnValue = CallFunc_GreaterEqual_IntInt_ReturnValue;
        Params.CallFunc_MakeVector_ReturnValue = CallFunc_MakeVector_ReturnValue;
        Params.CallFunc_MakeVector_Z_ImplicitCast = CallFunc_MakeVector_Z_ImplicitCast;
        Params.CallFunc_MakeVector_Y_ImplicitCast = CallFunc_MakeVector_Y_ImplicitCast;
        Params.CallFunc_MakeVector_X_ImplicitCast = CallFunc_MakeVector_X_ImplicitCast;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        MovementInput = Params.MovementInput;
    }

} // namespace UE

