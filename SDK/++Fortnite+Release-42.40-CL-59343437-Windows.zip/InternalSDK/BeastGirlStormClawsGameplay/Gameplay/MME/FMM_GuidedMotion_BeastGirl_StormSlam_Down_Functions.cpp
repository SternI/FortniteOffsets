/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/FMM_GuidedMotion_BeastGirl_StormSlam_Down_Functions
 * ============================================================
 */

#include "FMM_GuidedMotion_BeastGirl_StormSlam_Down_Functions.hpp"

namespace UE
{

    void UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C::AdjustRootMotionVelocity(FMMERuntimeContext& RuntimeContext, FVector& InOutVelocity, UFortMovementMode_GuidedMotionRuntimeData* CallFunc_GetRuntimeDataFromContext_ReturnValue, bool CallFunc_IsValid_ReturnValue, float CallFunc_GetValueAtLevel_ReturnValue, FVector CallFunc_Conv_DoubleToVector_ReturnValue, float CallFunc_GetRuntimeFloatCurveValue_ReturnValue, FVector CallFunc_Conv_DoubleToVector_ReturnValue_1, FVector CallFunc_Multiply_VectorVector_ReturnValue, FVector CallFunc_Multiply_VectorVector_ReturnValue_1, FVector CallFunc_Add_VectorVector_ReturnValue, FVector CallFunc_Normal_ReturnValue, FVector CallFunc_Multiply_VectorVector_ReturnValue_2, double CallFunc_Conv_DoubleToVector_InDouble_ImplicitCast, double CallFunc_Conv_DoubleToVector_InDouble_ImplicitCast_1)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("FMM_GuidedMotion_BeastGirl_StormSlam_Down.FMM_GuidedMotion_BeastGirl_StormSlam_Down_C.AdjustRootMotionVelocity");
    
        UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C___AdjustRootMotionVelocity_Params Params{};
        Params.RuntimeContext = RuntimeContext;
        Params.InOutVelocity = InOutVelocity;
        Params.CallFunc_GetRuntimeDataFromContext_ReturnValue = CallFunc_GetRuntimeDataFromContext_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_GetValueAtLevel_ReturnValue = CallFunc_GetValueAtLevel_ReturnValue;
        Params.CallFunc_Conv_DoubleToVector_ReturnValue = CallFunc_Conv_DoubleToVector_ReturnValue;
        Params.CallFunc_GetRuntimeFloatCurveValue_ReturnValue = CallFunc_GetRuntimeFloatCurveValue_ReturnValue;
        Params.CallFunc_Conv_DoubleToVector_ReturnValue_1 = CallFunc_Conv_DoubleToVector_ReturnValue_1;
        Params.CallFunc_Multiply_VectorVector_ReturnValue = CallFunc_Multiply_VectorVector_ReturnValue;
        Params.CallFunc_Multiply_VectorVector_ReturnValue_1 = CallFunc_Multiply_VectorVector_ReturnValue_1;
        Params.CallFunc_Add_VectorVector_ReturnValue = CallFunc_Add_VectorVector_ReturnValue;
        Params.CallFunc_Normal_ReturnValue = CallFunc_Normal_ReturnValue;
        Params.CallFunc_Multiply_VectorVector_ReturnValue_2 = CallFunc_Multiply_VectorVector_ReturnValue_2;
        Params.CallFunc_Conv_DoubleToVector_InDouble_ImplicitCast = CallFunc_Conv_DoubleToVector_InDouble_ImplicitCast;
        Params.CallFunc_Conv_DoubleToVector_InDouble_ImplicitCast_1 = CallFunc_Conv_DoubleToVector_InDouble_ImplicitCast_1;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        RuntimeContext = Params.RuntimeContext;
        InOutVelocity = Params.InOutVelocity;
    }

    void UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C::BP_OnExtensionActivate(FMMERuntimeContext& RuntimeContext)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("FMM_GuidedMotion_BeastGirl_StormSlam_Down.FMM_GuidedMotion_BeastGirl_StormSlam_Down_C.BP_OnExtensionActivate");
    
        UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C___BP_OnExtensionActivate_Params Params{};
        Params.RuntimeContext = RuntimeContext;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        RuntimeContext = Params.RuntimeContext;
    }

    void UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C::BP_OnExtensionDeactivate(FMMERuntimeContext& RuntimeContext)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("FMM_GuidedMotion_BeastGirl_StormSlam_Down.FMM_GuidedMotion_BeastGirl_StormSlam_Down_C.BP_OnExtensionDeactivate");
    
        UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C___BP_OnExtensionDeactivate_Params Params{};
        Params.RuntimeContext = RuntimeContext;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        RuntimeContext = Params.RuntimeContext;
    }

    void UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C::ExecuteUbergraph_FMM_GuidedMotion_BeastGirl_StormSlam_Down(int32 EntryPoint, FRotator CallFunc_GetNetSyncedBaseAimRotation_ReturnValue, FMMERuntimeContext K2Node_Event_RuntimeContext_1, FVector CallFunc_GetForwardVector_ReturnValue, FMMERuntimeContext K2Node_Event_RuntimeContext)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("FMM_GuidedMotion_BeastGirl_StormSlam_Down.FMM_GuidedMotion_BeastGirl_StormSlam_Down_C.ExecuteUbergraph_FMM_GuidedMotion_BeastGirl_StormSlam_Down");
    
        UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C___ExecuteUbergraph_FMM_GuidedMotion_BeastGirl_StormSlam_Down_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.CallFunc_GetNetSyncedBaseAimRotation_ReturnValue = CallFunc_GetNetSyncedBaseAimRotation_ReturnValue;
        Params.K2Node_Event_RuntimeContext_1 = K2Node_Event_RuntimeContext_1;
        Params.CallFunc_GetForwardVector_ReturnValue = CallFunc_GetForwardVector_ReturnValue;
        Params.K2Node_Event_RuntimeContext = K2Node_Event_RuntimeContext;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    FVector UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C::GetDirection_ConstantForce(UFortMovementMode_GuidedMotionRuntimeData* GuidedMotionRuntimeData, float CallFunc_GetRuntimeFloatCurveValue_ReturnValue, FVector CallFunc_Conv_DoubleToVector_ReturnValue, FVector CallFunc_Multiply_VectorVector_ReturnValue, FVector CallFunc_Multiply_VectorVector_ReturnValue_1, FVector CallFunc_Add_VectorVector_ReturnValue, FVector CallFunc_Normal_ReturnValue, double CallFunc_Conv_DoubleToVector_InDouble_ImplicitCast)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("FMM_GuidedMotion_BeastGirl_StormSlam_Down.FMM_GuidedMotion_BeastGirl_StormSlam_Down_C.GetDirection_ConstantForce");
    
        UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C___GetDirection_ConstantForce_Params Params{};
        Params.GuidedMotionRuntimeData = GuidedMotionRuntimeData;
        Params.CallFunc_GetRuntimeFloatCurveValue_ReturnValue = CallFunc_GetRuntimeFloatCurveValue_ReturnValue;
        Params.CallFunc_Conv_DoubleToVector_ReturnValue = CallFunc_Conv_DoubleToVector_ReturnValue;
        Params.CallFunc_Multiply_VectorVector_ReturnValue = CallFunc_Multiply_VectorVector_ReturnValue;
        Params.CallFunc_Multiply_VectorVector_ReturnValue_1 = CallFunc_Multiply_VectorVector_ReturnValue_1;
        Params.CallFunc_Add_VectorVector_ReturnValue = CallFunc_Add_VectorVector_ReturnValue;
        Params.CallFunc_Normal_ReturnValue = CallFunc_Normal_ReturnValue;
        Params.CallFunc_Conv_DoubleToVector_InDouble_ImplicitCast = CallFunc_Conv_DoubleToVector_InDouble_ImplicitCast;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C::GetStrength_ConstantForce(UFortMovementMode_GuidedMotionRuntimeData* GuidedMotionRuntimeData, float CallFunc_GetValueAtLevel_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("FMM_GuidedMotion_BeastGirl_StormSlam_Down.FMM_GuidedMotion_BeastGirl_StormSlam_Down_C.GetStrength_ConstantForce");
    
        UFMM_GuidedMotion_BeastGirl_StormSlam_Down_C___GetStrength_ConstantForce_Params Params{};
        Params.GuidedMotionRuntimeData = GuidedMotionRuntimeData;
        Params.CallFunc_GetValueAtLevel_ReturnValue = CallFunc_GetValueAtLevel_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

} // namespace UE

