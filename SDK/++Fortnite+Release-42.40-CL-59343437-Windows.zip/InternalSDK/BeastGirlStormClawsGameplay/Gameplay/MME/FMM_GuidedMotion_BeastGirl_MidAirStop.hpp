/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/FMM_GuidedMotion_BeastGirl_MidAirStop
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0005D0 (0x000030)
    class alignas(0x8) UFMM_GuidedMotion_BeastGirl_MidAirStop_C : public UFortMovementMode_ExtGuidedMotion
    {
    public:
        FPointerToUberGraphFrame    UberGraphFrame; // 0x0005A0 (0x000008)
        FVector                     BaseVelocity;   // 0x0005A8 (0x000018)
        double                      MasSpeedForce;  // 0x0005C0 (0x000008) [Default: 2000]
        double                      InitialUpForce; // 0x0005C8 (0x000008) [Default: 1500]
    
    public: // Functions
        void    BP_OnExtensionActivate(FMMERuntimeContext& RuntimeContext); // 0x000545D2 [Event | Public | HasOutParms | BlueprintEvent]
        void    ExecuteUbergraph_FMM_GuidedMotion_BeastGirl_MidAirStop(int32 EntryPoint, FVector CallFunc_Conv_DoubleToVector_ReturnValue, FMMERuntimeContext K2Node_Event_RuntimeContext, FVector CallFunc_GetActorForwardVector_ReturnValue, FVector CallFunc_GetActorRightVector_ReturnValue, FVector CallFunc_GetVelocity_ReturnValue, FVector CallFunc_RotateAngleAxis_ReturnValue, bool CallFunc_IsValid_ReturnValue, FVector CallFunc_Multiply_VectorVector_ReturnValue, FVector CallFunc_Add_VectorVector_ReturnValue, FVector CallFunc_ClampVectorSize_ReturnValue); // 0x000545D2 [Final | UbergraphFunction | HasDefaults]
        FVector GetDirection_ConstantForce(UFortMovementMode_GuidedMotionRuntimeData* GuidedMotionRuntimeData, FVector CallFunc_ClampVectorSize_ReturnValue); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintCallable | BlueprintEvent | Const]
        float   GetStrength_ConstantForce(UFortMovementMode_GuidedMotionRuntimeData* GuidedMotionRuntimeData, float CallFunc_GetStrength_ConstantForce_ReturnValue); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintCallable | BlueprintEvent | Const]
    };
}

