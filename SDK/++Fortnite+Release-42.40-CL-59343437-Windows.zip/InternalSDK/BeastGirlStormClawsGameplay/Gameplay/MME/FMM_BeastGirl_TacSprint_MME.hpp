/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/FMM_BeastGirl_TacSprint_MME
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0005E8 (0x000000)
    class UFMM_BeastGirl_TacSprint_MME_C : public UFortMovementMode_ELTacSprint
    {
    public:
    
    public: // Functions
        bool    CanApplyHolster(FName& HolsterId); // 0x000545D2 [Event | Public | HasOutParms | BlueprintCallable | BlueprintEvent | Const]
    };
}

