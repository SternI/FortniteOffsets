/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/FMM_BeastGirl_TacSprint_MME_Functions
 * ============================================================
 */

#include "FMM_BeastGirl_TacSprint_MME.hpp"

namespace UE
{

    struct UFMM_BeastGirl_TacSprint_MME_C___CanApplyHolster_Params
    {
        FName   HolsterId;      // 0x000000 (0x000004) [OutParam] [Default: FName(344802848) -> L""]
        bool    ReturnValue;    // 0x000004 (0x000001) [ReturnValue] [Default: false]
    };

} // namespace UE

