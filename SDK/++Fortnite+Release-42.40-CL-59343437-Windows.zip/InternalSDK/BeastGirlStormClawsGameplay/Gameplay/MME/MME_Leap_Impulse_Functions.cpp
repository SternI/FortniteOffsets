/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/MME_Leap_Impulse_Functions
 * ============================================================
 */

#include "MME_Leap_Impulse_Functions.hpp"

namespace UE
{

    void UMME_Leap_Impulse_C::BP_OnExtensionPush(FMMERuntimeContext& RuntimeContext)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("MME_Leap_Impulse.MME_Leap_Impulse_C.BP_OnExtensionPush");
    
        UMME_Leap_Impulse_C___BP_OnExtensionPush_Params Params{};
        Params.RuntimeContext = RuntimeContext;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        RuntimeContext = Params.RuntimeContext;
    }

    EFortMovementModeExt_UpdateResult UMME_Leap_Impulse_C::BP_UpdateBeforeCharacterMovement(float ElapsedTime, float DeltaTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("MME_Leap_Impulse.MME_Leap_Impulse_C.BP_UpdateBeforeCharacterMovement");
    
        UMME_Leap_Impulse_C___BP_UpdateBeforeCharacterMovement_Params Params{};
        Params.ElapsedTime = ElapsedTime;
        Params.DeltaTime = DeltaTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UMME_Leap_Impulse_C::ExecuteUbergraph_MME_Leap_Impulse(int32 EntryPoint, FMMERuntimeContext K2Node_Event_RuntimeContext)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("MME_Leap_Impulse.MME_Leap_Impulse_C.ExecuteUbergraph_MME_Leap_Impulse");
    
        UMME_Leap_Impulse_C___ExecuteUbergraph_MME_Leap_Impulse_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.K2Node_Event_RuntimeContext = K2Node_Event_RuntimeContext;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

