/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/FMM_GuidedMotion_BeastGirl_PreDiveLeap_Functions
 * ============================================================
 */

#include "FMM_GuidedMotion_BeastGirl_PreDiveLeap.hpp"

namespace UE
{

    struct UFMM_GuidedMotion_BeastGirl_PreDiveLeap_C___GetLaunchVelocity_Params
    {
        UFortMovementMode_GuidedMotionRuntimeData*  Runtime_Data;                               // 0x000000 (0x000008) [Default: 0x14072CA0]
        FVector                                     ReturnValue;                                // 0x000008 (0x000018) [ReturnValue]
        FVector                                     CallFunc_SelectVector_ReturnValue;          // 0x000020 (0x000018)
        double                                      CallFunc_BreakVector_X;                     // 0x000038 (0x000008) [Default: 9.88131e-324]
        double                                      CallFunc_BreakVector_Y;                     // 0x000040 (0x000008) [Default: 0]
        double                                      CallFunc_BreakVector_Z;                     // 0x000048 (0x000008) [Default: 0]
        int32                                       CallFunc_Array_Length_ReturnValue;          // 0x000050 (0x000004) [Default: 0]
        uint8                                       UnknownData_000054[0x000004];               // 0x000054 (0x000004)
        double                                      CallFunc_FClamp_ReturnValue;                // 0x000058 (0x000008) [Default: 0]
        bool                                        CallFunc_GreaterEqual_IntInt_ReturnValue;   // 0x000060 (0x000001) [Default: false]
        uint8                                       UnknownData_000061[0x000007];               // 0x000061 (0x000007)
        FVector                                     CallFunc_MakeVector_ReturnValue;            // 0x000068 (0x000018)
        FVector                                     CallFunc_Add_VectorVector_ReturnValue;      // 0x000080 (0x000018)
    };

} // namespace UE

