/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/FMM_GuidedMotion_BeastGirl_MovementLeap_Functions
 * ============================================================
 */

#include "FMM_GuidedMotion_BeastGirl_MovementLeap.hpp"

namespace UE
{

    struct UFMM_GuidedMotion_BeastGirl_MovementLeap_C___CalculateLeap_Params
    {
        UFortMovementMode_GuidedMotionRuntimeData*      RuntimeData;                                                    // 0x000000 (0x000008) [Default: 0x14072CA0]
        FVector                                         StartPos;                                                       // 0x000008 (0x000018) [OutParam]
        FVector                                         EndPos;                                                         // 0x000020 (0x000018) [OutParam]
        double                                          Arc;                                                            // 0x000038 (0x000008) [OutParam] [Default: 9.88131e-324]
        FVector                                         CallFunc_GetSyncronizedMovementInput_MovementInput;             // 0x000040 (0x000018)
        float                                           CallFunc_GetValueAtLevel_ReturnValue;                           // 0x000058 (0x000004) [Default: 0f]
        uint8                                           UnknownData_00005C[0x000004];                                   // 0x00005C (0x000004)
        double                                          CallFunc_VSize_ReturnValue;                                     // 0x000060 (0x000008) [Default: 0]
        bool                                            CallFunc_Greater_DoubleDouble_ReturnValue;                      // 0x000068 (0x000001) [Default: true]
        uint8                                           UnknownData_000069[0x000003];                                   // 0x000069 (0x000003)
        float                                           CallFunc_GetValueAtLevel_ReturnValue_1;                         // 0x00006C (0x000004) [Default: 4.58855e-41f]
        TScriptInterface<IGameplayTagAssetInterface>    CallFunc_Conv_ObjectToGameplayTagAssetInterface_ReturnValue;    // 0x000070 (0x000010)
        FVector                                         CallFunc_K2_GetActorLocation_ReturnValue;                       // 0x000080 (0x000018)
        bool                                            CallFunc_HasMatchingGameplayTag_ReturnValue;                    // 0x000098 (0x000001) [Default: true]
        uint8                                           UnknownData_000099[0x000007];                                   // 0x000099 (0x000007)
        FVector                                         CallFunc_GetActorForwardVector_ReturnValue;                     // 0x0000A0 (0x000018)
        double                                          CallFunc_SelectFloat_ReturnValue;                               // 0x0000B8 (0x000008) [Default: 0]
        FVector                                         CallFunc_SelectVector_ReturnValue;                              // 0x0000C0 (0x000018)
        FVector                                         CallFunc_Conv_DoubleToVector_ReturnValue;                       // 0x0000D8 (0x000018)
        double                                          CallFunc_SelectFloat_ReturnValue_1;                             // 0x0000F0 (0x000008) [Default: 1.6976e-313]
        FVector                                         CallFunc_Multiply_VectorVector_ReturnValue;                     // 0x0000F8 (0x000018)
        FVector                                         CallFunc_Add_VectorVector_ReturnValue;                          // 0x000110 (0x000018)
        FVector                                         CallFunc_Add_VectorVector_ReturnValue_1;                        // 0x000128 (0x000018)
        double                                          CallFunc_SelectFloat_B_ImplicitCast;                            // 0x000140 (0x000008) [Default: 0]
        double                                          CallFunc_SelectFloat_A_ImplicitCast;                            // 0x000148 (0x000008) [Default: 0]
    };

    struct UFMM_GuidedMotion_BeastGirl_MovementLeap_C___GetLaunchVelocity_Params
    {
        UFortMovementMode_GuidedMotionRuntimeData*  Runtime_Data;                                                       // 0x000000 (0x000008) [Default: 0x14072CA0]
        FVector                                     ReturnValue;                                                        // 0x000008 (0x000018) [ReturnValue]
        FVector                                     CallFunc_Conv_DoubleToVector_ReturnValue;                           // 0x000020 (0x000018)
        FVector                                     CallFunc_CalculateLeap_StartPos;                                    // 0x000038 (0x000018)
        FVector                                     CallFunc_CalculateLeap_EndPos;                                      // 0x000050 (0x000018)
        double                                      CallFunc_CalculateLeap_Arc;                                         // 0x000068 (0x000008) [Default: 6.9485e-310]
        FVector                                     CallFunc_SuggestProjectileVelocity_CustomArc_OutLaunchVelocity;     // 0x000070 (0x000018)
        bool                                        CallFunc_SuggestProjectileVelocity_CustomArc_ReturnValue;           // 0x000088 (0x000001) [Default: true]
        uint8                                       UnknownData_000089[0x000007];                                       // 0x000089 (0x000007)
        FVector                                     CallFunc_Divide_VectorVector_ReturnValue;                           // 0x000090 (0x000018)
        FVector                                     CallFunc_Add_VectorVector_ReturnValue;                              // 0x0000A8 (0x000018)
        float                                       CallFunc_SuggestProjectileVelocity_CustomArc_ArcParam_ImplicitCast; // 0x0000C0 (0x000004) [Default: 0f]
    };

    struct UFMM_GuidedMotion_BeastGirl_MovementLeap_C___GetSyncronizedMovementInput_Params
    {
        UFortMovementMode_GuidedMotionRuntimeData*  RuntimeData;                                // 0x000000 (0x000008) [Default: 0x14072CA0]
        FVector                                     MovementInput;                              // 0x000008 (0x000018) [OutParam]
        int32                                       CallFunc_Array_Length_ReturnValue;          // 0x000020 (0x000004) [Default: -1471267908]
        bool                                        CallFunc_GreaterEqual_IntInt_ReturnValue;   // 0x000024 (0x000001) [Default: false]
        uint8                                       UnknownData_000025[0x000003];               // 0x000025 (0x000003)
        FVector                                     CallFunc_MakeVector_ReturnValue;            // 0x000028 (0x000018)
        double                                      CallFunc_MakeVector_Z_ImplicitCast;         // 0x000040 (0x000008) [Default: 0]
        double                                      CallFunc_MakeVector_Y_ImplicitCast;         // 0x000048 (0x000008) [Default: 0]
        double                                      CallFunc_MakeVector_X_ImplicitCast;         // 0x000050 (0x000008) [Default: 0]
    };

} // namespace UE

