/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/FMM_GuidedMotion_BeastGirl_MidAirStop_Functions
 * ============================================================
 */

#include "FMM_GuidedMotion_BeastGirl_MidAirStop_Functions.hpp"

namespace UE
{

    void UFMM_GuidedMotion_BeastGirl_MidAirStop_C::BP_OnExtensionActivate(FMMERuntimeContext& RuntimeContext)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("FMM_GuidedMotion_BeastGirl_MidAirStop.FMM_GuidedMotion_BeastGirl_MidAirStop_C.BP_OnExtensionActivate");
    
        UFMM_GuidedMotion_BeastGirl_MidAirStop_C___BP_OnExtensionActivate_Params Params{};
        Params.RuntimeContext = RuntimeContext;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        RuntimeContext = Params.RuntimeContext;
    }

    void UFMM_GuidedMotion_BeastGirl_MidAirStop_C::ExecuteUbergraph_FMM_GuidedMotion_BeastGirl_MidAirStop(int32 EntryPoint, FVector CallFunc_Conv_DoubleToVector_ReturnValue, FMMERuntimeContext K2Node_Event_RuntimeContext, FVector CallFunc_GetActorForwardVector_ReturnValue, FVector CallFunc_GetActorRightVector_ReturnValue, FVector CallFunc_GetVelocity_ReturnValue, FVector CallFunc_RotateAngleAxis_ReturnValue, bool CallFunc_IsValid_ReturnValue, FVector CallFunc_Multiply_VectorVector_ReturnValue, FVector CallFunc_Add_VectorVector_ReturnValue, FVector CallFunc_ClampVectorSize_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("FMM_GuidedMotion_BeastGirl_MidAirStop.FMM_GuidedMotion_BeastGirl_MidAirStop_C.ExecuteUbergraph_FMM_GuidedMotion_BeastGirl_MidAirStop");
    
        UFMM_GuidedMotion_BeastGirl_MidAirStop_C___ExecuteUbergraph_FMM_GuidedMotion_BeastGirl_MidAirStop_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.CallFunc_Conv_DoubleToVector_ReturnValue = CallFunc_Conv_DoubleToVector_ReturnValue;
        Params.K2Node_Event_RuntimeContext = K2Node_Event_RuntimeContext;
        Params.CallFunc_GetActorForwardVector_ReturnValue = CallFunc_GetActorForwardVector_ReturnValue;
        Params.CallFunc_GetActorRightVector_ReturnValue = CallFunc_GetActorRightVector_ReturnValue;
        Params.CallFunc_GetVelocity_ReturnValue = CallFunc_GetVelocity_ReturnValue;
        Params.CallFunc_RotateAngleAxis_ReturnValue = CallFunc_RotateAngleAxis_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_Multiply_VectorVector_ReturnValue = CallFunc_Multiply_VectorVector_ReturnValue;
        Params.CallFunc_Add_VectorVector_ReturnValue = CallFunc_Add_VectorVector_ReturnValue;
        Params.CallFunc_ClampVectorSize_ReturnValue = CallFunc_ClampVectorSize_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    FVector UFMM_GuidedMotion_BeastGirl_MidAirStop_C::GetDirection_ConstantForce(UFortMovementMode_GuidedMotionRuntimeData* GuidedMotionRuntimeData, FVector CallFunc_ClampVectorSize_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("FMM_GuidedMotion_BeastGirl_MidAirStop.FMM_GuidedMotion_BeastGirl_MidAirStop_C.GetDirection_ConstantForce");
    
        UFMM_GuidedMotion_BeastGirl_MidAirStop_C___GetDirection_ConstantForce_Params Params{};
        Params.GuidedMotionRuntimeData = GuidedMotionRuntimeData;
        Params.CallFunc_ClampVectorSize_ReturnValue = CallFunc_ClampVectorSize_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UFMM_GuidedMotion_BeastGirl_MidAirStop_C::GetStrength_ConstantForce(UFortMovementMode_GuidedMotionRuntimeData* GuidedMotionRuntimeData, float CallFunc_GetStrength_ConstantForce_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("FMM_GuidedMotion_BeastGirl_MidAirStop.FMM_GuidedMotion_BeastGirl_MidAirStop_C.GetStrength_ConstantForce");
    
        UFMM_GuidedMotion_BeastGirl_MidAirStop_C___GetStrength_ConstantForce_Params Params{};
        Params.GuidedMotionRuntimeData = GuidedMotionRuntimeData;
        Params.CallFunc_GetStrength_ConstantForce_ReturnValue = CallFunc_GetStrength_ConstantForce_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

} // namespace UE

