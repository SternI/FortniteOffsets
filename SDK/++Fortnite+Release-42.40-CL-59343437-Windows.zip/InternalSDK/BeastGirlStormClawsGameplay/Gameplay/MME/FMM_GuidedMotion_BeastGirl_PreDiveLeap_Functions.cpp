/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeastGirlStormClawsGameplay/Gameplay/MME/FMM_GuidedMotion_BeastGirl_PreDiveLeap_Functions
 * ============================================================
 */

#include "FMM_GuidedMotion_BeastGirl_PreDiveLeap_Functions.hpp"

namespace UE
{

    FVector UFMM_GuidedMotion_BeastGirl_PreDiveLeap_C::GetLaunchVelocity(UFortMovementMode_GuidedMotionRuntimeData* Runtime_Data, FVector CallFunc_SelectVector_ReturnValue, double CallFunc_BreakVector_X, double CallFunc_BreakVector_Y, double CallFunc_BreakVector_Z, int32 CallFunc_Array_Length_ReturnValue, double CallFunc_FClamp_ReturnValue, bool CallFunc_GreaterEqual_IntInt_ReturnValue, FVector CallFunc_MakeVector_ReturnValue, FVector CallFunc_Add_VectorVector_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("FMM_GuidedMotion_BeastGirl_PreDiveLeap.FMM_GuidedMotion_BeastGirl_PreDiveLeap_C.GetLaunchVelocity");
    
        UFMM_GuidedMotion_BeastGirl_PreDiveLeap_C___GetLaunchVelocity_Params Params{};
        Params.Runtime_Data = Runtime_Data;
        Params.CallFunc_SelectVector_ReturnValue = CallFunc_SelectVector_ReturnValue;
        Params.CallFunc_BreakVector_X = CallFunc_BreakVector_X;
        Params.CallFunc_BreakVector_Y = CallFunc_BreakVector_Y;
        Params.CallFunc_BreakVector_Z = CallFunc_BreakVector_Z;
        Params.CallFunc_Array_Length_ReturnValue = CallFunc_Array_Length_ReturnValue;
        Params.CallFunc_FClamp_ReturnValue = CallFunc_FClamp_ReturnValue;
        Params.CallFunc_GreaterEqual_IntInt_ReturnValue = CallFunc_GreaterEqual_IntInt_ReturnValue;
        Params.CallFunc_MakeVector_ReturnValue = CallFunc_MakeVector_ReturnValue;
        Params.CallFunc_Add_VectorVector_ReturnValue = CallFunc_Add_VectorVector_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

} // namespace UE

