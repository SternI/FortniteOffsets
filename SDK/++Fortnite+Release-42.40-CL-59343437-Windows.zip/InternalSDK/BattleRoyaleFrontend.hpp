/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BattleRoyaleFrontend
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0002F8 (0x000008)
    class ABattleRoyaleFrontendDynamicUIDirector : public AFortDynamicUIDirector
    {
    public:
        uint8   UnknownData_0002F0[0x000008];   // 0x0002F0 (0x000008)
    };
    // Size: 0x000120 (0x0000F8)
    class alignas(0x8) UBattleRoyaleFrontendExperienceFlow : public UObject
    {
    public:
        void**                                              VTable_000028;                          // 0x000028 (0x000008) VTable [4 slots] -> 0x14737050
        uint8                                               UnknownData_000030[0x000020];           // 0x000030 (0x000020)
        TArray<FString>                                     DefaultFlowStepArray;                   // 0x000050 (0x000010)
        TArray<FString>                                     FirstTimeSeasonFlowStepArray;           // 0x000060 (0x000010)
        TMap<FString, FString>                              BRVideoRating;                          // 0x000070 (0x000010)
        TArray<FBattleRoyaleFrontendProductVideoOverride>   ProductVideoOverrides;                  // 0x000080 (0x000010)
        uint8                                               UnknownData_000090[0x000018];           // 0x000090 (0x000018)
        TSoftClassPtr<UClass>                               VideoPlayerClass;                       // 0x0000A8 (0x000020) [Default: nullptr]
        uint8                                               UnknownData_0000C8[0x000008];           // 0x0000C8 (0x000008)
        UClass*                                             HabaneroIntroModalClass;                // 0x0000D0 (0x000008) [Default: nullptr]
        TSoftClassPtr<UClass>                               FireModeSelectionReminderModalClass;    // 0x0000D8 (0x000020) [Default: nullptr]
        TSoftClassPtr<UClass>                               FireModeSelectionScreenClass;           // 0x0000F8 (0x000020) [Default: nullptr]
        UClass*                                             SimpleBuildAndEditModalHelper;          // 0x000118 (0x000008) [Default: nullptr]
    
    public: // Functions
        void    FinishTrailerStep(); // 0x10DC024C [Final | Native | Private]
        void    HandleBattlePassTrailerEnded(); // 0x10DC0262 [Final | Native | Private]
        void    HandleSeasonTrailerEnded(); // 0x10DC02D2 [Final | Native | Private]
        void    HandleVideoTerminalError(EBaseMediaTerminalErrorReason Reason); // 0x08048236 [Final | Native | Private]
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FBattleRoyaleFrontendProductVideoOverride
    {
        FGameplayTag    ProductTag;                     // 0x000000 (0x000004)
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FString         MediaID;                        // 0x000008 (0x000010)
        FName           MediaName;                      // 0x000018 (0x000004)
        uint8           UnknownData_00001C[0x000004];   // 0x00001C (0x000004)
    };
}

