/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AttachableWheelsRuntime_Functions
 * ============================================================
 */

#include "AttachableWheelsRuntime_Functions.hpp"

namespace UE
{

    bool AAttachableWheel::AttachInPlace(UPrimitiveComponent* InComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheel.AttachInPlace");
    
        AAttachableWheel___AttachInPlace_Params Params{};
        Params.InComponent = InComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool AAttachableWheel::AttachTo(UPrimitiveComponent* InComponent, FVector& WorldLocation, FVector& AxleDirection, FVector SteerAxis)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheel.AttachTo");
    
        AAttachableWheel___AttachTo_Params Params{};
        Params.InComponent = InComponent;
        Params.WorldLocation = WorldLocation;
        Params.AxleDirection = AxleDirection;
        Params.SteerAxis = SteerAxis;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        WorldLocation = Params.WorldLocation;
        AxleDirection = Params.AxleDirection;
    
        return Params.ReturnValue;
    }

    void AAttachableWheel::Detach()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheel.Detach");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    bool AAttachableWheel::DetachFrom(UPrimitiveComponent* InComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheel.DetachFrom");
    
        AAttachableWheel___DetachFrom_Params Params{};
        Params.InComponent = InComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void AAttachableWheel::DrawDebug()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheel.DrawDebug");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    FAttachableWheelAttachData AAttachableWheel::GetAttachData()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheel.GetAttachData");
    
        AAttachableWheel___GetAttachData_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UPrimitiveComponent* AAttachableWheel::GetAttachedComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheel.GetAttachedComponent");
    
        AAttachableWheel___GetAttachedComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool AAttachableWheel::GetWorldSpaceAttachData(FAttachableWheelAttachData& OutAttachData, UPrimitiveComponent* PrimitiveComponent, FName BodyName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheel.GetWorldSpaceAttachData");
    
        AAttachableWheel___GetWorldSpaceAttachData_Params Params{};
        Params.OutAttachData = OutAttachData;
        Params.PrimitiveComponent = PrimitiveComponent;
        Params.BodyName = BodyName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutAttachData = Params.OutAttachData;
    
        return Params.ReturnValue;
    }

    void AAttachableWheel::OnAttached(UPrimitiveComponent* AttachedComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheel.OnAttached");
    
        AAttachableWheel___OnAttached_Params Params{};
        Params.AttachedComponent = AttachedComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AAttachableWheel::OnDetached(UPrimitiveComponent* DetachedComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheel.OnDetached");
    
        AAttachableWheel___OnDetached_Params Params{};
        Params.DetachedComponent = DetachedComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AAttachableWheel::OnPhysicsStateChanged(UPrimitiveComponent* PrimitiveComponent, EComponentPhysicsStateChange StateChange)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheel.OnPhysicsStateChanged");
    
        AAttachableWheel___OnPhysicsStateChanged_Params Params{};
        Params.PrimitiveComponent = PrimitiveComponent;
        Params.StateChange = StateChange;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AAttachableWheel::OnRep_AttachData(FAttachableWheelAttachData& AttachDataPrev)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheel.OnRep_AttachData");
    
        AAttachableWheel___OnRep_AttachData_Params Params{};
        Params.AttachDataPrev = AttachDataPrev;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        AttachDataPrev = Params.AttachDataPrev;
    }

    void AAttachableWheel::OnRep_RuntimeData(FAttachableWheelRuntimeData& RuntimeDataPrev)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheel.OnRep_RuntimeData");
    
        AAttachableWheel___OnRep_RuntimeData_Params Params{};
        Params.RuntimeDataPrev = RuntimeDataPrev;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        RuntimeDataPrev = Params.RuntimeDataPrev;
    }

    void AAttachableWheel::SetRuntimeData(float Torque, float Velocity, float SteerAngle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheel.SetRuntimeData");
    
        AAttachableWheel___SetRuntimeData_Params Params{};
        Params.Torque = Torque;
        Params.Velocity = Velocity;
        Params.SteerAngle = SteerAngle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AAttachableWheel::SetRuntimeData_SteerAngle(float SteerAngle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheel.SetRuntimeData_SteerAngle");
    
        AAttachableWheel___SetRuntimeData_SteerAngle_Params Params{};
        Params.SteerAngle = SteerAngle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AAttachableWheel::SetRuntimeData_Torque(float Torque)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheel.SetRuntimeData_Torque");
    
        AAttachableWheel___SetRuntimeData_Torque_Params Params{};
        Params.Torque = Torque;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AAttachableWheel::SetRuntimeData_Velocity(float Velocity)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheel.SetRuntimeData_Velocity");
    
        AAttachableWheel___SetRuntimeData_Velocity_Params Params{};
        Params.Velocity = Velocity;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    int32 UAttachableWheelsComponent::DetachAllWheels()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheelsComponent.DetachAllWheels");
    
        UAttachableWheelsComponent___DetachAllWheels_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAttachableWheelsComponent::DrawDebug()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheelsComponent.DrawDebug");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    AAttachableWheel* UAttachableWheelsComponent::GetAttachedWheelClosestOnAxis(FVector& Point, float& OutClosetDistanceToAxis, FVector& OutClosestPointOnAxis, FVector& OutClosestAxis)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheelsComponent.GetAttachedWheelClosestOnAxis");
    
        UAttachableWheelsComponent___GetAttachedWheelClosestOnAxis_Params Params{};
        Params.Point = Point;
        Params.OutClosetDistanceToAxis = OutClosetDistanceToAxis;
        Params.OutClosestPointOnAxis = OutClosestPointOnAxis;
        Params.OutClosestAxis = OutClosestAxis;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Point = Params.Point;
        OutClosetDistanceToAxis = Params.OutClosetDistanceToAxis;
        OutClosestPointOnAxis = Params.OutClosestPointOnAxis;
        OutClosestAxis = Params.OutClosestAxis;
    
        return Params.ReturnValue;
    }

    TArray<AAttachableWheel*> UAttachableWheelsComponent::GetAttachedWheels()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheelsComponent.GetAttachedWheels");
    
        UAttachableWheelsComponent___GetAttachedWheels_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAttachableWheelsComponent::HandleWheelAttached_Internal(AAttachableWheel* AttachedWheel)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheelsComponent.HandleWheelAttached_Internal");
    
        UAttachableWheelsComponent___HandleWheelAttached_Internal_Params Params{};
        Params.AttachedWheel = AttachedWheel;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAttachableWheelsComponent::HandleWheelDetached_Internal(AAttachableWheel* AttachedWheel)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheelsComponent.HandleWheelDetached_Internal");
    
        UAttachableWheelsComponent___HandleWheelDetached_Internal_Params Params{};
        Params.AttachedWheel = AttachedWheel;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAttachableWheelsComponent::OnWheelAttached(AAttachableWheel* AttachedWheel)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheelsComponent.OnWheelAttached");
    
        UAttachableWheelsComponent___OnWheelAttached_Params Params{};
        Params.AttachedWheel = AttachedWheel;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAttachableWheelsComponent::OnWheelDetached(AAttachableWheel* AttachedWheel)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheelsComponent.OnWheelDetached");
    
        UAttachableWheelsComponent___OnWheelDetached_Params Params{};
        Params.AttachedWheel = AttachedWheel;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAttachableWheelsComponent::SetMaxChassisMassFraction(float InMaxChassisMassFraction)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AttachableWheelsRuntime.AttachableWheelsComponent.SetMaxChassisMassFraction");
    
        UAttachableWheelsComponent___SetMaxChassisMassFraction_Params Params{};
        Params.InMaxChassisMassFraction = InMaxChassisMassFraction;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

