/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:48
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AIDebuggerRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class UAIDebuggerCheatManager : public UChildCheatManager
    {
    public:
    
    public: // Functions
        void    EnableNavMeshVisualizer(bool bEnable); // 0x040ED1DC [Final | Exec | Native | Public]
        void    NextNavMesh(); // 0x0CA02B1A [Final | Exec | Native | Public]
        void    StartAIDebugger(FString AIDebuggerSoftClassPath); // 0x060638B8 [Final | Exec | Native | Public]
    };
    // Size: 0x000660 (0x0000F0)
    class alignas(0x8) UAIDebuggerRendererComponent : public UPrimitiveComponent
    {
    public:
        uint8       UnknownData_000570[0x0000A8];   // 0x000570 (0x0000A8)
        UMaterial*  NavMeshMaterial;                // 0x000618 (0x000008) [Default: nullptr]
        float       NavLinkLineThickness;           // 0x000620 (0x000004) [Default: 2f]
        float       NavLinkMaxDrawDistance;         // 0x000624 (0x000004) [Default: 5000f]
        uint8       UnknownData_000628[0x000038];   // 0x000628 (0x000038)
    
    public: // Functions
        void    OnNPCBoundsTimerTick(); // 0x10B73B5C [Final | Native | Protected]
    };
    // Size: 0x000140 (0x000078)
    class alignas(0x8) UFortControllerComponent_AIDebugger : public UFortControllerComponent
    {
    public:
        APlayerController*  OwnerPC;                        // 0x0000C8 (0x000008) [Default: nullptr]
        UClass*             NavMeshRendererComponentClass;  // 0x0000D0 (0x000008) [Default: nullptr]
        uint8               DefaultEnabledVisualizers;      // 0x0000D8 (0x000001) [Default: 0]
        uint8               UnknownData_0000D9[0x000003];   // 0x0000D9 (0x000003)
        int32               DefaultNavDataIndexToDisplay;   // 0x0000DC (0x000004) [Default: 0]
        uint8               EnabledVisualizers;             // 0x0000E0 (0x000001) [Default: 0]
        uint8               NumNavMeshes;                   // 0x0000E1 (0x000001) [Default: 0]
        uint8               UnknownData_0000E2[0x00005E];   // 0x0000E2 (0x00005E)
    
    public: // Functions
        UAIDebuggerRendererComponent*   GetOrCreateRenderer(); // 0x10B75042 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                            IsVisualizationEnabled(EAIDebuggerVisualization VisualizationType); // 0x07E6CC52 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                            OnPlayerExitedIsland(FEventMessageTag Channel, FPlayerExitSpatialActorContextWithPawn& PlayerExitSpatialActorContext); // 0x07E6CDC4 [Final | Native | Public | HasOutParms]
        void                            OnPossessedPawnChanged(APawn* OldPawn, APawn* NewPawn); // 0x07E6D04C [Final | Native | Public]
        void                            OnRep_EnabledVisualizers(); // 0x10B75212 [Final | Native | Public]
        void                            SetVisualizationEnable(EAIDebuggerVisualization VisualizationType, bool bEnable); // 0x07E6D2D2 [RequiredAPI | Net | NetReliable | Native | Event | Public | NetServer | BlueprintCallable]
        void                            VisualizeNavMeshID(int32 NavMeshID); // 0x0624CF52 [Net | NetReliable | Native | Event | Public | NetServer | BlueprintCallable]
        void                            VisualizeNextNavMesh(); // 0x0F3FA030 [Net | NetReliable | Native | Event | Public | NetServer | BlueprintCallable]
    };
}

