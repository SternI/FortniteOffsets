/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimationLayeringInternalRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000280 (0x0001B8)
    struct alignas(0x8) FAnimNode_CopyMotion : public FAnimNode_SkeletalControlBase
    {
        FComponentSpacePoseLink BasePose;                       // 0x0000C8 (0x000010)
        FComponentSpacePoseLink BasePoseReference;              // 0x0000D8 (0x000010)
        bool                    bUseBasePose;                   // 0x0000E8 (0x000001) [Default: false]
        uint8                   UnknownData_0000E9[0x000003];   // 0x0000E9 (0x000003)
        FName                   PoseHistoryTag;                 // 0x0000EC (0x000004) [Default: NAME_None]
        float                   Delay;                          // 0x0000F0 (0x000004) [Default: 0f]
        FBoneReference          SourceBone;                     // 0x0000F4 (0x00000C)
        FBoneReference          BoneToModify;                   // 0x000100 (0x00000C)
        FBoneReference          CopySpace;                      // 0x00010C (0x00000C)
        bool                    bUseRootSpace;                  // 0x000118 (0x000001) [Default: false]
        uint8                   UnknownData_000119[0x000003];   // 0x000119 (0x000003)
        FBoneReference          ApplySpace;                     // 0x00011C (0x00000C)
        FName                   DynamicSourceBone;              // 0x000128 (0x000004) [Default: NAME_None]
        FName                   DynamicCopySpace;               // 0x00012C (0x000004) [Default: NAME_None]
        FName                   DynamicApplySpace;              // 0x000130 (0x000004) [Default: NAME_None]
        uint8                   UnknownData_000134[0x000004];   // 0x000134 (0x000004)
        FRotator                TranslationOffset;              // 0x000138 (0x000018)
        FRotator                RotationOffset;                 // 0x000150 (0x000018)
        FVector                 RotationPivot;                  // 0x000168 (0x000018)
        FName                   CurvePrefix;                    // 0x000180 (0x000004) [Default: NAME_None]
        FName                   TargetCurveName;                // 0x000184 (0x000004) [Default: NAME_None]
        float                   TargetCurveScale;               // 0x000188 (0x000004) [Default: 0f]
        ECopyMotion_Component   TargetCurveComponent;           // 0x00018C (0x000001) [Default: ECopyMotion_Component(0)]
        TEnumAsByte<EAxis>      TargetCurveRotationAxis;        // 0x00018D (0x000001) [Default: 0]
        bool                    bUseLegacyBehavior;             // 0x00018E (0x000001) [Default: false]
        uint8                   UnknownByte_00018F;             // 0x00018F (0x000001)
        FRotator                ApplySpaceOffset;               // 0x000190 (0x000018)
        FName                   TranslationX_CurveName;         // 0x0001A8 (0x000004) [Default: NAME_None]
        FName                   TranslationY_CurveName;         // 0x0001AC (0x000004) [Default: NAME_None]
        FName                   TranslationZ_CurveName;         // 0x0001B0 (0x000004) [Default: NAME_None]
        FName                   RotationRoll_CurveName;         // 0x0001B4 (0x000004) [Default: NAME_None]
        FName                   RotationPitch_CurveName;        // 0x0001B8 (0x000004) [Default: NAME_None]
        FName                   RotationYaw_CurveName;          // 0x0001BC (0x000004) [Default: NAME_None]
        FVector                 TranslationScale;               // 0x0001C0 (0x000018)
        float                   TranslationSmoothingTime;       // 0x0001D8 (0x000004) [Default: 0f]
        uint8                   UnknownData_0001DC[0x000004];   // 0x0001DC (0x000004)
        UCurveVector*           TranslationRemapCurve;          // 0x0001E0 (0x000008) [Default: nullptr]
        float                   RotationScale;                  // 0x0001E8 (0x000004) [Default: 0f]
        float                   RotationSmoothingTime;          // 0x0001EC (0x000004) [Default: 0f]
        UCurveFloat*            RotationRemapCurve;             // 0x0001F0 (0x000008) [Default: nullptr]
        bool                    bDeltaSmoothing;                // 0x0001F8 (0x000001) [Default: false]
        uint8                   UnknownData_0001F9[0x000087];   // 0x0001F9 (0x000087)
    };
}

