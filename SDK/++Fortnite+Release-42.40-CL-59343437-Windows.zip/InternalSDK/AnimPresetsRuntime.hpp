/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimPresetsRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0000E0 (0x000020)
    class alignas(0x8) UAnimPresetComponent : public UActorComponent
    {
    public:
        TSoftClassPtr<UClass>   AnimPreset; // 0x0000C0 (0x000020) [Default: nullptr]
    };
    // Size: 0x000078 (0x000050)
    class alignas(0x8) UAnimPreset_BasicLocomotion : public UAnimPreset
    {
    public:
        FAnimPreset_SingleAnimationData Idle;           // 0x000028 (0x000010)
        FAnimPreset_SingleAnimationData MoveForward;    // 0x000038 (0x000010)
        FAnimPreset_SingleAnimationData MoveBackward;   // 0x000048 (0x000010)
        FAnimPreset_SingleAnimationData MoveLeft;       // 0x000058 (0x000010)
        FAnimPreset_SingleAnimationData MoveRight;      // 0x000068 (0x000010)
    };
    // Size: 0x000048 (0x000020)
    class alignas(0x8) UGameFeatureAction_AnimPreset : public UGameFeatureAction
    {
    public:
        TSoftClassPtr<UClass>   AnimBP_Preset_BasicLocomotion;  // 0x000028 (0x000020) [Default: nullptr]
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAnimPreset_SingleAnimationData
    {
        UAnimSequence*  Animation;                      // 0x000000 (0x000008)
        float           PlayRate;                       // 0x000008 (0x000004)
        uint8           UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
    };
}

