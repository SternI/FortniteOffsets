/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArmoredBattleBusRuntime_Functions
 * ============================================================
 */

#include "ArmoredBattleBusRuntime.hpp"

namespace UE
{

    struct UFortArmoredBattleBusPassengerAnimInstance___GenerateCharacterPitchAndYawForSlopedTerrain_Params
    {
        AFortAthenaVehicle* VehicleActor;   // 0x000000 (0x000008) [Default: 0x148BBE70]
        float               TurretYaw;      // 0x000008 (0x000004) [OutParam] [Default: 6.86636e-44f]
        float               TurretPitch;    // 0x00000C (0x000004) [OutParam] [Default: 1.66335e-34f]
        FRotator            PawnYawRotator; // 0x000010 (0x000018) [OutParam]
    };

    struct UFortArmoredBattleBusPassengerAnimInstance___GetFootAttachTransform_Params
    {
        USkeletalMeshComponent* BusMeshComponent;               // 0x000000 (0x000008) [Default: 0x148BBE70]
        uint8                   UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        FTransform              ReturnValue;                    // 0x000010 (0x000060) [ReturnValue]
    };

    struct UFortArmoredBattleBusPassengerAnimInstance___GetHandAttachLocation_Params
    {
        USkeletalMeshComponent* BusMeshComponent;           // 0x000000 (0x000008) [Default: 0x148BBE70]
        FName                   FrontHandAttachBoneName;    // 0x000008 (0x000004) [Default: FName(49) -> L""]
        FName                   RearHandAttachBoneName;     // 0x00000C (0x000004) [Default: FName(123541725) -> L""]
        FVector                 ReturnValue;                // 0x000010 (0x000018) [ReturnValue]
    };

    struct UFortArmoredBattleBusPassengerAnimInstance___GetPassengerTransform_Params
    {
        USkeletalMeshComponent* BusMeshComponent;               // 0x000000 (0x000008) [Default: 0x148BBE70]
        uint8                   UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        FTransform              ReturnValue;                    // 0x000010 (0x000060) [ReturnValue]
    };

    struct UFortArmoredBattleBusPassengerAnimInstance___UnrotateHandAttachLocation_Params
    {
        FVector     HandLocation;   // 0x000000 (0x000018) [OutParam]
        FVector     FootLocation;   // 0x000018 (0x000018) [OutParam]
        FRotator    FootRotation;   // 0x000030 (0x000018) [OutParam]
        FVector     ReturnValue;    // 0x000048 (0x000018) [ReturnValue]
    };

    struct UFortArmoredBattleBusPassengerAnimInstance___UpdateHandPositionsSlopeValues_Params
    {
        USkeletalMeshComponent* BusMeshComponent;   // 0x000000 (0x000008) [Default: 0x148BBE70]
    };

    struct UFortArmoredBattleBusPassengerAnimInstance___UpdateSmoothedVehicleYawRate_Params
    {
        AFortAthenaVehicle* VehicleActor;   // 0x000000 (0x000008) [Default: 0x148BBE70]
    };

    struct UFortArmoredBattleBusPassengerAnimInstance___UpdateYawDeltaSmoothed_Params
    {
        AFortAthenaVehicle* VehicleActor;                   // 0x000000 (0x000008) [Default: 0x148BBE70]
        FName               SocketName;                     // 0x000008 (0x000004) [Default: FName(49) -> L""]
        uint8               UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FRotator            NewRotation;                    // 0x000010 (0x000018) [OutParam]
        float               SmoothedYawValue;               // 0x000028 (0x000004) [OutParam] [Default: 0f]
    };

    struct UFortArmoredBattleBusVehicleAnimInstance___GetPitchAndYaw_Params
    {
        AFortAthenaVehicle* VehicleActor;                   // 0x000000 (0x000008) [Default: 0x148BC290]
        AFortPlayerPawn*    GunnerActor;                    // 0x000008 (0x000008) [Default: 0x65D18DD00000031]
        float               AdjustedPitch;                  // 0x000010 (0x000004) [OutParam] [Default: 1.262e-23f]
        float               AdjustedYaw;                    // 0x000014 (0x000004) [OutParam] [Default: 0f]
        bool                bIsLocalPlayerControlled;       // 0x000018 (0x000001) [OutParam] [Default: true]
        uint8               UnknownData_000019[0x000007];   // 0x000019 (0x000007)
        FRotator            YawRotator;                     // 0x000020 (0x000018) [OutParam]
    };

    struct UFortArmoredBattleBusVehicleAnimInstance___UpdateSmoothedVehicleYawRate_Params
    {
        AFortAthenaVehicle* VehicleActor;       // 0x000000 (0x000008) [Default: 0x148BC290]
        FRotator            PreviousRotator;    // 0x000008 (0x000018)
        float               ReturnValue;        // 0x000020 (0x000004) [ReturnValue] [Default: -3.44246e-29f]
    };

    struct UFortArmoredBattleBusVehicleAnimInstance___UpdateTurretAimPitchWeaponYaw_Params
    {
        AFortAthenaVehicle* OwnerVehicle;       // 0x000000 (0x000008) [Default: 0x148BC290]
        AFortPlayerPawn*    GunnerActor;        // 0x000008 (0x000008) [Default: 0x65D18DD00000031]
        FName               SocketName;         // 0x000010 (0x000004) [Default: FName(427039536) -> L""]
        float               YawOffset;          // 0x000014 (0x000004) [Default: 0f]
        float               TurretAimPitch;     // 0x000018 (0x000004) [OutParam] [Default: 1.26091e-23f]
        float               YawDeltaSmoothed;   // 0x00001C (0x000004) [OutParam] [Default: 0f]
        FRotator            WeaponYaw;          // 0x000020 (0x000018) [OutParam]
    };

    struct UFortArmoredBattleBusVehicleAnimInstance___UpdateYawDeltaSmoothed_Params
    {
        AFortAthenaVehicle* VehicleActor;                   // 0x000000 (0x000008) [Default: 0x148BC290]
        FName               SocketName;                     // 0x000008 (0x000004) [Default: FName(49) -> L""]
        uint8               UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FRotator            NewRotation;                    // 0x000010 (0x000018)
        float               SmoothedYawValue;               // 0x000028 (0x000004) [Default: 0f]
        float               ReturnValue;                    // 0x00002C (0x000004) [ReturnValue] [Default: 0f]
    };

} // namespace UE

