/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BlastBerryCoreRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FBlastBerryRespawnReward
    {
        float   RewardTime;     // 0x000000 (0x000004)
        FName   MessageTableId; // 0x000004 (0x000004)
        FName   MessageKey;     // 0x000008 (0x000004)
    };
    // Size: 0x000001 (0x000001)
    struct FReloadRemainingTeamLives
    {
        uint8   TeamLives;  // 0x000000 (0x000001)
    };
}

