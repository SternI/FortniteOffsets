/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AIProgressBarRuntime_Functions
 * ============================================================
 */

#include "AIProgressBarRuntime.hpp"

namespace UE
{

    struct AChallengeManagerBase___GetBossActor_Params
    {
        AActor* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1486BB10]
    };

    struct AChallengeManagerBase___GetBossIDTag_Params
    {
        FGameplayTag    ReturnValue;    // 0x000000 (0x000004) [ReturnValue]
    };

    struct AChallengeManagerBase___GetCurrentPhaseProgressTarget_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344374032]
    };

    struct AChallengeManagerBase___GetCurrentStageData_Params
    {
        FAIProgressBarStageData ReturnValue;    // 0x000000 (0x000020) [ReturnValue]
    };

    struct AChallengeManagerBase___GetCurrentState_Params
    {
        EChallengeState ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EChallengeState(16)]
    };

    struct AChallengeManagerBase___GetMusicTagByPhase_Params
    {
        FGameplayTag    ReturnValue;    // 0x000000 (0x000004) [ReturnValue]
    };

    struct AChallengeManagerBase___GetStageGoalTarget_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344374032]
    };

    struct AChallengeManagerBase___GetStageTotalProgressGoal_Params
    {
        int32   Stage;          // 0x000000 (0x000004) [Default: 344374032]
        int32   ReturnValue;    // 0x000004 (0x000004) [ReturnValue] [Default: 0]
    };

    struct AChallengeManagerBase___HandleActorDied_Params
    {
        UFortAthenaLivingWorldEncounterInstance*    EncounterInstance;  // 0x000000 (0x000008) [Default: 0x1486BB10]
        AActor*                                     DiedActor;          // 0x000008 (0x000008) [Default: 0x25E18DD00000031]
    };

    struct AChallengeManagerBase___HandleBossSpawned_Params
    {
        AActor* SpawnedActor;   // 0x000000 (0x000008) [Default: 0x1486BB10]
    };

    struct AChallengeManagerBase___HandlePawnSpawned_Params
    {
        UFortAthenaLivingWorldEncounterInstance*    EncounterInstance;  // 0x000000 (0x000008) [Default: 0x1486BB10]
        AActor*                                     SpawnedActor;       // 0x000008 (0x000008) [Default: 0x25E18DD00000031]
        UFortAthenaLivingWorldEventData*            EventData;          // 0x000010 (0x000008) [Default: 0x196A56E0]
    };

    struct AChallengeManagerBase___IncrementProgress_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct AChallengeManagerBase___IsBossReadyForFinalFight_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct AChallengeManagerBase___RequestPawnEnterArena_Params
    {
        AActor* Actor;  // 0x000000 (0x000008) [Default: 0x1486BB10]
    };

    struct AChallengeManagerBase___RequestPawnExitArena_Params
    {
        AActor* Actor;  // 0x000000 (0x000008) [Default: 0x1486BB10]
    };

    struct AChallengeManagerBase___SetAIProgressBarChallengeRef_Params
    {
        AActor* Actor;      // 0x000000 (0x000008) [Default: 0x1486BB10]
        bool    bSetToSelf; // 0x000008 (0x000001) [Default: true]
    };

    struct AChallengeManagerBase___SetCurrentState_Params
    {
        EChallengeState NewState;   // 0x000000 (0x000001) [Default: EChallengeState(16)]
    };

    struct AChallengeManagerBase___SetIsBossReadyForFinalFight_Params
    {
        bool    bIsReady;   // 0x000000 (0x000001) [Default: true]
    };

    struct AChallengeManagerBase___ShouldAdvanceStage_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct AChallengeManagerBase___SpawnReward_Params
    {
        AActor* Boss;   // 0x000000 (0x000008) [Default: 0x1486BB10]
    };

    struct AChallengeManagerBase___UpdateChallengeState_Params
    {
        EChallengeState NewState;   // 0x000000 (0x000001) [Default: EChallengeState(16)]
    };

    struct AChallengeManagerBase___UpdateMapIconByState_Params
    {
        EChallengeState ChallengeState; // 0x000000 (0x000001) [Default: EChallengeState(16)]
    };

    struct AChallengeManagerBase___OnStageAdvanced_Params
    {
        int32   NewStage;   // 0x000000 (0x000004) [Default: 344374032]
    };

} // namespace UE

