/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AutoAimWeaponRuntime_Functions
 * ============================================================
 */

#include "AutoAimWeaponRuntime_Functions.hpp"

namespace UE
{

    bool UAutoAimWeaponKismetLibrary::DoesAutoAimWeaponHaveLineOfSight(AFortPawn* SourcePawn, AFortPawn* TargetPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AutoAimWeaponRuntime.AutoAimWeaponKismetLibrary.DoesAutoAimWeaponHaveLineOfSight");
    
        UAutoAimWeaponKismetLibrary___DoesAutoAimWeaponHaveLineOfSight_Params Params{};
        Params.SourcePawn = SourcePawn;
        Params.TargetPawn = TargetPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAutoAimWeaponKismetLibrary::DoesAutoAimWeaponReticleIntersectTarget(float& OutReticleDistance, AFortPawn* SourcePawn, AFortPawn* TargetPawn, float ReticleSize)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AutoAimWeaponRuntime.AutoAimWeaponKismetLibrary.DoesAutoAimWeaponReticleIntersectTarget");
    
        UAutoAimWeaponKismetLibrary___DoesAutoAimWeaponReticleIntersectTarget_Params Params{};
        Params.OutReticleDistance = OutReticleDistance;
        Params.SourcePawn = SourcePawn;
        Params.TargetPawn = TargetPawn;
        Params.ReticleSize = ReticleSize;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutReticleDistance = Params.OutReticleDistance;
    
        return Params.ReturnValue;
    }

    void UAutoAimWeaponKismetLibrary::FindBestAutoAimTarget(AFortPawn*& OutTargetPawn, float& OutReticleDistance, AFortPlayerPawn* SourcePawn, float ReticleSize, float Range)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AutoAimWeaponRuntime.AutoAimWeaponKismetLibrary.FindBestAutoAimTarget");
    
        UAutoAimWeaponKismetLibrary___FindBestAutoAimTarget_Params Params{};
        Params.OutTargetPawn = OutTargetPawn;
        Params.OutReticleDistance = OutReticleDistance;
        Params.SourcePawn = SourcePawn;
        Params.ReticleSize = ReticleSize;
        Params.Range = Range;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutTargetPawn = Params.OutTargetPawn;
        OutReticleDistance = Params.OutReticleDistance;
    }

    UAutoAimWeaponPawnComponent* UAutoAimWeaponKismetLibrary::GetAutoAimWeaponPawnComponent(AFortPawn* SourcePawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AutoAimWeaponRuntime.AutoAimWeaponKismetLibrary.GetAutoAimWeaponPawnComponent");
    
        UAutoAimWeaponKismetLibrary___GetAutoAimWeaponPawnComponent_Params Params{};
        Params.SourcePawn = SourcePawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAutoAimWeaponPawnComponent::ApplySpreadToAimRotation(FRotator& OutRotation, float SpreadInDegrees)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AutoAimWeaponRuntime.AutoAimWeaponPawnComponent.ApplySpreadToAimRotation");
    
        UAutoAimWeaponPawnComponent___ApplySpreadToAimRotation_Params Params{};
        Params.OutRotation = OutRotation;
        Params.SpreadInDegrees = SpreadInDegrees;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutRotation = Params.OutRotation;
    }

    int32 UAutoAimWeaponPawnComponent::GetCurrentLockOnCount()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AutoAimWeaponRuntime.AutoAimWeaponPawnComponent.GetCurrentLockOnCount");
    
        UAutoAimWeaponPawnComponent___GetCurrentLockOnCount_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAutoAimWeaponPawnComponent::GetLockOnProgress()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AutoAimWeaponRuntime.AutoAimWeaponPawnComponent.GetLockOnProgress");
    
        UAutoAimWeaponPawnComponent___GetLockOnProgress_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAutoAimWeaponPawnComponent::GetLockOnTargetLocation(FVector& OutLockTargetLocation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AutoAimWeaponRuntime.AutoAimWeaponPawnComponent.GetLockOnTargetLocation");
    
        UAutoAimWeaponPawnComponent___GetLockOnTargetLocation_Params Params{};
        Params.OutLockTargetLocation = OutLockTargetLocation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutLockTargetLocation = Params.OutLockTargetLocation;
    
        return Params.ReturnValue;
    }

    float UAutoAimWeaponPawnComponent::GetTargetToReticleDistanceNormalized()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AutoAimWeaponRuntime.AutoAimWeaponPawnComponent.GetTargetToReticleDistanceNormalized");
    
        UAutoAimWeaponPawnComponent___GetTargetToReticleDistanceNormalized_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAutoAimWeaponPawnComponent::RotateAimTowardsLockOnTarget(FRotator& OutRotation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AutoAimWeaponRuntime.AutoAimWeaponPawnComponent.RotateAimTowardsLockOnTarget");
    
        UAutoAimWeaponPawnComponent___RotateAimTowardsLockOnTarget_Params Params{};
        Params.OutRotation = OutRotation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutRotation = Params.OutRotation;
    }

} // namespace UE

