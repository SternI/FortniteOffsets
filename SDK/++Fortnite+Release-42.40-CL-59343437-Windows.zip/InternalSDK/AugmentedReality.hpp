/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:04
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AugmentedReality
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000270 (0x000000)
    class AARActor : public AActor
    {
    public:
    
    public: // Functions
        UARComponent*   AddARComponent(UClass* InComponentClass, FGuid& NativeID); // 0x05F42384 [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000270 (0x000000)
    class AAROriginActor : public AActor
    {
    public:
    };
    // Size: 0x000378 (0x000028)
    class alignas(0x4) AARSharedWorldGameMode : public AGameMode
    {
    public:
        int32   BufferSizePerChunk;             // 0x000350 (0x000004) [Default: 512]
        uint8   UnknownData_000354[0x000024];   // 0x000354 (0x000024)
    
    public: // Functions
        AARSharedWorldGameState*    GetARSharedWorldGameState(); // 0x0EB842F4 [Final | RequiredAPI | BlueprintAuthorityOnly | Native | Public | BlueprintCallable]
        void                        SetARSharedWorldData(TArray<uint8> ARWorldData); // 0x05F53C10 [Final | RequiredAPI | BlueprintAuthorityOnly | Native | Public | BlueprintCallable]
        void                        SetARWorldSharingIsReady(); // 0x05F53DF4 [Final | RequiredAPI | BlueprintAuthorityOnly | Native | Public | BlueprintCallable]
        void                        SetPreviewImageData(TArray<uint8> ImageData); // 0x05F53F00 [Final | RequiredAPI | BlueprintAuthorityOnly | Native | Public | BlueprintCallable]
    };
    // Size: 0x000318 (0x000038)
    class alignas(0x8) AARSharedWorldGameState : public AGameState
    {
    public:
        TArray<uint8>   PreviewImageData;               // 0x0002E0 (0x000010)
        TArray<uint8>   ARWorldData;                    // 0x0002F0 (0x000010)
        int32           PreviewImageBytesTotal;         // 0x000300 (0x000004) [Default: 0]
        int32           ARWorldBytesTotal;              // 0x000304 (0x000004) [Default: 0]
        int32           PreviewImageBytesDelivered;     // 0x000308 (0x000004) [Default: 0]
        int32           ARWorldBytesDelivered;          // 0x00030C (0x000004) [Default: 0]
        uint8           UnknownData_000310[0x000008];   // 0x000310 (0x000008)
    
    public: // Functions
        void    K2_OnARWorldMapIsReady(); // 0x000545D2 [RequiredAPI | Event | Public | BlueprintEvent]
    };
    // Size: 0x0006D8 (0x000008)
    class AARSharedWorldPlayerController : public APlayerController
    {
    public:
        uint8   UnknownData_0006D0[0x000008];   // 0x0006D0 (0x000008)
    
    public: // Functions
        void    ClientInitSharedWorld(int32 PreviewImageSize, int32 ARWorldDataSize); // 0x05F549D8 [RequiredAPI | Net | NetReliable | Native | Event | Public | NetClient | NetValidate]
        void    ClientUpdateARWorldData(int32 Offset, TArray<uint8> Buffer); // 0x05F54C88 [RequiredAPI | Net | NetReliable | Native | Event | Public | NetClient | NetValidate]
        void    ClientUpdatePreviewImageData(int32 Offset, TArray<uint8> Buffer); // 0x05F54F48 [RequiredAPI | Net | NetReliable | Native | Event | Public | NetClient | NetValidate]
        void    ServerMarkReadyForReceiving(); // 0x0F140496 [RequiredAPI | Net | NetReliable | Native | Event | Public | NetServer | NetValidate]
    };
    // Size: 0x000290 (0x000010)
    class alignas(0x8) AARSkyLight : public ASkyLight
    {
    public:
        UAREnvironmentCaptureProbe* CaptureProbe;                   // 0x000280 (0x000008) [Default: nullptr]
        uint8                       UnknownData_000288[0x000008];   // 0x000288 (0x000008)
    
    public: // Functions
        void    SetEnvironmentCaptureProbe(UAREnvironmentCaptureProbe* InCaptureProbe); // 0x05F55F44 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000050 (0x000020)
    class alignas(0x8) UARBaseAsyncTaskBlueprintProxy : public UBlueprintAsyncActionBase
    {
    public:
        void**  VTable_000030;                  // 0x000030 (0x000008) VTable [9 slots] -> 0x1379C450
        uint8   UnknownData_000038[0x000018];   // 0x000038 (0x000018)
    };
    // Size: 0x000040 (0x000018)
    class alignas(0x8) UARBasicLightEstimate : public UARLightEstimate
    {
    public:
        float           AmbientIntensityLumens;         // 0x000028 (0x000004) [Default: 0f]
        float           AmbientColorTemperatureKelvin;  // 0x00002C (0x000004) [Default: 0f]
        FLinearColor    AmbientColor;                   // 0x000030 (0x000010)
    
    public: // Functions
        FLinearColor    GetAmbientColor(); // 0x0F13FAAC [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        float           GetAmbientColorTemperatureKelvin(); // 0x0F13FAC6 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float           GetAmbientIntensityLumens(); // 0x0F13FAE2 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000028 (0x000000)
    class UARBlueprintLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static bool                        AddManualEnvironmentCaptureProbe(FVector Location, FVector Extent); // 0x05F42622 [Final | RequiredAPI | Native | Static | Public | HasDefaults | BlueprintCallable]
        static UARCandidateImage*          AddRuntimeCandidateImage(UARSessionConfig* SessionConfig, UTexture2D* CandidateTexture, FString FriendlyName, float PhysicalWidth); // 0x05F428C4 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static bool                        AddTrackedPointWithName(FTransform& WorldTransform, FString PointName, bool bDeletePointsWithSameName); // 0x05F42D60 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static void                        CalculateAlignmentTransform(FTransform& TransformInFirstCoordinateSystem, FTransform& TransformInSecondCoordinateSystem, FTransform& AlignmentTransform); // 0x05F4315E [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static void                        CalculateClosestIntersection(TArray<FVector>& StartPoints, TArray<FVector>& EndPoints, FVector& ClosestIntersection); // 0x05F435FA [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static void                        DebugDrawPin(UARPin* ARPin, UObject* WorldContextObject, FLinearColor Color, float Scale, float PersistForSeconds); // 0x05F439DA [Final | RequiredAPI | Native | Static | Public | HasDefaults | BlueprintCallable]
        static void                        DebugDrawTrackedGeometry(UARTrackedGeometry* TrackedGeometry, UObject* WorldContextObject, FLinearColor Color, float OutlineThickness, float PersistForSeconds); // 0x05F43FE6 [Final | RequiredAPI | Native | Static | Public | HasDefaults | BlueprintCallable]
        static TArray<UARTrackedPoint*>    FindTrackedPointsByName(FString PointName); // 0x05F445F2 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static FTransform                  GetAlignmentTransform(); // 0x0F137B4E [Final | RequiredAPI | Native | Static | Public | HasDefaults | BlueprintCallable | BlueprintPure]
        static TArray<UARTrackedGeometry*> GetAllGeometries(); // 0x0F137C60 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static TArray<UARTrackedGeometry*> GetAllGeometriesByClass(UClass* GeometryClass); // 0x05F4478E [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static TArray<UARPin*>             GetAllPins(); // 0x0F137F62 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static TArray<FARPose2D>           GetAllTracked2DPoses(); // 0x0F138104 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static FARSessionStatus            GetARSessionStatus(); // 0x0F138272 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static UARTexture*                 GetARTexture(EARTextureType TextureType); // 0x05F44924 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static float                       GetARWorldScale(); // 0x0F13844E [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static bool                        GetCameraIntrinsics(FARCameraIntrinsics& OutCameraIntrinsics); // 0x05F44A8E [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static UARLightEstimate*           GetCurrentLightEstimate(); // 0x0F13856A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static int32                       GetNumberOfTrackedFacesSupported(); // 0x0F138628 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static bool                        GetObjectClassificationAtLocation(FVector& InWorldLocation, EARObjectClassification& OutClassification, FVector& OutClassificationLocation, float MaxLocationDiff); // 0x05F44C1A [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static TArray<FVector>             GetPointCloud(); // 0x0F1387CE [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static UARSessionConfig*           GetSessionConfig(); // 0x0F1388FC [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static TArray<FARVideoFormat>      GetSupportedVideoFormats(EARSessionType SessionType); // 0x05F450B0 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static EARTrackingQuality          GetTrackingQuality(); // 0x0F138A40 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static EARTrackingQualityReason    GetTrackingQualityReason(); // 0x0F138AF8 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static EARWorldMappingState        GetWorldMappingStatus(); // 0x0F138BB0 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static bool                        IsARPinLocalStoreReady(); // 0x0F138C6C [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static bool                        IsARPinLocalStoreSupported(); // 0x0F138D28 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static bool                        IsARSupported(); // 0x0F138DE4 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static bool                        IsSceneReconstructionSupported(EARSessionType SessionType, EARSceneReconstruction SceneReconstructionMethod); // 0x05F45252 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static bool                        IsSessionTrackingFeatureSupported(EARSessionType SessionType, EARSessionTrackingFeature SessionTrackingFeature); // 0x05F454C8 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static bool                        IsSessionTypeSupported(EARSessionType SessionType); // 0x05F4573E [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static TArray<FARTraceResult>      LineTraceTrackedObjects(FVector2D ScreenCoord, bool bTestFeaturePoints, bool bTestGroundPlane, bool bTestPlaneExtents, bool bTestPlaneBoundaryPolygon); // 0x05F458A6 [Final | RequiredAPI | Native | Static | Public | HasDefaults | BlueprintCallable]
        static TArray<FARTraceResult>      LineTraceTrackedObjects3D(FVector Start, FVector End, bool bTestFeaturePoints, bool bTestGroundPlane, bool bTestPlaneExtents, bool bTestPlaneBoundaryPolygon); // 0x05F45DF4 [Final | RequiredAPI | Native | Static | Public | HasDefaults | BlueprintCallable]
        static TMap<FName, UARPin*>        LoadARPinsFromLocalStore(); // 0x0F139352 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                        PauseARSession(); // 0x0F13948E [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static UARPin*                     PinComponent(USceneComponent* ComponentToPin, FTransform& PinToWorldTransform, UARTrackedGeometry* TrackedGeometry, FName DebugName); // 0x05F4646A [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static bool                        PinComponentToARPin(USceneComponent* ComponentToPin, UARPin* Pin); // 0x05F46908 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static UARPin*                     PinComponentToTraceResult(USceneComponent* ComponentToPin, FARTraceResult& TraceResult, FName DebugName); // 0x05F46B88 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                        RemoveAllARPinsFromLocalStore(); // 0x0F139784 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                        RemoveARPinFromLocalStore(FName InSaveName); // 0x05F46FC8 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                        RemovePin(UARPin* PinToRemove); // 0x05F4712C [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static FIntPoint                   ResizeXRCamera(FIntPoint& InSize); // 0x05F47292 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static bool                        SaveARPinToLocalStore(FName InSaveName, UARPin* InPin); // 0x05F47414 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                        SetAlignmentTransform(FTransform& InAlignmentTransform); // 0x05F47692 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static void                        SetARWorldOriginLocationAndRotation(FVector OriginLocation, FRotator OriginRotation, bool bIsTransformInWorldSpace, bool bMaintainUpDirection); // 0x05F47848 [Final | RequiredAPI | Native | Static | Public | HasDefaults | BlueprintCallable]
        static void                        SetARWorldScale(float InWorldScale); // 0x05F47C8E [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                        SetEnabledXRCamera(bool bOnOff); // 0x05F47DF4 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                        StartARSession(UARSessionConfig* SessionConfig); // 0x05F47F5C [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                        StopARSession(); // 0x0F13AC7A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static bool                        ToggleARCapture(bool bOnOff, EARCaptureType CaptureType); // 0x05F480C2 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static void                        UnpinComponent(USceneComponent* ComponentToUnpin); // 0x05F48342 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000050 (0x000028)
    class alignas(0x8) UARCandidateImage : public UDataAsset
    {
    public:
        UTexture2D*                     CandidateTexture;               // 0x000028 (0x000008) [Default: nullptr]
        FString                         FriendlyName;                   // 0x000030 (0x000010) [Default: L""]
        float                           Width;                          // 0x000040 (0x000004) [Default: 0f]
        float                           Height;                         // 0x000044 (0x000004) [Default: 0f]
        EARCandidateImageOrientation    orientation;                    // 0x000048 (0x000001) [Default: EARCandidateImageOrientation(0)]
        uint8                           UnknownData_000049[0x000007];   // 0x000049 (0x000007)
    
    public: // Functions
        UTexture2D*                     GetCandidateTexture(); // 0x0C98454A [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FString                         GetFriendlyName(); // 0x0DE3DE76 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EARCandidateImageOrientation    GetOrientation(); // 0x0F1421A0 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float                           GetPhysicalHeight(); // 0x0CA21AE2 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float                           GetPhysicalWidth(); // 0x0E222C50 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000080 (0x000058)
    class alignas(0x8) UARCandidateObject : public UDataAsset
    {
    public:
        TArray<uint8>   CandidateObjectData;    // 0x000028 (0x000010)
        FString         FriendlyName;           // 0x000038 (0x000010) [Default: L""]
        FBox            BoundingBox;            // 0x000048 (0x000038)
    
    public: // Functions
        FBox            GetBoundingBox(); // 0x0F1421B8 [Final | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        TArray<uint8>   GetCandidateObjectData(); // 0x0F1421EC [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FString         GetFriendlyName(); // 0x0F142208 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void            SetBoundingBox(FBox& InBoundingBox); // 0x05F56BAC [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        void            SetCandidateObjectData(TArray<uint8>& InCandidateObject); // 0x05F56D42 [Final | Native | Public | HasOutParms | BlueprintCallable]
        void            SetFriendlyName(FString NewName); // 0x05F56F34 [Final | Native | Public | BlueprintCallable]
    };
    // Size: 0x0002C0 (0x000080)
    class alignas(0x8) UARComponent : public USceneComponent
    {
    public:
        FGuid               NativeID;                       // 0x000240 (0x000010)
        uint8               UnknownData_000250[0x000030];   // 0x000250 (0x000030)
        bool                bUseDefaultReplication;         // 0x000280 (0x000001) [Default: true]
        uint8               UnknownData_000281[0x000007];   // 0x000281 (0x000007)
        UMaterialInterface* DefaultMeshMaterial;            // 0x000288 (0x000008) [Default: nullptr]
        UMaterialInterface* DefaultWireframeMeshMaterial;   // 0x000290 (0x000008) [Default: nullptr]
        UMRMeshComponent*   MRMeshComponent;                // 0x000298 (0x000008) [Default: nullptr]
        UARTrackedGeometry* MyTrackedGeometry;              // 0x0002A0 (0x000008) [Default: nullptr]
        uint8               UnknownData_0002A8[0x000018];   // 0x0002A8 (0x000018)
    
    public: // Functions
        UMRMeshComponent*   GetMRMesh(); // 0x0F13BD4A [Final | Native | Public | BlueprintCallable | BlueprintPure]
        void                OnRep_Payload(); // 0x0F13BD66 [RequiredAPI | Native | Protected]
        void                ReceiveRemove(); // 0x000545D2 [RequiredAPI | Event | Public | BlueprintEvent]
        void                SetNativeID(FGuid NativeID); // 0x05F499BC [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void                UpdateVisualization(); // 0x0CC02090 [RequiredAPI | Native | Event | Public | BlueprintCallable | BlueprintEvent]
    };
    // Size: 0x000028 (0x000000)
    class UARDependencyHandler : public UObject
    {
    public:
    
    public: // Functions
        void                    CheckARServiceAvailability(UObject* WorldContextObject, FLatentActionInfo LatentInfo, EARServiceAvailability& OutAvailability); // 0x05F4E9BE [Native | Public | HasOutParms | BlueprintCallable]
        static UARDependencyHandler*   GetARDependencyHandler(); // 0x0F13EEE2 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        void                    InstallARService(UObject* WorldContextObject, FLatentActionInfo LatentInfo, EARServiceInstallRequestResult& OutInstallResult); // 0x05F4EDB2 [Native | Public | HasOutParms | BlueprintCallable]
        void                    RequestARSessionPermission(UObject* WorldContextObject, UARSessionConfig* SessionConfig, FLatentActionInfo LatentInfo, EARServicePermissionRequestResult& OutPermissionResult); // 0x05F4F1A6 [Native | Public | HasOutParms | BlueprintCallable]
        void                    StartARSessionLatent(UObject* WorldContextObject, UARSessionConfig* SessionConfig, FLatentActionInfo LatentInfo); // 0x05F4F6BA [Native | Public | BlueprintCallable]
    };
    // Size: 0x000180 (0x000020)
    class alignas(0x8) UAREnvironmentCaptureProbe : public UARTrackedGeometry
    {
    public:
        FVector                             Extent;                     // 0x000160 (0x000018)
        UAREnvironmentCaptureProbeTexture*  EnvironmentCaptureTexture;  // 0x000178 (0x000008) [Default: nullptr]
    
    public: // Functions
        UAREnvironmentCaptureProbeTexture*  GetEnvironmentCaptureTexture(); // 0x0E388662 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure]
        FVector                             GetExtent(); // 0x0F140DC4 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000148 (0x000020)
    class alignas(0x8) UAREnvironmentCaptureProbeTexture : public UTextureCube
    {
    public:
        EARTextureType  TextureType;                    // 0x000128 (0x000001) [Default: EARTextureType(3)]
        uint8           UnknownData_000129[0x000003];   // 0x000129 (0x000003)
        float           Timestamp;                      // 0x00012C (0x000004) [Default: 0f]
        FGuid           ExternalTextureGuid;            // 0x000130 (0x000010)
        FVector2f       Size;                           // 0x000140 (0x000008)
    };
    // Size: 0x000320 (0x000060)
    class alignas(0x8) UAREnvironmentProbeComponent : public UARComponent
    {
    public:
        FAREnvironmentProbeUpdatePayload    ReplicatedPayload;  // 0x0002C0 (0x000060)
    
    public: // Functions
        void    ReceiveAdd(FAREnvironmentProbeUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    ReceiveUpdate(FAREnvironmentProbeUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    ServerUpdatePayload(FAREnvironmentProbeUpdatePayload NewPayload); // 0x05F4AFAE [RequiredAPI | Net | NetReliable | Native | Event | Protected | NetServer | NetValidate]
    };
    // Size: 0x000350 (0x000090)
    class alignas(0x8) UARFaceComponent : public UARComponent
    {
    public:
        EARFaceTransformMixing  TransformSetting;               // 0x0002C0 (0x000001) [Default: EARFaceTransformMixing(3)]
        bool                    bUpdateVertexNormal;            // 0x0002C1 (0x000001) [Default: false]
        bool                    bFaceOutOfScreen;               // 0x0002C2 (0x000001) [Default: true]
        uint8                   UnknownData_0002C3[0x000005];   // 0x0002C3 (0x000005)
        FARFaceUpdatePayload    ReplicatedPayload;              // 0x0002C8 (0x000060)
        uint8                   UnknownData_000328[0x000028];   // 0x000328 (0x000028)
    
    public: // Functions
        void    ReceiveAdd(FARFaceUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    ReceiveUpdate(FARFaceUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    ServerUpdatePayload(FARFaceUpdatePayload NewPayload); // 0x05F4A1E2 [RequiredAPI | Net | NetReliable | Native | Event | Protected | NetServer | NetValidate]
        static void    SetFaceComponentDebugMode(EFaceComponentDebugMode NewDebugMode); // 0x05F4A3B0 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000280 (0x000120)
    class alignas(0x8) UARFaceGeometry : public UARTrackedGeometry
    {
    public:
        FVector                         LookAtTarget;                   // 0x000160 (0x000018)
        bool                            bIsTracked;                     // 0x000178 (0x000001) [Default: false]
        uint8                           UnknownData_000179[0x000007];   // 0x000179 (0x000007)
        TMap<EARFaceBlendShape, float>  BlendShapes;                    // 0x000180 (0x000010)
        uint8                           UnknownData_000190[0x000030];   // 0x000190 (0x000030)
        FTransform                      LeftEyeTransform;               // 0x0001C0 (0x000060)
        FTransform                      RightEyeTransform;              // 0x000220 (0x000060)
    
    public: // Functions
        TMap<EARFaceBlendShape, float>  GetBlendShapes(); // 0x0F140BE6 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float                           GetBlendShapeValue(EARFaceBlendShape BlendShape); // 0x05F56224 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FTransform                      GetLocalSpaceEyeTransform(EAREye Eye); // 0x05F56396 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        FTransform                      GetWorldSpaceEyeTransform(EAREye Eye); // 0x05F5651A [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000170 (0x000010)
    class UARGeoAnchor : public UARTrackedGeometry
    {
    public:
        uint8   UnknownData_000160[0x000010];   // 0x000160 (0x000010)
    
    public: // Functions
        float               GetAltitudeMeters(); // 0x0D1EA1A2 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EARAltitudeSource   GetAltitudeSource(); // 0x0F140E60 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float               GetLatitude(); // 0x0F140E7A [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float               GetLongitude(); // 0x0CB035B2 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000360 (0x0000A0)
    class alignas(0x8) UARGeoAnchorComponent : public UARComponent
    {
    public:
        FARGeoAnchorUpdatePayload   ReplicatedPayload;  // 0x0002C0 (0x0000A0)
    
    public: // Functions
        void    ReceiveAdd(FARGeoAnchorUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    ReceiveUpdate(FARGeoAnchorUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    ServerUpdatePayload(FARGeoAnchorUpdatePayload NewPayload); // 0x05F4B338 [RequiredAPI | Net | NetReliable | Native | Event | Protected | NetServer | NetValidate]
        static void    SetGeoAnchorComponentDebugMode(EGeoAnchorComponentDebugMode NewDebugMode); // 0x05F4B526 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class UARGeoTrackingSupport : public UObject
    {
    public:
    
    public: // Functions
        bool                        AddGeoAnchorAtLocation(float Longitude, float Latitude, FString OptionalAnchorName); // 0x05F4FA9E [Native | Public | BlueprintCallable]
        bool                        AddGeoAnchorAtLocationWithAltitude(float Longitude, float Latitude, float AltitudeMeters, FString OptionalAnchorName); // 0x05F4FEBE [Native | Public | BlueprintCallable]
        EARGeoTrackingAccuracy      GetGeoTrackingAccuracy(); // 0x0C98A7DC [Native | Public | BlueprintCallable | BlueprintPure | Const]
        EARGeoTrackingState         GetGeoTrackingState(); // 0x0C98A806 [Native | Public | BlueprintCallable | BlueprintPure | Const]
        EARGeoTrackingStateReason   GetGeoTrackingStateReason(); // 0x0CD42F8A [Native | Public | BlueprintCallable | BlueprintPure | Const]
        static UARGeoTrackingSupport*      GetGeoTrackingSupport(); // 0x0F13EFFC [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x0000B0 (0x000060)
    class alignas(0x8) UARGetCandidateObjectAsyncTaskBlueprintProxy : public UARBaseAsyncTaskBlueprintProxy
    {
    public:
        MULTI_INLINE_DELEGATE(ARGetCandidateObjectPin)  OnSuccess;                      // 0x000050 (0x000010)
        MULTI_INLINE_DELEGATE(ARGetCandidateObjectPin)  OnFailed;                       // 0x000060 (0x000010)
        uint8                                           UnknownData_000070[0x000040];   // 0x000070 (0x000040)
    
    public: // Functions
        static UARGetCandidateObjectAsyncTaskBlueprintProxy*   ARGetCandidateObject(UObject* WorldContextObject, FVector Location, FVector Extent); // 0x05F495B8 [Final | Native | Static | Public | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000360 (0x0000A0)
    class alignas(0x8) UARImageComponent : public UARComponent
    {
    public:
        FARImageUpdatePayload   ReplicatedPayload;  // 0x0002C0 (0x0000A0)
    
    public: // Functions
        void    ReceiveAdd(FARImageUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    ReceiveUpdate(FARImageUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    ServerUpdatePayload(FARImageUpdatePayload NewPayload); // 0x05F4A548 [RequiredAPI | Net | NetReliable | Native | Event | Protected | NetServer | NetValidate]
        static void    SetImageComponentDebugMode(EImageComponentDebugMode NewDebugMode); // 0x05F4A720 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000270 (0x000030)
    class alignas(0x8) UARLifeCycleComponent : public USceneComponent
    {
    public:
        MULTI_INLINE_DELEGATE(InstanceARActorSpawnedDelegate)       OnARActorSpawnedDelegate;       // 0x000240 (0x000010)
        MULTI_INLINE_DELEGATE(InstanceARActorToBeDestroyedDelegate) OnARActorToBeDestroyedDelegate; // 0x000250 (0x000010)
        uint8                                                       UnknownData_000260[0x000010];   // 0x000260 (0x000010)
    
    public: // Functions
        void    ServerDestroyARActor(AARActor* Actor); // 0x05F50C18 [Final | RequiredAPI | Net | NetReliable | Native | Event | Private | NetServer | NetValidate]
        void    ServerSpawnARActor(UClass* ComponentClass, FGuid NativeID); // 0x05F50DB2 [Final | RequiredAPI | Net | NetReliable | Native | Event | Private | NetServer | HasDefaults | NetValidate]
        void    InstanceARActorSpawnedDelegate(UClass* ComponentClass, FGuid NativeID, AARActor* SpawnedActor); // 0x000545D2 [MulticastDelegate | Public | Delegate | HasDefaults]
        void    InstanceARActorToBeDestroyedDelegate(AARActor* Actor); // 0x000545D2 [MulticastDelegate | Public | Delegate]
    };
    // Size: 0x000028 (0x000000)
    class UARLightEstimate : public UObject
    {
    public:
    };
    // Size: 0x000350 (0x000090)
    class alignas(0x8) UARMeshComponent : public UARComponent
    {
    public:
        FARMeshUpdatePayload    ReplicatedPayload;  // 0x0002C0 (0x000090)
    
    public: // Functions
        void    ReceiveAdd(FARMeshUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    ReceiveUpdate(FARMeshUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    ServerUpdatePayload(FARMeshUpdatePayload NewPayload); // 0x05F4B168 [RequiredAPI | Net | NetReliable | Native | Event | Protected | NetServer | NetValidate]
    };
    // Size: 0x000160 (0x000000)
    class UARMeshGeometry : public UARTrackedGeometry
    {
    public:
    
    public: // Functions
        bool    GetObjectClassificationAtLocation(FVector& InWorldLocation, EARObjectClassification& OutClassification, FVector& OutClassificationLocation, float MaxLocationDiff); // 0x05F566B8 [Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000320 (0x000060)
    class alignas(0x8) UARObjectComponent : public UARComponent
    {
    public:
        FARObjectUpdatePayload  ReplicatedPayload;  // 0x0002C0 (0x000060)
    
    public: // Functions
        void    ReceiveAdd(FARObjectUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    ReceiveUpdate(FARObjectUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    ServerUpdatePayload(FARObjectUpdatePayload NewPayload); // 0x05F4AFAE [RequiredAPI | Net | NetReliable | Native | Event | Protected | NetServer | NetValidate]
    };
    // Size: 0x000150 (0x000128)
    class alignas(0x8) UARPin : public UObject
    {
    public:
        UARTrackedGeometry*                             TrackedGeometry;                    // 0x000028 (0x000008) [Default: nullptr]
        USceneComponent*                                PinnedComponent;                    // 0x000030 (0x000008) [Default: nullptr]
        uint8                                           UnknownData_000038[0x000008];       // 0x000038 (0x000008)
        FTransform                                      LocalToTrackingTransform;           // 0x000040 (0x000060)
        FTransform                                      LocalToAlignedTrackingTransform;    // 0x0000A0 (0x000060)
        EARTrackingState                                TrackingState;                      // 0x000100 (0x000001) [Default: EARTrackingState(0)]
        uint8                                           UnknownData_000101[0x00001F];       // 0x000101 (0x00001F)
        MULTI_INLINE_DELEGATE(OnARTrackingStateChanged) OnARTrackingStateChanged;           // 0x000120 (0x000010)
        MULTI_INLINE_DELEGATE(OnARTransformUpdated)     OnARTransformUpdated;               // 0x000130 (0x000010)
        uint8                                           UnknownData_000140[0x000010];       // 0x000140 (0x000010)
    
    public: // Functions
        void                DebugDraw(UWorld* World, FLinearColor& Color, float Scale, float PersistForSeconds); // 0x05F51CB4 [RequiredAPI | Native | Public | HasOutParms | HasDefaults | Const]
        FName               GetDebugName(); // 0x0DAC62B2 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FTransform          GetLocalToTrackingTransform(); // 0x0F13FAFE [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        FTransform          GetLocalToWorldTransform(); // 0x0F13FB26 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        USceneComponent*    GetPinnedComponent(); // 0x0CA03BAC [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UARTrackedGeometry* GetTrackedGeometry(); // 0x0C98454A [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EARTrackingState    GetTrackingState(); // 0x0F13FCA8 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000390 (0x0000D0)
    class alignas(0x8) UARPlaneComponent : public UARComponent
    {
    public:
        FARPlaneUpdatePayload   ReplicatedPayload;  // 0x0002C0 (0x0000D0)
    
    public: // Functions
        static TMap<EARObjectClassification, FLinearColor> GetObjectClassificationDebugColors(); // 0x0F13BDCE [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        void                                        ReceiveAdd(FARPlaneUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void                                        ReceiveUpdate(FARPlaneUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void                                        ServerUpdatePayload(FARPlaneUpdatePayload NewPayload); // 0x05F49B2C [RequiredAPI | Net | NetReliable | Native | Event | Protected | NetServer | NetValidate]
        static void                                        SetObjectClassificationDebugColors(TMap<EARObjectClassification, FLinearColor>& InColors); // 0x05F49D26 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                                        SetPlaneComponentDebugMode(EPlaneComponentDebugMode NewDebugMode); // 0x05F49EB8 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x0001B0 (0x000050)
    class alignas(0x8) UARPlaneGeometry : public UARTrackedGeometry
    {
    public:
        EARPlaneOrientation orientation;                    // 0x000160 (0x000001) [Default: EARPlaneOrientation(0)]
        uint8               UnknownData_000161[0x000007];   // 0x000161 (0x000007)
        FVector             Center;                         // 0x000168 (0x000018)
        FVector             Extent;                         // 0x000180 (0x000018)
        TArray<FVector>     BoundaryPolygon;                // 0x000198 (0x000010)
        UARPlaneGeometry*   SubsumedBy;                     // 0x0001A8 (0x000008) [Default: nullptr]
    
    public: // Functions
        TArray<FVector>     GetBoundaryPolygonInLocalSpace(); // 0x0F140A8E [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FVector             GetCenter(); // 0x0F140B28 [Final | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        FVector             GetExtent(); // 0x0F140B50 [Final | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        EARPlaneOrientation GetOrientation(); // 0x0F140B78 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UARPlaneGeometry*   GetSubsumedBy(); // 0x0F140B92 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x0002D0 (0x000010)
    class UARPointComponent : public UARComponent
    {
    public:
        FARPointUpdatePayload   ReplicatedPayload;              // 0x0002C0 (0x000001)
        uint8                   UnknownData_0002C1[0x00000F];   // 0x0002C1 (0x00000F)
    
    public: // Functions
        void    ReceiveAdd(FARPointUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    ReceiveUpdate(FARPointUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    ServerUpdatePayload(FARPointUpdatePayload NewPayload); // 0x05F4A050 [RequiredAPI | Net | NetReliable | Native | Event | Protected | NetServer | NetValidate]
    };
    // Size: 0x000330 (0x000070)
    class alignas(0x8) UARPoseComponent : public UARComponent
    {
    public:
        FARPoseUpdatePayload    ReplicatedPayload;  // 0x0002C0 (0x000070)
    
    public: // Functions
        void    ReceiveAdd(FARPoseUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    ReceiveUpdate(FARPoseUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    ServerUpdatePayload(FARPoseUpdatePayload NewPayload); // 0x05F4AC40 [RequiredAPI | Net | NetReliable | Native | Event | Protected | NetServer | NetValidate]
        static void    SetPoseComponentDebugMode(EPoseComponentDebugMode NewDebugMode); // 0x05F4AE16 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000370 (0x0000B0)
    class alignas(0x8) UARQRCodeComponent : public UARComponent
    {
    public:
        FARQRCodeUpdatePayload  ReplicatedPayload;  // 0x0002C0 (0x0000B0)
    
    public: // Functions
        void    ReceiveAdd(FARQRCodeUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    ReceiveUpdate(FARQRCodeUpdatePayload& Payload); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    ServerUpdatePayload(FARQRCodeUpdatePayload NewPayload); // 0x05F4A8B8 [RequiredAPI | Net | NetReliable | Native | Event | Protected | NetServer | NetValidate]
        static void    SetQRCodeComponentDebugMode(EQRCodeComponentDebugMode NewDebugMode); // 0x05F4AAA8 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000080 (0x000030)
    class alignas(0x8) UARSaveWorldAsyncTaskBlueprintProxy : public UARBaseAsyncTaskBlueprintProxy
    {
    public:
        MULTI_INLINE_DELEGATE(ARSaveWorldPin)   OnSuccess;                      // 0x000050 (0x000010)
        MULTI_INLINE_DELEGATE(ARSaveWorldPin)   OnFailed;                       // 0x000060 (0x000010)
        uint8                                   UnknownData_000070[0x000010];   // 0x000070 (0x000010)
    
    public: // Functions
        static UARSaveWorldAsyncTaskBlueprintProxy*    ARSaveWorld(UObject* WorldContextObject); // 0x05F4942E [Final | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000108 (0x0000E0)
    class alignas(0x8) UARSessionConfig : public UDataAsset
    {
    public:
        bool                            bGenerateMeshDataFromTrackedGeometry;   // 0x000028 (0x000001) [Default: false]
        bool                            bGenerateCollisionForMeshData;          // 0x000029 (0x000001) [Default: false]
        bool                            bGenerateNavMeshForMeshData;            // 0x00002A (0x000001) [Default: false]
        bool                            bUseMeshDataForOcclusion;               // 0x00002B (0x000001) [Default: false]
        bool                            bRenderMeshDataInWireframe;             // 0x00002C (0x000001) [Default: false]
        bool                            bTrackSceneObjects;                     // 0x00002D (0x000001) [Default: true]
        bool                            bUsePersonSegmentationForOcclusion;     // 0x00002E (0x000001) [Default: true]
        bool                            bUseSceneDepthForOcclusion;             // 0x00002F (0x000001) [Default: false]
        bool                            bUseAutomaticImageScaleEstimation;      // 0x000030 (0x000001) [Default: true]
        bool                            bUseStandardOnboardingUX;               // 0x000031 (0x000001) [Default: false]
        EARWorldAlignment               WorldAlignment;                         // 0x000032 (0x000001) [Default: EARWorldAlignment(0)]
        EARSessionType                  SessionType;                            // 0x000033 (0x000001) [Default: EARSessionType(2)]
        EARPlaneDetectionMode           PlaneDetectionMode;                     // 0x000034 (0x000001) [Default: EARPlaneDetectionMode(1)]
        bool                            bHorizontalPlaneDetection;              // 0x000035 (0x000001) [Default: true]
        bool                            bVerticalPlaneDetection;                // 0x000036 (0x000001) [Default: true]
        bool                            bEnableAutoFocus;                       // 0x000037 (0x000001) [Default: true]
        EARLightEstimationMode          LightEstimationMode;                    // 0x000038 (0x000001) [Default: EARLightEstimationMode(1)]
        EARFrameSyncMode                FrameSyncMode;                          // 0x000039 (0x000001) [Default: EARFrameSyncMode(0)]
        bool                            bEnableAutomaticCameraOverlay;          // 0x00003A (0x000001) [Default: true]
        bool                            bEnableAutomaticCameraTracking;         // 0x00003B (0x000001) [Default: true]
        bool                            bResetCameraTracking;                   // 0x00003C (0x000001) [Default: true]
        bool                            bResetTrackedObjects;                   // 0x00003D (0x000001) [Default: true]
        uint8                           UnknownData_00003E[0x000002];           // 0x00003E (0x000002)
        TArray<UARCandidateImage*>      CandidateImages;                        // 0x000040 (0x000010)
        int32                           MaxNumSimultaneousImagesTracked;        // 0x000050 (0x000004) [Default: 1]
        EAREnvironmentCaptureProbeType  EnvironmentCaptureProbeType;            // 0x000054 (0x000001) [Default: EAREnvironmentCaptureProbeType(0)]
        uint8                           UnknownData_000055[0x000003];           // 0x000055 (0x000003)
        TArray<uint8>                   WorldMapData;                           // 0x000058 (0x000010)
        TArray<UARCandidateObject*>     CandidateObjects;                       // 0x000068 (0x000010)
        FARVideoFormat                  DesiredVideoFormat;                     // 0x000078 (0x00000C)
        bool                            bUseOptimalVideoFormat;                 // 0x000084 (0x000001) [Default: true]
        EARFaceTrackingDirection        FaceTrackingDirection;                  // 0x000085 (0x000001) [Default: EARFaceTrackingDirection(0)]
        EARFaceTrackingUpdate           FaceTrackingUpdate;                     // 0x000086 (0x000001) [Default: EARFaceTrackingUpdate(0)]
        uint8                           UnknownByte_000087;                     // 0x000087 (0x000001)
        int32                           MaxNumberOfTrackedFaces;                // 0x000088 (0x000004) [Default: 1]
        uint8                           UnknownData_00008C[0x000004];           // 0x00008C (0x000004)
        TArray<uint8>                   SerializedARCandidateImageDatabase;     // 0x000090 (0x000010)
        EARSessionTrackingFeature       EnabledSessionTrackingFeature;          // 0x0000A0 (0x000001) [Default: EARSessionTrackingFeature(0)]
        EARSceneReconstruction          SceneReconstructionMethod;              // 0x0000A1 (0x000001) [Default: EARSceneReconstruction(0)]
        uint8                           UnknownData_0000A2[0x000006];           // 0x0000A2 (0x000006)
        UClass*                         PlaneComponentClass;                    // 0x0000A8 (0x000008) [Default: 0x17A7F2B0]
        UClass*                         PointComponentClass;                    // 0x0000B0 (0x000008) [Default: 0x17A7F900]
        UClass*                         FaceComponentClass;                     // 0x0000B8 (0x000008) [Default: 0x17A80440]
        UClass*                         ImageComponentClass;                    // 0x0000C0 (0x000008) [Default: 0x17A80D00]
        UClass*                         QRCodeComponentClass;                   // 0x0000C8 (0x000008) [Default: 0x17A94D10]
        UClass*                         PoseComponentClass;                     // 0x0000D0 (0x000008) [Default: 0x17A81E80]
        UClass*                         EnvironmentProbeComponentClass;         // 0x0000D8 (0x000008) [Default: 0x17A824D0]
        UClass*                         ObjectComponentClass;                   // 0x0000E0 (0x000008) [Default: 0x17A82B20]
        UClass*                         MeshComponentClass;                     // 0x0000E8 (0x000008) [Default: 0x17A83170]
        UClass*                         GeoAnchorComponentClass;                // 0x0000F0 (0x000008) [Default: 0x17A83A30]
        UMaterialInterface*             DefaultMeshMaterial;                    // 0x0000F8 (0x000008) [Default: 0x7FE838190EE8]
        UMaterialInterface*             DefaultWireframeMeshMaterial;           // 0x000100 (0x000008) [Default: 0x7FE838190EE8]
    
    public: // Functions
        void                            AddCandidateImage(UARCandidateImage* NewCandidateImage); // 0x05F5268C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            AddCandidateObject(UARCandidateObject* CandidateObject); // 0x05F5281C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            ClearCandidateImages(); // 0x0F13FE1C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        TArray<UARCandidateImage*>      GetCandidateImageList(); // 0x0F13FE6E [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<UARCandidateObject*>     GetCandidateObjectList(); // 0x0F13FE8A [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FARVideoFormat                  GetDesiredVideoFormat(); // 0x0F13FEA6 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EARSessionTrackingFeature       GetEnabledSessionTrackingFeature(); // 0x0F13FEC8 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EAREnvironmentCaptureProbeType  GetEnvironmentCaptureProbeType(); // 0x0F13FEE2 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EARFaceTrackingDirection        GetFaceTrackingDirection(); // 0x0F13FEFA [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EARFaceTrackingUpdate           GetFaceTrackingUpdate(); // 0x0F13FF14 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EARFrameSyncMode                GetFrameSyncMode(); // 0x0F13FF2E [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EARLightEstimationMode          GetLightEstimationMode(); // 0x0F13FF46 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32                           GetMaxNumSimultaneousImagesTracked(); // 0x0F13FF5E [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EARPlaneDetectionMode           GetPlaneDetectionMode(); // 0x0F13FF76 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EARSceneReconstruction          GetSceneReconstructionMethod(); // 0x0F13FF92 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EARSessionType                  GetSessionType(); // 0x0F13FFAC [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EARWorldAlignment               GetWorldAlignment(); // 0x0F13FFC4 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<uint8>                   GetWorldMapData(); // 0x0F13FFDC [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                            RemoveCandidateImage(UARCandidateImage* CandidateImage); // 0x05F529B0 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            RemoveCandidateImageAtIndex(int32 Index); // 0x05F52B1E [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            SetCandidateObjectList(TArray<UARCandidateObject*>& InCandidateObjects); // 0x05F52D26 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                            SetDesiredVideoFormat(FARVideoFormat NewFormat); // 0x05F52EC0 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            SetEnableAutoFocus(bool bNewValue); // 0x05F53040 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            SetFaceTrackingDirection(EARFaceTrackingDirection InDirection); // 0x05F531AC [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            SetFaceTrackingUpdate(EARFaceTrackingUpdate InUpdate); // 0x05F53316 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            SetResetCameraTracking(bool bNewValue); // 0x05F53480 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            SetResetTrackedObjects(bool bNewValue); // 0x05F535EC [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            SetSceneReconstructionMethod(EARSceneReconstruction InSceneReconstructionMethod); // 0x05F53758 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            SetSessionTrackingFeatureToEnable(EARSessionTrackingFeature InSessionTrackingFeature); // 0x05F538C2 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            SetWorldMapData(TArray<uint8> WorldMapData); // 0x05F53A2C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        bool                            ShouldEnableAutoFocus(); // 0x0F140052 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                            ShouldEnableCameraTracking(); // 0x0F14006A [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                            ShouldRenderCameraOverlay(); // 0x0F140082 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                            ShouldResetCameraTracking(); // 0x0F14009A [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                            ShouldResetTrackedObjects(); // 0x0F1400B2 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000140 (0x000020)
    class alignas(0x8) UARTexture : public UTexture
    {
    public:
        EARTextureType  TextureType;                    // 0x000120 (0x000001) [Default: EARTextureType(0)]
        uint8           UnknownData_000121[0x000003];   // 0x000121 (0x000003)
        float           Timestamp;                      // 0x000124 (0x000004) [Default: 0f]
        FGuid           ExternalTextureGuid;            // 0x000128 (0x000010)
        FVector2f       Size;                           // 0x000138 (0x000008)
    };
    // Size: 0x000148 (0x000008)
    class UARTextureCameraDepth : public UARTexture
    {
    public:
        EARDepthQuality     DepthQuality;                   // 0x000140 (0x000001) [Default: EARDepthQuality(0)]
        EARDepthAccuracy    DepthAccuracy;                  // 0x000141 (0x000001) [Default: EARDepthAccuracy(0)]
        bool                bIsTemporallySmoothed;          // 0x000142 (0x000001) [Default: false]
        uint8               UnknownData_000143[0x000005];   // 0x000143 (0x000005)
    };
    // Size: 0x000140 (0x000000)
    class UARTextureCameraImage : public UARTexture
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class UARTraceResultDummy : public UObject
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class UARTraceResultLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static float                   GetDistanceFromCamera(FARTraceResult& TraceResult); // 0x05F484A8 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FTransform              GetLocalToTrackingTransform(FARTraceResult& TraceResult); // 0x05F486B0 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        static FTransform              GetLocalToWorldTransform(FARTraceResult& TraceResult); // 0x05F48BF2 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        static FTransform              GetLocalTransform(FARTraceResult& TraceResult); // 0x05F48E24 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        static EARLineTraceChannels    GetTraceChannel(FARTraceResult& TraceResult); // 0x05F49024 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static UARTrackedGeometry*     GetTrackedGeometry(FARTraceResult& TraceResult); // 0x05F49228 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
    };
    // Size: 0x000210 (0x000150)
    class alignas(0x8) UARTrackableNotifyComponent : public UActorComponent
    {
    public:
        MULTI_INLINE_DELEGATE(TrackableDelegate)            OnAddTrackedGeometry;       // 0x0000C0 (0x000010)
        MULTI_INLINE_DELEGATE(TrackableDelegate)            OnUpdateTrackedGeometry;    // 0x0000D0 (0x000010)
        MULTI_INLINE_DELEGATE(TrackableDelegate)            OnRemoveTrackedGeometry;    // 0x0000E0 (0x000010)
        MULTI_INLINE_DELEGATE(TrackablePlaneDelegate)       OnAddTrackedPlane;          // 0x0000F0 (0x000010)
        MULTI_INLINE_DELEGATE(TrackablePlaneDelegate)       OnUpdateTrackedPlane;       // 0x000100 (0x000010)
        MULTI_INLINE_DELEGATE(TrackablePlaneDelegate)       OnRemoveTrackedPlane;       // 0x000110 (0x000010)
        MULTI_INLINE_DELEGATE(TrackablePointDelegate)       OnAddTrackedPoint;          // 0x000120 (0x000010)
        MULTI_INLINE_DELEGATE(TrackablePointDelegate)       OnUpdateTrackedPoint;       // 0x000130 (0x000010)
        MULTI_INLINE_DELEGATE(TrackablePointDelegate)       OnRemoveTrackedPoint;       // 0x000140 (0x000010)
        MULTI_INLINE_DELEGATE(TrackableImageDelegate)       OnAddTrackedImage;          // 0x000150 (0x000010)
        MULTI_INLINE_DELEGATE(TrackableImageDelegate)       OnUpdateTrackedImage;       // 0x000160 (0x000010)
        MULTI_INLINE_DELEGATE(TrackableImageDelegate)       OnRemoveTrackedImage;       // 0x000170 (0x000010)
        MULTI_INLINE_DELEGATE(TrackableFaceDelegate)        OnAddTrackedFace;           // 0x000180 (0x000010)
        MULTI_INLINE_DELEGATE(TrackableFaceDelegate)        OnUpdateTrackedFace;        // 0x000190 (0x000010)
        MULTI_INLINE_DELEGATE(TrackableFaceDelegate)        OnRemoveTrackedFace;        // 0x0001A0 (0x000010)
        MULTI_INLINE_DELEGATE(TrackableEnvProbeDelegate)    OnAddTrackedEnvProbe;       // 0x0001B0 (0x000010)
        MULTI_INLINE_DELEGATE(TrackableEnvProbeDelegate)    OnUpdateTrackedEnvProbe;    // 0x0001C0 (0x000010)
        MULTI_INLINE_DELEGATE(TrackableEnvProbeDelegate)    OnRemoveTrackedEnvProbe;    // 0x0001D0 (0x000010)
        MULTI_INLINE_DELEGATE(TrackableObjectDelegate)      OnAddTrackedObject;         // 0x0001E0 (0x000010)
        MULTI_INLINE_DELEGATE(TrackableObjectDelegate)      OnUpdateTrackedObject;      // 0x0001F0 (0x000010)
        MULTI_INLINE_DELEGATE(TrackableObjectDelegate)      OnRemoveTrackedObject;      // 0x000200 (0x000010)
    };
    // Size: 0x000160 (0x000138)
    class alignas(0x8) UARTrackedGeometry : public UObject
    {
    public:
        FGuid                       UniqueID;                           // 0x000028 (0x000010)
        uint8                       UnknownData_000038[0x000008];       // 0x000038 (0x000008)
        FTransform                  LocalToTrackingTransform;           // 0x000040 (0x000060)
        FTransform                  LocalToAlignedTrackingTransform;    // 0x0000A0 (0x000060)
        EARTrackingState            TrackingState;                      // 0x000100 (0x000001) [Default: EARTrackingState(1)]
        uint8                       UnknownData_000101[0x00000F];       // 0x000101 (0x00000F)
        UMRMeshComponent*           UnderlyingMesh;                     // 0x000110 (0x000008) [Default: nullptr]
        EARObjectClassification     ObjectClassification;               // 0x000118 (0x000001) [Default: EARObjectClassification(0)]
        EARSpatialMeshUsageFlags    SpatialMeshUsageFlags;              // 0x000119 (0x000001) [Default: EARSpatialMeshUsageFlags(0)]
        uint8                       UnknownData_00011A[0x000016];       // 0x00011A (0x000016)
        int32                       LastUpdateFrameNumber;              // 0x000130 (0x000004) [Default: 0]
        uint8                       UnknownData_000134[0x00000C];       // 0x000134 (0x00000C)
        FName                       DebugName;                          // 0x000140 (0x000004) [Default: NAME_None]
        uint8                       UnknownData_000144[0x00001C];       // 0x000144 (0x00001C)
    
    public: // Functions
        FName                   GetDebugName(); // 0x0F14098A [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32                   GetLastUpdateFrameNumber(); // 0x0F1409A4 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float                   GetLastUpdateTimestamp(); // 0x0F1409BE [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FTransform              GetLocalToTrackingTransform(); // 0x0F13FAFE [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        FTransform              GetLocalToWorldTransform(); // 0x0F1409DC [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
        FString                 GetName(); // 0x0F140A52 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EARObjectClassification GetObjectClassification(); // 0x0E1B8F2E [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EARTrackingState        GetTrackingState(); // 0x0F13FCA8 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UMRMeshComponent*       GetUnderlyingMesh(); // 0x0E1B8F12 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure]
        bool                    HasSpatialMeshUsageFlag(EARSpatialMeshUsageFlags InFlag); // 0x05F560B2 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                    IsTracked(); // 0x0F140A72 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000180 (0x000020)
    class alignas(0x8) UARTrackedImage : public UARTrackedGeometry
    {
    public:
        UARCandidateImage*  DetectedImage;                  // 0x000160 (0x000008) [Default: nullptr]
        FVector2D           EstimatedSize;                  // 0x000168 (0x000010)
        uint8               UnknownData_000178[0x000008];   // 0x000178 (0x000008)
    
    public: // Functions
        UARCandidateImage*  GetDetectedImage(); // 0x0F140BAE [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FVector2D           GetEstimateSize(); // 0x0F140BCA [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure]
    };
    // Size: 0x000170 (0x000010)
    class alignas(0x8) UARTrackedObject : public UARTrackedGeometry
    {
    public:
        UARCandidateObject* DetectedObject;                 // 0x000160 (0x000008) [Default: nullptr]
        uint8               UnknownData_000168[0x000008];   // 0x000168 (0x000008)
    
    public: // Functions
        UARCandidateObject* GetDetectedObject(); // 0x0F140BAE [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000160 (0x000000)
    class UARTrackedPoint : public UARTrackedGeometry
    {
    public:
    };
    // Size: 0x0001B0 (0x000050)
    class alignas(0x8) UARTrackedPose : public UARTrackedGeometry
    {
    public:
        FARPose3D   TrackedPose;    // 0x000160 (0x000050)
    
    public: // Functions
        FARPose3D   GetTrackedPoseData(); // 0x0F140DEC [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x0001A0 (0x000020)
    class alignas(0x8) UARTrackedQRCode : public UARTrackedImage
    {
    public:
        FString QRCode;                         // 0x000180 (0x000010) [Default: L""]
        int32   Version;                        // 0x000190 (0x000004) [Default: 0]
        uint8   UnknownData_000194[0x00000C];   // 0x000194 (0x00000C)
    };
    // Size: 0x000028 (0x000000)
    class UARTypesDummyClass : public UObject
    {
    public:
    };
    // Size: 0x0000A0 (0x000050)
    class alignas(0x8) UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy : public UARBaseAsyncTaskBlueprintProxy
    {
    public:
        MULTI_INLINE_DELEGATE(GeoTrackingAvailabilityDelegate)  OnSuccess;                      // 0x000050 (0x000010)
        MULTI_INLINE_DELEGATE(GeoTrackingAvailabilityDelegate)  OnFailed;                       // 0x000060 (0x000010)
        uint8                                                   UnknownData_000070[0x000030];   // 0x000070 (0x000030)
    
    public: // Functions
        static UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy*   CheckGeoTrackingAvailability(UObject* WorldContextObject); // 0x05F503FE [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy*   CheckGeoTrackingAvailabilityAtLocation(UObject* WorldContextObject, float Longitude, float Latitude); // 0x05F50588 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        void                                                    GeoTrackingAvailabilityDelegate(bool bIsAvailable, FString Error); // 0x000545D2 [MulticastDelegate | Public | Delegate]
    };
    // Size: 0x0000A8 (0x000058)
    class alignas(0x8) UGetGeoLocationAsyncTaskBlueprintProxy : public UARBaseAsyncTaskBlueprintProxy
    {
    public:
        MULTI_INLINE_DELEGATE(GetGeoLocationDelegate)   OnSuccess;                      // 0x000050 (0x000010)
        MULTI_INLINE_DELEGATE(GetGeoLocationDelegate)   OnFailed;                       // 0x000060 (0x000010)
        uint8                                           UnknownData_000070[0x000038];   // 0x000070 (0x000038)
    
    public: // Functions
        static UGetGeoLocationAsyncTaskBlueprintProxy* GetGeoLocationAtWorldPosition(UObject* WorldContextObject, FVector& WorldPosition); // 0x05F5095C [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        void                                    GetGeoLocationDelegate(float Longitude, float Latitude, float Altitude, FString Error); // 0x000545D2 [MulticastDelegate | Public | Delegate]
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FARCameraIntrinsics
    {
        FIntPoint   ImageResolution;    // 0x000000 (0x000008)
        FVector2D   FocalLength;        // 0x000008 (0x000010)
        FVector2D   PrincipalPoint;     // 0x000018 (0x000010)
    };
    // Size: 0x000060 (0x000060)
    struct alignas(0x8) FAREnvironmentProbeUpdatePayload
    {
        FTransform  WorldTransform; // 0x000000 (0x000060)
    };
    // Size: 0x000060 (0x000060)
    struct alignas(0x8) FARFaceUpdatePayload
    {
        FARSessionPayload   SessionPayload;     // 0x000000 (0x000018)
        FVector             LeftEyePosition;    // 0x000018 (0x000018)
        FVector             RightEyePosition;   // 0x000030 (0x000018)
        FVector             LookAtTarget;       // 0x000048 (0x000018)
    };
    // Size: 0x0000A0 (0x0000A0)
    struct alignas(0x8) FARGeoAnchorUpdatePayload
    {
        FARSessionPayload   SessionPayload;                 // 0x000000 (0x000018)
        uint8               UnknownData_000018[0x000008];   // 0x000018 (0x000008)
        FTransform          WorldTransform;                 // 0x000020 (0x000060)
        float               Longitude;                      // 0x000080 (0x000004)
        float               Latitude;                       // 0x000084 (0x000004)
        float               AltitudeMeters;                 // 0x000088 (0x000004)
        EARAltitudeSource   AltitudeSource;                 // 0x00008C (0x000001)
        uint8               UnknownData_00008D[0x000003];   // 0x00008D (0x000003)
        FString             AnchorName;                     // 0x000090 (0x000010)
    };
    // Size: 0x0000A0 (0x0000A0)
    struct alignas(0x8) FARImageUpdatePayload
    {
        FARSessionPayload   SessionPayload;                 // 0x000000 (0x000018)
        uint8               UnknownData_000018[0x000008];   // 0x000018 (0x000008)
        FTransform          WorldTransform;                 // 0x000020 (0x000060)
        UARCandidateImage*  DetectedImage;                  // 0x000080 (0x000008)
        FVector2D           EstimatedSize;                  // 0x000088 (0x000010)
        uint8               UnknownData_000098[0x000008];   // 0x000098 (0x000008)
    };
    // Size: 0x000090 (0x000090)
    struct alignas(0x8) FARMeshUpdatePayload
    {
        FARSessionPayload       SessionPayload;                 // 0x000000 (0x000018)
        uint8                   UnknownData_000018[0x000008];   // 0x000018 (0x000008)
        FTransform              WorldTransform;                 // 0x000020 (0x000060)
        EARObjectClassification ObjectClassification;           // 0x000080 (0x000001)
        uint8                   UnknownData_000081[0x00000F];   // 0x000081 (0x00000F)
    };
    // Size: 0x000060 (0x000060)
    struct alignas(0x8) FARObjectUpdatePayload
    {
        FTransform  WorldTransform; // 0x000000 (0x000060)
    };
    // Size: 0x0000D0 (0x0000D0)
    struct alignas(0x8) FARPlaneUpdatePayload
    {
        FARSessionPayload       SessionPayload;                 // 0x000000 (0x000018)
        uint8                   UnknownData_000018[0x000008];   // 0x000018 (0x000008)
        FTransform              WorldTransform;                 // 0x000020 (0x000060)
        FVector                 Center;                         // 0x000080 (0x000018)
        FVector                 Extents;                        // 0x000098 (0x000018)
        TArray<FVector>         BoundaryVertices;               // 0x0000B0 (0x000010)
        EARObjectClassification ObjectClassification;           // 0x0000C0 (0x000001) [Default: EARObjectClassification(1)]
        uint8                   UnknownData_0000C1[0x00000F];   // 0x0000C1 (0x00000F)
    };
    // Size: 0x000001 (0x000001)
    struct FARPointUpdatePayload
    {
        uint8   UnknownByte_000000; // 0x000000 (0x000001)
    };
    // Size: 0x000048 (0x000048)
    struct alignas(0x8) FARPose2D
    {
        FARSkeletonDefinition   SkeletonDefinition; // 0x000000 (0x000028)
        TArray<FVector2D>       JointLocations;     // 0x000028 (0x000010)
        TArray<bool>            IsJointTracked;     // 0x000038 (0x000010)
    };
    // Size: 0x000050 (0x000050)
    struct alignas(0x8) FARPose3D
    {
        FARSkeletonDefinition   SkeletonDefinition;             // 0x000000 (0x000028)
        TArray<FTransform>      JointTransforms;                // 0x000028 (0x000010)
        TArray<bool>            IsJointTracked;                 // 0x000038 (0x000010)
        EARJointTransformSpace  JointTransformSpace;            // 0x000048 (0x000001)
        uint8                   UnknownData_000049[0x000007];   // 0x000049 (0x000007)
    };
    // Size: 0x000070 (0x000070)
    struct alignas(0x8) FARPoseUpdatePayload
    {
        FTransform          WorldTransform;     // 0x000000 (0x000060)
        TArray<FTransform>  JointTransforms;    // 0x000060 (0x000010)
    };
    // Size: 0x0000B0 (0x0000B0)
    struct alignas(0x8) FARQRCodeUpdatePayload
    {
        FARSessionPayload   SessionPayload;                 // 0x000000 (0x000018)
        uint8               UnknownData_000018[0x000008];   // 0x000018 (0x000008)
        FTransform          WorldTransform;                 // 0x000020 (0x000060)
        FVector             Extents;                        // 0x000080 (0x000018)
        FString             QRCode;                         // 0x000098 (0x000010)
        uint8               UnknownData_0000A8[0x000008];   // 0x0000A8 (0x000008)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FARSessionPayload
    {
        int32               ConfigFlags;                    // 0x000000 (0x000004)
        uint8               UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UMaterialInterface* DefaultMeshMaterial;            // 0x000008 (0x000008)
        UMaterialInterface* DefaultWireframeMeshMaterial;   // 0x000010 (0x000008)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FARSessionStatus
    {
        FString             AdditionalInfo;                 // 0x000000 (0x000010)
        EARSessionStatus    Status;                         // 0x000010 (0x000001)
        uint8               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FARSharedWorldReplicationState
    {
        int32   PreviewImageOffset; // 0x000000 (0x000004)
        int32   ARWorldOffset;      // 0x000004 (0x000004)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FARSkeletonDefinition
    {
        int32           NumJoints;                      // 0x000000 (0x000004)
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FName>   JointNames;                     // 0x000008 (0x000010)
        TArray<int32>   ParentIndices;                  // 0x000018 (0x000010)
    };
    // Size: 0x000090 (0x000090)
    struct alignas(0x8) FARTraceResult
    {
        float                   DistanceFromCamera;             // 0x000000 (0x000004) [Default: 0f]
        EARLineTraceChannels    TraceChannel;                   // 0x000004 (0x000001) [Default: EARLineTraceChannels(0)]
        uint8                   UnknownData_000005[0x00000B];   // 0x000005 (0x00000B)
        FTransform              LocalTransform;                 // 0x000010 (0x000060)
        UARTrackedGeometry*     TrackedGeometry;                // 0x000070 (0x000008) [Default: nullptr]
        uint8                   UnknownData_000078[0x000018];   // 0x000078 (0x000018)
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FARVideoFormat
    {
        int32   FPS;    // 0x000000 (0x000004)
        int32   Width;  // 0x000004 (0x000004)
        int32   Height; // 0x000008 (0x000004)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FTrackedGeometryGroup
    {
        AARActor*           ARActor;            // 0x000000 (0x000008)
        UARComponent*       ARComponent;        // 0x000008 (0x000008)
        UARTrackedGeometry* TrackedGeometry;    // 0x000010 (0x000008)
    };
}

