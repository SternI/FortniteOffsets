/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioGameplayVolume_Functions
 * ============================================================
 */

#include "AudioGameplayVolume.hpp"

namespace UE
{

    struct AAudioGameplayVolume___SetEnabled_Params
    {
        bool    bEnable;    // 0x000000 (0x000001) [Default: true]
    };

    struct UAttenuationVolumeComponent___SetExteriorVolume_Params
    {
        float   Volume;             // 0x000000 (0x000004) [Default: 2.97219e-27f]
        float   InterpolateTime;    // 0x000004 (0x000004) [Default: 0f]
    };

    struct UAttenuationVolumeComponent___SetInteriorVolume_Params
    {
        float   Volume;             // 0x000000 (0x000004) [Default: 2.97219e-27f]
        float   InterpolateTime;    // 0x000004 (0x000004) [Default: 0f]
    };

    struct UAudioGameplayVolumeMutator___SetPriority_Params
    {
        int32   InPriority; // 0x000000 (0x000004) [Default: 325816848]
    };

    struct UFilterVolumeComponent___SetExteriorLPF_Params
    {
        float   Volume;             // 0x000000 (0x000004) [Default: 2.97386e-27f]
        float   InterpolateTime;    // 0x000004 (0x000004) [Default: 0f]
    };

    struct UFilterVolumeComponent___SetInteriorLPF_Params
    {
        float   Volume;             // 0x000000 (0x000004) [Default: 2.97386e-27f]
        float   InterpolateTime;    // 0x000004 (0x000004) [Default: 0f]
    };

    struct UReverbVolumeComponent___SetReverbSettings_Params
    {
        FReverbSettings NewReverbSettings;  // 0x000000 (0x000020) [OutParam]
    };

    struct USubmixOverrideVolumeComponent___SetSubmixOverrideSettings_Params
    {
        TArray<FAudioVolumeSubmixOverrideSettings>  NewSubmixOverrideSettings;  // 0x000000 (0x000010) [OutParam]
    };

    struct USubmixSendVolumeComponent___SetSubmixSendSettings_Params
    {
        TArray<FAudioVolumeSubmixSendSettings>  NewSubmixSendSettings;  // 0x000000 (0x000010) [OutParam]
    };

} // namespace UE

