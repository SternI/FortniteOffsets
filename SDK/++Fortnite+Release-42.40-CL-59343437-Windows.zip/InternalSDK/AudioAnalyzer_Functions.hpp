/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioAnalyzer_Functions
 * ============================================================
 */

#include "AudioAnalyzer.hpp"

namespace UE
{

    struct UAudioAnalyzer___StartAnalyzing_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x148F0D00]
        UAudioBus*  AudioBusToAnalyze;  // 0x000008 (0x000008) [Default: 0xBC5D18DD00000031]
    };

    struct UAudioAnalyzer___StopAnalyzing_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x148F0D00]
    };

} // namespace UE

