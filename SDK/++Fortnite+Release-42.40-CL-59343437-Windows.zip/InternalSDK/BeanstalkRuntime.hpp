/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BeanstalkRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x006240 (0x000360)
    class alignas(0x8) ABeanCharacter : public AFortStandInPlayerPawn
    {
    public:
        void**                                          VTable_005EE0;                      // 0x005EE0 (0x000008) VTable [9 slots] -> 0x1475E540
        UFortAbilitySet*                                AbilitySet;                         // 0x005EE8 (0x000008) [Default: nullptr]
        UBeanCharAnimInstance*                          AnimInstance;                       // 0x005EF0 (0x000008) [Default: nullptr]
        UMotionWarpingComponent*                        MotionWarpingComponent;             // 0x005EF8 (0x000008) [Default: 0x7FE838B08FB8]
        UClass*                                         ConfigurationClass;                 // 0x005F00 (0x000008) [Default: nullptr]
        UInputMappingContext*                           DefaultMappingContext;              // 0x005F08 (0x000008) [Default: nullptr]
        UInputAction*                                   DiveAction;                         // 0x005F10 (0x000008) [Default: nullptr]
        UInputAction*                                   GrabAction;                         // 0x005F18 (0x000008) [Default: nullptr]
        FGameplayTag                                    JumpButtonDiveIconOverrideTag;      // 0x005F20 (0x000004)
        uint8                                           UnknownData_005F24[0x00002C];       // 0x005F24 (0x00002C)
        UBeanCharMovementComponent*                     MovementComponent;                  // 0x005F50 (0x000008) [Default: nullptr]
        UBeanJiggleMotionComponent*                     JiggleComponent;                    // 0x005F58 (0x000008) [Default: 0x7FE838B0ABD8]
        uint8                                           UnknownData_005F60[0x000018];       // 0x005F60 (0x000018)
        UBeanCharStateMachine*                          StateMachine;                       // 0x005F78 (0x000008) [Default: 0x7FE838B0A580]
        UBeanStreamingManager*                          BeanStreamManager;                  // 0x005F80 (0x000008) [Default: nullptr]
        uint8                                           bPressedDive : 1;                   // 0x005F88 (0x000001) : 0x0 [Default: false]
        uint8                                           UnknownBit_005F88_1 : 1;            // 0x005F88 (0x000001) : 0x1
        uint8                                           UnknownBit_005F88_2 : 1;            // 0x005F88 (0x000001) : 0x2
        uint8                                           UnknownBit_005F88_3 : 1;            // 0x005F88 (0x000001) : 0x3
        uint8                                           UnknownBit_005F88_4 : 1;            // 0x005F88 (0x000001) : 0x4
        uint8                                           UnknownBit_005F88_5 : 1;            // 0x005F88 (0x000001) : 0x5
        uint8                                           UnknownBit_005F88_6 : 1;            // 0x005F88 (0x000001) : 0x6
        uint8                                           UnknownBit_005F88_7 : 1;            // 0x005F88 (0x000001) : 0x7
        uint8                                           UnknownData_005F89[0x00002F];       // 0x005F89 (0x00002F)
        UBeanCameraModeOverrideComponent*               BeanCameraModeOverrideComponent;    // 0x005FB8 (0x000008) [Default: 0x7FE838B0A878]
        UBeanParticleSystemsComponent*                  ParticleSystemsComponent;           // 0x005FC0 (0x000008) [Default: 0x7FE838B091B0]
        UBeanCharGrabComponent*                         GrabComponent;                      // 0x005FC8 (0x000008) [Default: 0x7FE838B09458]
        UBeanCharBeingGrabbedComponent*                 BeingGrabbedComponent;              // 0x005FD0 (0x000008) [Default: 0x7FE838B09748]
        FGameplayTag                                    GrabFeatureEnabledTag;              // 0x005FD8 (0x000004)
        uint8                                           bPressingGrab : 1;                  // 0x005FDC (0x000001) : 0x0 [Default: false]
        uint8                                           UnknownBit_005FDC_1 : 1;            // 0x005FDC (0x000001) : 0x1
        uint8                                           UnknownBit_005FDC_2 : 1;            // 0x005FDC (0x000001) : 0x2
        uint8                                           UnknownBit_005FDC_3 : 1;            // 0x005FDC (0x000001) : 0x3
        uint8                                           UnknownBit_005FDC_4 : 1;            // 0x005FDC (0x000001) : 0x4
        uint8                                           UnknownBit_005FDC_5 : 1;            // 0x005FDC (0x000001) : 0x5
        uint8                                           UnknownBit_005FDC_6 : 1;            // 0x005FDC (0x000001) : 0x6
        uint8                                           UnknownBit_005FDC_7 : 1;            // 0x005FDC (0x000001) : 0x7
        uint8                                           UnknownData_005FDD[0x000003];       // 0x005FDD (0x000003)
        UBeanCharMantleComponent*                       MantleComponent;                    // 0x005FE0 (0x000008) [Default: 0x7FE838B0AF68]
        uint8                                           bWantsToMantle : 1;                 // 0x005FE8 (0x000001) : 0x0 [Default: false]
        uint8                                           UnknownBit_005FE8_1 : 1;            // 0x005FE8 (0x000001) : 0x1
        uint8                                           UnknownBit_005FE8_2 : 1;            // 0x005FE8 (0x000001) : 0x2
        uint8                                           UnknownBit_005FE8_3 : 1;            // 0x005FE8 (0x000001) : 0x3
        uint8                                           UnknownBit_005FE8_4 : 1;            // 0x005FE8 (0x000001) : 0x4
        uint8                                           UnknownBit_005FE8_5 : 1;            // 0x005FE8 (0x000001) : 0x5
        uint8                                           UnknownBit_005FE8_6 : 1;            // 0x005FE8 (0x000001) : 0x6
        uint8                                           UnknownBit_005FE8_7 : 1;            // 0x005FE8 (0x000001) : 0x7
        uint8                                           UnknownData_005FE9[0x00000F];       // 0x005FE9 (0x00000F)
        UBeanCharRagdollComponent*                      RagdollComponent;                   // 0x005FF8 (0x000008) [Default: 0x7FE838B09F10]
        UPhysicsConstraintComponent*                    RagdollPhysicsConstraint;           // 0x006000 (0x000008) [Default: 0x7FE838B08970]
        UCapsuleComponent*                              RagdollRootCapsule;                 // 0x006008 (0x000008) [Default: 0x7FE838B083D0]
        float                                           CapsuleUnscaledHalfHeight;          // 0x006010 (0x000004) [Default: 57f]
        uint8                                           UnknownData_006014[0x000004];       // 0x006014 (0x000004)
        UBeanCharCollisionManagerComponent*             CollisionManagerComponent;          // 0x006018 (0x000008) [Default: 0x7FE838B09990]
        uint8                                           UnknownData_006020[0x000010];       // 0x006020 (0x000010)
        UInteractSelection_Base*                        PushedInteractionSelection;         // 0x006030 (0x000008) [Default: nullptr]
        uint8                                           UnknownData_006038[0x000030];       // 0x006038 (0x000030)
        TSoftObjectPtr<UAnimMontage>                    MantleAnimationMontage;             // 0x006068 (0x000020) [Default: nullptr]
        TSoftObjectPtr<UAnimMontage>                    GetupAnimationMontage_Front;        // 0x006088 (0x000020) [Default: nullptr]
        TSoftObjectPtr<UAnimMontage>                    GetupAnimationMontage_Left;         // 0x0060A8 (0x000020) [Default: nullptr]
        TSoftObjectPtr<UAnimMontage>                    GetupAnimationMontage_Right;        // 0x0060C8 (0x000020) [Default: nullptr]
        TSoftObjectPtr<UAnimMontage>                    GetupAnimationMontage_Back;         // 0x0060E8 (0x000020) [Default: nullptr]
        TSoftObjectPtr<UAnimMontage>                    LandStaggerAnimationMontage;        // 0x006108 (0x000020) [Default: nullptr]
        TSoftObjectPtr<UAnimMontage>                    LandStaggerAnimationMontageAlt;     // 0x006128 (0x000020) [Default: nullptr]
        TSoftObjectPtr<UBeanCosmeticBackpackAllowList>  BackpackAllowList;                  // 0x006148 (0x000020) [Default: nullptr]
        bool                                            bCharacterCosmeticsVisibility;      // 0x006168 (0x000001) [Default: true]
        bool                                            bBackpackCosmeticsVisibility;       // 0x006169 (0x000001) [Default: true]
        uint8                                           UnknownData_00616A[0x000006];       // 0x00616A (0x000006)
        FGameplayTagContainer                           IdleBreakBlockingTags;              // 0x006170 (0x000020)
        bool                                            bEnableInventoryMode;               // 0x006190 (0x000001) [Default: false]
        uint8                                           UnknownData_006191[0x000007];       // 0x006191 (0x000007)
        USkeletalMeshComponent*                         RetargetSourceMesh;                 // 0x006198 (0x000008) [Default: nullptr]
        uint8                                           UnknownData_0061A0[0x0000A0];       // 0x0061A0 (0x0000A0)
    
    public: // Functions
        void                                BP_OnBeanLocalInteractFailed(AActor* Interactable); // 0x000545D2 [RequiredAPI | Event | Public | BlueprintEvent]
        void                                Client_OnTeleport(FVector Location, FRotator Rotation); // 0x080B7C00 [RequiredAPI | Net | NetReliable | Native | Event | Protected | HasDefaults | NetClient]
        void                                Client_TeleportSucceeded(); // 0x10DF6CD4 [RequiredAPI | Net | NetReliable | Native | Event | Protected | NetClient]
        void                                Debug_ServerActivateRagdoll(FVector Force); // 0x080B7E6A [RequiredAPI | Net | NetReliable | Native | Event | Protected | NetServer | HasDefaults]
        TArray<UMaterialInstanceDynamic*>   GetAllCosmeticMaterials(); // 0x10DF6D16 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UBeanCharAnimInstance*              GetBeanAnimInstance(); // 0x10DF6EB4 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UBeanCharMovementComponent*         GetBeanCharacterMovement(); // 0x10DF6ED0 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UBeanCharBeingGrabbedComponent*     GetBeingGrabbedComponent(); // 0x10DF6F14 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UBeanCharCollisionManagerComponent* GetCollisionManager(); // 0x10DF6F30 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UBeanCharConfigObject*              GetConfiguration(); // 0x10DF6F4C [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UBeanCharGrabComponent*             GetGrabComponent(); // 0x10DF6F9E [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UBeanJiggleMotionComponent*         GetJiggleMotionComponent(); // 0x10DF6FBA [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UBeanCharMantleComponent*           GetMantleComponent(); // 0x10DF6FD6 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float                               GetMeshScale(); // 0x10DF6FF2 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        UBeanCharRagdollComponent*          GetRagdollComponent(); // 0x10DF7010 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        USkeletalMeshComponent*             GetRetargetSourceMesh(); // 0x10DF702C [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                                IsBeingGrabbed(); // 0x10DF7048 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                                OnRep_EnableInventoryMode(); // 0x10DF706C [Final | RequiredAPI | Native | Private]
        void                                PredictLaunch(TScriptInterface<IBeanLaunchPredictorInterface> SourceImpactPredictor, UObject* SourceOptionalSubobject, FVector& LaunchVector); // 0x080B7FE8 [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        void                                ServerPlayEmote(UAthenaDanceItemDefinition* EmoteToPlay, EFortEmotePlayMode PlayMode); // 0x080B83B0 [RequiredAPI | Net | Native | Event | Protected | NetServer]
        void                                TriggerRagdoll(FVector& Force, bool bIsViaLaunch); // 0x080B8636 [RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
    // Size: 0x0002E0 (0x000000)
    class AFortAthenaMutator_BeanGameStateCore : public AFortAthenaMutator
    {
    public:
    };
    // Size: 0x000300 (0x000020)
    class alignas(0x8) AFortAthenaMutator_BeanPlayerPawn : public AFortAthenaMutator
    {
    public:
        TSoftClassPtr<UClass>   OverridePawnClass;  // 0x0002E0 (0x000020) [Default: nullptr]
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x8) UBeanAudioDataAsset : public UDataAsset
    {
    public:
        TMap<FBeanAudioKey, FBeanAudioSet>  SoundListsByCategory;   // 0x000028 (0x000010)
    
    public: // Functions
        TMap<FBeanAudioKey, FBeanAudioSet>  GetSoundListsByCategory(); // 0x10DF3CB0 [Final | Native | Public | Const]
    };
    // Size: 0x0000D8 (0x000010)
    class alignas(0x8) UBeanCameraModeOverrideComponent : public UFortCameraModeOverrideComponent
    {
    public:
        UClass*                                 BeanCurrentCameraMode;  // 0x0000C8 (0x000008) [Default: nullptr]
        TWeakObjectPtr<UBeanCharConfigObject>   CharacterConfig;        // 0x0000D0 (0x000008) [Default: nullptr]
    };
    // Size: 0x0020F0 (0x000070)
    class alignas(0x8) UBeanCameraMode_ThirdPerson : public UFortCameraMode_ThirdPerson
    {
    public:
        bool                    bEnableDraggedBehaviour;                // 0x002080 (0x000001) [Default: true]
        uint8                   UnknownData_002081[0x000007];           // 0x002081 (0x000007)
        double                  ControllerYawToleranceForDragEnable;    // 0x002088 (0x000008) [Default: 1]
        FGameplayTagContainer   DisableDraggedCameraTags;               // 0x002090 (0x000020)
        double                  ResetCameraPitch;                       // 0x0020B0 (0x000008) [Default: 15]
        uint8                   UnknownData_0020B8[0x000038];           // 0x0020B8 (0x000038)
    };
    // Size: 0x0005E0 (0x000190)
    class alignas(0x8) UBeanCharAnimInstance : public UFortAnimInstance
    {
    public:
        bool                                    bIsSimulatedProxy;                      // 0x000450 (0x000001) [Default: false]
        EBeanCharStateID                        UpperStateID;                           // 0x000451 (0x000001) [Default: EBeanCharStateID(0)]
        EBeanCharStateID                        LowerStateID;                           // 0x000452 (0x000001) [Default: EBeanCharStateID(0)]
        EBeanCharStateID                        PrevLowerStateID;                       // 0x000453 (0x000001) [Default: EBeanCharStateID(0)]
        TEnumAsByte<EMovementMode>              MovementMode;                           // 0x000454 (0x000001) [Default: 1]
        bool                                    bIsMoving;                              // 0x000455 (0x000001) [Default: false]
        bool                                    bIsGrounded;                            // 0x000456 (0x000001) [Default: false]
        uint8                                   UnknownByte_000457;                     // 0x000457 (0x000001)
        float                                   TurningPercentage;                      // 0x000458 (0x000004) [Default: 0f]
        float                                   SpeedPercentage;                        // 0x00045C (0x000004) [Default: 0f]
        FVector                                 CurrentVelocity;                        // 0x000460 (0x000018)
        bool                                    bIsAnticipatingJumpLanding;             // 0x000478 (0x000001) [Default: false]
        uint8                                   UnknownData_000479[0x000007];           // 0x000479 (0x000007)
        FVector                                 LastRagdollImpactForce;                 // 0x000480 (0x000018)
        FVector                                 LastImpactForce;                        // 0x000498 (0x000018)
        FVector                                 LastImpactRelativeDirection;            // 0x0004B0 (0x000018)
        EBeanCharTurn180State                   TurnState;                              // 0x0004C8 (0x000001) [Default: EBeanCharTurn180State(0)]
        bool                                    bIsGrabbing;                            // 0x0004C9 (0x000001) [Default: false]
        bool                                    bHasGrabTarget;                         // 0x0004CA (0x000001) [Default: false]
        uint8                                   UnknownByte_0004CB;                     // 0x0004CB (0x000001)
        float                                   GrabStumbleDuration;                    // 0x0004CC (0x000004) [Default: 0.3f]
        FVector                                 LeftHandIKPosition;                     // 0x0004D0 (0x000018)
        FVector                                 RightHandIKPosition;                    // 0x0004E8 (0x000018)
        FRotator                                LeftHandIKRotation;                     // 0x000500 (0x000018)
        FRotator                                RightHandIKRotation;                    // 0x000518 (0x000018)
        float                                   IkAlpha;                                // 0x000530 (0x000004) [Default: 0f]
        bool                                    bUseImpactAnims;                        // 0x000534 (0x000001) [Default: true]
        bool                                    bImpactTriggered;                       // 0x000535 (0x000001) [Default: false]
        EBeanImpactAnimType                     ImpactAnimType;                         // 0x000536 (0x000001) [Default: EBeanImpactAnimType(0)]
        uint8                                   UnknownByte_000537;                     // 0x000537 (0x000001)
        float                                   LowImpactUpperThresholdReciprocal;      // 0x000538 (0x000004) [Default: 0.01f]
        float                                   MediumImpactUpperThresholdReciprocal;   // 0x00053C (0x000004) [Default: 0.005f]
        float                                   HighImpactUpperThresholdReciprocal;     // 0x000540 (0x000004) [Default: 0.001f]
        uint8                                   UnknownData_000544[0x000004];           // 0x000544 (0x000004)
        FRotator                                JiggleRotator0;                         // 0x000548 (0x000018)
        FRotator                                JiggleRotator1;                         // 0x000560 (0x000018)
        FRotator                                JiggleRotator2;                         // 0x000578 (0x000018)
        bool                                    bLowerStateUsesLocomotionAnim;          // 0x000590 (0x000001) [Default: true]
        TEnumAsByte<EFortWeaponCoreAnimation>   WeaponCoreAnim;                         // 0x000591 (0x000001) [Default: 35]
        uint8                                   UnknownData_000592[0x000002];           // 0x000592 (0x000002)
        TWeakObjectPtr<UBeanCharConfigObject>   BeanCharacterConfig;                    // 0x000594 (0x000008) [Default: nullptr]
        uint8                                   UnknownData_00059C[0x000044];           // 0x00059C (0x000044)
    
    public: // Functions
        UBeanCharConfigObject*  GetConfig(); // 0x10DF445A [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        ABeanCharacter*         TryGetBeanCharacter(); // 0x10DF4488 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000118 (0x000058)
    class UBeanCharBeingGrabbedComponent : public UActorComponent
    {
    public:
        uint8   UnknownData_0000C0[0x000058];   // 0x0000C0 (0x000058)
    
    public: // Functions
        FVector GetGrabbeeDragForce(float DragDuration, FVector& LocationOffset); // 0x080BECD0 [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000130 (0x000070)
    class alignas(0x8) UBeanCharCollisionManagerComponent : public UActorComponent
    {
    public:
        uint8   UnknownData_0000C0[0x000058];   // 0x0000C0 (0x000058)
        double  MaxConfigImpactThreshold;       // 0x000118 (0x000008) [Default: 0]
        double  NextImpactCueExecution;         // 0x000120 (0x000008) [Default: 0]
        float   RagdollThresholdMultiplier;     // 0x000128 (0x000004) [Default: 1f]
        uint8   UnknownData_00012C[0x000004];   // 0x00012C (0x000004)
    };
    // Size: 0x000958 (0x000930)
    class alignas(0x8) UBeanCharConfigObject : public UObject
    {
    public:
        FBeanCharInteractionsConfig     Interaction;                    // 0x000028 (0x0000F0)
        FBeanCharInventoryModeConfig    InventoryMode;                  // 0x000118 (0x000080)
        FBeanCharMovementConfig         Movement;                       // 0x000198 (0x000178)
        FBeanCharJumpConfig             Jump;                           // 0x000310 (0x000048)
        FBeanCharDiveConfig             Dive;                           // 0x000358 (0x000058)
        FBeanCharImpactConfig           Impact;                         // 0x0003B0 (0x000110)
        FBeanCharStaggerConfig          Stagger;                        // 0x0004C0 (0x00000C)
        uint8                           UnknownData_0004CC[0x000004];   // 0x0004CC (0x000004)
        FBeanCharRagdollConfig          Ragdoll;                        // 0x0004D0 (0x000158)
        FBeanCharRollConfig             Roll;                           // 0x000628 (0x000028)
        FBeanCharGrabConfig             Grab;                           // 0x000650 (0x0000D0)
        FBeanCharGetupConfig            Getup;                          // 0x000720 (0x000028)
        FBeanCharGetupRollConfig        GetupRoll;                      // 0x000748 (0x000010)
        FBeanCharMantleConfig           Mantle;                         // 0x000758 (0x0000C0)
        FBeanCharJostleConfig           Jostle;                         // 0x000818 (0x000030)
        FBeanCharCameraConfig           Camera;                         // 0x000848 (0x000018)
        FBeanCharCosmeticConfig         Cosmetics;                      // 0x000860 (0x000010)
        FBeanCharSwimmingConfig         Swimming;                       // 0x000870 (0x000020)
        FBeanCharZiplineConfig          Zipline;                        // 0x000890 (0x000004)
        uint8                           UnknownData_000894[0x000004];   // 0x000894 (0x000004)
        FBeanCharJiggleConfig           Jiggle;                         // 0x000898 (0x000090)
        FBeanCharHUDConfig              HUD;                            // 0x000928 (0x000020)
        FBeanCharTouchControlsConfig    TouchControls;                  // 0x000948 (0x00000C)
        uint8                           UnknownData_000954[0x000004];   // 0x000954 (0x000004)
    
    public: // Functions
        FBeanCharCameraConfig           GetCamera(); // 0x10DF3CCC [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharCosmeticConfig         GetCosmetics(); // 0x10DF3CEC [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharDiveConfig             GetDive(); // 0x10DF3D26 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharGetupConfig            GetGetup(); // 0x10DF3DB4 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharGetupRollConfig        GetGetupRoll(); // 0x10DF3E24 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharGrabConfig             GetGrab(); // 0x10DF3E7E [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharHUDConfig              GetHUD(); // 0x10DF3EA6 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharImpactConfig           GetImpact(); // 0x10DF3EC6 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharInteractionsConfig     GetInteraction(); // 0x10DF3F8A [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharInventoryModeConfig    GetInventoryMode(); // 0x10DF409E [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharJiggleConfig           GetJiggle(); // 0x10DF4104 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharJostleConfig           GetJostle(); // 0x10DF4166 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharJumpConfig             GetJump(); // 0x10DF419A [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharMantleConfig           GetMantle(); // 0x10DF41C2 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharMovementConfig         GetMovement(); // 0x10DF4210 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharRagdollConfig          GetRagdoll(); // 0x10DF42DC [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharRollConfig             GetRoll(); // 0x10DF4398 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharStaggerConfig          GetStagger(); // 0x10DF43CC [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharSwimmingConfig         GetSwimming(); // 0x10DF43F2 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharTouchControlsConfig    GetTouchControls(); // 0x10DF441A [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FBeanCharZiplineConfig          GetZipline(); // 0x10DF4440 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x0001D8 (0x000118)
    class alignas(0x8) UBeanCharGrabComponent : public UActorComponent
    {
    public:
        UAnimMontage*           ArmsOutMontage;                 // 0x0000C0 (0x000008) [Default: nullptr]
        FVector                 LeftHandIKPosition;             // 0x0000C8 (0x000018)
        FVector                 RightHandIKPosition;            // 0x0000E0 (0x000018)
        FRotator                LeftHandIKRotation;             // 0x0000F8 (0x000018)
        FRotator                RightHandIKRotation;            // 0x000110 (0x000018)
        float                   IkAlpha;                        // 0x000128 (0x000004) [Default: 0f]
        bool                    bHasIKTarget;                   // 0x00012C (0x000001) [Default: false]
        bool                    bIsGrabStumbling;               // 0x00012D (0x000001) [Default: false]
        uint8                   UnknownData_00012E[0x000022];   // 0x00012E (0x000022)
        TWeakObjectPtr<AActor>  GrabTarget;                     // 0x000150 (0x000008) [Default: nullptr]
        uint8                   UnknownData_000158[0x000010];   // 0x000158 (0x000010)
        float                   ServerLatestHoldStartTime;      // 0x000168 (0x000004) [Default: 0f]
        uint8                   UnknownData_00016C[0x00006C];   // 0x00016C (0x00006C)
    
    public: // Functions
        FVector GetGrabberDragForce(float DragDuration); // 0x080BF228 [Final | RequiredAPI | Native | Protected | HasDefaults | BlueprintCallable | BlueprintPure]
        void    HandleOnPawnJumped(); // 0x10DFFBF2 [Final | RequiredAPI | Native | Protected]
        void    OnRep_GrabTarget(); // 0x10DFFC46 [Final | RequiredAPI | Native | Protected]
        void    OnRep_ServerLatestHoldStartTime(); // 0x10DFFD36 [Final | RequiredAPI | Native | Protected]
    };
    // Size: 0x000108 (0x000048)
    class alignas(0x8) UBeanCharMantleComponent : public UActorComponent
    {
    public:
        FScalableFloat                  ClamberingEnabled;              // 0x0000C0 (0x000028)
        TWeakObjectPtr<ABeanCharacter>  BeanCharacter;                  // 0x0000E8 (0x000008) [Default: nullptr]
        float                           CachedClamberingEnabledValue;   // 0x0000F0 (0x000004) [Default: -1f]
        uint8                           UnknownData_0000F4[0x000004];   // 0x0000F4 (0x000004)
        double                          LastClamberingEnabledCacheTime; // 0x0000F8 (0x000008) [Default: 0]
        double                          ClamberingEnableCacheInterval;  // 0x000100 (0x000008) [Default: 5]
    };
    // Size: 0x0068C0 (0x000C50)
    class alignas(0x8) UBeanCharMovementComponent : public UFortMovementComp_CharacterAthena
    {
    public:
        uint8                                   UnknownData_005C70[0x000050];       // 0x005C70 (0x000050)
        void**                                  VTable_005CC0;                      // 0x005CC0 (0x000008) VTable [3 slots] -> 0x1476AB60
        uint8                                   UnknownData_005CC8[0x000020];       // 0x005CC8 (0x000020)
        void**                                  VTable_005CE8;                      // 0x005CE8 (0x000008) VTable [3 slots] -> 0x12F42730
        uint8                                   UnknownData_005CF0[0x000070];       // 0x005CF0 (0x000070)
        void**                                  VTable_005D60;                      // 0x005D60 (0x000008) VTable [3 slots] -> 0x12F42730
        uint8                                   UnknownData_005D68[0x000070];       // 0x005D68 (0x000070)
        void**                                  VTable_005DD8;                      // 0x005DD8 (0x000008) VTable [3 slots] -> 0x12F42730
        uint8                                   UnknownData_005DE0[0x000070];       // 0x005DE0 (0x000070)
        void**                                  VTable_005E50;                      // 0x005E50 (0x000008) VTable [3 slots] -> 0x141189D0
        uint8                                   UnknownData_005E58[0x000118];       // 0x005E58 (0x000118)
        void**                                  VTable_005F70;                      // 0x005F70 (0x000008) VTable [3 slots] -> 0x141189D0
        uint8                                   UnknownData_005F78[0x000118];       // 0x005F78 (0x000118)
        void**                                  VTable_006090;                      // 0x006090 (0x000008) VTable [3 slots] -> 0x141189D0
        uint8                                   UnknownData_006098[0x000118];       // 0x006098 (0x000118)
        void**                                  VTable_0061B0;                      // 0x0061B0 (0x000008) VTable [3 slots] -> 0x1476AB80
        uint8                                   UnknownData_0061B8[0x000120];       // 0x0061B8 (0x000120)
        void**                                  VTable_0062D8;                      // 0x0062D8 (0x000008) VTable [3 slots] -> 0x1476AB80
        uint8                                   UnknownData_0062E0[0x000120];       // 0x0062E0 (0x000120)
        void**                                  VTable_006400;                      // 0x006400 (0x000008) VTable [3 slots] -> 0x1476AB80
        uint8                                   UnknownData_006408[0x000120];       // 0x006408 (0x000120)
        void**                                  VTable_006528;                      // 0x006528 (0x000008) VTable [3 slots] -> 0x1476ABA0
        uint8                                   UnknownData_006530[0x000254];       // 0x006530 (0x000254)
        float                                   MovementBaseVelocitySamplingPeriod; // 0x006784 (0x000004) [Default: 0.05f]
        FMovementBaseInterfaceData              CurrentSampledMovementBaseData;     // 0x006788 (0x000018)
        uint8                                   UnknownData_0067A0[0x000101];       // 0x0067A0 (0x000101)
        bool                                    bAllowFloorHeightAdjustments;       // 0x0068A1 (0x000001) [Default: true]
        EBeanCharTurn180State                   TurnState;                          // 0x0068A2 (0x000001) [Default: EBeanCharTurn180State(0)]
        uint8                                   UnknownData_0068A3[0x00000D];       // 0x0068A3 (0x00000D)
        TWeakObjectPtr<UBeanCharConfigObject>   CharConfig;                         // 0x0068B0 (0x000008) [Default: nullptr]
        uint8                                   UnknownData_0068B8[0x000008];       // 0x0068B8 (0x000008)
    
    public: // Functions
        void                    ApplyKnockbackImpulse(FVector& Force); // 0x080C0002 [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        ABeanCharacter*         GetBeanCharacter(); // 0x10E02FBA [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EBeanCharTurn180State   GetTurn180State(); // 0x10E03008 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                    Server_SetDebugForceCorrection(EBeanDebugForceCorrectionMode Mode); // 0x0621D9D2 [RequiredAPI | Net | Native | Event | Protected | NetServer]
        void                    ServerRequestPredictLaunch(UObject* SourceObject, UObject* SourceOptionalSubobject, FVector LaunchVector, float MovementTimestamp); // 0x080C01A6 [RequiredAPI | Net | Native | Event | Public | NetServer | HasDefaults]
        void                    ServerSuggestImpartedMovementBaseVelocity(FVector ImpartedVelocity, float Timestamp); // 0x080C0658 [Final | RequiredAPI | Net | Native | Event | Private | NetServer | HasDefaults]
        void                    SetTurn180State(EBeanCharTurn180State NewTurnState); // 0x080C08DA [Final | Native | Public]
    };
    // Size: 0x000450 (0x000390)
    class alignas(0x8) UBeanCharRagdollComponent : public UActorComponent
    {
    public:
        FComponentReference                 PhysicsConstraintComponentReference;    // 0x0000C0 (0x000028)
        FComponentReference                 RootPrimitiveReference;                 // 0x0000E8 (0x000028)
        FComponentReference                 SkeletalMeshReference;                  // 0x000110 (0x000028)
        bool                                bEnableInputControlCurve;               // 0x000138 (0x000001) [Default: false]
        uint8                               UnknownData_000139[0x000007];           // 0x000139 (0x000007)
        FRuntimeFloatCurve                  RagdollInputControlWithTimeCurve;       // 0x000140 (0x000048)
        uint8                               UnknownByte_000188;                     // 0x000188 (0x000001)
        bool                                bIsConfiguredCorrectly;                 // 0x000189 (0x000001) [Default: false]
        bool                                bHasRequestedRagdollExit;               // 0x00018A (0x000001) [Default: false]
        uint8                               UnknownData_00018B[0x000005];           // 0x00018B (0x000005)
        FTransform                          StartingMeshTransform;                  // 0x000190 (0x000060)
        FCollisionResponseContainer         OriginalActorRootCollisionResponse;     // 0x0001F0 (0x000040)
        uint8                               UnknownData_000230[0x000048];           // 0x000230 (0x000048)
        FVector                             RagdollControlInputVector;              // 0x000278 (0x000018)
        bool                                bIsRagdollGrounded;                     // 0x000290 (0x000001) [Default: false]
        uint8                               UnknownData_000291[0x000003];           // 0x000291 (0x000003)
        float                               TimeOnGround;                           // 0x000294 (0x000004) [Default: 0f]
        uint8                               UnknownData_000298[0x000010];           // 0x000298 (0x000010)
        FVector                             LatestRagdollFloorOffset;               // 0x0002A8 (0x000018)
        FVector                             LatestRagdollFloorNormal;               // 0x0002C0 (0x000018)
        FBeanCharRagdollImpactData          CurrentImpactData;                      // 0x0002D8 (0x000040)
        float                               CurrentGravityZOverride;                // 0x000318 (0x000004) [Default: 3.4e+38f]
        uint8                               UnknownData_00031C[0x000004];           // 0x00031C (0x000004)
        FVector                             CurrentAdditionalGravity;               // 0x000320 (0x000018)
        uint8                               UnknownData_000338[0x000010];           // 0x000338 (0x000010)
        TArray<int32>                       CachedMeshBodyIndexesForCCD;            // 0x000348 (0x000010)
        double                              LowerLinearDistanceTarget;              // 0x000358 (0x000008) [Default: 0]
        double                              UpperLinearDistanceTarget;              // 0x000360 (0x000008) [Default: 0]
        float                               DefaultHardSnapLinearDistance;          // 0x000368 (0x000004) [Default: 0f]
        uint8                               UnknownData_00036C[0x000004];           // 0x00036C (0x000004)
        double                              MaxHardsnapLinearDistance;              // 0x000370 (0x000008) [Default: 0]
        bool                                bHasAddedIgnoredObjects;                // 0x000378 (0x000001) [Default: false]
        uint8                               UnknownData_000379[0x0000AF];           // 0x000379 (0x0000AF)
        FBeanRagdollDebugComponentHistory   RagdollComponentHistory;                // 0x000428 (0x000020)
        uint8                               UnknownData_000448[0x000008];           // 0x000448 (0x000008)
    
    public: // Functions
        void    ApplyImpulse(FVector& Force, bool bIsLaunch); // 0x080C7900 [RequiredAPI | Native | Public | HasOutParms | HasDefaults]
        void    CleanupRagdollForAbruptExit(); // 0x0E7885D8 [RequiredAPI | Native | Public]
        void    Client_CleanupRagdollForAbruptExit(); // 0x10E05590 [RequiredAPI | Net | NetReliable | Native | Event | Protected | NetClient]
        void    Client_SignalRagdollExit(FVector EndLocation, FQuat EndRotation, FVector EndVelocity); // 0x080C7B98 [RequiredAPI | Net | NetReliable | Native | Event | Protected | HasDefaults | NetClient]
        void    OnRagdollRootPrimitiveHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, FHitResult& Hit); // 0x080C82AA [Final | RequiredAPI | Native | Protected | HasOutParms | HasDefaults]
        void    RequestRagdollExit(); // 0x0F62D6CE [RequiredAPI | Native | Public]
        void    Server_SignalClientExitedRagdoll(); // 0x10033480 [RequiredAPI | Net | NetReliable | Native | Event | Protected | NetServer]
        void    ServerRPCRagdollControlInput(FVector InputVector); // 0x080C87E4 [RequiredAPI | Net | Native | Event | Public | NetServer | HasDefaults]
        void    SetRagdollEnabled(bool bShouldEnable); // 0x050585E8 [RequiredAPI | Native | Public]
    };
    // Size: 0x000198 (0x000170)
    class alignas(0x8) UBeanCharStateBase : public UObject
    {
    public:
        EBeanCharStateID                    StateId;                                // 0x000028 (0x000001) [Default: EBeanCharStateID(0)]
        EBeanCharStateLayerMask             LayerMask;                              // 0x000029 (0x000001) [Default: EBeanCharStateLayerMask(3)]
        TEnumAsByte<EMovementMode>          MovementMode;                           // 0x00002A (0x000001) [Default: 1]
        TEnumAsByte<EFortCustomMovement>    FortCustomMovementMode;                 // 0x00002B (0x000001) [Default: 0]
        FGameplayTag                        GameplayTag;                            // 0x00002C (0x000004)
        FGameplayCueTag                     GameplayCue;                            // 0x000030 (0x000004)
        uint8                               UnknownData_000034[0x000004];           // 0x000034 (0x000004)
        FGameplayCueParameters              GameplayCueParameters;                  // 0x000038 (0x0000D0)
        bool                                bShouldSetMovementMode;                 // 0x000108 (0x000001) [Default: true]
        bool                                bReplicateToSimulatedProxies;           // 0x000109 (0x000001) [Default: true]
        bool                                bExecuteCodeOnSimulatedProxies;         // 0x00010A (0x000001) [Default: false]
        bool                                bTryActivateFailsIfAlreadyActive;       // 0x00010B (0x000001) [Default: true]
        bool                                bServerMustFlushStateManually;          // 0x00010C (0x000001) [Default: false]
        bool                                bFlushPendingStateChangesOnStateExit;   // 0x00010D (0x000001) [Default: false]
        uint8                               UnknownData_00010E[0x000002];           // 0x00010E (0x000002)
        float                               Priority;                               // 0x000110 (0x000004) [Default: 0f]
        bool                                bShouldRemainVertical;                  // 0x000114 (0x000001) [Default: true]
        bool                                bCanPerformMantle;                      // 0x000115 (0x000001) [Default: false]
        uint8                               UnknownData_000116[0x000002];           // 0x000116 (0x000002)
        float                               DecelerationOverride;                   // 0x000118 (0x000004) [Default: -1f]
        bool                                bPauseJiggleCalculations;               // 0x00011C (0x000001) [Default: false]
        uint8                               UnknownData_00011D[0x000003];           // 0x00011D (0x000003)
        UBeanCharStateMachine*              OwnerStateMachine;                      // 0x000120 (0x000008) [Default: nullptr]
        TArray<uint16>                      RootMotionSourceIDs;                    // 0x000128 (0x000010)
        FGameplayTagContainer               GrantedTags;                            // 0x000138 (0x000020)
        FGameplayTagContainer               BlockedTags;                            // 0x000158 (0x000020)
        FGameplayTagContainer               BlockedAbilityTags;                     // 0x000178 (0x000020)
    };
    // Size: 0x000220 (0x000160)
    class alignas(0x8) UBeanCharStateMachine : public UActorComponent
    {
    public:
        bool                                        bIsInitialized;                         // 0x0000C0 (0x000001) [Default: false]
        uint8                                       UnknownData_0000C1[0x000007];           // 0x0000C1 (0x000007)
        FBeanCharStateMachineContext                Layers[0x000002];                       // 0x0000C8 (0x000080)
        uint8                                       UnknownData_000148[0x000028];           // 0x000148 (0x000028)
        TArray<UBeanCharStateBase*>                 TempTickStateList;                      // 0x000170 (0x000010)
        TArray<UBeanCharStateBase*>                 States;                                 // 0x000180 (0x000010)
        uint8                                       UnknownData_000190[0x000010];           // 0x000190 (0x000010)
        bool                                        bFlushMoveToServerAtEndOfFrame;         // 0x0001A0 (0x000001) [Default: false]
        bool                                        bFlushPendingStateChangesAtEndOfFrame;  // 0x0001A1 (0x000001) [Default: false]
        bool                                        bIsReplaying;                           // 0x0001A2 (0x000001) [Default: false]
        EBeanCharStateID                            ServerForceSetUpperState;               // 0x0001A3 (0x000001) [Default: EBeanCharStateID(0)]
        EBeanCharStateID                            ServerForceSetLowerState;               // 0x0001A4 (0x000001) [Default: EBeanCharStateID(0)]
        uint8                                       UnknownByte_0001A5;                     // 0x0001A5 (0x000001)
        uint16                                      SimulatedProxyStateData;                // 0x0001A6 (0x000002) [Default: 0]
        uint32                                      AutonomousProxyServerStateData;         // 0x0001A8 (0x000004) [Default: 0u]
        uint8                                       StateSyncID;                            // 0x0001AC (0x000001) [Default: 0]
        uint8                                       ServerStateSyncID;                      // 0x0001AD (0x000001) [Default: 0]
        uint8                                       UnknownData_0001AE[0x000002];           // 0x0001AE (0x000002)
        TArray<FBeanStateHistoryItem>               AutonomousProxyStateHistory;            // 0x0001B0 (0x000010)
        float                                       AutonomousProxyServerStateCheckTimer;   // 0x0001C0 (0x000004) [Default: 0f]
        float                                       RequestClientStateChangeTimeout;        // 0x0001C4 (0x000004) [Default: 0f]
        EBeanCharStateID                            RequestClientStateChangePendingStateID; // 0x0001C8 (0x000001) [Default: EBeanCharStateID(0)]
        uint8                                       UnknownData_0001C9[0x000007];           // 0x0001C9 (0x000007)
        TArray<FBeanStateGameplayTagsDefinition>    StateTagsDefinitions;                   // 0x0001D0 (0x000010)
        UClass*                                     AnimLayer_Swimming;                     // 0x0001E0 (0x000008) [Default: nullptr]
        UClass*                                     AnimLayer_Ragdoll;                      // 0x0001E8 (0x000008) [Default: nullptr]
        UClass*                                     AnimLayer_Zipline;                      // 0x0001F0 (0x000008) [Default: nullptr]
        UClass*                                     AnimLayer_Flying;                       // 0x0001F8 (0x000008) [Default: nullptr]
        UClass*                                     AnimLayer_Grab;                         // 0x000200 (0x000008) [Default: nullptr]
        UClass*                                     AnimLayer_EditMode;                     // 0x000208 (0x000008) [Default: nullptr]
        uint8                                       UnknownData_000210[0x000010];           // 0x000210 (0x000010)
    
    public: // Functions
        void                Client_ForceSetState(EBeanCharStateID StateUP, EBeanCharStateID StateLW, uint8 SyncID, bool bResetPredictionData); // 0x080CE7F6 [RequiredAPI | Net | NetReliable | Native | Event | Protected | NetClient]
        void                ClientRPC_RequestClientChangesState(EBeanCharStateID StateId, FVector Location, FRotator Rotation); // 0x080CEE4C [Final | RequiredAPI | Net | Native | Event | Private | HasDefaults | NetClient]
        void                Debug_RequestClientChangesState(EBeanCharStateID StateId); // 0x080CF216 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        UClass*             GetState(EBeanCharStateLayerID LayerID); // 0x080CF380 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float               GetStateActiveDuration(EBeanCharStateID StateId); // 0x080CF51C [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EBeanCharStateID    GetStateId(EBeanCharStateLayerID LayerID); // 0x080CF6A6 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                OnRep_AutonomousProxyStateData(); // 0x10E0978A [Final | RequiredAPI | Native | Private]
        void                OnRep_SimulatedProxyStateData(); // 0x10E097A0 [Final | RequiredAPI | Native | Private]
        void                ServerRPC_RequestClientChangeStateResponse(EBeanCharStateID StateId); // 0x080CFD44 [Final | RequiredAPI | Net | Native | Event | Private | NetServer]
    };
    // Size: 0x0001A0 (0x000008)
    class UBeanCharState_Dive : public UBeanCharStateBase
    {
    public:
        uint8   UnknownData_000198[0x000008];   // 0x000198 (0x000008)
    };
    // Size: 0x0001A0 (0x000008)
    class UBeanCharState_Emote : public UBeanCharStateBase
    {
    public:
        uint8   UnknownData_000198[0x000008];   // 0x000198 (0x000008)
    
    public: // Functions
        void    OnEmoteFinishedCallback(int32 EmoteIndex, bool bWasInterruption); // 0x080D2060 [Final | Native | Private]
    };
    // Size: 0x0001A0 (0x000008)
    class UBeanCharState_Falling : public UBeanCharStateBase
    {
    public:
        uint8   UnknownData_000198[0x000008];   // 0x000198 (0x000008)
    };
    // Size: 0x000198 (0x000000)
    class UBeanCharState_Flying : public UBeanCharStateBase
    {
    public:
    };
    // Size: 0x000230 (0x000098)
    class alignas(0x8) UBeanCharState_Getup : public UBeanCharStateBase
    {
    public:
        uint8           UnknownData_000198[0x000050];   // 0x000198 (0x000050)
        UAnimMontage*   ActiveAnim;                     // 0x0001E8 (0x000008) [Default: nullptr]
        uint8           UnknownData_0001F0[0x000040];   // 0x0001F0 (0x000040)
    };
    // Size: 0x0001E0 (0x000048)
    class UBeanCharState_GetupRoll : public UBeanCharStateBase
    {
    public:
        uint8   UnknownData_000198[0x000048];   // 0x000198 (0x000048)
    };
    // Size: 0x000198 (0x000000)
    class UBeanCharState_Grab : public UBeanCharStateBase
    {
    public:
    };
    // Size: 0x000198 (0x000000)
    class UBeanCharState_GrabStumble : public UBeanCharStateBase
    {
    public:
    };
    // Size: 0x0001B8 (0x000020)
    class UBeanCharState_Grounded : public UBeanCharStateBase
    {
    public:
        uint8   UnknownData_000198[0x000020];   // 0x000198 (0x000020)
    };
    // Size: 0x0001F8 (0x000060)
    class alignas(0x8) UBeanCharState_Jostle : public UBeanCharStateBase
    {
    public:
        FVector SeparationForce;                // 0x000198 (0x000018)
        uint8   UnknownData_0001B0[0x000048];   // 0x0001B0 (0x000048)
    };
    // Size: 0x0001B0 (0x000018)
    class UBeanCharState_Jump : public UBeanCharStateBase
    {
    public:
        uint8   UnknownData_000198[0x000018];   // 0x000198 (0x000018)
    };
    // Size: 0x0001E8 (0x000050)
    class UBeanCharState_Mantle : public UBeanCharStateBase
    {
    public:
        uint8   UnknownData_000198[0x000050];   // 0x000198 (0x000050)
    };
    // Size: 0x0001C8 (0x000030)
    class UBeanCharState_Ragdoll : public UBeanCharStateBase
    {
    public:
        uint8   UnknownData_000198[0x000030];   // 0x000198 (0x000030)
    };
    // Size: 0x0001A0 (0x000008)
    class UBeanCharState_Roll : public UBeanCharStateBase
    {
    public:
        uint8   UnknownData_000198[0x000008];   // 0x000198 (0x000008)
    };
    // Size: 0x0001A8 (0x000010)
    class alignas(0x8) UBeanCharState_Staggered : public UBeanCharStateBase
    {
    public:
        uint8           UnknownData_000198[0x000008];   // 0x000198 (0x000008)
        UAnimMontage*   CurrentMontage;                 // 0x0001A0 (0x000008) [Default: nullptr]
    };
    // Size: 0x000198 (0x000000)
    class UBeanCharState_SurfaceSwimming : public UBeanCharStateBase
    {
    public:
    };
    // Size: 0x0001B0 (0x000000)
    class UBeanCharState_WaterJump : public UBeanCharState_Jump
    {
    public:
    };
    // Size: 0x000198 (0x000000)
    class UBeanCharState_Zipline : public UBeanCharStateBase
    {
    public:
    };
    // Size: 0x000270 (0x000010)
    class alignas(0x8) UBeanChar_EditMode_AnimLayer : public UAnimInstance
    {
    public:
        TEnumAsByte<EFortWeaponCoreAnimation>   WeaponCoreAnim;                 // 0x000260 (0x000001) [Default: 35]
        bool                                    bIsMoving;                      // 0x000261 (0x000001) [Default: false]
        uint8                                   UnknownData_000262[0x000002];   // 0x000262 (0x000002)
        TWeakObjectPtr<UBeanCharConfigObject>   BeanCharacterConfig;            // 0x000264 (0x000008) [Default: nullptr]
        uint8                                   UnknownData_00026C[0x000004];   // 0x00026C (0x000004)
    
    public: // Functions
        UBeanCharConfigObject*  GetConfig(); // 0x10DF5BC6 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        ABeanCharacter*         TryGetBeanCharacter(); // 0x10DF4488 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000270 (0x000010)
    class alignas(0x8) UBeanChar_Flying_AnimLayer : public UAnimInstance
    {
    public:
        TWeakObjectPtr<UBeanCharConfigObject>   BeanCharacterConfig;            // 0x000260 (0x000008) [Default: nullptr]
        uint8                                   UnknownData_000268[0x000008];   // 0x000268 (0x000008)
    
    public: // Functions
        UBeanCharConfigObject*  GetConfig(); // 0x10DF6508 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        ABeanCharacter*         TryGetBeanCharacter(); // 0x10DF4488 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x0002E0 (0x000080)
    class alignas(0x8) UBeanChar_Grab_AnimLayer : public UAnimInstance
    {
    public:
        bool                                    bHasGrabTarget;                 // 0x000260 (0x000001) [Default: false]
        uint8                                   UnknownData_000261[0x000003];   // 0x000261 (0x000003)
        float                                   GrabStumbleDuration;            // 0x000264 (0x000004) [Default: 0.3f]
        FVector                                 LeftHandIKPosition;             // 0x000268 (0x000018)
        FVector                                 RightHandIKPosition;            // 0x000280 (0x000018)
        FRotator                                LeftHandIKRotation;             // 0x000298 (0x000018)
        FRotator                                RightHandIKRotation;            // 0x0002B0 (0x000018)
        float                                   IkAlpha;                        // 0x0002C8 (0x000004) [Default: 0f]
        TWeakObjectPtr<UBeanCharConfigObject>   BeanCharacterConfig;            // 0x0002CC (0x000008) [Default: nullptr]
        uint8                                   UnknownData_0002D4[0x00000C];   // 0x0002D4 (0x00000C)
    
    public: // Functions
        UBeanCharConfigObject*  GetConfig(); // 0x10DF6604 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        ABeanCharacter*         TryGetBeanCharacter(); // 0x10DF4488 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x0002B0 (0x000050)
    class alignas(0x8) UBeanChar_GroundLoc_AnimInstance : public UAnimInstance
    {
    public:
        float                                   TurningPercentage;              // 0x000260 (0x000004) [Default: 0f]
        float                                   SpeedPercentage;                // 0x000264 (0x000004) [Default: 0f]
        EBeanCharTurn180State                   TurnState;                      // 0x000268 (0x000001) [Default: EBeanCharTurn180State(0)]
        uint8                                   UnknownData_000269[0x000003];   // 0x000269 (0x000003)
        TWeakObjectPtr<UBeanCharConfigObject>   BeanCharacterConfig;            // 0x00026C (0x000008) [Default: nullptr]
        uint8                                   UnknownData_000274[0x00003C];   // 0x000274 (0x00003C)
    
    public: // Functions
        UBeanCharConfigObject*  GetConfig(); // 0x10DF4E88 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        ABeanCharacter*         TryGetBeanCharacter(); // 0x10DF4488 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x0002A0 (0x000040)
    class alignas(0x8) UBeanChar_Idle_AnimInstance : public UAnimInstance
    {
    public:
        UAnimSequence*                          CurrentIdleBreakAnimation;      // 0x000260 (0x000008) [Default: nullptr]
        bool                                    bIsPlayingIdleBreak;            // 0x000268 (0x000001) [Default: false]
        uint8                                   UnknownData_000269[0x000003];   // 0x000269 (0x000003)
        float                                   CurrentIdleBreakTime;           // 0x00026C (0x000004) [Default: 0f]
        uint8                                   UnknownData_000270[0x000008];   // 0x000270 (0x000008)
        TArray<TSoftObjectPtr<UAnimSequence>>   IdleBreaks;                     // 0x000278 (0x000010)
        float                                   IdleBreakMinTime;               // 0x000288 (0x000004) [Default: 2f]
        float                                   IdleBreakMaxTime;               // 0x00028C (0x000004) [Default: 5f]
        float                                   StopIdleBreakTrimTime;          // 0x000290 (0x000004) [Default: 0.2f]
        TWeakObjectPtr<UBeanCharConfigObject>   BeanCharacterConfig;            // 0x000294 (0x000008) [Default: nullptr]
        uint8                                   UnknownData_00029C[0x000004];   // 0x00029C (0x000004)
    
    public: // Functions
        UBeanCharConfigObject*  GetConfig(); // 0x10DF54A4 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        ABeanCharacter*         TryGetBeanCharacter(); // 0x10DF4488 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000280 (0x000020)
    class alignas(0x8) UBeanChar_InAirLoc_AnimInstance : public UAnimInstance
    {
    public:
        bool                                    bIsJumping;                     // 0x000260 (0x000001) [Default: false]
        bool                                    bIsFalling;                     // 0x000261 (0x000001) [Default: false]
        bool                                    bIsAnticipatingJumpLanding;     // 0x000262 (0x000001) [Default: false]
        bool                                    bIsDiving;                      // 0x000263 (0x000001) [Default: false]
        TWeakObjectPtr<UBeanCharConfigObject>   BeanCharacterConfig;            // 0x000264 (0x000008) [Default: nullptr]
        bool                                    bWasJumping;                    // 0x00026C (0x000001) [Default: false]
        uint8                                   UnknownData_00026D[0x000003];   // 0x00026D (0x000003)
        float                                   JumpStartZ;                     // 0x000270 (0x000004) [Default: 0f]
        uint8                                   UnknownData_000274[0x00000C];   // 0x000274 (0x00000C)
    
    public: // Functions
        UBeanCharConfigObject*  GetConfig(); // 0x10DF5BC6 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        ABeanCharacter*         TryGetBeanCharacter(); // 0x10DF4488 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000300 (0x0000A0)
    class alignas(0x8) UBeanChar_Jiggle_AnimInstance : public UAnimInstance
    {
    public:
        FVector                                 LastImpactForce;                        // 0x000260 (0x000018)
        FVector                                 LastImpactRelativeDirection;            // 0x000278 (0x000018)
        bool                                    bJustLandedFromJump;                    // 0x000290 (0x000001) [Default: false]
        bool                                    bIsMoving;                              // 0x000291 (0x000001) [Default: false]
        bool                                    bUseImpactAnims;                        // 0x000292 (0x000001) [Default: true]
        bool                                    bImpactTriggered;                       // 0x000293 (0x000001) [Default: false]
        EBeanImpactAnimType                     ImpactAnimType;                         // 0x000294 (0x000001) [Default: EBeanImpactAnimType(0)]
        uint8                                   UnknownData_000295[0x000003];           // 0x000295 (0x000003)
        float                                   LowImpactUpperThresholdReciprocal;      // 0x000298 (0x000004) [Default: 0.01f]
        float                                   MediumImpactUpperThresholdReciprocal;   // 0x00029C (0x000004) [Default: 0.005f]
        float                                   HighImpactUpperThresholdReciprocal;     // 0x0002A0 (0x000004) [Default: 0.001f]
        uint8                                   UnknownData_0002A4[0x000004];           // 0x0002A4 (0x000004)
        FRotator                                JiggleRotator0;                         // 0x0002A8 (0x000018)
        FRotator                                JiggleRotator1;                         // 0x0002C0 (0x000018)
        FRotator                                JiggleRotator2;                         // 0x0002D8 (0x000018)
        TWeakObjectPtr<UBeanCharConfigObject>   BeanCharacterConfig;                    // 0x0002F0 (0x000008) [Default: nullptr]
        uint8                                   UnknownData_0002F8[0x000008];           // 0x0002F8 (0x000008)
    
    public: // Functions
        UBeanCharConfigObject*  GetConfig(); // 0x10DF5DD4 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        ABeanCharacter*         TryGetBeanCharacter(); // 0x10DF4488 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x0004D0 (0x000080)
    class alignas(0x8) UBeanChar_Main_AnimInstance : public UFortAnimInstance
    {
    public:
        bool                                    bIsSimulatedProxy;              // 0x000450 (0x000001) [Default: false]
        TEnumAsByte<EMovementMode>              MovementMode;                   // 0x000451 (0x000001) [Default: 1]
        bool                                    bIsMoving;                      // 0x000452 (0x000001) [Default: false]
        bool                                    bIsGrounded;                    // 0x000453 (0x000001) [Default: false]
        uint8                                   UnknownData_000454[0x000004];   // 0x000454 (0x000004)
        FVector                                 CurrentVelocity;                // 0x000458 (0x000018)
        FRotator                                JiggleRotator0;                 // 0x000470 (0x000018)
        FRotator                                JiggleRotator1;                 // 0x000488 (0x000018)
        FRotator                                JiggleRotator2;                 // 0x0004A0 (0x000018)
        bool                                    bLowerStateUsesLocomotionAnim;  // 0x0004B8 (0x000001) [Default: true]
        uint8                                   UnknownData_0004B9[0x000003];   // 0x0004B9 (0x000003)
        TWeakObjectPtr<UBeanCharConfigObject>   BeanCharacterConfig;            // 0x0004BC (0x000008) [Default: nullptr]
        uint8                                   UnknownData_0004C4[0x00000C];   // 0x0004C4 (0x00000C)
    
    public: // Functions
        UBeanCharConfigObject*  GetConfig(); // 0x10DF61F6 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        ABeanCharacter*         TryGetBeanCharacter(); // 0x10DF4488 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x0002A0 (0x000040)
    class alignas(0x8) UBeanChar_Ragdoll_AnimLayer : public UAnimInstance
    {
    public:
        float                                   HighImpactUpperThresholdReciprocal; // 0x000260 (0x000004) [Default: 0f]
        uint8                                   UnknownData_000264[0x000004];       // 0x000264 (0x000004)
        FVector                                 LastRagdollImpactForce;             // 0x000268 (0x000018)
        FVector                                 LastImpactRelativeDirection;        // 0x000280 (0x000018)
        TWeakObjectPtr<UBeanCharConfigObject>   BeanCharacterConfig;                // 0x000298 (0x000008) [Default: nullptr]
    
    public: // Functions
        UBeanCharConfigObject*  GetConfig(); // 0x10DF67FC [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        ABeanCharacter*         TryGetBeanCharacter(); // 0x10DF4488 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000270 (0x000010)
    class alignas(0x8) UBeanChar_Swimming_AnimLayer : public UAnimInstance
    {
    public:
        float                                   SpeedPercentage;                // 0x000260 (0x000004) [Default: 0f]
        bool                                    bIsJumping;                     // 0x000264 (0x000001) [Default: false]
        uint8                                   UnknownData_000265[0x000003];   // 0x000265 (0x000003)
        TWeakObjectPtr<UBeanCharConfigObject>   BeanCharacterConfig;            // 0x000268 (0x000008) [Default: nullptr]
    
    public: // Functions
        UBeanCharConfigObject*  GetConfig(); // 0x10DF69D6 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        ABeanCharacter*         TryGetBeanCharacter(); // 0x10DF4488 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000270 (0x000010)
    class alignas(0x8) UBeanChar_Zipline_AnimLayer : public UAnimInstance
    {
    public:
        TWeakObjectPtr<UBeanCharConfigObject>   BeanCharacterConfig;            // 0x000260 (0x000008) [Default: nullptr]
        uint8                                   UnknownData_000268[0x000008];   // 0x000268 (0x000008)
    
    public: // Functions
        UBeanCharConfigObject*  GetConfig(); // 0x10DF6508 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        ABeanCharacter*         TryGetBeanCharacter(); // 0x10DF4488 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000048 (0x000020)
    class UBeanCheatManager : public UChildCheatManager
    {
    public:
        uint8   UnknownData_000028[0x000020];   // 0x000028 (0x000020)
    
    public: // Functions
        void    BeanAllowItemInteractionByTag(FString TagString); // 0x043A4E82 [Final | Exec | Native | Public]
        void    BeanDisallowItemInteractionByTag(FString TagString); // 0x043A4E82 [Final | Exec | Native | Public | Const]
        void    BeanEnableBeanInEditMode(bool bEnabled); // 0x080D9312 [Final | Exec | Native | Public | Const]
        void    BeanEnableGetupSpeedModifier(bool bEnabled); // 0x080D9482 [Final | Exec | Native | Public | Const]
        void    BeanEnableInventoryMode(bool bEnable); // 0x040ED1DC [Final | Exec | Native | Public]
        void    BeanRelockPlayerActionByTag(FString TagString); // 0x043A4E82 [Final | Exec | Native | Public | Const]
        void    BeanSetGlobalRagdollThreshold(float Threshold); // 0x080D95F2 [Final | Exec | Native | Public | Const]
        void    BeanToggleAbilityRestrictions(bool bApplyRestrictions); // 0x040ED1DC [Final | Exec | Native | Public]
        void    BeanTogglePickupRestrictions(bool bApplyRestrictions); // 0x040ED1DC [Final | Exec | Native | Public]
        void    BeanUnlockBuildMode(bool bUnlock); // 0x040ED1DC [Final | Exec | Native | Public]
        void    BeanUnlockPlayerActionByTag(FString TagString); // 0x043A4E82 [Final | Exec | Native | Public]
        void    RespawnAsDefaultPawn(); // 0x0CA02B1A [Final | Exec | Native | Public]
        void    SwitchBackFromBeanPawn(); // 0x0CA02B1A [Final | Exec | Native | Public]
        void    SwitchToBeanPawn(); // 0x0CA02B1A [Final | Exec | Native | Public]
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x8) UBeanCosmeticBackpackAllowList : public UDataAsset
    {
    public:
        TSet<TSoftObjectPtr<UAthenaBackpackItemDefinition>> AllowedBackpacks;   // 0x000028 (0x000010)
    };
    // Size: 0x000028 (0x000000)
    class IBeanGrabbable : public IInterface
    {
    public:
    };
    // Size: 0x000288 (0x0001C8)
    class alignas(0x8) UBeanJiggleMotionComponent : public UActorComponent
    {
    public:
        FRuntimeFloatCurve  VelocityCurve;                      // 0x0000C0 (0x000048)
        uint8               UnknownData_000108[0x000030];       // 0x000108 (0x000030)
        TArray<FQuat>       CurrentBoneRotations;               // 0x000138 (0x000010)
        TArray<FQuat>       TargetBoneRotations;                // 0x000148 (0x000010)
        TArray<FRotator>    CurrentInterpolatedBoneRotations;   // 0x000158 (0x000010)
        uint8               UnknownData_000168[0x000120];       // 0x000168 (0x000120)
    };
    // Size: 0x000028 (0x000000)
    class IBeanLaunchPredictorInterface : public IInterface
    {
    public:
    
    public: // Functions
        bool    ValidateLaunch(FBeanPredictedLaunch& PredictedLaunch); // 0x080CE64C [RequiredAPI | Native | Event | Public | HasOutParms | BlueprintCallable | BlueprintEvent | BlueprintPure | Const]
    };
    // Size: 0x0000D0 (0x000010)
    class alignas(0x8) UBeanParticleSystemsComponent : public UActorComponent
    {
    public:
        TMap<EBeanParticleVfxTypes, TSoftObjectPtr<UNiagaraSystem>> VfxParticleSystemsMap;  // 0x0000C0 (0x000010)
    };
    // Size: 0x000040 (0x000010)
    class alignas(0x8) UBeanPhysicsDOFConstraintSubsystem : public UGameInstanceSubsystem
    {
    public:
        TMap<ABeanCharacter*, FBeanPhysicsDOFConstraint>    PreviousConstraints;    // 0x000030 (0x000010)
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x8) UBeanStreamingManager : public UObject
    {
    public:
        TSet<UObject*>  LoadedAssets;   // 0x000028 (0x000010)
    };
    // Size: 0x000028 (0x000000)
    class UBeanstalkFunctionLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static bool    CanPawnSwitchToBeanNow(AFortPlayerPawn* PlayerPawn); // 0x080D9B86 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static bool    CanPlayerSwitchToBeanNow(AFortPlayerController* PlayerController); // 0x080D9CF4 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
        static void    SwitchBackFromBeanPawn(AFortPlayerController* PlayerController); // 0x080D9E62 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static bool    SwitchToBeanPawn(AFortPlayerController* PlayerController); // 0x080DA014 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000090 (0x000028)
    class UFortAutomationRpcManager_Beanstalk : public UFortAutomationRpcManager
    {
    public:
        uint8   UnknownData_000068[0x000028];   // 0x000068 (0x000028)
    
    public: // Functions
        void    OnBeanStateChanged_AddToHistory(EBeanCharStateID StateId, EBeanCharStateLayerID LayerID, bool bIsReplaying); // 0x080D8F9C [Final | RequiredAPI | Native | Public]
        void    OnBeanStateChanged_BroadcastMessage(EBeanCharStateID StateId, EBeanCharStateLayerID LayerID, bool bIsReplaying); // 0x080D8F9C [Final | RequiredAPI | Native | Public]
        void    OnBeanStateChanged_Grounded_ResetDive(EBeanCharStateID StateId, EBeanCharStateLayerID LayerID, bool bIsReplaying); // 0x080D8F9C [Final | RequiredAPI | Native | Public]
        void    OnCharacterOverlap_BroadcastMessage(AActor* OverlappedActor, AActor* OtherActor); // 0x05023DDC [Final | RequiredAPI | Native | Public]
        void    OnCharacterOverlap_Dive(AActor* OverlappedActor, AActor* OtherActor); // 0x05023DDC [Final | RequiredAPI | Native | Public]
        void    OnCharacterOverlap_Jump(AActor* OverlappedActor, AActor* OtherActor); // 0x05023DDC [Final | RequiredAPI | Native | Public]
    };
    // Size: 0x0000E0 (0x000000)
    class UFortPickupInteractOverrideComponent_Beanstalk : public UFortPickupInteractOverrideComponent
    {
    public:
    };
    // Size: 0x000048 (0x000000)
    class UInteractSelection_BeanPawn : public UInteractSelection_Base
    {
    public:
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FBeanAudioKey
    {
        EBeanAudioEventTypes    AudioEventType; // 0x000000 (0x000004)
        EBeanAudioCategories    AudioCategory;  // 0x000004 (0x000004)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FBeanAudioSet
    {
        TArray<USoundBase*> SoundClips2D;   // 0x000000 (0x000010)
        TArray<USoundBase*> SoundClips3D;   // 0x000010 (0x000010)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FBeanCharCameraConfig
    {
        UClass* CameraMode;                     // 0x000000 (0x000008)
        UClass* OverrideVehicleCameraMode;      // 0x000008 (0x000008)
        float   EnableDragAfterTeleportTimeout; // 0x000010 (0x000004)
        uint8   UnknownData_000014[0x000004];   // 0x000014 (0x000004)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FBeanCharCollisionResponseData
    {
        float                   ImpactThreshold;                // 0x000000 (0x000004)
        bool                    bActivateKnockback;             // 0x000004 (0x000001)
        bool                    bActivateRagdoll;               // 0x000005 (0x000001)
        EBeanImpactAnimType     ImpactAnimType;                 // 0x000006 (0x000001)
        bool                    bPlayImpactVFX;                 // 0x000007 (0x000001)
        UForceFeedbackEffect*   ForceFeedbackEffect;            // 0x000008 (0x000008)
        bool                    bPlayFeedbackOnLand;            // 0x000010 (0x000001)
        bool                    bPlayFeedbackOnLaunch;          // 0x000011 (0x000001)
        uint8                   UnknownData_000012[0x000006];   // 0x000012 (0x000006)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FBeanCharCosmeticConfig
    {
        TArray<UAthenaDanceItemDefinition*> DefaultEmotes;  // 0x000000 (0x000010)
    };
    // Size: 0x000058 (0x000058)
    struct alignas(0x8) FBeanCharDiveConfig
    {
        float           GroundDiveVelocity;                             // 0x000000 (0x000004)
        float           GroundDiveAngle;                                // 0x000004 (0x000004)
        float           AirDiveVelocity;                                // 0x000008 (0x000004)
        float           AirDiveAngle;                                   // 0x00000C (0x000004)
        double          HorizontalVelocityConservePercentageNormalized; // 0x000010 (0x000008)
        float           TurnSpeedDiving;                                // 0x000018 (0x000004)
        float           GroundTimeBeforeGetup;                          // 0x00001C (0x000004)
        float           LandingVelocityReductionPercentageNormalized;   // 0x000020 (0x000004)
        uint8           UnknownData_000024[0x000004];                   // 0x000024 (0x000004)
        UCurveVector*   DiveRotationCurve;                              // 0x000028 (0x000008)
        FVector         ParticleEmitterScale;                           // 0x000030 (0x000018)
        double          ParticleSpawnZOffset;                           // 0x000048 (0x000008)
        bool            bLaunchZOverrideResetsDive;                     // 0x000050 (0x000001)
        bool            bLaunchXYOverrideResetsDive;                    // 0x000051 (0x000001)
        uint8           UnknownData_000052[0x000006];                   // 0x000052 (0x000006)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FBeanCharGetupConfig
    {
        float           AnimationRate;                          // 0x000000 (0x000004)
        uint8           UnknownData_000004[0x000004];           // 0x000004 (0x000004)
        UCurveFloat*    MotionTimeCurve;                        // 0x000008 (0x000008)
        float           RunSpeedMultiplier;                     // 0x000010 (0x000004)
        float           TurnSpeedOverride;                      // 0x000014 (0x000004)
        float           RestoreMovementAfterDurationNormalized; // 0x000018 (0x000004)
        float           EarlyExitStateDurationNormalized;       // 0x00001C (0x000004)
        float           GetupAnimationThresholdPitch;           // 0x000020 (0x000004)
        float           SkipAnimationRotationDuration;          // 0x000024 (0x000004)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FBeanCharGetupRollConfig
    {
        float           duration;                       // 0x000000 (0x000004)
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UCurveFloat*    MotionTimeCurve;                // 0x000008 (0x000008)
    };
    // Size: 0x0000D0 (0x0000D0)
    struct alignas(0x8) FBeanCharGrabConfig
    {
        float   GrabbedJumpForceMultiplier;         // 0x000000 (0x000004)
        float   GrabRadius;                         // 0x000004 (0x000004)
        float   GrabTargetCheckHeight;              // 0x000008 (0x000004)
        float   UngrabDistanceAny;                  // 0x00000C (0x000004)
        float   UngrabDistanceVertical;             // 0x000010 (0x000004)
        float   GrabbingRunSpeedMultiplier;         // 0x000014 (0x000004)
        float   HoldingRunSpeedMultiplier;          // 0x000018 (0x000004)
        float   HoldingMaxTurnSpeed;                // 0x00001C (0x000004)
        float   BeingGrabbedRunSpeedMultiplier;     // 0x000020 (0x000004)
        float   BeingGrabbedMaxTurnSpeed;           // 0x000024 (0x000004)
        float   HoldPositionForwardOffset;          // 0x000028 (0x000004)
        float   RotateToFaceTargetSpeed;            // 0x00002C (0x000004)
        float   DragPositionTolerance;              // 0x000030 (0x000004)
        float   DragSpeed;                          // 0x000034 (0x000004)
        float   GrabberVelocityFactor;              // 0x000038 (0x000004)
        float   MaxForceOnGrabber;                  // 0x00003C (0x000004)
        float   GrabbeeVelocityFactor;              // 0x000040 (0x000004)
        float   MaxForceOnGrabbee;                  // 0x000044 (0x000004)
        float   GrabBreakTime;                      // 0x000048 (0x000004)
        float   GrabbeeCooldownAfterGrabBreak;      // 0x00004C (0x000004)
        float   GrabbeeJumpBreakTimeReduction;      // 0x000050 (0x000004)
        float   GrabBreakApartForce;                // 0x000054 (0x000004)
        float   GrabStumbleDuration;                // 0x000058 (0x000004)
        uint8   UnknownData_00005C[0x000004];       // 0x00005C (0x000004)
        FVector PlayerGrabOffsetIK;                 // 0x000060 (0x000018)
        FVector LeftHandRotationAdjustment;         // 0x000078 (0x000018)
        FVector RightHandRotationAdjustment;        // 0x000090 (0x000018)
        float   ServerNetLocationToleranceGrabber;  // 0x0000A8 (0x000004)
        float   ServerNetLocationToleranceGrabbee;  // 0x0000AC (0x000004)
        FVector ParticleEmitterScale;               // 0x0000B0 (0x000018)
        float   HoldingRunSpeedAnimationMultiplier; // 0x0000C8 (0x000004)
        uint8   UnknownData_0000CC[0x000004];       // 0x0000CC (0x000004)
    };
    // Size: 0x000038 (0x000038)
    struct FBeanCharGrabPrediction
    {
        uint8   UnknownData_000000[0x000038];   // 0x000000 (0x000038)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FBeanCharHUDConfig
    {
        FGameplayTagContainer   HiddenHUDElements;  // 0x000000 (0x000020)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FBeanCharIdleBreakDef
    {
        TSoftObjectPtr<UAnimMontage>    IdleAnim;                       // 0x000000 (0x000020) [Default: 0x12FB06E0]
        float                           Weighting;                      // 0x000020 (0x000004) [Default: 2.71601e+12f]
        uint8                           UnknownData_000024[0x000004];   // 0x000024 (0x000004)
    };
    // Size: 0x000110 (0x000110)
    struct alignas(0x8) FBeanCharImpactConfig
    {
        TArray<FBeanCharCollisionResponseData>  CollisionResponseData;                      // 0x000000 (0x000010)
        double                                  DiveHeadOnCollisionReactionMultiplier;      // 0x000010 (0x000008)
        double                                  GroundLandingCollisionReactionMultiplier;   // 0x000018 (0x000008)
        double                                  LedgeUpwardDotTolerance;                    // 0x000020 (0x000008)
        FVector                                 LedgeKnockbackMultiplier;                   // 0x000028 (0x000018)
        double                                  InAirKnockbackDampening;                    // 0x000040 (0x000008)
        double                                  MinKnockbackForce;                          // 0x000048 (0x000008)
        double                                  MaxKnockbackForce;                          // 0x000050 (0x000008)
        float                                   ImpactVFXCooldown;                          // 0x000058 (0x000004)
        float                                   ImpactOffsetAmount;                         // 0x00005C (0x000004)
        float                                   ImpactThresholdLarge;                       // 0x000060 (0x000004)
        float                                   ImpactThresholdMedium;                      // 0x000064 (0x000004)
        float                                   ImpactThresholdSmall;                       // 0x000068 (0x000004)
        uint8                                   UnknownData_00006C[0x000004];               // 0x00006C (0x000004)
        double                                  MinimumImpactGameplayCueStrength;           // 0x000070 (0x000008)
        double                                  ImpactGameplayCueCooldown;                  // 0x000078 (0x000008)
        TSet<EBeanCharStateID>                  IgnoreImpactStates;                         // 0x000080 (0x000010)
        FName                                   RootUnpinnedBone;                           // 0x000090 (0x000004)
        float                                   BasePinStrength;                            // 0x000094 (0x000004)
        FRuntimeFloatCurve                      PinningResetCurve;                          // 0x000098 (0x000048)
        TArray<TEnumAsByte<ECollisionChannel>>  PinningCollisionChannels;                   // 0x0000E0 (0x000010)
        FPhysicalAnimationData                  PinningPhysicalAnimationData;               // 0x0000F0 (0x000020)
    };
    // Size: 0x0000F0 (0x0000F0)
    struct alignas(0x8) FBeanCharInteractionsConfig
    {
        FGameplayTagContainer           PersistentTags;                         // 0x000000 (0x000020)
        FGameplayTagContainer           DisallowedPlayerActions;                // 0x000020 (0x000020)
        FGameplayTagContainer           BlockedGameplayAbilityTags;             // 0x000040 (0x000020)
        FGameplayTagContainer           AllowedItems;                           // 0x000060 (0x000020)
        FGameplayTagContainer           BlockedInteractableTags;                // 0x000080 (0x000020)
        FGameplayTagContainer           InteractablesRequiringReticle;          // 0x0000A0 (0x000020)
        FText                           BlockedInteractableContextText;         // 0x0000C0 (0x000010)
        FLinearColor                    BlockedInteractableContextTextColour;   // 0x0000D0 (0x000010)
        bool                            bBlockedInteractableContextTextOnly;    // 0x0000E0 (0x000001)
        uint8                           UnknownData_0000E1[0x000003];           // 0x0000E1 (0x000003)
        FInteractSelectionData_BeanPawn InteractSelectionData;                  // 0x0000E4 (0x000008)
        uint8                           UnknownData_0000EC[0x000004];           // 0x0000EC (0x000004)
    };
    // Size: 0x000080 (0x000080)
    struct alignas(0x8) FBeanCharInventoryModeConfig
    {
        FGameplayTagContainer   ActionsToAllow;                 // 0x000000 (0x000020)
        FGameplayTagContainer   GameplayAbilityTagsToUnblock;   // 0x000020 (0x000020)
        FGameplayTagContainer   HUDElementsToUnhide;            // 0x000040 (0x000020)
        FGameplayTagContainer   ItemsToAllow;                   // 0x000060 (0x000020)
    };
    // Size: 0x000090 (0x000090)
    struct alignas(0x8) FBeanCharJiggleConfig
    {
        TArray<float>                           BoneWeights;                    // 0x000000 (0x000010)
        double                                  BeingGrabbedWeightMultiplier;   // 0x000010 (0x000008)
        TArray<FBeanJiggleStateWeightOverride>  StateWeightOverrides;           // 0x000018 (0x000010)
        float                                   StateWeightBlendDuration;       // 0x000028 (0x000004)
        uint8                                   UnknownData_00002C[0x000004];   // 0x00002C (0x000004)
        double                                  PlatformVelocityMultiplier;     // 0x000030 (0x000008)
        double                                  AccelerationNoiseCutoff;        // 0x000038 (0x000008)
        double                                  Mass;                           // 0x000040 (0x000008)
        double                                  SpringConst;                    // 0x000048 (0x000008)
        double                                  SpringPivotOffset;              // 0x000050 (0x000008)
        double                                  SpringDamping;                  // 0x000058 (0x000008)
        double                                  SpringInterpSpeed;              // 0x000060 (0x000008)
        double                                  ClampOffsetFactor;              // 0x000068 (0x000008)
        double                                  MaxInputForce;                  // 0x000070 (0x000008)
        FVector                                 AccelerationAxisWeights;        // 0x000078 (0x000018)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FBeanCharJostleConfig
    {
        float   JostleTriggerRadius;            // 0x000000 (0x000004)
        float   JostleOuterRadius;              // 0x000004 (0x000004)
        float   JostleInnerRadius;              // 0x000008 (0x000004)
        float   JostleMandatoryRadius;          // 0x00000C (0x000004)
        double  JostleForceMultiplier;          // 0x000010 (0x000008)
        float   JostlerMinSpeedToApplyForce;    // 0x000018 (0x000004)
        float   JostleeMaxSpeedToTrigger;       // 0x00001C (0x000004)
        float   JostleeMaxSpeedToApplyForce;    // 0x000020 (0x000004)
        float   JostleRefreshInterval;          // 0x000024 (0x000004)
        float   PositionToleranceDuringJostle;  // 0x000028 (0x000004)
        uint8   UnknownData_00002C[0x000004];   // 0x00002C (0x000004)
    };
    // Size: 0x000048 (0x000048)
    struct alignas(0x8) FBeanCharJumpConfig
    {
        float   JumpZVelocity;                          // 0x000000 (0x000004)
        float   LandingVelocityConserve;                // 0x000004 (0x000004)
        double  TransitionToFallingZThreshold;          // 0x000008 (0x000008)
        float   JumpCoyoteTime;                         // 0x000010 (0x000004)
        float   JumpReverseCoyoteTime;                  // 0x000014 (0x000004)
        FVector ParticleEmitterScale;                   // 0x000018 (0x000018)
        double  ParticleSpawnZOffset;                   // 0x000030 (0x000008)
        double  AnticipateLandingInitialTraceLength;    // 0x000038 (0x000008)
        double  AnticipateLandingZVelocityMultiplier;   // 0x000040 (0x000008)
    };
    // Size: 0x0000D0 (0x0000D0)
    struct FBeanCharMantleCheckDebug
    {
        uint8   UnknownData_000000[0x0000D0];   // 0x000000 (0x0000D0)
    };
    // Size: 0x000110 (0x000040)
    struct alignas(0x8) FBeanCharMantleCheckDebug_StepFour : public FBeanCharMantleCheckDebug
    {
        uint8   UnknownData_0000D0[0x000008];   // 0x0000D0 (0x000008)
        void**  VTable_0000D8;                  // 0x0000D8 (0x000008) VTable [108 slots] -> 0x1527E848
        uint8   UnknownData_0000E0[0x000030];   // 0x0000E0 (0x000030)
    };
    // Size: 0x000110 (0x000040)
    struct FBeanCharMantleCheckDebug_StepOne : public FBeanCharMantleCheckDebug
    {
        uint8   UnknownData_0000D0[0x000040];   // 0x0000D0 (0x000040)
    };
    // Size: 0x0000E0 (0x000010)
    struct FBeanCharMantleCheckDebug_StepThree : public FBeanCharMantleCheckDebug
    {
        uint8   UnknownData_0000D0[0x000010];   // 0x0000D0 (0x000010)
    };
    // Size: 0x0000E0 (0x000010)
    struct FBeanCharMantleCheckDebug_StepTwo : public FBeanCharMantleCheckDebug
    {
        uint8   UnknownData_0000D0[0x000010];   // 0x0000D0 (0x000010)
    };
    // Size: 0x0000C0 (0x0000C0)
    struct alignas(0x8) FBeanCharMantleConfig
    {
        TArray<TEnumAsByte<ECollisionChannel>>  AcceptedCollisionChannels;              // 0x000000 (0x000010)
        TEnumAsByte<EComponentMobility>         HighestAcceptedComponentMobility;       // 0x000010 (0x000001)
        bool                                    bAllowMantleOnAllSceneGraphEntities;    // 0x000011 (0x000001)
        uint8                                   UnknownData_000012[0x000006];           // 0x000012 (0x000006)
        double                                  WallCheckDownOffset;                    // 0x000018 (0x000008)
        double                                  WallCheckDownOffsetDiving;              // 0x000020 (0x000008)
        double                                  WallCheckRadius;                        // 0x000028 (0x000008)
        double                                  WallCheckHeight;                        // 0x000030 (0x000008)
        double                                  WallCheckLength;                        // 0x000038 (0x000008)
        double                                  WallCheckMaxAngle;                      // 0x000040 (0x000008)
        double                                  WallCheckMinFacingAlignment;            // 0x000048 (0x000008)
        double                                  WallTopCheckMinimumLength;              // 0x000050 (0x000008)
        double                                  WallTopCheckRadius;                     // 0x000058 (0x000008)
        double                                  WallTopMinUpwardAlignment;              // 0x000060 (0x000008)
        double                                  LedgeCheckLength;                       // 0x000068 (0x000008)
        double                                  LedgeCheckRadius;                       // 0x000070 (0x000008)
        double                                  HangingSpotHorizontalOffset;            // 0x000078 (0x000008)
        double                                  HangingSpotVerticalOffset;              // 0x000080 (0x000008)
        double                                  HangingSpotMinimumHeight;               // 0x000088 (0x000008)
        double                                  HangingSpotMaxInclineDot;               // 0x000090 (0x000008)
        float                                   AnimationRate;                          // 0x000098 (0x000004)
        float                                   RestoreMovementAfterDurationNormalized; // 0x00009C (0x000004)
        float                                   RestoreMovementVelocityMultiplier;      // 0x0000A0 (0x000004)
        float                                   CancelBuffer;                           // 0x0000A4 (0x000004)
        float                                   CancelInputDuration;                    // 0x0000A8 (0x000004)
        float                                   CooldownTime;                           // 0x0000AC (0x000004)
        float                                   TimeToValidate;                         // 0x0000B0 (0x000004)
        FName                                   HangingSpotMotionWarp;                  // 0x0000B4 (0x000004)
        float                                   ClamberEnabledCacheTime;                // 0x0000B8 (0x000004)
        float                                   VelocityProjectionSeconds;              // 0x0000BC (0x000004)
    };
    // Size: 0x000038 (0x000038)
    struct FBeanCharMantleTargetData
    {
        uint8   UnknownData_000000[0x000038];   // 0x000000 (0x000038)
    };
    // Size: 0x000430 (0x000430)
    struct alignas(0x8) FBeanCharMantleTargetDebug
    {
        uint8   UnknownData_000000[0x000008];   // 0x000000 (0x000008)
        void**  VTable_000008;                  // 0x000008 (0x000008) VTable [108 slots] -> 0x1527E848
        uint8   UnknownData_000010[0x0000C8];   // 0x000010 (0x0000C8)
        void**  VTable_0000D8;                  // 0x0000D8 (0x000008) VTable [56 slots] -> 0x1527E678
        uint8   UnknownData_0000E0[0x000068];   // 0x0000E0 (0x000068)
        void**  VTable_000148;                  // 0x000148 (0x000008) VTable [189 slots] -> 0x12DD04C0
        uint8   UnknownData_000150[0x000068];   // 0x000150 (0x000068)
        void**  VTable_0001B8;                  // 0x0001B8 (0x000008) VTable [523 slots] -> 0x12DCFA50
        uint8   UnknownData_0001C0[0x000068];   // 0x0001C0 (0x000068)
        void**  VTable_000228;                  // 0x000228 (0x000008) VTable [243 slots] -> 0x12DCF0F0
        uint8   UnknownData_000230[0x000068];   // 0x000230 (0x000068)
        void**  VTable_000298;                  // 0x000298 (0x000008) VTable [243 slots] -> 0x12DCF0F0
        uint8   UnknownData_0002A0[0x000078];   // 0x0002A0 (0x000078)
        void**  VTable_000318;                  // 0x000318 (0x000008) VTable [121 slots] -> 0x12DD06E0
        uint8   UnknownData_000320[0x000110];   // 0x000320 (0x000110)
    };
    // Size: 0x000178 (0x000178)
    struct alignas(0x8) FBeanCharMovementConfig
    {
        float               Mass;                                       // 0x000000 (0x000004)
        float               GravityScale;                               // 0x000004 (0x000004)
        FRuntimeFloatCurve  NormalMaxAccelerationCurve;                 // 0x000008 (0x000048)
        FRuntimeFloatCurve  NormalMaxDecelerationCurve;                 // 0x000050 (0x000048)
        float               LeanAnimTurnThreshold;                      // 0x000098 (0x000004)
        float               LeanAnimTurnMaxAngleRadians;                // 0x00009C (0x000004)
        float               LeanAnimBlendSpeed;                         // 0x0000A0 (0x000004)
        float               TurnSpeedGrounded;                          // 0x0000A4 (0x000004)
        FRuntimeFloatCurve  TurnYawMultiplierGrounded;                  // 0x0000A8 (0x000048)
        float               TurnSpeedAerial;                            // 0x0000F0 (0x000004)
        float               TurnSpeedFlying;                            // 0x0000F4 (0x000004)
        bool                bIsTurn180Enabled;                          // 0x0000F8 (0x000001)
        uint8               UnknownData_0000F9[0x000003];               // 0x0000F9 (0x000003)
        float               Turn180MinSpeedPercentage;                  // 0x0000FC (0x000004)
        float               Turn180DotProductTolerance;                 // 0x000100 (0x000004)
        float               Turn180Duration;                            // 0x000104 (0x000004)
        FRuntimeFloatCurve  Turn180YawMultiplier;                       // 0x000108 (0x000048)
        float               Turn180CancelDotProductTolerance;           // 0x000150 (0x000004)
        bool                UseMeshPositionLerp;                        // 0x000154 (0x000001)
        bool                UseCameraPositionLerp;                      // 0x000155 (0x000001)
        uint8               UnknownData_000156[0x000002];               // 0x000156 (0x000002)
        float               PositionLerpSpeed;                          // 0x000158 (0x000004)
        float               PositionLerpAccelerationFactor;             // 0x00015C (0x000004)
        float               MaxCorrectionDistanceToTriggerMeshLerp;     // 0x000160 (0x000004)
        float               MaxCorrectionDistanceToTriggerCameraLerp;   // 0x000164 (0x000004)
        float               MaxFallDuration;                            // 0x000168 (0x000004)
        uint8               UnknownData_00016C[0x000004];               // 0x00016C (0x000004)
        double              FallToRagdollZVelocityThreshold;            // 0x000170 (0x000008)
    };
    // Size: 0x000158 (0x000158)
    struct alignas(0x8) FBeanCharRagdollConfig
    {
        double                                  ImpactForceMultiplier;                  // 0x000000 (0x000008)
        bool                                    bUseLaunchForceMultiplier;              // 0x000008 (0x000001)
        uint8                                   UnknownData_000009[0x000007];           // 0x000009 (0x000007)
        FRuntimeFloatCurve                      LaunchForceMultiplier;                  // 0x000010 (0x000048)
        double                                  GroundedRagdollControlForce;            // 0x000058 (0x000008)
        double                                  InAirRagdollControlForce;               // 0x000060 (0x000008)
        float                                   RagdollControlVelocityThreshold;        // 0x000068 (0x000004)
        float                                   ExitLinearVelocity;                     // 0x00006C (0x000004)
        float                                   ExitAngularVelocity;                    // 0x000070 (0x000004)
        float                                   GetupVerticalityDotProductTolerance;    // 0x000074 (0x000004)
        float                                   GetupVerticalityDotProductDeadZoneMin;  // 0x000078 (0x000004)
        float                                   GetupVerticalityDotProductDeadZoneMax;  // 0x00007C (0x000004)
        float                                   MinimumActiveSeconds;                   // 0x000080 (0x000004)
        float                                   MaxActiveSeconds;                       // 0x000084 (0x000004)
        double                                  AngularVelocityMagnitude;               // 0x000088 (0x000008)
        float                                   HighImpactMaxAnimThreshold;             // 0x000090 (0x000004)
        FName                                   SkeletalMeshAnchorBone;                 // 0x000094 (0x000004)
        float                                   PhysicsBlendWeight;                     // 0x000098 (0x000004)
        uint8                                   UnknownData_00009C[0x000004];           // 0x00009C (0x000004)
        FRotator                                MeshCapsuleRotationalOffset;            // 0x0000A0 (0x000018)
        FVector                                 MeshCapsulePositionalOffset;            // 0x0000B8 (0x000018)
        double                                  DebugTriggerRagdollForce;               // 0x0000D0 (0x000008)
        bool                                    bEnableRollExit;                        // 0x0000D8 (0x000001)
        uint8                                   UnknownData_0000D9[0x000007];           // 0x0000D9 (0x000007)
        double                                  SpeedForRollGetup;                      // 0x0000E0 (0x000008)
        float                                   GroundedCheckHalfHeightScale;           // 0x0000E8 (0x000004)
        uint8                                   UnknownData_0000EC[0x000004];           // 0x0000EC (0x000004)
        double                                  GroundedCheckRadius;                    // 0x0000F0 (0x000008)
        float                                   MinimumTimeOnGround;                    // 0x0000F8 (0x000004)
        uint8                                   UnknownData_0000FC[0x000004];           // 0x0000FC (0x000004)
        TArray<TEnumAsByte<ECollisionChannel>>  MeshCollisionChannels;                  // 0x000100 (0x000010)
        TArray<FString>                         MeshBonesWithCCD;                       // 0x000110 (0x000010)
        int32                                   MaxRemoteRagdollCharacters;             // 0x000120 (0x000004)
        uint8                                   UnknownData_000124[0x000004];           // 0x000124 (0x000004)
        double                                  MaxRemoteRagdollDistance;               // 0x000128 (0x000008)
        double                                  RemoteRagdollMinimumDeactiveTime;       // 0x000130 (0x000008)
        bool                                    bCullRemoteRagdollsBehindCamera;        // 0x000138 (0x000001)
        uint8                                   UnknownData_000139[0x000007];           // 0x000139 (0x000007)
        double                                  ReplicationHardsnapDistanceOverride;    // 0x000140 (0x000008)
        double                                  MaxSecondsStuck;                        // 0x000148 (0x000008)
        double                                  SameLocationDistanceTolerance;          // 0x000150 (0x000008)
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x8) FBeanCharRagdollImpactData
    {
        double  Strength;                       // 0x000000 (0x000008)
        FVector Location;                       // 0x000008 (0x000018)
        FVector Normal;                         // 0x000020 (0x000018)
        bool    bFromLaunch;                    // 0x000038 (0x000001)
        uint8   UnknownData_000039[0x000007];   // 0x000039 (0x000007)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FBeanCharRollConfig
    {
        double  ScaleSpeed;                         // 0x000000 (0x000008)
        float   MinimumDuration;                    // 0x000008 (0x000004)
        float   MaximumDurationBeforeForcedExit;    // 0x00000C (0x000004)
        double  ExitSpeed;                          // 0x000010 (0x000008)
        double  GetupDirectionTolerance;            // 0x000018 (0x000008)
        double  ForwardRollBlendSpeed;              // 0x000020 (0x000008)
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FBeanCharStaggerConfig
    {
        float   LandStaggerZVelocityThreshold;  // 0x000000 (0x000004)
        float   LandStaggerStunDurationSeconds; // 0x000004 (0x000004)
        float   VelocityMultiplierOnStagger;    // 0x000008 (0x000004)
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x8) FBeanCharStateMachineContext
    {
        uint8               UnknownData_000000[0x000008];   // 0x000000 (0x000008)
        UBeanCharStateBase* CurrentState;                   // 0x000008 (0x000008)
        uint8               UnknownData_000010[0x000010];   // 0x000010 (0x000010)
        UBeanCharStateBase* NewState;                       // 0x000020 (0x000008)
        uint8               UnknownData_000028[0x000018];   // 0x000028 (0x000018)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x4) FBeanCharSwimmingConfig
    {
        float   HeadingAdjustmentStrength;  // 0x000000 (0x000004)
        float   MinImmersionDepth;          // 0x000004 (0x000004)
        float   MaxImmersionDepth;          // 0x000008 (0x000004)
        float   TargetImmersionDepth;       // 0x00000C (0x000004)
        float   JumpMinVelocityZ;           // 0x000010 (0x000004)
        float   JumpMaxVelocityZ;           // 0x000014 (0x000004)
        float   JumpForceZ;                 // 0x000018 (0x000004)
        float   JumpForceDuration;          // 0x00001C (0x000004)
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FBeanCharTouchControlsConfig
    {
        int32   NumLandingPredictionTraceSubdivisions;      // 0x000000 (0x000004)
        float   JumpDiveButtonAdditionalCoyoteTime;         // 0x000004 (0x000004)
        float   JumpDiveButtonAdditionalReverseCoyoteTime;  // 0x000008 (0x000004)
    };
    // Size: 0x000004 (0x000004)
    struct alignas(0x4) FBeanCharZiplineConfig
    {
        float   ZiplineTurnSpeed;   // 0x000000 (0x000004)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FBeanJiggleStateWeightOverride
    {
        EBeanCharStateID    StateId;                        // 0x000000 (0x000001)
        uint8               UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        float               Weighting;                      // 0x000004 (0x000004)
    };
    // Size: 0x000020 (0x000020)
    struct FBeanPhysicsDOFConstraint
    {
        uint8   UnknownData_000000[0x000020];   // 0x000000 (0x000020)
    };
    // Size: 0x000058 (0x000058)
    struct alignas(0x8) FBeanPredictedLaunch
    {
        TWeakObjectPtr<ABeanCharacter>  Character;                      // 0x000000 (0x000008)
        FVector                         LaunchVector;                   // 0x000008 (0x000018)
        FVector                         CharacterLocationBeforeLaunch;  // 0x000020 (0x000018)
        FVector                         CharacterVelocityBeforeLaunch;  // 0x000038 (0x000018)
        TWeakObjectPtr<UObject>         OptionalSourceSubobject;        // 0x000050 (0x000008)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FBeanRagdollDebugComponentHistory
    {
        TArray<FBeanRagdollDebugComponentSnapshot>  CapsuleHistory; // 0x000000 (0x000010)
        TArray<FBeanRagdollDebugComponentSnapshot>  MeshHistory;    // 0x000010 (0x000010)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FBeanRagdollDebugComponentSnapshot
    {
        FVector Location;   // 0x000000 (0x000018)
        FVector Velocity;   // 0x000018 (0x000018)
    };
    // Size: 0x000100 (0x000040)
    struct alignas(0x8) FBeanRootMotionSource_MoveToWithTimeMappingForce : public FRootMotionSource
    {
        FVector         StartLocation;                                  // 0x0000C0 (0x000018)
        FVector         TargetLocation;                                 // 0x0000D8 (0x000018)
        UCurveFloat*    TimeMappingCurve;                               // 0x0000F0 (0x000008)
        float           PreviousPreCurvedTargetRotationTimeFraction;    // 0x0000F8 (0x000004)
        uint8           UnknownData_0000FC[0x000004];                   // 0x0000FC (0x000004)
    };
    // Size: 0x0000E0 (0x000020)
    struct alignas(0x8) FBeanRootMotionSource_RotationCurveForce : public FRootMotionSource
    {
        bool            bUseNormalizedTime;             // 0x0000C0 (0x000001)
        uint8           UnknownData_0000C1[0x000007];   // 0x0000C1 (0x000007)
        UCurveVector*   RotationCurve;                  // 0x0000C8 (0x000008)
        float           SimulatedTargetTimeFraction;    // 0x0000D0 (0x000004)
        uint8           UnknownData_0000D4[0x00000C];   // 0x0000D4 (0x00000C)
    };
    // Size: 0x0000F0 (0x000030)
    struct alignas(0x8) FBeanRootMotionSource_RotationDeltaForce : public FRootMotionSource
    {
        FQuat           DeltaRotation;                                  // 0x0000C0 (0x000020)
        UCurveFloat*    TimeMappingCurve;                               // 0x0000E0 (0x000008)
        float           PreviousPreCurvedTargetRotationTimeFraction;    // 0x0000E8 (0x000004)
        uint8           UnknownData_0000EC[0x000004];                   // 0x0000EC (0x000004)
    };
    // Size: 0x000068 (0x000068)
    struct alignas(0x8) FBeanStateGameplayTagsDefinition
    {
        EBeanCharStateID        StateId;                        // 0x000000 (0x000001)
        uint8                   UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        FGameplayTagContainer   GrantedTags;                    // 0x000008 (0x000020)
        FGameplayTagContainer   BlockedTags;                    // 0x000028 (0x000020)
        FGameplayTagContainer   BlockedAbilityTags;             // 0x000048 (0x000020)
    };
    // Size: 0x000004 (0x000004)
    struct FBeanStateHistoryItem
    {
        uint8   UnknownData_000000[0x000004];   // 0x000000 (0x000004)
    };
    // Size: 0x000003 (0x000003)
    struct FBeanStateHistoryRecord
    {
        EBeanCharStateID        StateId;        // 0x000000 (0x000001)
        EBeanCharStateLayerID   LayerID;        // 0x000001 (0x000001)
        bool                    bIsReplaying;   // 0x000002 (0x000001)
    };
    // Size: 0x000008 (0x000007)
    struct alignas(0x4) FInteractSelectionData_BeanPawn : public FInteractSelectionData_Base
    {
        float   InteractHalfAngle;  // 0x000004 (0x000004) [Default: 0f]
    };
}

