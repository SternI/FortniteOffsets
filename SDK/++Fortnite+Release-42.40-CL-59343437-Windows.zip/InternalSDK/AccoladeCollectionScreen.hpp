/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AccoladeCollectionScreen
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000040 (0x000010)
    class UFortCollectionDataEntryAccolade : public UFortCollectionDataEntry
    {
    public:
        uint8   UnknownData_000030[0x000010];   // 0x000030 (0x000010)
    };
    // Size: 0x000380 (0x000010)
    class alignas(0x8) UPinnedAccoladeWidget : public UFortHUDElementWidget
    {
    public:
        UFortLazyImage* LazyImage_PinColor;             // 0x000370 (0x000008) [Default: nullptr]
        int32           NumAllowedDescCharacters;       // 0x000378 (0x000004) [Default: 20]
        uint8           UnknownData_00037C[0x000004];   // 0x00037C (0x000004)
    
    public: // Functions
        void    BP_PopulateAccoladeInfo(FText& Description, int32 Achieved, int32 Total); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
    };
    // Size: 0x000108 (0x000048)
    class UQuestAccoladeDataSource : public UQuestCollectionDataSource
    {
    public:
        uint8   UnknownData_0000C0[0x000048];   // 0x0000C0 (0x000048)
    
    public: // Functions
        void    OnControllerComponentAttached(AFortPlayerController* OwnerController, UFortControllerComponent* AttachedComponent); // 0x07ECCA54 [Final | Native | Private]
    };
    // Size: 0x000130 (0x000020)
    class alignas(0x8) UQuestAccoladeInjector : public UQuestCollectionInjectorBase
    {
    public:
        int32                   CategorySortOrder;              // 0x000110 (0x000004) [Default: 2000]
        uint8                   UnknownData_000114[0x000004];   // 0x000114 (0x000004)
        UAccoladeProductData*   ProductData;                    // 0x000118 (0x000008) [Default: nullptr]
        uint8                   UnknownData_000120[0x000010];   // 0x000120 (0x000010)
    };
    // Size: 0x000148 (0x000010)
    class alignas(0x4) UQuestUIAccoladeEntryVM : public UQuestUICustomEntryVM
    {
    public:
        int32                   CompletedCount;                 // 0x000138 (0x000004) [Default: 0]
        EFortAccoladeTierType   Tier;                           // 0x00013C (0x000001) [Default: EFortAccoladeTierType(0)]
        uint8                   UnknownData_00013D[0x000003];   // 0x00013D (0x000003)
        int32                   ProgressAchieved;               // 0x000140 (0x000004) [Default: 0]
        int32                   ProgressTotal;                  // 0x000144 (0x000004) [Default: 0]
    };
}

