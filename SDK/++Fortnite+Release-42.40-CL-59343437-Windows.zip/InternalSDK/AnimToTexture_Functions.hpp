/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimToTexture_Functions
 * ============================================================
 */

#include "AnimToTexture.hpp"

namespace UE
{

    struct UAnimToTextureDataAsset___BP_GetBonePositionTexture_Params
    {
        UTexture2D* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14891710]
    };

    struct UAnimToTextureDataAsset___BP_GetBoneRotationTexture_Params
    {
        UTexture2D* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14891710]
    };

    struct UAnimToTextureDataAsset___BP_GetBoneWeightTexture_Params
    {
        UTexture2D* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14891710]
    };

    struct UAnimToTextureDataAsset___BP_GetSkeletalMesh_Params
    {
        USkeletalMesh*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14891710]
    };

    struct UAnimToTextureDataAsset___BP_GetStaticMesh_Params
    {
        UStaticMesh*    ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14891710]
    };

    struct UAnimToTextureDataAsset___GetIndexFromAnimSequence_Params
    {
        UAnimSequence*  Sequence;       // 0x000000 (0x000008) [Default: 0x14891710]
        int32           ReturnValue;    // 0x000008 (0x000004) [ReturnValue] [Default: 49]
    };

    struct UAnimToTextureInstancePlaybackLibrary___BatchUpdateInstancesAutoPlayData_Params
    {
        UInstancedStaticMeshComponent*      InstancedMeshComponent; // 0x000000 (0x000008) [Default: 0x130A5F60]
        TArray<FAnimToTextureAutoPlayData>  AutoPlayData;           // 0x000008 (0x000010) [OutParam]
        TArray<FTransform>                  Transforms;             // 0x000018 (0x000010) [OutParam]
        bool                                bMarkRenderStateDirty;  // 0x000028 (0x000001) [Default: true]
        bool                                ReturnValue;            // 0x000029 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAnimToTextureInstancePlaybackLibrary___BatchUpdateInstancesFrameData_Params
    {
        UInstancedStaticMeshComponent*  InstancedMeshComponent; // 0x000000 (0x000008) [Default: 0x130A5F60]
        TArray<FAnimToTextureFrameData> FrameData;              // 0x000008 (0x000010) [OutParam]
        TArray<FTransform>              Transforms;             // 0x000018 (0x000010) [OutParam]
        bool                            bMarkRenderStateDirty;  // 0x000028 (0x000001) [Default: true]
        bool                            ReturnValue;            // 0x000029 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAnimToTextureInstancePlaybackLibrary___GetAutoPlayDataFromDataAsset_Params
    {
        UAnimToTextureDataAsset*    DataAsset;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        int32                       AnimationIndex; // 0x000008 (0x000004) [Default: 49]
        FAnimToTextureAutoPlayData  AutoPlayData;   // 0x00000C (0x000010) [OutParam]
        float                       TimeOffset;     // 0x00001C (0x000004) [Default: 0f]
        float                       PlayRate;       // 0x000020 (0x000004) [Default: -4.9466e-11f]
        bool                        ReturnValue;    // 0x000024 (0x000001) [ReturnValue] [Default: false]
    };

    struct UAnimToTextureInstancePlaybackLibrary___GetFrame_Params
    {
        float   time;           // 0x000000 (0x000004) [Default: 1.74651e-27f]
        float   StartFrame;     // 0x000004 (0x000004) [Default: 0f]
        float   EndFrame;       // 0x000008 (0x000004) [Default: 6.86636e-44f]
        float   TimeOffset;     // 0x00000C (0x000004) [Default: -4.81596e-17f]
        float   PlayRate;       // 0x000010 (0x000004) [Default: 1.23967e-23f]
        float   SampleRate;     // 0x000014 (0x000004) [Default: 0f]
        float   ReturnValue;    // 0x000018 (0x000004) [ReturnValue] [Default: 1.23826e-23f]
    };

    struct UAnimToTextureInstancePlaybackLibrary___GetFrameDataFromDataAsset_Params
    {
        UAnimToTextureDataAsset*    DataAsset;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        int32                       AnimationIndex; // 0x000008 (0x000004) [Default: 49]
        float                       time;           // 0x00000C (0x000004) [Default: -4.81596e-17f]
        FAnimToTextureFrameData     FrameData;      // 0x000010 (0x000008) [OutParam]
        float                       TimeOffset;     // 0x000018 (0x000004) [Default: 1.23826e-23f]
        float                       PlayRate;       // 0x00001C (0x000004) [Default: 0f]
        bool                        ReturnValue;    // 0x000020 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAnimToTextureInstancePlaybackLibrary___SetupInstancedMeshComponent_Params
    {
        UInstancedStaticMeshComponent*  InstancedMeshComponent; // 0x000000 (0x000008) [Default: 0x130A5F60]
        int32                           NumInstances;           // 0x000008 (0x000004) [Default: 49]
        bool                            bAutoPlay;              // 0x00000C (0x000001) [Default: true]
        bool                            ReturnValue;            // 0x00000D (0x000001) [ReturnValue] [Default: true]
    };

    struct UAnimToTextureInstancePlaybackLibrary___UpdateInstanceAutoPlayData_Params
    {
        UInstancedStaticMeshComponent*  InstancedMeshComponent; // 0x000000 (0x000008) [Default: 0x130A5F60]
        int32                           InstanceIndex;          // 0x000008 (0x000004) [Default: 49]
        FAnimToTextureAutoPlayData      AutoPlayData;           // 0x00000C (0x000010) [OutParam]
        bool                            bMarkRenderStateDirty;  // 0x00001C (0x000001) [Default: false]
        bool                            ReturnValue;            // 0x00001D (0x000001) [ReturnValue] [Default: false]
    };

    struct UAnimToTextureInstancePlaybackLibrary___UpdateInstanceFrameData_Params
    {
        UInstancedStaticMeshComponent*  InstancedMeshComponent; // 0x000000 (0x000008) [Default: 0x130A5F60]
        int32                           InstanceIndex;          // 0x000008 (0x000004) [Default: 49]
        FAnimToTextureFrameData         FrameData;              // 0x00000C (0x000008) [OutParam]
        bool                            bMarkRenderStateDirty;  // 0x000014 (0x000001) [Default: false]
        bool                            ReturnValue;            // 0x000015 (0x000001) [ReturnValue] [Default: false]
    };

} // namespace UE

