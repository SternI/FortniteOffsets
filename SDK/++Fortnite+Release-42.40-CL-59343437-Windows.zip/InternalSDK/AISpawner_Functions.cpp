/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AISpawner_Functions
 * ============================================================
 */

#include "AISpawner_Functions.hpp"

namespace UE
{

    void AFortAthenaMutator_AISpawner::HandleCreativeModeratorModeActivatedChanged(AFortPlayerPawnAthena* Pawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AISpawner.FortAthenaMutator_AISpawner.HandleCreativeModeratorModeActivatedChanged");
    
        AFortAthenaMutator_AISpawner___HandleCreativeModeratorModeActivatedChanged_Params Params{};
        Params.Pawn = Pawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AFortAthenaMutator_AISpawner::HandlePlayerPawnChanged(AFortPlayerPawn* NewPawn, AFortPlayerPawn* OldPawn, AFortPlayerController* PC)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AISpawner.FortAthenaMutator_AISpawner.HandlePlayerPawnChanged");
    
        AFortAthenaMutator_AISpawner___HandlePlayerPawnChanged_Params Params{};
        Params.NewPawn = NewPawn;
        Params.OldPawn = OldPawn;
        Params.PC = PC;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAISpawnerPreviewerComponent::ClearActorPreview()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AISpawner.AISpawnerPreviewerComponent.ClearActorPreview");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAISpawnerPreviewerComponent::ClearCIDPreview()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AISpawner.AISpawnerPreviewerComponent.ClearCIDPreview");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAISpawnerPreviewerComponent::SetActorForPreview(UClass* InActorClass, TArray<UCustomCharacterPart*> OptionalCharacterParts)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AISpawner.AISpawnerPreviewerComponent.SetActorForPreview");
    
        UAISpawnerPreviewerComponent___SetActorForPreview_Params Params{};
        Params.InActorClass = InActorClass;
        Params.OptionalCharacterParts = OptionalCharacterParts;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAISpawnerPreviewerComponent::SetCIDForPreview(UAthenaCharacterItemDefinition* InCID, TArray<FMcpVariantChannelInfo> InVariants)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AISpawner.AISpawnerPreviewerComponent.SetCIDForPreview");
    
        UAISpawnerPreviewerComponent___SetCIDForPreview_Params Params{};
        Params.InCID = InCID;
        Params.InVariants = InVariants;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAISpawnerPreviewerComponent::SetPreviewByAssets(FCharacterPreviewAssets& PreviewAssets)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AISpawner.AISpawnerPreviewerComponent.SetPreviewByAssets");
    
        UAISpawnerPreviewerComponent___SetPreviewByAssets_Params Params{};
        Params.PreviewAssets = PreviewAssets;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PreviewAssets = Params.PreviewAssets;
    }

} // namespace UE

