/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioMotorSim
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000128 (0x000068)
    class alignas(0x8) UAudioMotorModelComponent : public UActorComponent
    {
    public:
        TArray<FMotorSimEntry>                          SimComponents;                  // 0x0000C0 (0x000010)
        TArray<TScriptInterface<IAudioMotorSimOutput>>  AudioComponents;                // 0x0000D0 (0x000010)
        uint8                                           UnknownData_0000E0[0x000048];   // 0x0000E0 (0x000048)
    
    public: // Functions
        void                            AddMotorAudioComponent(TScriptInterface<IAudioMotorSimOutput> InComponent); // 0x0567CA08 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            AddMotorSimComponent(TScriptInterface<IAudioMotorSim> InComponent, int32 SortOrder); // 0x0567CBBA [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            ConfigureMotorSimComponents(TArray<FInstancedStruct>& InConfigData); // 0x0567CE6A [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        FAudioMotorSimInputContext      GetCachedInputData(); // 0x0E45D730 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32                           GetGear(); // 0x0E45D764 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float                           GetRpm(); // 0x0E45D77E [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FAudioMotorSimRuntimeContext    GetRuntimeInfo(); // 0x0E45D79C [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                            RemoveAllMotorSimComponents(); // 0x0E45D7C4 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            RemoveMotorAudioComponent(TScriptInterface<IAudioMotorSimOutput> InComponent); // 0x0567D09A [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            RemoveMotorSimComponent(TScriptInterface<IAudioMotorSim> InComponent); // 0x0567D254 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            Reset(); // 0x010B003C [RequiredAPI | Native | Public | BlueprintCallable]
        void                            StartOutput(); // 0x0DAC6250 [RequiredAPI | Native | Public | BlueprintCallable]
        void                            StopOutput(); // 0x01274662 [RequiredAPI | Native | Public | BlueprintCallable]
        void                            Update(FAudioMotorSimInputContext& Input); // 0x0567D3EA [RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class IAudioMotorSim : public IInterface
    {
    public:
    
    public: // Functions
        void    ConfigMotorSim(FInstancedStruct& InConfigData); // 0x0567D5F8 [Native | Public | HasOutParms | BlueprintCallable]
        bool    GetEnabled(); // 0x0D1A9122 [Native | Public | BlueprintCallable]
        void    Reset(); // 0x0D1A9148 [Native | Public | BlueprintCallable]
    };
    // Size: 0x0000D0 (0x000010)
    class alignas(0x8) UAudioMotorSimComponent : public UActorComponent
    {
    public:
        void**  VTable_0000C0;                  // 0x0000C0 (0x000008) VTable [7 slots] -> 0x134DCD20
        bool    bEnabled;                       // 0x0000C8 (0x000001) [Default: true]
        uint8   UnknownData_0000C9[0x000007];   // 0x0000C9 (0x000007)
    
    public: // Functions
        void    BP_Reset(); // 0x000545D2 [RequiredAPI | Event | Public | BlueprintCallable | BlueprintEvent]
        bool    BP_Update(FAudioMotorSimInputContext& Input, FAudioMotorSimRuntimeContext& RuntimeInfo); // 0x000545D2 [RequiredAPI | Event | Public | HasOutParms | BlueprintEvent]
        void    SetEnabled(bool bNewEnabled); // 0x0567D7D0 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class IAudioMotorSimOutput : public IInterface
    {
    public:
    };
    // Size: 0x000001 (0x000001)
    struct FAudioMotorSimConfigData
    {
        uint8   UnknownByte_000000; // 0x000000 (0x000001)
    };
    // Size: 0x000010 (0x000010)
    struct FAudioMotorSimDebugDataBase
    {
        uint8   UnknownData_000000[0x000010];   // 0x000000 (0x000010)
    };
    // Size: 0x00002C (0x00002C)
    struct alignas(0x4) FAudioMotorSimInputContext
    {
        float   DeltaTime;                  // 0x000000 (0x000004)
        float   Speed;                      // 0x000004 (0x000004)
        float   ForwardSpeed;               // 0x000008 (0x000004)
        float   SideSpeed;                  // 0x00000C (0x000004)
        float   UpSpeed;                    // 0x000010 (0x000004)
        float   Throttle;                   // 0x000014 (0x000004)
        float   Brake;                      // 0x000018 (0x000004)
        float   SurfaceFrictionModifier;    // 0x00001C (0x000004)
        float   MotorFrictionModifier;      // 0x000020 (0x000004)
        float   Boost;                      // 0x000024 (0x000004)
        bool    bDriving;                   // 0x000028 (0x000001)
        bool    bGrounded;                  // 0x000029 (0x000001)
        bool    bCanShift;                  // 0x00002A (0x000001)
        bool    bClutchEngaged;             // 0x00002B (0x000001)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x4) FAudioMotorSimRuntimeContext
    {
        bool    bShifting;                      // 0x000000 (0x000001)
        uint8   UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        int32   Gear;                           // 0x000004 (0x000004)
        float   VirtualSpeedKmh;                // 0x000008 (0x000004)
        float   RPM;                            // 0x00000C (0x000004)
        float   Volume;                         // 0x000010 (0x000004)
        float   Pitch;                          // 0x000014 (0x000004)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FMotorSimEntry
    {
        TScriptInterface<IAudioMotorSim>    Sim;                            // 0x000000 (0x000010)
        int32                               SortOrder;                      // 0x000010 (0x000004)
        uint8                               UnknownData_000014[0x000004];   // 0x000014 (0x000004)
    };
}

