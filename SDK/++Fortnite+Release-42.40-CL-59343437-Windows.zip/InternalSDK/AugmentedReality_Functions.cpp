/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:04
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AugmentedReality_Functions
 * ============================================================
 */

#include "AugmentedReality_Functions.hpp"

namespace UE
{

    UARComponent* AARActor::AddARComponent(UClass* InComponentClass, FGuid& NativeID)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARActor.AddARComponent");
    
        AARActor___AddARComponent_Params Params{};
        Params.InComponentClass = InComponentClass;
        Params.NativeID = NativeID;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        NativeID = Params.NativeID;
    
        return Params.ReturnValue;
    }

    AARSharedWorldGameState* AARSharedWorldGameMode::GetARSharedWorldGameState()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSharedWorldGameMode.GetARSharedWorldGameState");
    
        AARSharedWorldGameMode___GetARSharedWorldGameState_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void AARSharedWorldGameMode::SetARSharedWorldData(TArray<uint8> ARWorldData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSharedWorldGameMode.SetARSharedWorldData");
    
        AARSharedWorldGameMode___SetARSharedWorldData_Params Params{};
        Params.ARWorldData = ARWorldData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AARSharedWorldGameMode::SetARWorldSharingIsReady()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSharedWorldGameMode.SetARWorldSharingIsReady");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AARSharedWorldGameMode::SetPreviewImageData(TArray<uint8> ImageData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSharedWorldGameMode.SetPreviewImageData");
    
        AARSharedWorldGameMode___SetPreviewImageData_Params Params{};
        Params.ImageData = ImageData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AARSharedWorldGameState::K2_OnARWorldMapIsReady()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSharedWorldGameState.K2_OnARWorldMapIsReady");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AARSharedWorldPlayerController::ClientInitSharedWorld(int32 PreviewImageSize, int32 ARWorldDataSize)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSharedWorldPlayerController.ClientInitSharedWorld");
    
        AARSharedWorldPlayerController___ClientInitSharedWorld_Params Params{};
        Params.PreviewImageSize = PreviewImageSize;
        Params.ARWorldDataSize = ARWorldDataSize;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AARSharedWorldPlayerController::ClientUpdateARWorldData(int32 Offset, TArray<uint8> Buffer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSharedWorldPlayerController.ClientUpdateARWorldData");
    
        AARSharedWorldPlayerController___ClientUpdateARWorldData_Params Params{};
        Params.Offset = Offset;
        Params.Buffer = Buffer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AARSharedWorldPlayerController::ClientUpdatePreviewImageData(int32 Offset, TArray<uint8> Buffer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSharedWorldPlayerController.ClientUpdatePreviewImageData");
    
        AARSharedWorldPlayerController___ClientUpdatePreviewImageData_Params Params{};
        Params.Offset = Offset;
        Params.Buffer = Buffer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AARSharedWorldPlayerController::ServerMarkReadyForReceiving()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSharedWorldPlayerController.ServerMarkReadyForReceiving");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AARSkyLight::SetEnvironmentCaptureProbe(UAREnvironmentCaptureProbe* InCaptureProbe)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSkyLight.SetEnvironmentCaptureProbe");
    
        AARSkyLight___SetEnvironmentCaptureProbe_Params Params{};
        Params.InCaptureProbe = InCaptureProbe;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    FLinearColor UARBasicLightEstimate::GetAmbientColor()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBasicLightEstimate.GetAmbientColor");
    
        UARBasicLightEstimate___GetAmbientColor_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UARBasicLightEstimate::GetAmbientColorTemperatureKelvin()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBasicLightEstimate.GetAmbientColorTemperatureKelvin");
    
        UARBasicLightEstimate___GetAmbientColorTemperatureKelvin_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UARBasicLightEstimate::GetAmbientIntensityLumens()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBasicLightEstimate.GetAmbientIntensityLumens");
    
        UARBasicLightEstimate___GetAmbientIntensityLumens_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UARBlueprintLibrary::AddManualEnvironmentCaptureProbe(FVector Location, FVector Extent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.AddManualEnvironmentCaptureProbe");
    
        UARBlueprintLibrary___AddManualEnvironmentCaptureProbe_Params Params{};
        Params.Location = Location;
        Params.Extent = Extent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UARCandidateImage* UARBlueprintLibrary::AddRuntimeCandidateImage(UARSessionConfig* SessionConfig, UTexture2D* CandidateTexture, FString FriendlyName, float PhysicalWidth)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.AddRuntimeCandidateImage");
    
        UARBlueprintLibrary___AddRuntimeCandidateImage_Params Params{};
        Params.SessionConfig = SessionConfig;
        Params.CandidateTexture = CandidateTexture;
        Params.FriendlyName = FriendlyName;
        Params.PhysicalWidth = PhysicalWidth;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UARBlueprintLibrary::AddTrackedPointWithName(FTransform& WorldTransform, FString PointName, bool bDeletePointsWithSameName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.AddTrackedPointWithName");
    
        UARBlueprintLibrary___AddTrackedPointWithName_Params Params{};
        Params.WorldTransform = WorldTransform;
        Params.PointName = PointName;
        Params.bDeletePointsWithSameName = bDeletePointsWithSameName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        WorldTransform = Params.WorldTransform;
    
        return Params.ReturnValue;
    }

    void UARBlueprintLibrary::CalculateAlignmentTransform(FTransform& TransformInFirstCoordinateSystem, FTransform& TransformInSecondCoordinateSystem, FTransform& AlignmentTransform)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.CalculateAlignmentTransform");
    
        UARBlueprintLibrary___CalculateAlignmentTransform_Params Params{};
        Params.TransformInFirstCoordinateSystem = TransformInFirstCoordinateSystem;
        Params.TransformInSecondCoordinateSystem = TransformInSecondCoordinateSystem;
        Params.AlignmentTransform = AlignmentTransform;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        TransformInFirstCoordinateSystem = Params.TransformInFirstCoordinateSystem;
        TransformInSecondCoordinateSystem = Params.TransformInSecondCoordinateSystem;
        AlignmentTransform = Params.AlignmentTransform;
    }

    void UARBlueprintLibrary::CalculateClosestIntersection(TArray<FVector>& StartPoints, TArray<FVector>& EndPoints, FVector& ClosestIntersection)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.CalculateClosestIntersection");
    
        UARBlueprintLibrary___CalculateClosestIntersection_Params Params{};
        Params.StartPoints = StartPoints;
        Params.EndPoints = EndPoints;
        Params.ClosestIntersection = ClosestIntersection;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        StartPoints = Params.StartPoints;
        EndPoints = Params.EndPoints;
        ClosestIntersection = Params.ClosestIntersection;
    }

    void UARBlueprintLibrary::DebugDrawPin(UARPin* ARPin, UObject* WorldContextObject, FLinearColor Color, float Scale, float PersistForSeconds)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.DebugDrawPin");
    
        UARBlueprintLibrary___DebugDrawPin_Params Params{};
        Params.ARPin = ARPin;
        Params.WorldContextObject = WorldContextObject;
        Params.Color = Color;
        Params.Scale = Scale;
        Params.PersistForSeconds = PersistForSeconds;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARBlueprintLibrary::DebugDrawTrackedGeometry(UARTrackedGeometry* TrackedGeometry, UObject* WorldContextObject, FLinearColor Color, float OutlineThickness, float PersistForSeconds)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.DebugDrawTrackedGeometry");
    
        UARBlueprintLibrary___DebugDrawTrackedGeometry_Params Params{};
        Params.TrackedGeometry = TrackedGeometry;
        Params.WorldContextObject = WorldContextObject;
        Params.Color = Color;
        Params.OutlineThickness = OutlineThickness;
        Params.PersistForSeconds = PersistForSeconds;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    TArray<UARTrackedPoint*> UARBlueprintLibrary::FindTrackedPointsByName(FString PointName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.FindTrackedPointsByName");
    
        UARBlueprintLibrary___FindTrackedPointsByName_Params Params{};
        Params.PointName = PointName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FTransform UARBlueprintLibrary::GetAlignmentTransform()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.GetAlignmentTransform");
    
        UARBlueprintLibrary___GetAlignmentTransform_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<UARTrackedGeometry*> UARBlueprintLibrary::GetAllGeometries()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.GetAllGeometries");
    
        UARBlueprintLibrary___GetAllGeometries_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<UARTrackedGeometry*> UARBlueprintLibrary::GetAllGeometriesByClass(UClass* GeometryClass)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.GetAllGeometriesByClass");
    
        UARBlueprintLibrary___GetAllGeometriesByClass_Params Params{};
        Params.GeometryClass = GeometryClass;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<UARPin*> UARBlueprintLibrary::GetAllPins()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.GetAllPins");
    
        UARBlueprintLibrary___GetAllPins_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FARPose2D> UARBlueprintLibrary::GetAllTracked2DPoses()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.GetAllTracked2DPoses");
    
        UARBlueprintLibrary___GetAllTracked2DPoses_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FARSessionStatus UARBlueprintLibrary::GetARSessionStatus()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.GetARSessionStatus");
    
        UARBlueprintLibrary___GetARSessionStatus_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UARTexture* UARBlueprintLibrary::GetARTexture(EARTextureType TextureType)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.GetARTexture");
    
        UARBlueprintLibrary___GetARTexture_Params Params{};
        Params.TextureType = TextureType;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UARBlueprintLibrary::GetARWorldScale()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.GetARWorldScale");
    
        UARBlueprintLibrary___GetARWorldScale_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UARBlueprintLibrary::GetCameraIntrinsics(FARCameraIntrinsics& OutCameraIntrinsics)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.GetCameraIntrinsics");
    
        UARBlueprintLibrary___GetCameraIntrinsics_Params Params{};
        Params.OutCameraIntrinsics = OutCameraIntrinsics;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutCameraIntrinsics = Params.OutCameraIntrinsics;
    
        return Params.ReturnValue;
    }

    UARLightEstimate* UARBlueprintLibrary::GetCurrentLightEstimate()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.GetCurrentLightEstimate");
    
        UARBlueprintLibrary___GetCurrentLightEstimate_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UARBlueprintLibrary::GetNumberOfTrackedFacesSupported()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.GetNumberOfTrackedFacesSupported");
    
        UARBlueprintLibrary___GetNumberOfTrackedFacesSupported_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UARBlueprintLibrary::GetObjectClassificationAtLocation(FVector& InWorldLocation, EARObjectClassification& OutClassification, FVector& OutClassificationLocation, float MaxLocationDiff)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.GetObjectClassificationAtLocation");
    
        UARBlueprintLibrary___GetObjectClassificationAtLocation_Params Params{};
        Params.InWorldLocation = InWorldLocation;
        Params.OutClassification = OutClassification;
        Params.OutClassificationLocation = OutClassificationLocation;
        Params.MaxLocationDiff = MaxLocationDiff;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InWorldLocation = Params.InWorldLocation;
        OutClassification = Params.OutClassification;
        OutClassificationLocation = Params.OutClassificationLocation;
    
        return Params.ReturnValue;
    }

    TArray<FVector> UARBlueprintLibrary::GetPointCloud()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.GetPointCloud");
    
        UARBlueprintLibrary___GetPointCloud_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UARSessionConfig* UARBlueprintLibrary::GetSessionConfig()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.GetSessionConfig");
    
        UARBlueprintLibrary___GetSessionConfig_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FARVideoFormat> UARBlueprintLibrary::GetSupportedVideoFormats(EARSessionType SessionType)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.GetSupportedVideoFormats");
    
        UARBlueprintLibrary___GetSupportedVideoFormats_Params Params{};
        Params.SessionType = SessionType;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARTrackingQuality UARBlueprintLibrary::GetTrackingQuality()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.GetTrackingQuality");
    
        UARBlueprintLibrary___GetTrackingQuality_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARTrackingQualityReason UARBlueprintLibrary::GetTrackingQualityReason()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.GetTrackingQualityReason");
    
        UARBlueprintLibrary___GetTrackingQualityReason_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARWorldMappingState UARBlueprintLibrary::GetWorldMappingStatus()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.GetWorldMappingStatus");
    
        UARBlueprintLibrary___GetWorldMappingStatus_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UARBlueprintLibrary::IsARPinLocalStoreReady()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.IsARPinLocalStoreReady");
    
        UARBlueprintLibrary___IsARPinLocalStoreReady_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UARBlueprintLibrary::IsARPinLocalStoreSupported()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.IsARPinLocalStoreSupported");
    
        UARBlueprintLibrary___IsARPinLocalStoreSupported_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UARBlueprintLibrary::IsARSupported()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.IsARSupported");
    
        UARBlueprintLibrary___IsARSupported_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UARBlueprintLibrary::IsSceneReconstructionSupported(EARSessionType SessionType, EARSceneReconstruction SceneReconstructionMethod)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.IsSceneReconstructionSupported");
    
        UARBlueprintLibrary___IsSceneReconstructionSupported_Params Params{};
        Params.SessionType = SessionType;
        Params.SceneReconstructionMethod = SceneReconstructionMethod;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UARBlueprintLibrary::IsSessionTrackingFeatureSupported(EARSessionType SessionType, EARSessionTrackingFeature SessionTrackingFeature)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.IsSessionTrackingFeatureSupported");
    
        UARBlueprintLibrary___IsSessionTrackingFeatureSupported_Params Params{};
        Params.SessionType = SessionType;
        Params.SessionTrackingFeature = SessionTrackingFeature;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UARBlueprintLibrary::IsSessionTypeSupported(EARSessionType SessionType)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.IsSessionTypeSupported");
    
        UARBlueprintLibrary___IsSessionTypeSupported_Params Params{};
        Params.SessionType = SessionType;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FARTraceResult> UARBlueprintLibrary::LineTraceTrackedObjects(FVector2D ScreenCoord, bool bTestFeaturePoints, bool bTestGroundPlane, bool bTestPlaneExtents, bool bTestPlaneBoundaryPolygon)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.LineTraceTrackedObjects");
    
        UARBlueprintLibrary___LineTraceTrackedObjects_Params Params{};
        Params.ScreenCoord = ScreenCoord;
        Params.bTestFeaturePoints = bTestFeaturePoints;
        Params.bTestGroundPlane = bTestGroundPlane;
        Params.bTestPlaneExtents = bTestPlaneExtents;
        Params.bTestPlaneBoundaryPolygon = bTestPlaneBoundaryPolygon;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FARTraceResult> UARBlueprintLibrary::LineTraceTrackedObjects3D(FVector Start, FVector End, bool bTestFeaturePoints, bool bTestGroundPlane, bool bTestPlaneExtents, bool bTestPlaneBoundaryPolygon)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.LineTraceTrackedObjects3D");
    
        UARBlueprintLibrary___LineTraceTrackedObjects3D_Params Params{};
        Params.Start = Start;
        Params.End = End;
        Params.bTestFeaturePoints = bTestFeaturePoints;
        Params.bTestGroundPlane = bTestGroundPlane;
        Params.bTestPlaneExtents = bTestPlaneExtents;
        Params.bTestPlaneBoundaryPolygon = bTestPlaneBoundaryPolygon;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TMap<FName, UARPin*> UARBlueprintLibrary::LoadARPinsFromLocalStore()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.LoadARPinsFromLocalStore");
    
        UARBlueprintLibrary___LoadARPinsFromLocalStore_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UARBlueprintLibrary::PauseARSession()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.PauseARSession");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    UARPin* UARBlueprintLibrary::PinComponent(USceneComponent* ComponentToPin, FTransform& PinToWorldTransform, UARTrackedGeometry* TrackedGeometry, FName DebugName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.PinComponent");
    
        UARBlueprintLibrary___PinComponent_Params Params{};
        Params.ComponentToPin = ComponentToPin;
        Params.PinToWorldTransform = PinToWorldTransform;
        Params.TrackedGeometry = TrackedGeometry;
        Params.DebugName = DebugName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PinToWorldTransform = Params.PinToWorldTransform;
    
        return Params.ReturnValue;
    }

    bool UARBlueprintLibrary::PinComponentToARPin(USceneComponent* ComponentToPin, UARPin* Pin)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.PinComponentToARPin");
    
        UARBlueprintLibrary___PinComponentToARPin_Params Params{};
        Params.ComponentToPin = ComponentToPin;
        Params.Pin = Pin;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UARPin* UARBlueprintLibrary::PinComponentToTraceResult(USceneComponent* ComponentToPin, FARTraceResult& TraceResult, FName DebugName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.PinComponentToTraceResult");
    
        UARBlueprintLibrary___PinComponentToTraceResult_Params Params{};
        Params.ComponentToPin = ComponentToPin;
        Params.TraceResult = TraceResult;
        Params.DebugName = DebugName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        TraceResult = Params.TraceResult;
    
        return Params.ReturnValue;
    }

    void UARBlueprintLibrary::RemoveAllARPinsFromLocalStore()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.RemoveAllARPinsFromLocalStore");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UARBlueprintLibrary::RemoveARPinFromLocalStore(FName InSaveName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.RemoveARPinFromLocalStore");
    
        UARBlueprintLibrary___RemoveARPinFromLocalStore_Params Params{};
        Params.InSaveName = InSaveName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARBlueprintLibrary::RemovePin(UARPin* PinToRemove)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.RemovePin");
    
        UARBlueprintLibrary___RemovePin_Params Params{};
        Params.PinToRemove = PinToRemove;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    FIntPoint UARBlueprintLibrary::ResizeXRCamera(FIntPoint& InSize)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.ResizeXRCamera");
    
        UARBlueprintLibrary___ResizeXRCamera_Params Params{};
        Params.InSize = InSize;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InSize = Params.InSize;
    
        return Params.ReturnValue;
    }

    bool UARBlueprintLibrary::SaveARPinToLocalStore(FName InSaveName, UARPin* InPin)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.SaveARPinToLocalStore");
    
        UARBlueprintLibrary___SaveARPinToLocalStore_Params Params{};
        Params.InSaveName = InSaveName;
        Params.InPin = InPin;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UARBlueprintLibrary::SetAlignmentTransform(FTransform& InAlignmentTransform)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.SetAlignmentTransform");
    
        UARBlueprintLibrary___SetAlignmentTransform_Params Params{};
        Params.InAlignmentTransform = InAlignmentTransform;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InAlignmentTransform = Params.InAlignmentTransform;
    }

    void UARBlueprintLibrary::SetARWorldOriginLocationAndRotation(FVector OriginLocation, FRotator OriginRotation, bool bIsTransformInWorldSpace, bool bMaintainUpDirection)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.SetARWorldOriginLocationAndRotation");
    
        UARBlueprintLibrary___SetARWorldOriginLocationAndRotation_Params Params{};
        Params.OriginLocation = OriginLocation;
        Params.OriginRotation = OriginRotation;
        Params.bIsTransformInWorldSpace = bIsTransformInWorldSpace;
        Params.bMaintainUpDirection = bMaintainUpDirection;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARBlueprintLibrary::SetARWorldScale(float InWorldScale)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.SetARWorldScale");
    
        UARBlueprintLibrary___SetARWorldScale_Params Params{};
        Params.InWorldScale = InWorldScale;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARBlueprintLibrary::SetEnabledXRCamera(bool bOnOff)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.SetEnabledXRCamera");
    
        UARBlueprintLibrary___SetEnabledXRCamera_Params Params{};
        Params.bOnOff = bOnOff;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARBlueprintLibrary::StartARSession(UARSessionConfig* SessionConfig)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.StartARSession");
    
        UARBlueprintLibrary___StartARSession_Params Params{};
        Params.SessionConfig = SessionConfig;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARBlueprintLibrary::StopARSession()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.StopARSession");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    bool UARBlueprintLibrary::ToggleARCapture(bool bOnOff, EARCaptureType CaptureType)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.ToggleARCapture");
    
        UARBlueprintLibrary___ToggleARCapture_Params Params{};
        Params.bOnOff = bOnOff;
        Params.CaptureType = CaptureType;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UARBlueprintLibrary::UnpinComponent(USceneComponent* ComponentToUnpin)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARBlueprintLibrary.UnpinComponent");
    
        UARBlueprintLibrary___UnpinComponent_Params Params{};
        Params.ComponentToUnpin = ComponentToUnpin;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UTexture2D* UARCandidateImage::GetCandidateTexture()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARCandidateImage.GetCandidateTexture");
    
        UARCandidateImage___GetCandidateTexture_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FString UARCandidateImage::GetFriendlyName()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARCandidateImage.GetFriendlyName");
    
        UARCandidateImage___GetFriendlyName_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARCandidateImageOrientation UARCandidateImage::GetOrientation()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARCandidateImage.GetOrientation");
    
        UARCandidateImage___GetOrientation_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UARCandidateImage::GetPhysicalHeight()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARCandidateImage.GetPhysicalHeight");
    
        UARCandidateImage___GetPhysicalHeight_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UARCandidateImage::GetPhysicalWidth()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARCandidateImage.GetPhysicalWidth");
    
        UARCandidateImage___GetPhysicalWidth_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBox UARCandidateObject::GetBoundingBox()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARCandidateObject.GetBoundingBox");
    
        UARCandidateObject___GetBoundingBox_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<uint8> UARCandidateObject::GetCandidateObjectData()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARCandidateObject.GetCandidateObjectData");
    
        UARCandidateObject___GetCandidateObjectData_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FString UARCandidateObject::GetFriendlyName()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARCandidateObject.GetFriendlyName");
    
        UARCandidateObject___GetFriendlyName_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UARCandidateObject::SetBoundingBox(FBox& InBoundingBox)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARCandidateObject.SetBoundingBox");
    
        UARCandidateObject___SetBoundingBox_Params Params{};
        Params.InBoundingBox = InBoundingBox;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InBoundingBox = Params.InBoundingBox;
    }

    void UARCandidateObject::SetCandidateObjectData(TArray<uint8>& InCandidateObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARCandidateObject.SetCandidateObjectData");
    
        UARCandidateObject___SetCandidateObjectData_Params Params{};
        Params.InCandidateObject = InCandidateObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InCandidateObject = Params.InCandidateObject;
    }

    void UARCandidateObject::SetFriendlyName(FString NewName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARCandidateObject.SetFriendlyName");
    
        UARCandidateObject___SetFriendlyName_Params Params{};
        Params.NewName = NewName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UMRMeshComponent* UARComponent::GetMRMesh()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARComponent.GetMRMesh");
    
        UARComponent___GetMRMesh_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UARComponent::OnRep_Payload()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARComponent.OnRep_Payload");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UARComponent::ReceiveRemove()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARComponent.ReceiveRemove");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UARComponent::SetNativeID(FGuid NativeID)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARComponent.SetNativeID");
    
        UARComponent___SetNativeID_Params Params{};
        Params.NativeID = NativeID;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARComponent::UpdateVisualization()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARComponent.UpdateVisualization");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UARDependencyHandler::CheckARServiceAvailability(UObject* WorldContextObject, FLatentActionInfo LatentInfo, EARServiceAvailability& OutAvailability)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARDependencyHandler.CheckARServiceAvailability");
    
        UARDependencyHandler___CheckARServiceAvailability_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.LatentInfo = LatentInfo;
        Params.OutAvailability = OutAvailability;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutAvailability = Params.OutAvailability;
    }

    UARDependencyHandler* UARDependencyHandler::GetARDependencyHandler()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARDependencyHandler.GetARDependencyHandler");
    
        UARDependencyHandler___GetARDependencyHandler_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UARDependencyHandler::InstallARService(UObject* WorldContextObject, FLatentActionInfo LatentInfo, EARServiceInstallRequestResult& OutInstallResult)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARDependencyHandler.InstallARService");
    
        UARDependencyHandler___InstallARService_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.LatentInfo = LatentInfo;
        Params.OutInstallResult = OutInstallResult;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutInstallResult = Params.OutInstallResult;
    }

    void UARDependencyHandler::RequestARSessionPermission(UObject* WorldContextObject, UARSessionConfig* SessionConfig, FLatentActionInfo LatentInfo, EARServicePermissionRequestResult& OutPermissionResult)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARDependencyHandler.RequestARSessionPermission");
    
        UARDependencyHandler___RequestARSessionPermission_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.SessionConfig = SessionConfig;
        Params.LatentInfo = LatentInfo;
        Params.OutPermissionResult = OutPermissionResult;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutPermissionResult = Params.OutPermissionResult;
    }

    void UARDependencyHandler::StartARSessionLatent(UObject* WorldContextObject, UARSessionConfig* SessionConfig, FLatentActionInfo LatentInfo)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARDependencyHandler.StartARSessionLatent");
    
        UARDependencyHandler___StartARSessionLatent_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.SessionConfig = SessionConfig;
        Params.LatentInfo = LatentInfo;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UAREnvironmentCaptureProbeTexture* UAREnvironmentCaptureProbe::GetEnvironmentCaptureTexture()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.AREnvironmentCaptureProbe.GetEnvironmentCaptureTexture");
    
        UAREnvironmentCaptureProbe___GetEnvironmentCaptureTexture_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FVector UAREnvironmentCaptureProbe::GetExtent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.AREnvironmentCaptureProbe.GetExtent");
    
        UAREnvironmentCaptureProbe___GetExtent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAREnvironmentProbeComponent::ReceiveAdd(FAREnvironmentProbeUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.AREnvironmentProbeComponent.ReceiveAdd");
    
        UAREnvironmentProbeComponent___ReceiveAdd_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UAREnvironmentProbeComponent::ReceiveUpdate(FAREnvironmentProbeUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.AREnvironmentProbeComponent.ReceiveUpdate");
    
        UAREnvironmentProbeComponent___ReceiveUpdate_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UAREnvironmentProbeComponent::ServerUpdatePayload(FAREnvironmentProbeUpdatePayload NewPayload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.AREnvironmentProbeComponent.ServerUpdatePayload");
    
        UAREnvironmentProbeComponent___ServerUpdatePayload_Params Params{};
        Params.NewPayload = NewPayload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARFaceComponent::ReceiveAdd(FARFaceUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARFaceComponent.ReceiveAdd");
    
        UARFaceComponent___ReceiveAdd_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UARFaceComponent::ReceiveUpdate(FARFaceUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARFaceComponent.ReceiveUpdate");
    
        UARFaceComponent___ReceiveUpdate_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UARFaceComponent::ServerUpdatePayload(FARFaceUpdatePayload NewPayload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARFaceComponent.ServerUpdatePayload");
    
        UARFaceComponent___ServerUpdatePayload_Params Params{};
        Params.NewPayload = NewPayload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARFaceComponent::SetFaceComponentDebugMode(EFaceComponentDebugMode NewDebugMode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARFaceComponent.SetFaceComponentDebugMode");
    
        UARFaceComponent___SetFaceComponentDebugMode_Params Params{};
        Params.NewDebugMode = NewDebugMode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    TMap<EARFaceBlendShape, float> UARFaceGeometry::GetBlendShapes()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARFaceGeometry.GetBlendShapes");
    
        UARFaceGeometry___GetBlendShapes_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UARFaceGeometry::GetBlendShapeValue(EARFaceBlendShape BlendShape)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARFaceGeometry.GetBlendShapeValue");
    
        UARFaceGeometry___GetBlendShapeValue_Params Params{};
        Params.BlendShape = BlendShape;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FTransform UARFaceGeometry::GetLocalSpaceEyeTransform(EAREye Eye)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARFaceGeometry.GetLocalSpaceEyeTransform");
    
        UARFaceGeometry___GetLocalSpaceEyeTransform_Params Params{};
        Params.Eye = Eye;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FTransform UARFaceGeometry::GetWorldSpaceEyeTransform(EAREye Eye)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARFaceGeometry.GetWorldSpaceEyeTransform");
    
        UARFaceGeometry___GetWorldSpaceEyeTransform_Params Params{};
        Params.Eye = Eye;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UARGeoAnchor::GetAltitudeMeters()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARGeoAnchor.GetAltitudeMeters");
    
        UARGeoAnchor___GetAltitudeMeters_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARAltitudeSource UARGeoAnchor::GetAltitudeSource()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARGeoAnchor.GetAltitudeSource");
    
        UARGeoAnchor___GetAltitudeSource_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UARGeoAnchor::GetLatitude()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARGeoAnchor.GetLatitude");
    
        UARGeoAnchor___GetLatitude_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UARGeoAnchor::GetLongitude()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARGeoAnchor.GetLongitude");
    
        UARGeoAnchor___GetLongitude_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UARGeoAnchorComponent::ReceiveAdd(FARGeoAnchorUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARGeoAnchorComponent.ReceiveAdd");
    
        UARGeoAnchorComponent___ReceiveAdd_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UARGeoAnchorComponent::ReceiveUpdate(FARGeoAnchorUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARGeoAnchorComponent.ReceiveUpdate");
    
        UARGeoAnchorComponent___ReceiveUpdate_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UARGeoAnchorComponent::ServerUpdatePayload(FARGeoAnchorUpdatePayload NewPayload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARGeoAnchorComponent.ServerUpdatePayload");
    
        UARGeoAnchorComponent___ServerUpdatePayload_Params Params{};
        Params.NewPayload = NewPayload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARGeoAnchorComponent::SetGeoAnchorComponentDebugMode(EGeoAnchorComponentDebugMode NewDebugMode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARGeoAnchorComponent.SetGeoAnchorComponentDebugMode");
    
        UARGeoAnchorComponent___SetGeoAnchorComponentDebugMode_Params Params{};
        Params.NewDebugMode = NewDebugMode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UARGeoTrackingSupport::AddGeoAnchorAtLocation(float Longitude, float Latitude, FString OptionalAnchorName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARGeoTrackingSupport.AddGeoAnchorAtLocation");
    
        UARGeoTrackingSupport___AddGeoAnchorAtLocation_Params Params{};
        Params.Longitude = Longitude;
        Params.Latitude = Latitude;
        Params.OptionalAnchorName = OptionalAnchorName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UARGeoTrackingSupport::AddGeoAnchorAtLocationWithAltitude(float Longitude, float Latitude, float AltitudeMeters, FString OptionalAnchorName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARGeoTrackingSupport.AddGeoAnchorAtLocationWithAltitude");
    
        UARGeoTrackingSupport___AddGeoAnchorAtLocationWithAltitude_Params Params{};
        Params.Longitude = Longitude;
        Params.Latitude = Latitude;
        Params.AltitudeMeters = AltitudeMeters;
        Params.OptionalAnchorName = OptionalAnchorName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARGeoTrackingAccuracy UARGeoTrackingSupport::GetGeoTrackingAccuracy()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingAccuracy");
    
        UARGeoTrackingSupport___GetGeoTrackingAccuracy_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARGeoTrackingState UARGeoTrackingSupport::GetGeoTrackingState()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingState");
    
        UARGeoTrackingSupport___GetGeoTrackingState_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARGeoTrackingStateReason UARGeoTrackingSupport::GetGeoTrackingStateReason()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingStateReason");
    
        UARGeoTrackingSupport___GetGeoTrackingStateReason_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UARGeoTrackingSupport* UARGeoTrackingSupport::GetGeoTrackingSupport()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingSupport");
    
        UARGeoTrackingSupport___GetGeoTrackingSupport_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UARGetCandidateObjectAsyncTaskBlueprintProxy* UARGetCandidateObjectAsyncTaskBlueprintProxy::ARGetCandidateObject(UObject* WorldContextObject, FVector Location, FVector Extent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARGetCandidateObjectAsyncTaskBlueprintProxy.ARGetCandidateObject");
    
        UARGetCandidateObjectAsyncTaskBlueprintProxy___ARGetCandidateObject_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Location = Location;
        Params.Extent = Extent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UARImageComponent::ReceiveAdd(FARImageUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARImageComponent.ReceiveAdd");
    
        UARImageComponent___ReceiveAdd_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UARImageComponent::ReceiveUpdate(FARImageUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARImageComponent.ReceiveUpdate");
    
        UARImageComponent___ReceiveUpdate_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UARImageComponent::ServerUpdatePayload(FARImageUpdatePayload NewPayload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARImageComponent.ServerUpdatePayload");
    
        UARImageComponent___ServerUpdatePayload_Params Params{};
        Params.NewPayload = NewPayload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARImageComponent::SetImageComponentDebugMode(EImageComponentDebugMode NewDebugMode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARImageComponent.SetImageComponentDebugMode");
    
        UARImageComponent___SetImageComponentDebugMode_Params Params{};
        Params.NewDebugMode = NewDebugMode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARLifeCycleComponent::ServerDestroyARActor(AARActor* Actor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARLifeCycleComponent.ServerDestroyARActor");
    
        UARLifeCycleComponent___ServerDestroyARActor_Params Params{};
        Params.Actor = Actor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARLifeCycleComponent::ServerSpawnARActor(UClass* ComponentClass, FGuid NativeID)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARLifeCycleComponent.ServerSpawnARActor");
    
        UARLifeCycleComponent___ServerSpawnARActor_Params Params{};
        Params.ComponentClass = ComponentClass;
        Params.NativeID = NativeID;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARLifeCycleComponent::InstanceARActorSpawnedDelegate(UClass* ComponentClass, FGuid NativeID, AARActor* SpawnedActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARLifeCycleComponent.InstanceARActorSpawnedDelegate");
    
        UARLifeCycleComponent___InstanceARActorSpawnedDelegate_Params Params{};
        Params.ComponentClass = ComponentClass;
        Params.NativeID = NativeID;
        Params.SpawnedActor = SpawnedActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARLifeCycleComponent::InstanceARActorToBeDestroyedDelegate(AARActor* Actor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARLifeCycleComponent.InstanceARActorToBeDestroyedDelegate");
    
        UARLifeCycleComponent___InstanceARActorToBeDestroyedDelegate_Params Params{};
        Params.Actor = Actor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARMeshComponent::ReceiveAdd(FARMeshUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARMeshComponent.ReceiveAdd");
    
        UARMeshComponent___ReceiveAdd_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UARMeshComponent::ReceiveUpdate(FARMeshUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARMeshComponent.ReceiveUpdate");
    
        UARMeshComponent___ReceiveUpdate_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UARMeshComponent::ServerUpdatePayload(FARMeshUpdatePayload NewPayload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARMeshComponent.ServerUpdatePayload");
    
        UARMeshComponent___ServerUpdatePayload_Params Params{};
        Params.NewPayload = NewPayload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UARMeshGeometry::GetObjectClassificationAtLocation(FVector& InWorldLocation, EARObjectClassification& OutClassification, FVector& OutClassificationLocation, float MaxLocationDiff)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARMeshGeometry.GetObjectClassificationAtLocation");
    
        UARMeshGeometry___GetObjectClassificationAtLocation_Params Params{};
        Params.InWorldLocation = InWorldLocation;
        Params.OutClassification = OutClassification;
        Params.OutClassificationLocation = OutClassificationLocation;
        Params.MaxLocationDiff = MaxLocationDiff;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InWorldLocation = Params.InWorldLocation;
        OutClassification = Params.OutClassification;
        OutClassificationLocation = Params.OutClassificationLocation;
    
        return Params.ReturnValue;
    }

    void UARObjectComponent::ReceiveAdd(FARObjectUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARObjectComponent.ReceiveAdd");
    
        UARObjectComponent___ReceiveAdd_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UARObjectComponent::ReceiveUpdate(FARObjectUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARObjectComponent.ReceiveUpdate");
    
        UARObjectComponent___ReceiveUpdate_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UARObjectComponent::ServerUpdatePayload(FARObjectUpdatePayload NewPayload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARObjectComponent.ServerUpdatePayload");
    
        UARObjectComponent___ServerUpdatePayload_Params Params{};
        Params.NewPayload = NewPayload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARPin::DebugDraw(UWorld* World, FLinearColor& Color, float Scale, float PersistForSeconds)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPin.DebugDraw");
    
        UARPin___DebugDraw_Params Params{};
        Params.World = World;
        Params.Color = Color;
        Params.Scale = Scale;
        Params.PersistForSeconds = PersistForSeconds;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Color = Params.Color;
    }

    FName UARPin::GetDebugName()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPin.GetDebugName");
    
        UARPin___GetDebugName_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FTransform UARPin::GetLocalToTrackingTransform()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPin.GetLocalToTrackingTransform");
    
        UARPin___GetLocalToTrackingTransform_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FTransform UARPin::GetLocalToWorldTransform()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPin.GetLocalToWorldTransform");
    
        UARPin___GetLocalToWorldTransform_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    USceneComponent* UARPin::GetPinnedComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPin.GetPinnedComponent");
    
        UARPin___GetPinnedComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UARTrackedGeometry* UARPin::GetTrackedGeometry()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPin.GetTrackedGeometry");
    
        UARPin___GetTrackedGeometry_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARTrackingState UARPin::GetTrackingState()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPin.GetTrackingState");
    
        UARPin___GetTrackingState_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TMap<EARObjectClassification, FLinearColor> UARPlaneComponent::GetObjectClassificationDebugColors()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPlaneComponent.GetObjectClassificationDebugColors");
    
        UARPlaneComponent___GetObjectClassificationDebugColors_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UARPlaneComponent::ReceiveAdd(FARPlaneUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPlaneComponent.ReceiveAdd");
    
        UARPlaneComponent___ReceiveAdd_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UARPlaneComponent::ReceiveUpdate(FARPlaneUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPlaneComponent.ReceiveUpdate");
    
        UARPlaneComponent___ReceiveUpdate_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UARPlaneComponent::ServerUpdatePayload(FARPlaneUpdatePayload NewPayload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPlaneComponent.ServerUpdatePayload");
    
        UARPlaneComponent___ServerUpdatePayload_Params Params{};
        Params.NewPayload = NewPayload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARPlaneComponent::SetObjectClassificationDebugColors(TMap<EARObjectClassification, FLinearColor>& InColors)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPlaneComponent.SetObjectClassificationDebugColors");
    
        UARPlaneComponent___SetObjectClassificationDebugColors_Params Params{};
        Params.InColors = InColors;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InColors = Params.InColors;
    }

    void UARPlaneComponent::SetPlaneComponentDebugMode(EPlaneComponentDebugMode NewDebugMode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPlaneComponent.SetPlaneComponentDebugMode");
    
        UARPlaneComponent___SetPlaneComponentDebugMode_Params Params{};
        Params.NewDebugMode = NewDebugMode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    TArray<FVector> UARPlaneGeometry::GetBoundaryPolygonInLocalSpace()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPlaneGeometry.GetBoundaryPolygonInLocalSpace");
    
        UARPlaneGeometry___GetBoundaryPolygonInLocalSpace_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FVector UARPlaneGeometry::GetCenter()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPlaneGeometry.GetCenter");
    
        UARPlaneGeometry___GetCenter_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FVector UARPlaneGeometry::GetExtent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPlaneGeometry.GetExtent");
    
        UARPlaneGeometry___GetExtent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARPlaneOrientation UARPlaneGeometry::GetOrientation()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPlaneGeometry.GetOrientation");
    
        UARPlaneGeometry___GetOrientation_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UARPlaneGeometry* UARPlaneGeometry::GetSubsumedBy()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPlaneGeometry.GetSubsumedBy");
    
        UARPlaneGeometry___GetSubsumedBy_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UARPointComponent::ReceiveAdd(FARPointUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPointComponent.ReceiveAdd");
    
        UARPointComponent___ReceiveAdd_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UARPointComponent::ReceiveUpdate(FARPointUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPointComponent.ReceiveUpdate");
    
        UARPointComponent___ReceiveUpdate_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UARPointComponent::ServerUpdatePayload(FARPointUpdatePayload NewPayload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPointComponent.ServerUpdatePayload");
    
        UARPointComponent___ServerUpdatePayload_Params Params{};
        Params.NewPayload = NewPayload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARPoseComponent::ReceiveAdd(FARPoseUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPoseComponent.ReceiveAdd");
    
        UARPoseComponent___ReceiveAdd_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UARPoseComponent::ReceiveUpdate(FARPoseUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPoseComponent.ReceiveUpdate");
    
        UARPoseComponent___ReceiveUpdate_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UARPoseComponent::ServerUpdatePayload(FARPoseUpdatePayload NewPayload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPoseComponent.ServerUpdatePayload");
    
        UARPoseComponent___ServerUpdatePayload_Params Params{};
        Params.NewPayload = NewPayload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARPoseComponent::SetPoseComponentDebugMode(EPoseComponentDebugMode NewDebugMode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARPoseComponent.SetPoseComponentDebugMode");
    
        UARPoseComponent___SetPoseComponentDebugMode_Params Params{};
        Params.NewDebugMode = NewDebugMode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARQRCodeComponent::ReceiveAdd(FARQRCodeUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARQRCodeComponent.ReceiveAdd");
    
        UARQRCodeComponent___ReceiveAdd_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UARQRCodeComponent::ReceiveUpdate(FARQRCodeUpdatePayload& Payload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARQRCodeComponent.ReceiveUpdate");
    
        UARQRCodeComponent___ReceiveUpdate_Params Params{};
        Params.Payload = Payload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Payload = Params.Payload;
    }

    void UARQRCodeComponent::ServerUpdatePayload(FARQRCodeUpdatePayload NewPayload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARQRCodeComponent.ServerUpdatePayload");
    
        UARQRCodeComponent___ServerUpdatePayload_Params Params{};
        Params.NewPayload = NewPayload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARQRCodeComponent::SetQRCodeComponentDebugMode(EQRCodeComponentDebugMode NewDebugMode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARQRCodeComponent.SetQRCodeComponentDebugMode");
    
        UARQRCodeComponent___SetQRCodeComponentDebugMode_Params Params{};
        Params.NewDebugMode = NewDebugMode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UARSaveWorldAsyncTaskBlueprintProxy* UARSaveWorldAsyncTaskBlueprintProxy::ARSaveWorld(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSaveWorldAsyncTaskBlueprintProxy.ARSaveWorld");
    
        UARSaveWorldAsyncTaskBlueprintProxy___ARSaveWorld_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UARSessionConfig::AddCandidateImage(UARCandidateImage* NewCandidateImage)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.AddCandidateImage");
    
        UARSessionConfig___AddCandidateImage_Params Params{};
        Params.NewCandidateImage = NewCandidateImage;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARSessionConfig::AddCandidateObject(UARCandidateObject* CandidateObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.AddCandidateObject");
    
        UARSessionConfig___AddCandidateObject_Params Params{};
        Params.CandidateObject = CandidateObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARSessionConfig::ClearCandidateImages()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.ClearCandidateImages");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    TArray<UARCandidateImage*> UARSessionConfig::GetCandidateImageList()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.GetCandidateImageList");
    
        UARSessionConfig___GetCandidateImageList_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<UARCandidateObject*> UARSessionConfig::GetCandidateObjectList()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.GetCandidateObjectList");
    
        UARSessionConfig___GetCandidateObjectList_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FARVideoFormat UARSessionConfig::GetDesiredVideoFormat()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.GetDesiredVideoFormat");
    
        UARSessionConfig___GetDesiredVideoFormat_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARSessionTrackingFeature UARSessionConfig::GetEnabledSessionTrackingFeature()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.GetEnabledSessionTrackingFeature");
    
        UARSessionConfig___GetEnabledSessionTrackingFeature_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EAREnvironmentCaptureProbeType UARSessionConfig::GetEnvironmentCaptureProbeType()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.GetEnvironmentCaptureProbeType");
    
        UARSessionConfig___GetEnvironmentCaptureProbeType_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARFaceTrackingDirection UARSessionConfig::GetFaceTrackingDirection()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.GetFaceTrackingDirection");
    
        UARSessionConfig___GetFaceTrackingDirection_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARFaceTrackingUpdate UARSessionConfig::GetFaceTrackingUpdate()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.GetFaceTrackingUpdate");
    
        UARSessionConfig___GetFaceTrackingUpdate_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARFrameSyncMode UARSessionConfig::GetFrameSyncMode()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.GetFrameSyncMode");
    
        UARSessionConfig___GetFrameSyncMode_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARLightEstimationMode UARSessionConfig::GetLightEstimationMode()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.GetLightEstimationMode");
    
        UARSessionConfig___GetLightEstimationMode_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UARSessionConfig::GetMaxNumSimultaneousImagesTracked()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.GetMaxNumSimultaneousImagesTracked");
    
        UARSessionConfig___GetMaxNumSimultaneousImagesTracked_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARPlaneDetectionMode UARSessionConfig::GetPlaneDetectionMode()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.GetPlaneDetectionMode");
    
        UARSessionConfig___GetPlaneDetectionMode_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARSceneReconstruction UARSessionConfig::GetSceneReconstructionMethod()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.GetSceneReconstructionMethod");
    
        UARSessionConfig___GetSceneReconstructionMethod_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARSessionType UARSessionConfig::GetSessionType()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.GetSessionType");
    
        UARSessionConfig___GetSessionType_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARWorldAlignment UARSessionConfig::GetWorldAlignment()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.GetWorldAlignment");
    
        UARSessionConfig___GetWorldAlignment_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<uint8> UARSessionConfig::GetWorldMapData()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.GetWorldMapData");
    
        UARSessionConfig___GetWorldMapData_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UARSessionConfig::RemoveCandidateImage(UARCandidateImage* CandidateImage)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.RemoveCandidateImage");
    
        UARSessionConfig___RemoveCandidateImage_Params Params{};
        Params.CandidateImage = CandidateImage;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARSessionConfig::RemoveCandidateImageAtIndex(int32 Index)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.RemoveCandidateImageAtIndex");
    
        UARSessionConfig___RemoveCandidateImageAtIndex_Params Params{};
        Params.Index = Index;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARSessionConfig::SetCandidateObjectList(TArray<UARCandidateObject*>& InCandidateObjects)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.SetCandidateObjectList");
    
        UARSessionConfig___SetCandidateObjectList_Params Params{};
        Params.InCandidateObjects = InCandidateObjects;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InCandidateObjects = Params.InCandidateObjects;
    }

    void UARSessionConfig::SetDesiredVideoFormat(FARVideoFormat NewFormat)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.SetDesiredVideoFormat");
    
        UARSessionConfig___SetDesiredVideoFormat_Params Params{};
        Params.NewFormat = NewFormat;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARSessionConfig::SetEnableAutoFocus(bool bNewValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.SetEnableAutoFocus");
    
        UARSessionConfig___SetEnableAutoFocus_Params Params{};
        Params.bNewValue = bNewValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARSessionConfig::SetFaceTrackingDirection(EARFaceTrackingDirection InDirection)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.SetFaceTrackingDirection");
    
        UARSessionConfig___SetFaceTrackingDirection_Params Params{};
        Params.InDirection = InDirection;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARSessionConfig::SetFaceTrackingUpdate(EARFaceTrackingUpdate InUpdate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.SetFaceTrackingUpdate");
    
        UARSessionConfig___SetFaceTrackingUpdate_Params Params{};
        Params.InUpdate = InUpdate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARSessionConfig::SetResetCameraTracking(bool bNewValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.SetResetCameraTracking");
    
        UARSessionConfig___SetResetCameraTracking_Params Params{};
        Params.bNewValue = bNewValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARSessionConfig::SetResetTrackedObjects(bool bNewValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.SetResetTrackedObjects");
    
        UARSessionConfig___SetResetTrackedObjects_Params Params{};
        Params.bNewValue = bNewValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARSessionConfig::SetSceneReconstructionMethod(EARSceneReconstruction InSceneReconstructionMethod)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.SetSceneReconstructionMethod");
    
        UARSessionConfig___SetSceneReconstructionMethod_Params Params{};
        Params.InSceneReconstructionMethod = InSceneReconstructionMethod;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARSessionConfig::SetSessionTrackingFeatureToEnable(EARSessionTrackingFeature InSessionTrackingFeature)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.SetSessionTrackingFeatureToEnable");
    
        UARSessionConfig___SetSessionTrackingFeatureToEnable_Params Params{};
        Params.InSessionTrackingFeature = InSessionTrackingFeature;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UARSessionConfig::SetWorldMapData(TArray<uint8> WorldMapData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.SetWorldMapData");
    
        UARSessionConfig___SetWorldMapData_Params Params{};
        Params.WorldMapData = WorldMapData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UARSessionConfig::ShouldEnableAutoFocus()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.ShouldEnableAutoFocus");
    
        UARSessionConfig___ShouldEnableAutoFocus_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UARSessionConfig::ShouldEnableCameraTracking()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.ShouldEnableCameraTracking");
    
        UARSessionConfig___ShouldEnableCameraTracking_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UARSessionConfig::ShouldRenderCameraOverlay()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.ShouldRenderCameraOverlay");
    
        UARSessionConfig___ShouldRenderCameraOverlay_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UARSessionConfig::ShouldResetCameraTracking()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.ShouldResetCameraTracking");
    
        UARSessionConfig___ShouldResetCameraTracking_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UARSessionConfig::ShouldResetTrackedObjects()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARSessionConfig.ShouldResetTrackedObjects");
    
        UARSessionConfig___ShouldResetTrackedObjects_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UARTraceResultLibrary::GetDistanceFromCamera(FARTraceResult& TraceResult)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTraceResultLibrary.GetDistanceFromCamera");
    
        UARTraceResultLibrary___GetDistanceFromCamera_Params Params{};
        Params.TraceResult = TraceResult;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        TraceResult = Params.TraceResult;
    
        return Params.ReturnValue;
    }

    FTransform UARTraceResultLibrary::GetLocalToTrackingTransform(FARTraceResult& TraceResult)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTraceResultLibrary.GetLocalToTrackingTransform");
    
        UARTraceResultLibrary___GetLocalToTrackingTransform_Params Params{};
        Params.TraceResult = TraceResult;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        TraceResult = Params.TraceResult;
    
        return Params.ReturnValue;
    }

    FTransform UARTraceResultLibrary::GetLocalToWorldTransform(FARTraceResult& TraceResult)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTraceResultLibrary.GetLocalToWorldTransform");
    
        UARTraceResultLibrary___GetLocalToWorldTransform_Params Params{};
        Params.TraceResult = TraceResult;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        TraceResult = Params.TraceResult;
    
        return Params.ReturnValue;
    }

    FTransform UARTraceResultLibrary::GetLocalTransform(FARTraceResult& TraceResult)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTraceResultLibrary.GetLocalTransform");
    
        UARTraceResultLibrary___GetLocalTransform_Params Params{};
        Params.TraceResult = TraceResult;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        TraceResult = Params.TraceResult;
    
        return Params.ReturnValue;
    }

    EARLineTraceChannels UARTraceResultLibrary::GetTraceChannel(FARTraceResult& TraceResult)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTraceResultLibrary.GetTraceChannel");
    
        UARTraceResultLibrary___GetTraceChannel_Params Params{};
        Params.TraceResult = TraceResult;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        TraceResult = Params.TraceResult;
    
        return Params.ReturnValue;
    }

    UARTrackedGeometry* UARTraceResultLibrary::GetTrackedGeometry(FARTraceResult& TraceResult)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTraceResultLibrary.GetTrackedGeometry");
    
        UARTraceResultLibrary___GetTrackedGeometry_Params Params{};
        Params.TraceResult = TraceResult;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        TraceResult = Params.TraceResult;
    
        return Params.ReturnValue;
    }

    FName UARTrackedGeometry::GetDebugName()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTrackedGeometry.GetDebugName");
    
        UARTrackedGeometry___GetDebugName_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UARTrackedGeometry::GetLastUpdateFrameNumber()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTrackedGeometry.GetLastUpdateFrameNumber");
    
        UARTrackedGeometry___GetLastUpdateFrameNumber_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UARTrackedGeometry::GetLastUpdateTimestamp()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTrackedGeometry.GetLastUpdateTimestamp");
    
        UARTrackedGeometry___GetLastUpdateTimestamp_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FTransform UARTrackedGeometry::GetLocalToTrackingTransform()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTrackedGeometry.GetLocalToTrackingTransform");
    
        UARTrackedGeometry___GetLocalToTrackingTransform_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FTransform UARTrackedGeometry::GetLocalToWorldTransform()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTrackedGeometry.GetLocalToWorldTransform");
    
        UARTrackedGeometry___GetLocalToWorldTransform_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FString UARTrackedGeometry::GetName()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTrackedGeometry.GetName");
    
        UARTrackedGeometry___GetName_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARObjectClassification UARTrackedGeometry::GetObjectClassification()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTrackedGeometry.GetObjectClassification");
    
        UARTrackedGeometry___GetObjectClassification_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EARTrackingState UARTrackedGeometry::GetTrackingState()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTrackedGeometry.GetTrackingState");
    
        UARTrackedGeometry___GetTrackingState_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UMRMeshComponent* UARTrackedGeometry::GetUnderlyingMesh()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTrackedGeometry.GetUnderlyingMesh");
    
        UARTrackedGeometry___GetUnderlyingMesh_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UARTrackedGeometry::HasSpatialMeshUsageFlag(EARSpatialMeshUsageFlags InFlag)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTrackedGeometry.HasSpatialMeshUsageFlag");
    
        UARTrackedGeometry___HasSpatialMeshUsageFlag_Params Params{};
        Params.InFlag = InFlag;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UARTrackedGeometry::IsTracked()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTrackedGeometry.IsTracked");
    
        UARTrackedGeometry___IsTracked_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UARCandidateImage* UARTrackedImage::GetDetectedImage()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTrackedImage.GetDetectedImage");
    
        UARTrackedImage___GetDetectedImage_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FVector2D UARTrackedImage::GetEstimateSize()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTrackedImage.GetEstimateSize");
    
        UARTrackedImage___GetEstimateSize_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UARCandidateObject* UARTrackedObject::GetDetectedObject()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTrackedObject.GetDetectedObject");
    
        UARTrackedObject___GetDetectedObject_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FARPose3D UARTrackedPose::GetTrackedPoseData()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.ARTrackedPose.GetTrackedPoseData");
    
        UARTrackedPose___GetTrackedPoseData_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy* UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy::CheckGeoTrackingAvailability(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy.CheckGeoTrackingAvailability");
    
        UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy___CheckGeoTrackingAvailability_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy* UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy::CheckGeoTrackingAvailabilityAtLocation(UObject* WorldContextObject, float Longitude, float Latitude)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy.CheckGeoTrackingAvailabilityAtLocation");
    
        UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy___CheckGeoTrackingAvailabilityAtLocation_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Longitude = Longitude;
        Params.Latitude = Latitude;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy::GeoTrackingAvailabilityDelegate(bool bIsAvailable, FString Error)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy.GeoTrackingAvailabilityDelegate");
    
        UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy___GeoTrackingAvailabilityDelegate_Params Params{};
        Params.bIsAvailable = bIsAvailable;
        Params.Error = Error;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UGetGeoLocationAsyncTaskBlueprintProxy* UGetGeoLocationAsyncTaskBlueprintProxy::GetGeoLocationAtWorldPosition(UObject* WorldContextObject, FVector& WorldPosition)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.GetGeoLocationAsyncTaskBlueprintProxy.GetGeoLocationAtWorldPosition");
    
        UGetGeoLocationAsyncTaskBlueprintProxy___GetGeoLocationAtWorldPosition_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.WorldPosition = WorldPosition;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        WorldPosition = Params.WorldPosition;
    
        return Params.ReturnValue;
    }

    void UGetGeoLocationAsyncTaskBlueprintProxy::GetGeoLocationDelegate(float Longitude, float Latitude, float Altitude, FString Error)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AugmentedReality.GetGeoLocationAsyncTaskBlueprintProxy.GetGeoLocationDelegate");
    
        UGetGeoLocationAsyncTaskBlueprintProxy___GetGeoLocationDelegate_Params Params{};
        Params.Longitude = Longitude;
        Params.Latitude = Latitude;
        Params.Altitude = Altitude;
        Params.Error = Error;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

