/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AccoladesUI
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000338 (0x000008)
    class alignas(0x8) UAthenaAccoladeListEntryWidget : public UCommonUserWidget
    {
    public:
        void**  VTable_000330;  // 0x000330 (0x000008) VTable [7 slots] -> 0x146AE3E0
    
    public: // Functions
        void    SetCount(int32 Count); // 0x000545D2 [Event | Protected | BlueprintCallable | BlueprintEvent]
        void    SetIcon(UFortAccoladeItemDefinition* ItemDef); // 0x000545D2 [Event | Protected | BlueprintCallable | BlueprintEvent]
        void    SetIconImage(TSoftObjectPtr<UTexture2D>& IconImage, EFortAccoladeType AccoladeType, EFortAccoladeTierType AccoladeTier); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintCallable | BlueprintEvent]
        void    SetJustCompleted(bool bJustCompleted); // 0x000545D2 [Event | Protected | BlueprintCallable | BlueprintEvent]
        void    SetSource(FText& SourceText); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintCallable | BlueprintEvent]
        void    SetTitle(FText& TitleText); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintCallable | BlueprintEvent]
    };
    // Size: 0x000FE0 (0x000000)
    class UAthenaAccoladeListWidget : public UCommonListView
    {
    public:
    
    public: // Functions
        void    PopulateWidget(); // 0x10BF99FE [Final | Native | Public | BlueprintCallable]
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x8) UAthenaAccoladeWrapper : public UObject
    {
    public:
        FName                       AccoladeRowName;    // 0x000028 (0x000004) [Default: NAME_None]
        FFortAccoladeSessionData    AccoladeData;       // 0x00002C (0x00000C)
    };
    // Size: 0x000001 (0x000001)
    struct FFortEvent_AccoladesUITriggerAccoladesListWidgetRemoval
    {
        uint8   UnknownByte_000000; // 0x000000 (0x000001)
    };
}

