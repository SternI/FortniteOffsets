/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AircraftADSUI
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0000A0 (0x000028)
    class UAircraftADSPOIVM : public UFortPerUserViewModel
    {
    public:
        uint8   UnknownData_000078[0x000028];   // 0x000078 (0x000028)
    
    public: // Functions
        bool    IsGolden(); // 0x10BFEEFA [Final | Native | Private | BlueprintCallable | BlueprintPure | Const]
        bool    IsPOISelected(); // 0x10BFEF20 [Final | Native | Private | BlueprintCallable | BlueprintPure | Const]
        FText   POIName(); // 0x10BFEFE0 [Final | Native | Private | BlueprintCallable | BlueprintPure | Const]
        void    SetPOIVolume(AFortPoiVolume* InPOIVolume); // 0x07ED004E [Final | Native | Public | BlueprintCallable]
    };
    // Size: 0x000160 (0x0000A0)
    class alignas(0x8) UFortPlayerControllerComponent_AircraftADSUI : public UControllerComponent
    {
    public:
        FGameplayTag                                    POIWidgetAliasTag;              // 0x0000C0 (0x000004)
        uint8                                           UnknownData_0000C4[0x000004];   // 0x0000C4 (0x000004)
        FScalableFloat                                  POIHighlightMaxAngle;           // 0x0000C8 (0x000028)
        uint8                                           UnknownData_0000F0[0x000010];   // 0x0000F0 (0x000010)
        TMap<TWeakObjectPtr<AFortPoiVolume>, FVector>   POIVolumeWorldCenters;          // 0x000100 (0x000010)
        uint8                                           UnknownData_000110[0x000050];   // 0x000110 (0x000050)
    
    public: // Functions
        void    HandleEnterAircraft(AController* Controller); // 0x07ED01BC [Final | Native | Private]
        void    HandleExitAircraft(AController* Controller); // 0x07ED0326 [Final | Native | Private]
        bool    IsPOIBubbleEnabled(); // 0x10BFF4C0 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        void    OnAircraftZoomInActivated(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnAircraftZoomInDeactivated(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnEnterAircraft(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnExitAircraft(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnPOIVolumeSelectionChanged(AFortPoiVolume* POIVolume); // 0x000545D2 [Event | Protected | BlueprintEvent]
    };
    // Size: 0x000001 (0x000001)
    struct FFortEvent_AircraftADSPOIVolumeSelectionChanged
    {
        bool    bPOISelected;   // 0x000000 (0x000001)
    };
}

