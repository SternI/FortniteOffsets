/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AirJellyfishRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000470 (0x000020)
    class alignas(0x8) UFortAirJellyfishAnimInstance : public UFortAnimInstance
    {
    public:
        float       RotatorLerpRate;            // 0x000450 (0x000004) [Default: 0.7f]
        float       VelocityDirectionScalar;    // 0x000454 (0x000004) [Default: 0.2f]
        FRotator    RootRotation;               // 0x000458 (0x000018)
    };
}

