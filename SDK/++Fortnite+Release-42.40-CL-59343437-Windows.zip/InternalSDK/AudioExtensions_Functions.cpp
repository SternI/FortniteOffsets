/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:12
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioExtensions_Functions
 * ============================================================
 */

#include "AudioExtensions_Functions.hpp"

namespace UE
{

    void IAudioParameterControllerInterface::ResetParameters()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioExtensions.AudioParameterControllerInterface.ResetParameters");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void IAudioParameterControllerInterface::SetBoolArrayParameter(FName InName, TArray<bool>& InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioExtensions.AudioParameterControllerInterface.SetBoolArrayParameter");
    
        IAudioParameterControllerInterface___SetBoolArrayParameter_Params Params{};
        Params.InName = InName;
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InValue = Params.InValue;
    }

    void IAudioParameterControllerInterface::SetBoolParameter(FName InName, bool InBool)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioExtensions.AudioParameterControllerInterface.SetBoolParameter");
    
        IAudioParameterControllerInterface___SetBoolParameter_Params Params{};
        Params.InName = InName;
        Params.InBool = InBool;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void IAudioParameterControllerInterface::SetFloatArrayParameter(FName InName, TArray<float>& InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioExtensions.AudioParameterControllerInterface.SetFloatArrayParameter");
    
        IAudioParameterControllerInterface___SetFloatArrayParameter_Params Params{};
        Params.InName = InName;
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InValue = Params.InValue;
    }

    void IAudioParameterControllerInterface::SetFloatParameter(FName InName, float InFloat)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioExtensions.AudioParameterControllerInterface.SetFloatParameter");
    
        IAudioParameterControllerInterface___SetFloatParameter_Params Params{};
        Params.InName = InName;
        Params.InFloat = InFloat;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void IAudioParameterControllerInterface::SetIntArrayParameter(FName InName, TArray<int32>& InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioExtensions.AudioParameterControllerInterface.SetIntArrayParameter");
    
        IAudioParameterControllerInterface___SetIntArrayParameter_Params Params{};
        Params.InName = InName;
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InValue = Params.InValue;
    }

    void IAudioParameterControllerInterface::SetIntParameter(FName InName, int32 InInt)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioExtensions.AudioParameterControllerInterface.SetIntParameter");
    
        IAudioParameterControllerInterface___SetIntParameter_Params Params{};
        Params.InName = InName;
        Params.InInt = InInt;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void IAudioParameterControllerInterface::SetObjectArrayParameter(FName InName, TArray<UObject*>& InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioExtensions.AudioParameterControllerInterface.SetObjectArrayParameter");
    
        IAudioParameterControllerInterface___SetObjectArrayParameter_Params Params{};
        Params.InName = InName;
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InValue = Params.InValue;
    }

    void IAudioParameterControllerInterface::SetObjectParameter(FName InName, UObject* InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioExtensions.AudioParameterControllerInterface.SetObjectParameter");
    
        IAudioParameterControllerInterface___SetObjectParameter_Params Params{};
        Params.InName = InName;
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void IAudioParameterControllerInterface::SetParameters_Blueprint(TArray<FAudioParameter>& InParameters)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioExtensions.AudioParameterControllerInterface.SetParameters_Blueprint");
    
        IAudioParameterControllerInterface___SetParameters_Blueprint_Params Params{};
        Params.InParameters = InParameters;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InParameters = Params.InParameters;
    }

    void IAudioParameterControllerInterface::SetStringArrayParameter(FName InName, TArray<FString>& InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioExtensions.AudioParameterControllerInterface.SetStringArrayParameter");
    
        IAudioParameterControllerInterface___SetStringArrayParameter_Params Params{};
        Params.InName = InName;
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InValue = Params.InValue;
    }

    void IAudioParameterControllerInterface::SetStringParameter(FName InName, FString InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioExtensions.AudioParameterControllerInterface.SetStringParameter");
    
        IAudioParameterControllerInterface___SetStringParameter_Params Params{};
        Params.InName = InName;
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void IAudioParameterControllerInterface::SetTriggerParameter(FName InName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioExtensions.AudioParameterControllerInterface.SetTriggerParameter");
    
        IAudioParameterControllerInterface___SetTriggerParameter_Params Params{};
        Params.InName = InName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

