/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioMotorSim_Functions
 * ============================================================
 */

#include "AudioMotorSim.hpp"

namespace UE
{

    struct UAudioMotorModelComponent___AddMotorAudioComponent_Params
    {
        TScriptInterface<IAudioMotorSimOutput>  InComponent;    // 0x000000 (0x000010)
    };

    struct UAudioMotorModelComponent___AddMotorSimComponent_Params
    {
        TScriptInterface<IAudioMotorSim>    InComponent;    // 0x000000 (0x000010)
        int32                               SortOrder;      // 0x000010 (0x000004) [Default: 393197312]
    };

    struct UAudioMotorModelComponent___ConfigureMotorSimComponents_Params
    {
        TArray<FInstancedStruct>    InConfigData;   // 0x000000 (0x000010) [OutParam]
    };

    struct UAudioMotorModelComponent___GetCachedInputData_Params
    {
        FAudioMotorSimInputContext  ReturnValue;    // 0x000000 (0x00002C) [ReturnValue]
    };

    struct UAudioMotorModelComponent___GetGear_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 325829408]
    };

    struct UAudioMotorModelComponent___GetRpm_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 2.97574e-27f]
    };

    struct UAudioMotorModelComponent___GetRuntimeInfo_Params
    {
        FAudioMotorSimRuntimeContext    ReturnValue;    // 0x000000 (0x000018) [ReturnValue]
    };

    struct UAudioMotorModelComponent___RemoveMotorAudioComponent_Params
    {
        TScriptInterface<IAudioMotorSimOutput>  InComponent;    // 0x000000 (0x000010)
    };

    struct UAudioMotorModelComponent___RemoveMotorSimComponent_Params
    {
        TScriptInterface<IAudioMotorSim>    InComponent;    // 0x000000 (0x000010)
    };

    struct UAudioMotorModelComponent___Update_Params
    {
        FAudioMotorSimInputContext  Input;  // 0x000000 (0x00002C) [OutParam]
    };

    struct IAudioMotorSim___ConfigMotorSim_Params
    {
        FInstancedStruct    InConfigData;   // 0x000000 (0x000010) [OutParam]
    };

    struct IAudioMotorSim___GetEnabled_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioMotorSimComponent___BP_Update_Params
    {
        FAudioMotorSimInputContext      Input;          // 0x000000 (0x00002C) [OutParam]
        FAudioMotorSimRuntimeContext    RuntimeInfo;    // 0x00002C (0x000018) [OutParam]
        bool                            ReturnValue;    // 0x000044 (0x000001) [ReturnValue] [Default: false]
    };

    struct UAudioMotorSimComponent___SetEnabled_Params
    {
        bool    bNewEnabled;    // 0x000000 (0x000001) [Default: true]
    };

} // namespace UE

