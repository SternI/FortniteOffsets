/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArcadeWeaponUI
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0000A0 (0x000028)
    class UArcadeWeaponInGameUIHitPointsVM : public UFortPerUserViewModel
    {
    public:
        uint8   UnknownData_000078[0x000028];   // 0x000078 (0x000028)
    
    public: // Functions
        bool        GetIsTrickShot(); // 0x10C4D58A [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FText       GetScoreText(); // 0x10C4D670 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FVector2D   GetScoreTextRenderTranslation(); // 0x10C4D6EC [Final | Native | Public | HasDefaults | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x0000A0 (0x000028)
    class UArcadeWeaponUIScoreVM : public UFortPerUserViewModel
    {
    public:
        uint8   UnknownData_000078[0x000028];   // 0x000078 (0x000028)
    
    public: // Functions
        int32   GetCurrentMatchScore(); // 0x10C4DAE8 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32   GetCurrentStreak(); // 0x10C4DB2E [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
}

