/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BeanstalkManagersRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000070 (0x000048)
    class alignas(0x8) UBeanstalkAccountItemDefinitionOverrideManager : public UObject
    {
    public:
        void**                                                          VTable_000028;                  // 0x000028 (0x000008) VTable [10 slots] -> 0x147734F0
        TSoftObjectPtr<UBeanCosmeticsData>                              BeanCosmetics;                  // 0x000030 (0x000020) [Default: nullptr]
        UBeanCosmeticsData*                                             BeanCosmeticsDataCache;         // 0x000050 (0x000008) [Default: nullptr]
        TMap<FPrimaryAssetId, FBeanstalkAccountItemDefinitionOverride>  OverrideCache;                  // 0x000058 (0x000010)
        uint8                                                           UnknownData_000068[0x000008];   // 0x000068 (0x000008)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FBeanstalkAccountItemDefinitionOverride
    {
        UFortAccountItemDefinition* AccountItemDefinition;          // 0x000000 (0x000008)
        uint8                       UnknownData_000008[0x000008];   // 0x000008 (0x000008)
    };
}

