/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BackToHub
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000190 (0x000000)
    class UBackToHubRegistry : public UFortSettingRegistry
    {
    public:
    };
    // Size: 0x0005B8 (0x000000)
    class UBackToHubScreen : public USettingsScreen
    {
    public:
    };
    // Size: 0x000060 (0x000030)
    class UBackToHubSettingSubsystem : public UFortLocalPlayerSubsystem
    {
    public:
        uint8   UnknownData_000030[0x000030];   // 0x000030 (0x000030)
    };
    // Size: 0x000050 (0x000020)
    class alignas(0x8) UBackToHubSettings : public UDeveloperSettings
    {
    public:
        TArray<FString>                     HubLinkCodes;       // 0x000030 (0x000010)
        TArray<FSettingRegistryManifest>    RegistryManifests;  // 0x000040 (0x000010)
    };
}

