/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BeatSyncedAnimRuntime_Functions
 * ============================================================
 */

#include "BeatSyncedAnimRuntime.hpp"

namespace UE
{

    struct UBeatSyncedAnimLibrary___GetLastEmoteExecuted_Params
    {
        AController*            Controller;     // 0x000000 (0x000008) [Default: 0x130A5F60]
        UFortItemDefinition*    ReturnValue;    // 0x000008 (0x000008) [ReturnValue] [Default: 0x386318DD00000031]
    };

    struct UFMBeatTimingUtils___GetCurrentBeatAndTime_Params
    {
        UMusicClockComponent*   MusicClock;     // 0x000000 (0x000008) [Default: 0x130A5F60]
        UObject*                WorldContext;   // 0x000008 (0x000008) [Default: 0x376318DD00000031]
        FBeatAndTime            ReturnValue;    // 0x000010 (0x000010) [ReturnValue]
    };

    struct UMontageBeatSyncComponent___GetOwnerFortPlayerPawn_Params
    {
        AFortPlayerPawn*    ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14957930]
    };

    struct UMontageBeatSyncComponent___GetOwnerSkeletalMeshActor_Params
    {
        ASkeletalMeshActor* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14957930]
    };

    struct UMontageBeatSyncComponent___GetOwnerSkeletalMeshComponent_Params
    {
        USkeletalMeshComponent* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14957930]
    };

    struct UMontageBeatSyncComponent___IsMusicPlaying_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UMontageBeatSyncComponent___OnClockPlayStateChanged_Params
    {
        EMusicClockState    NewState;   // 0x000000 (0x000001) [Default: EMusicClockState(48)]
    };

    struct UMontageBeatSyncComponent___OnMontageEnded_Params
    {
        UAnimMontage*   Montage;        // 0x000000 (0x000008) [Default: 0x14957930]
        bool            bInterrupted;   // 0x000008 (0x000001) [Default: true]
    };

    struct UMontageBeatSyncComponent___OnMontageStarted_Params
    {
        UAnimMontage*   Montage;    // 0x000000 (0x000008) [Default: 0x14957930]
    };

    struct UMontageBeatSyncComponent___OnMusicEventClockStateChanged_Params
    {
        UMusicEventInstance*    MusicEvent; // 0x000000 (0x000008) [Default: 0x14957930]
    };

    struct UMontageBeatSyncComponent___OnRep_MusicClock_Params
    {
        TWeakObjectPtr<UMusicClockComponent>    OldWeakMusicClockPtr;   // 0x000000 (0x000008) [OutParam] [Default: 0x14957930]
    };

    struct UMontageBeatSyncComponent___ServerRPC_SetBeatSyncingPermission_Params
    {
        bool    bNewPermission; // 0x000000 (0x000001) [Default: true]
    };

    struct UMontageBeatSyncComponent___ServerRPC_SetMusicClock_Params
    {
        UMusicClockComponent*   NewMusicClock;  // 0x000000 (0x000008) [Default: 0x14957930]
    };

    struct UMontageBeatSyncComponent___ServerRPC_StartStopBSE_Params
    {
        bool    bStarted;   // 0x000000 (0x000001) [Default: true]
    };

    struct UMontageBeatSyncComponent___SetMusicClock_Params
    {
        UMusicClockComponent*   NewMusicClock;  // 0x000000 (0x000008) [Default: 0x14957930]
    };

} // namespace UE

