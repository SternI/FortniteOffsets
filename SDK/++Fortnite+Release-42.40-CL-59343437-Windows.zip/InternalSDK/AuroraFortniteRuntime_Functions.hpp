/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AuroraFortniteRuntime_Functions
 * ============================================================
 */

#include "AuroraFortniteRuntime.hpp"

namespace UE
{

    struct UAuroraFortnitePlayerControllerComponent___OnMinigameStateChanged_Params
    {
        AFortMinigame*      InMinigame; // 0x000000 (0x000008) [Default: 0x14906030]
        EFortMinigameState  InNewState; // 0x000008 (0x000001) [Default: EFortMinigameState(49)]
    };

    struct UAuroraFortnitePlayerControllerComponent___Server_SetPlatformFamily_Params
    {
        FString InPlatformFamily;   // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UCustomDebugCommand_AuroraPurchasesAlwaysFail___GetAlwaysFailPurchases_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UCustomDebugCommand_AuroraPurchasesAlwaysFail___SetAlwaysFailPurchases_Params
    {
        bool    bInAlwaysFailPurchases; // 0x000000 (0x000001) [Default: true]
    };

} // namespace UE

