/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:12
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimationCore
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000038 (0x000010)
    class alignas(0x8) UAnimationDataSourceRegistry : public UObject
    {
    public:
        TMap<FName, TWeakObjectPtr<UObject>>    DataSources;    // 0x000028 (0x000010)
    };
    // Size: 0x000070 (0x000060)
    struct alignas(0x8) FAimConstraintDescription : public FConstraintDescriptionEx
    {
        FAxis   LookAt_Axis;                    // 0x000010 (0x000020)
        FAxis   LookUp_Axis;                    // 0x000030 (0x000020)
        bool    bUseLookUp;                     // 0x000050 (0x000001)
        uint8   UnknownData_000051[0x000007];   // 0x000051 (0x000007)
        FVector LookUpTarget;                   // 0x000058 (0x000018)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FAxis
    {
        FVector Axis;                           // 0x000000 (0x000018)
        bool    bInLocalSpace;                  // 0x000018 (0x000001)
        uint8   UnknownData_000019[0x000007];   // 0x000019 (0x000007)
    };
    // Size: 0x0000E0 (0x0000E0)
    struct FCCDIKChainLink
    {
        uint8   UnknownData_000000[0x0000E0];   // 0x000000 (0x0000E0)
    };
    // Size: 0x0000E0 (0x0000E0)
    struct alignas(0x8) FConstraintData
    {
        FConstraintDescriptor   Constraint;                     // 0x000000 (0x000010)
        float                   Weight;                         // 0x000010 (0x000004) [Default: 1.42825e-31f]
        bool                    bMaintainOffset;                // 0x000014 (0x000001) [Default: false]
        uint8                   UnknownData_000015[0x00000B];   // 0x000015 (0x00000B)
        FTransform              Offset;                         // 0x000020 (0x000060)
        FTransform              CurrentTransform;               // 0x000080 (0x000060)
    };
    // Size: 0x00000D (0x00000D)
    struct alignas(0x3) FConstraintDescription
    {
        bool                    bTranslation;       // 0x000000 (0x000001)
        bool                    bRotation;          // 0x000001 (0x000001)
        bool                    bScale;             // 0x000002 (0x000001)
        bool                    bParent;            // 0x000003 (0x000001)
        FFilterOptionPerAxis    TranslationAxes;    // 0x000004 (0x000003)
        FFilterOptionPerAxis    RotationAxes;       // 0x000007 (0x000003)
        FFilterOptionPerAxis    ScaleAxes;          // 0x00000A (0x000003)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x3) FConstraintDescriptionEx
    {
        uint8                   UnknownData_000000[0x000008];   // 0x000000 (0x000008)
        FFilterOptionPerAxis    AxesFilterOption;               // 0x000008 (0x000003)
        uint8                   UnknownData_00000B[0x000005];   // 0x00000B (0x000005)
    };
    // Size: 0x000010 (0x000010)
    struct FConstraintDescriptor
    {
        EConstraintType Type;                           // 0x000000 (0x000001)
        uint8           UnknownData_000001[0x00000F];   // 0x000001 (0x00000F)
    };
    // Size: 0x0000C0 (0x0000C0)
    struct alignas(0x8) FConstraintOffset
    {
        FVector     Translation;                    // 0x000000 (0x000018)
        uint8       UnknownData_000018[0x000008];   // 0x000018 (0x000008)
        FQuat       Rotation;                       // 0x000020 (0x000020)
        FVector     Scale;                          // 0x000040 (0x000018)
        uint8       UnknownData_000058[0x000008];   // 0x000058 (0x000008)
        FTransform  Parent;                         // 0x000060 (0x000060)
    };
    // Size: 0x000048 (0x000048)
    struct alignas(0x8) FEulerTransform
    {
        FVector     Location;   // 0x000000 (0x000018)
        FRotator    Rotation;   // 0x000018 (0x000018)
        FVector     Scale;      // 0x000030 (0x000018)
    };
    // Size: 0x000050 (0x000050)
    struct FFABRIKChainLink
    {
        uint8   UnknownData_000000[0x000050];   // 0x000000 (0x000050)
    };
    // Size: 0x000003 (0x000003)
    struct FFilterOptionPerAxis
    {
        bool    bX; // 0x000000 (0x000001)
        bool    bY; // 0x000001 (0x000001)
        bool    bZ; // 0x000002 (0x000001)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FNodeChain
    {
        TArray<FName>   Nodes;  // 0x000000 (0x000010)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FNodeHierarchyData
    {
        TArray<FNodeObject> Nodes;                  // 0x000000 (0x000010)
        TArray<FTransform>  Transforms;             // 0x000010 (0x000010)
        TMap<FName, int32>  NodeNameToIndexMapping; // 0x000020 (0x000010)
    };
    // Size: 0x000038 (0x000038)
    struct alignas(0x8) FNodeHierarchyWithUserData
    {
        uint8               UnknownData_000000[0x000008];   // 0x000000 (0x000008)
        FNodeHierarchyData  Hierarchy;                      // 0x000008 (0x000030)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FNodeObject
    {
        FName   Name;       // 0x000000 (0x000004)
        FName   ParentName; // 0x000004 (0x000004)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FTransformConstraint
    {
        FConstraintDescription  Operator;                       // 0x000000 (0x00000D)
        uint8                   UnknownData_00000D[0x000003];   // 0x00000D (0x000003)
        FName                   SourceNode;                     // 0x000010 (0x000004) [Default: NAME_None]
        FName                   TargetNode;                     // 0x000014 (0x000004) [Default: NAME_None]
        float                   Weight;                         // 0x000018 (0x000004) [Default: 0f]
        bool                    bMaintainOffset;                // 0x00001C (0x000001) [Default: false]
        uint8                   UnknownData_00001D[0x000003];   // 0x00001D (0x000003)
    };
    // Size: 0x000018 (0x000008)
    struct FTransformConstraintDescription : public FConstraintDescriptionEx
    {
        ETransformConstraintType    TransformType;                  // 0x000010 (0x000001)
        uint8                       UnknownData_000011[0x000007];   // 0x000011 (0x000007)
    };
    // Size: 0x000009 (0x000009)
    struct alignas(0x3) FTransformFilter
    {
        FFilterOptionPerAxis    TranslationFilter;  // 0x000000 (0x000003)
        FFilterOptionPerAxis    RotationFilter;     // 0x000003 (0x000003)
        FFilterOptionPerAxis    ScaleFilter;        // 0x000006 (0x000003)
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x8) FTransformNoScale
    {
        FVector Location;                       // 0x000000 (0x000018)
        uint8   UnknownData_000018[0x000008];   // 0x000018 (0x000008)
        FQuat   Rotation;                       // 0x000020 (0x000020)
    };
}

