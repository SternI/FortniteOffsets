/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AppleImageUtils
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class IAppleImageInterface : public IInterface
    {
    public:
    };
    // Size: 0x000088 (0x000060)
    class alignas(0x8) UAppleImageUtilsBaseAsyncTaskBlueprintProxy : public UObject
    {
    public:
        void**                                              VTable_000028;                  // 0x000028 (0x000008) VTable [9 slots] -> 0x134D75F0
        MULTI_INLINE_DELEGATE(AppleImageConversionDelegate) OnSuccess;                      // 0x000030 (0x000010)
        MULTI_INLINE_DELEGATE(AppleImageConversionDelegate) OnFailure;                      // 0x000040 (0x000010)
        uint8                                               UnknownData_000050[0x000010];   // 0x000050 (0x000010)
        FAppleImageUtilsImageConversionResult               ConversionResult;               // 0x000060 (0x000020)
        uint8                                               UnknownData_000080[0x000008];   // 0x000080 (0x000008)
    
    public: // Functions
        static UAppleImageUtilsBaseAsyncTaskBlueprintProxy*    CreateProxyObjectForConvertToHEIF(UTexture* SourceImage, int32 Quality, bool bWantColor, bool bUseGpu, float Scale, ETextureRotationDirection Rotate); // 0x056766B8 [Final | Native | Static | Public | BlueprintCallable]
        static UAppleImageUtilsBaseAsyncTaskBlueprintProxy*    CreateProxyObjectForConvertToJPEG(UTexture* SourceImage, int32 Quality, bool bWantColor, bool bUseGpu, float Scale, ETextureRotationDirection Rotate); // 0x05676C9A [Final | Native | Static | Public | BlueprintCallable]
        static UAppleImageUtilsBaseAsyncTaskBlueprintProxy*    CreateProxyObjectForConvertToPNG(UTexture* SourceImage, bool bWantColor, bool bUseGpu, float Scale, ETextureRotationDirection Rotate); // 0x0567727C [Final | Native | Static | Public | BlueprintCallable]
        static UAppleImageUtilsBaseAsyncTaskBlueprintProxy*    CreateProxyObjectForConvertToTIFF(UTexture* SourceImage, bool bWantColor, bool bUseGpu, float Scale, ETextureRotationDirection Rotate); // 0x0567779E [Final | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FAppleImageUtilsImageConversionResult
    {
        FString         Error;      // 0x000000 (0x000010)
        TArray<uint8>   ImageData;  // 0x000010 (0x000010)
    };
}

