/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:09
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimationBudgetAllocator
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class UAnimationBudgetBlueprintLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static void    EnableAnimationBudget(UObject* WorldContextObject, bool bEnabled); // 0x04DFB7BA [Final | Native | Static | Private | BlueprintCallable]
        static void    SetAnimationBudgetParameters(UObject* WorldContextObject, FAnimationBudgetAllocatorParameters& InParameters); // 0x04DFBA34 [Final | Native | Static | Private | HasOutParms | BlueprintCallable]
    };
    // Size: 0x001040 (0x000030)
    class USkeletalMeshComponentBudgeted : public USkeletalMeshComponent
    {
    public:
        uint8   UnknownData_001010[0x000020];       // 0x001010 (0x000020)
        uint8   bAutoRegisterWithBudgetAllocator : 1; // 0x001030 (0x000001) : 0x0 [Default: true]
        uint8   bAutoCalculateSignificance : 1;     // 0x001030 (0x000001) : 0x0 [Default: true]
        uint8   bShouldUseActorRenderedFlag : 1;    // 0x001030 (0x000001) : 0x0 [Default: true]
        uint8   UnknownBit_001030_1 : 1;            // 0x001030 (0x000001) : 0x1
        uint8   UnknownBit_001030_2 : 1;            // 0x001030 (0x000001) : 0x2
        uint8   UnknownBit_001030_3 : 1;            // 0x001030 (0x000001) : 0x3
        uint8   UnknownBit_001030_4 : 1;            // 0x001030 (0x000001) : 0x4
        uint8   UnknownBit_001030_5 : 1;            // 0x001030 (0x000001) : 0x5
        uint8   UnknownBit_001030_6 : 1;            // 0x001030 (0x000001) : 0x6
        uint8   UnknownBit_001030_7 : 1;            // 0x001030 (0x000001) : 0x7
        uint8   UnknownData_001031[0x00000F];       // 0x001031 (0x00000F)
    
    public: // Functions
        void    SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator); // 0x04DFBD60 [Final | Native | Public | BlueprintCallable]
    };
    // Size: 0x000058 (0x000058)
    struct alignas(0x4) FAnimationBudgetAllocatorParameters
    {
        float   BudgetInMs;                                 // 0x000000 (0x000004) [Default: 0f]
        float   MinQuality;                                 // 0x000004 (0x000004) [Default: 0f]
        int32   MaxTickRate;                                // 0x000008 (0x000004) [Default: 0]
        float   WorkUnitSmoothingSpeed;                     // 0x00000C (0x000004) [Default: 0f]
        float   AlwaysTickFalloffAggression;                // 0x000010 (0x000004) [Default: 0f]
        float   InterpolationFalloffAggression;             // 0x000014 (0x000004) [Default: 0f]
        int32   InterpolationMaxRate;                       // 0x000018 (0x000004) [Default: 0]
        int32   MaxInterpolatedComponents;                  // 0x00001C (0x000004) [Default: 0]
        float   InterpolationTickMultiplier;                // 0x000020 (0x000004) [Default: 0f]
        float   InitialEstimatedWorkUnitTimeMs;             // 0x000024 (0x000004) [Default: 0f]
        int32   MaxTickedOffsreenComponents;                // 0x000028 (0x000004) [Default: 0]
        int32   StateChangeThrottleInFrames;                // 0x00002C (0x000004) [Default: 0]
        float   BudgetFactorBeforeReducedWork;              // 0x000030 (0x000004) [Default: 0f]
        float   BudgetFactorBeforeReducedWorkEpsilon;       // 0x000034 (0x000004) [Default: 0f]
        float   BudgetPressureSmoothingSpeed;               // 0x000038 (0x000004) [Default: 0f]
        int32   ReducedWorkThrottleMinInFrames;             // 0x00003C (0x000004) [Default: 0]
        int32   ReducedWorkThrottleMaxInFrames;             // 0x000040 (0x000004) [Default: 0]
        float   BudgetFactorBeforeAggressiveReducedWork;    // 0x000044 (0x000004) [Default: 0f]
        int32   ReducedWorkThrottleMaxPerFrame;             // 0x000048 (0x000004) [Default: 0]
        float   BudgetPressureBeforeEmergencyReducedWork;   // 0x00004C (0x000004) [Default: 0f]
        float   AutoCalculatedSignificanceMaxDistance;      // 0x000050 (0x000004) [Default: 0f]
        uint8   UnknownData_000054[0x000004];               // 0x000054 (0x000004)
    };
}

