/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArcadeMinigamesRuntime_Functions
 * ============================================================
 */

#include "ArcadeMinigamesRuntime.hpp"

namespace UE
{

    struct UFortControllerComponent_ArcadeMinigame___BeginSession_Params
    {
        UDynamicUIScene*    Scene;  // 0x000000 (0x000008) [Default: 0x14899380]
    };

    struct UFortControllerComponent_ArcadeMinigame___ClientStartLocalArcade_Params
    {
        UDynamicUIScene*    Scene;  // 0x000000 (0x000008) [Default: 0x14899380]
    };

    struct UFortControllerComponent_ArcadeMinigame___GetArcadeMinigameComponentForPlayer_Params
    {
        APlayerController*                          PlayerController;   // 0x000000 (0x000008) [Default: 0x14899380]
        UFortControllerComponent_ArcadeMinigame*    ReturnValue;        // 0x000008 (0x000008) [ReturnValue] [Default: 0xB95E18DD00000031]
    };

    struct UFortControllerComponent_ArcadeMinigame___IsInSession_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UFortControllerComponent_ArcadeMinigame___OnPawnDBNOStateChanged_Params
    {
        AFortPawn*  FortPawn;   // 0x000000 (0x000008) [Default: 0x14899380]
        bool        bInIsDBNO;  // 0x000008 (0x000001) [Default: true]
    };

} // namespace UE

