/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:48
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AIDebuggerRuntime_Functions
 * ============================================================
 */

#include "AIDebuggerRuntime_Functions.hpp"

namespace UE
{

    void UAIDebuggerCheatManager::EnableNavMeshVisualizer(bool bEnable)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIDebuggerRuntime.AIDebuggerCheatManager.EnableNavMeshVisualizer");
    
        UAIDebuggerCheatManager___EnableNavMeshVisualizer_Params Params{};
        Params.bEnable = bEnable;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIDebuggerCheatManager::NextNavMesh()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIDebuggerRuntime.AIDebuggerCheatManager.NextNavMesh");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAIDebuggerCheatManager::StartAIDebugger(FString AIDebuggerSoftClassPath)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIDebuggerRuntime.AIDebuggerCheatManager.StartAIDebugger");
    
        UAIDebuggerCheatManager___StartAIDebugger_Params Params{};
        Params.AIDebuggerSoftClassPath = AIDebuggerSoftClassPath;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAIDebuggerRendererComponent::OnNPCBoundsTimerTick()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIDebuggerRuntime.AIDebuggerRendererComponent.OnNPCBoundsTimerTick");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    UAIDebuggerRendererComponent* UFortControllerComponent_AIDebugger::GetOrCreateRenderer()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIDebuggerRuntime.FortControllerComponent_AIDebugger.GetOrCreateRenderer");
    
        UFortControllerComponent_AIDebugger___GetOrCreateRenderer_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UFortControllerComponent_AIDebugger::IsVisualizationEnabled(EAIDebuggerVisualization VisualizationType)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIDebuggerRuntime.FortControllerComponent_AIDebugger.IsVisualizationEnabled");
    
        UFortControllerComponent_AIDebugger___IsVisualizationEnabled_Params Params{};
        Params.VisualizationType = VisualizationType;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortControllerComponent_AIDebugger::OnPlayerExitedIsland(FEventMessageTag Channel, FPlayerExitSpatialActorContextWithPawn& PlayerExitSpatialActorContext)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIDebuggerRuntime.FortControllerComponent_AIDebugger.OnPlayerExitedIsland");
    
        UFortControllerComponent_AIDebugger___OnPlayerExitedIsland_Params Params{};
        Params.Channel = Channel;
        Params.PlayerExitSpatialActorContext = PlayerExitSpatialActorContext;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PlayerExitSpatialActorContext = Params.PlayerExitSpatialActorContext;
    }

    void UFortControllerComponent_AIDebugger::OnPossessedPawnChanged(APawn* OldPawn, APawn* NewPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIDebuggerRuntime.FortControllerComponent_AIDebugger.OnPossessedPawnChanged");
    
        UFortControllerComponent_AIDebugger___OnPossessedPawnChanged_Params Params{};
        Params.OldPawn = OldPawn;
        Params.NewPawn = NewPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortControllerComponent_AIDebugger::OnRep_EnabledVisualizers()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIDebuggerRuntime.FortControllerComponent_AIDebugger.OnRep_EnabledVisualizers");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortControllerComponent_AIDebugger::SetVisualizationEnable(EAIDebuggerVisualization VisualizationType, bool bEnable)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIDebuggerRuntime.FortControllerComponent_AIDebugger.SetVisualizationEnable");
    
        UFortControllerComponent_AIDebugger___SetVisualizationEnable_Params Params{};
        Params.VisualizationType = VisualizationType;
        Params.bEnable = bEnable;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortControllerComponent_AIDebugger::VisualizeNavMeshID(int32 NavMeshID)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIDebuggerRuntime.FortControllerComponent_AIDebugger.VisualizeNavMeshID");
    
        UFortControllerComponent_AIDebugger___VisualizeNavMeshID_Params Params{};
        Params.NavMeshID = NavMeshID;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortControllerComponent_AIDebugger::VisualizeNextNavMesh()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIDebuggerRuntime.FortControllerComponent_AIDebugger.VisualizeNextNavMesh");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

} // namespace UE

