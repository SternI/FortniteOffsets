/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AshtonGameplayRuntime_Functions
 * ============================================================
 */

#include "AshtonGameplayRuntime_Functions.hpp"

namespace UE
{

    void IAshtonShieldWeaponInterface::GetAshtonShieldData(FScalableFloat& BlockHealth, float& DamageCount)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AshtonGameplayRuntime.AshtonShieldWeaponInterface.GetAshtonShieldData");
    
        IAshtonShieldWeaponInterface___GetAshtonShieldData_Params Params{};
        Params.BlockHealth = BlockHealth;
        Params.DamageCount = DamageCount;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlockHealth = Params.BlockHealth;
        DamageCount = Params.DamageCount;
    }

} // namespace UE

