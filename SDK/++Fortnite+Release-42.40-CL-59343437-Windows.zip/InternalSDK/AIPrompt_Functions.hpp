/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AIPrompt_Functions
 * ============================================================
 */

#include "AIPrompt.hpp"

namespace UE
{

    struct UAIPromptOratorInputControllerComponent___OnEnableInput_Params
    {
        bool    InInputEnabled; // 0x000000 (0x000001) [Default: true]
    };

    struct UAIPromptOratorInputControllerComponent___OnSetInHearingRange_Params
    {
        bool    bInInHearingRange;  // 0x000000 (0x000001) [Default: true]
    };

    struct UAIPromptOratorInputControllerComponent___PushToTalkEnded_Params
    {
        FInputActionInstance    ActionData; // 0x000000 (0x000060) [OutParam]
    };

    struct UAIPromptOratorInputControllerComponent___SetActiveConversationID_Params
    {
        FGuid   InActiveConversationID; // 0x000000 (0x000010)
    };

    struct UAIPromptOratorInputControllerComponent___SetInHearingRange_Params
    {
        bool    InInHearingRange;   // 0x000000 (0x000001) [Default: true]
    };

    struct UAIPromptOratorInputControllerComponent___SetInputEnabled_Params
    {
        bool    InInputEnabled; // 0x000000 (0x000001) [Default: true]
    };

    struct UAIPromptOratorInputControllerComponent___StartPushToTalk_Params
    {
        FInputActionInstance    ActionData; // 0x000000 (0x000060) [OutParam]
    };

    struct UFortAIPromptContainerBase___AddStatusWidget_Params
    {
        FGuid                               ConversationId;         // 0x000000 (0x000010) [OutParam]
        FPersonaUIWidgetLayoutDefinition    WidgetLayoutDefinition; // 0x000010 (0x000020) [OutParam]
        UUserWidget*                        StatusWidget;           // 0x000030 (0x000008) [Default: nullptr]
    };

    struct UFortAIPromptContainerBase___AddSubtitleWidget_Params
    {
        UUserWidget*    CustomSubtitleWidget;   // 0x000000 (0x000008) [Default: 0x149B01F0]
    };

    struct UFortAIPromptContainerBase___GetSubtitleWidgetFromConversationID_Params
    {
        FGuid           ConversationId; // 0x000000 (0x000010) [OutParam]
        UUserWidget*    ReturnValue;    // 0x000010 (0x000008) [ReturnValue] [Default: 0x1995BED0]
    };

    struct UFortAIPromptContainerBase___RemoveStatusWidget_Params
    {
        FGuid   ConversationId; // 0x000000 (0x000010) [OutParam]
    };

    struct UFortAIPromptContainerBase___RemoveSubtitleWidget_Params
    {
        UUserWidget*    CustomSubtitleWidget;   // 0x000000 (0x000008) [Default: 0x149B01F0]
    };

    struct ULLMPersonaConversationComponent___AddPlayerToPromptList_Params
    {
        AController*    Controller; // 0x000000 (0x000008) [Default: 0x149B2630]
    };

    struct ULLMPersonaConversationComponent___AddSessionFacts_Params
    {
        FLLMFacts   LLMFacts;   // 0x000000 (0x000018) [OutParam]
    };

    struct ULLMPersonaConversationComponent___AssignLLMPersonas_Params
    {
        TArray<FLLMPersona> InPersonas;         // 0x000000 (0x000010)
        FLLMPersona         InDefaultPersona;   // 0x000010 (0x000078)
    };

    struct ULLMPersonaConversationComponent___BindDefaultPersonaToPawn_Params
    {
        APawn*  Pawn;   // 0x000000 (0x000008) [Default: 0x149B2630]
    };

    struct ULLMPersonaConversationComponent___FireAnalyticsEvent_PersonaDeviceSettings_Params
    {
        bool    bUseCustomWidget;   // 0x000000 (0x000001) [Default: true]
        bool    bUseSubtitles;      // 0x000001 (0x000001) [Default: true]
    };

    struct ULLMPersonaConversationComponent___GetParticipantPlayerControllers_Params
    {
        TArray<APlayerController*>  ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct ULLMPersonaConversationComponent___OnPlayerVoiceInputStarted_Params
    {
        UOratorInputControllerComponent*    OratorInputControllerComponent; // 0x000000 (0x000008) [Default: 0x149B2630]
    };

    struct ULLMPersonaConversationComponent___OnPlayerVoiceInputStopped_Params
    {
        UOratorInputControllerComponent*    OratorInputControllerComponent; // 0x000000 (0x000008) [Default: 0x149B2630]
    };

    struct ULLMPersonaConversationComponent___RegisterPlayer_Params
    {
        AController*        Controller;         // 0x000000 (0x000008) [Default: 0x149B2630]
        FPersonaUIParams    PersonaUIParams;    // 0x000008 (0x0000A0)
    };

    struct ULLMPersonaConversationComponent___RemovePlayerFromOtherConvos_Params
    {
        AController*    Controller; // 0x000000 (0x000008) [Default: 0x149B2630]
    };

    struct ULLMPersonaConversationComponent___RemovePlayerFromPromptList_Params
    {
        AController*    Controller; // 0x000000 (0x000008) [Default: 0x149B2630]
    };

    struct ULLMPersonaConversationComponent___SendDefaultPrompt_Params
    {
        FString DefaultPrompt;  // 0x000000 (0x000010) [Default: L"??"]
    };

    struct ULLMPersonaConversationComponent___SetInterruptBehavior_Params
    {
        EInterruptBehavior  InInterruptBehavior;    // 0x000000 (0x000001) [Default: EInterruptBehavior(48)]
    };

    struct ULLMPersonaConversationComponent___SetResponseEventCriteria_Params
    {
        TArray<FResponseEventCriteria>  InResponseEventCriteria;    // 0x000000 (0x000010) [OutParam]
    };

    struct ULLMPersonaConversationComponent___UnregisterPlayer_Params
    {
        AController*    Controller; // 0x000000 (0x000008) [Default: 0x149B2630]
    };

    struct ULLMPersonaConversationComponent___UpdateInstigatorBlockList_Params
    {
        APlayerController*          Instigator; // 0x000000 (0x000008) [Default: 0x149B2630]
        TArray<FUniqueNetIdRepl>    BlockList;  // 0x000008 (0x000010) [OutParam]
    };

    struct ULLMPersonaConversationComponentHolder___GetLLMPersonaConversationComponent_Params
    {
        ULLMPersonaConversationComponent*   ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x149B2A20]
    };

    struct UNPCCharacterModifier_Persona___GetAllowedVoices_Params
    {
        bool            bRestrictEpicInternalConstructor;   // 0x000000 (0x000001) [Default: true]
        uint8           UnknownData_000001[0x000007];       // 0x000001 (0x000007)
        TArray<UClass*> ReturnValue;                        // 0x000008 (0x000010) [ReturnValue]
    };

    struct UPersonaDelegateWrapper___OnMonologueEventPerceived_Params
    {
        FMonologuePerceivedEvent    PerceivedEvent; // 0x000000 (0x000038) [OutParam]
    };

    struct UPersonaDelegateWrapper___OnPlayerUnregistered_Params
    {
        AFortPlayerState*   UnregisteredPlayerState;    // 0x000000 (0x000008) [Default: 0x149B4070]
    };

    struct UPersonaOratorComponent___HandleUtteranceCancelled_Params
    {
        FGuid   UtteranceID;    // 0x000000 (0x000010)
    };

    struct UPersonaOratorInputControllerComponent___IsMuted_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UPersonaOratorInputControllerComponent___ServerUpdateBlockList_Params
    {
        TArray<FUniqueNetIdRepl>    BlockList;  // 0x000000 (0x000010)
    };

    struct UPersonaOratorInputControllerComponent___ServerUpdateStopVoiceCaptureTime_Params
    {
        FDateTime   InStopVoiceCaptureTime; // 0x000000 (0x000008)
    };

    struct UPersonaPrompt___SendPrompt_Params
    {
        FString         Topic;                          // 0x000000 (0x000010) [Default: L"??"]
        bool            bIsBatchPrompt;                 // 0x000010 (0x000001) [Default: true]
        uint8           UnknownData_000011[0x000003];   // 0x000011 (0x000003)
        int32           BatchSize;                      // 0x000014 (0x000004) [Default: 0]
        UScriptStruct*  StructType;                     // 0x000018 (0x000008) [Default: 0x1995A660]
    };

    struct UPersonaUIControllerComponent___AddedToConversation_Params
    {
        FGuid                       PersonaConversation;    // 0x000000 (0x000010)
        FPersonaUIParams            PersonaUIParams;        // 0x000010 (0x0000A0)
        UPersonaOratorComponent*    PersonaOrator;          // 0x0000B0 (0x000008) [Default: nullptr]
    };

    struct UPersonaUIControllerComponent___OnPlayerAllowedToHearOratorChanged_Params
    {
        UOratorControllerComponent* InOratorControllerComponent;    // 0x000000 (0x000008) [Default: 0x149B5A00]
        bool                        bPlayerAllowedToHearOrator;     // 0x000008 (0x000001) [Default: true]
    };

    struct UPersonaUIControllerComponent___OnPromptIgnored_Params
    {
        FGuid   PersonaConversation;    // 0x000000 (0x000010)
        bool    bIsProcessing;          // 0x000010 (0x000001) [Default: true]
    };

    struct UPersonaUIControllerComponent___OnResponseFailed_Params
    {
        FGuid                               PersonaConversation;            // 0x000000 (0x000010)
        ELLMErrorType                       ErrorType;                      // 0x000010 (0x000001) [Default: ELLMErrorType(192)]
        uint8                               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        TArray<EPersonaModerationCategory>  TrippedModerationCategories;    // 0x000018 (0x000010)
    };

    struct UPersonaUIControllerComponent___OnResponseProcessing_Params
    {
        FGuid   PersonaConversation;    // 0x000000 (0x000010)
    };

    struct UPersonaUIControllerComponent___OnResponseReceived_Params
    {
        FGuid               PersonaConversation;    // 0x000000 (0x000010)
        FText               ResponseContents;       // 0x000010 (0x000010)
        AFortPlayerState*   UtteranceInstigator;    // 0x000020 (0x000008) [Default: 0xED88EBB]
    };

    struct UPersonaUIControllerComponent___OnStartedPlayingAudio_Params
    {
        FGuid   PersonaConversation;    // 0x000000 (0x000010)
    };

    struct UPersonaUIControllerComponent___OnStoppedPlayingAudio_Params
    {
        FGuid   PersonaConversation;    // 0x000000 (0x000010)
    };

    struct UPersonaUIControllerComponent___OnVoiceRecordingStarted_Params
    {
        FGuid   PersonaConversation;    // 0x000000 (0x000010) [OutParam]
    };

    struct UPersonaUIControllerComponent___OnVoiceRecordingStopped_Params
    {
        FGuid   PersonaConversation;    // 0x000000 (0x000010) [OutParam]
    };

    struct UPersonaUIControllerComponent___RemovedFromConversation_Params
    {
        FGuid   PersonaConversation;    // 0x000000 (0x000010)
    };

    struct UPersonaUIControllerComponent___SetConnected_Params
    {
        FGuid   PersonaConversation;    // 0x000000 (0x000010)
        bool    bIsConnected;           // 0x000010 (0x000001) [Default: true]
    };

    struct UPersonaUIControllerComponent___SetInHearingRange_Params
    {
        FGuid   PersonaConversation;    // 0x000000 (0x000010) [OutParam]
        bool    bInHearingRange;        // 0x000010 (0x000001) [Default: true]
    };

    struct UPersonaUIControllerComponent___SetInputEnabled_Params
    {
        FGuid   PersonaConversation;    // 0x000000 (0x000010) [OutParam]
        bool    bInputEnabled;          // 0x000010 (0x000001) [Default: true]
    };

    struct UPersonaUIControllerComponent___SetMuted_Params
    {
        bool    bMuted; // 0x000000 (0x000001) [Default: false]
    };

    struct UPersonaUIControllerComponent___SetPersonaIcon_Params
    {
        FGuid                       PersonaConversation;    // 0x000000 (0x000010)
        TSoftObjectPtr<UTexture2D>  InPersonaIcon;          // 0x000010 (0x000020) [Default: 0x1996CCC0]
    };

    struct UPersonaUIControllerComponent___SetPersonaName_Params
    {
        FGuid   PersonaConversation;    // 0x000000 (0x000010)
        FString InPersonaName;          // 0x000010 (0x000010) [Default: L""]
    };

    struct UPersonaUIControllerComponent___SetTimeLeftRecording_Params
    {
        FGuid   PersonaConversation;    // 0x000000 (0x000010) [OutParam]
        float   DeltaTime;              // 0x000010 (0x000004) [Default: 1.55923e-23f]
        float   RecordingTimeMax;       // 0x000014 (0x000004) [Default: 0f]
    };

    struct UPersonaUtteranceWrapper___OnOratorCurrentUtteranceClosed_Params
    {
        FGuid   UtteranceGuid;  // 0x000000 (0x000010)
        FString UtteranceText;  // 0x000010 (0x000010) [Default: L""]
        FString ReplyContentId; // 0x000020 (0x000010) [Default: L""]
    };

    struct UPersonaUtteranceWrapper___OnOratorUtteranceAudibilityChanged_Params
    {
        FGuid   UtteranceGuid;  // 0x000000 (0x000010)
        bool    bIsAudible;     // 0x000010 (0x000001) [Default: true]
    };

    struct UPersonaUtteranceWrapper___OnOratorUtteranceCancelled_Params
    {
        FGuid   UtteranceGuid;  // 0x000000 (0x000010)
    };

    struct UPersonaUtteranceWrapper___OnOratorUtteranceEnded_Params
    {
        FGuid   UtteranceGuid;  // 0x000000 (0x000010)
    };

    struct UPersonaUtteranceWrapper___OnOratorUtteranceStarted_Params
    {
        FGuid   UtteranceGuid;  // 0x000000 (0x000010)
    };

} // namespace UE

