/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:12
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AssetRegistry_Functions
 * ============================================================
 */

#include "AssetRegistry.hpp"

namespace UE
{

    struct IAssetRegistry___GetAllAssets_Params
    {
        TArray<FAssetData>  OutAssetData;               // 0x000000 (0x000010) [OutParam]
        bool                bIncludeOnlyOnDiskAssets;   // 0x000010 (0x000001) [Default: true]
        bool                ReturnValue;                // 0x000011 (0x000001) [ReturnValue] [Default: true]
    };

    struct IAssetRegistry___GetAllCachedPaths_Params
    {
        TArray<FString> OutPathList;    // 0x000000 (0x000010) [OutParam]
    };

    struct IAssetRegistry___GetAncestorClassNames_Params
    {
        FTopLevelAssetPath          ClassPathName;          // 0x000000 (0x000008)
        TArray<FTopLevelAssetPath>  OutAncestorClassNames;  // 0x000008 (0x000010) [OutParam]
        bool                        ReturnValue;            // 0x000018 (0x000001) [ReturnValue] [Default: true]
    };

    struct IAssetRegistry___GetAssetByObjectPath_Params
    {
        FName       ObjectPath;                     // 0x000000 (0x000004) [Default: FName(318462576) -> L""]
        bool        bIncludeOnlyOnDiskAssets;       // 0x000004 (0x000001) [Default: false]
        uint8       UnknownData_000005[0x000003];   // 0x000005 (0x000003)
        FAssetData  ReturnValue;                    // 0x000008 (0x000038) [ReturnValue]
    };

    struct IAssetRegistry___GetAssets_Params
    {
        FARFilter           Filter;                 // 0x000000 (0x000090) [OutParam]
        TArray<FAssetData>  OutAssetData;           // 0x000090 (0x000010) [OutParam]
        bool                bSkipARFilteredAssets;  // 0x0000A0 (0x000001) [Default: false]
        bool                ReturnValue;            // 0x0000A1 (0x000001) [ReturnValue] [Default: true]
    };

    struct IAssetRegistry___GetAssetsByClass_Params
    {
        FTopLevelAssetPath  ClassPathName;      // 0x000000 (0x000008)
        TArray<FAssetData>  OutAssetData;       // 0x000008 (0x000010) [OutParam]
        bool                bSearchSubClasses;  // 0x000018 (0x000001) [Default: true]
        bool                ReturnValue;        // 0x000019 (0x000001) [ReturnValue] [Default: true]
    };

    struct IAssetRegistry___GetAssetsByPackageName_Params
    {
        FName               PackageName;                    // 0x000000 (0x000004) [Default: FName(318462576) -> L""]
        uint8               UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FAssetData>  OutAssetData;                   // 0x000008 (0x000010) [OutParam]
        bool                bIncludeOnlyOnDiskAssets;       // 0x000018 (0x000001) [Default: true]
        bool                bSkipARFilteredAssets;          // 0x000019 (0x000001) [Default: true]
        bool                ReturnValue;                    // 0x00001A (0x000001) [ReturnValue] [Default: true]
    };

    struct IAssetRegistry___GetAssetsByPath_Params
    {
        FName               PackagePath;                    // 0x000000 (0x000004) [Default: FName(318462576) -> L""]
        uint8               UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FAssetData>  OutAssetData;                   // 0x000008 (0x000010) [OutParam]
        bool                bRecursive;                     // 0x000018 (0x000001) [Default: true]
        bool                bIncludeOnlyOnDiskAssets;       // 0x000019 (0x000001) [Default: true]
        bool                ReturnValue;                    // 0x00001A (0x000001) [ReturnValue] [Default: true]
    };

    struct IAssetRegistry___GetAssetsByPaths_Params
    {
        TArray<FName>       PackagePaths;               // 0x000000 (0x000010)
        TArray<FAssetData>  OutAssetData;               // 0x000010 (0x000010) [OutParam]
        bool                bRecursive;                 // 0x000020 (0x000001) [Default: true]
        bool                bIncludeOnlyOnDiskAssets;   // 0x000021 (0x000001) [Default: true]
        bool                ReturnValue;                // 0x000022 (0x000001) [ReturnValue] [Default: true]
    };

    struct IAssetRegistry___GetDerivedClassNames_Params
    {
        TArray<FTopLevelAssetPath>  ClassNames;             // 0x000000 (0x000010) [OutParam]
        TSet<FTopLevelAssetPath>    ExcludedClassNames;     // 0x000010 (0x000010) [OutParam]
        TSet<FTopLevelAssetPath>    OutDerivedClassNames;   // 0x000020 (0x000010) [OutParam]
    };

    struct IAssetRegistry___GetInMemoryAssets_Params
    {
        FARFilter           Filter;                 // 0x000000 (0x000090) [OutParam]
        TArray<FAssetData>  OutAssetData;           // 0x000090 (0x000010) [OutParam]
        bool                bSkipARFilteredAssets;  // 0x0000A0 (0x000001) [Default: false]
        bool                ReturnValue;            // 0x0000A1 (0x000001) [ReturnValue] [Default: true]
    };

    struct IAssetRegistry___GetSubPaths_Params
    {
        FString         InBasePath;     // 0x000000 (0x000010) [Default: L"??"]
        TArray<FString> OutPathList;    // 0x000010 (0x000010) [OutParam]
        bool            bInRecurse;     // 0x000020 (0x000001) [Default: true]
    };

    struct IAssetRegistry___HasAssets_Params
    {
        FName   PackagePath;    // 0x000000 (0x000004) [Default: FName(318462576) -> L""]
        bool    bRecursive;     // 0x000004 (0x000001) [Default: false]
        bool    ReturnValue;    // 0x000005 (0x000001) [ReturnValue] [Default: false]
    };

    struct IAssetRegistry___IsLoadingAssets_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct IAssetRegistry___IsSearchAllAssets_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct IAssetRegistry___IsSearchAsync_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct IAssetRegistry___K2_GetAssetByObjectPath_Params
    {
        FSoftObjectPath ObjectPath;                     // 0x000000 (0x000018) [OutParam]
        bool            bIncludeOnlyOnDiskAssets;       // 0x000018 (0x000001) [Default: true]
        bool            bSkipARFilteredAssets;          // 0x000019 (0x000001) [Default: true]
        uint8           UnknownData_00001A[0x000006];   // 0x00001A (0x000006)
        FAssetData      ReturnValue;                    // 0x000020 (0x000038) [ReturnValue]
    };

    struct IAssetRegistry___K2_GetDependencies_Params
    {
        FName                           PackageName;                    // 0x000000 (0x000004) [Default: FName(318462576) -> L""]
        FAssetRegistryDependencyOptions DependencyOptions;              // 0x000004 (0x000007) [OutParam]
        uint8                           UnknownData_00000B[0x000005];   // 0x00000B (0x000005)
        TArray<FName>                   OutDependencies;                // 0x000010 (0x000010) [OutParam]
        bool                            ReturnValue;                    // 0x000020 (0x000001) [ReturnValue] [Default: true]
    };

    struct IAssetRegistry___K2_GetReferencers_Params
    {
        FName                           PackageName;                    // 0x000000 (0x000004) [Default: FName(318462576) -> L""]
        FAssetRegistryDependencyOptions ReferenceOptions;               // 0x000004 (0x000007) [OutParam]
        uint8                           UnknownData_00000B[0x000005];   // 0x00000B (0x000005)
        TArray<FName>                   OutReferencers;                 // 0x000010 (0x000010) [OutParam]
        bool                            ReturnValue;                    // 0x000020 (0x000001) [ReturnValue] [Default: true]
    };

    struct IAssetRegistry___PrioritizeSearchPath_Params
    {
        FString PathToPrioritize;   // 0x000000 (0x000010) [Default: L"??"]
    };

    struct IAssetRegistry___RunAssetsThroughFilter_Params
    {
        TArray<FAssetData>  AssetDataList;  // 0x000000 (0x000010) [OutParam]
        FARFilter           Filter;         // 0x000010 (0x000090) [OutParam]
    };

    struct IAssetRegistry___ScanFilesSynchronous_Params
    {
        TArray<FString> InFilePaths;    // 0x000000 (0x000010) [OutParam]
        bool            bForceRescan;   // 0x000010 (0x000001) [Default: true]
    };

    struct IAssetRegistry___ScanModifiedAssetFiles_Params
    {
        TArray<FString> InFilePaths;    // 0x000000 (0x000010) [OutParam]
    };

    struct IAssetRegistry___ScanPathsSynchronous_Params
    {
        TArray<FString> InPaths;                    // 0x000000 (0x000010) [OutParam]
        bool            bForceRescan;               // 0x000010 (0x000001) [Default: true]
        bool            bIgnoreDenyListScanFilters; // 0x000011 (0x000001) [Default: true]
    };

    struct IAssetRegistry___SearchAllAssets_Params
    {
        bool    bSynchronousSearch; // 0x000000 (0x000001) [Default: true]
    };

    struct IAssetRegistry___UseFilterToExcludeAssets_Params
    {
        TArray<FAssetData>  AssetDataList;  // 0x000000 (0x000010) [OutParam]
        FARFilter           Filter;         // 0x000010 (0x000090) [OutParam]
    };

    struct IAssetRegistry___WaitForPackage_Params
    {
        FString PackageName;    // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UAssetRegistryHelpers___CreateAssetData_Params
    {
        UObject*    InAsset;                        // 0x000000 (0x000008) [Default: 0x12FB5A70]
        bool        bAllowBlueprintClass;           // 0x000008 (0x000001) [Default: true]
        uint8       UnknownData_000009[0x000007];   // 0x000009 (0x000007)
        FAssetData  ReturnValue;                    // 0x000010 (0x000038) [ReturnValue]
    };

    struct UAssetRegistryHelpers___FindAssetNativeClass_Params
    {
        FAssetData  AssetData;      // 0x000000 (0x000038) [OutParam]
        UClass*     ReturnValue;    // 0x000038 (0x000008) [ReturnValue] [Default: 0x16A6A410]
    };

    struct UAssetRegistryHelpers___GetAsset_Params
    {
        FAssetData  InAssetData;    // 0x000000 (0x000038) [OutParam]
        UObject*    ReturnValue;    // 0x000038 (0x000008) [ReturnValue] [Default: 0x16A6A410]
    };

    struct UAssetRegistryHelpers___GetAssetRegistry_Params
    {
        TScriptInterface<IAssetRegistry>    ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAssetRegistryHelpers___GetBlueprintAssets_Params
    {
        FARFilter           InFilter;       // 0x000000 (0x000090) [OutParam]
        TArray<FAssetData>  OutAssetData;   // 0x000090 (0x000010) [OutParam]
    };

    struct UAssetRegistryHelpers___GetClass_Params
    {
        FAssetData  InAssetData;    // 0x000000 (0x000038) [OutParam]
        UClass*     ReturnValue;    // 0x000038 (0x000008) [ReturnValue] [Default: 0x16A6A410]
    };

    struct UAssetRegistryHelpers___GetDerivedClassAssetData_Params
    {
        TArray<FTopLevelAssetPath>  InBaseClasses;              // 0x000000 (0x000010) [OutParam]
        TArray<FAssetData>          OutDerivedClassAssetData;   // 0x000010 (0x000010) [OutParam]
    };

    struct UAssetRegistryHelpers___GetExportTextName_Params
    {
        FAssetData  InAssetData;    // 0x000000 (0x000038) [OutParam]
        FString     ReturnValue;    // 0x000038 (0x000010) [ReturnValue] [Default: L""]
    };

    struct UAssetRegistryHelpers___GetFullName_Params
    {
        FAssetData  InAssetData;    // 0x000000 (0x000038) [OutParam]
        FString     ReturnValue;    // 0x000038 (0x000010) [ReturnValue] [Default: L""]
    };

    struct UAssetRegistryHelpers___GetTagValue_Params
    {
        FAssetData  InAssetData;                    // 0x000000 (0x000038) [OutParam]
        FName       InTagName;                      // 0x000038 (0x000004) [OutParam] [Default: FName(380019728) -> L""]
        uint8       UnknownData_00003C[0x000004];   // 0x00003C (0x000004)
        FString     OutTagValue;                    // 0x000040 (0x000010) [OutParam] [Default: L""]
        bool        ReturnValue;                    // 0x000050 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAssetRegistryHelpers___IsAssetLoaded_Params
    {
        FAssetData  InAssetData;    // 0x000000 (0x000038) [OutParam]
        bool        ReturnValue;    // 0x000038 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAssetRegistryHelpers___IsRedirector_Params
    {
        FAssetData  InAssetData;    // 0x000000 (0x000038) [OutParam]
        bool        ReturnValue;    // 0x000038 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAssetRegistryHelpers___IsUAsset_Params
    {
        FAssetData  InAssetData;    // 0x000000 (0x000038) [OutParam]
        bool        ReturnValue;    // 0x000038 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAssetRegistryHelpers___IsValid_Params
    {
        FAssetData  InAssetData;    // 0x000000 (0x000038) [OutParam]
        bool        ReturnValue;    // 0x000038 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAssetRegistryHelpers___SetFilterTagsAndValues_Params
    {
        FARFilter               InFilter;           // 0x000000 (0x000090) [OutParam]
        TArray<FTagAndValue>    InTagsAndValues;    // 0x000090 (0x000010) [OutParam]
        FARFilter               ReturnValue;        // 0x0000A0 (0x000090) [ReturnValue]
    };

    struct UAssetRegistryHelpers___SortByAssetName_Params
    {
        TArray<FAssetData>      Assets;     // 0x000000 (0x000010) [OutParam]
        EAssetRegistrySortOrder SortOrder;  // 0x000010 (0x000001) [Default: EAssetRegistrySortOrder(48)]
    };

    struct UAssetRegistryHelpers___SortByPredicate_Params
    {
        TArray<FAssetData>      Assets;             // 0x000000 (0x000010) [OutParam]
        SortingPredicate        SortingPredicate;   // 0x000010 (0x00000C)
        EAssetRegistrySortOrder SortOrder;          // 0x00001C (0x000001) [Default: EAssetRegistrySortOrder(0)]
    };

    struct UAssetRegistryHelpers___ToSoftObjectPath_Params
    {
        FAssetData      InAssetData;    // 0x000000 (0x000038) [OutParam]
        FSoftObjectPath ReturnValue;    // 0x000038 (0x000018) [ReturnValue]
    };

    struct UAssetRegistryHelpers___SortingPredicate_Params
    {
        FAssetData  Left;           // 0x000000 (0x000038) [OutParam]
        FAssetData  Right;          // 0x000038 (0x000038) [OutParam]
        bool        ReturnValue;    // 0x000070 (0x000001) [ReturnValue] [Default: true]
    };

} // namespace UE

