/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BikeKidUI_Functions
 * ============================================================
 */

#include "BikeKidUI.hpp"

namespace UE
{

    struct UBikeKidHUD___GetControlledBikeKid_Params
    {
        AFortBikeKid*   ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x149600F0]
    };

    struct UBikeKidHUD___GetTargetConfirmationTime_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.51465e-26f]
    };

    struct UBikeKidHUD___OnBikeKidEnergyChanged_Params
    {
        float   EnergyPercentage;   // 0x000000 (0x000004) [Default: 1.51465e-26f]
    };

    struct UBikeKidHUD___OnBikeKidHealthUpdated_Params
    {
        float   HealthPercentage;   // 0x000000 (0x000004) [Default: 1.51465e-26f]
        float   CurrentHealth;      // 0x000004 (0x000004) [Default: 0f]
    };

    struct UBikeKidHUD___OnBikeKidSignalDataUpdated_Params
    {
        float   DistanceFromPlayer; // 0x000000 (0x000004) [Default: 1.51465e-26f]
        float   SignalPercentage;   // 0x000004 (0x000004) [Default: 0f]
    };

    struct UBikeKidHUD___OnReticleChangeAbilityActivated_Params
    {
        FGameplayTag    UpdatedTag; // 0x000000 (0x000004)
    };

    struct UBikeKidHUD___OnTargetingStatusChanged_Params
    {
        FBikeKidStatusData  StatusData; // 0x000000 (0x000008) [OutParam]
    };

    struct UBikeKidTetherIndicator___BP_WhileInWarningRange_Params
    {
        float   SignalIntensityPercentage;  // 0x000000 (0x000004) [Default: 1.51485e-26f]
    };

    struct UBikeKidTetherIndicator___GetControlledBikeKid_Params
    {
        AFortBikeKid*   ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14960620]
    };

} // namespace UE

