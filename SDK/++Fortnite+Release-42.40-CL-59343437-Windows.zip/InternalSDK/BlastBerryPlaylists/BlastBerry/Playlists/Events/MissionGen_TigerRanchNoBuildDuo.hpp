/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:42
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BlastBerryPlaylists/BlastBerry/Playlists/Events/MissionGen_TigerRanchNoBuildDuo
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0007B0 (0x000000)
    class UMissionGen_TigerRanchNoBuildDuo_C : public UFortMissionGenerator
    {
    public:
    };
}

