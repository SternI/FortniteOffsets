/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:25
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BlastBerryPlaylists/BlastBerry/Playlists/MissionGen_Habanero_TimberStakeNoBuildSolo
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0007B0 (0x000000)
    class UMissionGen_Habanero_TimberStakeNoBuildSolo_C : public UFortMissionGenerator
    {
    public:
    };
}

