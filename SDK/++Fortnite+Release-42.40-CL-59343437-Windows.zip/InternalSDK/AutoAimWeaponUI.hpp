/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AutoAimWeaponUI
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0002C0 (0x000030)
    class alignas(0x8) UFortAutoAimTargetImage : public UImage
    {
    public:
        FScalableFloat  AutoAimReticleSize;             // 0x000290 (0x000028)
        uint8           UnknownData_0002B8[0x000008];   // 0x0002B8 (0x000008)
    };
}

