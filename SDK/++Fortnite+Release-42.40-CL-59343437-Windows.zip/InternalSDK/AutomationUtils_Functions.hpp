/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AutomationUtils_Functions
 * ============================================================
 */

#include "AutomationUtils.hpp"

namespace UE
{

    struct UAutomationUtilsBlueprintLibrary___AddAutomationMountPoint_Params
    {
        FString RootPath;   // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UAutomationUtilsBlueprintLibrary___RemoveAutomationMountPoint_Params
    {
        FString RootPath;   // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UAutomationUtilsBlueprintLibrary___TakeGameplayAutomationScreenshot_Params
    {
        FString ScreenshotName;     // 0x000000 (0x000010) [Default: L"??"]
        float   MaxGlobalError;     // 0x000010 (0x000004) [Default: 7.79544e-25f]
        float   MaxLocalError;      // 0x000014 (0x000004) [Default: 0f]
        FString MapNameOverride;    // 0x000018 (0x000010) [Default: L""]
    };

} // namespace UE

