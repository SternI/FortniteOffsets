/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:16
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AINavigation/_Verse/VNI/AINavigation_Functions
 * ============================================================
 */

#include "AINavigation_Functions.hpp"

namespace UE
{

    int64 Utask__Root_operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_Ntuple_L_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_M_L_2fUnrealEngine_2ecom_2fAINavigation_N_Rnavigation__query_R_R::Update()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.task__Root$operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_Ntuple_L_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_M_L_2fUnrealEngine_2ecom_2fAINavigation_N_Rnavigation__query_R_R.Update");
    
        Utask__Root_operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_Ntuple_L_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_M_L_2fUnrealEngine_2ecom_2fAINavigation_N_Rnavigation__query_R_R___Update_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    int64 Utask__Root_operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_N_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_R::Update()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.task__Root$operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_N_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_R.Update");
    
        Utask__Root_operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_N_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_R___Update_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    void Unavigation_layer::_Block()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_layer._Block");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Unavigation_layer::_InitCDO()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_layer._InitCDO");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Unavigation_layer::_InitInstance()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_layer._InitInstance");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Unavigation_layer_air_auto::_Block()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_layer_air_auto._Block");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Unavigation_layer_air_auto::_InitCDO()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_layer_air_auto._InitCDO");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Unavigation_layer_air_auto::_InitInstance()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_layer_air_auto._InitInstance");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Unavigation_user_component::_Block()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_user_component._Block");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Unavigation_user_component::_InitCDO()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_user_component._InitCDO");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Unavigation_user_component::_InitInstance()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_user_component._InitInstance");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Unavigation_user_component::_L_2fVerse_2eorg_2fSceneGraph_2fcomponent_N_ROnAddedToScene(Ftuple_L_R __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_user_component._L_2fVerse_2eorg_2fSceneGraph_2fcomponent_N_ROnAddedToScene");
    
        Unavigation_user_component____L_2fVerse_2eorg_2fSceneGraph_2fcomponent_N_ROnAddedToScene_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void Unavigation_user_component::_L_2fVerse_2eorg_2fSceneGraph_2fcomponent_N_ROnRemovingFromScene(Ftuple_L_R __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_user_component._L_2fVerse_2eorg_2fSceneGraph_2fcomponent_N_ROnRemovingFromScene");
    
        Unavigation_user_component____L_2fVerse_2eorg_2fSceneGraph_2fcomponent_N_ROnRemovingFromScene_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void Unavigation_layer_ground_auto::_Block()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_layer_ground_auto._Block");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Unavigation_layer_ground_auto::_InitCDO()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_layer_ground_auto._InitCDO");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Unavigation_layer_ground_auto::_InitInstance()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_layer_ground_auto._InitInstance");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Unavigation_system_component::_Block()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_system_component._Block");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Unavigation_system_component::_InitCDO()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_system_component._InitCDO");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Unavigation_system_component::_InitInstance()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_system_component._InitInstance");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Unavigation_path::_Block()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_path._Block");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Unavigation_path::_InitCDO()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_path._InitCDO");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Unavigation_path::_InitInstance()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_path._InitInstance");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    TOptional<TArray<Fnavigation_path_point>> Unavigation_path::_L_2fUnrealEngine_2ecom_2fAINavigation_2fnavigation__path_N_RGetPathPoints(Ftuple_L_R __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation.navigation_path._L_2fUnrealEngine_2ecom_2fAINavigation_2fnavigation__path_N_RGetPathPoints");
    
        Unavigation_path____L_2fUnrealEngine_2ecom_2fAINavigation_2fnavigation__path_N_RGetPathPoints_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    void U_Root::_InitCDO()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation._Root._InitCDO");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    Fnavigation_path_point U_Root::navigation_path_point_Factory(FSpatialMath_vector3 _ExprResult_0, FSpatialMath_vector3 _ExprResult_1)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation._Root.navigation_path_point_Factory");
    
        U_Root___navigation_path_point_Factory_Params Params{};
        Params._ExprResult_0 = _ExprResult_0;
        Params._ExprResult_1 = _ExprResult_1;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    Fnavigation_path_point U_Root::navigation_path_point_OverrideFactory(uint8 __verse_0xFB48ED96__InitOverrideMap[0x000010], uint8 _ExprResultStack_0[0x000010], TOptional<bool> _ExprResult_1, FSpatialMath_vector3 _ExprResult_2, uint8 _ExprResultStack_3[0x000010], TOptional<bool> _ExprResult_4, FSpatialMath_vector3 _ExprResult_5)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation._Root.navigation_path_point_OverrideFactory");
    
        U_Root___navigation_path_point_OverrideFactory_Params Params{};
        Params.__verse_0xFB48ED96__InitOverrideMap[0x000010] = __verse_0xFB48ED96__InitOverrideMap[0x000010];
        Params._ExprResultStack_0[0x000010] = _ExprResultStack_0[0x000010];
        Params._ExprResult_1 = _ExprResult_1;
        Params._ExprResult_2 = _ExprResult_2;
        Params._ExprResultStack_3[0x000010] = _ExprResultStack_3[0x000010];
        Params._ExprResult_4 = _ExprResult_4;
        Params._ExprResult_5 = _ExprResult_5;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    UConcurrency_task* U_Root::operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_N_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lentity_Mvector3_R __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation._Root.operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_N_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_R");
    
        U_Root___operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_N_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_R_Params Params{};
        Params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
        Params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
        Params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    UConcurrency_task* U_Root::operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_Ntuple_L_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_M_L_2fUnrealEngine_2ecom_2fAINavigation_N_Rnavigation__query_R_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lentity_Mtuple_Lvector3_Mnavigation__query_R_R __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AINavigation._Root.operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_Ntuple_L_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_M_L_2fUnrealEngine_2ecom_2fAINavigation_N_Rnavigation__query_R_R");
    
        U_Root___operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_Ntuple_L_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_M_L_2fUnrealEngine_2ecom_2fAINavigation_N_Rnavigation__query_R_R_Params Params{};
        Params.__verse_0xC1E81372_CallingTask = __verse_0xC1E81372_CallingTask;
        Params.__verse_0xA3A00DDB_CallerResumeState = __verse_0xA3A00DDB_CallerResumeState;
        Params.__verse_0x2AC0E4D8_CallerCancelState = __verse_0x2AC0E4D8_CallerCancelState;
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

} // namespace UE

