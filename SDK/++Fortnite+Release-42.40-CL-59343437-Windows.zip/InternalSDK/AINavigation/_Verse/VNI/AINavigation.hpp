/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:16
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AINavigation/_Verse/VNI/AINavigation
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0000F0 (0x000030)
    class alignas(0x8) Utask__Root_operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_Ntuple_L_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_M_L_2fUnrealEngine_2ecom_2fAINavigation_N_Rnavigation__query_R_R : public UConcurrency_task
    {
    public:
        Ftuple_Lentity_Mtuple_Lvector3_Mnavigation__query_R_R   __verse_0xB2CDDD72_Argument;    // 0x0000C0 (0x000028)
        Unavigation_path*                                       _RetVal;                        // 0x0000E8 (0x000008) [Default: nullptr]
    
    public: // Functions
        int64   Update(); // 0x0E3B5150 [Native | Public | HasOutParms]
    };
    // Size: 0x0000E8 (0x000028)
    class alignas(0x8) Utask__Root_operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_N_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_R : public UConcurrency_task
    {
    public:
        Ftuple_Lentity_Mvector3_R   __verse_0xB2CDDD72_Argument;    // 0x0000C0 (0x000020)
        Unavigation_path*           _RetVal;                        // 0x0000E0 (0x000008) [Default: nullptr]
    
    public: // Functions
        int64   Update(); // 0x0E3B514A [Native | Public | HasOutParms]
    };
    // Size: 0x0000D8 (0x000000)
    class Unavigation_layer : public UAssets_asset
    {
    public:
    
    public: // Functions
        void    _Block(); // 0x000545D2 [FUNC_None]
        void    _InitCDO(); // 0x000545D2 [FUNC_None]
        void    _InitInstance(); // 0x000545D2 [FUNC_None]
    };
    // Size: 0x0000D8 (0x000000)
    class Unavigation_layer_air_auto : public Unavigation_layer
    {
    public:
    
    public: // Functions
        void    _Block(); // 0x000545D2 [FUNC_None]
        void    _InitCDO(); // 0x000545D2 [FUNC_None]
        void    _InitInstance(); // 0x000545D2 [FUNC_None]
    };
    // Size: 0x000078 (0x000020)
    class alignas(0x8) Unavigation_user_component : public UComponent
    {
    public:
        UCompositeNavigationQuery*  __verse_0x6AFD19C2_DefaultNavigationQuery;  // 0x000058 (0x000008) [Default: nullptr]
        uint8                       UnknownData_000060[0x000018];               // 0x000060 (0x000018)
    
    public: // Functions
        void    _Block(); // 0x000545D2 [FUNC_None]
        void    _InitCDO(); // 0x000545D2 [FUNC_None]
        void    _InitInstance(); // 0x000545D2 [FUNC_None]
        void    _L_2fVerse_2eorg_2fSceneGraph_2fcomponent_N_ROnAddedToScene(Ftuple_L_R __verse_0xB2CDDD72_Argument); // 0x0E3B513E [Native | Public | BlueprintCallable]
        void    _L_2fVerse_2eorg_2fSceneGraph_2fcomponent_N_ROnRemovingFromScene(Ftuple_L_R __verse_0xB2CDDD72_Argument); // 0x0E3B5144 [Native | Public | BlueprintCallable]
    };
    // Size: 0x0000D8 (0x000000)
    class Unavigation_layer_ground_auto : public Unavigation_layer
    {
    public:
    
    public: // Functions
        void    _Block(); // 0x000545D2 [FUNC_None]
        void    _InitCDO(); // 0x000545D2 [FUNC_None]
        void    _InitInstance(); // 0x000545D2 [FUNC_None]
    };
    // Size: 0x000058 (0x000000)
    class Unavigation_system_component : public UComponent
    {
    public:
    
    public: // Functions
        void    _Block(); // 0x000545D2 [FUNC_None]
        void    _InitCDO(); // 0x000545D2 [FUNC_None]
        void    _InitInstance(); // 0x000545D2 [FUNC_None]
    };
    // Size: 0x000040 (0x000018)
    class Unavigation_path : public UObject
    {
    public:
        uint8                       UnknownData_000028[0x000010];   // 0x000028 (0x000010)
        navigation_find_path_result __verse_0x95D09D0E_Result;      // 0x000038 (0x000001) [Default: navigation_find_path_result(0)]
        uint8                       UnknownData_000039[0x000007];   // 0x000039 (0x000007)
    
    public: // Functions
        void                                        _Block(); // 0x000545D2 [FUNC_None]
        void                                        _InitCDO(); // 0x000545D2 [FUNC_None]
        void                                        _InitInstance(); // 0x000545D2 [FUNC_None]
        TOptional<TArray<Fnavigation_path_point>>   _L_2fUnrealEngine_2ecom_2fAINavigation_2fnavigation__path_N_RGetPathPoints(Ftuple_L_R __verse_0xB2CDDD72_Argument); // 0x0E3B5138 [Native | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class U_Root : public UObject
    {
    public:
    
    public: // Functions
        void                    _InitCDO(); // 0x000545D2 [FUNC_None]
        static Fnavigation_path_point  navigation_path_point_Factory(FSpatialMath_vector3 _ExprResult_0, FSpatialMath_vector3 _ExprResult_1); // 0x000545D2 [Static | HasOutParms | HasDefaults]
        static Fnavigation_path_point  navigation_path_point_OverrideFactory(uint8 __verse_0xFB48ED96__InitOverrideMap[0x000010], uint8 _ExprResultStack_0[0x000010], TOptional<bool> _ExprResult_1, FSpatialMath_vector3 _ExprResult_2, uint8 _ExprResultStack_3[0x000010], TOptional<bool> _ExprResult_4, FSpatialMath_vector3 _ExprResult_5); // 0x000545D2 [Static | HasOutParms | HasDefaults]
        static UConcurrency_task*      operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_N_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lentity_Mvector3_R __verse_0xB2CDDD72_Argument); // 0x000545D2 [Final | Static | Public | HasOutParms | BlueprintCallable]
        static UConcurrency_task*      operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_Ntuple_L_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_M_L_2fUnrealEngine_2ecom_2fAINavigation_N_Rnavigation__query_R_R(UConcurrency_task* __verse_0xC1E81372_CallingTask, int64 __verse_0xA3A00DDB_CallerResumeState, int64 __verse_0x2AC0E4D8_CallerCancelState, Ftuple_Lentity_Mtuple_Lvector3_Mnavigation__query_R_R __verse_0xB2CDDD72_Argument); // 0x000545D2 [Final | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) Fnavigation_path_point
    {
        FSpatialMath_vector3    __verse_0xB0C27E0A_Location;    // 0x000000 (0x000018)
    };
    // Size: 0x000001 (0x000001)
    struct Ftuple_L_R
    {
        uint8   _StructPaddingDummy;    // 0x000000 (0x000001)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) Ftuple_Lentity_Mtuple_Lvector3_Mnavigation__query_R_R
    {
        UEntity*                                __verse_0x18E3F084_Elem0;   // 0x000000 (0x000008)
        Ftuple_Lvector3_Mnavigation__query_R    __verse_0x7D844C3C_Elem1;   // 0x000008 (0x000020)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) Ftuple_Lentity_Mvector3_R
    {
        UEntity*                __verse_0x18E3F084_Elem0;   // 0x000000 (0x000008)
        FSpatialMath_vector3    __verse_0x7D844C3C_Elem1;   // 0x000008 (0x000018)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) Ftuple_Lvector3_Mnavigation__query_R
    {
        FSpatialMath_vector3        __verse_0x18E3F084_Elem0;   // 0x000000 (0x000018)
        UCompositeNavigationQuery*  __verse_0x7D844C3C_Elem1;   // 0x000018 (0x000008)
    };
}

