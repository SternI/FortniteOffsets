/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:16
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AINavigation/_Verse/VNI/AINavigation_Functions
 * ============================================================
 */

#include "AINavigation.hpp"

namespace UE
{

    struct Utask__Root_operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_Ntuple_L_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_M_L_2fUnrealEngine_2ecom_2fAINavigation_N_Rnavigation__query_R_R___Update_Params
    {
        int64   RetVal; // 0x000000 (0x000008) [ReturnValue] [Default: 324773760ll]
    };

    struct Utask__Root_operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_N_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_R___Update_Params
    {
        int64   RetVal; // 0x000000 (0x000008) [ReturnValue] [Default: 324773760ll]
    };

    struct Unavigation_user_component____L_2fVerse_2eorg_2fSceneGraph_2fcomponent_N_ROnAddedToScene_Params
    {
        Ftuple_L_R  __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000001)
    };

    struct Unavigation_user_component____L_2fVerse_2eorg_2fSceneGraph_2fcomponent_N_ROnRemovingFromScene_Params
    {
        Ftuple_L_R  __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000001)
    };

    struct Unavigation_path____L_2fUnrealEngine_2ecom_2fAINavigation_2fnavigation__path_N_RGetPathPoints_Params
    {
        Ftuple_L_R                                  __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000001)
        uint8                                       UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        TOptional<TArray<Fnavigation_path_point>>   RetVal;                         // 0x000008 (0x000010) [ReturnValue]
    };

    struct U_Root___navigation_path_point_Factory_Params
    {
        Fnavigation_path_point  RetVal;         // 0x000000 (0x000018) [ReturnValue]
        FSpatialMath_vector3    _ExprResult_0;  // 0x000018 (0x000018)
        FSpatialMath_vector3    _ExprResult_1;  // 0x000030 (0x000018)
    };

    struct U_Root___navigation_path_point_OverrideFactory_Params
    {
        Fnavigation_path_point  RetVal;                                         // 0x000000 (0x000018) [ReturnValue]
        uint8                   __verse_0xFB48ED96__InitOverrideMap[0x000010];  // 0x000018 (0x000010)
        uint8                   _ExprResultStack_0[0x000010];                   // 0x000028 (0x000010)
        TOptional<bool>         _ExprResult_1;                                  // 0x000038 (0x000002)
        uint8                   UnknownData_00003A[0x000006];                   // 0x00003A (0x000006)
        FSpatialMath_vector3    _ExprResult_2;                                  // 0x000040 (0x000018)
        uint8                   _ExprResultStack_3[0x000010];                   // 0x000058 (0x000010)
        TOptional<bool>         _ExprResult_4;                                  // 0x000068 (0x000002)
        uint8                   UnknownData_00006A[0x000006];                   // 0x00006A (0x000006)
        FSpatialMath_vector3    _ExprResult_5;                                  // 0x000070 (0x000018)
    };

    struct U_Root___operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_N_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_R_Params
    {
        UConcurrency_task*          __verse_0xC1E81372_CallingTask;         // 0x000000 (0x000008) [Default: 0x135BDA60]
        int64                       __verse_0xA3A00DDB_CallerResumeState;   // 0x000008 (0x000008) [Default: -1875721907330351055ll]
        int64                       __verse_0x2AC0E4D8_CallerCancelState;   // 0x000010 (0x000008) [Default: 140635374359184ll]
        Ftuple_Lentity_Mvector3_R   __verse_0xB2CDDD72_Argument;            // 0x000018 (0x000020)
        UConcurrency_task*          RetVal;                                 // 0x000038 (0x000008) [ReturnValue] [Default: 0x16A41560]
    };

    struct U_Root___operator_U_2eFindPath_U_L_N_L_2fVerse_2eorg_2fSceneGraph_N_Rentity_M_Ntuple_L_L_2fUnrealEngine_2ecom_2fTemporary_2fSpatialMath_N_Rvector3_M_L_2fUnrealEngine_2ecom_2fAINavigation_N_Rnavigation__query_R_R_Params
    {
        UConcurrency_task*                                      __verse_0xC1E81372_CallingTask;         // 0x000000 (0x000008) [Default: 0x135BDA60]
        int64                                                   __verse_0xA3A00DDB_CallerResumeState;   // 0x000008 (0x000008) [Default: -1875721907330351055ll]
        int64                                                   __verse_0x2AC0E4D8_CallerCancelState;   // 0x000010 (0x000008) [Default: 140635374359184ll]
        Ftuple_Lentity_Mtuple_Lvector3_Mnavigation__query_R_R   __verse_0xB2CDDD72_Argument;            // 0x000018 (0x000028)
        UConcurrency_task*                                      RetVal;                                 // 0x000040 (0x000008) [ReturnValue] [Default: nullptr]
    };

} // namespace UE

