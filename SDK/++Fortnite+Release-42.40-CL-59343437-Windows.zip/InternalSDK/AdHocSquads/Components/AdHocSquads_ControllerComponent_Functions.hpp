/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:43
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AdHocSquads/Components/AdHocSquads_ControllerComponent_Functions
 * ============================================================
 */

#include "AdHocSquads_ControllerComponent.hpp"

namespace UE
{

    struct UAdHocSquads_ControllerComponent_C___ExecuteUbergraph_AdHocSquads_ControllerComponent_Params
    {
        int32                           EntryPoint;                                         // 0x000000 (0x000004) [Default: 330213904]
        EAdHocSquads_SquadUpResult      Temp_byte_Variable;                                 // 0x000004 (0x000001) [Default: EAdHocSquads_SquadUpResult(0)]
        uint8                           UnknownData_000005[0x000003];                       // 0x000005 (0x000003)
        FText                           Temp_text_Variable;                                 // 0x000008 (0x000010)
        FText                           Temp_text_Variable_1;                               // 0x000018 (0x000010)
        FText                           Temp_text_Variable_2;                               // 0x000028 (0x000010)
        FText                           Temp_text_Variable_3;                               // 0x000038 (0x000010)
        FText                           Temp_text_Variable_4;                               // 0x000048 (0x000010)
        FText                           Temp_text_Variable_5;                               // 0x000058 (0x000010)
        FText                           Temp_text_Variable_6;                               // 0x000068 (0x000010)
        FText                           Temp_text_Variable_7;                               // 0x000078 (0x000010)
        FText                           Temp_text_Variable_8;                               // 0x000088 (0x000010)
        FText                           Temp_text_Variable_9;                               // 0x000098 (0x000010)
        FText                           Temp_text_Variable_10;                              // 0x0000A8 (0x000010)
        AFortPlayerStateAthena*         K2Node_Event_PlayerFromSquad;                       // 0x0000B8 (0x000008) [Default: nullptr]
        EAdHocSquads_SquadUpResult      K2Node_Event_FailureReason;                         // 0x0000C0 (0x000001) [Default: EAdHocSquads_SquadUpResult(0)]
        uint8                           UnknownData_0000C1[0x000007];                       // 0x0000C1 (0x000007)
        AFortPlayerStateAthena*         K2Node_Event_JoiningPlayer;                         // 0x0000C8 (0x000008) [Default: nullptr]
        bool                            K2Node_Event_bInviteInstigatedByThisPlayer_1;       // 0x0000D0 (0x000001) [Default: false]
        bool                            CallFunc_IsValid_ReturnValue;                       // 0x0000D1 (0x000001) [Default: false]
        uint8                           UnknownData_0000D2[0x000006];                       // 0x0000D2 (0x000006)
        FText                           K2Node_Select_Default;                              // 0x0000D8 (0x000010)
        FFormatArgumentData             K2Node_MakeStruct_FormatArgumentData;               // 0x0000E8 (0x000048)
        FFormatArgumentData             K2Node_MakeStruct_FormatArgumentData_1;             // 0x000130 (0x000048)
        FString                         CallFunc_GetPlayerNameForStreaming_ReturnValue;     // 0x000178 (0x000010) [Default: L""]
        TArray<FFormatArgumentData>     K2Node_MakeArray_Array;                             // 0x000188 (0x000010)
        FText                           CallFunc_Conv_StringToText_ReturnValue;             // 0x000198 (0x000010)
        FText                           CallFunc_Format_ReturnValue;                        // 0x0001A8 (0x000010)
        FFormatArgumentData             K2Node_MakeStruct_FormatArgumentData_2;             // 0x0001B8 (0x000048)
        TArray<FFormatArgumentData>     K2Node_MakeArray_Array_1;                           // 0x000200 (0x000010)
        FString                         CallFunc_GetPlayerNameForStreaming_ReturnValue_1;   // 0x000210 (0x000010) [Default: L""]
        FText                           CallFunc_Format_ReturnValue_1;                      // 0x000220 (0x000010)
        FText                           CallFunc_Conv_StringToText_ReturnValue_1;           // 0x000230 (0x000010)
        FFormatArgumentData             K2Node_MakeStruct_FormatArgumentData_3;             // 0x000240 (0x000048)
        bool                            CallFunc_IsValid_ReturnValue_1;                     // 0x000288 (0x000001) [Default: false]
        uint8                           UnknownData_000289[0x000007];                       // 0x000289 (0x000007)
        TArray<FFormatArgumentData>     K2Node_MakeArray_Array_2;                           // 0x000290 (0x000010)
        FText                           CallFunc_Format_ReturnValue_2;                      // 0x0002A0 (0x000010)
        AFortPlayerStateAthena*         K2Node_Event_PlayerTheOwningPlayerIsJoining;        // 0x0002B0 (0x000008) [Default: nullptr]
        bool                            K2Node_Event_bInviteInstigatedByThisPlayer;         // 0x0002B8 (0x000001) [Default: false]
        bool                            CallFunc_IsValid_ReturnValue_2;                     // 0x0002B9 (0x000001) [Default: false]
        uint8                           UnknownData_0002BA[0x000006];                       // 0x0002BA (0x000006)
        FString                         CallFunc_GetPlayerNameForStreaming_ReturnValue_2;   // 0x0002C0 (0x000010) [Default: L""]
        FText                           CallFunc_Conv_StringToText_ReturnValue_2;           // 0x0002D0 (0x000010)
        AFortPlayerStateAthena*         K2Node_Event_LeavingPlayer;                         // 0x0002E0 (0x000008) [Default: nullptr]
        EAdHocSquads_LeaveSquadReason   K2Node_Event_LeaveReason_1;                         // 0x0002E8 (0x000001) [Default: EAdHocSquads_LeaveSquadReason(0)]
        uint8                           UnknownData_0002E9[0x000007];                       // 0x0002E9 (0x000007)
        FFormatArgumentData             K2Node_MakeStruct_FormatArgumentData_4;             // 0x0002F0 (0x000048)
        bool                            CallFunc_IsValid_ReturnValue_3;                     // 0x000338 (0x000001) [Default: false]
        uint8                           UnknownData_000339[0x000007];                       // 0x000339 (0x000007)
        TArray<FFormatArgumentData>     K2Node_MakeArray_Array_3;                           // 0x000340 (0x000010)
        FText                           CallFunc_Format_ReturnValue_3;                      // 0x000350 (0x000010)
        FString                         CallFunc_GetPlayerNameForStreaming_ReturnValue_3;   // 0x000360 (0x000010) [Default: L""]
        FText                           CallFunc_Conv_StringToText_ReturnValue_3;           // 0x000370 (0x000010)
        EAdHocSquads_LeaveSquadReason   K2Node_Event_LeaveReason;                           // 0x000380 (0x000001) [Default: EAdHocSquads_LeaveSquadReason(0)]
        uint8                           UnknownData_000381[0x000007];                       // 0x000381 (0x000007)
        FFormatArgumentData             K2Node_MakeStruct_FormatArgumentData_5;             // 0x000388 (0x000048)
        TArray<FFormatArgumentData>     K2Node_MakeArray_Array_4;                           // 0x0003D0 (0x000010)
        TArray<FFormatArgumentData>     K2Node_MakeArray_Array_5;                           // 0x0003E0 (0x000010)
        FText                           CallFunc_Format_ReturnValue_4;                      // 0x0003F0 (0x000010)
        FText                           CallFunc_Format_ReturnValue_5;                      // 0x000400 (0x000010)
        AFortPlayerStateAthena*         K2Node_Event_PlayerInitiatingInvite;                // 0x000410 (0x000008) [Default: nullptr]
        FText                           CallFunc_Conv_ObjectToText_ReturnValue;             // 0x000418 (0x000010)
        AFortPlayerPawn*                CallFunc_GetCurrentPawn_ReturnValue;                // 0x000428 (0x000008) [Default: nullptr]
        FFormatArgumentData             K2Node_MakeStruct_FormatArgumentData_6;             // 0x000430 (0x000048)
        bool                            CallFunc_IsValid_ReturnValue_4;                     // 0x000478 (0x000001) [Default: false]
        uint8                           UnknownData_000479[0x000003];                       // 0x000479 (0x000003)
        int32                           CallFunc_GetNumberOfPlayersInSquad_ReturnValue;     // 0x00047C (0x000004) [Default: 0]
        int64                           CallFunc_Conv_IntToInt64_ReturnValue;               // 0x000480 (0x000008) [Default: 320785792ll]
        FFormatArgumentData             K2Node_MakeStruct_FormatArgumentData_7;             // 0x000488 (0x000048)
        TArray<FFormatArgumentData>     K2Node_MakeArray_Array_6;                           // 0x0004D0 (0x000010)
        FText                           CallFunc_Format_ReturnValue_6;                      // 0x0004E0 (0x000010)
    };

    struct UAdHocSquads_ControllerComponent_C___OnFailedToJoinSquad_Params
    {
        AFortPlayerStateAthena*     PlayerFromSquad;    // 0x000000 (0x000008) [Default: 0x13AEAA10]
        EAdHocSquads_SquadUpResult  FailureReason;      // 0x000008 (0x000001) [Default: EAdHocSquads_SquadUpResult(49)]
    };

    struct UAdHocSquads_ControllerComponent_C___OnOtherPlayerJoinedSquad_Params
    {
        AFortPlayerStateAthena* JoiningPlayer;                  // 0x000000 (0x000008) [Default: 0x13AEAA10]
        bool                    bInviteInstigatedByThisPlayer;  // 0x000008 (0x000001) [Default: true]
    };

    struct UAdHocSquads_ControllerComponent_C___OnOtherPlayerLeftSquad_Params
    {
        AFortPlayerStateAthena*         LeavingPlayer;  // 0x000000 (0x000008) [Default: 0x13AEAA10]
        EAdHocSquads_LeaveSquadReason   LeaveReason;    // 0x000008 (0x000001) [Default: EAdHocSquads_LeaveSquadReason(49)]
    };

    struct UAdHocSquads_ControllerComponent_C___OnOwningPlayerJoinedSquad_Params
    {
        AFortPlayerStateAthena* PlayerTheOwningPlayerIsJoining; // 0x000000 (0x000008) [Default: 0x13AEAA10]
        bool                    bInviteInstigatedByThisPlayer;  // 0x000008 (0x000001) [Default: true]
    };

    struct UAdHocSquads_ControllerComponent_C___OnOwningPlayerLeftSquad_Params
    {
        EAdHocSquads_LeaveSquadReason   LeaveReason;    // 0x000000 (0x000001) [Default: EAdHocSquads_LeaveSquadReason(16)]
    };

    struct UAdHocSquads_ControllerComponent_C___OnPlayerInitiatedSquadInvite_Params
    {
        AFortPlayerStateAthena* PlayerInitiatingInvite; // 0x000000 (0x000008) [Default: 0x13AEAA10]
    };

    struct UAdHocSquads_ControllerComponent_C___PlaySFX_Params
    {
        USoundBase*         Music_Stinger;                                  // 0x000000 (0x000008) [Default: 0x13AEAA10]
        bool                SFX_is_Attenuated;                              // 0x000008 (0x000001) [Default: true]
        uint8               UnknownData_000009[0x000007];                   // 0x000009 (0x000007)
        AFortPlayerPawn*    Attenuated_SFX_Attached_to_Fort_Player_Pawn;    // 0x000010 (0x000008) [Default: 0x7FEDD8332A80]
        USoundBase*         UI_SFX___Other_SFX_3P;                          // 0x000018 (0x000008) [Default: 0x7FE99A0CA1E0]
        USoundBase*         UI_SFX___Other_SFX_1P;                          // 0x000020 (0x000008) [Default: 0x57F437BC]
        bool                bLocallyControlled;                             // 0x000028 (0x000001) [Default: true]
        uint8               UnknownData_000029[0x000007];                   // 0x000029 (0x000007)
        USoundBase*         Selected_SFX;                                   // 0x000030 (0x000008) [Default: 0x130A96B0]
        bool                CallFunc_IsValid_ReturnValue;                   // 0x000038 (0x000001) [Default: true]
        uint8               UnknownData_000039[0x000007];                   // 0x000039 (0x000007)
        USceneComponent*    CallFunc_K2_GetRootComponent_ReturnValue;       // 0x000040 (0x000008) [Default: 0x9A0002]
        bool                Temp_bool_Variable;                             // 0x000048 (0x000001) [Default: false]
        uint8               UnknownData_000049[0x000007];                   // 0x000049 (0x000007)
        USoundBase*         K2Node_Select_Default;                          // 0x000050 (0x000008) [Default: nullptr]
        bool                CallFunc_IsValid_ReturnValue_1;                 // 0x000058 (0x000001) [Default: false]
        uint8               UnknownData_000059[0x000007];                   // 0x000059 (0x000007)
        UAudioComponent*    CallFunc_SpawnSoundAttached_ReturnValue;        // 0x000060 (0x000008) [Default: nullptr]
        bool                CallFunc_IsLocallyControlled_ReturnValue;       // 0x000068 (0x000001) [Default: false]
    };

    struct UAdHocSquads_ControllerComponent_C___ShowUIMessage_Params
    {
        FText   DisplayText;                            // 0x000000 (0x000010)
        bool    CallFunc_IsDedicatedServer_ReturnValue; // 0x000010 (0x000001) [Default: true]
    };

} // namespace UE

