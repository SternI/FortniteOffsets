/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:43
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AdHocSquads/Components/AdHocSquads_ControllerComponent
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000223 (0x00003B)
    class alignas(0x8) UAdHocSquads_ControllerComponent_C : public UFortControllerComponent_AdHocSquads
    {
    public:
        FPointerToUberGraphFrame    UberGraphFrame;             // 0x0001E8 (0x000008)
        USoundBase*                 MusicStinger_JoinSquad;     // 0x0001F0 (0x000008) [Default: 0x7FEE99447400]
        USoundBase*                 SFX_UI_JoinSquad;           // 0x0001F8 (0x000008) [Default: 0x7FEE99447800]
        USoundBase*                 MusicStinger_LeaveSquad;    // 0x000200 (0x000008) [Default: 0x7FEE99447000]
        USoundBase*                 SFX_UI_LeaveSquad;          // 0x000208 (0x000008) [Default: 0x7FEE9941D400]
        USoundBase*                 SFX_Whistle_1P;             // 0x000210 (0x000008) [Default: 0x7FEE9944BC00]
        USoundBase*                 SFX_Whistle_3P;             // 0x000218 (0x000008) [Default: 0x7FEE9944B800]
        bool                        bDebugPrintToScreen;        // 0x000220 (0x000001) [Default: false]
        bool                        bDebugPrintToLog;           // 0x000221 (0x000001) [Default: false]
        bool                        bDisableAudio;              // 0x000222 (0x000001) [Default: false]
    
    public: // Functions
        void    ExecuteUbergraph_AdHocSquads_ControllerComponent(int32 EntryPoint, EAdHocSquads_SquadUpResult Temp_byte_Variable, FText Temp_text_Variable, FText Temp_text_Variable_1, FText Temp_text_Variable_2, FText Temp_text_Variable_3, FText Temp_text_Variable_4, FText Temp_text_Variable_5, FText Temp_text_Variable_6, FText Temp_text_Variable_7, FText Temp_text_Variable_8, FText Temp_text_Variable_9, FText Temp_text_Variable_10, AFortPlayerStateAthena* K2Node_Event_PlayerFromSquad, EAdHocSquads_SquadUpResult K2Node_Event_FailureReason, AFortPlayerStateAthena* K2Node_Event_JoiningPlayer, bool K2Node_Event_bInviteInstigatedByThisPlayer_1, bool CallFunc_IsValid_ReturnValue, FText K2Node_Select_Default, FFormatArgumentData K2Node_MakeStruct_FormatArgumentData, FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_1, FString CallFunc_GetPlayerNameForStreaming_ReturnValue, TArray<FFormatArgumentData> K2Node_MakeArray_Array, FText CallFunc_Conv_StringToText_ReturnValue, FText CallFunc_Format_ReturnValue, FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2, TArray<FFormatArgumentData> K2Node_MakeArray_Array_1, FString CallFunc_GetPlayerNameForStreaming_ReturnValue_1, FText CallFunc_Format_ReturnValue_1, FText CallFunc_Conv_StringToText_ReturnValue_1, FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_3, bool CallFunc_IsValid_ReturnValue_1, TArray<FFormatArgumentData> K2Node_MakeArray_Array_2, FText CallFunc_Format_ReturnValue_2, AFortPlayerStateAthena* K2Node_Event_PlayerTheOwningPlayerIsJoining, bool K2Node_Event_bInviteInstigatedByThisPlayer, bool CallFunc_IsValid_ReturnValue_2, FString CallFunc_GetPlayerNameForStreaming_ReturnValue_2, FText CallFunc_Conv_StringToText_ReturnValue_2, AFortPlayerStateAthena* K2Node_Event_LeavingPlayer, EAdHocSquads_LeaveSquadReason K2Node_Event_LeaveReason_1, FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_4, bool CallFunc_IsValid_ReturnValue_3, TArray<FFormatArgumentData> K2Node_MakeArray_Array_3, FText CallFunc_Format_ReturnValue_3, FString CallFunc_GetPlayerNameForStreaming_ReturnValue_3, FText CallFunc_Conv_StringToText_ReturnValue_3, EAdHocSquads_LeaveSquadReason K2Node_Event_LeaveReason, FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_5, TArray<FFormatArgumentData> K2Node_MakeArray_Array_4, TArray<FFormatArgumentData> K2Node_MakeArray_Array_5, FText CallFunc_Format_ReturnValue_4, FText CallFunc_Format_ReturnValue_5, AFortPlayerStateAthena* K2Node_Event_PlayerInitiatingInvite, FText CallFunc_Conv_ObjectToText_ReturnValue, AFortPlayerPawn* CallFunc_GetCurrentPawn_ReturnValue, FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_6, bool CallFunc_IsValid_ReturnValue_4, int32 CallFunc_GetNumberOfPlayersInSquad_ReturnValue, int64 CallFunc_Conv_IntToInt64_ReturnValue, FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_7, TArray<FFormatArgumentData> K2Node_MakeArray_Array_6, FText CallFunc_Format_ReturnValue_6); // 0x000545D2 [Final | UbergraphFunction | HasDefaults]
        void    OnFailedToJoinSquad(AFortPlayerStateAthena* PlayerFromSquad, EAdHocSquads_SquadUpResult FailureReason); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnOtherPlayerJoinedSquad(AFortPlayerStateAthena* JoiningPlayer, bool bInviteInstigatedByThisPlayer); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnOtherPlayerLeftSquad(AFortPlayerStateAthena* LeavingPlayer, EAdHocSquads_LeaveSquadReason LeaveReason); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnOwningPlayerJoinedSquad(AFortPlayerStateAthena* PlayerTheOwningPlayerIsJoining, bool bInviteInstigatedByThisPlayer); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnOwningPlayerLeftSquad(EAdHocSquads_LeaveSquadReason LeaveReason); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnPlayerInitiatedSquadInvite(AFortPlayerStateAthena* PlayerInitiatingInvite); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    PlaySFX(USoundBase* Music_Stinger, bool SFX_is_Attenuated, AFortPlayerPawn* Attenuated_SFX_Attached_to_Fort_Player_Pawn, USoundBase* UI_SFX___Other_SFX_3P, USoundBase* UI_SFX___Other_SFX_1P, bool bLocallyControlled, USoundBase* Selected_SFX, bool CallFunc_IsValid_ReturnValue, USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue, bool Temp_bool_Variable, USoundBase* K2Node_Select_Default, bool CallFunc_IsValid_ReturnValue_1, UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue, bool CallFunc_IsLocallyControlled_ReturnValue); // 0x000545D2 [Public | BlueprintCallable | BlueprintEvent]
        void    ShowUIMessage(FText DisplayText, bool CallFunc_IsDedicatedServer_ReturnValue); // 0x000545D2 [Public | BlueprintCallable | BlueprintEvent]
    };
}

