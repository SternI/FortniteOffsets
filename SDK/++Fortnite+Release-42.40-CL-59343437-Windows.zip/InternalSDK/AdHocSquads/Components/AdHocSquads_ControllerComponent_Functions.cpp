/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:43
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AdHocSquads/Components/AdHocSquads_ControllerComponent_Functions
 * ============================================================
 */

#include "AdHocSquads_ControllerComponent_Functions.hpp"

namespace UE
{

    void UAdHocSquads_ControllerComponent_C::ExecuteUbergraph_AdHocSquads_ControllerComponent(int32 EntryPoint, EAdHocSquads_SquadUpResult Temp_byte_Variable, FText Temp_text_Variable, FText Temp_text_Variable_1, FText Temp_text_Variable_2, FText Temp_text_Variable_3, FText Temp_text_Variable_4, FText Temp_text_Variable_5, FText Temp_text_Variable_6, FText Temp_text_Variable_7, FText Temp_text_Variable_8, FText Temp_text_Variable_9, FText Temp_text_Variable_10, AFortPlayerStateAthena* K2Node_Event_PlayerFromSquad, EAdHocSquads_SquadUpResult K2Node_Event_FailureReason, AFortPlayerStateAthena* K2Node_Event_JoiningPlayer, bool K2Node_Event_bInviteInstigatedByThisPlayer_1, bool CallFunc_IsValid_ReturnValue, FText K2Node_Select_Default, FFormatArgumentData K2Node_MakeStruct_FormatArgumentData, FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_1, FString CallFunc_GetPlayerNameForStreaming_ReturnValue, TArray<FFormatArgumentData> K2Node_MakeArray_Array, FText CallFunc_Conv_StringToText_ReturnValue, FText CallFunc_Format_ReturnValue, FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2, TArray<FFormatArgumentData> K2Node_MakeArray_Array_1, FString CallFunc_GetPlayerNameForStreaming_ReturnValue_1, FText CallFunc_Format_ReturnValue_1, FText CallFunc_Conv_StringToText_ReturnValue_1, FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_3, bool CallFunc_IsValid_ReturnValue_1, TArray<FFormatArgumentData> K2Node_MakeArray_Array_2, FText CallFunc_Format_ReturnValue_2, AFortPlayerStateAthena* K2Node_Event_PlayerTheOwningPlayerIsJoining, bool K2Node_Event_bInviteInstigatedByThisPlayer, bool CallFunc_IsValid_ReturnValue_2, FString CallFunc_GetPlayerNameForStreaming_ReturnValue_2, FText CallFunc_Conv_StringToText_ReturnValue_2, AFortPlayerStateAthena* K2Node_Event_LeavingPlayer, EAdHocSquads_LeaveSquadReason K2Node_Event_LeaveReason_1, FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_4, bool CallFunc_IsValid_ReturnValue_3, TArray<FFormatArgumentData> K2Node_MakeArray_Array_3, FText CallFunc_Format_ReturnValue_3, FString CallFunc_GetPlayerNameForStreaming_ReturnValue_3, FText CallFunc_Conv_StringToText_ReturnValue_3, EAdHocSquads_LeaveSquadReason K2Node_Event_LeaveReason, FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_5, TArray<FFormatArgumentData> K2Node_MakeArray_Array_4, TArray<FFormatArgumentData> K2Node_MakeArray_Array_5, FText CallFunc_Format_ReturnValue_4, FText CallFunc_Format_ReturnValue_5, AFortPlayerStateAthena* K2Node_Event_PlayerInitiatingInvite, FText CallFunc_Conv_ObjectToText_ReturnValue, AFortPlayerPawn* CallFunc_GetCurrentPawn_ReturnValue, FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_6, bool CallFunc_IsValid_ReturnValue_4, int32 CallFunc_GetNumberOfPlayersInSquad_ReturnValue, int64 CallFunc_Conv_IntToInt64_ReturnValue, FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_7, TArray<FFormatArgumentData> K2Node_MakeArray_Array_6, FText CallFunc_Format_ReturnValue_6)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdHocSquads_ControllerComponent.AdHocSquads_ControllerComponent_C.ExecuteUbergraph_AdHocSquads_ControllerComponent");
    
        UAdHocSquads_ControllerComponent_C___ExecuteUbergraph_AdHocSquads_ControllerComponent_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.Temp_byte_Variable = Temp_byte_Variable;
        Params.Temp_text_Variable = Temp_text_Variable;
        Params.Temp_text_Variable_1 = Temp_text_Variable_1;
        Params.Temp_text_Variable_2 = Temp_text_Variable_2;
        Params.Temp_text_Variable_3 = Temp_text_Variable_3;
        Params.Temp_text_Variable_4 = Temp_text_Variable_4;
        Params.Temp_text_Variable_5 = Temp_text_Variable_5;
        Params.Temp_text_Variable_6 = Temp_text_Variable_6;
        Params.Temp_text_Variable_7 = Temp_text_Variable_7;
        Params.Temp_text_Variable_8 = Temp_text_Variable_8;
        Params.Temp_text_Variable_9 = Temp_text_Variable_9;
        Params.Temp_text_Variable_10 = Temp_text_Variable_10;
        Params.K2Node_Event_PlayerFromSquad = K2Node_Event_PlayerFromSquad;
        Params.K2Node_Event_FailureReason = K2Node_Event_FailureReason;
        Params.K2Node_Event_JoiningPlayer = K2Node_Event_JoiningPlayer;
        Params.K2Node_Event_bInviteInstigatedByThisPlayer_1 = K2Node_Event_bInviteInstigatedByThisPlayer_1;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.K2Node_Select_Default = K2Node_Select_Default;
        Params.K2Node_MakeStruct_FormatArgumentData = K2Node_MakeStruct_FormatArgumentData;
        Params.K2Node_MakeStruct_FormatArgumentData_1 = K2Node_MakeStruct_FormatArgumentData_1;
        Params.CallFunc_GetPlayerNameForStreaming_ReturnValue = CallFunc_GetPlayerNameForStreaming_ReturnValue;
        Params.K2Node_MakeArray_Array = K2Node_MakeArray_Array;
        Params.CallFunc_Conv_StringToText_ReturnValue = CallFunc_Conv_StringToText_ReturnValue;
        Params.CallFunc_Format_ReturnValue = CallFunc_Format_ReturnValue;
        Params.K2Node_MakeStruct_FormatArgumentData_2 = K2Node_MakeStruct_FormatArgumentData_2;
        Params.K2Node_MakeArray_Array_1 = K2Node_MakeArray_Array_1;
        Params.CallFunc_GetPlayerNameForStreaming_ReturnValue_1 = CallFunc_GetPlayerNameForStreaming_ReturnValue_1;
        Params.CallFunc_Format_ReturnValue_1 = CallFunc_Format_ReturnValue_1;
        Params.CallFunc_Conv_StringToText_ReturnValue_1 = CallFunc_Conv_StringToText_ReturnValue_1;
        Params.K2Node_MakeStruct_FormatArgumentData_3 = K2Node_MakeStruct_FormatArgumentData_3;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
        Params.K2Node_MakeArray_Array_2 = K2Node_MakeArray_Array_2;
        Params.CallFunc_Format_ReturnValue_2 = CallFunc_Format_ReturnValue_2;
        Params.K2Node_Event_PlayerTheOwningPlayerIsJoining = K2Node_Event_PlayerTheOwningPlayerIsJoining;
        Params.K2Node_Event_bInviteInstigatedByThisPlayer = K2Node_Event_bInviteInstigatedByThisPlayer;
        Params.CallFunc_IsValid_ReturnValue_2 = CallFunc_IsValid_ReturnValue_2;
        Params.CallFunc_GetPlayerNameForStreaming_ReturnValue_2 = CallFunc_GetPlayerNameForStreaming_ReturnValue_2;
        Params.CallFunc_Conv_StringToText_ReturnValue_2 = CallFunc_Conv_StringToText_ReturnValue_2;
        Params.K2Node_Event_LeavingPlayer = K2Node_Event_LeavingPlayer;
        Params.K2Node_Event_LeaveReason_1 = K2Node_Event_LeaveReason_1;
        Params.K2Node_MakeStruct_FormatArgumentData_4 = K2Node_MakeStruct_FormatArgumentData_4;
        Params.CallFunc_IsValid_ReturnValue_3 = CallFunc_IsValid_ReturnValue_3;
        Params.K2Node_MakeArray_Array_3 = K2Node_MakeArray_Array_3;
        Params.CallFunc_Format_ReturnValue_3 = CallFunc_Format_ReturnValue_3;
        Params.CallFunc_GetPlayerNameForStreaming_ReturnValue_3 = CallFunc_GetPlayerNameForStreaming_ReturnValue_3;
        Params.CallFunc_Conv_StringToText_ReturnValue_3 = CallFunc_Conv_StringToText_ReturnValue_3;
        Params.K2Node_Event_LeaveReason = K2Node_Event_LeaveReason;
        Params.K2Node_MakeStruct_FormatArgumentData_5 = K2Node_MakeStruct_FormatArgumentData_5;
        Params.K2Node_MakeArray_Array_4 = K2Node_MakeArray_Array_4;
        Params.K2Node_MakeArray_Array_5 = K2Node_MakeArray_Array_5;
        Params.CallFunc_Format_ReturnValue_4 = CallFunc_Format_ReturnValue_4;
        Params.CallFunc_Format_ReturnValue_5 = CallFunc_Format_ReturnValue_5;
        Params.K2Node_Event_PlayerInitiatingInvite = K2Node_Event_PlayerInitiatingInvite;
        Params.CallFunc_Conv_ObjectToText_ReturnValue = CallFunc_Conv_ObjectToText_ReturnValue;
        Params.CallFunc_GetCurrentPawn_ReturnValue = CallFunc_GetCurrentPawn_ReturnValue;
        Params.K2Node_MakeStruct_FormatArgumentData_6 = K2Node_MakeStruct_FormatArgumentData_6;
        Params.CallFunc_IsValid_ReturnValue_4 = CallFunc_IsValid_ReturnValue_4;
        Params.CallFunc_GetNumberOfPlayersInSquad_ReturnValue = CallFunc_GetNumberOfPlayersInSquad_ReturnValue;
        Params.CallFunc_Conv_IntToInt64_ReturnValue = CallFunc_Conv_IntToInt64_ReturnValue;
        Params.K2Node_MakeStruct_FormatArgumentData_7 = K2Node_MakeStruct_FormatArgumentData_7;
        Params.K2Node_MakeArray_Array_6 = K2Node_MakeArray_Array_6;
        Params.CallFunc_Format_ReturnValue_6 = CallFunc_Format_ReturnValue_6;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAdHocSquads_ControllerComponent_C::OnFailedToJoinSquad(AFortPlayerStateAthena* PlayerFromSquad, EAdHocSquads_SquadUpResult FailureReason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdHocSquads_ControllerComponent.AdHocSquads_ControllerComponent_C.OnFailedToJoinSquad");
    
        UAdHocSquads_ControllerComponent_C___OnFailedToJoinSquad_Params Params{};
        Params.PlayerFromSquad = PlayerFromSquad;
        Params.FailureReason = FailureReason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAdHocSquads_ControllerComponent_C::OnOtherPlayerJoinedSquad(AFortPlayerStateAthena* JoiningPlayer, bool bInviteInstigatedByThisPlayer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdHocSquads_ControllerComponent.AdHocSquads_ControllerComponent_C.OnOtherPlayerJoinedSquad");
    
        UAdHocSquads_ControllerComponent_C___OnOtherPlayerJoinedSquad_Params Params{};
        Params.JoiningPlayer = JoiningPlayer;
        Params.bInviteInstigatedByThisPlayer = bInviteInstigatedByThisPlayer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAdHocSquads_ControllerComponent_C::OnOtherPlayerLeftSquad(AFortPlayerStateAthena* LeavingPlayer, EAdHocSquads_LeaveSquadReason LeaveReason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdHocSquads_ControllerComponent.AdHocSquads_ControllerComponent_C.OnOtherPlayerLeftSquad");
    
        UAdHocSquads_ControllerComponent_C___OnOtherPlayerLeftSquad_Params Params{};
        Params.LeavingPlayer = LeavingPlayer;
        Params.LeaveReason = LeaveReason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAdHocSquads_ControllerComponent_C::OnOwningPlayerJoinedSquad(AFortPlayerStateAthena* PlayerTheOwningPlayerIsJoining, bool bInviteInstigatedByThisPlayer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdHocSquads_ControllerComponent.AdHocSquads_ControllerComponent_C.OnOwningPlayerJoinedSquad");
    
        UAdHocSquads_ControllerComponent_C___OnOwningPlayerJoinedSquad_Params Params{};
        Params.PlayerTheOwningPlayerIsJoining = PlayerTheOwningPlayerIsJoining;
        Params.bInviteInstigatedByThisPlayer = bInviteInstigatedByThisPlayer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAdHocSquads_ControllerComponent_C::OnOwningPlayerLeftSquad(EAdHocSquads_LeaveSquadReason LeaveReason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdHocSquads_ControllerComponent.AdHocSquads_ControllerComponent_C.OnOwningPlayerLeftSquad");
    
        UAdHocSquads_ControllerComponent_C___OnOwningPlayerLeftSquad_Params Params{};
        Params.LeaveReason = LeaveReason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAdHocSquads_ControllerComponent_C::OnPlayerInitiatedSquadInvite(AFortPlayerStateAthena* PlayerInitiatingInvite)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdHocSquads_ControllerComponent.AdHocSquads_ControllerComponent_C.OnPlayerInitiatedSquadInvite");
    
        UAdHocSquads_ControllerComponent_C___OnPlayerInitiatedSquadInvite_Params Params{};
        Params.PlayerInitiatingInvite = PlayerInitiatingInvite;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAdHocSquads_ControllerComponent_C::PlaySFX(USoundBase* Music_Stinger, bool SFX_is_Attenuated, AFortPlayerPawn* Attenuated_SFX_Attached_to_Fort_Player_Pawn, USoundBase* UI_SFX___Other_SFX_3P, USoundBase* UI_SFX___Other_SFX_1P, bool bLocallyControlled, USoundBase* Selected_SFX, bool CallFunc_IsValid_ReturnValue, USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue, bool Temp_bool_Variable, USoundBase* K2Node_Select_Default, bool CallFunc_IsValid_ReturnValue_1, UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue, bool CallFunc_IsLocallyControlled_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdHocSquads_ControllerComponent.AdHocSquads_ControllerComponent_C.PlaySFX");
    
        UAdHocSquads_ControllerComponent_C___PlaySFX_Params Params{};
        Params.Music_Stinger = Music_Stinger;
        Params.SFX_is_Attenuated = SFX_is_Attenuated;
        Params.Attenuated_SFX_Attached_to_Fort_Player_Pawn = Attenuated_SFX_Attached_to_Fort_Player_Pawn;
        Params.UI_SFX___Other_SFX_3P = UI_SFX___Other_SFX_3P;
        Params.UI_SFX___Other_SFX_1P = UI_SFX___Other_SFX_1P;
        Params.bLocallyControlled = bLocallyControlled;
        Params.Selected_SFX = Selected_SFX;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_K2_GetRootComponent_ReturnValue = CallFunc_K2_GetRootComponent_ReturnValue;
        Params.Temp_bool_Variable = Temp_bool_Variable;
        Params.K2Node_Select_Default = K2Node_Select_Default;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
        Params.CallFunc_SpawnSoundAttached_ReturnValue = CallFunc_SpawnSoundAttached_ReturnValue;
        Params.CallFunc_IsLocallyControlled_ReturnValue = CallFunc_IsLocallyControlled_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAdHocSquads_ControllerComponent_C::ShowUIMessage(FText DisplayText, bool CallFunc_IsDedicatedServer_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdHocSquads_ControllerComponent.AdHocSquads_ControllerComponent_C.ShowUIMessage");
    
        UAdHocSquads_ControllerComponent_C___ShowUIMessage_Params Params{};
        Params.DisplayText = DisplayText;
        Params.CallFunc_IsDedicatedServer_ReturnValue = CallFunc_IsDedicatedServer_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

