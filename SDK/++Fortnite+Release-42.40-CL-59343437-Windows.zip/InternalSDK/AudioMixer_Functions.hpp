/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:10
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioMixer_Functions
 * ============================================================
 */

#include "AudioMixer.hpp"

namespace UE
{

    struct UAudioMixerBlueprintLibrary___AddMasterSubmixEffect_Params
    {
        UObject*                    WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundEffectSubmixPreset*   SubmixEffectPreset; // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
    };

    struct UAudioMixerBlueprintLibrary___AddSourceEffectToPresetChain_Params
    {
        UObject*                        WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundEffectSourcePresetChain*  PresetChain;        // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
        FSourceEffectChainEntry         Entry;              // 0x000010 (0x000010)
    };

    struct UAudioMixerBlueprintLibrary___AddSubmixEffect_Params
    {
        UObject*                    WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundSubmix*               SoundSubmix;        // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
        USoundEffectSubmixPreset*   SubmixEffectPreset; // 0x000010 (0x000008) [Default: 0x16FAEDC0]
        int32                       ReturnValue;        // 0x000018 (0x000004) [ReturnValue] [Default: 385544544]
    };

    struct UAudioMixerBlueprintLibrary___ClearMasterSubmixEffects_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
    };

    struct UAudioMixerBlueprintLibrary___ClearSubmixEffectChainOverride_Params
    {
        UObject*        WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundSubmix*   SoundSubmix;        // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
        float           FadeTimeSec;        // 0x000010 (0x000004) [Default: 4.05397e-25f]
    };

    struct UAudioMixerBlueprintLibrary___ClearSubmixEffects_Params
    {
        UObject*        WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundSubmix*   SoundSubmix;        // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
    };

    struct UAudioMixerBlueprintLibrary___Conv_AudioOutputDeviceInfoToString_Params
    {
        FAudioOutputDeviceInfo  Info;           // 0x000000 (0x000048) [OutParam]
        FString                 ReturnValue;    // 0x000048 (0x000010) [ReturnValue] [Default: L""]
    };

    struct UAudioMixerBlueprintLibrary___GetAvailableAudioOutputDevices_Params
    {
        UObject*                        WorldContextObject;     // 0x000000 (0x000008) [Default: 0x130A5F60]
        OnAudioOutputDevicesObtained    OnObtainDevicesEvent;   // 0x000008 (0x00000C) [OutParam]
    };

    struct UAudioMixerBlueprintLibrary___GetCurrentAudioOutputDeviceName_Params
    {
        UObject*                        WorldContextObject;         // 0x000000 (0x000008) [Default: 0x130A5F60]
        OnMainAudioOutputDeviceObtained OnObtainCurrentDeviceEvent; // 0x000008 (0x00000C) [OutParam]
    };

    struct UAudioMixerBlueprintLibrary___GetMagnitudeForFrequencies_Params
    {
        UObject*        WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        TArray<float>   Frequencies;        // 0x000008 (0x000010) [OutParam]
        TArray<float>   Magnitudes;         // 0x000018 (0x000010) [OutParam]
        USoundSubmix*   SubmixToAnalyze;    // 0x000028 (0x000008) [Default: 0x1326CB70]
    };

    struct UAudioMixerBlueprintLibrary___GetNumberOfEntriesInSourceEffectChain_Params
    {
        UObject*                        WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundEffectSourcePresetChain*  PresetChain;        // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
        int32                           ReturnValue;        // 0x000010 (0x000004) [ReturnValue] [Default: 385543616]
    };

    struct UAudioMixerBlueprintLibrary___GetPhaseForFrequencies_Params
    {
        UObject*        WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        TArray<float>   Frequencies;        // 0x000008 (0x000010) [OutParam]
        TArray<float>   Phases;             // 0x000018 (0x000010) [OutParam]
        USoundSubmix*   SubmixToAnalyze;    // 0x000028 (0x000008) [Default: 0x1326CB70]
    };

    struct UAudioMixerBlueprintLibrary___IsAudioBusActive_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        UAudioBus*  AudioBus;           // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
        bool        ReturnValue;        // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioMixerBlueprintLibrary___MakeFullSpectrumSpectralAnalysisBandSettings_Params
    {
        int32                                               InNumBands;                     // 0x000000 (0x000004) [Default: 319446880]
        float                                               InMinimumFrequency;             // 0x000004 (0x000004) [Default: 0f]
        float                                               InMaximumFrequency;             // 0x000008 (0x000004) [Default: 6.86636e-44f]
        int32                                               InAttackTimeMsec;               // 0x00000C (0x000004) [Default: 152836317]
        int32                                               InReleaseTimeMsec;              // 0x000010 (0x000004) [Default: 385543616]
        uint8                                               UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        TArray<FSoundSubmixSpectralAnalysisBandSettings>    ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UAudioMixerBlueprintLibrary___MakeMusicalSpectralAnalysisBandSettings_Params
    {
        int32                                               InNumSemitones;                 // 0x000000 (0x000004) [Default: 319446880]
        EMusicalNoteName                                    InStartingMusicalNote;          // 0x000004 (0x000001) [Default: EMusicalNoteName(0)]
        uint8                                               UnknownData_000005[0x000003];   // 0x000005 (0x000003)
        int32                                               InStartingOctave;               // 0x000008 (0x000004) [Default: 49]
        int32                                               InAttackTimeMsec;               // 0x00000C (0x000004) [Default: 152836317]
        int32                                               InReleaseTimeMsec;              // 0x000010 (0x000004) [Default: 385543616]
        uint8                                               UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        TArray<FSoundSubmixSpectralAnalysisBandSettings>    ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UAudioMixerBlueprintLibrary___MakePresetSpectralAnalysisBandSettings_Params
    {
        EAudioSpectrumBandPresetType                        InBandPresetType;               // 0x000000 (0x000001) [Default: EAudioSpectrumBandPresetType(96)]
        uint8                                               UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        int32                                               InNumBands;                     // 0x000004 (0x000004) [Default: 0]
        int32                                               InAttackTimeMsec;               // 0x000008 (0x000004) [Default: 49]
        int32                                               InReleaseTimeMsec;              // 0x00000C (0x000004) [Default: 152836317]
        TArray<FSoundSubmixSpectralAnalysisBandSettings>    ReturnValue;                    // 0x000010 (0x000010) [ReturnValue]
    };

    struct UAudioMixerBlueprintLibrary___PauseRecordingOutput_Params
    {
        UObject*        WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundSubmix*   SubmixToPause;      // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
    };

    struct UAudioMixerBlueprintLibrary___PrimeSoundCueForPlayback_Params
    {
        USoundCue*  SoundCue;   // 0x000000 (0x000008) [Default: 0x130A5F60]
    };

    struct UAudioMixerBlueprintLibrary___PrimeSoundForPlayback_Params
    {
        USoundWave*         SoundWave;          // 0x000000 (0x000008) [Default: 0x130A5F60]
        OnSoundLoadComplete OnLoadCompletion;   // 0x000008 (0x00000C)
    };

    struct UAudioMixerBlueprintLibrary___RegisterAudioBusToSubmix_Params
    {
        UObject*        WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundSubmix*   SoundSubmix;        // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
        UAudioBus*      AudioBus;           // 0x000010 (0x000008) [Default: 0x16FAEDC0]
    };

    struct UAudioMixerBlueprintLibrary___RemoveMasterSubmixEffect_Params
    {
        UObject*                    WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundEffectSubmixPreset*   SubmixEffectPreset; // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
    };

    struct UAudioMixerBlueprintLibrary___RemoveSourceEffectFromPresetChain_Params
    {
        UObject*                        WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundEffectSourcePresetChain*  PresetChain;        // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
        int32                           EntryIndex;         // 0x000010 (0x000004) [Default: 385543616]
    };

    struct UAudioMixerBlueprintLibrary___RemoveSubmixEffect_Params
    {
        UObject*                    WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundSubmix*               SoundSubmix;        // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
        USoundEffectSubmixPreset*   SubmixEffectPreset; // 0x000010 (0x000008) [Default: 0x16FAEDC0]
    };

    struct UAudioMixerBlueprintLibrary___RemoveSubmixEffectAtIndex_Params
    {
        UObject*        WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundSubmix*   SoundSubmix;        // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
        int32           SubmixChainIndex;   // 0x000010 (0x000004) [Default: 385543616]
    };

    struct UAudioMixerBlueprintLibrary___RemoveSubmixEffectPreset_Params
    {
        UObject*                    WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundSubmix*               SoundSubmix;        // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
        USoundEffectSubmixPreset*   SubmixEffectPreset; // 0x000010 (0x000008) [Default: 0x16FAEDC0]
    };

    struct UAudioMixerBlueprintLibrary___RemoveSubmixEffectPresetAtIndex_Params
    {
        UObject*        WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundSubmix*   SoundSubmix;        // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
        int32           SubmixChainIndex;   // 0x000010 (0x000004) [Default: 385543616]
    };

    struct UAudioMixerBlueprintLibrary___ReplaceSoundEffectSubmix_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundSubmix*               InSoundSubmix;                  // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
        int32                       SubmixChainIndex;               // 0x000010 (0x000004) [Default: 385543616]
        uint8                       UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        USoundEffectSubmixPreset*   SubmixEffectPreset;             // 0x000018 (0x000008) [Default: 0x16FAF160]
    };

    struct UAudioMixerBlueprintLibrary___ReplaceSubmixEffect_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundSubmix*               InSoundSubmix;                  // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
        int32                       SubmixChainIndex;               // 0x000010 (0x000004) [Default: 385543616]
        uint8                       UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        USoundEffectSubmixPreset*   SubmixEffectPreset;             // 0x000018 (0x000008) [Default: 0x16FAF160]
    };

    struct UAudioMixerBlueprintLibrary___ResumeRecordingOutput_Params
    {
        UObject*        WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundSubmix*   SubmixToPause;      // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
    };

    struct UAudioMixerBlueprintLibrary___SetBypassSourceEffectChainEntry_Params
    {
        UObject*                        WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundEffectSourcePresetChain*  PresetChain;        // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
        int32                           EntryIndex;         // 0x000010 (0x000004) [Default: 385543616]
        bool                            bBypassed;          // 0x000014 (0x000001) [Default: false]
    };

    struct UAudioMixerBlueprintLibrary___SetSubmixEffectChainOverride_Params
    {
        UObject*                            WorldContextObject;         // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundSubmix*                       SoundSubmix;                // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
        TArray<USoundEffectSubmixPreset*>   SubmixEffectPresetChain;    // 0x000010 (0x000010)
        float                               FadeTimeSec;                // 0x000020 (0x000004) [Default: 6.73589e+19f]
    };

    struct UAudioMixerBlueprintLibrary___StartAnalyzingOutput_Params
    {
        UObject*                    WorldContextObject;     // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundSubmix*               SubmixToAnalyze;        // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
        EFFTSize                    FFTSize;                // 0x000010 (0x000001) [Default: EFFTSize(192)]
        EFFTPeakInterpolationMethod InterpolationMethod;    // 0x000011 (0x000001) [Default: EFFTPeakInterpolationMethod(237)]
        EFFTWindowType              WindowType;             // 0x000012 (0x000001) [Default: EFFTWindowType(250)]
        uint8                       UnknownByte_000013;     // 0x000013 (0x000001)
        float                       HopSize;                // 0x000014 (0x000004) [Default: 0f]
        EAudioSpectrumType          SpectrumType;           // 0x000018 (0x000001) [Default: EAudioSpectrumType(96)]
    };

    struct UAudioMixerBlueprintLibrary___StartAudioBus_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        UAudioBus*  AudioBus;           // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
    };

    struct UAudioMixerBlueprintLibrary___StartRecordingOutput_Params
    {
        UObject*        WorldContextObject;             // 0x000000 (0x000008) [Default: 0x130A5F60]
        float           ExpectedDuration;               // 0x000008 (0x000004) [Default: 6.86636e-44f]
        uint8           UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        USoundSubmix*   SubmixToRecord;                 // 0x000010 (0x000008) [Default: 0x16FAEDC0]
    };

    struct UAudioMixerBlueprintLibrary___StopAnalyzingOutput_Params
    {
        UObject*        WorldContextObject;     // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundSubmix*   SubmixToStopAnalyzing;  // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
    };

    struct UAudioMixerBlueprintLibrary___StopAudioBus_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        UAudioBus*  AudioBus;           // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
    };

    struct UAudioMixerBlueprintLibrary___StopRecordingOutput_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x130A5F60]
        EAudioRecordingExportType   ExportType;                     // 0x000008 (0x000001) [Default: EAudioRecordingExportType(49)]
        uint8                       UnknownData_000009[0x000007];   // 0x000009 (0x000007)
        FString                     Name;                           // 0x000010 (0x000010) [Default: L""]
        FString                     Path;                           // 0x000020 (0x000010) [Default: L""]
        USoundSubmix*               SubmixToRecord;                 // 0x000030 (0x000008) [Default: 0x81C18DD00000031]
        USoundWave*                 ExistingSoundWaveToOverwrite;   // 0x000038 (0x000008) [Default: 0x16FBC6D0]
        USoundWave*                 ReturnValue;                    // 0x000040 (0x000008) [ReturnValue] [Default: 0x16FAF160]
    };

    struct UAudioMixerBlueprintLibrary___SwapAudioOutputDevice_Params
    {
        UObject*                WorldContextObject;     // 0x000000 (0x000008) [Default: 0x130A5F60]
        FString                 NewDeviceId;            // 0x000008 (0x000010) [Default: L""]
        OnCompletedDeviceSwap   OnCompletedDeviceSwap;  // 0x000018 (0x00000C) [OutParam]
    };

    struct UAudioMixerBlueprintLibrary___TrimAudioCache_Params
    {
        float   InMegabytesToFree;  // 0x000000 (0x000004) [Default: 1.74651e-27f]
        float   ReturnValue;        // 0x000004 (0x000004) [ReturnValue] [Default: 0f]
    };

    struct UAudioMixerBlueprintLibrary___UnregisterAudioBusFromSubmix_Params
    {
        UObject*        WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundSubmix*   SoundSubmix;        // 0x000008 (0x000008) [Default: 0x91C18DD00000031]
        UAudioBus*      AudioBus;           // 0x000010 (0x000008) [Default: 0x16FAEDC0]
    };

    struct UQuartzClockHandle___GetBeatProgressPercent_Params
    {
        EQuartzCommandQuantization  QuantizationBoundary;           // 0x000000 (0x000001) [Default: EQuartzCommandQuantization(112)]
        uint8                       UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        float                       PhaseOffset;                    // 0x000004 (0x000004) [Default: 0f]
        float                       MSOffset;                       // 0x000008 (0x000004) [Default: 6.86636e-44f]
        float                       ReturnValue;                    // 0x00000C (0x000004) [ReturnValue] [Default: 4.69738e-34f]
    };

    struct UQuartzClockHandle___GetBeatsPerMinute_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326CB70]
        float       ReturnValue;        // 0x000008 (0x000004) [ReturnValue] [Default: 6.86636e-44f]
    };

    struct UQuartzClockHandle___GetCurrentTimestamp_Params
    {
        UObject*                    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326CB70]
        FQuartzTransportTimeStamp   ReturnValue;        // 0x000008 (0x000010) [ReturnValue]
    };

    struct UQuartzClockHandle___GetDurationOfQuantizationTypeInSeconds_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x1326CB70]
        EQuartzCommandQuantization  QuantizationType;               // 0x000008 (0x000001) [OutParam] [Default: EQuartzCommandQuantization(49)]
        uint8                       UnknownData_000009[0x000003];   // 0x000009 (0x000003)
        float                       Multiplier;                     // 0x00000C (0x000004) [Default: 4.69738e-34f]
        float                       ReturnValue;                    // 0x000010 (0x000004) [ReturnValue] [Default: 4.06767e-25f]
    };

    struct UQuartzClockHandle___GetEstimatedRunTime_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326CB70]
        float       ReturnValue;        // 0x000008 (0x000004) [ReturnValue] [Default: 6.86636e-44f]
    };

    struct UQuartzClockHandle___GetMillisecondsPerTick_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326CB70]
        float       ReturnValue;        // 0x000008 (0x000004) [ReturnValue] [Default: 6.86636e-44f]
    };

    struct UQuartzClockHandle___GetSecondsPerTick_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326CB70]
        float       ReturnValue;        // 0x000008 (0x000004) [ReturnValue] [Default: 6.86636e-44f]
    };

    struct UQuartzClockHandle___GetThirtySecondNotesPerMinute_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326CB70]
        float       ReturnValue;        // 0x000008 (0x000004) [ReturnValue] [Default: 6.86636e-44f]
    };

    struct UQuartzClockHandle___GetTicksPerSecond_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326CB70]
        float       ReturnValue;        // 0x000008 (0x000004) [ReturnValue] [Default: 6.86636e-44f]
    };

    struct UQuartzClockHandle___IsClockRunning_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326CB70]
        bool        ReturnValue;        // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct UQuartzClockHandle___NotifyOnQuantizationBoundary_Params
    {
        UObject*                    WorldContextObject;     // 0x000000 (0x000008) [Default: 0x1326CB70]
        FQuartzQuantizationBoundary InQuantizationBoundary; // 0x000008 (0x000020)
        OnQuartzCommandEventBP      InDelegate;             // 0x000028 (0x00000C) [OutParam]
        float                       InMsOffset;             // 0x000034 (0x000004) [Default: 0f]
    };

    struct UQuartzClockHandle___PauseClock_Params
    {
        UObject*            WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326CB70]
        UQuartzClockHandle* ClockHandle;        // 0x000008 (0x000008) [OutParam] [Default: 0x81C18DD00000031]
    };

    struct UQuartzClockHandle___ResetTransport_Params
    {
        UObject*                WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326CB70]
        OnQuartzCommandEventBP  InDelegate;         // 0x000008 (0x00000C) [OutParam]
    };

    struct UQuartzClockHandle___ResetTransportQuantized_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x1326CB70]
        FQuartzQuantizationBoundary InQuantizationBoundary;         // 0x000008 (0x000020)
        OnQuartzCommandEventBP      InDelegate;                     // 0x000028 (0x00000C) [OutParam]
        uint8                       UnknownData_000034[0x000004];   // 0x000034 (0x000004)
        UQuartzClockHandle*         ClockHandle;                    // 0x000038 (0x000008) [OutParam] [Default: 0x1326CE20]
    };

    struct UQuartzClockHandle___ResumeClock_Params
    {
        UObject*            WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326CB70]
        UQuartzClockHandle* ClockHandle;        // 0x000008 (0x000008) [OutParam] [Default: 0x81C18DD00000031]
    };

    struct UQuartzClockHandle___SetBeatsPerMinute_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x1326CB70]
        FQuartzQuantizationBoundary QuantizationBoundary;           // 0x000008 (0x000020) [OutParam]
        OnQuartzCommandEventBP      Delegate;                       // 0x000028 (0x00000C) [OutParam]
        uint8                       UnknownData_000034[0x000004];   // 0x000034 (0x000004)
        UQuartzClockHandle*         ClockHandle;                    // 0x000038 (0x000008) [OutParam] [Default: 0x1326CE20]
        float                       BeatsPerMinute;                 // 0x000040 (0x000004) [Default: 2.10538e-27f]
    };

    struct UQuartzClockHandle___SetMillisecondsPerTick_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x1326CB70]
        FQuartzQuantizationBoundary QuantizationBoundary;           // 0x000008 (0x000020) [OutParam]
        OnQuartzCommandEventBP      Delegate;                       // 0x000028 (0x00000C) [OutParam]
        uint8                       UnknownData_000034[0x000004];   // 0x000034 (0x000004)
        UQuartzClockHandle*         ClockHandle;                    // 0x000038 (0x000008) [OutParam] [Default: 0x1326CE20]
        float                       MillisecondsPerTick;            // 0x000040 (0x000004) [Default: 2.10538e-27f]
    };

    struct UQuartzClockHandle___SetSecondsPerTick_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x1326CB70]
        FQuartzQuantizationBoundary QuantizationBoundary;           // 0x000008 (0x000020) [OutParam]
        OnQuartzCommandEventBP      Delegate;                       // 0x000028 (0x00000C) [OutParam]
        uint8                       UnknownData_000034[0x000004];   // 0x000034 (0x000004)
        UQuartzClockHandle*         ClockHandle;                    // 0x000038 (0x000008) [OutParam] [Default: 0x1326CE20]
        float                       SecondsPerTick;                 // 0x000040 (0x000004) [Default: 2.10538e-27f]
    };

    struct UQuartzClockHandle___SetThirtySecondNotesPerMinute_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x1326CB70]
        FQuartzQuantizationBoundary QuantizationBoundary;           // 0x000008 (0x000020) [OutParam]
        OnQuartzCommandEventBP      Delegate;                       // 0x000028 (0x00000C) [OutParam]
        uint8                       UnknownData_000034[0x000004];   // 0x000034 (0x000004)
        UQuartzClockHandle*         ClockHandle;                    // 0x000038 (0x000008) [OutParam] [Default: 0x1326CE20]
        float                       ThirtySecondsNotesPerMinute;    // 0x000040 (0x000004) [Default: 2.10538e-27f]
    };

    struct UQuartzClockHandle___SetTicksPerSecond_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x1326CB70]
        FQuartzQuantizationBoundary QuantizationBoundary;           // 0x000008 (0x000020) [OutParam]
        OnQuartzCommandEventBP      Delegate;                       // 0x000028 (0x00000C) [OutParam]
        uint8                       UnknownData_000034[0x000004];   // 0x000034 (0x000004)
        UQuartzClockHandle*         ClockHandle;                    // 0x000038 (0x000008) [OutParam] [Default: 0x1326CE20]
        float                       TicksPerSecond;                 // 0x000040 (0x000004) [Default: 2.10538e-27f]
    };

    struct UQuartzClockHandle___StartClock_Params
    {
        UObject*            WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326CB70]
        UQuartzClockHandle* ClockHandle;        // 0x000008 (0x000008) [OutParam] [Default: 0x81C18DD00000031]
    };

    struct UQuartzClockHandle___StartOtherClock_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x1326CB70]
        FName                       OtherClockName;                 // 0x000008 (0x000004) [Default: FName(49) -> L""]
        uint8                       UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FQuartzQuantizationBoundary InQuantizationBoundary;         // 0x000010 (0x000020)
        OnQuartzCommandEventBP      InDelegate;                     // 0x000030 (0x00000C) [OutParam]
    };

    struct UQuartzClockHandle___StopClock_Params
    {
        UObject*            WorldContextObject;             // 0x000000 (0x000008) [Default: 0x1326CB70]
        bool                CancelPendingEvents;            // 0x000008 (0x000001) [Default: true]
        uint8               UnknownData_000009[0x000007];   // 0x000009 (0x000007)
        UQuartzClockHandle* ClockHandle;                    // 0x000010 (0x000008) [OutParam] [Default: 0x16FBC6D0]
    };

    struct UQuartzClockHandle___SubscribeToAllQuantizationEvents_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x1326CB70]
        OnQuartzMetronomeEventBP    OnQuantizationEvent;            // 0x000008 (0x00000C) [OutParam]
        uint8                       UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        UQuartzClockHandle*         ClockHandle;                    // 0x000018 (0x000008) [OutParam] [Default: 0x16FAF160]
    };

    struct UQuartzClockHandle___SubscribeToQuantizationEvent_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x1326CB70]
        EQuartzCommandQuantization  InQuantizationBoundary;         // 0x000008 (0x000001) [Default: EQuartzCommandQuantization(49)]
        uint8                       UnknownData_000009[0x000003];   // 0x000009 (0x000003)
        OnQuartzMetronomeEventBP    OnQuantizationEvent;            // 0x00000C (0x00000C) [OutParam]
        UQuartzClockHandle*         ClockHandle;                    // 0x000018 (0x000008) [OutParam] [Default: 0x16FAF160]
    };

    struct UQuartzClockHandle___UnsubscribeFromAllTimeDivisions_Params
    {
        UObject*            WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326CB70]
        UQuartzClockHandle* ClockHandle;        // 0x000008 (0x000008) [OutParam] [Default: 0x81C18DD00000031]
    };

    struct UQuartzClockHandle___UnsubscribeFromTimeDivision_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x1326CB70]
        EQuartzCommandQuantization  InQuantizationBoundary;         // 0x000008 (0x000001) [Default: EQuartzCommandQuantization(49)]
        uint8                       UnknownData_000009[0x000007];   // 0x000009 (0x000007)
        UQuartzClockHandle*         ClockHandle;                    // 0x000010 (0x000008) [OutParam] [Default: 0x16FBC6D0]
    };

    struct UQuartzSubsystem___CreateNewClock_Params
    {
        UObject*                WorldContextObject;             // 0x000000 (0x000008) [Default: 0x1326D080]
        FName                   ClockName;                      // 0x000008 (0x000004) [Default: FName(49) -> L""]
        uint8                   UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FQuartzClockSettings    InSettings;                     // 0x000010 (0x000020)
        bool                    bOverrideSettingsIfClockExists; // 0x000030 (0x000001) [Default: false]
        bool                    bUseAudioEngineClockManager;    // 0x000031 (0x000001) [Default: false]
        uint8                   UnknownData_000032[0x000006];   // 0x000032 (0x000006)
        UQuartzClockHandle*     ReturnValue;                    // 0x000038 (0x000008) [ReturnValue] [Default: 0x1326D340]
    };

    struct UQuartzSubsystem___DeleteClockByHandle_Params
    {
        UObject*            WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326D080]
        UQuartzClockHandle* InClockHandle;      // 0x000008 (0x000008) [OutParam] [Default: 0x71C18DD00000031]
    };

    struct UQuartzSubsystem___DeleteClockByName_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326D080]
        FName       ClockName;          // 0x000008 (0x000004) [Default: FName(49) -> L""]
    };

    struct UQuartzSubsystem___DoesClockExist_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326D080]
        FName       ClockName;          // 0x000008 (0x000004) [Default: FName(49) -> L""]
        bool        ReturnValue;        // 0x00000C (0x000001) [ReturnValue] [Default: true]
    };

    struct UQuartzSubsystem___GetAudioRenderThreadToGameThreadAverageLatency_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 2.10549e-27f]
    };

    struct UQuartzSubsystem___GetAudioRenderThreadToGameThreadMaxLatency_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 2.10549e-27f]
    };

    struct UQuartzSubsystem___GetAudioRenderThreadToGameThreadMinLatency_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 2.10549e-27f]
    };

    struct UQuartzSubsystem___GetCurrentClockTimestamp_Params
    {
        UObject*                    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326D080]
        FName                       InClockName;        // 0x000008 (0x000004) [OutParam] [Default: FName(49) -> L""]
        FQuartzTransportTimeStamp   ReturnValue;        // 0x00000C (0x000010) [ReturnValue]
    };

    struct UQuartzSubsystem___GetDurationOfQuantizationTypeInSeconds_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x1326D080]
        FName                       ClockName;                      // 0x000008 (0x000004) [Default: FName(49) -> L""]
        EQuartzCommandQuantization  QuantizationType;               // 0x00000C (0x000001) [OutParam] [Default: EQuartzCommandQuantization(221)]
        uint8                       UnknownData_00000D[0x000003];   // 0x00000D (0x000003)
        float                       Multiplier;                     // 0x000010 (0x000004) [Default: 4.06676e-25f]
        float                       ReturnValue;                    // 0x000014 (0x000004) [ReturnValue] [Default: 0f]
    };

    struct UQuartzSubsystem___GetEstimatedClockRunTime_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326D080]
        FName       InClockName;        // 0x000008 (0x000004) [OutParam] [Default: FName(49) -> L""]
        float       ReturnValue;        // 0x00000C (0x000004) [ReturnValue] [Default: 1.17434e-34f]
    };

    struct UQuartzSubsystem___GetGameThreadToAudioRenderThreadAverageLatency_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326D080]
        float       ReturnValue;        // 0x000008 (0x000004) [ReturnValue] [Default: 6.86636e-44f]
    };

    struct UQuartzSubsystem___GetGameThreadToAudioRenderThreadMaxLatency_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326D080]
        float       ReturnValue;        // 0x000008 (0x000004) [ReturnValue] [Default: 6.86636e-44f]
    };

    struct UQuartzSubsystem___GetGameThreadToAudioRenderThreadMinLatency_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326D080]
        float       ReturnValue;        // 0x000008 (0x000004) [ReturnValue] [Default: 6.86636e-44f]
    };

    struct UQuartzSubsystem___GetHandleForClock_Params
    {
        UObject*            WorldContextObject;             // 0x000000 (0x000008) [Default: 0x1326D080]
        FName               ClockName;                      // 0x000008 (0x000004) [Default: FName(49) -> L""]
        uint8               UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        UQuartzClockHandle* ReturnValue;                    // 0x000010 (0x000008) [ReturnValue] [Default: 0x16FBB870]
    };

    struct UQuartzSubsystem___GetRoundTripAverageLatency_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326D080]
        float       ReturnValue;        // 0x000008 (0x000004) [ReturnValue] [Default: 6.86636e-44f]
    };

    struct UQuartzSubsystem___GetRoundTripMaxLatency_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326D080]
        float       ReturnValue;        // 0x000008 (0x000004) [ReturnValue] [Default: 6.86636e-44f]
    };

    struct UQuartzSubsystem___GetRoundTripMinLatency_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326D080]
        float       ReturnValue;        // 0x000008 (0x000004) [ReturnValue] [Default: 6.86636e-44f]
    };

    struct UQuartzSubsystem___IsClockRunning_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x1326D080]
        FName       ClockName;          // 0x000008 (0x000004) [Default: FName(49) -> L""]
        bool        ReturnValue;        // 0x00000C (0x000001) [ReturnValue] [Default: true]
    };

    struct UQuartzSubsystem___IsQuartzEnabled_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UQuartzSubsystem___SetQuartzSubsystemTickableWhenPaused_Params
    {
        bool    bInTickableWhenPaused;  // 0x000000 (0x000001) [Default: true]
    };

    struct UScrubbedSound___GetPlayheadTime_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 2.10493e-27f]
    };

    struct UScrubbedSound___SetGrainDurationRange_Params
    {
        FVector2D   InGrainDurationRangeSeconds;    // 0x000000 (0x000010) [OutParam]
    };

    struct UScrubbedSound___SetIsScrubbing_Params
    {
        bool    bInIsScrubbing; // 0x000000 (0x000001) [Default: false]
    };

    struct UScrubbedSound___SetIsScrubbingWhileStationary_Params
    {
        bool    bInScrubWhileStationary;    // 0x000000 (0x000001) [Default: false]
    };

    struct UScrubbedSound___SetPlayheadTime_Params
    {
        float   InPlayheadTimeSeconds;  // 0x000000 (0x000004) [Default: 2.10493e-27f]
    };

    struct UScrubbedSound___SetSoundWave_Params
    {
        USoundWave* InSoundWave;    // 0x000000 (0x000008) [Default: 0x1326C500]
    };

    struct USubmixEffectDynamicsProcessorPreset___SetAudioBus_Params
    {
        UAudioBus*  AudioBus;   // 0x000000 (0x000008) [Default: 0x1326B8D0]
    };

    struct USubmixEffectDynamicsProcessorPreset___SetExternalSubmix_Params
    {
        USoundSubmix*   Submix; // 0x000000 (0x000008) [Default: 0x1326B8D0]
    };

    struct USubmixEffectDynamicsProcessorPreset___SetSettings_Params
    {
        FSubmixEffectDynamicsProcessorSettings  Settings;   // 0x000000 (0x000060) [OutParam]
    };

    struct USubmixEffectReverbPreset___SetSettings_Params
    {
        FSubmixEffectReverbSettings InSettings; // 0x000000 (0x000040) [OutParam]
    };

    struct USubmixEffectReverbPreset___SetSettingsWithReverbEffect_Params
    {
        UReverbEffect*  InReverbEffect; // 0x000000 (0x000008) [Default: 0x1326BF20]
        float           WetLevel;       // 0x000008 (0x000004) [Default: 6.86636e-44f]
        float           DryLevel;       // 0x00000C (0x000004) [Default: -5.27234e-31f]
    };

    struct USubmixEffectSubmixEQPreset___SetSettings_Params
    {
        FSubmixEffectSubmixEQSettings   InSettings; // 0x000000 (0x000010) [OutParam]
    };

    struct USynthComponent___AdjustVolume_Params
    {
        float               AdjustVolumeDuration;   // 0x000000 (0x000004) [Default: 2.10396e-27f]
        float               AdjustVolumeLevel;      // 0x000004 (0x000004) [Default: 0f]
        EAudioFaderCurve    FadeCurve;              // 0x000008 (0x000001) [Default: EAudioFaderCurve(49)]
    };

    struct USynthComponent___FadeIn_Params
    {
        float               FadeInDuration;     // 0x000000 (0x000004) [Default: 2.10396e-27f]
        float               FadeVolumeLevel;    // 0x000004 (0x000004) [Default: 0f]
        float               StartTime;          // 0x000008 (0x000004) [Default: 6.86636e-44f]
        EAudioFaderCurve    FadeCurve;          // 0x00000C (0x000001) [Default: EAudioFaderCurve(221)]
    };

    struct USynthComponent___FadeOut_Params
    {
        float               FadeOutDuration;    // 0x000000 (0x000004) [Default: 2.10396e-27f]
        float               FadeVolumeLevel;    // 0x000004 (0x000004) [Default: 0f]
        EAudioFaderCurve    FadeCurve;          // 0x000008 (0x000001) [Default: EAudioFaderCurve(49)]
    };

    struct USynthComponent___GetModulators_Params
    {
        EModulationDestination      Destination;                    // 0x000000 (0x000001) [Default: EModulationDestination(112)]
        uint8                       UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        TSet<USoundModulatorBase*>  ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct USynthComponent___IsPlaying_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct USynthComponent___SetAudioBusSendPostEffect_Params
    {
        UAudioBus*  AudioBus;           // 0x000000 (0x000008) [Default: 0x1326B170]
        float       AudioBusSendLevel;  // 0x000008 (0x000004) [Default: 6.86636e-44f]
    };

    struct USynthComponent___SetAudioBusSendPreEffect_Params
    {
        UAudioBus*  AudioBus;           // 0x000000 (0x000008) [Default: 0x1326B170]
        float       AudioBusSendLevel;  // 0x000008 (0x000004) [Default: 6.86636e-44f]
    };

    struct USynthComponent___SetLowPassFilterEnabled_Params
    {
        bool    InLowPassFilterEnabled; // 0x000000 (0x000001) [Default: true]
    };

    struct USynthComponent___SetLowPassFilterFrequency_Params
    {
        float   InLowPassFilterFrequency;   // 0x000000 (0x000004) [Default: 2.10396e-27f]
    };

    struct USynthComponent___SetModulationRouting_Params
    {
        TSet<USoundModulatorBase*>  Modulators;     // 0x000000 (0x000010) [OutParam]
        EModulationDestination      Destination;    // 0x000010 (0x000001) [Default: EModulationDestination(96)]
        EModulationRouting          RoutingMethod;  // 0x000011 (0x000001) [Default: EModulationRouting(200)]
    };

    struct USynthComponent___SetOutputToBusOnly_Params
    {
        bool    bInOutputToBusOnly; // 0x000000 (0x000001) [Default: true]
    };

    struct USynthComponent___SetSourceBusSendPostEffect_Params
    {
        USoundSourceBus*    SoundSourceBus;     // 0x000000 (0x000008) [Default: 0x1326B170]
        float               SourceBusSendLevel; // 0x000008 (0x000004) [Default: 6.86636e-44f]
    };

    struct USynthComponent___SetSourceBusSendPreEffect_Params
    {
        USoundSourceBus*    SoundSourceBus;     // 0x000000 (0x000008) [Default: 0x1326B170]
        float               SourceBusSendLevel; // 0x000008 (0x000004) [Default: 6.86636e-44f]
    };

    struct USynthComponent___SetSubmixSend_Params
    {
        USoundSubmixBase*   Submix;     // 0x000000 (0x000008) [Default: 0x1326B170]
        float               SendLevel;  // 0x000008 (0x000004) [Default: 6.86636e-44f]
    };

    struct USynthComponent___SetVolumeMultiplier_Params
    {
        float   VolumeMultiplier;   // 0x000000 (0x000004) [Default: 2.10396e-27f]
    };

} // namespace UE

