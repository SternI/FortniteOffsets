/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:36
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AuroraEntity/_Verse/VNI/AuroraEntityRuntime_Functions
 * ============================================================
 */

#include "AuroraEntityRuntime_Functions.hpp"

namespace UE
{

    UObject* U_SolarisSignatureFunctionOuter::VerseFunction_0(uint8 __verse_0xB2CDDD72_Argument[0x000010])
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraEntityRuntime.$SolarisSignatureFunctionOuter.VerseFunction_0");
    
        U_SolarisSignatureFunctionOuter___VerseFunction_0_Params Params{};
        Params.__verse_0xB2CDDD72_Argument[0x000010] = __verse_0xB2CDDD72_Argument[0x000010];
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    void U_SolarisSignatureFunctionOuter::VerseFunction_1(uint8 __verse_0xB2CDDD72_Argument[0x000010])
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraEntityRuntime.$SolarisSignatureFunctionOuter.VerseFunction_1");
    
        U_SolarisSignatureFunctionOuter___VerseFunction_1_Params Params{};
        Params.__verse_0xB2CDDD72_Argument[0x000010] = __verse_0xB2CDDD72_Argument[0x000010];
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UObject* U_SolarisSignatureFunctionOuter::VerseFunction_2(uint8 __verse_0xB2CDDD72_Argument[0x000010])
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraEntityRuntime.$SolarisSignatureFunctionOuter.VerseFunction_2");
    
        U_SolarisSignatureFunctionOuter___VerseFunction_2_Params Params{};
        Params.__verse_0xB2CDDD72_Argument[0x000010] = __verse_0xB2CDDD72_Argument[0x000010];
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    void U_SolarisSignatureFunctionOuter::VerseFunction_3(uint8 __verse_0xB2CDDD72_Argument[0x000010])
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraEntityRuntime.$SolarisSignatureFunctionOuter.VerseFunction_3");
    
        U_SolarisSignatureFunctionOuter___VerseFunction_3_Params Params{};
        Params.__verse_0xB2CDDD72_Argument[0x000010] = __verse_0xB2CDDD72_Argument[0x000010];
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void Uoffer_interactable_component::_Block()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraEntityRuntime.offer_interactable_component._Block");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Uoffer_interactable_component::_InitCDO(TOptional<UObject*> _ExprResult_0, TOptional<EVerseFalse> __verse_0x00000000__1, bool _ExprResult_1, TOptional<EVerseFalse> _ExprResultStack_2, UVerse_message* _ExprResultStack_3, TOptional<UVerse_message*> _ExprResult_4, TOptional<EVerseFalse> __verse_0x00000000__3, bool _ExprResult_5, TOptional<EVerseFalse> _ExprResultStack_6, double _ExprResult_7, TOptional<UObject*> _ExprResult_8, TOptional<EVerseFalse> __verse_0x00000000__5, bool _ExprResult_9, TOptional<EVerseFalse> _ExprResultStack_10, UVerse_message* _ExprResultStack_11, TOptional<UVerse_message*> _ExprResult_12, TOptional<EVerseFalse> __verse_0x00000000__7, bool _ExprResult_13, TOptional<EVerseFalse> _ExprResultStack_14, double _ExprResult_15)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraEntityRuntime.offer_interactable_component._InitCDO");
    
        Uoffer_interactable_component____InitCDO_Params Params{};
        Params._ExprResult_0 = _ExprResult_0;
        Params.__verse_0x00000000__1 = __verse_0x00000000__1;
        Params._ExprResult_1 = _ExprResult_1;
        Params._ExprResultStack_2 = _ExprResultStack_2;
        Params._ExprResultStack_3 = _ExprResultStack_3;
        Params._ExprResult_4 = _ExprResult_4;
        Params.__verse_0x00000000__3 = __verse_0x00000000__3;
        Params._ExprResult_5 = _ExprResult_5;
        Params._ExprResultStack_6 = _ExprResultStack_6;
        Params._ExprResult_7 = _ExprResult_7;
        Params._ExprResult_8 = _ExprResult_8;
        Params.__verse_0x00000000__5 = __verse_0x00000000__5;
        Params._ExprResult_9 = _ExprResult_9;
        Params._ExprResultStack_10 = _ExprResultStack_10;
        Params._ExprResultStack_11 = _ExprResultStack_11;
        Params._ExprResult_12 = _ExprResult_12;
        Params.__verse_0x00000000__7 = __verse_0x00000000__7;
        Params._ExprResult_13 = _ExprResult_13;
        Params._ExprResultStack_14 = _ExprResultStack_14;
        Params._ExprResult_15 = _ExprResult_15;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void Uoffer_interactable_component::_InitInstance()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraEntityRuntime.offer_interactable_component._InitInstance");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Uoffer_interactable_component::_L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RConvertPriceToFloat_L_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Rprice__dimension_R(Uprice_dimension* __verse_0xB2CDDD72_Argument, Uprice_vbucks* __verse_0xD8100EFB_VBucksPrice_2, Uprice_vbucks* _TEMP_0, TOptional<Uprice_vbucks*> _FallibleType_1, double _ExprResultStack_2, double __verse_0x9DCC4B98_float, double _ExprResultStack_3, double _ExprResultStack_4, double __verse_0x82BCEE78_type_7b0_2e000000_7d, Uprice_vbucks* __verse_0xD8100EFB_VBucksPrice_5, Uprice_vbucks* _TEMP_5, TOptional<Uprice_vbucks*> _FallibleType_6, double _ExprResultStack_7, double _ExprResultStack_8, double _ExprResultStack_9)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraEntityRuntime.offer_interactable_component._L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RConvertPriceToFloat_L_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Rprice__dimension_R");
    
        Uoffer_interactable_component____L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RConvertPriceToFloat_L_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Rprice__dimension_R_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
        Params.__verse_0xD8100EFB_VBucksPrice_2 = __verse_0xD8100EFB_VBucksPrice_2;
        Params._TEMP_0 = _TEMP_0;
        Params._FallibleType_1 = _FallibleType_1;
        Params._ExprResultStack_2 = _ExprResultStack_2;
        Params.__verse_0x9DCC4B98_float = __verse_0x9DCC4B98_float;
        Params._ExprResultStack_3 = _ExprResultStack_3;
        Params._ExprResultStack_4 = _ExprResultStack_4;
        Params.__verse_0x82BCEE78_type_7b0_2e000000_7d = __verse_0x82BCEE78_type_7b0_2e000000_7d;
        Params.__verse_0xD8100EFB_VBucksPrice_5 = __verse_0xD8100EFB_VBucksPrice_5;
        Params._TEMP_5 = _TEMP_5;
        Params._FallibleType_6 = _FallibleType_6;
        Params._ExprResultStack_7 = _ExprResultStack_7;
        Params._ExprResultStack_8 = _ExprResultStack_8;
        Params._ExprResultStack_9 = _ExprResultStack_9;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void Uoffer_interactable_component::_L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_ROnSucceed0_L_Nany_R_Nvoid(uint8 __verse_0xB2CDDD72_Argument[0x000010], EVerseTrue _InvokeSureResultDummy_0, USimulation_agent* _ExprResult_1, EVerseTrue _InvokeSureResultDummy_2, USimulation_agent* _ExprResult_3)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraEntityRuntime.offer_interactable_component._L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_ROnSucceed0_L_Nany_R_Nvoid");
    
        Uoffer_interactable_component____L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_ROnSucceed0_L_Nany_R_Nvoid_Params Params{};
        Params.__verse_0xB2CDDD72_Argument[0x000010] = __verse_0xB2CDDD72_Argument[0x000010];
        Params._InvokeSureResultDummy_0 = _InvokeSureResultDummy_0;
        Params._ExprResult_1 = _ExprResult_1;
        Params._InvokeSureResultDummy_2 = _InvokeSureResultDummy_2;
        Params._ExprResult_3 = _ExprResult_3;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void Uoffer_interactable_component::_L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_ROnSucceed_L_N_L_2fVerse_2eorg_2fSimulation_N_Ragent_R(USimulation_agent* __verse_0xB2CDDD72_Argument, USimulation_player* __verse_0xE5E3B371_Player_1, USimulation_player* _TEMP_0, TOptional<USimulation_player*> _FallibleType_1, UConcurrency_task* _AsyncTask_2, Ftuple_Lplayer_Moffer_R _ExprResult_3, Uoffer* _ExprResultStack_4, int64 _AsyncResult_5, USimulation_player* __verse_0xE5E3B371_Player_3, USimulation_player* _TEMP_6, TOptional<USimulation_player*> _FallibleType_7, UConcurrency_task* _AsyncTask_8, Ftuple_Lplayer_Moffer_R _ExprResult_9, Uoffer* _ExprResultStack_10, int64 _AsyncResult_11)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraEntityRuntime.offer_interactable_component._L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_ROnSucceed_L_N_L_2fVerse_2eorg_2fSimulation_N_Ragent_R");
    
        Uoffer_interactable_component____L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_ROnSucceed_L_N_L_2fVerse_2eorg_2fSimulation_N_Ragent_R_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
        Params.__verse_0xE5E3B371_Player_1 = __verse_0xE5E3B371_Player_1;
        Params._TEMP_0 = _TEMP_0;
        Params._FallibleType_1 = _FallibleType_1;
        Params._AsyncTask_2 = _AsyncTask_2;
        Params._ExprResult_3 = _ExprResult_3;
        Params._ExprResultStack_4 = _ExprResultStack_4;
        Params._AsyncResult_5 = _AsyncResult_5;
        Params.__verse_0xE5E3B371_Player_3 = __verse_0xE5E3B371_Player_3;
        Params._TEMP_6 = _TEMP_6;
        Params._FallibleType_7 = _FallibleType_7;
        Params._AsyncTask_8 = _AsyncTask_8;
        Params._ExprResult_9 = _ExprResult_9;
        Params._ExprResultStack_10 = _ExprResultStack_10;
        Params._AsyncResult_11 = _AsyncResult_11;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UVerse_message* Uoffer_interactable_component::_L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RPromptMessageFormat_L_Nfloat_M_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_R(Ftuple_Lfloat_Mmessage_R __verse_0xB2CDDD72_Argument, Ftuple_L_Kchar_M_Kchar_M_5b_Kchar_5dlocalizable__value_R _ExprResult_0, uint8 _ExprResult_1[0x000010], uint8 _ExprResult_2[0x000010], uint8 _ExprResult_3[0x000010], uint8 _ExprResult_4[0x000010], UVerse_localizable_float* _ExprResultStack_5, uint8 _ExprResult_6[0x000010], UVerse_localizable_message* _ExprResultStack_7, Ftuple_L_Kchar_M_Kchar_M_5b_Kchar_5dlocalizable__value_R _ExprResult_8, uint8 _ExprResult_9[0x000010], uint8 _ExprResult_10[0x000010], uint8 _ExprResult_11[0x000010], uint8 _ExprResult_12[0x000010], UVerse_localizable_float* _ExprResultStack_13, uint8 _ExprResult_14[0x000010], UVerse_localizable_message* _ExprResultStack_15)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraEntityRuntime.offer_interactable_component._L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RPromptMessageFormat_L_Nfloat_M_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_R");
    
        Uoffer_interactable_component____L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RPromptMessageFormat_L_Nfloat_M_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_R_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
        Params._ExprResult_0 = _ExprResult_0;
        Params._ExprResult_1[0x000010] = _ExprResult_1[0x000010];
        Params._ExprResult_2[0x000010] = _ExprResult_2[0x000010];
        Params._ExprResult_3[0x000010] = _ExprResult_3[0x000010];
        Params._ExprResult_4[0x000010] = _ExprResult_4[0x000010];
        Params._ExprResultStack_5 = _ExprResultStack_5;
        Params._ExprResult_6[0x000010] = _ExprResult_6[0x000010];
        Params._ExprResultStack_7 = _ExprResultStack_7;
        Params._ExprResult_8 = _ExprResult_8;
        Params._ExprResult_9[0x000010] = _ExprResult_9[0x000010];
        Params._ExprResult_10[0x000010] = _ExprResult_10[0x000010];
        Params._ExprResult_11[0x000010] = _ExprResult_11[0x000010];
        Params._ExprResult_12[0x000010] = _ExprResult_12[0x000010];
        Params._ExprResultStack_13 = _ExprResultStack_13;
        Params._ExprResult_14[0x000010] = _ExprResult_14[0x000010];
        Params._ExprResultStack_15 = _ExprResultStack_15;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    void Uoffer_interactable_component::_L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RRefreshPrompt(Ftuple_L_R __verse_0xB2CDDD72_Argument, EVerseTrue _InvokeSureResultDummy_0, Uoffer* _ExprResultStack_1, EVerseTrue _InvokeSureResultDummy_2, Ftuple_Lfloat_Mmessage_R _ExprResult_3, double _ExprResultStack_4, UVerse_message* _ExprResultStack_5, Uoffer* _ExprResultStack_6, EVerseTrue _InvokeSureResultDummy_7, Uoffer* _ExprResultStack_8, EVerseTrue _InvokeSureResultDummy_9, Ftuple_Lfloat_Mmessage_R _ExprResult_10, double _ExprResultStack_11, UVerse_message* _ExprResultStack_12, Uoffer* _ExprResultStack_13)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraEntityRuntime.offer_interactable_component._L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RRefreshPrompt");
    
        Uoffer_interactable_component____L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RRefreshPrompt_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
        Params._InvokeSureResultDummy_0 = _InvokeSureResultDummy_0;
        Params._ExprResultStack_1 = _ExprResultStack_1;
        Params._InvokeSureResultDummy_2 = _InvokeSureResultDummy_2;
        Params._ExprResult_3 = _ExprResult_3;
        Params._ExprResultStack_4 = _ExprResultStack_4;
        Params._ExprResultStack_5 = _ExprResultStack_5;
        Params._ExprResultStack_6 = _ExprResultStack_6;
        Params._InvokeSureResultDummy_7 = _InvokeSureResultDummy_7;
        Params._ExprResultStack_8 = _ExprResultStack_8;
        Params._InvokeSureResultDummy_9 = _InvokeSureResultDummy_9;
        Params._ExprResult_10 = _ExprResult_10;
        Params._ExprResultStack_11 = _ExprResultStack_11;
        Params._ExprResultStack_12 = _ExprResultStack_12;
        Params._ExprResultStack_13 = _ExprResultStack_13;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void Uoffer_interactable_component::_L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RUpdatePromptMessage_L_Nfloat_M_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_R(Ftuple_Lfloat_Mmessage_R __verse_0xB2CDDD72_Argument, UVerse_message* __verse_0x69D81F63_PromptMessage_2, Ftuple_Lfloat_Mmessage_R _ExprResult_0, TOptional<UVerse_message*> _ExprResultStack_1, TOptional<UVerse_message*> __verse_0xE072269F__Qmessage, TOptional<UVerse_message*> _ExprResult_2, UVerse_message* __verse_0x69D81F63_PromptMessage_4, Ftuple_Lfloat_Mmessage_R _ExprResult_3, TOptional<UVerse_message*> _ExprResultStack_4, TOptional<UVerse_message*> _ExprResult_5)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraEntityRuntime.offer_interactable_component._L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RUpdatePromptMessage_L_Nfloat_M_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_R");
    
        Uoffer_interactable_component____L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RUpdatePromptMessage_L_Nfloat_M_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_R_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
        Params.__verse_0x69D81F63_PromptMessage_2 = __verse_0x69D81F63_PromptMessage_2;
        Params._ExprResult_0 = _ExprResult_0;
        Params._ExprResultStack_1 = _ExprResultStack_1;
        Params.__verse_0xE072269F__Qmessage = __verse_0xE072269F__Qmessage;
        Params._ExprResult_2 = _ExprResult_2;
        Params.__verse_0x69D81F63_PromptMessage_4 = __verse_0x69D81F63_PromptMessage_4;
        Params._ExprResult_3 = _ExprResult_3;
        Params._ExprResultStack_4 = _ExprResultStack_4;
        Params._ExprResult_5 = _ExprResult_5;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void Uoffer_interactable_component::_L_2fVerse_2eorg_2fSceneGraph_2fcomponent_N_ROnBeginSimulation(Ftuple_L_R __verse_0xB2CDDD72_Argument, EVerseTrue _InvokeSureResultDummy_0, Ftuple_L_R _ExprResult_1, TOptional<UObject*> _ExprResultStack_2, TOptional<UObject*> __verse_0xAAF5E970__Qcancelable, TOptional<UObject*> _ExprResult_3, UObject* _ExprResultStack_4, uint8 _Callee_5[0x000010], EVerseTrue _InvokeSureResultDummy_6, Ftuple_L_R _ExprResult_7, EVerseTrue _InvokeSureResultDummy_8, Ftuple_L_R _ExprResult_9, TOptional<UObject*> _ExprResultStack_10, TOptional<UObject*> _ExprResult_11, UObject* _ExprResultStack_12, uint8 _Callee_13[0x000010], EVerseTrue _InvokeSureResultDummy_14, Ftuple_L_R _ExprResult_15)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraEntityRuntime.offer_interactable_component._L_2fVerse_2eorg_2fSceneGraph_2fcomponent_N_ROnBeginSimulation");
    
        Uoffer_interactable_component____L_2fVerse_2eorg_2fSceneGraph_2fcomponent_N_ROnBeginSimulation_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
        Params._InvokeSureResultDummy_0 = _InvokeSureResultDummy_0;
        Params._ExprResult_1 = _ExprResult_1;
        Params._ExprResultStack_2 = _ExprResultStack_2;
        Params.__verse_0xAAF5E970__Qcancelable = __verse_0xAAF5E970__Qcancelable;
        Params._ExprResult_3 = _ExprResult_3;
        Params._ExprResultStack_4 = _ExprResultStack_4;
        Params._Callee_5[0x000010] = _Callee_5[0x000010];
        Params._InvokeSureResultDummy_6 = _InvokeSureResultDummy_6;
        Params._ExprResult_7 = _ExprResult_7;
        Params._InvokeSureResultDummy_8 = _InvokeSureResultDummy_8;
        Params._ExprResult_9 = _ExprResult_9;
        Params._ExprResultStack_10 = _ExprResultStack_10;
        Params._ExprResult_11 = _ExprResult_11;
        Params._ExprResultStack_12 = _ExprResultStack_12;
        Params._Callee_13[0x000010] = _Callee_13[0x000010];
        Params._InvokeSureResultDummy_14 = _InvokeSureResultDummy_14;
        Params._ExprResult_15 = _ExprResult_15;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    TOptional<EVerseTrue> Uoffer_interactable_component::_L_2fVerse_2eorg_2fSceneGraph_2finteractable__component_N_RCanInteract_L_N_L_2fVerse_2eorg_2fSimulation_N_Ragent_R(USimulation_agent* __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraEntityRuntime.offer_interactable_component._L_2fVerse_2eorg_2fSceneGraph_2finteractable__component_N_RCanInteract_L_N_L_2fVerse_2eorg_2fSimulation_N_Ragent_R");
    
        Uoffer_interactable_component____L_2fVerse_2eorg_2fSceneGraph_2finteractable__component_N_RCanInteract_L_N_L_2fVerse_2eorg_2fSimulation_N_Ragent_R_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    TOptional<UVerse_message*> Uoffer_interactable_component::_L_2fVerse_2eorg_2fSceneGraph_2finteractable__component_N_RInteractMessage_L_N_L_2fVerse_2eorg_2fSimulation_N_Ragent_R(USimulation_agent* __verse_0xB2CDDD72_Argument, EVerseFalse _ExprResult_0, UVerse_message* __verse_0x72B10F24_Message_1, TOptional<UVerse_message*> _ExprResultStack_1, TOptional<UVerse_message*> _ExprResultStack_2, EVerseFalse _ExprResult_3, UVerse_message* __verse_0x72B10F24_Message_3, TOptional<UVerse_message*> _ExprResultStack_4, TOptional<UVerse_message*> _ExprResultStack_5)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraEntityRuntime.offer_interactable_component._L_2fVerse_2eorg_2fSceneGraph_2finteractable__component_N_RInteractMessage_L_N_L_2fVerse_2eorg_2fSimulation_N_Ragent_R");
    
        Uoffer_interactable_component____L_2fVerse_2eorg_2fSceneGraph_2finteractable__component_N_RInteractMessage_L_N_L_2fVerse_2eorg_2fSimulation_N_Ragent_R_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
        Params._ExprResult_0 = _ExprResult_0;
        Params.__verse_0x72B10F24_Message_1 = __verse_0x72B10F24_Message_1;
        Params._ExprResultStack_1 = _ExprResultStack_1;
        Params._ExprResultStack_2 = _ExprResultStack_2;
        Params._ExprResult_3 = _ExprResult_3;
        Params.__verse_0x72B10F24_Message_3 = __verse_0x72B10F24_Message_3;
        Params._ExprResultStack_4 = _ExprResultStack_4;
        Params._ExprResultStack_5 = _ExprResultStack_5;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

} // namespace UE

