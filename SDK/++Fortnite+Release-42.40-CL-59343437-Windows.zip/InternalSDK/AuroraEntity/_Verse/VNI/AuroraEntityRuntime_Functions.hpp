/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:36
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AuroraEntity/_Verse/VNI/AuroraEntityRuntime_Functions
 * ============================================================
 */

#include "AuroraEntityRuntime.hpp"

namespace UE
{

    struct U_SolarisSignatureFunctionOuter___VerseFunction_0_Params
    {
        uint8       __verse_0xB2CDDD72_Argument[0x000010];  // 0x000000 (0x000010)
        UObject*    RetVal;                                 // 0x000010 (0x000008) [ReturnValue] [Default: 0x7FEDD95A3D20]
    };

    struct U_SolarisSignatureFunctionOuter___VerseFunction_1_Params
    {
        uint8   __verse_0xB2CDDD72_Argument[0x000010];  // 0x000000 (0x000010)
    };

    struct U_SolarisSignatureFunctionOuter___VerseFunction_2_Params
    {
        uint8       __verse_0xB2CDDD72_Argument[0x000010];  // 0x000000 (0x000010)
        UObject*    RetVal;                                 // 0x000010 (0x000008) [ReturnValue] [Default: 0x7FEDD95A3D20]
    };

    struct U_SolarisSignatureFunctionOuter___VerseFunction_3_Params
    {
        uint8   __verse_0xB2CDDD72_Argument[0x000010];  // 0x000000 (0x000010)
    };

    struct Uoffer_interactable_component____InitCDO_Params
    {
        TOptional<UObject*>         _ExprResult_0;                  // 0x000000 (0x000008)
        TOptional<EVerseFalse>      __verse_0x00000000__1;          // 0x000008 (0x000002)
        bool                        _ExprResult_1;                  // 0x00000A (0x000001) [Default: true]
        TOptional<EVerseFalse>      _ExprResultStack_2;             // 0x00000B (0x000002)
        uint8                       UnknownData_00000D[0x000003];   // 0x00000D (0x000003)
        UVerse_message*             _ExprResultStack_3;             // 0x000010 (0x000008) [Default: 0x7FEDD95A32A0]
        TOptional<UVerse_message*>  _ExprResult_4;                  // 0x000018 (0x000008)
        TOptional<EVerseFalse>      __verse_0x00000000__3;          // 0x000020 (0x000002)
        bool                        _ExprResult_5;                  // 0x000022 (0x000001) [Default: true]
        TOptional<EVerseFalse>      _ExprResultStack_6;             // 0x000023 (0x000002)
        uint8                       UnknownData_000025[0x000003];   // 0x000025 (0x000003)
        double                      _ExprResult_7;                  // 0x000028 (0x000008) [Default: 0]
        TOptional<UObject*>         _ExprResult_8;                  // 0x000030 (0x000008)
        TOptional<EVerseFalse>      __verse_0x00000000__5;          // 0x000038 (0x000002)
        bool                        _ExprResult_9;                  // 0x00003A (0x000001) [Default: false]
        TOptional<EVerseFalse>      _ExprResultStack_10;            // 0x00003B (0x000002)
        uint8                       UnknownData_00003D[0x000003];   // 0x00003D (0x000003)
        UVerse_message*             _ExprResultStack_11;            // 0x000040 (0x000008) [Default: nullptr]
        TOptional<UVerse_message*>  _ExprResult_12;                 // 0x000048 (0x000008)
        TOptional<EVerseFalse>      __verse_0x00000000__7;          // 0x000050 (0x000002)
        bool                        _ExprResult_13;                 // 0x000052 (0x000001) [Default: false]
        TOptional<EVerseFalse>      _ExprResultStack_14;            // 0x000053 (0x000002)
        uint8                       UnknownData_000055[0x000003];   // 0x000055 (0x000003)
        double                      _ExprResult_15;                 // 0x000058 (0x000008) [Default: 0]
    };

    struct Uoffer_interactable_component____L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RConvertPriceToFloat_L_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Rprice__dimension_R_Params
    {
        Uprice_dimension*           __verse_0xB2CDDD72_Argument;                // 0x000000 (0x000008) [Default: 0x14908390]
        Uprice_vbucks*              __verse_0xD8100EFB_VBucksPrice_2;           // 0x000008 (0x000008) [Default: 0x524D1CDD00280031]
        Uprice_vbucks*              _TEMP_0;                                    // 0x000010 (0x000008) [Default: 0x7FEDD95A32A0]
        TOptional<Uprice_vbucks*>   _FallibleType_1;                            // 0x000018 (0x000008)
        double                      _ExprResultStack_2;                         // 0x000020 (0x000008) [Default: 1.59801e-314]
        double                      __verse_0x9DCC4B98_float;                   // 0x000028 (0x000008) [Default: 0]
        double                      _ExprResultStack_3;                         // 0x000030 (0x000008) [Default: 0]
        double                      _ExprResultStack_4;                         // 0x000038 (0x000008) [Default: 0]
        double                      __verse_0x82BCEE78_type_7b0_2e000000_7d;    // 0x000040 (0x000008) [Default: 0]
        Uprice_vbucks*              __verse_0xD8100EFB_VBucksPrice_5;           // 0x000048 (0x000008) [Default: nullptr]
        Uprice_vbucks*              _TEMP_5;                                    // 0x000050 (0x000008) [Default: nullptr]
        TOptional<Uprice_vbucks*>   _FallibleType_6;                            // 0x000058 (0x000008)
        double                      _ExprResultStack_7;                         // 0x000060 (0x000008) [Default: 0]
        double                      _ExprResultStack_8;                         // 0x000068 (0x000008) [Default: 0]
        double                      _ExprResultStack_9;                         // 0x000070 (0x000008) [Default: 0]
    };

    struct Uoffer_interactable_component____L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_ROnSucceed0_L_Nany_R_Nvoid_Params
    {
        uint8               __verse_0xB2CDDD72_Argument[0x000010];  // 0x000000 (0x000010)
        EVerseTrue          _InvokeSureResultDummy_0;               // 0x000010 (0x000001) [Default: EVerseTrue(160)]
        uint8               UnknownData_000011[0x000007];           // 0x000011 (0x000007)
        USimulation_agent*  _ExprResult_1;                          // 0x000018 (0x000008) [Default: 0x7FE99A40C190]
        EVerseTrue          _InvokeSureResultDummy_2;               // 0x000020 (0x000001) [Default: EVerseTrue(188)]
        uint8               UnknownData_000021[0x000007];           // 0x000021 (0x000007)
        USimulation_agent*  _ExprResult_3;                          // 0x000028 (0x000008) [Default: nullptr]
    };

    struct Uoffer_interactable_component____L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_ROnSucceed_L_N_L_2fVerse_2eorg_2fSimulation_N_Ragent_R_Params
    {
        USimulation_agent*              __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000008) [Default: 0x14908390]
        USimulation_player*             __verse_0xE5E3B371_Player_1;    // 0x000008 (0x000008) [Default: 0x524D1CDD00280031]
        USimulation_player*             _TEMP_0;                        // 0x000010 (0x000008) [Default: 0x7FEDD95A32A0]
        TOptional<USimulation_player*>  _FallibleType_1;                // 0x000018 (0x000008)
        UConcurrency_task*              _AsyncTask_2;                   // 0x000020 (0x000008) [Default: 0xC0C909BC]
        Ftuple_Lplayer_Moffer_R         _ExprResult_3;                  // 0x000028 (0x000010)
        Uoffer*                         _ExprResultStack_4;             // 0x000038 (0x000008) [Default: nullptr]
        int64                           _AsyncResult_5;                 // 0x000040 (0x000008) [Default: 0ll]
        USimulation_player*             __verse_0xE5E3B371_Player_3;    // 0x000048 (0x000008) [Default: nullptr]
        USimulation_player*             _TEMP_6;                        // 0x000050 (0x000008) [Default: nullptr]
        TOptional<USimulation_player*>  _FallibleType_7;                // 0x000058 (0x000008)
        UConcurrency_task*              _AsyncTask_8;                   // 0x000060 (0x000008) [Default: nullptr]
        Ftuple_Lplayer_Moffer_R         _ExprResult_9;                  // 0x000068 (0x000010)
        Uoffer*                         _ExprResultStack_10;            // 0x000078 (0x000008) [Default: 0x1]
        int64                           _AsyncResult_11;                // 0x000080 (0x000008) [Default: 0ll]
    };

    struct Uoffer_interactable_component____L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RPromptMessageFormat_L_Nfloat_M_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_R_Params
    {
        Ftuple_Lfloat_Mmessage_R                                    __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000010)
        UVerse_message*                                             RetVal;                         // 0x000010 (0x000008) [ReturnValue] [Default: 0x7FEDD95A32A0]
        Ftuple_L_Kchar_M_Kchar_M_5b_Kchar_5dlocalizable__value_R    _ExprResult_0;                  // 0x000018 (0x000030)
        uint8                                                       _ExprResult_1[0x000010];        // 0x000048 (0x000010)
        uint8                                                       _ExprResult_2[0x000010];        // 0x000058 (0x000010)
        uint8                                                       _ExprResult_3[0x000010];        // 0x000068 (0x000010)
        uint8                                                       _ExprResult_4[0x000010];        // 0x000078 (0x000010)
        UVerse_localizable_float*                                   _ExprResultStack_5;             // 0x000088 (0x000008) [Default: nullptr]
        uint8                                                       _ExprResult_6[0x000010];        // 0x000090 (0x000010)
        UVerse_localizable_message*                                 _ExprResultStack_7;             // 0x0000A0 (0x000008) [Default: 0x7FEB189839A0]
        Ftuple_L_Kchar_M_Kchar_M_5b_Kchar_5dlocalizable__value_R    _ExprResult_8;                  // 0x0000A8 (0x000030)
        uint8                                                       _ExprResult_9[0x000010];        // 0x0000D8 (0x000010)
        uint8                                                       _ExprResult_10[0x000010];       // 0x0000E8 (0x000010)
        uint8                                                       _ExprResult_11[0x000010];       // 0x0000F8 (0x000010)
        uint8                                                       _ExprResult_12[0x000010];       // 0x000108 (0x000010)
        UVerse_localizable_float*                                   _ExprResultStack_13;            // 0x000118 (0x000008) [Default: 0x7FE9D8E834E0]
        uint8                                                       _ExprResult_14[0x000010];       // 0x000120 (0x000010)
        UVerse_localizable_message*                                 _ExprResultStack_15;            // 0x000130 (0x000008) [Default: 0x3F8000003ED2E686]
    };

    struct Uoffer_interactable_component____L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RRefreshPrompt_Params
    {
        Ftuple_L_R                  __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000001)
        EVerseTrue                  _InvokeSureResultDummy_0;       // 0x000001 (0x000001) [Default: EVerseTrue(131)]
        uint8                       UnknownData_000002[0x000006];   // 0x000002 (0x000006)
        Uoffer*                     _ExprResultStack_1;             // 0x000008 (0x000008) [Default: 0x524D1CDD00280031]
        EVerseTrue                  _InvokeSureResultDummy_2;       // 0x000010 (0x000001) [Default: EVerseTrue(160)]
        uint8                       UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        Ftuple_Lfloat_Mmessage_R    _ExprResult_3;                  // 0x000018 (0x000010)
        double                      _ExprResultStack_4;             // 0x000028 (0x000008) [Default: 0]
        UVerse_message*             _ExprResultStack_5;             // 0x000030 (0x000008) [Default: nullptr]
        Uoffer*                     _ExprResultStack_6;             // 0x000038 (0x000008) [Default: nullptr]
        EVerseTrue                  _InvokeSureResultDummy_7;       // 0x000040 (0x000001) [Default: EVerseTrue(0)]
        uint8                       UnknownData_000041[0x000007];   // 0x000041 (0x000007)
        Uoffer*                     _ExprResultStack_8;             // 0x000048 (0x000008) [Default: nullptr]
        EVerseTrue                  _InvokeSureResultDummy_9;       // 0x000050 (0x000001) [Default: EVerseTrue(0)]
        uint8                       UnknownData_000051[0x000007];   // 0x000051 (0x000007)
        Ftuple_Lfloat_Mmessage_R    _ExprResult_10;                 // 0x000058 (0x000010)
        double                      _ExprResultStack_11;            // 0x000068 (0x000008) [Default: 0]
        UVerse_message*             _ExprResultStack_12;            // 0x000070 (0x000008) [Default: nullptr]
        Uoffer*                     _ExprResultStack_13;            // 0x000078 (0x000008) [Default: 0x1]
    };

    struct Uoffer_interactable_component____L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RUpdatePromptMessage_L_Nfloat_M_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_R_Params
    {
        Ftuple_Lfloat_Mmessage_R    __verse_0xB2CDDD72_Argument;        // 0x000000 (0x000010)
        UVerse_message*             __verse_0x69D81F63_PromptMessage_2; // 0x000010 (0x000008) [Default: 0x7FEDD95A32A0]
        Ftuple_Lfloat_Mmessage_R    _ExprResult_0;                      // 0x000018 (0x000010)
        TOptional<UVerse_message*>  _ExprResultStack_1;                 // 0x000028 (0x000008)
        TOptional<UVerse_message*>  __verse_0xE072269F__Qmessage;       // 0x000030 (0x000008)
        TOptional<UVerse_message*>  _ExprResult_2;                      // 0x000038 (0x000008)
        UVerse_message*             __verse_0x69D81F63_PromptMessage_4; // 0x000040 (0x000008) [Default: nullptr]
        Ftuple_Lfloat_Mmessage_R    _ExprResult_3;                      // 0x000048 (0x000010)
        TOptional<UVerse_message*>  _ExprResultStack_4;                 // 0x000058 (0x000008)
        TOptional<UVerse_message*>  _ExprResult_5;                      // 0x000060 (0x000008)
    };

    struct Uoffer_interactable_component____L_2fVerse_2eorg_2fSceneGraph_2fcomponent_N_ROnBeginSimulation_Params
    {
        Ftuple_L_R          __verse_0xB2CDDD72_Argument;        // 0x000000 (0x000001)
        EVerseTrue          _InvokeSureResultDummy_0;           // 0x000001 (0x000001) [Default: EVerseTrue(131)]
        Ftuple_L_R          _ExprResult_1;                      // 0x000002 (0x000001)
        uint8               UnknownData_000003[0x000005];       // 0x000003 (0x000005)
        TOptional<UObject*> _ExprResultStack_2;                 // 0x000008 (0x000008)
        TOptional<UObject*> __verse_0xAAF5E970__Qcancelable;    // 0x000010 (0x000008)
        TOptional<UObject*> _ExprResult_3;                      // 0x000018 (0x000008)
        UObject*            _ExprResultStack_4;                 // 0x000020 (0x000008) [Default: 0xC0C909BC]
        uint8               _Callee_5[0x000010];                // 0x000028 (0x000010)
        EVerseTrue          _InvokeSureResultDummy_6;           // 0x000038 (0x000001) [Default: EVerseTrue(0)]
        Ftuple_L_R          _ExprResult_7;                      // 0x000039 (0x000001)
        EVerseTrue          _InvokeSureResultDummy_8;           // 0x00003A (0x000001) [Default: EVerseTrue(0)]
        Ftuple_L_R          _ExprResult_9;                      // 0x00003B (0x000001)
        uint8               UnknownData_00003C[0x000004];       // 0x00003C (0x000004)
        TOptional<UObject*> _ExprResultStack_10;                // 0x000040 (0x000008)
        TOptional<UObject*> _ExprResult_11;                     // 0x000048 (0x000008)
        UObject*            _ExprResultStack_12;                // 0x000050 (0x000008) [Default: nullptr]
        uint8               _Callee_13[0x000010];               // 0x000058 (0x000010)
        EVerseTrue          _InvokeSureResultDummy_14;          // 0x000068 (0x000001) [Default: EVerseTrue(0)]
        Ftuple_L_R          _ExprResult_15;                     // 0x000069 (0x000001)
    };

    struct Uoffer_interactable_component____L_2fVerse_2eorg_2fSceneGraph_2finteractable__component_N_RCanInteract_L_N_L_2fVerse_2eorg_2fSimulation_N_Ragent_R_Params
    {
        USimulation_agent*      __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000008) [Default: 0x14908390]
        TOptional<EVerseTrue>   RetVal;                         // 0x000008 (0x000002) [ReturnValue]
    };

    struct Uoffer_interactable_component____L_2fVerse_2eorg_2fSceneGraph_2finteractable__component_N_RInteractMessage_L_N_L_2fVerse_2eorg_2fSimulation_N_Ragent_R_Params
    {
        USimulation_agent*          __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000008) [Default: 0x14908390]
        TOptional<UVerse_message*>  RetVal;                         // 0x000008 (0x000008) [ReturnValue]
        EVerseFalse                 _ExprResult_0;                  // 0x000010 (0x000001) [Default: EVerseFalse(160)]
        uint8                       UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        UVerse_message*             __verse_0x72B10F24_Message_1;   // 0x000018 (0x000008) [Default: 0x7FE99A40C190]
        TOptional<UVerse_message*>  _ExprResultStack_1;             // 0x000020 (0x000008)
        TOptional<UVerse_message*>  _ExprResultStack_2;             // 0x000028 (0x000008)
        EVerseFalse                 _ExprResult_3;                  // 0x000030 (0x000001) [Default: EVerseFalse(0)]
        uint8                       UnknownData_000031[0x000007];   // 0x000031 (0x000007)
        UVerse_message*             __verse_0x72B10F24_Message_3;   // 0x000038 (0x000008) [Default: nullptr]
        TOptional<UVerse_message*>  _ExprResultStack_4;             // 0x000040 (0x000008)
        TOptional<UVerse_message*>  _ExprResultStack_5;             // 0x000048 (0x000008)
    };

} // namespace UE

