/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:36
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AuroraEntity/_Verse/VNI/AuroraEntityRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class U_SolarisSignatureFunctionOuter : public UObject
    {
    public:
    
    public: // Functions
        UObject*    VerseFunction_0(uint8 __verse_0xB2CDDD72_Argument[0x000010]); // 0x000545D2 [Delegate | HasOutParms]
        void        VerseFunction_1(uint8 __verse_0xB2CDDD72_Argument[0x000010]); // 0x000545D2 [Delegate]
        UObject*    VerseFunction_2(uint8 __verse_0xB2CDDD72_Argument[0x000010]); // 0x000545D2 [Delegate | HasOutParms]
        void        VerseFunction_3(uint8 __verse_0xB2CDDD72_Argument[0x000010]); // 0x000545D2 [Delegate]
    };
    // Size: 0x0000E0 (0x000030)
    class alignas(0x8) Uoffer_interactable_component : public Uinteractable_component
    {
    public:
        Uoffer*                     __verse_0xF9A030B2_Offer;                   // 0x0000B0 (0x000008) [Default: nullptr]
        TOptional<UObject*>         __verse_0x5E39C0B3_SucceededEventHandle;    // 0x0000B8 (0x000008)
        UVerse_message*             __verse_0x3F72DB13_FallbackPromptMessage;   // 0x0000C0 (0x000008) [Default: 0x7FE9D92A36C0]
        TOptional<UVerse_message*>  __verse_0xEF41CBA0_OutputMessage;           // 0x0000C8 (0x000008)
        double                      __verse_0xBB25E312_OfferFloatPrice;         // 0x0000D0 (0x000008) [Default: 0]
        uint8                       UnknownData_0000D8[0x000008];               // 0x0000D8 (0x000008)
    
    public: // Functions
        void                        _Block(); // 0x000545D2 [FUNC_None]
        void                        _InitCDO(TOptional<UObject*> _ExprResult_0, TOptional<EVerseFalse> __verse_0x00000000__1, bool _ExprResult_1, TOptional<EVerseFalse> _ExprResultStack_2, UVerse_message* _ExprResultStack_3, TOptional<UVerse_message*> _ExprResult_4, TOptional<EVerseFalse> __verse_0x00000000__3, bool _ExprResult_5, TOptional<EVerseFalse> _ExprResultStack_6, double _ExprResult_7, TOptional<UObject*> _ExprResult_8, TOptional<EVerseFalse> __verse_0x00000000__5, bool _ExprResult_9, TOptional<EVerseFalse> _ExprResultStack_10, UVerse_message* _ExprResultStack_11, TOptional<UVerse_message*> _ExprResult_12, TOptional<EVerseFalse> __verse_0x00000000__7, bool _ExprResult_13, TOptional<EVerseFalse> _ExprResultStack_14, double _ExprResult_15); // 0x000545D2 [HasDefaults]
        void                        _InitInstance(); // 0x000545D2 [FUNC_None]
        void                        _L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RConvertPriceToFloat_L_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Rprice__dimension_R(Uprice_dimension* __verse_0xB2CDDD72_Argument, Uprice_vbucks* __verse_0xD8100EFB_VBucksPrice_2, Uprice_vbucks* _TEMP_0, TOptional<Uprice_vbucks*> _FallibleType_1, double _ExprResultStack_2, double __verse_0x9DCC4B98_float, double _ExprResultStack_3, double _ExprResultStack_4, double __verse_0x82BCEE78_type_7b0_2e000000_7d, Uprice_vbucks* __verse_0xD8100EFB_VBucksPrice_5, Uprice_vbucks* _TEMP_5, TOptional<Uprice_vbucks*> _FallibleType_6, double _ExprResultStack_7, double _ExprResultStack_8, double _ExprResultStack_9); // 0x000545D2 [Public | HasDefaults | BlueprintCallable]
        void                        _L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_ROnSucceed0_L_Nany_R_Nvoid(uint8 __verse_0xB2CDDD72_Argument[0x000010], EVerseTrue _InvokeSureResultDummy_0, USimulation_agent* _ExprResult_1, EVerseTrue _InvokeSureResultDummy_2, USimulation_agent* _ExprResult_3); // 0x000545D2 [Public | HasDefaults | BlueprintCallable]
        void                        _L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_ROnSucceed_L_N_L_2fVerse_2eorg_2fSimulation_N_Ragent_R(USimulation_agent* __verse_0xB2CDDD72_Argument, USimulation_player* __verse_0xE5E3B371_Player_1, USimulation_player* _TEMP_0, TOptional<USimulation_player*> _FallibleType_1, UConcurrency_task* _AsyncTask_2, Ftuple_Lplayer_Moffer_R _ExprResult_3, Uoffer* _ExprResultStack_4, int64 _AsyncResult_5, USimulation_player* __verse_0xE5E3B371_Player_3, USimulation_player* _TEMP_6, TOptional<USimulation_player*> _FallibleType_7, UConcurrency_task* _AsyncTask_8, Ftuple_Lplayer_Moffer_R _ExprResult_9, Uoffer* _ExprResultStack_10, int64 _AsyncResult_11); // 0x000545D2 [Public | HasDefaults | BlueprintCallable]
        UVerse_message*             _L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RPromptMessageFormat_L_Nfloat_M_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_R(Ftuple_Lfloat_Mmessage_R __verse_0xB2CDDD72_Argument, Ftuple_L_Kchar_M_Kchar_M_5b_Kchar_5dlocalizable__value_R _ExprResult_0, uint8 _ExprResult_1[0x000010], uint8 _ExprResult_2[0x000010], uint8 _ExprResult_3[0x000010], uint8 _ExprResult_4[0x000010], UVerse_localizable_float* _ExprResultStack_5, uint8 _ExprResult_6[0x000010], UVerse_localizable_message* _ExprResultStack_7, Ftuple_L_Kchar_M_Kchar_M_5b_Kchar_5dlocalizable__value_R _ExprResult_8, uint8 _ExprResult_9[0x000010], uint8 _ExprResult_10[0x000010], uint8 _ExprResult_11[0x000010], uint8 _ExprResult_12[0x000010], UVerse_localizable_float* _ExprResultStack_13, uint8 _ExprResult_14[0x000010], UVerse_localizable_message* _ExprResultStack_15); // 0x000545D2 [Public | HasOutParms | HasDefaults | BlueprintCallable]
        void                        _L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RRefreshPrompt(Ftuple_L_R __verse_0xB2CDDD72_Argument, EVerseTrue _InvokeSureResultDummy_0, Uoffer* _ExprResultStack_1, EVerseTrue _InvokeSureResultDummy_2, Ftuple_Lfloat_Mmessage_R _ExprResult_3, double _ExprResultStack_4, UVerse_message* _ExprResultStack_5, Uoffer* _ExprResultStack_6, EVerseTrue _InvokeSureResultDummy_7, Uoffer* _ExprResultStack_8, EVerseTrue _InvokeSureResultDummy_9, Ftuple_Lfloat_Mmessage_R _ExprResult_10, double _ExprResultStack_11, UVerse_message* _ExprResultStack_12, Uoffer* _ExprResultStack_13); // 0x000545D2 [Public | HasDefaults | BlueprintCallable]
        void                        _L_2fUnrealEngine_2ecom_2fMarketplace_2foffer__interactable__component_N_RUpdatePromptMessage_L_Nfloat_M_N_L_2fVerse_2eorg_2fVerse_N_Rmessage_R(Ftuple_Lfloat_Mmessage_R __verse_0xB2CDDD72_Argument, UVerse_message* __verse_0x69D81F63_PromptMessage_2, Ftuple_Lfloat_Mmessage_R _ExprResult_0, TOptional<UVerse_message*> _ExprResultStack_1, TOptional<UVerse_message*> __verse_0xE072269F__Qmessage, TOptional<UVerse_message*> _ExprResult_2, UVerse_message* __verse_0x69D81F63_PromptMessage_4, Ftuple_Lfloat_Mmessage_R _ExprResult_3, TOptional<UVerse_message*> _ExprResultStack_4, TOptional<UVerse_message*> _ExprResult_5); // 0x000545D2 [Public | HasDefaults | BlueprintCallable]
        void                        _L_2fVerse_2eorg_2fSceneGraph_2fcomponent_N_ROnBeginSimulation(Ftuple_L_R __verse_0xB2CDDD72_Argument, EVerseTrue _InvokeSureResultDummy_0, Ftuple_L_R _ExprResult_1, TOptional<UObject*> _ExprResultStack_2, TOptional<UObject*> __verse_0xAAF5E970__Qcancelable, TOptional<UObject*> _ExprResult_3, UObject* _ExprResultStack_4, uint8 _Callee_5[0x000010], EVerseTrue _InvokeSureResultDummy_6, Ftuple_L_R _ExprResult_7, EVerseTrue _InvokeSureResultDummy_8, Ftuple_L_R _ExprResult_9, TOptional<UObject*> _ExprResultStack_10, TOptional<UObject*> _ExprResult_11, UObject* _ExprResultStack_12, uint8 _Callee_13[0x000010], EVerseTrue _InvokeSureResultDummy_14, Ftuple_L_R _ExprResult_15); // 0x000545D2 [Public | HasDefaults | BlueprintCallable]
        TOptional<EVerseTrue>       _L_2fVerse_2eorg_2fSceneGraph_2finteractable__component_N_RCanInteract_L_N_L_2fVerse_2eorg_2fSimulation_N_Ragent_R(USimulation_agent* __verse_0xB2CDDD72_Argument); // 0x10D9A70E [Native | Public | HasOutParms | BlueprintCallable]
        TOptional<UVerse_message*>  _L_2fVerse_2eorg_2fSceneGraph_2finteractable__component_N_RInteractMessage_L_N_L_2fVerse_2eorg_2fSimulation_N_Ragent_R(USimulation_agent* __verse_0xB2CDDD72_Argument, EVerseFalse _ExprResult_0, UVerse_message* __verse_0x72B10F24_Message_1, TOptional<UVerse_message*> _ExprResultStack_1, TOptional<UVerse_message*> _ExprResultStack_2, EVerseFalse _ExprResult_3, UVerse_message* __verse_0x72B10F24_Message_3, TOptional<UVerse_message*> _ExprResultStack_4, TOptional<UVerse_message*> _ExprResultStack_5); // 0x000545D2 [Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) Ftuple_L_Kchar_M_Kchar_M_5b_Kchar_5dlocalizable__value_R
    {
        uint8   __verse_0x18E3F084_Elem0[0x000010]; // 0x000000 (0x000010)
        uint8   __verse_0x7D844C3C_Elem1[0x000010]; // 0x000010 (0x000010)
        uint8   __verse_0x932BF92E_Elem2[0x000010]; // 0x000020 (0x000010)
    };
    // Size: 0x000001 (0x000001)
    struct Ftuple_L_R
    {
        uint8   _StructPaddingDummy;    // 0x000000 (0x000001)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) Ftuple_Lfloat_Mmessage_R
    {
        double          __verse_0x18E3F084_Elem0;   // 0x000000 (0x000008)
        UVerse_message* __verse_0x7D844C3C_Elem1;   // 0x000008 (0x000008)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) Ftuple_Lplayer_Moffer_R
    {
        USimulation_player* __verse_0x18E3F084_Elem0;   // 0x000000 (0x000008)
        Uoffer*             __verse_0x7D844C3C_Elem1;   // 0x000008 (0x000008)
    };
}

