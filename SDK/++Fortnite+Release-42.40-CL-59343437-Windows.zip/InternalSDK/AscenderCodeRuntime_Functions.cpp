/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AscenderCodeRuntime_Functions
 * ============================================================
 */

#include "AscenderCodeRuntime_Functions.hpp"

namespace UE
{

    void AFortAscenderZipline::ApplyStructureDamage(ABuildingSMActor* BuildingActor, AActor* DamageSource)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.ApplyStructureDamage");
    
        AFortAscenderZipline___ApplyStructureDamage_Params Params{};
        Params.BuildingActor = BuildingActor;
        Params.DamageSource = DamageSource;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AFortAscenderZipline::BP_HandlePlayerStartedUsingHandle(AFortPlayerPawn* player)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.BP_HandlePlayerStartedUsingHandle");
    
        AFortAscenderZipline___BP_HandlePlayerStartedUsingHandle_Params Params{};
        Params.player = player;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AFortAscenderZipline::BP_HandlePlayerStoppedUsingHandle(AFortPlayerPawn* player)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.BP_HandlePlayerStoppedUsingHandle");
    
        AFortAscenderZipline___BP_HandlePlayerStoppedUsingHandle_Params Params{};
        Params.player = player;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AFortAscenderZipline::BP_HandleStartedLoweringCable()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.BP_HandleStartedLoweringCable");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AFortAscenderZipline::BP_HandleStartedLoweringHandle()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.BP_HandleStartedLoweringHandle");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AFortAscenderZipline::BP_HandleStoppedLoweringCable()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.BP_HandleStoppedLoweringCable");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AFortAscenderZipline::BP_HandleStoppedLoweringHandle()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.BP_HandleStoppedLoweringHandle");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AFortAscenderZipline::BP_HandleUpdatedLoweringCable()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.BP_HandleUpdatedLoweringCable");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AFortAscenderZipline::BP_HandleUpdatedLoweringHandle()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.BP_HandleUpdatedLoweringHandle");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AFortAscenderZipline::BP_OnVolumeReady()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.BP_OnVolumeReady");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AFortAscenderZipline::FindNewFloor()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.FindNewFloor");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    UPrimitiveComponent* AFortAscenderZipline::GetHandleComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.GetHandleComponent");
    
        AFortAscenderZipline___GetHandleComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UPrimitiveComponent* AFortAscenderZipline::GetInteractComponentOverride(AFortPlayerPawn* InteractingPawn, UPrimitiveComponent* InteractComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.GetInteractComponentOverride");
    
        AFortAscenderZipline___GetInteractComponentOverride_Params Params{};
        Params.InteractingPawn = InteractingPawn;
        Params.InteractComponent = InteractComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    AFortPlayerPawn* AFortAscenderZipline::GetPawnUsingHandle()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.GetPawnUsingHandle");
    
        AFortAscenderZipline___GetPawnUsingHandle_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UPrimitiveComponent* AFortAscenderZipline::GetTopComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.GetTopComponent");
    
        AFortAscenderZipline___GetTopComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void AFortAscenderZipline::HandleFloorActorDestroyed(AActor* Actor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.HandleFloorActorDestroyed");
    
        AFortAscenderZipline___HandleFloorActorDestroyed_Params Params{};
        Params.Actor = Actor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AFortAscenderZipline::HandleFloorActorHealthChanged()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.HandleFloorActorHealthChanged");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AFortAscenderZipline::HandlePawnUsingHandleDied(AFortPawn* DeadPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.HandlePawnUsingHandleDied");
    
        AFortAscenderZipline___HandlePawnUsingHandleDied_Params Params{};
        Params.DeadPawn = DeadPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool AFortAscenderZipline::IsUsingHandle(AFortPawn* PawnToCheck)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.IsUsingHandle");
    
        AFortAscenderZipline___IsUsingHandle_Params Params{};
        Params.PawnToCheck = PawnToCheck;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void AFortAscenderZipline::OnRep_InitialSplineEndLocation()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.OnRep_InitialSplineEndLocation");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AFortAscenderZipline::OnRep_PawnUsingHandle()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.OnRep_PawnUsingHandle");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AFortAscenderZipline::OnRep_TargetSplineEndLocation()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.OnRep_TargetSplineEndLocation");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AFortAscenderZipline::OnSpawningFromSaveFinish()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.OnSpawningFromSaveFinish");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AFortAscenderZipline::SetupAscender(bool bFromConstruction, bool bFromReplication)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.SetupAscender");
    
        AFortAscenderZipline___SetupAscender_Params Params{};
        Params.bFromConstruction = bFromConstruction;
        Params.bFromReplication = bFromReplication;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AFortAscenderZipline::SetupEventForSpatialGameplayVolume()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortAscenderZipline.SetupEventForSpatialGameplayVolume");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortCheatManager_AscenderZipline::RemoveAscenders(bool bRemoveAscendersOn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortCheatManager_AscenderZipline.RemoveAscenders");
    
        UFortCheatManager_AscenderZipline___RemoveAscenders_Params Params{};
        Params.bRemoveAscendersOn = bRemoveAscendersOn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UAnimMontage* UFortPawnComponent_AscenderMontageProvider::GetSuitableMontage(bool bAscending)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AscenderCodeRuntime.FortPawnComponent_AscenderMontageProvider.GetSuitableMontage");
    
        UFortPawnComponent_AscenderMontageProvider___GetSuitableMontage_Params Params{};
        Params.bAscending = bAscending;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

} // namespace UE

