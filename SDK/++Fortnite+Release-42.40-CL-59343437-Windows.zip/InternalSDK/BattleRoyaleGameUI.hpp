/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BattleRoyaleGameUI
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000088 (0x000058)
    class alignas(0x8) UBattleRoyaleGameUISubsystem : public UGameInstanceSubsystem
    {
    public:
        MULTI_INLINE_DELEGATE(OnBoolCVarChanged)    OnSquadListPlacementCVarChanged;    // 0x000030 (0x000010)
        MULTI_INLINE_DELEGATE(OnBoolCVarChanged)    OnNewHudEnabledCVarChanged;         // 0x000040 (0x000010)
        MULTI_INLINE_DELEGATE(OnBoolCVarChanged)    OnNewQuickbarEnabledCVarChanged;    // 0x000050 (0x000010)
        MULTI_INLINE_DELEGATE(OnBoolCVarChanged)    OnKillFeedPlacementCVarChanged;     // 0x000060 (0x000010)
        uint8                                       UnknownData_000070[0x000018];       // 0x000070 (0x000018)
    };
    // Size: 0x000080 (0x000008)
    class UBattleRoyaleQuickbarViewModel : public UFortPerUserViewModel
    {
    public:
        bool    bIsSwitchModeUnboundMessageEnabled; // 0x000078 (0x000001) [Default: false]
        uint8   UnknownData_000079[0x000007];       // 0x000079 (0x000007)
    
    public: // Functions
        void    HandleSimpleBuildToggled(bool bIsEnabled); // 0x0804BE30 [Final | Native | Private]
    };
    // Size: 0x000110 (0x000000)
    class UInstituteChirpEquippedItemViewModel : public UHUDEquippedItemViewModel
    {
    public:
    
    public: // Functions
        EFortRarity GetRarity(); // 0x10DC16DE [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000098 (0x000030)
    class alignas(0x8) UInstituteChirpGadgetFuelViewModel : public UMVVMViewModelBase
    {
    public:
        EFortFuelGadgetVisualType   FortFuelGadgetVisualType;       // 0x000068 (0x000001) [Default: EFortFuelGadgetVisualType(0)]
        uint8                       UnknownData_000069[0x000003];   // 0x000069 (0x000003)
        float                       FuelChargeCount;                // 0x00006C (0x000004) [Default: 0f]
        float                       FuelPercentage;                 // 0x000070 (0x000004) [Default: 0f]
        TWeakObjectPtr<UFortItem>   Item;                           // 0x000074 (0x000008) [Default: nullptr]
        uint8                       UnknownData_00007C[0x00001C];   // 0x00007C (0x00001C)
    
    public: // Functions
        void    InitializePlayerController(APlayerController* OwningPlayerController); // 0x0804BFC4 [Final | Native | Public | BlueprintCallable]
        void    SetFortItem(UFortItem* InItem); // 0x0804C136 [Final | Native | Public | BlueprintCallable]
    };
    // Size: 0x0000A0 (0x000010)
    class alignas(0x8) UInstituteChirpQuickbarSlotViewModel : public UHUDQuickbarSlotViewModel
    {
    public:
        UInstituteChirpGadgetFuelViewModel* FuelViewModel;                  // 0x000090 (0x000008) [Default: 0x7FE838B1B3A8]
        EFortQuickBars                      QuickBarType;                   // 0x000098 (0x000001) [Default: EFortQuickBars(0)]
        uint8                               UnknownData_000099[0x000007];   // 0x000099 (0x000007)
    
    public: // Functions
        int32       GetNumberOfSlotsTaken(); // 0x0211783C [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EFortRarity GetRarity(); // 0x0211787C [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void        InitializeWithType(APlayerController* InPlayerController, EFortQuickBars InQuickBarType, int32 InSlot); // 0x0804C2A8 [Final | Native | Public | BlueprintCallable]
    };
    // Size: 0x000088 (0x000010)
    class alignas(0x4) UQuickbarGizmoSlotVM : public UFortPerUserViewModel
    {
    public:
        int32   SlotIndex;                      // 0x000078 (0x000004) [Default: -1]
        bool    bIsVisible;                     // 0x00007C (0x000001) [Default: false]
        bool    bIsSwapped;                     // 0x00007D (0x000001) [Default: false]
        uint8   UnknownData_00007E[0x00000A];   // 0x00007E (0x00000A)
    
    public: // Functions
        void    HandleQuickbarContentsChanged(EFortQuickBars QuickBarIndex, TArray<int32>& ChangedSlots); // 0x0804C668 [Final | Native | Protected | HasOutParms]
        void    HandleQuickbarFullUpdate(EFortQuickBars QuickBarIndex); // 0x0804C900 [Final | Native | Protected]
        void    HandleQuickBarSlotFocusChanged(EFortQuickBars QuickBarIndex, int32 FocusedSlotIndex); // 0x0804CA6A [Final | Native | Protected]
    };
}

