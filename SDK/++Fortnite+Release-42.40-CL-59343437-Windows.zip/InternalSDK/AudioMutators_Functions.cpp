/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:07
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioMutators_Functions
 * ============================================================
 */

#include "AudioMutators_Functions.hpp"

namespace UE
{

    void UAudioMutatorsSubsystem::AddMutator(UAudioMutatorBase* Mutator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMutators.AudioMutatorsSubsystem.AddMutator");
    
        UAudioMutatorsSubsystem___AddMutator_Params Params{};
        Params.Mutator = Mutator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMutatorsSubsystem::RemoveMutator(UAudioMutatorBase* Mutator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMutators.AudioMutatorsSubsystem.RemoveMutator");
    
        UAudioMutatorsSubsystem___RemoveMutator_Params Params{};
        Params.Mutator = Mutator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMutatorsSubsystem::ReplaceMutator(UAudioMutatorBase* Mutator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMutators.AudioMutatorsSubsystem.ReplaceMutator");
    
        UAudioMutatorsSubsystem___ReplaceMutator_Params Params{};
        Params.Mutator = Mutator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

