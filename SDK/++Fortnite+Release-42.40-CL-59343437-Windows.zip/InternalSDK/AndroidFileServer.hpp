/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AndroidFileServer
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class UAndroidFileServerBPLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static TEnumAsByte<EAFSActiveType> IsFileServerRunning(); // 0x0C984634 [Final | Native | Static | Public | BlueprintCallable]
        static bool                        StartFileServer(bool bUSB, bool bNetwork, int32 Port); // 0x07ED1618 [Final | Native | Static | Public | BlueprintCallable]
        static bool                        StopFileServer(bool bUSB, bool bNetwork); // 0x07ED199C [Final | Native | Static | Public | BlueprintCallable]
    };
}

