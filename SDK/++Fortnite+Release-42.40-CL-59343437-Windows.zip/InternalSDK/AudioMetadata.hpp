/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioMetadata
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000050 (0x000020)
    class alignas(0x8) UAudioMetadataDeveloperSettings : public UDeveloperSettings
    {
    public:
        FAudioMetadataModulationSettings    ModulationSettings; // 0x000030 (0x000010)
        FAudioMetadataSubmixSettings        SubmixSettings;     // 0x000040 (0x000010)
    };
    // Size: 0x0000B0 (0x000080)
    class alignas(0x8) UAudioMetadataSubsystem : public UAudioEngineSubsystem
    {
    public:
        void**  VTable_000030;                  // 0x000030 (0x000008) VTable [12 slots] -> 0x134DC130
        uint8   UnknownData_000038[0x000078];   // 0x000038 (0x000078)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAudioMetadataModulationSettings
    {
        USoundControlBus*   ControlBusLicensedAudioMuteAll;     // 0x000000 (0x000008)
        USoundControlBus*   ControlBusLicensedAudioMuteOthers;  // 0x000008 (0x000008)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAudioMetadataSubmixSettings
    {
        USoundSubmix*   LicensedAudioSubmix;    // 0x000000 (0x000008) [Default: nullptr]
        USoundSubmix*   PostPartySubmix;        // 0x000008 (0x000008) [Default: nullptr]
    };
}

