/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:37
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BikeKid/Mutators/FortAthenaMutator_BikeKid
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0002E8 (0x000000)
    class AFortAthenaMutator_BikeKid_C : public AFortAthenaMutator_BikeKid
    {
    public:
    };
}

