/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:04
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BasicQuest
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class IBasicQuest : public IQuest
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class IBasicQuestDefinition : public IQuestDefinition
    {
    public:
    };
    // Size: 0x000090 (0x000068)
    class alignas(0x8) UQuestObjectiveDefinitionBase : public UObject
    {
    public:
        void**                      VTable_000028;          // 0x000028 (0x000008) VTable [7 slots] -> 0x137C4B60
        FText                       DisplayName;            // 0x000030 (0x000010)
        FText                       Description;            // 0x000040 (0x000010)
        FText                       ShortDescription;       // 0x000050 (0x000010)
        TSoftObjectPtr<UTexture2D>  Icon;                   // 0x000060 (0x000020) [Default: nullptr]
        FString                     ObjectiveTemplateId;    // 0x000080 (0x000010) [Default: L""]
    };
    // Size: 0x0000B0 (0x000088)
    class alignas(0x8) UQuestObjectiveInstance : public UObject
    {
    public:
        void**                                      VTable_000028;                  // 0x000028 (0x000008) VTable [105 slots] -> 0x137C4E20
        uint8                                       UnknownData_000030[0x000058];   // 0x000030 (0x000058)
        TScriptInterface<IQuestObjectiveDefinition> OwningDefinition;               // 0x000088 (0x000010)
        TScriptInterface<IQuest>                    OwningQuest;                    // 0x000098 (0x000010)
        uint8                                       UnknownData_0000A8[0x000008];   // 0x0000A8 (0x000008)
    };
    // Size: 0x000080 (0x000058)
    class alignas(0x8) UQuestRewardDefinitionBase : public UObject
    {
    public:
        void**                      VTable_000028;      // 0x000028 (0x000008) VTable [7 slots] -> 0x137C5130
        FText                       DisplayName;        // 0x000030 (0x000010)
        FText                       Description;        // 0x000040 (0x000010)
        FText                       ShortDescription;   // 0x000050 (0x000010)
        TSoftObjectPtr<UTexture2D>  Icon;               // 0x000060 (0x000020) [Default: nullptr]
    };
    // Size: 0x0000C0 (0x000098)
    class alignas(0x8) UQuestViewTest_BasicQuest : public UObject
    {
    public:
        void**  VTable_000028;                  // 0x000028 (0x000008) VTable [37 slots] -> 0x137C4600
        uint8   UnknownData_000030[0x000090];   // 0x000030 (0x000090)
    };
    // Size: 0x0000C0 (0x000098)
    class alignas(0x8) UQuestViewTest_DirtyMarkSpyQuest : public UObject
    {
    public:
        void**  VTable_000028;                  // 0x000028 (0x000008) VTable [37 slots] -> 0x137C4600
        uint8   UnknownData_000030[0x000090];   // 0x000030 (0x000090)
    };
    // Size: 0x000030 (0x000008)
    class alignas(0x8) UQuestViewTest_FieldProbeHost : public UObject
    {
    public:
        UObject*    ProbeField; // 0x000028 (0x000008) [Default: nullptr]
    };
    // Size: 0x000088 (0x000060)
    class alignas(0x8) UVerseQuestObjective : public UObject
    {
    public:
        void**  VTable_000028;                  // 0x000028 (0x000008) VTable [107 slots] -> 0x137C5450
        uint8   UnknownData_000030[0x000058];   // 0x000030 (0x000058)
    };
    // Size: 0x000070 (0x000048)
    class alignas(0x8) UVerseQuestReward : public UObject
    {
    public:
        void**  VTable_000028;                  // 0x000028 (0x000008) VTable [11 slots] -> 0x137C5750
        uint8   UnknownData_000030[0x000040];   // 0x000030 (0x000040)
    };
    // Size: 0x000090 (0x000070)
    struct alignas(0x8) FBasicQuestView : public FQuestView
    {
        TArray<FInstancedStruct>    ObjectiveStates;    // 0x000020 (0x000010)
        FText                       DisplayName;        // 0x000030 (0x000010)
        FText                       Description;        // 0x000040 (0x000010)
        FText                       ShortDescription;   // 0x000050 (0x000010)
        TSoftObjectPtr<UObject>     Icon;               // 0x000060 (0x000020) [Default: 0x377BF772]
        TArray<FInstancedStruct>    Rewards;            // 0x000080 (0x000010)
    };
    // Size: 0x000028 (0x000008)
    struct FQuestViewTest_AddReferencedObjectsSpyView : public FQuestView
    {
        uint8   UnknownData_000020[0x000008];   // 0x000020 (0x000008)
    };
    // Size: 0x000028 (0x000008)
    struct alignas(0x8) FQuestViewTest_RefHolderView : public FQuestView
    {
        UObject*    HeldRef;    // 0x000020 (0x000008) [Default: nullptr]
    };
    // Size: 0x000078 (0x000008)
    struct FQuestViewTest_UpdateObjectiveSpyView : public FQuestObjectiveView
    {
        uint8   UnknownData_000070[0x000008];   // 0x000070 (0x000008)
    };
    // Size: 0x000098 (0x000008)
    struct alignas(0x4) FQuestViewTest_UpdateSpyView : public FBasicQuestView
    {
        int32   UpdateQuestViewCallCount;       // 0x000090 (0x000004) [Default: 0]
        uint8   UnknownData_000094[0x000004];   // 0x000094 (0x000004)
    };
}

