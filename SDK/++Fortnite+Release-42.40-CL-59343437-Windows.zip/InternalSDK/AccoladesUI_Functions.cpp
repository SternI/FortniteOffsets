/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AccoladesUI_Functions
 * ============================================================
 */

#include "AccoladesUI_Functions.hpp"

namespace UE
{

    void UAthenaAccoladeListEntryWidget::SetCount(int32 Count)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AccoladesUI.AthenaAccoladeListEntryWidget.SetCount");
    
        UAthenaAccoladeListEntryWidget___SetCount_Params Params{};
        Params.Count = Count;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAthenaAccoladeListEntryWidget::SetIcon(UFortAccoladeItemDefinition* ItemDef)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AccoladesUI.AthenaAccoladeListEntryWidget.SetIcon");
    
        UAthenaAccoladeListEntryWidget___SetIcon_Params Params{};
        Params.ItemDef = ItemDef;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAthenaAccoladeListEntryWidget::SetIconImage(TSoftObjectPtr<UTexture2D>& IconImage, EFortAccoladeType AccoladeType, EFortAccoladeTierType AccoladeTier)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AccoladesUI.AthenaAccoladeListEntryWidget.SetIconImage");
    
        UAthenaAccoladeListEntryWidget___SetIconImage_Params Params{};
        Params.IconImage = IconImage;
        Params.AccoladeType = AccoladeType;
        Params.AccoladeTier = AccoladeTier;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        IconImage = Params.IconImage;
    }

    void UAthenaAccoladeListEntryWidget::SetJustCompleted(bool bJustCompleted)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AccoladesUI.AthenaAccoladeListEntryWidget.SetJustCompleted");
    
        UAthenaAccoladeListEntryWidget___SetJustCompleted_Params Params{};
        Params.bJustCompleted = bJustCompleted;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAthenaAccoladeListEntryWidget::SetSource(FText& SourceText)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AccoladesUI.AthenaAccoladeListEntryWidget.SetSource");
    
        UAthenaAccoladeListEntryWidget___SetSource_Params Params{};
        Params.SourceText = SourceText;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SourceText = Params.SourceText;
    }

    void UAthenaAccoladeListEntryWidget::SetTitle(FText& TitleText)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AccoladesUI.AthenaAccoladeListEntryWidget.SetTitle");
    
        UAthenaAccoladeListEntryWidget___SetTitle_Params Params{};
        Params.TitleText = TitleText;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        TitleText = Params.TitleText;
    }

    void UAthenaAccoladeListWidget::PopulateWidget()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AccoladesUI.AthenaAccoladeListWidget.PopulateWidget");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

} // namespace UE

