/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArcadeMinigamesRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000138 (0x000070)
    class alignas(0x8) UFortControllerComponent_ArcadeMinigame : public UFortControllerComponent
    {
    public:
        MULTI_INLINE_DELEGATE(ArcadeMinigameIsInSessionUpdated) OnArcadeMinigameIsInSessionUpdated;         // 0x0000C8 (0x000010)
        UInputMappingContext*                                   ArcadeInputMappingContext;                  // 0x0000D8 (0x000008) [Default: nullptr]
        UInputMappingContext*                                   ArcadeInputMappingContext_Switch;           // 0x0000E0 (0x000008) [Default: nullptr]
        UInputMappingContext*                                   DefaultInputMappingContextToSuppress;       // 0x0000E8 (0x000008) [Default: nullptr]
        int32                                                   DefaultInputMappingContextRestorePriority;  // 0x0000F0 (0x000004) [Default: 1001]
        int32                                                   ArcadeInputMappingPriority;                 // 0x0000F4 (0x000004) [Default: 10]
        UInputAction*                                           ExitInputAction;                            // 0x0000F8 (0x000008) [Default: nullptr]
        UDynamicUIScene*                                        MobileControlOverlayScene;                  // 0x000100 (0x000008) [Default: nullptr]
        bool                                                    bIsInSession;                               // 0x000108 (0x000001) [Default: false]
        uint8                                                   UnknownData_000109[0x00000F];               // 0x000109 (0x00000F)
        UDynamicUIScene*                                        ActiveScene;                                // 0x000118 (0x000008) [Default: nullptr]
        UDynamicUIScene*                                        ActiveMobileOverlayScene;                   // 0x000120 (0x000008) [Default: nullptr]
        UInputMappingContext*                                   ActiveInputMappingContext;                  // 0x000128 (0x000008) [Default: nullptr]
        uint8                                                   UnknownData_000130[0x000008];               // 0x000130 (0x000008)
    
    public: // Functions
        void                                        BeginSession(UDynamicUIScene* Scene); // 0x07EE1FD8 [Final | BlueprintAuthorityOnly | Native | Public | BlueprintCallable]
        void                                        ClientStartLocalArcade(UDynamicUIScene* Scene); // 0x0648D208 [Net | NetReliable | Native | Event | Protected | NetClient]
        void                                        ClientStopLocalArcade(); // 0x0F28FDD2 [Net | NetReliable | Native | Event | Protected | NetClient]
        void                                        EndSession(); // 0x10C0FA7A [Final | BlueprintAuthorityOnly | Native | Public | BlueprintCallable]
        static UFortControllerComponent_ArcadeMinigame*    GetArcadeMinigameComponentForPlayer(APlayerController* PlayerController); // 0x07EE2DA6 [Final | Native | Static | Public | BlueprintCallable]
        bool                                        IsInSession(); // 0x10262830 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                                        OnPawnDBNOStateChanged(AFortPawn* FortPawn, bool bInIsDBNO); // 0x07EE2F14 [Final | Native | Protected]
        void                                        ServerRequestEndSession(); // 0x0E6F04AC [Net | NetReliable | Native | Event | Public | NetServer]
    };
}

