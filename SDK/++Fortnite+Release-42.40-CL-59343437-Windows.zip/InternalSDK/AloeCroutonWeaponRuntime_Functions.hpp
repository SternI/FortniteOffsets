/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AloeCroutonWeaponRuntime_Functions
 * ============================================================
 */

#include "AloeCroutonWeaponRuntime.hpp"

namespace UE
{

    struct UFortChargingSet_AloeCrouton___GetCooldownDuration_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.38381e-26f]
    };

    struct UFortChargingSet_AloeCrouton___GetCooldownRemaining_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.38381e-26f]
    };

    struct UFortChargingSet_AloeCrouton___OnRep_Charge_Params
    {
        FFortGameplayAttributeData  OldValue;   // 0x000000 (0x000028) [OutParam]
    };

    struct UFortCosmeticStatObject_AloeCroutonCharge___HandleChargeCountChanged_Params
    {
        float                                   OldChargeCount;     // 0x000000 (0x000004) [Default: 1.38395e-26f]
        float                                   NewChargeCount;     // 0x000004 (0x000004) [Default: 0f]
        TWeakObjectPtr<AFortPlayerController>   PlayerController;   // 0x000008 (0x000008) [Default: 0x9D5E18DD00000031]
    };

} // namespace UE

