/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AccoladesRuntime_Functions
 * ============================================================
 */

#include "AccoladesRuntime_Functions.hpp"

namespace UE
{

    void UFortCheatManager_Accolades::ResetAccoladeData()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AccoladesRuntime.FortCheatManager_Accolades.ResetAccoladeData");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortCheatManager_Accolades::TriggerAccolade(FString AccoladeName, int32 TimesToTrigger)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AccoladesRuntime.FortCheatManager_Accolades.TriggerAccolade");
    
        UFortCheatManager_Accolades___TriggerAccolade_Params Params{};
        Params.AccoladeName = AccoladeName;
        Params.TimesToTrigger = TimesToTrigger;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortControllerComponent_AccoladeCollection::ClientNotifyRestored(EPersistenceFrameworkResult Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AccoladesRuntime.FortControllerComponent_AccoladeCollection.ClientNotifyRestored");
    
        UFortControllerComponent_AccoladeCollection___ClientNotifyRestored_Params Params{};
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortControllerComponent_AccoladeCollection::ClientResetAccoladeData()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AccoladesRuntime.FortControllerComponent_AccoladeCollection.ClientResetAccoladeData");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortControllerComponent_AccoladeCollection::HandleOnCurrentPlaylistLoaded(FName PlaylistName, FGameplayTagContainer& PlaylistContextTags)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AccoladesRuntime.FortControllerComponent_AccoladeCollection.HandleOnCurrentPlaylistLoaded");
    
        UFortControllerComponent_AccoladeCollection___HandleOnCurrentPlaylistLoaded_Params Params{};
        Params.PlaylistName = PlaylistName;
        Params.PlaylistContextTags = PlaylistContextTags;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PlaylistContextTags = Params.PlaylistContextTags;
    }

    void UFortControllerComponent_AccoladeCollection::HandlePlayerProfileInitialized()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AccoladesRuntime.FortControllerComponent_AccoladeCollection.HandlePlayerProfileInitialized");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortControllerComponent_AccoladeCollection::OnRep_PinnedAccoladeName(FName OldPinnedAccoladeName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AccoladesRuntime.FortControllerComponent_AccoladeCollection.OnRep_PinnedAccoladeName");
    
        UFortControllerComponent_AccoladeCollection___OnRep_PinnedAccoladeName_Params Params{};
        Params.OldPinnedAccoladeName = OldPinnedAccoladeName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortControllerComponent_AccoladeCollection::ServerMarkAccoladesAsSeen(TArray<FName> AccoladeNames)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AccoladesRuntime.FortControllerComponent_AccoladeCollection.ServerMarkAccoladesAsSeen");
    
        UFortControllerComponent_AccoladeCollection___ServerMarkAccoladesAsSeen_Params Params{};
        Params.AccoladeNames = AccoladeNames;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortControllerComponent_AccoladeCollection::ServerPinAccolade(FName AccoladeName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AccoladesRuntime.FortControllerComponent_AccoladeCollection.ServerPinAccolade");
    
        UFortControllerComponent_AccoladeCollection___ServerPinAccolade_Params Params{};
        Params.AccoladeName = AccoladeName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

