/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AVCodecsCoreRHI_Functions
 * ============================================================
 */

#include "AVCodecsCoreRHI_Functions.hpp"

namespace UE
{

    void USimpleAudioEncoder::Close()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleAudioEncoder.Close");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    ESimpleAudioCodec USimpleAudioEncoder::GetCodec()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleAudioEncoder.GetCodec");
    
        USimpleAudioEncoder___GetCodec_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FSimpleAudioEncoderConfig USimpleAudioEncoder::GetConfig()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleAudioEncoder.GetConfig");
    
        USimpleAudioEncoder___GetConfig_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool USimpleAudioEncoder::IsAsync()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleAudioEncoder.IsAsync");
    
        USimpleAudioEncoder___IsAsync_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool USimpleAudioEncoder::IsOpen()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleAudioEncoder.IsOpen");
    
        USimpleAudioEncoder___IsOpen_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool USimpleAudioEncoder::Open(ESimpleAudioCodec Codec, FSimpleAudioEncoderConfig Config, bool bAsynchronous)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleAudioEncoder.Open");
    
        USimpleAudioEncoder___Open_Params Params{};
        Params.Codec = Codec;
        Params.Config = Config;
        Params.bAsynchronous = bAsynchronous;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool USimpleAudioEncoder::ReceivePacket(FSimpleAudioPacket& OutPacket)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleAudioEncoder.ReceivePacket");
    
        USimpleAudioEncoder___ReceivePacket_Params Params{};
        Params.OutPacket = OutPacket;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutPacket = Params.OutPacket;
    
        return Params.ReturnValue;
    }

    void USimpleAudioEncoder::ReceivePackets(TArray<FSimpleAudioPacket>& OutPackets)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleAudioEncoder.ReceivePackets");
    
        USimpleAudioEncoder___ReceivePackets_Params Params{};
        Params.OutPackets = OutPackets;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutPackets = Params.OutPackets;
    }

    bool USimpleAudioEncoder::SendFrameFloat(TArray<float>& Resource, double Timestamp, int32 NumSamples, float SampleDuration)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleAudioEncoder.SendFrameFloat");
    
        USimpleAudioEncoder___SendFrameFloat_Params Params{};
        Params.Resource = Resource;
        Params.Timestamp = Timestamp;
        Params.NumSamples = NumSamples;
        Params.SampleDuration = SampleDuration;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Resource = Params.Resource;
    
        return Params.ReturnValue;
    }

    void USimpleAudioEncoder::SetConfig(FSimpleAudioEncoderConfig NewConfig)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleAudioEncoder.SetConfig");
    
        USimpleAudioEncoder___SetConfig_Params Params{};
        Params.NewConfig = NewConfig;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void USimpleVideoDecoder::Close()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoDecoder.Close");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    ESimpleVideoCodec USimpleVideoDecoder::GetCodec()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoDecoder.GetCodec");
    
        USimpleVideoDecoder___GetCodec_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool USimpleVideoDecoder::IsAsync()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoDecoder.IsAsync");
    
        USimpleVideoDecoder___IsAsync_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool USimpleVideoDecoder::IsOpen()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoDecoder.IsOpen");
    
        USimpleVideoDecoder___IsOpen_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool USimpleVideoDecoder::Open(ESimpleVideoCodec Codec, bool bAsynchronous)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoDecoder.Open");
    
        USimpleVideoDecoder___Open_Params Params{};
        Params.Codec = Codec;
        Params.bAsynchronous = bAsynchronous;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool USimpleVideoDecoder::ReceiveFrame(UTextureRenderTarget2D* Resource)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoDecoder.ReceiveFrame");
    
        USimpleVideoDecoder___ReceiveFrame_Params Params{};
        Params.Resource = Resource;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool USimpleVideoDecoder::SendPacket(FSimpleVideoPacket& Packet)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoDecoder.SendPacket");
    
        USimpleVideoDecoder___SendPacket_Params Params{};
        Params.Packet = Packet;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Packet = Params.Packet;
    
        return Params.ReturnValue;
    }

    void USimpleVideoEncoder::Close()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoEncoder.Close");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    ESimpleVideoCodec USimpleVideoEncoder::GetCodec()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoEncoder.GetCodec");
    
        USimpleVideoEncoder___GetCodec_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FSimpleVideoEncoderConfig USimpleVideoEncoder::GetConfig()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoEncoder.GetConfig");
    
        USimpleVideoEncoder___GetConfig_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool USimpleVideoEncoder::IsAsync()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoEncoder.IsAsync");
    
        USimpleVideoEncoder___IsAsync_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool USimpleVideoEncoder::IsOpen()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoEncoder.IsOpen");
    
        USimpleVideoEncoder___IsOpen_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool USimpleVideoEncoder::Open(ESimpleVideoCodec Codec, FSimpleVideoEncoderConfig Config, bool bAsynchronous)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoEncoder.Open");
    
        USimpleVideoEncoder___Open_Params Params{};
        Params.Codec = Codec;
        Params.Config = Config;
        Params.bAsynchronous = bAsynchronous;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool USimpleVideoEncoder::ReceivePacket(FSimpleVideoPacket& OutPacket)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoEncoder.ReceivePacket");
    
        USimpleVideoEncoder___ReceivePacket_Params Params{};
        Params.OutPacket = OutPacket;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutPacket = Params.OutPacket;
    
        return Params.ReturnValue;
    }

    void USimpleVideoEncoder::ReceivePackets(TArray<FSimpleVideoPacket>& OutPackets)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoEncoder.ReceivePackets");
    
        USimpleVideoEncoder___ReceivePackets_Params Params{};
        Params.OutPackets = OutPackets;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutPackets = Params.OutPackets;
    }

    bool USimpleVideoEncoder::SendFrameRenderTarget(UTextureRenderTarget2D* Resource, double Timestamp, bool bForceKeyframe)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoEncoder.SendFrameRenderTarget");
    
        USimpleVideoEncoder___SendFrameRenderTarget_Params Params{};
        Params.Resource = Resource;
        Params.Timestamp = Timestamp;
        Params.bForceKeyframe = bForceKeyframe;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool USimpleVideoEncoder::SendFrameTexture(UTexture2D* Resource, double Timestamp, bool bForceKeyframe)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoEncoder.SendFrameTexture");
    
        USimpleVideoEncoder___SendFrameTexture_Params Params{};
        Params.Resource = Resource;
        Params.Timestamp = Timestamp;
        Params.bForceKeyframe = bForceKeyframe;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void USimpleVideoEncoder::SetConfig(FSimpleVideoEncoderConfig NewConfig)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoEncoder.SetConfig");
    
        USimpleVideoEncoder___SetConfig_Params Params{};
        Params.NewConfig = NewConfig;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void USimpleVideoHelper::ShareRenderTarget2D(UTextureRenderTarget2D* RenderTarget)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AVCodecsCoreRHI.SimpleVideoHelper.ShareRenderTarget2D");
    
        USimpleVideoHelper___ShareRenderTarget2D_Params Params{};
        Params.RenderTarget = RenderTarget;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

