/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:09
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimationBudgetAllocator_Functions
 * ============================================================
 */

#include "AnimationBudgetAllocator.hpp"

namespace UE
{

    struct UAnimationBudgetBlueprintLibrary___EnableAnimationBudget_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        bool        bEnabled;           // 0x000008 (0x000001) [Default: true]
    };

    struct UAnimationBudgetBlueprintLibrary___SetAnimationBudgetParameters_Params
    {
        UObject*                            WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        FAnimationBudgetAllocatorParameters InParameters;       // 0x000008 (0x000058) [OutParam]
    };

    struct USkeletalMeshComponentBudgeted___SetAutoRegisterWithBudgetAllocator_Params
    {
        bool    bInAutoRegisterWithBudgetAllocator; // 0x000000 (0x000001) [Default: true]
    };

} // namespace UE

