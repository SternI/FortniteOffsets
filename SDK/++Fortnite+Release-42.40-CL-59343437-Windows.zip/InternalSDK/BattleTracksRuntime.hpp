/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BattleTracksRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000118 (0x000050)
    class alignas(0x8) UBattleTracksPlayerComponent : public UFortControllerComponent
    {
    public:
        AFortPlayerController*                      PlayerController;               // 0x0000C8 (0x000008) [Default: nullptr]
        AFortPlayerPawn*                            PlayerPawn;                     // 0x0000D0 (0x000008) [Default: nullptr]
        USparksCosmeticComponent*                   SparksCosmeticComponent;        // 0x0000D8 (0x000008) [Default: nullptr]
        UFortMusicPlayer*                           MusicPlayer;                    // 0x0000E0 (0x000008) [Default: nullptr]
        uint8                                       UnknownData_0000E8[0x000010];   // 0x0000E8 (0x000010)
        TMap<FGameplayTag, USoundControlBusMix*>    MomentMixes;                    // 0x0000F8 (0x000010)
        USoundControlBusMix*                        ActiveMomentMix;                // 0x000108 (0x000008) [Default: nullptr]
        FGameplayTag                                CurrentMomentMixTag;            // 0x000110 (0x000004)
        uint8                                       UnknownData_000114[0x000004];   // 0x000114 (0x000004)
    
    public: // Functions
        void                                BP_HandlePlayerPlaceChanged(int32 Placement); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void                                BP_HandlePossessedPawnChanged(APawn* OldPawn, APawn* NewPawn); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void                                BP_HandleSparksLoadoutFilled(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        TScriptInterface<IFortMusicItem>    GetSongInMomentSlot(FGameplayTag& MomentTag); // 0x080B4064 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        void                                HandlePlayerPlaceChanged(); // 0x10DF3150 [Final | Native | Protected]
        void                                HandlePlaySongEvent(FFortBattleTracksPlaySongEvent& Event); // 0x080B458C [Final | Native | Protected | HasOutParms]
        void                                HandlePossessedPawnChanged(APawn* OldPawn, APawn* NewPawn); // 0x080B4BAE [Final | Native | Protected]
        void                                HandlePrepareSongEvent(FFortBattleTracksPrepareSongEvent& Event); // 0x080B4E2E [Final | Native | Protected | HasOutParms]
        void                                HandleSparksLoadoutFilled(); // 0x10DF33C0 [Final | Native | Protected]
        void                                HandleStopSongEvent(FFortBattleTracksStopSongEvent& Event); // 0x080B5542 [Final | Native | Protected | HasOutParms]
        void                                PlayEquippedJamTrack(int32 Index, FFortMusicPlayerParams PlayerParams); // 0x080B580E [Final | Native | Protected | BlueprintCallable]
        void                                PlayMomentTrack(FGameplayTag& MomentTag, FFortMusicPlayerParams PlayerParams); // 0x080B6066 [Final | Native | Protected | HasOutParms | BlueprintCallable]
        void                                PrepareEquippedJamTrack(int32 Index, FFortMusicPlayerParams PlayerParams); // 0x080B6478 [Final | Native | Protected | BlueprintCallable]
        void                                PrepareMomentTrack(FGameplayTag& MomentTag, FFortMusicPlayerParams PlayerParams); // 0x080B686C [Final | Native | Protected | HasOutParms | BlueprintCallable]
        void                                PrepareSong(TScriptInterface<IFortMusicItem> Song, FFortMusicPlayerParams PlayerParams); // 0x080B6C7E [Final | Native | Protected | BlueprintCallable]
        static bool                                ShouldPrepareVictorySongEarly(); // 0x10DF379C [Final | Native | Static | Protected | BlueprintCallable | BlueprintPure]
        void                                StopSong(float FadeOutTime); // 0x080B70A0 [Final | Native | Protected | BlueprintCallable]
    };
    // Size: 0x000048 (0x000048)
    struct alignas(0x8) FFortBattleTracksPlaySongEvent
    {
        uint8                               UnknownData_000000[0x000008];   // 0x000000 (0x000008)
        TScriptInterface<IFortMusicItem>    Song;                           // 0x000008 (0x000010)
        int32                               JamTrackIndex;                  // 0x000018 (0x000004) [Default: 0]
        FGameplayTag                        MomentTag;                      // 0x00001C (0x000004)
        FGameplayTag                        MusicEventTag;                  // 0x000020 (0x000004)
        uint8                               UnknownData_000024[0x000004];   // 0x000024 (0x000004)
        FGameplayTagContainer               MusicEventBehaviorTags;         // 0x000028 (0x000020)
    };
    // Size: 0x000048 (0x000000)
    struct FFortBattleTracksPrepareSongEvent : public FFortBattleTracksPlaySongEvent
    {
    };
    // Size: 0x000001 (0x000001)
    struct FFortBattleTracksStopSongEvent
    {
        uint8   UnknownByte_000000; // 0x000000 (0x000001)
    };
}

