/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimationSharing_Functions
 * ============================================================
 */

#include "AnimationSharing_Functions.hpp"

namespace UE
{

    void UAnimSharingStateInstance::GetInstancedActors(TArray<AActor*>& Actors)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationSharing.AnimSharingStateInstance.GetInstancedActors");
    
        UAnimSharingStateInstance___GetInstancedActors_Params Params{};
        Params.Actors = Actors;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Actors = Params.Actors;
    }

    bool UAnimationSharingManager::AnimationSharingEnabled()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationSharing.AnimationSharingManager.AnimationSharingEnabled");
    
        UAnimationSharingManager___AnimationSharingEnabled_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAnimationSharingManager::CreateAnimationSharingManager(UObject* WorldContextObject, UAnimationSharingSetup* Setup)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationSharing.AnimationSharingManager.CreateAnimationSharingManager");
    
        UAnimationSharingManager___CreateAnimationSharingManager_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Setup = Setup;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAnimationSharingManager* UAnimationSharingManager::GetAnimationSharingManager(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationSharing.AnimationSharingManager.GetAnimationSharingManager");
    
        UAnimationSharingManager___GetAnimationSharingManager_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAnimationSharingManager::RegisterActorWithSkeletonBP(AActor* InActor, Uskeleton* SharingSkeleton)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationSharing.AnimationSharingManager.RegisterActorWithSkeletonBP");
    
        UAnimationSharingManager___RegisterActorWithSkeletonBP_Params Params{};
        Params.InActor = InActor;
        Params.SharingSkeleton = SharingSkeleton;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UEnum* UAnimationSharingStateProcessor::GetAnimationStateEnum()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationSharing.AnimationSharingStateProcessor.GetAnimationStateEnum");
    
        UAnimationSharingStateProcessor___GetAnimationStateEnum_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAnimationSharingStateProcessor::ProcessActorState(int32& OutState, AActor* InActor, uint8 CurrentState, uint8 OnDemandState, bool& bShouldProcess)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationSharing.AnimationSharingStateProcessor.ProcessActorState");
    
        UAnimationSharingStateProcessor___ProcessActorState_Params Params{};
        Params.OutState = OutState;
        Params.InActor = InActor;
        Params.CurrentState = CurrentState;
        Params.OnDemandState = OnDemandState;
        Params.bShouldProcess = bShouldProcess;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutState = Params.OutState;
        bShouldProcess = Params.bShouldProcess;
    }

} // namespace UE

