/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BattlePassBase
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000318 (0x000010)
    class alignas(0x8) UFortBattlePassLevelCount : public UUserWidget
    {
    public:
        UCommonTextBlock*   Text_LevelCount;                // 0x000308 (0x000008) [Default: nullptr]
        uint8               UnknownData_000310[0x000008];   // 0x000310 (0x000008)
    };
}

