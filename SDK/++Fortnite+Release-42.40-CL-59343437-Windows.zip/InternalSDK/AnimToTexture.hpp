/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimToTexture
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000210 (0x0001E8)
    class alignas(0x8) UAnimToTextureDataAsset : public UPrimaryDataAsset
    {
    public:
        TSoftObjectPtr<USkeletalMesh>           SkeletalMesh;                   // 0x000028 (0x000020) [Default: nullptr]
        int32                                   SkeletalLODIndex;               // 0x000048 (0x000004) [Default: 0]
        uint8                                   UnknownData_00004C[0x000004];   // 0x00004C (0x000004)
        TSoftObjectPtr<UStaticMesh>             StaticMesh;                     // 0x000050 (0x000020) [Default: nullptr]
        int32                                   StaticLODIndex;                 // 0x000070 (0x000004) [Default: 0]
        int32                                   UVChannel;                      // 0x000074 (0x000004) [Default: 1]
        int32                                   NumDriverTriangles;             // 0x000078 (0x000004) [Default: 10]
        float                                   Sigma;                          // 0x00007C (0x000004) [Default: 1f]
        int32                                   MaxHeight;                      // 0x000080 (0x000004) [Default: 4096]
        int32                                   MaxWidth;                       // 0x000084 (0x000004) [Default: 4096]
        bool                                    bEnforcePowerOfTwo;             // 0x000088 (0x000001) [Default: false]
        EAnimToTexturePrecision                 Precision;                      // 0x000089 (0x000001) [Default: EAnimToTexturePrecision(0)]
        EAnimToTextureMode                      Mode;                           // 0x00008A (0x000001) [Default: EAnimToTextureMode(1)]
        uint8                                   UnknownData_00008B[0x000005];   // 0x00008B (0x000005)
        TSoftObjectPtr<UTexture2D>              VertexPositionTexture;          // 0x000090 (0x000020) [Default: nullptr]
        TSoftObjectPtr<UTexture2D>              VertexNormalTexture;            // 0x0000B0 (0x000020) [Default: nullptr]
        TSoftObjectPtr<UTexture2D>              BonePositionTexture;            // 0x0000D0 (0x000020) [Default: nullptr]
        TSoftObjectPtr<UTexture2D>              BoneRotationTexture;            // 0x0000F0 (0x000020) [Default: nullptr]
        TSoftObjectPtr<UTexture2D>              BoneWeightTexture;              // 0x000110 (0x000020) [Default: nullptr]
        FTransform                              RootTransform;                  // 0x000130 (0x000060)
        FName                                   AttachToSocket;                 // 0x000190 (0x000004) [Default: NAME_None]
        float                                   SampleRate;                     // 0x000194 (0x000004) [Default: 30f]
        TArray<FAnimToTextureAnimSequenceInfo>  AnimSequences;                  // 0x000198 (0x000010)
        bool                                    bAutoPlay;                      // 0x0001A8 (0x000001) [Default: true]
        uint8                                   UnknownData_0001A9[0x000003];   // 0x0001A9 (0x000003)
        int32                                   AnimationIndex;                 // 0x0001AC (0x000004) [Default: 0]
        int32                                   Frame;                          // 0x0001B0 (0x000004) [Default: 0]
        EAnimToTextureNumBoneInfluences         NumBoneInfluences;              // 0x0001B4 (0x000001) [Default: EAnimToTextureNumBoneInfluences(2)]
        uint8                                   UnknownData_0001B5[0x000003];   // 0x0001B5 (0x000003)
        int32                                   NumFrames;                      // 0x0001B8 (0x000004) [Default: 0]
        int32                                   NumBones;                       // 0x0001BC (0x000004) [Default: 0]
        int32                                   VertexRowsPerFrame;             // 0x0001C0 (0x000004) [Default: 1]
        FVector3f                               VertexMinBBox;                  // 0x0001C4 (0x00000C)
        FVector3f                               VertexSizeBBox;                 // 0x0001D0 (0x00000C)
        int32                                   BoneWeightRowsPerFrame;         // 0x0001DC (0x000004) [Default: 1]
        int32                                   BoneRowsPerFrame;               // 0x0001E0 (0x000004) [Default: 1]
        FVector3f                               BoneMinBBox;                    // 0x0001E4 (0x00000C)
        FVector3f                               BoneSizeBBox;                   // 0x0001F0 (0x00000C)
        uint8                                   UnknownData_0001FC[0x000004];   // 0x0001FC (0x000004)
        TArray<FAnimToTextureAnimInfo>          Animations;                     // 0x000200 (0x000010)
    
    public: // Functions
        UTexture2D*     BP_GetBonePositionTexture(); // 0x10C0234E [Final | Native | Public | BlueprintCallable | BlueprintPure]
        UTexture2D*     BP_GetBoneRotationTexture(); // 0x10C0237C [Final | Native | Public | BlueprintCallable | BlueprintPure]
        UTexture2D*     BP_GetBoneWeightTexture(); // 0x10C023AA [Final | Native | Public | BlueprintCallable | BlueprintPure]
        USkeletalMesh*  BP_GetSkeletalMesh(); // 0x10C023D8 [Final | Native | Public | BlueprintCallable | BlueprintPure]
        UStaticMesh*    BP_GetStaticMesh(); // 0x10C02402 [Final | Native | Public | BlueprintCallable | BlueprintPure]
        int32           GetIndexFromAnimSequence(UAnimSequence* Sequence); // 0x07ED209C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void            ResetInfo(); // 0x10C0242C [Final | RequiredAPI | Native | Public]
    };
    // Size: 0x000028 (0x000000)
    class UAnimToTextureInstancePlaybackLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static bool    BatchUpdateInstancesAutoPlayData(UInstancedStaticMeshComponent* InstancedMeshComponent, TArray<FAnimToTextureAutoPlayData>& AutoPlayData, TArray<FTransform>& Transforms, bool bMarkRenderStateDirty); // 0x07ED2248 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static bool    BatchUpdateInstancesFrameData(UInstancedStaticMeshComponent* InstancedMeshComponent, TArray<FAnimToTextureFrameData>& FrameData, TArray<FTransform>& Transforms, bool bMarkRenderStateDirty); // 0x07ED26CA [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static bool    GetAutoPlayDataFromDataAsset(UAnimToTextureDataAsset* DataAsset, int32 AnimationIndex, FAnimToTextureAutoPlayData& AutoPlayData, float TimeOffset, float PlayRate); // 0x07ED2B4C [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static float   GetFrame(float time, float StartFrame, float EndFrame, float TimeOffset, float PlayRate, float SampleRate); // 0x07ED31B0 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static bool    GetFrameDataFromDataAsset(UAnimToTextureDataAsset* DataAsset, int32 AnimationIndex, float time, FAnimToTextureFrameData& FrameData, float TimeOffset, float PlayRate); // 0x07ED37B6 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static bool    SetupInstancedMeshComponent(UInstancedStaticMeshComponent* InstancedMeshComponent, int32 NumInstances, bool bAutoPlay); // 0x07ED3DA0 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static bool    UpdateInstanceAutoPlayData(UInstancedStaticMeshComponent* InstancedMeshComponent, int32 InstanceIndex, FAnimToTextureAutoPlayData& AutoPlayData, bool bMarkRenderStateDirty); // 0x07ED4132 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static bool    UpdateInstanceFrameData(UInstancedStaticMeshComponent* InstancedMeshComponent, int32 InstanceIndex, FAnimToTextureFrameData& FrameData, bool bMarkRenderStateDirty); // 0x07ED4572 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FAnimToTextureAnimInfo
    {
        int32   StartFrame; // 0x000000 (0x000004)
        int32   EndFrame;   // 0x000004 (0x000004)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FAnimToTextureAnimSequenceInfo
    {
        bool            bEnabled;                       // 0x000000 (0x000001)
        uint8           UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        UAnimSequence*  AnimSequence;                   // 0x000008 (0x000008)
        bool            bUseCustomRange;                // 0x000010 (0x000001)
        uint8           UnknownData_000011[0x000003];   // 0x000011 (0x000003)
        int32           StartFrame;                     // 0x000014 (0x000004)
        int32           EndFrame;                       // 0x000018 (0x000004)
        uint8           UnknownData_00001C[0x000004];   // 0x00001C (0x000004)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x4) FAnimToTextureAutoPlayData
    {
        float   TimeOffset; // 0x000000 (0x000004)
        float   PlayRate;   // 0x000004 (0x000004)
        float   StartFrame; // 0x000008 (0x000004)
        float   EndFrame;   // 0x00000C (0x000004)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FAnimToTextureFrameData
    {
        float   Frame;      // 0x000000 (0x000004)
        float   PrevFrame;  // 0x000004 (0x000004)
    };
}

