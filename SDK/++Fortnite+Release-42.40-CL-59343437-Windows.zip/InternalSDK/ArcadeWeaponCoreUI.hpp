/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArcadeWeaponCoreUI
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000080 (0x000018)
    class alignas(0x8) UArcadeWeaponLeaderboardPlayerEntryVM : public UMVVMViewModelBase
    {
    public:
        UFortPlayerAvatarViewModel* FortPlayerAvatarViewModel;      // 0x000068 (0x000008) [Default: nullptr]
        uint8                       UnknownData_000070[0x000010];   // 0x000070 (0x000010)
    
    public: // Functions
        int32   GetCurrentMatchScore(); // 0x0BE7B586 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32   GetHighScore(); // 0x0BE7B5B8 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FText   GetName(); // 0x0B4691F6 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32   GetRank(); // 0x0BE7B5EA [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x000098 (0x000020)
    class alignas(0x8) UArcadeWeaponLeaderboardVM : public UFortPerUserViewModel
    {
    public:
        TArray<UArcadeWeaponLeaderboardPlayerEntryVM*>  LeaderboardEntries;             // 0x000078 (0x000010)
        UArcadeWeaponLeaderboardPlayerEntryVM*          LocalPlayerEntry;               // 0x000088 (0x000008) [Default: nullptr]
        uint8                                           UnknownData_000090[0x000008];   // 0x000090 (0x000008)
    
    public: // Functions
        EArcadeWeaponLeaderboardMode    GetLeaderboardMode(); // 0x0B0A7104 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                            HandleFriendsLeaderboardChanged(); // 0x10C4D4D0 [Final | Native | Private]
        void                            HandleGlobalLeaderboardChanged(); // 0x10C4D4EE [Final | Native | Private]
        void                            HandleLeaderboardModeChanged(); // 0x10C4D50C [Final | Native | Private]
        void                            ToggleLeaderboard(EArcadeWeaponLeaderboardType InLeaderboardType); // 0x07F3B31C [Final | Native | Protected | BlueprintCallable]
    };
    // Size: 0x000508 (0x000068)
    class alignas(0x8) UArcadeWeaponTabScreen : public UCommonActivatableWidget
    {
    public:
        void**                              VTable_0004A0;                  // 0x0004A0 (0x000008) VTable [16 slots] -> 0x146D77E0
        uint8                               UnknownData_0004A8[0x000020];   // 0x0004A8 (0x000020)
        FAthenaMapScreenContainerTabInfo    MapTabInfo;                     // 0x0004C8 (0x000040)
    };
}

