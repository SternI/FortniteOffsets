/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AutomationUtils_Functions
 * ============================================================
 */

#include "AutomationUtils_Functions.hpp"

namespace UE
{

    void UAutomationUtilsBlueprintLibrary::AddAutomationMountPoint(FString RootPath)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AutomationUtils.AutomationUtilsBlueprintLibrary.AddAutomationMountPoint");
    
        UAutomationUtilsBlueprintLibrary___AddAutomationMountPoint_Params Params{};
        Params.RootPath = RootPath;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAutomationUtilsBlueprintLibrary::FinishAllAssetCompilation()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AutomationUtils.AutomationUtilsBlueprintLibrary.FinishAllAssetCompilation");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAutomationUtilsBlueprintLibrary::RemoveAutomationMountPoint(FString RootPath)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AutomationUtils.AutomationUtilsBlueprintLibrary.RemoveAutomationMountPoint");
    
        UAutomationUtilsBlueprintLibrary___RemoveAutomationMountPoint_Params Params{};
        Params.RootPath = RootPath;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAutomationUtilsBlueprintLibrary::TakeGameplayAutomationScreenshot(FString ScreenshotName, float MaxGlobalError, float MaxLocalError, FString MapNameOverride)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AutomationUtils.AutomationUtilsBlueprintLibrary.TakeGameplayAutomationScreenshot");
    
        UAutomationUtilsBlueprintLibrary___TakeGameplayAutomationScreenshot_Params Params{};
        Params.ScreenshotName = ScreenshotName;
        Params.MaxGlobalError = MaxGlobalError;
        Params.MaxLocalError = MaxLocalError;
        Params.MapNameOverride = MapNameOverride;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

