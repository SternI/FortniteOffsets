/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AssetTags_Functions
 * ============================================================
 */

#include "AssetTags.hpp"

namespace UE
{

    struct UAssetTagsSubsystem___CollectionExists_Params
    {
        FName   Name;           // 0x000000 (0x000004) [Default: FName(319848944) -> L""]
        bool    ReturnValue;    // 0x000004 (0x000001) [ReturnValue] [Default: false]
    };

    struct UAssetTagsSubsystem___GetAssetsInCollection_Params
    {
        FName               Name;                           // 0x000000 (0x000004) [Default: FName(319848944) -> L""]
        uint8               UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FAssetData>  ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UAssetTagsSubsystem___GetCollections_Params
    {
        TArray<FName>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAssetTagsSubsystem___GetCollectionsContainingAsset_Params
    {
        FName           AssetPathName;                  // 0x000000 (0x000004) [Default: FName(319848944) -> L""]
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FName>   ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UAssetTagsSubsystem___GetCollectionsContainingAssetData_Params
    {
        FAssetData      AssetData;      // 0x000000 (0x000038) [OutParam]
        TArray<FName>   ReturnValue;    // 0x000038 (0x000010) [ReturnValue]
    };

    struct UAssetTagsSubsystem___GetCollectionsContainingAssetPtr_Params
    {
        UObject*        AssetPtr;       // 0x000000 (0x000008) [Default: 0x131081F0]
        TArray<FName>   ReturnValue;    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UAssetTagsSubsystem___K2_GetCollectionsContainingAsset_Params
    {
        FSoftObjectPath AssetPath;      // 0x000000 (0x000018) [OutParam]
        TArray<FName>   ReturnValue;    // 0x000018 (0x000010) [ReturnValue]
    };

} // namespace UE

