/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AircraftADS_Functions
 * ============================================================
 */

#include "AircraftADS.hpp"

namespace UE
{

    struct UFortControllerComponent_AircraftADS___BP_OnZoomInCameraActivate_Params
    {
        AFortPlayerController*  Initiator;  // 0x000000 (0x000008) [Default: 0x1488FC60]
    };

    struct UFortControllerComponent_AircraftADS___BP_OnZoomInCameraDeactivate_Params
    {
        AFortPlayerController*  Initiator;  // 0x000000 (0x000008) [Default: 0x1488FC60]
    };

    struct UFortControllerComponent_AircraftADS___OnExitAircraft_Params
    {
        AController*    Controller; // 0x000000 (0x000008) [Default: 0x1488FC60]
    };

    struct UFortControllerComponent_AircraftADS___OnADSCameraActivation_Params
    {
        AFortPlayerController*  Controller; // 0x000000 (0x000008) [Default: 0x1488FC60]
    };

    struct UFortControllerComponent_AircraftADS___OnADSCameraDeactivation_Params
    {
        AFortPlayerController*  Controller; // 0x000000 (0x000008) [Default: 0x1488FC60]
    };

} // namespace UE

