/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioShapes
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000240 (0x000060)
    class alignas(0x8) UAudioShapeBoxComponent : public UAudioShapePrimitiveComponent
    {
    public:
        FTransform  BoxTransform;   // 0x0001E0 (0x000060)
    
    public: // Functions
        void    SetBoxTransform(FTransform& InTransform); // 0x0567D960 [Final | RequiredAPI | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000120 (0x000058)
    class alignas(0x8) UAudioShapeComponent : public UAudioGameplayComponent
    {
    public:
        void**                                                  VTable_0000C8;                  // 0x0000C8 (0x000008) VTable [4 slots] -> 0x134DDA70
        float                                                   MaxDistanceOffset;              // 0x0000D0 (0x000004) [Default: 1000f]
        float                                                   SmoothingDistance;              // 0x0000D4 (0x000004) [Default: 512f]
        float                                                   FadeInTime;                     // 0x0000D8 (0x000004) [Default: 1f]
        float                                                   FadeOutTime;                    // 0x0000DC (0x000004) [Default: 1f]
        MULTI_INLINE_DELEGATE(OnAudioShapeAudibleStateChanged)  OnAudibleStateChanged;          // 0x0000E0 (0x000010)
        TMap<FName, UAudioComponent*>                           AudioComponents;                // 0x0000F0 (0x000010)
        TArray<APlayerController*>                              LocalControllers;               // 0x000100 (0x000010)
        uint8                                                   UnknownData_000110[0x000010];   // 0x000110 (0x000010)
    
    public: // Functions
        void    Disable(); // 0x0DAC6250 [RequiredAPI | Native | Protected | BlueprintCallable]
        void    Enable(); // 0x0CBFB85A [RequiredAPI | Native | Protected | BlueprintCallable]
        bool    IsAudioShapeReady(); // 0x0E45DFA4 [RequiredAPI | Native | Public]
        bool    IsShapeActive(); // 0x0E45DFCE [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    UpdateAudioShape(TArray<APlayerController*>& InLocalControllers); // 0x0567DB2A [Final | RequiredAPI | Native | Public | HasOutParms]
    };
    // Size: 0x0001F0 (0x000010)
    class alignas(0x4) UAudioShapeCylinderComponent : public UAudioShapePrimitiveComponent
    {
    public:
        float   HalfHeight;                     // 0x0001E0 (0x000004) [Default: 500f]
        float   Radius;                         // 0x0001E4 (0x000004) [Default: 1000f]
        uint8   UnknownData_0001E8[0x000008];   // 0x0001E8 (0x000008)
    
    public: // Functions
        void    SetHalfHeight(float InHalfHeight); // 0x0567DCB8 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetRadius(float InRadius); // 0x0567DE32 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000210 (0x000030)
    class alignas(0x8) UAudioShapeLineComponent : public UAudioShapePrimitiveComponent
    {
    public:
        FVector StartPoint; // 0x0001E0 (0x000018)
        FVector Endpoint;   // 0x0001F8 (0x000018)
    
    public: // Functions
        void    SetEndPoint(FVector& InEndPoint); // 0x0567DFAC [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        void    SetStartPoint(FVector& InStartPoint); // 0x0567E134 [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000200 (0x000020)
    class alignas(0x8) UAudioShapeLineListComponent : public UAudioShapePrimitiveComponent
    {
    public:
        TArray<FVector> PointList;                      // 0x0001E0 (0x000010)
        bool            bClosedLoop;                    // 0x0001F0 (0x000001) [Default: false]
        uint8           UnknownData_0001F1[0x00000F];   // 0x0001F1 (0x00000F)
    
    public: // Functions
        int32   AddPoint(FVector& InPoint); // 0x0567E2BC [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        void    GetPoints(TArray<FVector>& OutPoints); // 0x0567E486 [Final | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        bool    RemovePoint(int32 InIndex); // 0x0567E61C [Final | Native | Public | BlueprintCallable]
        bool    UpdatePoint(int32 InIndex, FVector& InPoint); // 0x0567E7AE [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
    // Size: 0x0001E0 (0x0000C0)
    class alignas(0x8) UAudioShapePrimitiveComponent : public UAudioShapeComponent
    {
    public:
        USoundBase*                                             SoundOnEdge;                    // 0x000120 (0x000008) [Default: nullptr]
        USoundBase*                                             SoundOnInside;                  // 0x000128 (0x000008) [Default: nullptr]
        MULTI_INLINE_DELEGATE(OnAudioShapeInsideStateChanged)   OnInsideStateChanged;           // 0x000130 (0x000010)
        bool                                                    bUseOwningActorTransform;       // 0x000140 (0x000001) [Default: false]
        bool                                                    bAutoRefreshShape;              // 0x000141 (0x000001) [Default: false]
        uint8                                                   UnknownData_000142[0x000006];   // 0x000142 (0x000006)
        FVector                                                 ActorTransformScale;            // 0x000148 (0x000018)
        uint8                                                   UnknownData_000160[0x000080];   // 0x000160 (0x000080)
    
    public: // Functions
        UAudioComponent*    GetEdgeAudioComponent(); // 0x0E45E584 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure]
        UAudioComponent*    GetInsideAudioComponent(); // 0x0E45E600 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure]
        bool                GetIsPlayerInside(); // 0x0E45E67C [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x0001F0 (0x000010)
    class alignas(0x4) UAudioShapeSphereComponent : public UAudioShapePrimitiveComponent
    {
    public:
        float   Radius;                         // 0x0001E0 (0x000004) [Default: 1000f]
        uint8   UnknownData_0001E4[0x00000C];   // 0x0001E4 (0x00000C)
    
    public: // Functions
        void    SetRadius(float InRadius); // 0x0567DCB8 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x0002B0 (0x000190)
    class alignas(0x8) UAudioShapeSplineComponent : public UAudioShapeComponent
    {
    public:
        float                                               TravelDistanceCrossfadeThreshold;   // 0x000120 (0x000004) [Default: 1000f]
        float                                               TravelDistanceCrossfadeTime;        // 0x000124 (0x000004) [Default: 1f]
        USoundBase*                                         ClosestPointSound;                  // 0x000128 (0x000008) [Default: nullptr]
        MULTI_INLINE_DELEGATE(OnAudioUpdateInAudibleRange)  OnAudioUpdateInAudibleRange;        // 0x000130 (0x000010)
        uint8                                               UnknownData_000140[0x000058];       // 0x000140 (0x000058)
        FBox                                                SplineAABB;                         // 0x000198 (0x000038)
        TArray<UAudioComponent*>                            FadingComponents;                   // 0x0001D0 (0x000010)
        TWeakObjectPtr<USplineComponent>                    Spline;                             // 0x0001E0 (0x000008) [Default: nullptr]
        TArray<FSplineSegmentData>                          SplineSegments;                     // 0x0001E8 (0x000010)
        uint8                                               UnknownData_0001F8[0x0000B8];       // 0x0001F8 (0x0000B8)
    
    public: // Functions
        UAudioComponent*    GetAudioComponent(); // 0x0E45E6AA [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                SetSpline(USplineComponent* NewSpline); // 0x0567FBFE [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x0000A0 (0x000068)
    class alignas(0x8) UAudioShapeSubsystem : public UWorldSubsystem
    {
    public:
        void**                          VTable_000038;                  // 0x000038 (0x000008) VTable [7 slots] -> 0x134DFF60
        uint8                           UnknownData_000040[0x000020];   // 0x000040 (0x000020)
        TArray<UAudioShapeComponent*>   PendingAudioShapes;             // 0x000060 (0x000010)
        TArray<UAudioShapeComponent*>   AudioShapes;                    // 0x000070 (0x000010)
        TArray<APlayerController*>      LocalControllers;               // 0x000080 (0x000010)
        uint8                           UnknownData_000090[0x000010];   // 0x000090 (0x000010)
    };
    // Size: 0x000040 (0x000040)
    struct alignas(0x8) FSplineSegmentData
    {
        FBoxSphereBounds    Bounds;                         // 0x000000 (0x000038)
        int32               PointIndex;                     // 0x000038 (0x000004)
        uint8               UnknownData_00003C[0x000004];   // 0x00003C (0x000004)
    };
}

