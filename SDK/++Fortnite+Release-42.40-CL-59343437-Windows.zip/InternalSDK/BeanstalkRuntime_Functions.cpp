/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BeanstalkRuntime_Functions
 * ============================================================
 */

#include "BeanstalkRuntime_Functions.hpp"

namespace UE
{

    void ABeanCharacter::BP_OnBeanLocalInteractFailed(AActor* Interactable)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.BP_OnBeanLocalInteractFailed");
    
        ABeanCharacter___BP_OnBeanLocalInteractFailed_Params Params{};
        Params.Interactable = Interactable;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABeanCharacter::Client_OnTeleport(FVector Location, FRotator Rotation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.Client_OnTeleport");
    
        ABeanCharacter___Client_OnTeleport_Params Params{};
        Params.Location = Location;
        Params.Rotation = Rotation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABeanCharacter::Client_TeleportSucceeded()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.Client_TeleportSucceeded");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ABeanCharacter::Debug_ServerActivateRagdoll(FVector Force)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.Debug_ServerActivateRagdoll");
    
        ABeanCharacter___Debug_ServerActivateRagdoll_Params Params{};
        Params.Force = Force;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    TArray<UMaterialInstanceDynamic*> ABeanCharacter::GetAllCosmeticMaterials()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.GetAllCosmeticMaterials");
    
        ABeanCharacter___GetAllCosmeticMaterials_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharAnimInstance* ABeanCharacter::GetBeanAnimInstance()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.GetBeanAnimInstance");
    
        ABeanCharacter___GetBeanAnimInstance_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharMovementComponent* ABeanCharacter::GetBeanCharacterMovement()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.GetBeanCharacterMovement");
    
        ABeanCharacter___GetBeanCharacterMovement_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharBeingGrabbedComponent* ABeanCharacter::GetBeingGrabbedComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.GetBeingGrabbedComponent");
    
        ABeanCharacter___GetBeingGrabbedComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharCollisionManagerComponent* ABeanCharacter::GetCollisionManager()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.GetCollisionManager");
    
        ABeanCharacter___GetCollisionManager_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharConfigObject* ABeanCharacter::GetConfiguration()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.GetConfiguration");
    
        ABeanCharacter___GetConfiguration_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharGrabComponent* ABeanCharacter::GetGrabComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.GetGrabComponent");
    
        ABeanCharacter___GetGrabComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanJiggleMotionComponent* ABeanCharacter::GetJiggleMotionComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.GetJiggleMotionComponent");
    
        ABeanCharacter___GetJiggleMotionComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharMantleComponent* ABeanCharacter::GetMantleComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.GetMantleComponent");
    
        ABeanCharacter___GetMantleComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float ABeanCharacter::GetMeshScale()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.GetMeshScale");
    
        ABeanCharacter___GetMeshScale_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharRagdollComponent* ABeanCharacter::GetRagdollComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.GetRagdollComponent");
    
        ABeanCharacter___GetRagdollComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    USkeletalMeshComponent* ABeanCharacter::GetRetargetSourceMesh()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.GetRetargetSourceMesh");
    
        ABeanCharacter___GetRetargetSourceMesh_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool ABeanCharacter::IsBeingGrabbed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.IsBeingGrabbed");
    
        ABeanCharacter___IsBeingGrabbed_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void ABeanCharacter::OnRep_EnableInventoryMode()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.OnRep_EnableInventoryMode");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ABeanCharacter::PredictLaunch(TScriptInterface<IBeanLaunchPredictorInterface> SourceImpactPredictor, UObject* SourceOptionalSubobject, FVector& LaunchVector)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.PredictLaunch");
    
        ABeanCharacter___PredictLaunch_Params Params{};
        Params.SourceImpactPredictor = SourceImpactPredictor;
        Params.SourceOptionalSubobject = SourceOptionalSubobject;
        Params.LaunchVector = LaunchVector;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        LaunchVector = Params.LaunchVector;
    }

    void ABeanCharacter::ServerPlayEmote(UAthenaDanceItemDefinition* EmoteToPlay, EFortEmotePlayMode PlayMode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.ServerPlayEmote");
    
        ABeanCharacter___ServerPlayEmote_Params Params{};
        Params.EmoteToPlay = EmoteToPlay;
        Params.PlayMode = PlayMode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABeanCharacter::TriggerRagdoll(FVector& Force, bool bIsViaLaunch)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharacter.TriggerRagdoll");
    
        ABeanCharacter___TriggerRagdoll_Params Params{};
        Params.Force = Force;
        Params.bIsViaLaunch = bIsViaLaunch;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Force = Params.Force;
    }

    TMap<FBeanAudioKey, FBeanAudioSet> UBeanAudioDataAsset::GetSoundListsByCategory()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanAudioDataAsset.GetSoundListsByCategory");
    
        UBeanAudioDataAsset___GetSoundListsByCategory_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharConfigObject* UBeanCharAnimInstance::GetConfig()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharAnimInstance.GetConfig");
    
        UBeanCharAnimInstance___GetConfig_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    ABeanCharacter* UBeanCharAnimInstance::TryGetBeanCharacter()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharAnimInstance.TryGetBeanCharacter");
    
        UBeanCharAnimInstance___TryGetBeanCharacter_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FVector UBeanCharBeingGrabbedComponent::GetGrabbeeDragForce(float DragDuration, FVector& LocationOffset)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharBeingGrabbedComponent.GetGrabbeeDragForce");
    
        UBeanCharBeingGrabbedComponent___GetGrabbeeDragForce_Params Params{};
        Params.DragDuration = DragDuration;
        Params.LocationOffset = LocationOffset;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        LocationOffset = Params.LocationOffset;
    
        return Params.ReturnValue;
    }

    FBeanCharCameraConfig UBeanCharConfigObject::GetCamera()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetCamera");
    
        UBeanCharConfigObject___GetCamera_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharCosmeticConfig UBeanCharConfigObject::GetCosmetics()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetCosmetics");
    
        UBeanCharConfigObject___GetCosmetics_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharDiveConfig UBeanCharConfigObject::GetDive()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetDive");
    
        UBeanCharConfigObject___GetDive_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharGetupConfig UBeanCharConfigObject::GetGetup()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetGetup");
    
        UBeanCharConfigObject___GetGetup_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharGetupRollConfig UBeanCharConfigObject::GetGetupRoll()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetGetupRoll");
    
        UBeanCharConfigObject___GetGetupRoll_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharGrabConfig UBeanCharConfigObject::GetGrab()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetGrab");
    
        UBeanCharConfigObject___GetGrab_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharHUDConfig UBeanCharConfigObject::GetHUD()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetHUD");
    
        UBeanCharConfigObject___GetHUD_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharImpactConfig UBeanCharConfigObject::GetImpact()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetImpact");
    
        UBeanCharConfigObject___GetImpact_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharInteractionsConfig UBeanCharConfigObject::GetInteraction()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetInteraction");
    
        UBeanCharConfigObject___GetInteraction_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharInventoryModeConfig UBeanCharConfigObject::GetInventoryMode()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetInventoryMode");
    
        UBeanCharConfigObject___GetInventoryMode_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharJiggleConfig UBeanCharConfigObject::GetJiggle()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetJiggle");
    
        UBeanCharConfigObject___GetJiggle_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharJostleConfig UBeanCharConfigObject::GetJostle()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetJostle");
    
        UBeanCharConfigObject___GetJostle_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharJumpConfig UBeanCharConfigObject::GetJump()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetJump");
    
        UBeanCharConfigObject___GetJump_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharMantleConfig UBeanCharConfigObject::GetMantle()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetMantle");
    
        UBeanCharConfigObject___GetMantle_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharMovementConfig UBeanCharConfigObject::GetMovement()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetMovement");
    
        UBeanCharConfigObject___GetMovement_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharRagdollConfig UBeanCharConfigObject::GetRagdoll()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetRagdoll");
    
        UBeanCharConfigObject___GetRagdoll_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharRollConfig UBeanCharConfigObject::GetRoll()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetRoll");
    
        UBeanCharConfigObject___GetRoll_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharStaggerConfig UBeanCharConfigObject::GetStagger()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetStagger");
    
        UBeanCharConfigObject___GetStagger_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharSwimmingConfig UBeanCharConfigObject::GetSwimming()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetSwimming");
    
        UBeanCharConfigObject___GetSwimming_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharTouchControlsConfig UBeanCharConfigObject::GetTouchControls()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetTouchControls");
    
        UBeanCharConfigObject___GetTouchControls_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeanCharZiplineConfig UBeanCharConfigObject::GetZipline()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharConfigObject.GetZipline");
    
        UBeanCharConfigObject___GetZipline_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FVector UBeanCharGrabComponent::GetGrabberDragForce(float DragDuration)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharGrabComponent.GetGrabberDragForce");
    
        UBeanCharGrabComponent___GetGrabberDragForce_Params Params{};
        Params.DragDuration = DragDuration;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBeanCharGrabComponent::HandleOnPawnJumped()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharGrabComponent.HandleOnPawnJumped");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBeanCharGrabComponent::OnRep_GrabTarget()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharGrabComponent.OnRep_GrabTarget");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBeanCharGrabComponent::OnRep_ServerLatestHoldStartTime()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharGrabComponent.OnRep_ServerLatestHoldStartTime");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBeanCharMovementComponent::ApplyKnockbackImpulse(FVector& Force)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharMovementComponent.ApplyKnockbackImpulse");
    
        UBeanCharMovementComponent___ApplyKnockbackImpulse_Params Params{};
        Params.Force = Force;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Force = Params.Force;
    }

    ABeanCharacter* UBeanCharMovementComponent::GetBeanCharacter()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharMovementComponent.GetBeanCharacter");
    
        UBeanCharMovementComponent___GetBeanCharacter_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EBeanCharTurn180State UBeanCharMovementComponent::GetTurn180State()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharMovementComponent.GetTurn180State");
    
        UBeanCharMovementComponent___GetTurn180State_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBeanCharMovementComponent::Server_SetDebugForceCorrection(EBeanDebugForceCorrectionMode Mode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharMovementComponent.Server_SetDebugForceCorrection");
    
        UBeanCharMovementComponent___Server_SetDebugForceCorrection_Params Params{};
        Params.Mode = Mode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCharMovementComponent::ServerRequestPredictLaunch(UObject* SourceObject, UObject* SourceOptionalSubobject, FVector LaunchVector, float MovementTimestamp)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharMovementComponent.ServerRequestPredictLaunch");
    
        UBeanCharMovementComponent___ServerRequestPredictLaunch_Params Params{};
        Params.SourceObject = SourceObject;
        Params.SourceOptionalSubobject = SourceOptionalSubobject;
        Params.LaunchVector = LaunchVector;
        Params.MovementTimestamp = MovementTimestamp;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCharMovementComponent::ServerSuggestImpartedMovementBaseVelocity(FVector ImpartedVelocity, float Timestamp)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharMovementComponent.ServerSuggestImpartedMovementBaseVelocity");
    
        UBeanCharMovementComponent___ServerSuggestImpartedMovementBaseVelocity_Params Params{};
        Params.ImpartedVelocity = ImpartedVelocity;
        Params.Timestamp = Timestamp;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCharMovementComponent::SetTurn180State(EBeanCharTurn180State NewTurnState)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharMovementComponent.SetTurn180State");
    
        UBeanCharMovementComponent___SetTurn180State_Params Params{};
        Params.NewTurnState = NewTurnState;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCharRagdollComponent::ApplyImpulse(FVector& Force, bool bIsLaunch)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharRagdollComponent.ApplyImpulse");
    
        UBeanCharRagdollComponent___ApplyImpulse_Params Params{};
        Params.Force = Force;
        Params.bIsLaunch = bIsLaunch;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Force = Params.Force;
    }

    void UBeanCharRagdollComponent::CleanupRagdollForAbruptExit()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharRagdollComponent.CleanupRagdollForAbruptExit");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBeanCharRagdollComponent::Client_CleanupRagdollForAbruptExit()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharRagdollComponent.Client_CleanupRagdollForAbruptExit");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBeanCharRagdollComponent::Client_SignalRagdollExit(FVector EndLocation, FQuat EndRotation, FVector EndVelocity)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharRagdollComponent.Client_SignalRagdollExit");
    
        UBeanCharRagdollComponent___Client_SignalRagdollExit_Params Params{};
        Params.EndLocation = EndLocation;
        Params.EndRotation = EndRotation;
        Params.EndVelocity = EndVelocity;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCharRagdollComponent::OnRagdollRootPrimitiveHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, FHitResult& Hit)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharRagdollComponent.OnRagdollRootPrimitiveHit");
    
        UBeanCharRagdollComponent___OnRagdollRootPrimitiveHit_Params Params{};
        Params.HitComp = HitComp;
        Params.OtherActor = OtherActor;
        Params.OtherComp = OtherComp;
        Params.NormalImpulse = NormalImpulse;
        Params.Hit = Hit;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Hit = Params.Hit;
    }

    void UBeanCharRagdollComponent::RequestRagdollExit()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharRagdollComponent.RequestRagdollExit");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBeanCharRagdollComponent::Server_SignalClientExitedRagdoll()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharRagdollComponent.Server_SignalClientExitedRagdoll");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBeanCharRagdollComponent::ServerRPCRagdollControlInput(FVector InputVector)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharRagdollComponent.ServerRPCRagdollControlInput");
    
        UBeanCharRagdollComponent___ServerRPCRagdollControlInput_Params Params{};
        Params.InputVector = InputVector;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCharRagdollComponent::SetRagdollEnabled(bool bShouldEnable)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharRagdollComponent.SetRagdollEnabled");
    
        UBeanCharRagdollComponent___SetRagdollEnabled_Params Params{};
        Params.bShouldEnable = bShouldEnable;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCharStateMachine::Client_ForceSetState(EBeanCharStateID StateUP, EBeanCharStateID StateLW, uint8 SyncID, bool bResetPredictionData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharStateMachine.Client_ForceSetState");
    
        UBeanCharStateMachine___Client_ForceSetState_Params Params{};
        Params.StateUP = StateUP;
        Params.StateLW = StateLW;
        Params.SyncID = SyncID;
        Params.bResetPredictionData = bResetPredictionData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCharStateMachine::ClientRPC_RequestClientChangesState(EBeanCharStateID StateId, FVector Location, FRotator Rotation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharStateMachine.ClientRPC_RequestClientChangesState");
    
        UBeanCharStateMachine___ClientRPC_RequestClientChangesState_Params Params{};
        Params.StateId = StateId;
        Params.Location = Location;
        Params.Rotation = Rotation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCharStateMachine::Debug_RequestClientChangesState(EBeanCharStateID StateId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharStateMachine.Debug_RequestClientChangesState");
    
        UBeanCharStateMachine___Debug_RequestClientChangesState_Params Params{};
        Params.StateId = StateId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UClass* UBeanCharStateMachine::GetState(EBeanCharStateLayerID LayerID)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharStateMachine.GetState");
    
        UBeanCharStateMachine___GetState_Params Params{};
        Params.LayerID = LayerID;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UBeanCharStateMachine::GetStateActiveDuration(EBeanCharStateID StateId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharStateMachine.GetStateActiveDuration");
    
        UBeanCharStateMachine___GetStateActiveDuration_Params Params{};
        Params.StateId = StateId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EBeanCharStateID UBeanCharStateMachine::GetStateId(EBeanCharStateLayerID LayerID)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharStateMachine.GetStateId");
    
        UBeanCharStateMachine___GetStateId_Params Params{};
        Params.LayerID = LayerID;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBeanCharStateMachine::OnRep_AutonomousProxyStateData()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharStateMachine.OnRep_AutonomousProxyStateData");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBeanCharStateMachine::OnRep_SimulatedProxyStateData()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharStateMachine.OnRep_SimulatedProxyStateData");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBeanCharStateMachine::ServerRPC_RequestClientChangeStateResponse(EBeanCharStateID StateId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharStateMachine.ServerRPC_RequestClientChangeStateResponse");
    
        UBeanCharStateMachine___ServerRPC_RequestClientChangeStateResponse_Params Params{};
        Params.StateId = StateId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCharState_Emote::OnEmoteFinishedCallback(int32 EmoteIndex, bool bWasInterruption)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCharState_Emote.OnEmoteFinishedCallback");
    
        UBeanCharState_Emote___OnEmoteFinishedCallback_Params Params{};
        Params.EmoteIndex = EmoteIndex;
        Params.bWasInterruption = bWasInterruption;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UBeanCharConfigObject* UBeanChar_EditMode_AnimLayer::GetConfig()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_EditMode_AnimLayer.GetConfig");
    
        UBeanChar_EditMode_AnimLayer___GetConfig_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    ABeanCharacter* UBeanChar_EditMode_AnimLayer::TryGetBeanCharacter()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_EditMode_AnimLayer.TryGetBeanCharacter");
    
        UBeanChar_EditMode_AnimLayer___TryGetBeanCharacter_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharConfigObject* UBeanChar_Flying_AnimLayer::GetConfig()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_Flying_AnimLayer.GetConfig");
    
        UBeanChar_Flying_AnimLayer___GetConfig_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    ABeanCharacter* UBeanChar_Flying_AnimLayer::TryGetBeanCharacter()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_Flying_AnimLayer.TryGetBeanCharacter");
    
        UBeanChar_Flying_AnimLayer___TryGetBeanCharacter_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharConfigObject* UBeanChar_Grab_AnimLayer::GetConfig()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_Grab_AnimLayer.GetConfig");
    
        UBeanChar_Grab_AnimLayer___GetConfig_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    ABeanCharacter* UBeanChar_Grab_AnimLayer::TryGetBeanCharacter()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_Grab_AnimLayer.TryGetBeanCharacter");
    
        UBeanChar_Grab_AnimLayer___TryGetBeanCharacter_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharConfigObject* UBeanChar_GroundLoc_AnimInstance::GetConfig()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_GroundLoc_AnimInstance.GetConfig");
    
        UBeanChar_GroundLoc_AnimInstance___GetConfig_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    ABeanCharacter* UBeanChar_GroundLoc_AnimInstance::TryGetBeanCharacter()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_GroundLoc_AnimInstance.TryGetBeanCharacter");
    
        UBeanChar_GroundLoc_AnimInstance___TryGetBeanCharacter_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharConfigObject* UBeanChar_Idle_AnimInstance::GetConfig()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_Idle_AnimInstance.GetConfig");
    
        UBeanChar_Idle_AnimInstance___GetConfig_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    ABeanCharacter* UBeanChar_Idle_AnimInstance::TryGetBeanCharacter()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_Idle_AnimInstance.TryGetBeanCharacter");
    
        UBeanChar_Idle_AnimInstance___TryGetBeanCharacter_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharConfigObject* UBeanChar_InAirLoc_AnimInstance::GetConfig()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_InAirLoc_AnimInstance.GetConfig");
    
        UBeanChar_InAirLoc_AnimInstance___GetConfig_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    ABeanCharacter* UBeanChar_InAirLoc_AnimInstance::TryGetBeanCharacter()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_InAirLoc_AnimInstance.TryGetBeanCharacter");
    
        UBeanChar_InAirLoc_AnimInstance___TryGetBeanCharacter_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharConfigObject* UBeanChar_Jiggle_AnimInstance::GetConfig()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_Jiggle_AnimInstance.GetConfig");
    
        UBeanChar_Jiggle_AnimInstance___GetConfig_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    ABeanCharacter* UBeanChar_Jiggle_AnimInstance::TryGetBeanCharacter()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_Jiggle_AnimInstance.TryGetBeanCharacter");
    
        UBeanChar_Jiggle_AnimInstance___TryGetBeanCharacter_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharConfigObject* UBeanChar_Main_AnimInstance::GetConfig()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_Main_AnimInstance.GetConfig");
    
        UBeanChar_Main_AnimInstance___GetConfig_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    ABeanCharacter* UBeanChar_Main_AnimInstance::TryGetBeanCharacter()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_Main_AnimInstance.TryGetBeanCharacter");
    
        UBeanChar_Main_AnimInstance___TryGetBeanCharacter_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharConfigObject* UBeanChar_Ragdoll_AnimLayer::GetConfig()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_Ragdoll_AnimLayer.GetConfig");
    
        UBeanChar_Ragdoll_AnimLayer___GetConfig_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    ABeanCharacter* UBeanChar_Ragdoll_AnimLayer::TryGetBeanCharacter()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_Ragdoll_AnimLayer.TryGetBeanCharacter");
    
        UBeanChar_Ragdoll_AnimLayer___TryGetBeanCharacter_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharConfigObject* UBeanChar_Swimming_AnimLayer::GetConfig()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_Swimming_AnimLayer.GetConfig");
    
        UBeanChar_Swimming_AnimLayer___GetConfig_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    ABeanCharacter* UBeanChar_Swimming_AnimLayer::TryGetBeanCharacter()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_Swimming_AnimLayer.TryGetBeanCharacter");
    
        UBeanChar_Swimming_AnimLayer___TryGetBeanCharacter_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UBeanCharConfigObject* UBeanChar_Zipline_AnimLayer::GetConfig()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_Zipline_AnimLayer.GetConfig");
    
        UBeanChar_Zipline_AnimLayer___GetConfig_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    ABeanCharacter* UBeanChar_Zipline_AnimLayer::TryGetBeanCharacter()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanChar_Zipline_AnimLayer.TryGetBeanCharacter");
    
        UBeanChar_Zipline_AnimLayer___TryGetBeanCharacter_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBeanCheatManager::BeanAllowItemInteractionByTag(FString TagString)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCheatManager.BeanAllowItemInteractionByTag");
    
        UBeanCheatManager___BeanAllowItemInteractionByTag_Params Params{};
        Params.TagString = TagString;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCheatManager::BeanDisallowItemInteractionByTag(FString TagString)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCheatManager.BeanDisallowItemInteractionByTag");
    
        UBeanCheatManager___BeanDisallowItemInteractionByTag_Params Params{};
        Params.TagString = TagString;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCheatManager::BeanEnableBeanInEditMode(bool bEnabled)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCheatManager.BeanEnableBeanInEditMode");
    
        UBeanCheatManager___BeanEnableBeanInEditMode_Params Params{};
        Params.bEnabled = bEnabled;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCheatManager::BeanEnableGetupSpeedModifier(bool bEnabled)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCheatManager.BeanEnableGetupSpeedModifier");
    
        UBeanCheatManager___BeanEnableGetupSpeedModifier_Params Params{};
        Params.bEnabled = bEnabled;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCheatManager::BeanEnableInventoryMode(bool bEnable)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCheatManager.BeanEnableInventoryMode");
    
        UBeanCheatManager___BeanEnableInventoryMode_Params Params{};
        Params.bEnable = bEnable;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCheatManager::BeanRelockPlayerActionByTag(FString TagString)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCheatManager.BeanRelockPlayerActionByTag");
    
        UBeanCheatManager___BeanRelockPlayerActionByTag_Params Params{};
        Params.TagString = TagString;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCheatManager::BeanSetGlobalRagdollThreshold(float Threshold)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCheatManager.BeanSetGlobalRagdollThreshold");
    
        UBeanCheatManager___BeanSetGlobalRagdollThreshold_Params Params{};
        Params.Threshold = Threshold;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCheatManager::BeanToggleAbilityRestrictions(bool bApplyRestrictions)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCheatManager.BeanToggleAbilityRestrictions");
    
        UBeanCheatManager___BeanToggleAbilityRestrictions_Params Params{};
        Params.bApplyRestrictions = bApplyRestrictions;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCheatManager::BeanTogglePickupRestrictions(bool bApplyRestrictions)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCheatManager.BeanTogglePickupRestrictions");
    
        UBeanCheatManager___BeanTogglePickupRestrictions_Params Params{};
        Params.bApplyRestrictions = bApplyRestrictions;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCheatManager::BeanUnlockBuildMode(bool bUnlock)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCheatManager.BeanUnlockBuildMode");
    
        UBeanCheatManager___BeanUnlockBuildMode_Params Params{};
        Params.bUnlock = bUnlock;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCheatManager::BeanUnlockPlayerActionByTag(FString TagString)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCheatManager.BeanUnlockPlayerActionByTag");
    
        UBeanCheatManager___BeanUnlockPlayerActionByTag_Params Params{};
        Params.TagString = TagString;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeanCheatManager::RespawnAsDefaultPawn()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCheatManager.RespawnAsDefaultPawn");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBeanCheatManager::SwitchBackFromBeanPawn()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCheatManager.SwitchBackFromBeanPawn");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBeanCheatManager::SwitchToBeanPawn()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanCheatManager.SwitchToBeanPawn");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    bool IBeanLaunchPredictorInterface::ValidateLaunch(FBeanPredictedLaunch& PredictedLaunch)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanLaunchPredictorInterface.ValidateLaunch");
    
        IBeanLaunchPredictorInterface___ValidateLaunch_Params Params{};
        Params.PredictedLaunch = PredictedLaunch;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PredictedLaunch = Params.PredictedLaunch;
    
        return Params.ReturnValue;
    }

    bool UBeanstalkFunctionLibrary::CanPawnSwitchToBeanNow(AFortPlayerPawn* PlayerPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanstalkFunctionLibrary.CanPawnSwitchToBeanNow");
    
        UBeanstalkFunctionLibrary___CanPawnSwitchToBeanNow_Params Params{};
        Params.PlayerPawn = PlayerPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UBeanstalkFunctionLibrary::CanPlayerSwitchToBeanNow(AFortPlayerController* PlayerController)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanstalkFunctionLibrary.CanPlayerSwitchToBeanNow");
    
        UBeanstalkFunctionLibrary___CanPlayerSwitchToBeanNow_Params Params{};
        Params.PlayerController = PlayerController;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBeanstalkFunctionLibrary::SwitchBackFromBeanPawn(AFortPlayerController* PlayerController)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanstalkFunctionLibrary.SwitchBackFromBeanPawn");
    
        UBeanstalkFunctionLibrary___SwitchBackFromBeanPawn_Params Params{};
        Params.PlayerController = PlayerController;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UBeanstalkFunctionLibrary::SwitchToBeanPawn(AFortPlayerController* PlayerController)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.BeanstalkFunctionLibrary.SwitchToBeanPawn");
    
        UBeanstalkFunctionLibrary___SwitchToBeanPawn_Params Params{};
        Params.PlayerController = PlayerController;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortAutomationRpcManager_Beanstalk::OnBeanStateChanged_AddToHistory(EBeanCharStateID StateId, EBeanCharStateLayerID LayerID, bool bIsReplaying)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.FortAutomationRpcManager_Beanstalk.OnBeanStateChanged_AddToHistory");
    
        UFortAutomationRpcManager_Beanstalk___OnBeanStateChanged_AddToHistory_Params Params{};
        Params.StateId = StateId;
        Params.LayerID = LayerID;
        Params.bIsReplaying = bIsReplaying;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortAutomationRpcManager_Beanstalk::OnBeanStateChanged_BroadcastMessage(EBeanCharStateID StateId, EBeanCharStateLayerID LayerID, bool bIsReplaying)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.FortAutomationRpcManager_Beanstalk.OnBeanStateChanged_BroadcastMessage");
    
        UFortAutomationRpcManager_Beanstalk___OnBeanStateChanged_BroadcastMessage_Params Params{};
        Params.StateId = StateId;
        Params.LayerID = LayerID;
        Params.bIsReplaying = bIsReplaying;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortAutomationRpcManager_Beanstalk::OnBeanStateChanged_Grounded_ResetDive(EBeanCharStateID StateId, EBeanCharStateLayerID LayerID, bool bIsReplaying)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.FortAutomationRpcManager_Beanstalk.OnBeanStateChanged_Grounded_ResetDive");
    
        UFortAutomationRpcManager_Beanstalk___OnBeanStateChanged_Grounded_ResetDive_Params Params{};
        Params.StateId = StateId;
        Params.LayerID = LayerID;
        Params.bIsReplaying = bIsReplaying;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortAutomationRpcManager_Beanstalk::OnCharacterOverlap_BroadcastMessage(AActor* OverlappedActor, AActor* OtherActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.FortAutomationRpcManager_Beanstalk.OnCharacterOverlap_BroadcastMessage");
    
        UFortAutomationRpcManager_Beanstalk___OnCharacterOverlap_BroadcastMessage_Params Params{};
        Params.OverlappedActor = OverlappedActor;
        Params.OtherActor = OtherActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortAutomationRpcManager_Beanstalk::OnCharacterOverlap_Dive(AActor* OverlappedActor, AActor* OtherActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.FortAutomationRpcManager_Beanstalk.OnCharacterOverlap_Dive");
    
        UFortAutomationRpcManager_Beanstalk___OnCharacterOverlap_Dive_Params Params{};
        Params.OverlappedActor = OverlappedActor;
        Params.OtherActor = OtherActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortAutomationRpcManager_Beanstalk::OnCharacterOverlap_Jump(AActor* OverlappedActor, AActor* OtherActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeanstalkRuntime.FortAutomationRpcManager_Beanstalk.OnCharacterOverlap_Jump");
    
        UFortAutomationRpcManager_Beanstalk___OnCharacterOverlap_Jump_Params Params{};
        Params.OverlappedActor = OverlappedActor;
        Params.OtherActor = OtherActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

