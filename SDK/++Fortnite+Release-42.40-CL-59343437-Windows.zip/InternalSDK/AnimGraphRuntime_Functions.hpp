/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:09
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimGraphRuntime_Functions
 * ============================================================
 */

#include "AnimGraphRuntime.hpp"

namespace UE
{

    struct UAnimExecutionContextLibrary___ConvertToComponentSpacePoseContext_Params
    {
        FAnimExecutionContext                   Context;                        // 0x000000 (0x000010) [OutParam]
        EAnimExecutionContextConversionResult   Result;                         // 0x000010 (0x000001) [OutParam] [Default: EAnimExecutionContextConversionResult(80)]
        uint8                                   UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FAnimComponentSpacePoseContext          ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UAnimExecutionContextLibrary___ConvertToInitializationContext_Params
    {
        FAnimExecutionContext                   Context;                        // 0x000000 (0x000010) [OutParam]
        EAnimExecutionContextConversionResult   Result;                         // 0x000010 (0x000001) [OutParam] [Default: EAnimExecutionContextConversionResult(80)]
        uint8                                   UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FAnimInitializationContext              ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UAnimExecutionContextLibrary___ConvertToPoseContext_Params
    {
        FAnimExecutionContext                   Context;                        // 0x000000 (0x000010) [OutParam]
        EAnimExecutionContextConversionResult   Result;                         // 0x000010 (0x000001) [OutParam] [Default: EAnimExecutionContextConversionResult(80)]
        uint8                                   UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FAnimPoseContext                        ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UAnimExecutionContextLibrary___ConvertToUpdateContext_Params
    {
        FAnimExecutionContext                   Context;                        // 0x000000 (0x000010) [OutParam]
        EAnimExecutionContextConversionResult   Result;                         // 0x000010 (0x000001) [OutParam] [Default: EAnimExecutionContextConversionResult(80)]
        uint8                                   UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FAnimUpdateContext                      ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UAnimExecutionContextLibrary___GetAnimInstance_Params
    {
        FAnimExecutionContext   Context;        // 0x000000 (0x000010) [OutParam]
        UAnimInstance*          ReturnValue;    // 0x000010 (0x000008) [ReturnValue] [Default: 0x170B7350]
    };

    struct UAnimExecutionContextLibrary___GetAnimNodeReference_Params
    {
        UAnimInstance*      Instance;                       // 0x000000 (0x000008) [Default: 0x130A5F60]
        int32               Index;                          // 0x000008 (0x000004) [Default: 49]
        uint8               UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FAnimNodeReference  ReturnValue;                    // 0x000010 (0x000010) [ReturnValue]
    };

    struct UAnimExecutionContextLibrary___GetCurrentWeight_Params
    {
        FAnimUpdateContext  Context;        // 0x000000 (0x000010) [OutParam]
        float               ReturnValue;    // 0x000010 (0x000004) [ReturnValue] [Default: 4.50589e-25f]
    };

    struct UAnimExecutionContextLibrary___GetDeltaTime_Params
    {
        FAnimUpdateContext  Context;        // 0x000000 (0x000010) [OutParam]
        float               ReturnValue;    // 0x000010 (0x000004) [ReturnValue] [Default: 4.50589e-25f]
    };

    struct UAnimExecutionContextLibrary___IsActive_Params
    {
        FAnimExecutionContext   Context;        // 0x000000 (0x000010) [OutParam]
        bool                    ReturnValue;    // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAnimNodeRigidBodyLibrary___ConvertToRigidBodyAnimNode_Params
    {
        FAnimNodeReference                  Node;                           // 0x000000 (0x000010) [OutParam]
        EAnimNodeReferenceConversionResult  Result;                         // 0x000010 (0x000001) [OutParam] [Default: EAnimNodeReferenceConversionResult(0)]
        uint8                               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FRigidBodyAnimNodeReference         ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UAnimNodeRigidBodyLibrary___ConvertToRigidBodyAnimNodePure_Params
    {
        FAnimNodeReference          Node;               // 0x000000 (0x000010) [OutParam]
        FRigidBodyAnimNodeReference RigidBodyAnimNode;  // 0x000010 (0x000010) [OutParam]
        bool                        Result;             // 0x000020 (0x000001) [OutParam] [Default: true]
    };

    struct UAnimNodeRigidBodyLibrary___SetOverridePhysicsAsset_Params
    {
        FRigidBodyAnimNodeReference Node;           // 0x000000 (0x000010) [OutParam]
        UPhysicsAsset*              PhysicsAsset;   // 0x000010 (0x000008) [Default: 0x170CE600]
        FRigidBodyAnimNodeReference ReturnValue;    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UAnimationStateMachineLibrary___ConvertToAnimationStateMachine_Params
    {
        FAnimNodeReference                  Node;           // 0x000000 (0x000010) [OutParam]
        FAnimationStateMachineReference     AnimationState; // 0x000010 (0x000010) [OutParam]
        EAnimNodeReferenceConversionResult  Result;         // 0x000020 (0x000001) [OutParam] [Default: EAnimNodeReferenceConversionResult(187)]
    };

    struct UAnimationStateMachineLibrary___ConvertToAnimationStateMachinePure_Params
    {
        FAnimNodeReference              Node;           // 0x000000 (0x000010) [OutParam]
        FAnimationStateMachineReference AnimationState; // 0x000010 (0x000010) [OutParam]
        bool                            Result;         // 0x000020 (0x000001) [OutParam] [Default: true]
    };

    struct UAnimationStateMachineLibrary___ConvertToAnimationStateResult_Params
    {
        FAnimNodeReference                  Node;           // 0x000000 (0x000010) [OutParam]
        FAnimationStateResultReference      AnimationState; // 0x000010 (0x000010) [OutParam]
        EAnimNodeReferenceConversionResult  Result;         // 0x000020 (0x000001) [OutParam] [Default: EAnimNodeReferenceConversionResult(187)]
    };

    struct UAnimationStateMachineLibrary___ConvertToAnimationStateResultPure_Params
    {
        FAnimNodeReference              Node;           // 0x000000 (0x000010) [OutParam]
        FAnimationStateResultReference  AnimationState; // 0x000010 (0x000010) [OutParam]
        bool                            Result;         // 0x000020 (0x000001) [OutParam] [Default: true]
    };

    struct UAnimationStateMachineLibrary___GetRelevantAnimTimeRemaining_Params
    {
        FAnimUpdateContext              UpdateContext;  // 0x000000 (0x000010) [OutParam]
        FAnimationStateResultReference  Node;           // 0x000010 (0x000010) [OutParam]
        float                           ReturnValue;    // 0x000020 (0x000004) [ReturnValue] [Default: -1.04208e+36f]
    };

    struct UAnimationStateMachineLibrary___GetRelevantAnimTimeRemainingFraction_Params
    {
        FAnimUpdateContext              UpdateContext;  // 0x000000 (0x000010) [OutParam]
        FAnimationStateResultReference  Node;           // 0x000010 (0x000010) [OutParam]
        float                           ReturnValue;    // 0x000020 (0x000004) [ReturnValue] [Default: -1.04208e+36f]
    };

    struct UAnimationStateMachineLibrary___GetState_Params
    {
        FAnimUpdateContext              UpdateContext;  // 0x000000 (0x000010) [OutParam]
        FAnimationStateMachineReference Node;           // 0x000010 (0x000010) [OutParam]
        FName                           ReturnValue;    // 0x000020 (0x000004) [ReturnValue] [Default: FName(-79121733) -> L"Default__AnimationStateMachineLibrary"]
    };

    struct UAnimationStateMachineLibrary___IsStateBlendingIn_Params
    {
        FAnimUpdateContext              UpdateContext;  // 0x000000 (0x000010) [OutParam]
        FAnimationStateResultReference  Node;           // 0x000010 (0x000010) [OutParam]
        bool                            ReturnValue;    // 0x000020 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAnimationStateMachineLibrary___IsStateBlendingOut_Params
    {
        FAnimUpdateContext              UpdateContext;  // 0x000000 (0x000010) [OutParam]
        FAnimationStateResultReference  Node;           // 0x000010 (0x000010) [OutParam]
        bool                            ReturnValue;    // 0x000020 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAnimationStateMachineLibrary___SetState_Params
    {
        FAnimUpdateContext                  UpdateContext;                  // 0x000000 (0x000010) [OutParam]
        FAnimationStateMachineReference     Node;                           // 0x000010 (0x000010) [OutParam]
        FName                               TargetState;                    // 0x000020 (0x000004) [Default: FName(-79121733) -> L"Default__AnimationStateMachineLibrary"]
        float                               duration;                       // 0x000024 (0x000004) [Default: 0f]
        TEnumAsByte<ETransitionLogicType>   BlendType;                      // 0x000028 (0x000001) [Default: 96]
        uint8                               UnknownData_000029[0x000007];   // 0x000029 (0x000007)
        UBlendProfile*                      BlendProfile;                   // 0x000030 (0x000008) [Default: 0x7C2218DD00000031]
        EAlphaBlendOption                   AlphaBlendOption;               // 0x000038 (0x000001) [Default: EAlphaBlendOption(240)]
        uint8                               UnknownData_000039[0x000007];   // 0x000039 (0x000007)
        UCurveFloat*                        CustomBlendCurve;               // 0x000040 (0x000008) [Default: 0x170B2C50]
    };

    struct UBlendListBaseLibrary___ConvertToBlendListBase_Params
    {
        FAnimNodeReference                  Node;                           // 0x000000 (0x000010) [OutParam]
        EAnimNodeReferenceConversionResult  Result;                         // 0x000010 (0x000001) [OutParam] [Default: EAnimNodeReferenceConversionResult(240)]
        uint8                               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FBlendListBaseReference             ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UBlendListBaseLibrary___ResetNode_Params
    {
        FBlendListBaseReference BlendListBase;  // 0x000000 (0x000010) [OutParam]
    };

    struct UBlendSpaceLibrary___ConvertToBlendSpace_Params
    {
        FAnimNodeReference                  Node;                           // 0x000000 (0x000010) [OutParam]
        EAnimNodeReferenceConversionResult  Result;                         // 0x000010 (0x000001) [OutParam] [Default: EAnimNodeReferenceConversionResult(240)]
        uint8                               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FBlendSpaceReference                ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UBlendSpaceLibrary___ConvertToBlendSpacePure_Params
    {
        FAnimNodeReference      Node;       // 0x000000 (0x000010) [OutParam]
        FBlendSpaceReference    BlendSpace; // 0x000010 (0x000010) [OutParam]
        bool                    Result;     // 0x000020 (0x000001) [OutParam] [Default: true]
    };

    struct UBlendSpaceLibrary___GetFilteredPosition_Params
    {
        FBlendSpaceReference    BlendSpace;     // 0x000000 (0x000010) [OutParam]
        FVector                 ReturnValue;    // 0x000010 (0x000018) [ReturnValue]
    };

    struct UBlendSpaceLibrary___GetPosition_Params
    {
        FBlendSpaceReference    BlendSpace;     // 0x000000 (0x000010) [OutParam]
        FVector                 ReturnValue;    // 0x000010 (0x000018) [ReturnValue]
    };

    struct UBlendSpaceLibrary___SnapToPosition_Params
    {
        FBlendSpaceReference    BlendSpace;     // 0x000000 (0x000010) [OutParam]
        FVector                 NewPosition;    // 0x000010 (0x000018)
    };

    struct UBlendSpacePlayerLibrary___ConvertToBlendSpacePlayer_Params
    {
        FAnimNodeReference                  Node;                           // 0x000000 (0x000010) [OutParam]
        EAnimNodeReferenceConversionResult  Result;                         // 0x000010 (0x000001) [OutParam] [Default: EAnimNodeReferenceConversionResult(160)]
        uint8                               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FBlendSpacePlayerReference          ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UBlendSpacePlayerLibrary___ConvertToBlendSpacePlayerPure_Params
    {
        FAnimNodeReference          Node;               // 0x000000 (0x000010) [OutParam]
        FBlendSpacePlayerReference  BlendSpacePlayer;   // 0x000010 (0x000010) [OutParam]
        bool                        Result;             // 0x000020 (0x000001) [OutParam] [Default: true]
    };

    struct UBlendSpacePlayerLibrary___GetAccumulatedTime_Params
    {
        FBlendSpacePlayerReference  BlendSpacePlayer;   // 0x000000 (0x000010) [OutParam]
        float                       ReturnValue;        // 0x000010 (0x000004) [ReturnValue] [Default: 4.53369e-25f]
    };

    struct UBlendSpacePlayerLibrary___GetBlendSpace_Params
    {
        FBlendSpacePlayerReference  BlendSpacePlayer;   // 0x000000 (0x000010) [OutParam]
        UBlendSpace*                ReturnValue;        // 0x000010 (0x000008) [ReturnValue] [Default: 0x170C4FA0]
    };

    struct UBlendSpacePlayerLibrary___GetLoop_Params
    {
        FBlendSpacePlayerReference  BlendSpacePlayer;   // 0x000000 (0x000010) [OutParam]
        bool                        ReturnValue;        // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBlendSpacePlayerLibrary___GetPlayRate_Params
    {
        FBlendSpacePlayerReference  BlendSpacePlayer;   // 0x000000 (0x000010) [OutParam]
        float                       ReturnValue;        // 0x000010 (0x000004) [ReturnValue] [Default: 4.53369e-25f]
    };

    struct UBlendSpacePlayerLibrary___GetPosition_Params
    {
        FBlendSpacePlayerReference  BlendSpacePlayer;   // 0x000000 (0x000010) [OutParam]
        FVector                     ReturnValue;        // 0x000010 (0x000018) [ReturnValue]
    };

    struct UBlendSpacePlayerLibrary___GetStartPosition_Params
    {
        FBlendSpacePlayerReference  BlendSpacePlayer;   // 0x000000 (0x000010) [OutParam]
        float                       ReturnValue;        // 0x000010 (0x000004) [ReturnValue] [Default: 4.53369e-25f]
    };

    struct UBlendSpacePlayerLibrary___SetAccumulatedTime_Params
    {
        FBlendSpacePlayerReference  BlendSpacePlayer;               // 0x000000 (0x000010) [OutParam]
        float                       time;                           // 0x000010 (0x000004) [Default: 4.53369e-25f]
        uint8                       UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        FBlendSpacePlayerReference  ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UBlendSpacePlayerLibrary___SetBlendSpace_Params
    {
        FBlendSpacePlayerReference  BlendSpacePlayer;   // 0x000000 (0x000010) [OutParam]
        UBlendSpace*                BlendSpace;         // 0x000010 (0x000008) [Default: 0x170C4FA0]
        FBlendSpacePlayerReference  ReturnValue;        // 0x000018 (0x000010) [ReturnValue]
    };

    struct UBlendSpacePlayerLibrary___SetBlendSpaceWithInertialBlending_Params
    {
        FAnimUpdateContext          UpdateContext;                  // 0x000000 (0x000010) [OutParam]
        FBlendSpacePlayerReference  BlendSpacePlayer;               // 0x000010 (0x000010) [OutParam]
        UBlendSpace*                BlendSpace;                     // 0x000020 (0x000008) [Default: 0xA948B2BB]
        float                       BlendTime;                      // 0x000028 (0x000004) [Default: 1.74651e-27f]
        uint8                       UnknownData_00002C[0x000004];   // 0x00002C (0x000004)
        FBlendSpacePlayerReference  ReturnValue;                    // 0x000030 (0x000010) [ReturnValue]
    };

    struct UBlendSpacePlayerLibrary___SetLoop_Params
    {
        FBlendSpacePlayerReference  BlendSpacePlayer;               // 0x000000 (0x000010) [OutParam]
        bool                        bLoop;                          // 0x000010 (0x000001) [Default: true]
        uint8                       UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FBlendSpacePlayerReference  ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UBlendSpacePlayerLibrary___SetPlayRate_Params
    {
        FBlendSpacePlayerReference  BlendSpacePlayer;               // 0x000000 (0x000010) [OutParam]
        float                       PlayRate;                       // 0x000010 (0x000004) [Default: 4.53369e-25f]
        uint8                       UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        FBlendSpacePlayerReference  ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UBlendSpacePlayerLibrary___SetResetPlayTimeWhenBlendSpaceChanges_Params
    {
        FBlendSpacePlayerReference  BlendSpacePlayer;               // 0x000000 (0x000010) [OutParam]
        bool                        bReset;                         // 0x000010 (0x000001) [Default: true]
        uint8                       UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FBlendSpacePlayerReference  ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UBlendSpacePlayerLibrary___ShouldResetPlayTimeWhenBlendSpaceChanges_Params
    {
        FBlendSpacePlayerReference  BlendSpacePlayer;   // 0x000000 (0x000010) [OutParam]
        bool                        ReturnValue;        // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBlendSpacePlayerLibrary___SnapToPosition_Params
    {
        FBlendSpacePlayerReference  BlendSpacePlayer;   // 0x000000 (0x000010) [OutParam]
        FVector                     NewPosition;        // 0x000010 (0x000018)
    };

    struct UKismetAnimationLibrary___CalculateDirection_Params
    {
        FVector     Velocity;       // 0x000000 (0x000018) [OutParam]
        FRotator    BaseRotation;   // 0x000018 (0x000018) [OutParam]
        float       ReturnValue;    // 0x000030 (0x000004) [ReturnValue] [Default: 6.86636e-44f]
    };

    struct UKismetAnimationLibrary___K2_CalculateVelocityFromPositionHistory_Params
    {
        float               DeltaSeconds;                   // 0x000000 (0x000004) [Default: 1.74651e-27f]
        uint8               UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FVector             Position;                       // 0x000008 (0x000018)
        FPositionHistory    History;                        // 0x000020 (0x000030) [OutParam]
        int32               NumberOfSamples;                // 0x000050 (0x000004) [Default: 319446880]
        float               VelocityMin;                    // 0x000054 (0x000004) [Default: 0f]
        float               VelocityMax;                    // 0x000058 (0x000004) [Default: 6.86636e-44f]
        float               ReturnValue;                    // 0x00005C (0x000004) [ReturnValue] [Default: 3.28772e+33f]
    };

    struct UKismetAnimationLibrary___K2_CalculateVelocityFromSockets_Params
    {
        float                                   DeltaSeconds;                   // 0x000000 (0x000004) [Default: 1.74651e-27f]
        uint8                                   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        USkeletalMeshComponent*                 Component;                      // 0x000008 (0x000008) [Default: 0x792218DD00000031]
        FName                                   SocketOrBoneName;               // 0x000010 (0x000004) [Default: FName(386747952) -> L""]
        FName                                   ReferenceSocketOrBone;          // 0x000014 (0x000004) [Default: NAME_None]
        TEnumAsByte<ERelativeTransformSpace>    SocketSpace;                    // 0x000018 (0x000001) [Default: 80]
        uint8                                   UnknownData_000019[0x000007];   // 0x000019 (0x000007)
        FVector                                 OffsetInBoneSpace;              // 0x000020 (0x000018)
        FPositionHistory                        History;                        // 0x000038 (0x000030) [OutParam]
        int32                                   NumberOfSamples;                // 0x000068 (0x000004) [Default: 386608208]
        float                                   VelocityMin;                    // 0x00006C (0x000004) [Default: 0f]
        float                                   VelocityMax;                    // 0x000070 (0x000004) [Default: -1.62123e-25f]
        EEasingFuncType                         EasingType;                     // 0x000074 (0x000001) [Default: EEasingFuncType(0)]
        uint8                                   UnknownData_000075[0x000003];   // 0x000075 (0x000003)
        FRuntimeFloatCurve                      CustomCurve;                    // 0x000078 (0x000048) [OutParam]
        float                                   ReturnValue;                    // 0x0000C0 (0x000004) [ReturnValue] [Default: 4.13149e+33f]
    };

    struct UKismetAnimationLibrary___K2_DirectionBetweenSockets_Params
    {
        USkeletalMeshComponent* Component;              // 0x000000 (0x000008) [Default: 0x130A5F60]
        FName                   SocketOrBoneNameFrom;   // 0x000008 (0x000004) [Default: FName(49) -> L""]
        FName                   SocketOrBoneNameTo;     // 0x00000C (0x000004) [Default: FName(2032277725) -> L""]
        FVector                 ReturnValue;            // 0x000010 (0x000018) [ReturnValue]
    };

    struct UKismetAnimationLibrary___K2_DistanceBetweenTwoSocketsAndMapRange_Params
    {
        USkeletalMeshComponent*                 Component;                      // 0x000000 (0x000008) [Default: 0x130A5F60]
        FName                                   SocketOrBoneNameA;              // 0x000008 (0x000004) [Default: FName(49) -> L""]
        TEnumAsByte<ERelativeTransformSpace>    SocketSpaceA;                   // 0x00000C (0x000001) [Default: 221]
        uint8                                   UnknownData_00000D[0x000003];   // 0x00000D (0x000003)
        FName                                   SocketOrBoneNameB;              // 0x000010 (0x000004) [Default: FName(386747952) -> L""]
        TEnumAsByte<ERelativeTransformSpace>    SocketSpaceB;                   // 0x000014 (0x000001) [Default: 0]
        bool                                    bRemapRange;                    // 0x000015 (0x000001) [Default: false]
        uint8                                   UnknownData_000016[0x000002];   // 0x000016 (0x000002)
        float                                   InRangeMin;                     // 0x000018 (0x000004) [Default: 4.49693e-25f]
        float                                   InRangeMax;                     // 0x00001C (0x000004) [Default: 0f]
        float                                   OutRangeMin;                    // 0x000020 (0x000004) [Default: -4.78502e-05f]
        float                                   OutRangeMax;                    // 0x000024 (0x000004) [Default: 0f]
        float                                   ReturnValue;                    // 0x000028 (0x000004) [ReturnValue] [Default: 1.74651e-27f]
    };

    struct UKismetAnimationLibrary___K2_EndProfilingTimer_Params
    {
        bool    bLog;                           // 0x000000 (0x000001) [Default: true]
        uint8   UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        FString LogPrefix;                      // 0x000008 (0x000010) [Default: L""]
        float   ReturnValue;                    // 0x000018 (0x000004) [ReturnValue] [Default: 4.49693e-25f]
    };

    struct UKismetAnimationLibrary___K2_LookAt_Params
    {
        FTransform  CurrentTransform;               // 0x000000 (0x000060) [OutParam]
        FVector     TargetPosition;                 // 0x000060 (0x000018) [OutParam]
        FVector     LookAtVector;                   // 0x000078 (0x000018)
        bool        bUseUpVector;                   // 0x000090 (0x000001) [Default: true]
        uint8       UnknownData_000091[0x000007];   // 0x000091 (0x000007)
        FVector     UpVector;                       // 0x000098 (0x000018)
        float       ClampConeInDegree;              // 0x0000B0 (0x000004) [Default: 4.57356e-25f]
        uint8       UnknownData_0000B4[0x00000C];   // 0x0000B4 (0x00000C)
        FTransform  ReturnValue;                    // 0x0000C0 (0x000060) [ReturnValue]
    };

    struct UKismetAnimationLibrary___K2_MakePerlinNoiseAndRemap_Params
    {
        float   Value;          // 0x000000 (0x000004) [Default: 1.74651e-27f]
        float   RangeOutMin;    // 0x000004 (0x000004) [Default: 0f]
        float   RangeOutMax;    // 0x000008 (0x000004) [Default: 6.86636e-44f]
        float   ReturnValue;    // 0x00000C (0x000004) [ReturnValue] [Default: 5.26035e+34f]
    };

    struct UKismetAnimationLibrary___K2_MakePerlinNoiseVectorAndRemap_Params
    {
        float   X;                              // 0x000000 (0x000004) [Default: 1.74651e-27f]
        float   Y;                              // 0x000004 (0x000004) [Default: 0f]
        float   Z;                              // 0x000008 (0x000004) [Default: 6.86636e-44f]
        float   RangeOutMinX;                   // 0x00000C (0x000004) [Default: 5.26035e+34f]
        float   RangeOutMaxX;                   // 0x000010 (0x000004) [Default: 4.56582e-25f]
        float   RangeOutMinY;                   // 0x000014 (0x000004) [Default: 0f]
        float   RangeOutMaxY;                   // 0x000018 (0x000004) [Default: 4.49693e-25f]
        float   RangeOutMinZ;                   // 0x00001C (0x000004) [Default: 0f]
        float   RangeOutMaxZ;                   // 0x000020 (0x000004) [Default: -4.78502e-05f]
        uint8   UnknownData_000024[0x000004];   // 0x000024 (0x000004)
        FVector ReturnValue;                    // 0x000028 (0x000018) [ReturnValue]
    };

    struct UKismetAnimationLibrary___K2_TwoBoneIK_Params
    {
        FVector RootPos;                        // 0x000000 (0x000018) [OutParam]
        FVector JointPos;                       // 0x000018 (0x000018) [OutParam]
        FVector EndPos;                         // 0x000030 (0x000018) [OutParam]
        FVector JointTarget;                    // 0x000048 (0x000018) [OutParam]
        FVector Effector;                       // 0x000060 (0x000018) [OutParam]
        FVector OutJointPos;                    // 0x000078 (0x000018) [OutParam]
        FVector OutEndPos;                      // 0x000090 (0x000018) [OutParam]
        bool    bAllowStretching;               // 0x0000A8 (0x000001) [Default: true]
        uint8   UnknownData_0000A9[0x000003];   // 0x0000A9 (0x000003)
        float   StartStretchRatio;              // 0x0000AC (0x000004) [Default: 2.05483e+32f]
        float   MaxStretchScale;                // 0x0000B0 (0x000004) [Default: 4.57356e-25f]
    };

    struct ULayeredBoneBlendLibrary___ConvertToLayeredBlendPerBonePure_Params
    {
        FAnimNodeReference          Node;               // 0x000000 (0x000010) [OutParam]
        FLayeredBoneBlendReference  LayeredBoneBlend;   // 0x000010 (0x000010) [OutParam]
        bool                        Result;             // 0x000020 (0x000001) [OutParam] [Default: true]
    };

    struct ULayeredBoneBlendLibrary___ConvertToLayeredBoneBlend_Params
    {
        FAnimNodeReference                  Node;                           // 0x000000 (0x000010) [OutParam]
        EAnimNodeReferenceConversionResult  Result;                         // 0x000010 (0x000001) [OutParam] [Default: EAnimNodeReferenceConversionResult(176)]
        uint8                               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FLayeredBoneBlendReference          ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct ULayeredBoneBlendLibrary___GetNumPoses_Params
    {
        FLayeredBoneBlendReference  LayeredBoneBlend;   // 0x000000 (0x000010) [OutParam]
        int32                       ReturnValue;        // 0x000010 (0x000004) [ReturnValue] [Default: 386751152]
    };

    struct ULayeredBoneBlendLibrary___SetBlendMask_Params
    {
        FAnimUpdateContext          UpdateContext;      // 0x000000 (0x000010) [OutParam]
        FLayeredBoneBlendReference  LayeredBoneBlend;   // 0x000010 (0x000010) [OutParam]
        int32                       PoseIndex;          // 0x000020 (0x000004) [Default: -2025278789]
        FName                       BlendMaskName;      // 0x000024 (0x000004) [Default: NAME_None]
        FLayeredBoneBlendReference  ReturnValue;        // 0x000028 (0x000010) [ReturnValue]
    };

    struct ULinkedAnimGraphLibrary___ConvertToLinkedAnimGraph_Params
    {
        FAnimNodeReference                  Node;                           // 0x000000 (0x000010) [OutParam]
        EAnimNodeReferenceConversionResult  Result;                         // 0x000010 (0x000001) [OutParam] [Default: EAnimNodeReferenceConversionResult(240)]
        uint8                               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FLinkedAnimGraphReference           ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct ULinkedAnimGraphLibrary___ConvertToLinkedAnimGraphPure_Params
    {
        FAnimNodeReference          Node;               // 0x000000 (0x000010) [OutParam]
        FLinkedAnimGraphReference   LinkedAnimGraph;    // 0x000010 (0x000010) [OutParam]
        bool                        Result;             // 0x000020 (0x000001) [OutParam] [Default: true]
    };

    struct ULinkedAnimGraphLibrary___GetLinkedAnimInstance_Params
    {
        FLinkedAnimGraphReference   Node;           // 0x000000 (0x000010) [OutParam]
        UAnimInstance*              ReturnValue;    // 0x000010 (0x000008) [ReturnValue] [Default: 0x170D65F0]
    };

    struct ULinkedAnimGraphLibrary___HasLinkedAnimInstance_Params
    {
        FLinkedAnimGraphReference   Node;           // 0x000000 (0x000010) [OutParam]
        bool                        ReturnValue;    // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct UMirrorAnimLibrary___ConvertToMirrorNode_Params
    {
        FAnimNodeReference                  Node;                           // 0x000000 (0x000010) [OutParam]
        EAnimNodeReferenceConversionResult  Result;                         // 0x000010 (0x000001) [OutParam] [Default: EAnimNodeReferenceConversionResult(144)]
        uint8                               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FMirrorAnimNodeReference            ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UMirrorAnimLibrary___ConvertToMirrorNodePure_Params
    {
        FAnimNodeReference          Node;       // 0x000000 (0x000010) [OutParam]
        FMirrorAnimNodeReference    MirrorNode; // 0x000010 (0x000010) [OutParam]
        bool                        Result;     // 0x000020 (0x000001) [OutParam] [Default: true]
    };

    struct UMirrorAnimLibrary___GetMirror_Params
    {
        FMirrorAnimNodeReference    MirrorNode;     // 0x000000 (0x000010) [OutParam]
        bool                        ReturnValue;    // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct UMirrorAnimLibrary___GetMirrorDataTable_Params
    {
        FMirrorAnimNodeReference    MirrorNode;     // 0x000000 (0x000010) [OutParam]
        UMirrorDataTable*           ReturnValue;    // 0x000010 (0x000008) [ReturnValue] [Default: 0x170D7790]
    };

    struct UMirrorAnimLibrary___GetMirrorTransitionBlendTime_Params
    {
        FMirrorAnimNodeReference    MirrorNode;     // 0x000000 (0x000010) [OutParam]
        float                       ReturnValue;    // 0x000010 (0x000004) [ReturnValue] [Default: 4.57105e-25f]
    };

    struct UMirrorAnimLibrary___SetMirror_Params
    {
        FMirrorAnimNodeReference    MirrorNode;                     // 0x000000 (0x000010) [OutParam]
        bool                        bInMirror;                      // 0x000010 (0x000001) [Default: true]
        uint8                       UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FMirrorAnimNodeReference    ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UMirrorAnimLibrary___SetMirrorTransitionBlendTime_Params
    {
        FMirrorAnimNodeReference    MirrorNode;                     // 0x000000 (0x000010) [OutParam]
        float                       InBlendTime;                    // 0x000010 (0x000004) [Default: 4.57105e-25f]
        uint8                       UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        FMirrorAnimNodeReference    ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UModifyCurveAnimLibrary___ConvertToModifyCurveNode_Params
    {
        FAnimNodeReference                  Node;                           // 0x000000 (0x000010) [OutParam]
        EAnimNodeReferenceConversionResult  Result;                         // 0x000010 (0x000001) [OutParam] [Default: EAnimNodeReferenceConversionResult(128)]
        uint8                               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FModifyCurveAnimNodeReference       ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UModifyCurveAnimLibrary___ConvertToModifyCurveNodePure_Params
    {
        FAnimNodeReference              Node;               // 0x000000 (0x000010) [OutParam]
        FModifyCurveAnimNodeReference   ModifyCurveNode;    // 0x000010 (0x000010) [OutParam]
        bool                            Result;             // 0x000020 (0x000001) [OutParam] [Default: true]
    };

    struct UModifyCurveAnimLibrary___GetAlpha_Params
    {
        FModifyCurveAnimNodeReference   ModifyCurveNode;    // 0x000000 (0x000010) [OutParam]
        float                           ReturnValue;        // 0x000010 (0x000004) [ReturnValue] [Default: 4.57356e-25f]
    };

    struct UModifyCurveAnimLibrary___GetApplyMode_Params
    {
        FModifyCurveAnimNodeReference   ModifyCurveNode;    // 0x000000 (0x000010) [OutParam]
        EModifyCurveApplyMode           ReturnValue;        // 0x000010 (0x000001) [ReturnValue] [Default: EModifyCurveApplyMode(128)]
    };

    struct UModifyCurveAnimLibrary___SetAlpha_Params
    {
        FModifyCurveAnimNodeReference   ModifyCurveNode;                // 0x000000 (0x000010) [OutParam]
        float                           InAlpha;                        // 0x000010 (0x000004) [Default: 4.57356e-25f]
        uint8                           UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        FModifyCurveAnimNodeReference   ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UModifyCurveAnimLibrary___SetApplyMode_Params
    {
        FModifyCurveAnimNodeReference   ModifyCurveNode;                // 0x000000 (0x000010) [OutParam]
        EModifyCurveApplyMode           InMode;                         // 0x000010 (0x000001) [Default: EModifyCurveApplyMode(128)]
        uint8                           UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FModifyCurveAnimNodeReference   ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UModifyCurveAnimLibrary___SetCurveMap_Params
    {
        FModifyCurveAnimNodeReference   ModifyCurveNode;    // 0x000000 (0x000010) [OutParam]
        TMap<FName, float>              InCurveMap;         // 0x000010 (0x000010) [OutParam]
        FModifyCurveAnimNodeReference   ReturnValue;        // 0x000020 (0x000010) [ReturnValue]
    };

    struct UPlayMontageCallbackProxy___CreateProxyObjectForPlayMontage_Params
    {
        USkeletalMeshComponent*     InSkeletalMeshComponent;        // 0x000000 (0x000008) [Default: 0x132DA890]
        UAnimMontage*               MontageToPlay;                  // 0x000008 (0x000008) [Default: 0x932A18DD00000031]
        float                       PlayRate;                       // 0x000010 (0x000004) [Default: 4.57566e-25f]
        float                       StartingPosition;               // 0x000014 (0x000004) [Default: 0f]
        FName                       StartingSection;                // 0x000018 (0x000004) [Default: FName(386608208) -> L""]
        bool                        bShouldStopAllMontages;         // 0x00001C (0x000001) [Default: false]
        uint8                       UnknownData_00001D[0x000003];   // 0x00001D (0x000003)
        UPlayMontageCallbackProxy*  ReturnValue;                    // 0x000020 (0x000008) [ReturnValue] [Default: 0x95A5B3BB]
    };

    struct UPlayMontageCallbackProxy___OnMontageBlendingOut_Params
    {
        UAnimMontage*   Montage;        // 0x000000 (0x000008) [Default: 0x132DA890]
        bool            bInterrupted;   // 0x000008 (0x000001) [Default: true]
    };

    struct UPlayMontageCallbackProxy___OnMontageEnded_Params
    {
        UAnimMontage*   Montage;        // 0x000000 (0x000008) [Default: 0x132DA890]
        bool            bInterrupted;   // 0x000008 (0x000001) [Default: true]
    };

    struct UPlayMontageCallbackProxy___OnNotifyBeginReceived_Params
    {
        FName                           NotifyName;                     // 0x000000 (0x000004) [Default: FName(321759376) -> L""]
        uint8                           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FBranchingPointNotifyPayload    BranchingPointNotifyPayload;    // 0x000008 (0x000020) [OutParam]
    };

    struct UPlayMontageCallbackProxy___OnNotifyEndReceived_Params
    {
        FName                           NotifyName;                     // 0x000000 (0x000004) [Default: FName(321759376) -> L""]
        uint8                           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FBranchingPointNotifyPayload    BranchingPointNotifyPayload;    // 0x000008 (0x000020) [OutParam]
    };

    struct USequenceEvaluatorLibrary___AdvanceTime_Params
    {
        FAnimUpdateContext          UpdateContext;                  // 0x000000 (0x000010) [OutParam]
        FSequenceEvaluatorReference SequenceEvaluator;              // 0x000010 (0x000010) [OutParam]
        float                       PlayRate;                       // 0x000020 (0x000004) [Default: 13036.7f]
        uint8                       UnknownData_000024[0x000004];   // 0x000024 (0x000004)
        FSequenceEvaluatorReference ReturnValue;                    // 0x000028 (0x000010) [ReturnValue]
    };

    struct USequenceEvaluatorLibrary___ConvertToSequenceEvaluator_Params
    {
        FAnimNodeReference                  Node;                           // 0x000000 (0x000010) [OutParam]
        EAnimNodeReferenceConversionResult  Result;                         // 0x000010 (0x000001) [OutParam] [Default: EAnimNodeReferenceConversionResult(64)]
        uint8                               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FSequenceEvaluatorReference         ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct USequenceEvaluatorLibrary___ConvertToSequenceEvaluatorPure_Params
    {
        FAnimNodeReference          Node;               // 0x000000 (0x000010) [OutParam]
        FSequenceEvaluatorReference SequenceEvaluator;  // 0x000010 (0x000010) [OutParam]
        bool                        Result;             // 0x000020 (0x000001) [OutParam] [Default: true]
    };

    struct USequenceEvaluatorLibrary___GetAccumulatedTime_Params
    {
        FSequenceEvaluatorReference SequenceEvaluator;  // 0x000000 (0x000010) [OutParam]
        float                       ReturnValue;        // 0x000010 (0x000004) [ReturnValue] [Default: 4.58073e-25f]
    };

    struct USequenceEvaluatorLibrary___GetSequence_Params
    {
        FSequenceEvaluatorReference SequenceEvaluator;  // 0x000000 (0x000010) [OutParam]
        UAnimSequenceBase*          ReturnValue;        // 0x000010 (0x000008) [ReturnValue] [Default: 0x170DC440]
    };

    struct USequenceEvaluatorLibrary___SetExplicitFrame_Params
    {
        FSequenceEvaluatorReference SequenceEvaluator;              // 0x000000 (0x000010) [OutParam]
        int32                       Frame;                          // 0x000010 (0x000004) [Default: 386778176]
        uint8                       UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        FSequenceEvaluatorReference ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct USequenceEvaluatorLibrary___SetExplicitTime_Params
    {
        FSequenceEvaluatorReference SequenceEvaluator;              // 0x000000 (0x000010) [OutParam]
        float                       time;                           // 0x000010 (0x000004) [Default: 4.58073e-25f]
        uint8                       UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        FSequenceEvaluatorReference ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct USequenceEvaluatorLibrary___SetSequence_Params
    {
        FSequenceEvaluatorReference SequenceEvaluator;  // 0x000000 (0x000010) [OutParam]
        UAnimSequenceBase*          Sequence;           // 0x000010 (0x000008) [Default: 0x170DC440]
        FSequenceEvaluatorReference ReturnValue;        // 0x000018 (0x000010) [ReturnValue]
    };

    struct USequenceEvaluatorLibrary___SetSequenceWithInertialBlending_Params
    {
        FAnimUpdateContext          UpdateContext;                  // 0x000000 (0x000010) [OutParam]
        FSequenceEvaluatorReference SequenceEvaluator;              // 0x000010 (0x000010) [OutParam]
        UAnimSequenceBase*          Sequence;                       // 0x000020 (0x000008) [Default: 0x464BB2BB]
        float                       BlendTime;                      // 0x000028 (0x000004) [Default: 1.74651e-27f]
        uint8                       UnknownData_00002C[0x000004];   // 0x00002C (0x000004)
        FSequenceEvaluatorReference ReturnValue;                    // 0x000030 (0x000010) [ReturnValue]
    };

    struct USequencePlayerLibrary___ComputePlayRateFromDuration_Params
    {
        FSequencePlayerReference    SequencePlayer; // 0x000000 (0x000010) [OutParam]
        float                       duration;       // 0x000010 (0x000004) [Default: 4.58493e-25f]
        float                       ReturnValue;    // 0x000014 (0x000004) [ReturnValue] [Default: 0f]
    };

    struct USequencePlayerLibrary___ConvertToSequencePlayer_Params
    {
        FAnimNodeReference                  Node;                           // 0x000000 (0x000010) [OutParam]
        EAnimNodeReferenceConversionResult  Result;                         // 0x000010 (0x000001) [OutParam] [Default: EAnimNodeReferenceConversionResult(144)]
        uint8                               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FSequencePlayerReference            ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct USequencePlayerLibrary___ConvertToSequencePlayerPure_Params
    {
        FAnimNodeReference          Node;           // 0x000000 (0x000010) [OutParam]
        FSequencePlayerReference    SequencePlayer; // 0x000010 (0x000010) [OutParam]
        bool                        Result;         // 0x000020 (0x000001) [OutParam] [Default: true]
    };

    struct USequencePlayerLibrary___GetAccumulatedTime_Params
    {
        FSequencePlayerReference    SequencePlayer; // 0x000000 (0x000010) [OutParam]
        float                       ReturnValue;    // 0x000010 (0x000004) [ReturnValue] [Default: 4.58493e-25f]
    };

    struct USequencePlayerLibrary___GetLoopAnimation_Params
    {
        FSequencePlayerReference    SequencePlayer; // 0x000000 (0x000010) [OutParam]
        bool                        ReturnValue;    // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct USequencePlayerLibrary___GetPlayRate_Params
    {
        FSequencePlayerReference    SequencePlayer; // 0x000000 (0x000010) [OutParam]
        float                       ReturnValue;    // 0x000010 (0x000004) [ReturnValue] [Default: 4.58493e-25f]
    };

    struct USequencePlayerLibrary___GetSequence_Params
    {
        FSequencePlayerReference    SequencePlayer; // 0x000000 (0x000010) [OutParam]
        UAnimSequenceBase*          SequenceBase;   // 0x000010 (0x000008) [OutParam] [Default: 0x170DE590]
        FSequencePlayerReference    ReturnValue;    // 0x000018 (0x000010) [ReturnValue]
    };

    struct USequencePlayerLibrary___GetSequencePure_Params
    {
        FSequencePlayerReference    SequencePlayer; // 0x000000 (0x000010) [OutParam]
        UAnimSequenceBase*          ReturnValue;    // 0x000010 (0x000008) [ReturnValue] [Default: 0x170DE590]
    };

    struct USequencePlayerLibrary___GetStartPosition_Params
    {
        FSequencePlayerReference    SequencePlayer; // 0x000000 (0x000010) [OutParam]
        float                       ReturnValue;    // 0x000010 (0x000004) [ReturnValue] [Default: 4.58493e-25f]
    };

    struct USequencePlayerLibrary___SetAccumulatedTime_Params
    {
        FSequencePlayerReference    SequencePlayer;                 // 0x000000 (0x000010) [OutParam]
        float                       time;                           // 0x000010 (0x000004) [Default: 4.58493e-25f]
        uint8                       UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        FSequencePlayerReference    ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct USequencePlayerLibrary___SetPlayRate_Params
    {
        FSequencePlayerReference    SequencePlayer;                 // 0x000000 (0x000010) [OutParam]
        float                       PlayRate;                       // 0x000010 (0x000004) [Default: 4.58493e-25f]
        uint8                       UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        FSequencePlayerReference    ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct USequencePlayerLibrary___SetSequence_Params
    {
        FSequencePlayerReference    SequencePlayer; // 0x000000 (0x000010) [OutParam]
        UAnimSequenceBase*          Sequence;       // 0x000010 (0x000008) [Default: 0x170DE590]
        FSequencePlayerReference    ReturnValue;    // 0x000018 (0x000010) [ReturnValue]
    };

    struct USequencePlayerLibrary___SetSequenceWithInertialBlending_Params
    {
        FAnimUpdateContext          UpdateContext;                  // 0x000000 (0x000010) [OutParam]
        FSequencePlayerReference    SequencePlayer;                 // 0x000010 (0x000010) [OutParam]
        UAnimSequenceBase*          Sequence;                       // 0x000020 (0x000008) [Default: 0x544BB2BB]
        float                       BlendTime;                      // 0x000028 (0x000004) [Default: 1.5821e-27f]
        uint8                       UnknownData_00002C[0x000004];   // 0x00002C (0x000004)
        FSequencePlayerReference    ReturnValue;                    // 0x000030 (0x000010) [ReturnValue]
    };

    struct USequencePlayerLibrary___SetStartPosition_Params
    {
        FSequencePlayerReference    SequencePlayer;                 // 0x000000 (0x000010) [OutParam]
        float                       StartPosition;                  // 0x000010 (0x000004) [Default: 4.58493e-25f]
        uint8                       UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        FSequencePlayerReference    ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct ISequencerAnimationOverride___AllowsCinematicOverride_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct ISequencerAnimationOverride___GetSequencerAnimSlotNames_Params
    {
        TArray<FName>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct USkeletalControlLibrary___ConvertToSkeletalControl_Params
    {
        FAnimNodeReference                  Node;                           // 0x000000 (0x000010) [OutParam]
        EAnimNodeReferenceConversionResult  Result;                         // 0x000010 (0x000001) [OutParam] [Default: EAnimNodeReferenceConversionResult(224)]
        uint8                               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FSkeletalControlReference           ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct USkeletalControlLibrary___ConvertToSkeletalControlPure_Params
    {
        FAnimNodeReference          Node;               // 0x000000 (0x000010) [OutParam]
        FSkeletalControlReference   SkeletalControl;    // 0x000010 (0x000010) [OutParam]
        bool                        Result;             // 0x000020 (0x000001) [OutParam] [Default: true]
    };

    struct USkeletalControlLibrary___GetAlpha_Params
    {
        FSkeletalControlReference   SkeletalControl;    // 0x000000 (0x000010) [OutParam]
        float                       ReturnValue;        // 0x000010 (0x000004) [ReturnValue] [Default: 4.58661e-25f]
    };

    struct USkeletalControlLibrary___SetAlpha_Params
    {
        FSkeletalControlReference   SkeletalControl;                // 0x000000 (0x000010) [OutParam]
        float                       Alpha;                          // 0x000010 (0x000004) [Default: 4.58661e-25f]
        uint8                       UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        FSkeletalControlReference   ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

} // namespace UE

