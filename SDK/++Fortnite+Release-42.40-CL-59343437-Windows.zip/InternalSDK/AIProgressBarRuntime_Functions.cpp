/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AIProgressBarRuntime_Functions
 * ============================================================
 */

#include "AIProgressBarRuntime_Functions.hpp"

namespace UE
{

    void AChallengeManagerBase::AdvanceChallenge()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.AdvanceChallenge");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::BindToBossPawnEvents()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.BindToBossPawnEvents");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::CleanupEncounter()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.CleanupEncounter");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::DespawnAllMinions()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.DespawnAllMinions");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::DisableMapIcon()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.DisableMapIcon");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::FinishTransition()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.FinishTransition");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    AActor* AChallengeManagerBase::GetBossActor()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.GetBossActor");
    
        AChallengeManagerBase___GetBossActor_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FGameplayTag AChallengeManagerBase::GetBossIDTag()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.GetBossIDTag");
    
        AChallengeManagerBase___GetBossIDTag_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 AChallengeManagerBase::GetCurrentPhaseProgressTarget()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.GetCurrentPhaseProgressTarget");
    
        AChallengeManagerBase___GetCurrentPhaseProgressTarget_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FAIProgressBarStageData AChallengeManagerBase::GetCurrentStageData()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.GetCurrentStageData");
    
        AChallengeManagerBase___GetCurrentStageData_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EChallengeState AChallengeManagerBase::GetCurrentState()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.GetCurrentState");
    
        AChallengeManagerBase___GetCurrentState_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FGameplayTag AChallengeManagerBase::GetMusicTagByPhase()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.GetMusicTagByPhase");
    
        AChallengeManagerBase___GetMusicTagByPhase_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 AChallengeManagerBase::GetStageGoalTarget()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.GetStageGoalTarget");
    
        AChallengeManagerBase___GetStageGoalTarget_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 AChallengeManagerBase::GetStageTotalProgressGoal(int32 Stage)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.GetStageTotalProgressGoal");
    
        AChallengeManagerBase___GetStageTotalProgressGoal_Params Params{};
        Params.Stage = Stage;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void AChallengeManagerBase::HandleActorDied(UFortAthenaLivingWorldEncounterInstance* EncounterInstance, AActor* DiedActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.HandleActorDied");
    
        AChallengeManagerBase___HandleActorDied_Params Params{};
        Params.EncounterInstance = EncounterInstance;
        Params.DiedActor = DiedActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AChallengeManagerBase::HandleBossDied()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.HandleBossDied");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::HandleBossHealthChanged()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.HandleBossHealthChanged");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::HandleBossSpawned(AActor* SpawnedActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.HandleBossSpawned");
    
        AChallengeManagerBase___HandleBossSpawned_Params Params{};
        Params.SpawnedActor = SpawnedActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AChallengeManagerBase::HandlePawnSpawned(UFortAthenaLivingWorldEncounterInstance* EncounterInstance, AActor* SpawnedActor, UFortAthenaLivingWorldEventData* EventData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.HandlePawnSpawned");
    
        AChallengeManagerBase___HandlePawnSpawned_Params Params{};
        Params.EncounterInstance = EncounterInstance;
        Params.SpawnedActor = SpawnedActor;
        Params.EventData = EventData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool AChallengeManagerBase::IncrementProgress()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.IncrementProgress");
    
        AChallengeManagerBase___IncrementProgress_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool AChallengeManagerBase::IsBossReadyForFinalFight()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.IsBossReadyForFinalFight");
    
        AChallengeManagerBase___IsBossReadyForFinalFight_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void AChallengeManagerBase::OnRep_BossProgress()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.OnRep_BossProgress");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::OnRep_CurrentState()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.OnRep_CurrentState");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::OnRep_IsBossReadyForFinalFight()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.OnRep_IsBossReadyForFinalFight");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::OnRep_TotalProgress()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.OnRep_TotalProgress");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::PlayTransitionEffects()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.PlayTransitionEffects");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::RequestPawnEnterArena(AActor* Actor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.RequestPawnEnterArena");
    
        AChallengeManagerBase___RequestPawnEnterArena_Params Params{};
        Params.Actor = Actor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AChallengeManagerBase::RequestPawnExitArena(AActor* Actor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.RequestPawnExitArena");
    
        AChallengeManagerBase___RequestPawnExitArena_Params Params{};
        Params.Actor = Actor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AChallengeManagerBase::ResetProgress()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.ResetProgress");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::SetAIProgressBarChallengeRef(AActor* Actor, bool bSetToSelf)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.SetAIProgressBarChallengeRef");
    
        AChallengeManagerBase___SetAIProgressBarChallengeRef_Params Params{};
        Params.Actor = Actor;
        Params.bSetToSelf = bSetToSelf;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AChallengeManagerBase::SetCurrentState(EChallengeState NewState)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.SetCurrentState");
    
        AChallengeManagerBase___SetCurrentState_Params Params{};
        Params.NewState = NewState;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AChallengeManagerBase::SetIsBossReadyForFinalFight(bool bIsReady)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.SetIsBossReadyForFinalFight");
    
        AChallengeManagerBase___SetIsBossReadyForFinalFight_Params Params{};
        Params.bIsReady = bIsReady;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AChallengeManagerBase::SetPhaseMusicEvent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.SetPhaseMusicEvent");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    bool AChallengeManagerBase::ShouldAdvanceStage()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.ShouldAdvanceStage");
    
        AChallengeManagerBase___ShouldAdvanceStage_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void AChallengeManagerBase::SpawnReward(AActor* Boss)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.SpawnReward");
    
        AChallengeManagerBase___SpawnReward_Params Params{};
        Params.Boss = Boss;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AChallengeManagerBase::StartChallenegeAfterDelay()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.StartChallenegeAfterDelay");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::StartChallenge()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.StartChallenge");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::StartSimpleChallenge()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.StartSimpleChallenge");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::TransitionToStage()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.TransitionToStage");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::UnbindToBossPawnEvents()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.UnbindToBossPawnEvents");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::UpdateChallengeState(EChallengeState NewState)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.UpdateChallengeState");
    
        AChallengeManagerBase___UpdateChallengeState_Params Params{};
        Params.NewState = NewState;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AChallengeManagerBase::UpdateCurrentPhase()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.UpdateCurrentPhase");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::UpdateMapIconByState(EChallengeState ChallengeState)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.UpdateMapIconByState");
    
        AChallengeManagerBase___UpdateMapIconByState_Params Params{};
        Params.ChallengeState = ChallengeState;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AChallengeManagerBase::UpdateMusicTagOnSpawnedActors()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.UpdateMusicTagOnSpawnedActors");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::OnBossProgressUpdated()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.OnBossProgressUpdated");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::OnBossReadyForFinalFight()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.OnBossReadyForFinalFight");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::OnChallengeBegun()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.OnChallengeBegun");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::OnCurrentStateUpdated()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.OnCurrentStateUpdated");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AChallengeManagerBase::OnStageAdvanced(int32 NewStage)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.OnStageAdvanced");
    
        AChallengeManagerBase___OnStageAdvanced_Params Params{};
        Params.NewStage = NewStage;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AChallengeManagerBase::OnTotalProgressUpdated()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIProgressBarRuntime.ChallengeManagerBase.OnTotalProgressUpdated");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

} // namespace UE

