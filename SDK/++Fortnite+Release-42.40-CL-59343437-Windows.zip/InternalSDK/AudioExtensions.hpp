/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:12
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioExtensions
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class UAudioEndpointSettingsBase : public UObject
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class IAudioParameterControllerInterface : public IInterface
    {
    public:
    
    public: // Functions
        void    ResetParameters(); // 0x0C7A33DA [Native | Public | BlueprintCallable]
        void    SetBoolArrayParameter(FName InName, TArray<bool>& InValue); // 0x03ECEBB4 [Native | Public | HasOutParms | BlueprintCallable]
        void    SetBoolParameter(FName InName, bool InBool); // 0x03ECEE56 [Native | Public | BlueprintCallable]
        void    SetFloatArrayParameter(FName InName, TArray<float>& InValue); // 0x03ECF0DE [Native | Public | HasOutParms | BlueprintCallable]
        void    SetFloatParameter(FName InName, float InFloat); // 0x03ECF380 [Native | Public | BlueprintCallable]
        void    SetIntArrayParameter(FName InName, TArray<int32>& InValue); // 0x03ECF606 [Native | Public | HasOutParms | BlueprintCallable]
        void    SetIntParameter(FName InName, int32 InInt); // 0x03ECF8A8 [Native | Public | BlueprintCallable]
        void    SetObjectArrayParameter(FName InName, TArray<UObject*>& InValue); // 0x03ECFB2C [Native | Public | HasOutParms | BlueprintCallable]
        void    SetObjectParameter(FName InName, UObject* InValue); // 0x03ECFDCE [Native | Public | BlueprintCallable]
        void    SetParameters_Blueprint(TArray<FAudioParameter>& InParameters); // 0x03ED0054 [Native | Public | HasOutParms | BlueprintCallable]
        void    SetStringArrayParameter(FName InName, TArray<FString>& InValue); // 0x03ED01EE [Native | Public | HasOutParms | BlueprintCallable]
        void    SetStringParameter(FName InName, FString InValue); // 0x03ED049C [Native | Public | BlueprintCallable]
        void    SetTriggerParameter(FName InName); // 0x03ED0730 [Native | Public | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class UAudioPropertiesSheetAssetBase : public UObject
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class IAudioPropertiesSheetAssetUserInterface : public IInterface
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class UDummyEndpointSettings : public UAudioEndpointSettingsBase
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class UOcclusionPluginSourceSettingsBase : public UObject
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class UReverbPluginSourceSettingsBase : public UObject
    {
    public:
    };
    // Size: 0x000030 (0x000008)
    class alignas(0x8) USoundModulatorBase : public UObject
    {
    public:
        void**  VTable_000028;  // 0x000028 (0x000008) VTable [13 slots] -> 0x12E6CCA0
    };
    // Size: 0x000030 (0x000008)
    class alignas(0x8) USoundfieldEffectBase : public UObject
    {
    public:
        USoundfieldEffectSettingsBase*  Settings;   // 0x000028 (0x000008) [Default: nullptr]
    };
    // Size: 0x000028 (0x000000)
    class USoundfieldEffectSettingsBase : public UObject
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class USoundfieldEncodingSettingsBase : public UObject
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class USoundfieldEndpointSettingsBase : public UObject
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class USourceDataOverridePluginSourceSettingsBase : public UObject
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class USpatializationPluginSourceSettingsBase : public UObject
    {
    public:
    };
    // Size: 0x000048 (0x000020)
    class UWaveformTransformationBase : public UObject
    {
    public:
        uint8   UnknownData_000028[0x000020];   // 0x000028 (0x000020)
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x8) UWaveformTransformationChain : public UObject
    {
    public:
        TArray<UWaveformTransformationBase*>    Transformations;    // 0x000028 (0x000010)
    };
    // Size: 0x000090 (0x000090)
    struct alignas(0x8) FAudioParameter
    {
        FName               ParamName;                      // 0x000000 (0x000004) [Default: FName(380170688) -> L""]
        float               FloatParam;                     // 0x000004 (0x000004) [Default: 0f]
        bool                BoolParam;                      // 0x000008 (0x000001) [Default: false]
        uint8               UnknownData_000009[0x000003];   // 0x000009 (0x000003)
        int32               IntParam;                       // 0x00000C (0x000004) [Default: 0]
        UObject*            ObjectParam;                    // 0x000010 (0x000008) [Default: 0x1]
        FString             StringParam;                    // 0x000018 (0x000010) [Default: L""]
        TArray<float>       ArrayFloatParam;                // 0x000028 (0x000010)
        TArray<bool>        ArrayBoolParam;                 // 0x000038 (0x000010)
        TArray<int32>       ArrayIntParam;                  // 0x000048 (0x000010)
        TArray<UObject*>    ArrayObjectParam;               // 0x000058 (0x000010)
        TArray<FString>     ArrayStringParam;               // 0x000068 (0x000010)
        EAudioParameterType ParamType;                      // 0x000078 (0x000001) [Default: EAudioParameterType(14)]
        uint8               UnknownData_000079[0x000003];   // 0x000079 (0x000003)
        FName               TypeName;                       // 0x00007C (0x000004) [Default: NAME_None]
        uint8               UnknownData_000080[0x000008];   // 0x000080 (0x000008)
        void**              VTable_000088;                  // 0x000088 (0x000008) VTable [86 slots] -> 0x1527E268
    };
    // Size: 0x000004 (0x000004)
    struct alignas(0x4) FSoundGeneratorOutput
    {
        FName   Name;   // 0x000000 (0x000004)
    };
    // Size: 0x000001 (0x000001)
    struct FSoundWaveCloudStreamingPlatformProjectSettings
    {
        ESoundWaveCloudStreamingPlatformProjectEnableType   EnablementSetting;  // 0x000000 (0x000001) [Default: ESoundWaveCloudStreamingPlatformProjectEnableType(224)]
    };
    // Size: 0x000001 (0x000001)
    struct FSoundWaveCloudStreamingPlatformSettings
    {
        ESoundWaveCloudStreamingPlatformEnableType  EnablementSetting;  // 0x000000 (0x000001)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FSoundWaveCuePoint
    {
        int32   CuePointID;                     // 0x000000 (0x000004) [Default: 0]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FString Label;                          // 0x000008 (0x000010) [Default: L""]
        int64   FramePosition;                  // 0x000018 (0x000008) [Default: 0ll]
        int64   FrameLength;                    // 0x000020 (0x000008) [Default: 0ll]
        bool    bIsLoopRegion;                  // 0x000028 (0x000001) [Default: false]
        uint8   UnknownData_000029[0x000007];   // 0x000029 (0x000007)
    };
}

