/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimPresetsCore_Functions
 * ============================================================
 */

#include "AnimPresetsCore.hpp"

namespace UE
{

    struct UAnimPreset___GetPresetClass_Params
    {
        TSoftClassPtr<UClass>   ReturnValue;    // 0x000000 (0x000020) [ReturnValue] [Default: 0x1369DFD0]
    };

    struct UAnimPreset___HandleAnimInstance_Params
    {
        UAnimInstance*  Instance;   // 0x000000 (0x000008) [Default: 0x1369DFD0]
    };

} // namespace UE

