/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AVCodecsCoreRHI_Functions
 * ============================================================
 */

#include "AVCodecsCoreRHI.hpp"

namespace UE
{

    struct USimpleAudioEncoder___GetCodec_Params
    {
        ESimpleAudioCodec   ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: ESimpleAudioCodec(64)]
    };

    struct USimpleAudioEncoder___GetConfig_Params
    {
        FSimpleAudioEncoderConfig   ReturnValue;    // 0x000000 (0x00000C) [ReturnValue]
    };

    struct USimpleAudioEncoder___IsAsync_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct USimpleAudioEncoder___IsOpen_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct USimpleAudioEncoder___Open_Params
    {
        ESimpleAudioCodec           Codec;                          // 0x000000 (0x000001) [Default: ESimpleAudioCodec(64)]
        uint8                       UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        FSimpleAudioEncoderConfig   Config;                         // 0x000004 (0x00000C)
        bool                        bAsynchronous;                  // 0x000010 (0x000001) [Default: true]
        bool                        ReturnValue;                    // 0x000011 (0x000001) [ReturnValue] [Default: true]
    };

    struct USimpleAudioEncoder___ReceivePacket_Params
    {
        FSimpleAudioPacket  OutPacket;      // 0x000000 (0x000028) [OutParam]
        bool                ReturnValue;    // 0x000028 (0x000001) [ReturnValue] [Default: true]
    };

    struct USimpleAudioEncoder___ReceivePackets_Params
    {
        TArray<FSimpleAudioPacket>  OutPackets; // 0x000000 (0x000010) [OutParam]
    };

    struct USimpleAudioEncoder___SendFrameFloat_Params
    {
        TArray<float>   Resource;       // 0x000000 (0x000010) [OutParam]
        double          Timestamp;      // 0x000010 (0x000008) [Default: 1.93977e-315]
        int32           NumSamples;     // 0x000018 (0x000004) [Default: 392608528]
        float           SampleDuration; // 0x00001C (0x000004) [Default: 0f]
        bool            ReturnValue;    // 0x000020 (0x000001) [ReturnValue] [Default: true]
    };

    struct USimpleAudioEncoder___SetConfig_Params
    {
        FSimpleAudioEncoderConfig   NewConfig;  // 0x000000 (0x00000C)
    };

    struct USimpleVideoDecoder___GetCodec_Params
    {
        ESimpleVideoCodec   ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: ESimpleVideoCodec(144)]
    };

    struct USimpleVideoDecoder___IsAsync_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct USimpleVideoDecoder___IsOpen_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct USimpleVideoDecoder___Open_Params
    {
        ESimpleVideoCodec   Codec;          // 0x000000 (0x000001) [Default: ESimpleVideoCodec(144)]
        bool                bAsynchronous;  // 0x000001 (0x000001) [Default: true]
        bool                ReturnValue;    // 0x000002 (0x000001) [ReturnValue] [Default: true]
    };

    struct USimpleVideoDecoder___ReceiveFrame_Params
    {
        UTextureRenderTarget2D* Resource;       // 0x000000 (0x000008) [Default: 0x1368D990]
        bool                    ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct USimpleVideoDecoder___SendPacket_Params
    {
        FSimpleVideoPacket  Packet;         // 0x000000 (0x000760) [OutParam]
        bool                ReturnValue;    // 0x000760 (0x000001) [ReturnValue] [Default: false]
    };

    struct USimpleVideoEncoder___GetCodec_Params
    {
        ESimpleVideoCodec   ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: ESimpleVideoCodec(224)]
    };

    struct USimpleVideoEncoder___GetConfig_Params
    {
        FSimpleVideoEncoderConfig   ReturnValue;    // 0x000000 (0x000014) [ReturnValue]
    };

    struct USimpleVideoEncoder___IsAsync_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct USimpleVideoEncoder___IsOpen_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct USimpleVideoEncoder___Open_Params
    {
        ESimpleVideoCodec           Codec;                          // 0x000000 (0x000001) [Default: ESimpleVideoCodec(224)]
        uint8                       UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        FSimpleVideoEncoderConfig   Config;                         // 0x000004 (0x000014)
        bool                        bAsynchronous;                  // 0x000018 (0x000001) [Default: true]
        bool                        ReturnValue;                    // 0x000019 (0x000001) [ReturnValue] [Default: true]
    };

    struct USimpleVideoEncoder___ReceivePacket_Params
    {
        FSimpleVideoPacket  OutPacket;      // 0x000000 (0x000760) [OutParam]
        bool                ReturnValue;    // 0x000760 (0x000001) [ReturnValue] [Default: false]
    };

    struct USimpleVideoEncoder___ReceivePackets_Params
    {
        TArray<FSimpleVideoPacket>  OutPackets; // 0x000000 (0x000010) [OutParam]
    };

    struct USimpleVideoEncoder___SendFrameRenderTarget_Params
    {
        UTextureRenderTarget2D* Resource;       // 0x000000 (0x000008) [Default: 0x1368DCE0]
        double                  Timestamp;      // 0x000008 (0x000008) [Default: -6.8755e-48]
        bool                    bForceKeyframe; // 0x000010 (0x000001) [Default: true]
        bool                    ReturnValue;    // 0x000011 (0x000001) [ReturnValue] [Default: true]
    };

    struct USimpleVideoEncoder___SendFrameTexture_Params
    {
        UTexture2D* Resource;       // 0x000000 (0x000008) [Default: 0x1368DCE0]
        double      Timestamp;      // 0x000008 (0x000008) [Default: -6.8755e-48]
        bool        bForceKeyframe; // 0x000010 (0x000001) [Default: true]
        bool        ReturnValue;    // 0x000011 (0x000001) [ReturnValue] [Default: true]
    };

    struct USimpleVideoEncoder___SetConfig_Params
    {
        FSimpleVideoEncoderConfig   NewConfig;  // 0x000000 (0x000014)
    };

    struct USimpleVideoHelper___ShareRenderTarget2D_Params
    {
        UTextureRenderTarget2D* RenderTarget;   // 0x000000 (0x000008) [Default: 0x12FAB170]
    };

} // namespace UE

