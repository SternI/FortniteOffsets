/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AutoAimWeaponRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class UAutoAimWeaponKismetLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static bool                            DoesAutoAimWeaponHaveLineOfSight(AFortPawn* SourcePawn, AFortPawn* TargetPawn); // 0x08037880 [Final | Native | Static | Public | BlueprintCallable]
        static bool                            DoesAutoAimWeaponReticleIntersectTarget(float& OutReticleDistance, AFortPawn* SourcePawn, AFortPawn* TargetPawn, float ReticleSize); // 0x08037B1C [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
        static void                            FindBestAutoAimTarget(AFortPawn*& OutTargetPawn, float& OutReticleDistance, AFortPlayerPawn* SourcePawn, float ReticleSize, float Range); // 0x08037FFC [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
        static UAutoAimWeaponPawnComponent*    GetAutoAimWeaponPawnComponent(AFortPawn* SourcePawn); // 0x08038BCC [Final | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x0001A8 (0x0000E0)
    class alignas(0x8) UAutoAimWeaponPawnComponent : public UFortPawnComponent
    {
    public:
        FGameplayTagContainer                   UseSingleLocationTargetingPawnTags;     // 0x0000C8 (0x000020)
        FGameplayTagContainer                   LowPriorityTargetPawnTags;              // 0x0000E8 (0x000020)
        TArray<FAutoAimWeaponBoneSegmentData>   MultiSocketTargetingBoneSegmentDatas;   // 0x000108 (0x000010)
        FScalableFloat                          LockOnTimeReticleCenter;                // 0x000118 (0x000028)
        FScalableFloat                          LockOnTimeReticleEdge;                  // 0x000140 (0x000028)
        FScalableFloat                          MaxLockOns;                             // 0x000168 (0x000028)
        TEnumAsByte<ETraceTypeQuery>            LineOfSightTraceChannel;                // 0x000190 (0x000001) [Default: 5]
        uint8                                   UnknownData_000191[0x000003];           // 0x000191 (0x000003)
        float                                   ProgressTowardNextLockOn;               // 0x000194 (0x000004) [Default: 0f]
        int32                                   CurrentLockOnCount;                     // 0x000198 (0x000004) [Default: 0]
        float                                   TargetToReticleDistanceNormalized;      // 0x00019C (0x000004) [Default: 0f]
        TWeakObjectPtr<AFortPawn>               LockOnTarget;                           // 0x0001A0 (0x000008) [Default: nullptr]
    
    public: // Functions
        void    ApplySpreadToAimRotation(FRotator& OutRotation, float SpreadInDegrees); // 0x08038D5A [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        int32   GetCurrentLockOnCount(); // 0x10DB086E [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float   GetLockOnProgress(); // 0x10DB0888 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool    GetLockOnTargetLocation(FVector& OutLockTargetLocation); // 0x08038FE6 [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable | Const]
        float   GetTargetToReticleDistanceNormalized(); // 0x10DB0A70 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    RotateAimTowardsLockOnTarget(FRotator& OutRotation); // 0x08039164 [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FAutoAimWeaponBoneSegmentData
    {
        FName   BoneName1;                              // 0x000000 (0x000004)
        FName   BoneName2;                              // 0x000004 (0x000004)
        float   BoneCollisionCapsuleRadiusAproximation; // 0x000008 (0x000004)
    };
    // Size: 0x000001 (0x000001)
    struct FFortEvent_LockOnReticleStateChanged
    {
        bool    bEnabledReticle;    // 0x000000 (0x000001)
    };
}

