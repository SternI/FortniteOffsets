/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:12
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioExtensions_Functions
 * ============================================================
 */

#include "AudioExtensions.hpp"

namespace UE
{

    struct IAudioParameterControllerInterface___SetBoolArrayParameter_Params
    {
        FName           InName;                         // 0x000000 (0x000004) [Default: FName(318419312) -> L""]
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<bool>    InValue;                        // 0x000008 (0x000010) [OutParam]
    };

    struct IAudioParameterControllerInterface___SetBoolParameter_Params
    {
        FName   InName; // 0x000000 (0x000004) [Default: FName(318419312) -> L""]
        bool    InBool; // 0x000004 (0x000001) [Default: false]
    };

    struct IAudioParameterControllerInterface___SetFloatArrayParameter_Params
    {
        FName           InName;                         // 0x000000 (0x000004) [Default: FName(318419312) -> L""]
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<float>   InValue;                        // 0x000008 (0x000010) [OutParam]
    };

    struct IAudioParameterControllerInterface___SetFloatParameter_Params
    {
        FName   InName;     // 0x000000 (0x000004) [Default: FName(318419312) -> L""]
        float   InFloat;    // 0x000004 (0x000004) [Default: 0f]
    };

    struct IAudioParameterControllerInterface___SetIntArrayParameter_Params
    {
        FName           InName;                         // 0x000000 (0x000004) [Default: FName(318419312) -> L""]
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<int32>   InValue;                        // 0x000008 (0x000010) [OutParam]
    };

    struct IAudioParameterControllerInterface___SetIntParameter_Params
    {
        FName   InName; // 0x000000 (0x000004) [Default: FName(318419312) -> L""]
        int32   InInt;  // 0x000004 (0x000004) [Default: 0]
    };

    struct IAudioParameterControllerInterface___SetObjectArrayParameter_Params
    {
        FName               InName;                         // 0x000000 (0x000004) [Default: FName(318419312) -> L""]
        uint8               UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<UObject*>    InValue;                        // 0x000008 (0x000010) [OutParam]
    };

    struct IAudioParameterControllerInterface___SetObjectParameter_Params
    {
        FName       InName;                         // 0x000000 (0x000004) [Default: FName(318419312) -> L""]
        uint8       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UObject*    InValue;                        // 0x000008 (0x000008) [Default: 0xE68E1BDD00000031]
    };

    struct IAudioParameterControllerInterface___SetParameters_Blueprint_Params
    {
        TArray<FAudioParameter> InParameters;   // 0x000000 (0x000010) [OutParam]
    };

    struct IAudioParameterControllerInterface___SetStringArrayParameter_Params
    {
        FName           InName;                         // 0x000000 (0x000004) [Default: FName(318419312) -> L""]
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FString> InValue;                        // 0x000008 (0x000010) [OutParam]
    };

    struct IAudioParameterControllerInterface___SetStringParameter_Params
    {
        FName   InName;                         // 0x000000 (0x000004) [Default: FName(318419312) -> L""]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FString InValue;                        // 0x000008 (0x000010) [Default: L""]
    };

    struct IAudioParameterControllerInterface___SetTriggerParameter_Params
    {
        FName   InName; // 0x000000 (0x000004) [Default: FName(318419312) -> L""]
    };

} // namespace UE

