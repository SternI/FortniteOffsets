/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BallisticShieldBaseRuntime_Functions
 * ============================================================
 */

#include "BallisticShieldBaseRuntime.hpp"

namespace UE
{

    struct IBallisticShieldWeaponInterface___GetBallisticShieldData_Params
    {
        EBallisticShieldPlayerActionState   BallisticShieldPlayerState;     // 0x000000 (0x000001) [OutParam] [Default: EBallisticShieldPlayerActionState(112)]
        uint8                               UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        float                               StaggerBuildupPercent;          // 0x000004 (0x000004) [OutParam] [Default: 0f]
    };

} // namespace UE

