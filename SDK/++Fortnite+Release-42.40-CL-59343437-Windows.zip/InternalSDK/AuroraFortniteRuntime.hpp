/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AuroraFortniteRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000208 (0x000018)
    class UAuroraFortnitePlayerControllerComponent : public UAuroraPlayerControllerComponent
    {
    public:
        uint8   UnknownData_0001F0[0x000018];   // 0x0001F0 (0x000018)
    
    public: // Functions
        void    OnMinigameStateChanged(AFortMinigame* InMinigame, EFortMinigameState InNewState); // 0x0802C9C4 [Final | Native | Private]
        void    Server_SetPlatformFamily(FString InPlatformFamily); // 0x0802CE64 [Net | NetReliable | Native | Event | Public | NetServer]
    };
    // Size: 0x0000F0 (0x000010)
    class UCustomDebugCommand_AuroraDisplayStoreUI : public UCustomDebugCommand_Base
    {
    public:
        uint8   UnknownData_0000E0[0x000010];   // 0x0000E0 (0x000010)
    };
    // Size: 0x0000E0 (0x000000)
    class UCustomDebugCommand_AuroraForceClawbackAll : public UCustomDebugCommand_Base
    {
    public:
    };
    // Size: 0x0000E8 (0x000000)
    class UCustomDebugCommand_AuroraGrantAllEntitlement : public UCustomDebugCommand_AuroraGrantEntitlement
    {
    public:
    };
    // Size: 0x0000E8 (0x000008)
    class UCustomDebugCommand_AuroraGrantEntitlement : public UCustomDebugCommand_Base
    {
    public:
        uint8   UnknownData_0000E0[0x000008];   // 0x0000E0 (0x000008)
    };
    // Size: 0x0000E8 (0x000000)
    class UCustomDebugCommand_AuroraGrantOneEntitlement : public UCustomDebugCommand_AuroraGrantEntitlement
    {
    public:
    };
    // Size: 0x0000E0 (0x000000)
    class UCustomDebugCommand_AuroraPrintOwnedEntitlements : public UCustomDebugCommand_Base
    {
    public:
    };
    // Size: 0x0000E8 (0x000008)
    class UCustomDebugCommand_AuroraPurchasesAlwaysFail : public UCustomDebugCommand_Base
    {
    public:
        bool    bAlwaysFailPurchases;           // 0x0000E0 (0x000001) [Default: false]
        uint8   UnknownData_0000E1[0x000007];   // 0x0000E1 (0x000007)
    
    public: // Functions
        bool    GetAlwaysFailPurchases(); // 0x0F294864 [Final | Native | Public | Const]
        void    SetAlwaysFailPurchases(bool bInAlwaysFailPurchases); // 0x0802CFE8 [Final | Native | Public]
    };
}

