/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArcadeWeaponGameplayRuntime_Functions
 * ============================================================
 */

#include "ArcadeWeaponGameplayRuntime_Functions.hpp"

namespace UE
{

    void UFortCheatManager_ArcadeWeaponPersistence::ClearHighScoreForAll()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortCheatManager_ArcadeWeaponPersistence.ClearHighScoreForAll");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortCheatManager_ArcadeWeaponPersistence::ClearMyHighScore()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortCheatManager_ArcadeWeaponPersistence.ClearMyHighScore");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    EArcadeWeaponLeaderboardMode UFortControllerComponent_ArcadeWeaponLeaderboard::GetActiveLeaderboardMode()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortControllerComponent_ArcadeWeaponLeaderboard.GetActiveLeaderboardMode");
    
        UFortControllerComponent_ArcadeWeaponLeaderboard___GetActiveLeaderboardMode_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UFortControllerComponent_ArcadeWeaponLeaderboard::GetEntryForPlayer(APlayerState* PlayerState, FArcadeWeaponLeaderboardEntry& OutEntry)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortControllerComponent_ArcadeWeaponLeaderboard.GetEntryForPlayer");
    
        UFortControllerComponent_ArcadeWeaponLeaderboard___GetEntryForPlayer_Params Params{};
        Params.PlayerState = PlayerState;
        Params.OutEntry = OutEntry;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutEntry = Params.OutEntry;
    
        return Params.ReturnValue;
    }

    int32 UFortControllerComponent_ArcadeWeaponLeaderboard::GetLocalPlayerRank()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortControllerComponent_ArcadeWeaponLeaderboard.GetLocalPlayerRank");
    
        UFortControllerComponent_ArcadeWeaponLeaderboard___GetLocalPlayerRank_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UFortControllerComponent_ArcadeWeaponLeaderboard::GetNumEntries()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortControllerComponent_ArcadeWeaponLeaderboard.GetNumEntries");
    
        UFortControllerComponent_ArcadeWeaponLeaderboard___GetNumEntries_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FArcadeWeaponLeaderboardEntry> UFortControllerComponent_ArcadeWeaponLeaderboard::GetRankedEntries()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortControllerComponent_ArcadeWeaponLeaderboard.GetRankedEntries");
    
        UFortControllerComponent_ArcadeWeaponLeaderboard___GetRankedEntries_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FArcadeWeaponLeaderboardEntry> UFortControllerComponent_ArcadeWeaponLeaderboard::GetRankedFriendsEntries()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortControllerComponent_ArcadeWeaponLeaderboard.GetRankedFriendsEntries");
    
        UFortControllerComponent_ArcadeWeaponLeaderboard___GetRankedFriendsEntries_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FArcadeWeaponLeaderboardEntry> UFortControllerComponent_ArcadeWeaponLeaderboard::GetRankedGlobalEntries()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortControllerComponent_ArcadeWeaponLeaderboard.GetRankedGlobalEntries");
    
        UFortControllerComponent_ArcadeWeaponLeaderboard___GetRankedGlobalEntries_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortControllerComponent_ArcadeWeaponLeaderboard::HandleNewHighScore(int32 NewHighScore)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortControllerComponent_ArcadeWeaponLeaderboard.HandleNewHighScore");
    
        UFortControllerComponent_ArcadeWeaponLeaderboard___HandleNewHighScore_Params Params{};
        Params.NewHighScore = NewHighScore;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortControllerComponent_ArcadeWeaponLeaderboard::HandleScoreDataChanged(FArcadeWeaponScoreData& ScoreData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortControllerComponent_ArcadeWeaponLeaderboard.HandleScoreDataChanged");
    
        UFortControllerComponent_ArcadeWeaponLeaderboard___HandleScoreDataChanged_Params Params{};
        Params.ScoreData = ScoreData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ScoreData = Params.ScoreData;
    }

    bool UFortControllerComponent_ArcadeWeaponLeaderboard::IsLeaderboardEnabled()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortControllerComponent_ArcadeWeaponLeaderboard.IsLeaderboardEnabled");
    
        UFortControllerComponent_ArcadeWeaponLeaderboard___IsLeaderboardEnabled_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortControllerComponent_ArcadeWeaponLeaderboard::PushGlobalScoreForPlayer()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortControllerComponent_ArcadeWeaponLeaderboard.PushGlobalScoreForPlayer");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortControllerComponent_ArcadeWeaponLeaderboard::RequestFriendsLeaderboard(EArcadeWeaponLeaderboardMode Mode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortControllerComponent_ArcadeWeaponLeaderboard.RequestFriendsLeaderboard");
    
        UFortControllerComponent_ArcadeWeaponLeaderboard___RequestFriendsLeaderboard_Params Params{};
        Params.Mode = Mode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortControllerComponent_ArcadeWeaponLeaderboard::RequestGlobalLeaderboard(EArcadeWeaponLeaderboardMode Mode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortControllerComponent_ArcadeWeaponLeaderboard.RequestGlobalLeaderboard");
    
        UFortControllerComponent_ArcadeWeaponLeaderboard___RequestGlobalLeaderboard_Params Params{};
        Params.Mode = Mode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortPlayerStateComponent_ArcadeWeaponPersistence::ClearHighScore()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortPlayerStateComponent_ArcadeWeaponPersistence.ClearHighScore");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    int32 UFortPlayerStateComponent_ArcadeWeaponPersistence::GetCumulativeScore()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortPlayerStateComponent_ArcadeWeaponPersistence.GetCumulativeScore");
    
        UFortPlayerStateComponent_ArcadeWeaponPersistence___GetCumulativeScore_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FArcadeWeaponScoreData UFortPlayerStateComponent_ArcadeWeaponPersistence::GetCurrentScoreData()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortPlayerStateComponent_ArcadeWeaponPersistence.GetCurrentScoreData");
    
        UFortPlayerStateComponent_ArcadeWeaponPersistence___GetCurrentScoreData_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UFortPlayerStateComponent_ArcadeWeaponPersistence::GetHighScore()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortPlayerStateComponent_ArcadeWeaponPersistence.GetHighScore");
    
        UFortPlayerStateComponent_ArcadeWeaponPersistence___GetHighScore_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UFortPlayerStateComponent_ArcadeWeaponPersistence::GetHighScoreForMode(EArcadeWeaponLeaderboardMode Mode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortPlayerStateComponent_ArcadeWeaponPersistence.GetHighScoreForMode");
    
        UFortPlayerStateComponent_ArcadeWeaponPersistence___GetHighScoreForMode_Params Params{};
        Params.Mode = Mode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UFortPlayerStateComponent_ArcadeWeaponPersistence::GetStreak()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortPlayerStateComponent_ArcadeWeaponPersistence.GetStreak");
    
        UFortPlayerStateComponent_ArcadeWeaponPersistence___GetStreak_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortPlayerStateComponent_ArcadeWeaponPersistence::HandlePlayerPersistenceAvailable(EFortSaveFrameworkPersistence_AvailableType AvailableType, FInstancedStruct& InPersistenceDataRoot)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortPlayerStateComponent_ArcadeWeaponPersistence.HandlePlayerPersistenceAvailable");
    
        UFortPlayerStateComponent_ArcadeWeaponPersistence___HandlePlayerPersistenceAvailable_Params Params{};
        Params.AvailableType = AvailableType;
        Params.InPersistenceDataRoot = InPersistenceDataRoot;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InPersistenceDataRoot = Params.InPersistenceDataRoot;
    }

    bool UFortPlayerStateComponent_ArcadeWeaponPersistence::IsUsingMinigameScore()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortPlayerStateComponent_ArcadeWeaponPersistence.IsUsingMinigameScore");
    
        UFortPlayerStateComponent_ArcadeWeaponPersistence___IsUsingMinigameScore_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortPlayerStateComponent_ArcadeWeaponPersistence::OnMinigameScoreUpdate()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortPlayerStateComponent_ArcadeWeaponPersistence.OnMinigameScoreUpdate");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortPlayerStateComponent_ArcadeWeaponPersistence::OnRep_CurrentScoreData()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortPlayerStateComponent_ArcadeWeaponPersistence.OnRep_CurrentScoreData");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortPlayerStateComponent_ArcadeWeaponPersistence::OnRep_HighScoreBuild(int32 OldValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortPlayerStateComponent_ArcadeWeaponPersistence.OnRep_HighScoreBuild");
    
        UFortPlayerStateComponent_ArcadeWeaponPersistence___OnRep_HighScoreBuild_Params Params{};
        Params.OldValue = OldValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortPlayerStateComponent_ArcadeWeaponPersistence::OnRep_HighScoreZeroBuild(int32 OldValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortPlayerStateComponent_ArcadeWeaponPersistence.OnRep_HighScoreZeroBuild");
    
        UFortPlayerStateComponent_ArcadeWeaponPersistence___OnRep_HighScoreZeroBuild_Params Params{};
        Params.OldValue = OldValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortPlayerStateComponent_ArcadeWeaponPersistence::ResetCombo()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortPlayerStateComponent_ArcadeWeaponPersistence.ResetCombo");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    bool UFortPlayerStateComponent_ArcadeWeaponPersistence::TrySetNewHighScore(int32 NewScore)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortPlayerStateComponent_ArcadeWeaponPersistence.TrySetNewHighScore");
    
        UFortPlayerStateComponent_ArcadeWeaponPersistence___TrySetNewHighScore_Params Params{};
        Params.NewScore = NewScore;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortPlayerStateComponent_ArcadeWeaponPersistence::UpdateScoreAndStreak(FArcadeWeaponScoreData& InScoreData, FArcadeWeaponScoreData& OutScoreData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortPlayerStateComponent_ArcadeWeaponPersistence.UpdateScoreAndStreak");
    
        UFortPlayerStateComponent_ArcadeWeaponPersistence___UpdateScoreAndStreak_Params Params{};
        Params.InScoreData = InScoreData;
        Params.OutScoreData = OutScoreData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InScoreData = Params.InScoreData;
        OutScoreData = Params.OutScoreData;
    }

    FTrickShotConfig UFortWeaponComponent_ArcadeWeapon::CheckIfTrickShot()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortWeaponComponent_ArcadeWeapon.CheckIfTrickShot");
    
        UFortWeaponComponent_ArcadeWeapon___CheckIfTrickShot_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UFortPlayerStateComponent_ArcadeWeaponPersistence* UFortWeaponComponent_ArcadeWeapon::GetArcadeWeaponPersistenceComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortWeaponComponent_ArcadeWeapon.GetArcadeWeaponPersistenceComponent");
    
        UFortWeaponComponent_ArcadeWeapon___GetArcadeWeaponPersistenceComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FArcadeWeaponScoreData UFortWeaponComponent_ArcadeWeapon::GetCurrentScoreData()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortWeaponComponent_ArcadeWeapon.GetCurrentScoreData");
    
        UFortWeaponComponent_ArcadeWeapon___GetCurrentScoreData_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    AFortPlayerPawn* UFortWeaponComponent_ArcadeWeapon::GetPlayerPawn()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortWeaponComponent_ArcadeWeapon.GetPlayerPawn");
    
        UFortWeaponComponent_ArcadeWeapon___GetPlayerPawn_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortWeaponComponent_ArcadeWeapon::OnScoreDataChanged(FArcadeWeaponScoreData& ScoreData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArcadeWeaponGameplayRuntime.FortWeaponComponent_ArcadeWeapon.OnScoreDataChanged");
    
        UFortWeaponComponent_ArcadeWeapon___OnScoreDataChanged_Params Params{};
        Params.ScoreData = ScoreData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ScoreData = Params.ScoreData;
    }

} // namespace UE

