/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AdHocSquadsRuntime_Functions
 * ============================================================
 */

#include "AdHocSquadsRuntime_Functions.hpp"

namespace UE
{

    void UAdHocSquadPawnOutlineComponent::HandlePlayerSquadChanged(AFortPlayerStateAthena* InPlayerState, uint8 PreviousSquadId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdHocSquadsRuntime.AdHocSquadPawnOutlineComponent.HandlePlayerSquadChanged");
    
        UAdHocSquadPawnOutlineComponent___HandlePlayerSquadChanged_Params Params{};
        Params.InPlayerState = InPlayerState;
        Params.PreviousSquadId = PreviousSquadId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAdHocSquadPawnOutlineComponent::OnRep_AdHocSquadId(uint8 PreviousAdHocSquadId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AdHocSquadsRuntime.AdHocSquadPawnOutlineComponent.OnRep_AdHocSquadId");
    
        UAdHocSquadPawnOutlineComponent___OnRep_AdHocSquadId_Params Params{};
        Params.PreviousAdHocSquadId = PreviousAdHocSquadId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

