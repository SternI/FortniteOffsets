/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AndroidPermission
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000050 (0x000028)
    class alignas(0x8) UAndroidPermissionCallbackProxy : public UObject
    {
    public:
        MULTI_INLINE_DELEGATE(AndroidPermissionDynamicDelegate) OnPermissionsGrantedDynamicDelegate;    // 0x000028 (0x000010)
        uint8                                                   UnknownData_000038[0x000018];           // 0x000038 (0x000018)
    };
    // Size: 0x000028 (0x000000)
    class UAndroidPermissionFunctionLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static UAndroidPermissionCallbackProxy*    AcquirePermissions(TArray<FString>& permissions); // 0x07ED1C14 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable]
        static bool                                CheckPermission(FString permission); // 0x07ED1E7A [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
}

