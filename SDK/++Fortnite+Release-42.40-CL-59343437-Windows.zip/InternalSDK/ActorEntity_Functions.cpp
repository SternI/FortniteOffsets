/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ActorEntity_Functions
 * ============================================================
 */

#include "ActorEntity_Functions.hpp"

namespace UE
{

    void UPhysicsComponentBridgeHelper::HandleActorComponentHit(UPrimitiveComponent* PrimitiveComponent, AActor* OtherActor, UPrimitiveComponent* OtherComponent, FVector NormalImpulse, FHitResult& Hit)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ActorEntity.PhysicsComponentBridgeHelper.HandleActorComponentHit");
    
        UPhysicsComponentBridgeHelper___HandleActorComponentHit_Params Params{};
        Params.PrimitiveComponent = PrimitiveComponent;
        Params.OtherActor = OtherActor;
        Params.OtherComponent = OtherComponent;
        Params.NormalImpulse = NormalImpulse;
        Params.Hit = Hit;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Hit = Params.Hit;
    }

    void UPossessableComponentBridgeHelper::HandlePawnControllerChanged(APawn* OwnerPawn, AController* OldController, AController* NewController)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ActorEntity.PossessableComponentBridgeHelper.HandlePawnControllerChanged");
    
        UPossessableComponentBridgeHelper___HandlePawnControllerChanged_Params Params{};
        Params.OwnerPawn = OwnerPawn;
        Params.OldController = OldController;
        Params.NewController = NewController;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

