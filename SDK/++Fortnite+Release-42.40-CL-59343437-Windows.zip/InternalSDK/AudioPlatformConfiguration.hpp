/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:12
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioPlatformConfiguration
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000010 (0x000010)
    struct alignas(0x4) FPlatformRuntimeAudioCompressionOverrides
    {
        bool    bOverrideCompressionTimes;      // 0x000000 (0x000001) [Default: false]
        uint8   UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        float   DurationThreshold;              // 0x000004 (0x000004) [Default: 0f]
        int32   MaxNumRandomBranches;           // 0x000008 (0x000004) [Default: 0]
        int32   SoundCueQualityIndex;           // 0x00000C (0x000004) [Default: 0]
    };
}

