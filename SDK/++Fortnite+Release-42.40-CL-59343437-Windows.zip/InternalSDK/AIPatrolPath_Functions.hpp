/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AIPatrolPath_Functions
 * ============================================================
 */

#include "AIPatrolPath.hpp"

namespace UE
{

    struct UAIPatrolPathComponent___CanNextPointBeReached_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAIPatrolPathComponent___GeneratePathPoints_Params
    {
        EFortCreativePatrolPathGroup    PatrolPathGroup;                // 0x000000 (0x000001) [Default: EFortCreativePatrolPathGroup(80)]
        bool                            bGenerationCausedByDuplication; // 0x000001 (0x000001) [Default: true]
    };

    struct UAIPatrolPathComponent___GetLinkedPatrolPoints_Params
    {
        TArray<UAIPatrolPathComponent*> ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAIPatrolPathComponent___GetNextAvailablePatrolPathIndex_Params
    {
        int32   NextAvailableIndex; // 0x000000 (0x000004) [OutParam] [Default: 345529936]
        bool    ReturnValue;        // 0x000004 (0x000001) [ReturnValue] [Default: false]
    };

    struct UAIPatrolPathComponent___GetPatrolFilterOptions_Params
    {
        UClass* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x14985E50]
    };

    struct UAIPatrolPathComponent___GetPatrollingMode_Params
    {
        EPatrollingMode ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EPatrollingMode(80)]
    };

    struct UAIPatrolPathComponent___GetPatrolPathGroup_Params
    {
        EFortCreativePatrolPathGroup    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EFortCreativePatrolPathGroup(80)]
    };

    struct UAIPatrolPathComponent___GetPatrolPathIndex_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 345529936]
    };

    struct UAIPatrolPathComponent___GetPatrolPathIndexFromDevice_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 345529936]
    };

    struct UAIPatrolPathComponent___GetPatrolPathPoint_Params
    {
        int32                   InPatrolPathIndex;      // 0x000000 (0x000004) [Default: 345529936]
        int32                   InPatrolPathPointIndex; // 0x000004 (0x000004) [Default: 0]
        UAIPatrolPathComponent* ReturnValue;            // 0x000008 (0x000008) [ReturnValue] [Default: 0xB56318DD00000031]
    };

    struct UAIPatrolPathComponent___GetPatrolPathPointIndex_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 345529936]
    };

    struct UAIPatrolPathComponent___GetPatrolPathPointIndexFromDevice_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 345529936]
    };

    struct UAIPatrolPathComponent___HasValidPatrolPath_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAIPatrolPathComponent___NextPatrolPointFailedToReach_Params
    {
        AFortAthenaPatrolPoint* PathPoint;          // 0x000000 (0x000008) [Default: 0x14985E50]
        AAIController*          PatrolInstigator;   // 0x000008 (0x000008) [Default: 0xB56318DD00000031]
    };

    struct UAIPatrolPathComponent___NotifyEditorUserOptionChanged_Params
    {
        TArray<FString> UserOptions;    // 0x000000 (0x000010) [OutParam]
    };

    struct UAIPatrolPathComponent___OnPathExtremitiesChanged_Params
    {
        bool    bIsStart;   // 0x000000 (0x000001) [Default: true]
        bool    bIsEnd;     // 0x000001 (0x000001) [Default: true]
    };

    struct UAIPatrolPathComponent___PatrolPathStarted_Params
    {
        AAIController*  Instigator; // 0x000000 (0x000008) [Default: 0x14985E50]
    };

    struct UAIPatrolPathComponent___PatrolPathStopped_Params
    {
        AAIController*  Instigator; // 0x000000 (0x000008) [Default: 0x14985E50]
    };

    struct UAIPatrolPathComponent___PatrolPointFailedToReach_Params
    {
        AFortAthenaPatrolPoint* PathPoint;  // 0x000000 (0x000008) [Default: 0x14985E50]
        AAIController*          Instigator; // 0x000008 (0x000008) [Default: 0xB56318DD00000031]
    };

    struct UAIPatrolPathComponent___PatrolPointReached_Params
    {
        AFortAthenaPatrolPoint* PathPoint;          // 0x000000 (0x000008) [Default: 0x14985E50]
        AAIController*          Instigator;         // 0x000008 (0x000008) [Default: 0xB56318DD00000031]
        bool                    bReachedBackward;   // 0x000010 (0x000001) [Default: true]
    };

    struct UAIPatrolPathComponent___PropagatePatrolPathIndexToDevice_Params
    {
        int32   NewPatrolPathIndex; // 0x000000 (0x000004) [Default: 345529936]
    };

    struct UAIPatrolPathComponent___PropagatePatrolPathPointIndexToDevice_Params
    {
        int32   NewPatrolPathPointIndex;    // 0x000000 (0x000004) [Default: 345529936]
    };

    struct UAIPatrolPathComponent___RemovePoint_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAIPatrolPathComponent___SetPatrollingMode_Params
    {
        EPatrollingMode NewMode;    // 0x000000 (0x000001) [Default: EPatrollingMode(80)]
    };

    struct UAIPatrolPathComponent___SetPatrolPathEnabled_Params
    {
        bool    bIsEnabled; // 0x000000 (0x000001) [Default: true]
    };

    struct UAIPatrolPathComponent___SetPatrolPathGroup_Params
    {
        EFortCreativePatrolPathGroup    PatrolPathGroup;    // 0x000000 (0x000001) [Default: EFortCreativePatrolPathGroup(80)]
    };

    struct UAIPatrolPathComponent___SetRenderPath_Params
    {
        bool    bRenderPath;    // 0x000000 (0x000001) [Default: true]
    };

    struct UAIPatrolPathComponent___ShouldRenderPath_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

} // namespace UE

