/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AVCodecsCoreRHI
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class USimpleAVHelper : public UObject
    {
    public:
    };
    // Size: 0x000070 (0x000048)
    class alignas(0x8) USimpleAudioEncoder : public UObject
    {
    public:
        void**  VTable_000028;                  // 0x000028 (0x000008) VTable [6 slots] -> 0x134AD8B0
        uint8   UnknownData_000030[0x000040];   // 0x000030 (0x000040)
    
    public: // Functions
        void                        Close(); // 0x0E3C6A18 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        ESimpleAudioCodec           GetCodec(); // 0x0E3C6AD0 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FSimpleAudioEncoderConfig   GetConfig(); // 0x0E3C6B48 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                        IsAsync(); // 0x0E3C6BE8 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                        IsOpen(); // 0x0E3C6C02 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                        Open(ESimpleAudioCodec Codec, FSimpleAudioEncoderConfig Config, bool bAsynchronous); // 0x055E3FEC [Final | RequiredAPI | Native | Public | BlueprintCallable]
        bool                        ReceivePacket(FSimpleAudioPacket& OutPacket); // 0x055E43A2 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        ReceivePackets(TArray<FSimpleAudioPacket>& OutPackets); // 0x055E4532 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        bool                        SendFrameFloat(TArray<float>& Resource, double Timestamp, int32 NumSamples, float SampleDuration); // 0x055E46C8 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        SetConfig(FSimpleAudioEncoderConfig NewConfig); // 0x055E4B40 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class USimpleAudioHelper : public USimpleAVHelper
    {
    public:
    };
    // Size: 0x000060 (0x000038)
    class alignas(0x8) USimpleVideoDecoder : public UObject
    {
    public:
        void**  VTable_000028;                  // 0x000028 (0x000008) VTable [6 slots] -> 0x134ADC00
        uint8   UnknownData_000030[0x000030];   // 0x000030 (0x000030)
    
    public: // Functions
        void                Close(); // 0x0E3C7CAA [Final | RequiredAPI | Native | Public | BlueprintCallable]
        ESimpleVideoCodec   GetCodec(); // 0x0E3C7D4E [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                IsAsync(); // 0x0E3C6BE8 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                IsOpen(); // 0x0E3C6C02 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                Open(ESimpleVideoCodec Codec, bool bAsynchronous); // 0x055E4CCC [Final | RequiredAPI | Native | Public | BlueprintCallable]
        bool                ReceiveFrame(UTextureRenderTarget2D* Resource); // 0x055E4F52 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        bool                SendPacket(FSimpleVideoPacket& Packet); // 0x055E50C8 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000070 (0x000048)
    class alignas(0x8) USimpleVideoEncoder : public UObject
    {
    public:
        void**  VTable_000028;                  // 0x000028 (0x000008) VTable [11 slots] -> 0x134ADF50
        uint8   UnknownData_000030[0x000040];   // 0x000030 (0x000040)
    
    public: // Functions
        void                        Close(); // 0x0E3C8A38 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        ESimpleVideoCodec           GetCodec(); // 0x0E3C7D4E [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FSimpleVideoEncoderConfig   GetConfig(); // 0x0E3C8AF0 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                        IsAsync(); // 0x0E3C6BE8 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                        IsOpen(); // 0x0E3C6C02 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                        Open(ESimpleVideoCodec Codec, FSimpleVideoEncoderConfig Config, bool bAsynchronous); // 0x055E52B8 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        bool                        ReceivePacket(FSimpleVideoPacket& OutPacket); // 0x055E568C [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        ReceivePackets(TArray<FSimpleVideoPacket>& OutPackets); // 0x055E587C [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        bool                        SendFrameRenderTarget(UTextureRenderTarget2D* Resource, double Timestamp, bool bForceKeyframe); // 0x055E5A12 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        bool                        SendFrameTexture(UTexture2D* Resource, double Timestamp, bool bForceKeyframe); // 0x055E5DB0 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                        SetConfig(FSimpleVideoEncoderConfig NewConfig); // 0x0E3C93FC [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class USimpleVideoHelper : public USimpleAVHelper
    {
    public:
    
    public: // Functions
        static void    ShareRenderTarget2D(UTextureRenderTarget2D* RenderTarget); // 0x055E614E [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x00000C (0x00000C)
    struct alignas(0x4) FSimpleAudioEncoderConfig
    {
        int32   bitrate;        // 0x000000 (0x000004)
        int32   SampleRate;     // 0x000004 (0x000004)
        int32   NumChannels;    // 0x000008 (0x000004)
    };
    // Size: 0x000028 (0x000028)
    struct FSimpleAudioPacket
    {
        uint8   UnknownData_000000[0x000028];   // 0x000000 (0x000028)
    };
    // Size: 0x000014 (0x000014)
    struct alignas(0x4) FSimpleVideoEncoderConfig
    {
        int32   Width;              // 0x000000 (0x000004)
        int32   Height;             // 0x000004 (0x000004)
        int32   TargetFramerate;    // 0x000008 (0x000004)
        int32   targetBitrate;      // 0x00000C (0x000004)
        int32   MaxBitrate;         // 0x000010 (0x000004)
    };
    // Size: 0x000760 (0x000760)
    struct FSimpleVideoPacket
    {
        uint8   UnknownData_000000[0x000760];   // 0x000000 (0x000760)
    };
}

