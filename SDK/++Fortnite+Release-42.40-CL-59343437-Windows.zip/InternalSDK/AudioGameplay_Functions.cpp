/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:09
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioGameplay_Functions
 * ============================================================
 */

#include "AudioGameplay_Functions.hpp"

namespace UE
{

    FGameplayTagContainer UAudioAssetUserData::GetAllTags(USoundBase* InSound)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioAssetUserData.GetAllTags");
    
        UAudioAssetUserData___GetAllTags_Params Params{};
        Params.InSound = InSound;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FGameplayTagContainer UAudioAssetUserData::GetFilteredTags(USoundBase* InSound, FGameplayTag InTag)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioAssetUserData.GetFilteredTags");
    
        UAudioAssetUserData___GetFilteredTags_Params Params{};
        Params.InSound = InSound;
        Params.InTag = InTag;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAudioAssetUserData::HasTag(USoundBase* InSound, FGameplayTag InTag, bool bExactMatch)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioAssetUserData.HasTag");
    
        UAudioAssetUserData___HasTag_Params Params{};
        Params.InSound = InSound;
        Params.InTag = InTag;
        Params.bExactMatch = bExactMatch;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioComponentGroup::AddExtension(TScriptInterface<IAudioComponentGroupExtension> NewExtension)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.AddExtension");
    
        UAudioComponentGroup___AddExtension_Params Params{};
        Params.NewExtension = NewExtension;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioComponentGroup::AddExternalComponent(UAudioComponent* ComponentToAdd)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.AddExternalComponent");
    
        UAudioComponentGroup___AddExternalComponent_Params Params{};
        Params.ComponentToAdd = ComponentToAdd;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioComponentGroup::BroadcastEvent(FName EventName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.BroadcastEvent");
    
        UAudioComponentGroup___BroadcastEvent_Params Params{};
        Params.EventName = EventName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioComponentGroup::BroadcastKill()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.BroadcastKill");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioComponentGroup::BroadcastStopAll()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.BroadcastStopAll");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioComponentGroup::DisableVirtualization()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.DisableVirtualization");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioComponentGroup::EnableVirtualization()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.EnableVirtualization");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    bool UAudioComponentGroup::GetBoolParamValue(FName ParamName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.GetBoolParamValue");
    
        UAudioComponentGroup___GetBoolParamValue_Params Params{};
        Params.ParamName = ParamName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAudioComponentGroup::GetFloatParamValue(FName ParamName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.GetFloatParamValue");
    
        UAudioComponentGroup___GetFloatParamValue_Params Params{};
        Params.ParamName = ParamName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FString UAudioComponentGroup::GetStringParamValue(FName ParamName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.GetStringParamValue");
    
        UAudioComponentGroup___GetStringParamValue_Params Params{};
        Params.ParamName = ParamName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAudioComponentGroup::IsPlayingAny()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.IsPlayingAny");
    
        UAudioComponentGroup___IsPlayingAny_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAudioComponentGroup::IsVirtualized()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.IsVirtualized");
    
        UAudioComponentGroup___IsVirtualized_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioComponentGroup::RemoveExtension(TScriptInterface<IAudioComponentGroupExtension> NewExtension)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.RemoveExtension");
    
        UAudioComponentGroup___RemoveExtension_Params Params{};
        Params.NewExtension = NewExtension;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioComponentGroup::RemoveExternalComponent(UAudioComponent* ComponentToRemove)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.RemoveExternalComponent");
    
        UAudioComponentGroup___RemoveExternalComponent_Params Params{};
        Params.ComponentToRemove = ComponentToRemove;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioComponentGroup::SetLowPassFilter(float InFrequency)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.SetLowPassFilter");
    
        UAudioComponentGroup___SetLowPassFilter_Params Params{};
        Params.InFrequency = InFrequency;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioComponentGroup::SetPitchMultiplier(float InPitch)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.SetPitchMultiplier");
    
        UAudioComponentGroup___SetPitchMultiplier_Params Params{};
        Params.InPitch = InPitch;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioComponentGroup::SetVolumeMultiplier(float InVolume)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.SetVolumeMultiplier");
    
        UAudioComponentGroup___SetVolumeMultiplier_Params Params{};
        Params.InVolume = InVolume;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UAudioComponentGroup* UAudioComponentGroup::StaticGetOrCreateComponentGroup(AActor* Actor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.StaticGetOrCreateComponentGroup");
    
        UAudioComponentGroup___StaticGetOrCreateComponentGroup_Params Params{};
        Params.Actor = Actor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioComponentGroup::StopSound(USoundBase* Sound, float FadeTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.StopSound");
    
        UAudioComponentGroup___StopSound_Params Params{};
        Params.Sound = Sound;
        Params.FadeTime = FadeTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioComponentGroup::SubscribeToBool(FName ParamName, BoolParamCallback Delegate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.SubscribeToBool");
    
        UAudioComponentGroup___SubscribeToBool_Params Params{};
        Params.ParamName = ParamName;
        Params.Delegate = Delegate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioComponentGroup::SubscribeToEvent(FName EventName, SoundCallback Delegate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.SubscribeToEvent");
    
        UAudioComponentGroup___SubscribeToEvent_Params Params{};
        Params.EventName = EventName;
        Params.Delegate = Delegate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioComponentGroup::SubscribeToStringParam(FName ParamName, StringParamCallback Delegate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.SubscribeToStringParam");
    
        UAudioComponentGroup___SubscribeToStringParam_Params Params{};
        Params.ParamName = ParamName;
        Params.Delegate = Delegate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioComponentGroup::UnsubscribeObject(UObject* Object)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioComponentGroup.UnsubscribeObject");
    
        UAudioComponentGroup___UnsubscribeObject_Params Params{};
        Params.Object = Object;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool IAudioGameplayCondition::ConditionMet()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioGameplayCondition.ConditionMet");
    
        IAudioGameplayCondition___ConditionMet_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool IAudioGameplayCondition::ConditionMet_Position(FVector& Position)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioGameplayCondition.ConditionMet_Position");
    
        IAudioGameplayCondition___ConditionMet_Position_Params Params{};
        Params.Position = Position;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Position = Params.Position;
    
        return Params.ReturnValue;
    }

    void IAudioGameplayVolumeInteraction::OnListenerEnter()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioGameplayVolumeInteraction.OnListenerEnter");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void IAudioGameplayVolumeInteraction::OnListenerExit()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioGameplayVolumeInteraction.OnListenerExit");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    TArray<FAudioParameter> UAudioParameterComponent::GetParameters()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplay.AudioParameterComponent.GetParameters");
    
        UAudioParameterComponent___GetParameters_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

} // namespace UE

