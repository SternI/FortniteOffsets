/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BattleRoyaleFrontend_Functions
 * ============================================================
 */

#include "BattleRoyaleFrontend_Functions.hpp"

namespace UE
{

    void UBattleRoyaleFrontendExperienceFlow::FinishTrailerStep()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleRoyaleFrontend.BattleRoyaleFrontendExperienceFlow.FinishTrailerStep");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBattleRoyaleFrontendExperienceFlow::HandleBattlePassTrailerEnded()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleRoyaleFrontend.BattleRoyaleFrontendExperienceFlow.HandleBattlePassTrailerEnded");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBattleRoyaleFrontendExperienceFlow::HandleSeasonTrailerEnded()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleRoyaleFrontend.BattleRoyaleFrontendExperienceFlow.HandleSeasonTrailerEnded");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBattleRoyaleFrontendExperienceFlow::HandleVideoTerminalError(EBaseMediaTerminalErrorReason Reason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleRoyaleFrontend.BattleRoyaleFrontendExperienceFlow.HandleVideoTerminalError");
    
        UBattleRoyaleFrontendExperienceFlow___HandleVideoTerminalError_Params Params{};
        Params.Reason = Reason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

