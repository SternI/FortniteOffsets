/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:48
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeetCalf/Gameplay/Mutators/B_Mutator_BeetCalfDrawKeyCarrier
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0002F0 (0x000000)
    class AB_Mutator_BeetCalfDrawKeyCarrier_C : public AFortAthenaMutator_DrawTaggedPlayerIndicators
    {
    public:
    };
}

