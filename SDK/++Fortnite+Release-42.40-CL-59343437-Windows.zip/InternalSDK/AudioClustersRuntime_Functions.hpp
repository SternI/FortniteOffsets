/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioClustersRuntime_Functions
 * ============================================================
 */

#include "AudioClustersRuntime.hpp"

namespace UE
{

    struct UAudioClusterBehavior___OnActorAdded_Params
    {
        AActor* Actor;  // 0x000000 (0x000008) [Default: 0x148EB630]
    };

    struct UAudioClusterBehavior___OnActorRemoved_Params
    {
        AActor* Actor;  // 0x000000 (0x000008) [Default: 0x148EB630]
    };

    struct UAudioClusterBehavior___OnPositionUpdated_Params
    {
        FVector NewPosition;    // 0x000000 (0x000018) [OutParam]
    };

    struct UAudioClusterBehavior___OnSizeUpdated_Params
    {
        int32   NewSize;    // 0x000000 (0x000004) [Default: 344897072]
    };

    struct UAudioClusterBehavior___OnStart_Params
    {
        int32   InitialSize;    // 0x000000 (0x000004) [Default: 344897072]
    };

    struct UAudioClusterFunctionLibrary___IsAudioClusterConfigurationsHandleValid_Params
    {
        UObject*                            WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        FAudioClusterConfigurationsHandle   Handle;             // 0x000008 (0x000020) [OutParam]
        bool                                ReturnValue;        // 0x000028 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioClusterFunctionLibrary___RegisterClusterConfigurations_Params
    {
        UObject*                            WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        UAudioClusterConfigurations*        Configurations;     // 0x000008 (0x000008) [Default: 0x925D18DD00000031]
        FAudioClusterConfigurationsHandle   ReturnValue;        // 0x000010 (0x000020) [ReturnValue]
    };

    struct UAudioClusterFunctionLibrary___UnregisterClusterConfigurations_Params
    {
        UObject*                            WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        FAudioClusterConfigurationsHandle   Handle;             // 0x000008 (0x000020) [OutParam]
    };

} // namespace UE

