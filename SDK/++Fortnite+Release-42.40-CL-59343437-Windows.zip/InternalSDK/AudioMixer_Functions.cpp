/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:10
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioMixer_Functions
 * ============================================================
 */

#include "AudioMixer_Functions.hpp"

namespace UE
{

    void UAudioMixerBlueprintLibrary::AddMasterSubmixEffect(UObject* WorldContextObject, USoundEffectSubmixPreset* SubmixEffectPreset)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.AddMasterSubmixEffect");
    
        UAudioMixerBlueprintLibrary___AddMasterSubmixEffect_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.SubmixEffectPreset = SubmixEffectPreset;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::AddSourceEffectToPresetChain(UObject* WorldContextObject, USoundEffectSourcePresetChain* PresetChain, FSourceEffectChainEntry Entry)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.AddSourceEffectToPresetChain");
    
        UAudioMixerBlueprintLibrary___AddSourceEffectToPresetChain_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.PresetChain = PresetChain;
        Params.Entry = Entry;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    int32 UAudioMixerBlueprintLibrary::AddSubmixEffect(UObject* WorldContextObject, USoundSubmix* SoundSubmix, USoundEffectSubmixPreset* SubmixEffectPreset)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.AddSubmixEffect");
    
        UAudioMixerBlueprintLibrary___AddSubmixEffect_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.SoundSubmix = SoundSubmix;
        Params.SubmixEffectPreset = SubmixEffectPreset;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioMixerBlueprintLibrary::ClearMasterSubmixEffects(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.ClearMasterSubmixEffects");
    
        UAudioMixerBlueprintLibrary___ClearMasterSubmixEffects_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::ClearSubmixEffectChainOverride(UObject* WorldContextObject, USoundSubmix* SoundSubmix, float FadeTimeSec)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffectChainOverride");
    
        UAudioMixerBlueprintLibrary___ClearSubmixEffectChainOverride_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.SoundSubmix = SoundSubmix;
        Params.FadeTimeSec = FadeTimeSec;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::ClearSubmixEffects(UObject* WorldContextObject, USoundSubmix* SoundSubmix)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffects");
    
        UAudioMixerBlueprintLibrary___ClearSubmixEffects_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.SoundSubmix = SoundSubmix;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    FString UAudioMixerBlueprintLibrary::Conv_AudioOutputDeviceInfoToString(FAudioOutputDeviceInfo& Info)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.Conv_AudioOutputDeviceInfoToString");
    
        UAudioMixerBlueprintLibrary___Conv_AudioOutputDeviceInfoToString_Params Params{};
        Params.Info = Info;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Info = Params.Info;
    
        return Params.ReturnValue;
    }

    void UAudioMixerBlueprintLibrary::GetAvailableAudioOutputDevices(UObject* WorldContextObject, OnAudioOutputDevicesObtained& OnObtainDevicesEvent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.GetAvailableAudioOutputDevices");
    
        UAudioMixerBlueprintLibrary___GetAvailableAudioOutputDevices_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.OnObtainDevicesEvent = OnObtainDevicesEvent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OnObtainDevicesEvent = Params.OnObtainDevicesEvent;
    }

    void UAudioMixerBlueprintLibrary::GetCurrentAudioOutputDeviceName(UObject* WorldContextObject, OnMainAudioOutputDeviceObtained& OnObtainCurrentDeviceEvent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.GetCurrentAudioOutputDeviceName");
    
        UAudioMixerBlueprintLibrary___GetCurrentAudioOutputDeviceName_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.OnObtainCurrentDeviceEvent = OnObtainCurrentDeviceEvent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OnObtainCurrentDeviceEvent = Params.OnObtainCurrentDeviceEvent;
    }

    void UAudioMixerBlueprintLibrary::GetMagnitudeForFrequencies(UObject* WorldContextObject, TArray<float>& Frequencies, TArray<float>& Magnitudes, USoundSubmix* SubmixToAnalyze)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.GetMagnitudeForFrequencies");
    
        UAudioMixerBlueprintLibrary___GetMagnitudeForFrequencies_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Frequencies = Frequencies;
        Params.Magnitudes = Magnitudes;
        Params.SubmixToAnalyze = SubmixToAnalyze;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Frequencies = Params.Frequencies;
        Magnitudes = Params.Magnitudes;
    }

    int32 UAudioMixerBlueprintLibrary::GetNumberOfEntriesInSourceEffectChain(UObject* WorldContextObject, USoundEffectSourcePresetChain* PresetChain)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.GetNumberOfEntriesInSourceEffectChain");
    
        UAudioMixerBlueprintLibrary___GetNumberOfEntriesInSourceEffectChain_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.PresetChain = PresetChain;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioMixerBlueprintLibrary::GetPhaseForFrequencies(UObject* WorldContextObject, TArray<float>& Frequencies, TArray<float>& Phases, USoundSubmix* SubmixToAnalyze)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.GetPhaseForFrequencies");
    
        UAudioMixerBlueprintLibrary___GetPhaseForFrequencies_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Frequencies = Frequencies;
        Params.Phases = Phases;
        Params.SubmixToAnalyze = SubmixToAnalyze;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Frequencies = Params.Frequencies;
        Phases = Params.Phases;
    }

    bool UAudioMixerBlueprintLibrary::IsAudioBusActive(UObject* WorldContextObject, UAudioBus* AudioBus)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.IsAudioBusActive");
    
        UAudioMixerBlueprintLibrary___IsAudioBusActive_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.AudioBus = AudioBus;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FSoundSubmixSpectralAnalysisBandSettings> UAudioMixerBlueprintLibrary::MakeFullSpectrumSpectralAnalysisBandSettings(int32 InNumBands, float InMinimumFrequency, float InMaximumFrequency, int32 InAttackTimeMsec, int32 InReleaseTimeMsec)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.MakeFullSpectrumSpectralAnalysisBandSettings");
    
        UAudioMixerBlueprintLibrary___MakeFullSpectrumSpectralAnalysisBandSettings_Params Params{};
        Params.InNumBands = InNumBands;
        Params.InMinimumFrequency = InMinimumFrequency;
        Params.InMaximumFrequency = InMaximumFrequency;
        Params.InAttackTimeMsec = InAttackTimeMsec;
        Params.InReleaseTimeMsec = InReleaseTimeMsec;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FSoundSubmixSpectralAnalysisBandSettings> UAudioMixerBlueprintLibrary::MakeMusicalSpectralAnalysisBandSettings(int32 InNumSemitones, EMusicalNoteName InStartingMusicalNote, int32 InStartingOctave, int32 InAttackTimeMsec, int32 InReleaseTimeMsec)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.MakeMusicalSpectralAnalysisBandSettings");
    
        UAudioMixerBlueprintLibrary___MakeMusicalSpectralAnalysisBandSettings_Params Params{};
        Params.InNumSemitones = InNumSemitones;
        Params.InStartingMusicalNote = InStartingMusicalNote;
        Params.InStartingOctave = InStartingOctave;
        Params.InAttackTimeMsec = InAttackTimeMsec;
        Params.InReleaseTimeMsec = InReleaseTimeMsec;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FSoundSubmixSpectralAnalysisBandSettings> UAudioMixerBlueprintLibrary::MakePresetSpectralAnalysisBandSettings(EAudioSpectrumBandPresetType InBandPresetType, int32 InNumBands, int32 InAttackTimeMsec, int32 InReleaseTimeMsec)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.MakePresetSpectralAnalysisBandSettings");
    
        UAudioMixerBlueprintLibrary___MakePresetSpectralAnalysisBandSettings_Params Params{};
        Params.InBandPresetType = InBandPresetType;
        Params.InNumBands = InNumBands;
        Params.InAttackTimeMsec = InAttackTimeMsec;
        Params.InReleaseTimeMsec = InReleaseTimeMsec;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioMixerBlueprintLibrary::PauseRecordingOutput(UObject* WorldContextObject, USoundSubmix* SubmixToPause)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.PauseRecordingOutput");
    
        UAudioMixerBlueprintLibrary___PauseRecordingOutput_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.SubmixToPause = SubmixToPause;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::PrimeSoundCueForPlayback(USoundCue* SoundCue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundCueForPlayback");
    
        UAudioMixerBlueprintLibrary___PrimeSoundCueForPlayback_Params Params{};
        Params.SoundCue = SoundCue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::PrimeSoundForPlayback(USoundWave* SoundWave, OnSoundLoadComplete OnLoadCompletion)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundForPlayback");
    
        UAudioMixerBlueprintLibrary___PrimeSoundForPlayback_Params Params{};
        Params.SoundWave = SoundWave;
        Params.OnLoadCompletion = OnLoadCompletion;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::RegisterAudioBusToSubmix(UObject* WorldContextObject, USoundSubmix* SoundSubmix, UAudioBus* AudioBus)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.RegisterAudioBusToSubmix");
    
        UAudioMixerBlueprintLibrary___RegisterAudioBusToSubmix_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.SoundSubmix = SoundSubmix;
        Params.AudioBus = AudioBus;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::RemoveMasterSubmixEffect(UObject* WorldContextObject, USoundEffectSubmixPreset* SubmixEffectPreset)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.RemoveMasterSubmixEffect");
    
        UAudioMixerBlueprintLibrary___RemoveMasterSubmixEffect_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.SubmixEffectPreset = SubmixEffectPreset;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::RemoveSourceEffectFromPresetChain(UObject* WorldContextObject, USoundEffectSourcePresetChain* PresetChain, int32 EntryIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.RemoveSourceEffectFromPresetChain");
    
        UAudioMixerBlueprintLibrary___RemoveSourceEffectFromPresetChain_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.PresetChain = PresetChain;
        Params.EntryIndex = EntryIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::RemoveSubmixEffect(UObject* WorldContextObject, USoundSubmix* SoundSubmix, USoundEffectSubmixPreset* SubmixEffectPreset)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffect");
    
        UAudioMixerBlueprintLibrary___RemoveSubmixEffect_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.SoundSubmix = SoundSubmix;
        Params.SubmixEffectPreset = SubmixEffectPreset;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::RemoveSubmixEffectAtIndex(UObject* WorldContextObject, USoundSubmix* SoundSubmix, int32 SubmixChainIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectAtIndex");
    
        UAudioMixerBlueprintLibrary___RemoveSubmixEffectAtIndex_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.SoundSubmix = SoundSubmix;
        Params.SubmixChainIndex = SubmixChainIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::RemoveSubmixEffectPreset(UObject* WorldContextObject, USoundSubmix* SoundSubmix, USoundEffectSubmixPreset* SubmixEffectPreset)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPreset");
    
        UAudioMixerBlueprintLibrary___RemoveSubmixEffectPreset_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.SoundSubmix = SoundSubmix;
        Params.SubmixEffectPreset = SubmixEffectPreset;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::RemoveSubmixEffectPresetAtIndex(UObject* WorldContextObject, USoundSubmix* SoundSubmix, int32 SubmixChainIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPresetAtIndex");
    
        UAudioMixerBlueprintLibrary___RemoveSubmixEffectPresetAtIndex_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.SoundSubmix = SoundSubmix;
        Params.SubmixChainIndex = SubmixChainIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::ReplaceSoundEffectSubmix(UObject* WorldContextObject, USoundSubmix* InSoundSubmix, int32 SubmixChainIndex, USoundEffectSubmixPreset* SubmixEffectPreset)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.ReplaceSoundEffectSubmix");
    
        UAudioMixerBlueprintLibrary___ReplaceSoundEffectSubmix_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.InSoundSubmix = InSoundSubmix;
        Params.SubmixChainIndex = SubmixChainIndex;
        Params.SubmixEffectPreset = SubmixEffectPreset;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::ReplaceSubmixEffect(UObject* WorldContextObject, USoundSubmix* InSoundSubmix, int32 SubmixChainIndex, USoundEffectSubmixPreset* SubmixEffectPreset)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.ReplaceSubmixEffect");
    
        UAudioMixerBlueprintLibrary___ReplaceSubmixEffect_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.InSoundSubmix = InSoundSubmix;
        Params.SubmixChainIndex = SubmixChainIndex;
        Params.SubmixEffectPreset = SubmixEffectPreset;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::ResumeRecordingOutput(UObject* WorldContextObject, USoundSubmix* SubmixToPause)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.ResumeRecordingOutput");
    
        UAudioMixerBlueprintLibrary___ResumeRecordingOutput_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.SubmixToPause = SubmixToPause;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::SetBypassSourceEffectChainEntry(UObject* WorldContextObject, USoundEffectSourcePresetChain* PresetChain, int32 EntryIndex, bool bBypassed)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.SetBypassSourceEffectChainEntry");
    
        UAudioMixerBlueprintLibrary___SetBypassSourceEffectChainEntry_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.PresetChain = PresetChain;
        Params.EntryIndex = EntryIndex;
        Params.bBypassed = bBypassed;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::SetSubmixEffectChainOverride(UObject* WorldContextObject, USoundSubmix* SoundSubmix, TArray<USoundEffectSubmixPreset*> SubmixEffectPresetChain, float FadeTimeSec)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.SetSubmixEffectChainOverride");
    
        UAudioMixerBlueprintLibrary___SetSubmixEffectChainOverride_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.SoundSubmix = SoundSubmix;
        Params.SubmixEffectPresetChain = SubmixEffectPresetChain;
        Params.FadeTimeSec = FadeTimeSec;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::StartAnalyzingOutput(UObject* WorldContextObject, USoundSubmix* SubmixToAnalyze, EFFTSize FFTSize, EFFTPeakInterpolationMethod InterpolationMethod, EFFTWindowType WindowType, float HopSize, EAudioSpectrumType SpectrumType)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.StartAnalyzingOutput");
    
        UAudioMixerBlueprintLibrary___StartAnalyzingOutput_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.SubmixToAnalyze = SubmixToAnalyze;
        Params.FFTSize = FFTSize;
        Params.InterpolationMethod = InterpolationMethod;
        Params.WindowType = WindowType;
        Params.HopSize = HopSize;
        Params.SpectrumType = SpectrumType;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::StartAudioBus(UObject* WorldContextObject, UAudioBus* AudioBus)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.StartAudioBus");
    
        UAudioMixerBlueprintLibrary___StartAudioBus_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.AudioBus = AudioBus;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::StartRecordingOutput(UObject* WorldContextObject, float ExpectedDuration, USoundSubmix* SubmixToRecord)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.StartRecordingOutput");
    
        UAudioMixerBlueprintLibrary___StartRecordingOutput_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.ExpectedDuration = ExpectedDuration;
        Params.SubmixToRecord = SubmixToRecord;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::StopAnalyzingOutput(UObject* WorldContextObject, USoundSubmix* SubmixToStopAnalyzing)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.StopAnalyzingOutput");
    
        UAudioMixerBlueprintLibrary___StopAnalyzingOutput_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.SubmixToStopAnalyzing = SubmixToStopAnalyzing;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMixerBlueprintLibrary::StopAudioBus(UObject* WorldContextObject, UAudioBus* AudioBus)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.StopAudioBus");
    
        UAudioMixerBlueprintLibrary___StopAudioBus_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.AudioBus = AudioBus;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    USoundWave* UAudioMixerBlueprintLibrary::StopRecordingOutput(UObject* WorldContextObject, EAudioRecordingExportType ExportType, FString Name, FString Path, USoundSubmix* SubmixToRecord, USoundWave* ExistingSoundWaveToOverwrite)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.StopRecordingOutput");
    
        UAudioMixerBlueprintLibrary___StopRecordingOutput_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.ExportType = ExportType;
        Params.Name = Name;
        Params.Path = Path;
        Params.SubmixToRecord = SubmixToRecord;
        Params.ExistingSoundWaveToOverwrite = ExistingSoundWaveToOverwrite;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioMixerBlueprintLibrary::SwapAudioOutputDevice(UObject* WorldContextObject, FString NewDeviceId, OnCompletedDeviceSwap& OnCompletedDeviceSwap)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.SwapAudioOutputDevice");
    
        UAudioMixerBlueprintLibrary___SwapAudioOutputDevice_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.NewDeviceId = NewDeviceId;
        Params.OnCompletedDeviceSwap = OnCompletedDeviceSwap;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OnCompletedDeviceSwap = Params.OnCompletedDeviceSwap;
    }

    float UAudioMixerBlueprintLibrary::TrimAudioCache(float InMegabytesToFree)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.TrimAudioCache");
    
        UAudioMixerBlueprintLibrary___TrimAudioCache_Params Params{};
        Params.InMegabytesToFree = InMegabytesToFree;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioMixerBlueprintLibrary::UnregisterAudioBusFromSubmix(UObject* WorldContextObject, USoundSubmix* SoundSubmix, UAudioBus* AudioBus)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.AudioMixerBlueprintLibrary.UnregisterAudioBusFromSubmix");
    
        UAudioMixerBlueprintLibrary___UnregisterAudioBusFromSubmix_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.SoundSubmix = SoundSubmix;
        Params.AudioBus = AudioBus;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    float UQuartzClockHandle::GetBeatProgressPercent(EQuartzCommandQuantization QuantizationBoundary, float PhaseOffset, float MSOffset)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.GetBeatProgressPercent");
    
        UQuartzClockHandle___GetBeatProgressPercent_Params Params{};
        Params.QuantizationBoundary = QuantizationBoundary;
        Params.PhaseOffset = PhaseOffset;
        Params.MSOffset = MSOffset;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UQuartzClockHandle::GetBeatsPerMinute(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.GetBeatsPerMinute");
    
        UQuartzClockHandle___GetBeatsPerMinute_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FQuartzTransportTimeStamp UQuartzClockHandle::GetCurrentTimestamp(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.GetCurrentTimestamp");
    
        UQuartzClockHandle___GetCurrentTimestamp_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UQuartzClockHandle::GetDurationOfQuantizationTypeInSeconds(UObject* WorldContextObject, EQuartzCommandQuantization& QuantizationType, float Multiplier)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.GetDurationOfQuantizationTypeInSeconds");
    
        UQuartzClockHandle___GetDurationOfQuantizationTypeInSeconds_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.QuantizationType = QuantizationType;
        Params.Multiplier = Multiplier;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        QuantizationType = Params.QuantizationType;
    
        return Params.ReturnValue;
    }

    float UQuartzClockHandle::GetEstimatedRunTime(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.GetEstimatedRunTime");
    
        UQuartzClockHandle___GetEstimatedRunTime_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UQuartzClockHandle::GetMillisecondsPerTick(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.GetMillisecondsPerTick");
    
        UQuartzClockHandle___GetMillisecondsPerTick_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UQuartzClockHandle::GetSecondsPerTick(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.GetSecondsPerTick");
    
        UQuartzClockHandle___GetSecondsPerTick_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UQuartzClockHandle::GetThirtySecondNotesPerMinute(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.GetThirtySecondNotesPerMinute");
    
        UQuartzClockHandle___GetThirtySecondNotesPerMinute_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UQuartzClockHandle::GetTicksPerSecond(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.GetTicksPerSecond");
    
        UQuartzClockHandle___GetTicksPerSecond_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UQuartzClockHandle::IsClockRunning(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.IsClockRunning");
    
        UQuartzClockHandle___IsClockRunning_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UQuartzClockHandle::NotifyOnQuantizationBoundary(UObject* WorldContextObject, FQuartzQuantizationBoundary InQuantizationBoundary, OnQuartzCommandEventBP& InDelegate, float InMsOffset)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.NotifyOnQuantizationBoundary");
    
        UQuartzClockHandle___NotifyOnQuantizationBoundary_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.InQuantizationBoundary = InQuantizationBoundary;
        Params.InDelegate = InDelegate;
        Params.InMsOffset = InMsOffset;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InDelegate = Params.InDelegate;
    }

    void UQuartzClockHandle::PauseClock(UObject* WorldContextObject, UQuartzClockHandle*& ClockHandle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.PauseClock");
    
        UQuartzClockHandle___PauseClock_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.ClockHandle = ClockHandle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ClockHandle = Params.ClockHandle;
    }

    void UQuartzClockHandle::ResetTransport(UObject* WorldContextObject, OnQuartzCommandEventBP& InDelegate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.ResetTransport");
    
        UQuartzClockHandle___ResetTransport_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.InDelegate = InDelegate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InDelegate = Params.InDelegate;
    }

    void UQuartzClockHandle::ResetTransportQuantized(UObject* WorldContextObject, FQuartzQuantizationBoundary InQuantizationBoundary, OnQuartzCommandEventBP& InDelegate, UQuartzClockHandle*& ClockHandle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.ResetTransportQuantized");
    
        UQuartzClockHandle___ResetTransportQuantized_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.InQuantizationBoundary = InQuantizationBoundary;
        Params.InDelegate = InDelegate;
        Params.ClockHandle = ClockHandle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InDelegate = Params.InDelegate;
        ClockHandle = Params.ClockHandle;
    }

    void UQuartzClockHandle::ResumeClock(UObject* WorldContextObject, UQuartzClockHandle*& ClockHandle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.ResumeClock");
    
        UQuartzClockHandle___ResumeClock_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.ClockHandle = ClockHandle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ClockHandle = Params.ClockHandle;
    }

    void UQuartzClockHandle::SetBeatsPerMinute(UObject* WorldContextObject, FQuartzQuantizationBoundary& QuantizationBoundary, OnQuartzCommandEventBP& Delegate, UQuartzClockHandle*& ClockHandle, float BeatsPerMinute)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.SetBeatsPerMinute");
    
        UQuartzClockHandle___SetBeatsPerMinute_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.QuantizationBoundary = QuantizationBoundary;
        Params.Delegate = Delegate;
        Params.ClockHandle = ClockHandle;
        Params.BeatsPerMinute = BeatsPerMinute;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        QuantizationBoundary = Params.QuantizationBoundary;
        Delegate = Params.Delegate;
        ClockHandle = Params.ClockHandle;
    }

    void UQuartzClockHandle::SetMillisecondsPerTick(UObject* WorldContextObject, FQuartzQuantizationBoundary& QuantizationBoundary, OnQuartzCommandEventBP& Delegate, UQuartzClockHandle*& ClockHandle, float MillisecondsPerTick)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.SetMillisecondsPerTick");
    
        UQuartzClockHandle___SetMillisecondsPerTick_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.QuantizationBoundary = QuantizationBoundary;
        Params.Delegate = Delegate;
        Params.ClockHandle = ClockHandle;
        Params.MillisecondsPerTick = MillisecondsPerTick;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        QuantizationBoundary = Params.QuantizationBoundary;
        Delegate = Params.Delegate;
        ClockHandle = Params.ClockHandle;
    }

    void UQuartzClockHandle::SetSecondsPerTick(UObject* WorldContextObject, FQuartzQuantizationBoundary& QuantizationBoundary, OnQuartzCommandEventBP& Delegate, UQuartzClockHandle*& ClockHandle, float SecondsPerTick)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.SetSecondsPerTick");
    
        UQuartzClockHandle___SetSecondsPerTick_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.QuantizationBoundary = QuantizationBoundary;
        Params.Delegate = Delegate;
        Params.ClockHandle = ClockHandle;
        Params.SecondsPerTick = SecondsPerTick;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        QuantizationBoundary = Params.QuantizationBoundary;
        Delegate = Params.Delegate;
        ClockHandle = Params.ClockHandle;
    }

    void UQuartzClockHandle::SetThirtySecondNotesPerMinute(UObject* WorldContextObject, FQuartzQuantizationBoundary& QuantizationBoundary, OnQuartzCommandEventBP& Delegate, UQuartzClockHandle*& ClockHandle, float ThirtySecondsNotesPerMinute)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.SetThirtySecondNotesPerMinute");
    
        UQuartzClockHandle___SetThirtySecondNotesPerMinute_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.QuantizationBoundary = QuantizationBoundary;
        Params.Delegate = Delegate;
        Params.ClockHandle = ClockHandle;
        Params.ThirtySecondsNotesPerMinute = ThirtySecondsNotesPerMinute;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        QuantizationBoundary = Params.QuantizationBoundary;
        Delegate = Params.Delegate;
        ClockHandle = Params.ClockHandle;
    }

    void UQuartzClockHandle::SetTicksPerSecond(UObject* WorldContextObject, FQuartzQuantizationBoundary& QuantizationBoundary, OnQuartzCommandEventBP& Delegate, UQuartzClockHandle*& ClockHandle, float TicksPerSecond)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.SetTicksPerSecond");
    
        UQuartzClockHandle___SetTicksPerSecond_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.QuantizationBoundary = QuantizationBoundary;
        Params.Delegate = Delegate;
        Params.ClockHandle = ClockHandle;
        Params.TicksPerSecond = TicksPerSecond;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        QuantizationBoundary = Params.QuantizationBoundary;
        Delegate = Params.Delegate;
        ClockHandle = Params.ClockHandle;
    }

    void UQuartzClockHandle::StartClock(UObject* WorldContextObject, UQuartzClockHandle*& ClockHandle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.StartClock");
    
        UQuartzClockHandle___StartClock_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.ClockHandle = ClockHandle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ClockHandle = Params.ClockHandle;
    }

    void UQuartzClockHandle::StartOtherClock(UObject* WorldContextObject, FName OtherClockName, FQuartzQuantizationBoundary InQuantizationBoundary, OnQuartzCommandEventBP& InDelegate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.StartOtherClock");
    
        UQuartzClockHandle___StartOtherClock_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.OtherClockName = OtherClockName;
        Params.InQuantizationBoundary = InQuantizationBoundary;
        Params.InDelegate = InDelegate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InDelegate = Params.InDelegate;
    }

    void UQuartzClockHandle::StopClock(UObject* WorldContextObject, bool CancelPendingEvents, UQuartzClockHandle*& ClockHandle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.StopClock");
    
        UQuartzClockHandle___StopClock_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.CancelPendingEvents = CancelPendingEvents;
        Params.ClockHandle = ClockHandle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ClockHandle = Params.ClockHandle;
    }

    void UQuartzClockHandle::SubscribeToAllQuantizationEvents(UObject* WorldContextObject, OnQuartzMetronomeEventBP& OnQuantizationEvent, UQuartzClockHandle*& ClockHandle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.SubscribeToAllQuantizationEvents");
    
        UQuartzClockHandle___SubscribeToAllQuantizationEvents_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.OnQuantizationEvent = OnQuantizationEvent;
        Params.ClockHandle = ClockHandle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OnQuantizationEvent = Params.OnQuantizationEvent;
        ClockHandle = Params.ClockHandle;
    }

    void UQuartzClockHandle::SubscribeToQuantizationEvent(UObject* WorldContextObject, EQuartzCommandQuantization InQuantizationBoundary, OnQuartzMetronomeEventBP& OnQuantizationEvent, UQuartzClockHandle*& ClockHandle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.SubscribeToQuantizationEvent");
    
        UQuartzClockHandle___SubscribeToQuantizationEvent_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.InQuantizationBoundary = InQuantizationBoundary;
        Params.OnQuantizationEvent = OnQuantizationEvent;
        Params.ClockHandle = ClockHandle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OnQuantizationEvent = Params.OnQuantizationEvent;
        ClockHandle = Params.ClockHandle;
    }

    void UQuartzClockHandle::UnsubscribeFromAllTimeDivisions(UObject* WorldContextObject, UQuartzClockHandle*& ClockHandle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.UnsubscribeFromAllTimeDivisions");
    
        UQuartzClockHandle___UnsubscribeFromAllTimeDivisions_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.ClockHandle = ClockHandle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ClockHandle = Params.ClockHandle;
    }

    void UQuartzClockHandle::UnsubscribeFromTimeDivision(UObject* WorldContextObject, EQuartzCommandQuantization InQuantizationBoundary, UQuartzClockHandle*& ClockHandle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzClockHandle.UnsubscribeFromTimeDivision");
    
        UQuartzClockHandle___UnsubscribeFromTimeDivision_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.InQuantizationBoundary = InQuantizationBoundary;
        Params.ClockHandle = ClockHandle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ClockHandle = Params.ClockHandle;
    }

    UQuartzClockHandle* UQuartzSubsystem::CreateNewClock(UObject* WorldContextObject, FName ClockName, FQuartzClockSettings InSettings, bool bOverrideSettingsIfClockExists, bool bUseAudioEngineClockManager)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.CreateNewClock");
    
        UQuartzSubsystem___CreateNewClock_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.ClockName = ClockName;
        Params.InSettings = InSettings;
        Params.bOverrideSettingsIfClockExists = bOverrideSettingsIfClockExists;
        Params.bUseAudioEngineClockManager = bUseAudioEngineClockManager;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UQuartzSubsystem::DeleteClockByHandle(UObject* WorldContextObject, UQuartzClockHandle*& InClockHandle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.DeleteClockByHandle");
    
        UQuartzSubsystem___DeleteClockByHandle_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.InClockHandle = InClockHandle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InClockHandle = Params.InClockHandle;
    }

    void UQuartzSubsystem::DeleteClockByName(UObject* WorldContextObject, FName ClockName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.DeleteClockByName");
    
        UQuartzSubsystem___DeleteClockByName_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.ClockName = ClockName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UQuartzSubsystem::DoesClockExist(UObject* WorldContextObject, FName ClockName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.DoesClockExist");
    
        UQuartzSubsystem___DoesClockExist_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.ClockName = ClockName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UQuartzSubsystem::GetAudioRenderThreadToGameThreadAverageLatency()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadAverageLatency");
    
        UQuartzSubsystem___GetAudioRenderThreadToGameThreadAverageLatency_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UQuartzSubsystem::GetAudioRenderThreadToGameThreadMaxLatency()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadMaxLatency");
    
        UQuartzSubsystem___GetAudioRenderThreadToGameThreadMaxLatency_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UQuartzSubsystem::GetAudioRenderThreadToGameThreadMinLatency()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadMinLatency");
    
        UQuartzSubsystem___GetAudioRenderThreadToGameThreadMinLatency_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FQuartzTransportTimeStamp UQuartzSubsystem::GetCurrentClockTimestamp(UObject* WorldContextObject, FName& InClockName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.GetCurrentClockTimestamp");
    
        UQuartzSubsystem___GetCurrentClockTimestamp_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.InClockName = InClockName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InClockName = Params.InClockName;
    
        return Params.ReturnValue;
    }

    float UQuartzSubsystem::GetDurationOfQuantizationTypeInSeconds(UObject* WorldContextObject, FName ClockName, EQuartzCommandQuantization& QuantizationType, float Multiplier)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.GetDurationOfQuantizationTypeInSeconds");
    
        UQuartzSubsystem___GetDurationOfQuantizationTypeInSeconds_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.ClockName = ClockName;
        Params.QuantizationType = QuantizationType;
        Params.Multiplier = Multiplier;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        QuantizationType = Params.QuantizationType;
    
        return Params.ReturnValue;
    }

    float UQuartzSubsystem::GetEstimatedClockRunTime(UObject* WorldContextObject, FName& InClockName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.GetEstimatedClockRunTime");
    
        UQuartzSubsystem___GetEstimatedClockRunTime_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.InClockName = InClockName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InClockName = Params.InClockName;
    
        return Params.ReturnValue;
    }

    float UQuartzSubsystem::GetGameThreadToAudioRenderThreadAverageLatency(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadAverageLatency");
    
        UQuartzSubsystem___GetGameThreadToAudioRenderThreadAverageLatency_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UQuartzSubsystem::GetGameThreadToAudioRenderThreadMaxLatency(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadMaxLatency");
    
        UQuartzSubsystem___GetGameThreadToAudioRenderThreadMaxLatency_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UQuartzSubsystem::GetGameThreadToAudioRenderThreadMinLatency(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadMinLatency");
    
        UQuartzSubsystem___GetGameThreadToAudioRenderThreadMinLatency_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UQuartzClockHandle* UQuartzSubsystem::GetHandleForClock(UObject* WorldContextObject, FName ClockName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.GetHandleForClock");
    
        UQuartzSubsystem___GetHandleForClock_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.ClockName = ClockName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UQuartzSubsystem::GetRoundTripAverageLatency(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.GetRoundTripAverageLatency");
    
        UQuartzSubsystem___GetRoundTripAverageLatency_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UQuartzSubsystem::GetRoundTripMaxLatency(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.GetRoundTripMaxLatency");
    
        UQuartzSubsystem___GetRoundTripMaxLatency_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UQuartzSubsystem::GetRoundTripMinLatency(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.GetRoundTripMinLatency");
    
        UQuartzSubsystem___GetRoundTripMinLatency_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UQuartzSubsystem::IsClockRunning(UObject* WorldContextObject, FName ClockName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.IsClockRunning");
    
        UQuartzSubsystem___IsClockRunning_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.ClockName = ClockName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UQuartzSubsystem::IsQuartzEnabled()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.IsQuartzEnabled");
    
        UQuartzSubsystem___IsQuartzEnabled_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UQuartzSubsystem::SetQuartzSubsystemTickableWhenPaused(bool bInTickableWhenPaused)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.QuartzSubsystem.SetQuartzSubsystemTickableWhenPaused");
    
        UQuartzSubsystem___SetQuartzSubsystemTickableWhenPaused_Params Params{};
        Params.bInTickableWhenPaused = bInTickableWhenPaused;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    float UScrubbedSound::GetPlayheadTime()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.ScrubbedSound.GetPlayheadTime");
    
        UScrubbedSound___GetPlayheadTime_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UScrubbedSound::SetGrainDurationRange(FVector2D& InGrainDurationRangeSeconds)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.ScrubbedSound.SetGrainDurationRange");
    
        UScrubbedSound___SetGrainDurationRange_Params Params{};
        Params.InGrainDurationRangeSeconds = InGrainDurationRangeSeconds;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InGrainDurationRangeSeconds = Params.InGrainDurationRangeSeconds;
    }

    void UScrubbedSound::SetIsScrubbing(bool bInIsScrubbing)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.ScrubbedSound.SetIsScrubbing");
    
        UScrubbedSound___SetIsScrubbing_Params Params{};
        Params.bInIsScrubbing = bInIsScrubbing;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UScrubbedSound::SetIsScrubbingWhileStationary(bool bInScrubWhileStationary)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.ScrubbedSound.SetIsScrubbingWhileStationary");
    
        UScrubbedSound___SetIsScrubbingWhileStationary_Params Params{};
        Params.bInScrubWhileStationary = bInScrubWhileStationary;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UScrubbedSound::SetPlayheadTime(float InPlayheadTimeSeconds)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.ScrubbedSound.SetPlayheadTime");
    
        UScrubbedSound___SetPlayheadTime_Params Params{};
        Params.InPlayheadTimeSeconds = InPlayheadTimeSeconds;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UScrubbedSound::SetSoundWave(USoundWave* InSoundWave)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.ScrubbedSound.SetSoundWave");
    
        UScrubbedSound___SetSoundWave_Params Params{};
        Params.InSoundWave = InSoundWave;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void USubmixEffectDynamicsProcessorPreset::ResetKey()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SubmixEffectDynamicsProcessorPreset.ResetKey");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void USubmixEffectDynamicsProcessorPreset::SetAudioBus(UAudioBus* AudioBus)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SubmixEffectDynamicsProcessorPreset.SetAudioBus");
    
        USubmixEffectDynamicsProcessorPreset___SetAudioBus_Params Params{};
        Params.AudioBus = AudioBus;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void USubmixEffectDynamicsProcessorPreset::SetExternalSubmix(USoundSubmix* Submix)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SubmixEffectDynamicsProcessorPreset.SetExternalSubmix");
    
        USubmixEffectDynamicsProcessorPreset___SetExternalSubmix_Params Params{};
        Params.Submix = Submix;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void USubmixEffectDynamicsProcessorPreset::SetSettings(FSubmixEffectDynamicsProcessorSettings& Settings)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SubmixEffectDynamicsProcessorPreset.SetSettings");
    
        USubmixEffectDynamicsProcessorPreset___SetSettings_Params Params{};
        Params.Settings = Settings;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Settings = Params.Settings;
    }

    void USubmixEffectReverbPreset::SetSettings(FSubmixEffectReverbSettings& InSettings)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SubmixEffectReverbPreset.SetSettings");
    
        USubmixEffectReverbPreset___SetSettings_Params Params{};
        Params.InSettings = InSettings;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InSettings = Params.InSettings;
    }

    void USubmixEffectReverbPreset::SetSettingsWithReverbEffect(UReverbEffect* InReverbEffect, float WetLevel, float DryLevel)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SubmixEffectReverbPreset.SetSettingsWithReverbEffect");
    
        USubmixEffectReverbPreset___SetSettingsWithReverbEffect_Params Params{};
        Params.InReverbEffect = InReverbEffect;
        Params.WetLevel = WetLevel;
        Params.DryLevel = DryLevel;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void USubmixEffectSubmixEQPreset::SetSettings(FSubmixEffectSubmixEQSettings& InSettings)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SubmixEffectSubmixEQPreset.SetSettings");
    
        USubmixEffectSubmixEQPreset___SetSettings_Params Params{};
        Params.InSettings = InSettings;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InSettings = Params.InSettings;
    }

    void USynthComponent::AdjustVolume(float AdjustVolumeDuration, float AdjustVolumeLevel, EAudioFaderCurve FadeCurve)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SynthComponent.AdjustVolume");
    
        USynthComponent___AdjustVolume_Params Params{};
        Params.AdjustVolumeDuration = AdjustVolumeDuration;
        Params.AdjustVolumeLevel = AdjustVolumeLevel;
        Params.FadeCurve = FadeCurve;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void USynthComponent::FadeIn(float FadeInDuration, float FadeVolumeLevel, float StartTime, EAudioFaderCurve FadeCurve)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SynthComponent.FadeIn");
    
        USynthComponent___FadeIn_Params Params{};
        Params.FadeInDuration = FadeInDuration;
        Params.FadeVolumeLevel = FadeVolumeLevel;
        Params.StartTime = StartTime;
        Params.FadeCurve = FadeCurve;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void USynthComponent::FadeOut(float FadeOutDuration, float FadeVolumeLevel, EAudioFaderCurve FadeCurve)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SynthComponent.FadeOut");
    
        USynthComponent___FadeOut_Params Params{};
        Params.FadeOutDuration = FadeOutDuration;
        Params.FadeVolumeLevel = FadeVolumeLevel;
        Params.FadeCurve = FadeCurve;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    TSet<USoundModulatorBase*> USynthComponent::GetModulators(EModulationDestination Destination)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SynthComponent.GetModulators");
    
        USynthComponent___GetModulators_Params Params{};
        Params.Destination = Destination;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool USynthComponent::IsPlaying()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SynthComponent.IsPlaying");
    
        USynthComponent___IsPlaying_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void USynthComponent::SetAudioBusSendPostEffect(UAudioBus* AudioBus, float AudioBusSendLevel)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SynthComponent.SetAudioBusSendPostEffect");
    
        USynthComponent___SetAudioBusSendPostEffect_Params Params{};
        Params.AudioBus = AudioBus;
        Params.AudioBusSendLevel = AudioBusSendLevel;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void USynthComponent::SetAudioBusSendPreEffect(UAudioBus* AudioBus, float AudioBusSendLevel)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SynthComponent.SetAudioBusSendPreEffect");
    
        USynthComponent___SetAudioBusSendPreEffect_Params Params{};
        Params.AudioBus = AudioBus;
        Params.AudioBusSendLevel = AudioBusSendLevel;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void USynthComponent::SetLowPassFilterEnabled(bool InLowPassFilterEnabled)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SynthComponent.SetLowPassFilterEnabled");
    
        USynthComponent___SetLowPassFilterEnabled_Params Params{};
        Params.InLowPassFilterEnabled = InLowPassFilterEnabled;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void USynthComponent::SetLowPassFilterFrequency(float InLowPassFilterFrequency)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SynthComponent.SetLowPassFilterFrequency");
    
        USynthComponent___SetLowPassFilterFrequency_Params Params{};
        Params.InLowPassFilterFrequency = InLowPassFilterFrequency;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void USynthComponent::SetModulationRouting(TSet<USoundModulatorBase*>& Modulators, EModulationDestination Destination, EModulationRouting RoutingMethod)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SynthComponent.SetModulationRouting");
    
        USynthComponent___SetModulationRouting_Params Params{};
        Params.Modulators = Modulators;
        Params.Destination = Destination;
        Params.RoutingMethod = RoutingMethod;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Modulators = Params.Modulators;
    }

    void USynthComponent::SetOutputToBusOnly(bool bInOutputToBusOnly)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SynthComponent.SetOutputToBusOnly");
    
        USynthComponent___SetOutputToBusOnly_Params Params{};
        Params.bInOutputToBusOnly = bInOutputToBusOnly;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void USynthComponent::SetSourceBusSendPostEffect(USoundSourceBus* SoundSourceBus, float SourceBusSendLevel)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SynthComponent.SetSourceBusSendPostEffect");
    
        USynthComponent___SetSourceBusSendPostEffect_Params Params{};
        Params.SoundSourceBus = SoundSourceBus;
        Params.SourceBusSendLevel = SourceBusSendLevel;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void USynthComponent::SetSourceBusSendPreEffect(USoundSourceBus* SoundSourceBus, float SourceBusSendLevel)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SynthComponent.SetSourceBusSendPreEffect");
    
        USynthComponent___SetSourceBusSendPreEffect_Params Params{};
        Params.SoundSourceBus = SoundSourceBus;
        Params.SourceBusSendLevel = SourceBusSendLevel;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void USynthComponent::SetSubmixSend(USoundSubmixBase* Submix, float SendLevel)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SynthComponent.SetSubmixSend");
    
        USynthComponent___SetSubmixSend_Params Params{};
        Params.Submix = Submix;
        Params.SendLevel = SendLevel;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void USynthComponent::SetVolumeMultiplier(float VolumeMultiplier)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SynthComponent.SetVolumeMultiplier");
    
        USynthComponent___SetVolumeMultiplier_Params Params{};
        Params.VolumeMultiplier = VolumeMultiplier;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void USynthComponent::Start()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SynthComponent.Start");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void USynthComponent::Stop()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioMixer.SynthComponent.Stop");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

} // namespace UE

