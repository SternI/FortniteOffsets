/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AIPromptUI_Functions
 * ============================================================
 */

#include "AIPromptUI_Functions.hpp"

namespace UE
{

    bool UPersonaPermissionVM::OnButtonClicked(int32 ButtonIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AIPromptUI.PersonaPermissionVM.OnButtonClicked");
    
        UPersonaPermissionVM___OnButtonClicked_Params Params{};
        Params.ButtonIndex = ButtonIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

} // namespace UE

