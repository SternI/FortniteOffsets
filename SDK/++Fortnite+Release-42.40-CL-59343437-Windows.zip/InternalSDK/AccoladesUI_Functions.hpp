/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AccoladesUI_Functions
 * ============================================================
 */

#include "AccoladesUI.hpp"

namespace UE
{

    struct UAthenaAccoladeListEntryWidget___SetCount_Params
    {
        int32   Count;  // 0x000000 (0x000004) [Default: 340340544]
    };

    struct UAthenaAccoladeListEntryWidget___SetIcon_Params
    {
        UFortAccoladeItemDefinition*    ItemDef;    // 0x000000 (0x000008) [Default: 0x14492F40]
    };

    struct UAthenaAccoladeListEntryWidget___SetIconImage_Params
    {
        TSoftObjectPtr<UTexture2D>  IconImage;      // 0x000000 (0x000020) [OutParam] [Default: 0x14492F40]
        EFortAccoladeType           AccoladeType;   // 0x000020 (0x000001) [Default: EFortAccoladeType(187)]
        EFortAccoladeTierType       AccoladeTier;   // 0x000021 (0x000001) [Default: EFortAccoladeTierType(141)]
    };

    struct UAthenaAccoladeListEntryWidget___SetJustCompleted_Params
    {
        bool    bJustCompleted; // 0x000000 (0x000001) [Default: true]
    };

    struct UAthenaAccoladeListEntryWidget___SetSource_Params
    {
        FText   SourceText; // 0x000000 (0x000010) [OutParam]
    };

    struct UAthenaAccoladeListEntryWidget___SetTitle_Params
    {
        FText   TitleText;  // 0x000000 (0x000010) [OutParam]
    };

} // namespace UE

