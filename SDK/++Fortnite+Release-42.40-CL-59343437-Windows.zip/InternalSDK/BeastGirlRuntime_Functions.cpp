/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BeastGirlRuntime_Functions
 * ============================================================
 */

#include "BeastGirlRuntime_Functions.hpp"

namespace UE
{

    void ABeastGirlStandInPawn::ApplyWaterJumpCooldown()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.ApplyWaterJumpCooldown");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ABeastGirlStandInPawn::AttachOriginalPawnToMovementBase()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.AttachOriginalPawnToMovementBase");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ABeastGirlStandInPawn::BP_HandleTransfomation()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.BP_HandleTransfomation");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ABeastGirlStandInPawn::BP_OnOutOfHealth(AFortPawn* OriginalPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.BP_OnOutOfHealth");
    
        ABeastGirlStandInPawn___BP_OnOutOfHealth_Params Params{};
        Params.OriginalPawn = OriginalPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABeastGirlStandInPawn::BP_OnRestoreToOriginalPawn(AFortPawn* OriginalPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.BP_OnRestoreToOriginalPawn");
    
        ABeastGirlStandInPawn___BP_OnRestoreToOriginalPawn_Params Params{};
        Params.OriginalPawn = OriginalPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABeastGirlStandInPawn::DestroyPawn()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.DestroyPawn");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ABeastGirlStandInPawn::DetachOriginalPawnFromMovingBase()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.DetachOriginalPawnFromMovingBase");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ABeastGirlStandInPawn::EquipDefaultWeapon()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.EquipDefaultWeapon");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ABeastGirlStandInPawn::ForceBackblingVisibility(AFortPlayerPawn* Pawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.ForceBackblingVisibility");
    
        ABeastGirlStandInPawn___ForceBackblingVisibility_Params Params{};
        Params.Pawn = Pawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABeastGirlStandInPawn::ForceRefreshEquippedWeapon(AFortWeapon* NewWeapon)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.ForceRefreshEquippedWeapon");
    
        ABeastGirlStandInPawn___ForceRefreshEquippedWeapon_Params Params{};
        Params.NewWeapon = NewWeapon;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABeastGirlStandInPawn::GameplayTagCallback_InsideSafeZone(FGameplayTag Tag, int32 NewCount)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.GameplayTagCallback_InsideSafeZone");
    
        ABeastGirlStandInPawn___GameplayTagCallback_InsideSafeZone_Params Params{};
        Params.Tag = Tag;
        Params.NewCount = NewCount;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABeastGirlStandInPawn::GameplayTagCallback_SprintActive(FGameplayTag Tag, int32 NewCount)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.GameplayTagCallback_SprintActive");
    
        ABeastGirlStandInPawn___GameplayTagCallback_SprintActive_Params Params{};
        Params.Tag = Tag;
        Params.NewCount = NewCount;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    FBeastGirlTransformationAnimations ABeastGirlStandInPawn::GetTransformationAnimations(bool bIsOptOut)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.GetTransformationAnimations");
    
        ABeastGirlStandInPawn___GetTransformationAnimations_Params Params{};
        Params.bIsOptOut = bIsOptOut;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void ABeastGirlStandInPawn::HandleCapsuleHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, FHitResult& Hit)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.HandleCapsuleHit");
    
        ABeastGirlStandInPawn___HandleCapsuleHit_Params Params{};
        Params.HitComponent = HitComponent;
        Params.OtherActor = OtherActor;
        Params.OtherComp = OtherComp;
        Params.NormalImpulse = NormalImpulse;
        Params.Hit = Hit;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Hit = Params.Hit;
    }

    void ABeastGirlStandInPawn::HandleOnWeaponEquipped(AFortWeapon* NewWeapon, AFortWeapon* PrevWeapon)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.HandleOnWeaponEquipped");
    
        ABeastGirlStandInPawn___HandleOnWeaponEquipped_Params Params{};
        Params.NewWeapon = NewWeapon;
        Params.PrevWeapon = PrevWeapon;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABeastGirlStandInPawn::OnBeastGirlDidDamage(AActor* DamagedActor, float Damage, AController* InstigatedBy, AActor* DamageCauser, FVector HitLocation, UPrimitiveComponent* FHitComponent, FName BoneName, FVector Momentum)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.OnBeastGirlDidDamage");
    
        ABeastGirlStandInPawn___OnBeastGirlDidDamage_Params Params{};
        Params.DamagedActor = DamagedActor;
        Params.Damage = Damage;
        Params.InstigatedBy = InstigatedBy;
        Params.DamageCauser = DamageCauser;
        Params.HitLocation = HitLocation;
        Params.FHitComponent = FHitComponent;
        Params.BoneName = BoneName;
        Params.Momentum = Momentum;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABeastGirlStandInPawn::OnPlayerEliminated(FFortVerbMessage_PawnEliminated& Event)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.OnPlayerEliminated");
    
        ABeastGirlStandInPawn___OnPlayerEliminated_Params Params{};
        Params.Event = Event;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Event = Params.Event;
    }

    void ABeastGirlStandInPawn::OnReceiveReplacedPawn()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.OnReceiveReplacedPawn");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ABeastGirlStandInPawn::OnRep_AttachedBaseForTransformation()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.OnRep_AttachedBaseForTransformation");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ABeastGirlStandInPawn::OnRep_bHadSpriteEquipped()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.OnRep_bHadSpriteEquipped");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ABeastGirlStandInPawn::OnRep_Weapon()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.OnRep_Weapon");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ABeastGirlStandInPawn::ReplaceAndPossess(AFortPlayerPawn* PlayerPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.ReplaceAndPossess");
    
        ABeastGirlStandInPawn___ReplaceAndPossess_Params Params{};
        Params.PlayerPawn = PlayerPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABeastGirlStandInPawn::RestoreToOriginalPawn(AFortPlayerController* FallbackController)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.RestoreToOriginalPawn");
    
        ABeastGirlStandInPawn___RestoreToOriginalPawn_Params Params{};
        Params.FallbackController = FallbackController;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABeastGirlStandInPawn::SetIsTransformingInto(bool bTransformingInto)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.SetIsTransformingInto");
    
        ABeastGirlStandInPawn___SetIsTransformingInto_Params Params{};
        Params.bTransformingInto = bTransformingInto;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABeastGirlStandInPawn::SetReplicatedTransformationData(bool bIsOptOut, bool bIsInWater)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.SetReplicatedTransformationData");
    
        ABeastGirlStandInPawn___SetReplicatedTransformationData_Params Params{};
        Params.bIsOptOut = bIsOptOut;
        Params.bIsInWater = bIsInWater;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    ABeastGirlStandInPawn* ABeastGirlStandInPawn::SpawnBeastGirlForPlayerPawn(AFortPlayerPawn* PlayerPawn, UClass* ClassToSpawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlStandInPawn.SpawnBeastGirlForPlayerPawn");
    
        ABeastGirlStandInPawn___SpawnBeastGirlForPlayerPawn_Params Params{};
        Params.PlayerPawn = PlayerPawn;
        Params.ClassToSpawn = ClassToSpawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBeastGirlTransformationManager::ApplyConsumableDurabilityCost()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlTransformationManager.ApplyConsumableDurabilityCost");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    float UBeastGirlTransformationManager::GetNewDurability(float FinalBeastGirlHealth, UFortWorldItemDefinition* ItemDefinition)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlTransformationManager.GetNewDurability");
    
        UBeastGirlTransformationManager___GetNewDurability_Params Params{};
        Params.FinalBeastGirlHealth = FinalBeastGirlHealth;
        Params.ItemDefinition = ItemDefinition;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UBeastGirlTransformationManager::HasEnoughDurability(AFortWeapon* CurrentWeapon)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlTransformationManager.HasEnoughDurability");
    
        UBeastGirlTransformationManager___HasEnoughDurability_Params Params{};
        Params.CurrentWeapon = CurrentWeapon;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UBeastGirlTransformationManager::NewCode_AddConsumableWithRemainingHealth()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlTransformationManager.NewCode_AddConsumableWithRemainingHealth");
    
        UBeastGirlTransformationManager___NewCode_AddConsumableWithRemainingHealth_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UBeastGirlTransformationManager::OldCode_AddConsumableWithRemainingHealth()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlTransformationManager.OldCode_AddConsumableWithRemainingHealth");
    
        UBeastGirlTransformationManager___OldCode_AddConsumableWithRemainingHealth_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBeastGirlTransformationManager::OnRep_BeastGirlPawn()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlTransformationManager.OnRep_BeastGirlPawn");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBeastGirlTransformationManager::ResetOptOutFlag()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlTransformationManager.ResetOptOutFlag");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBeastGirlTransformationManager::RestoreOriginalHealthAndShields()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlTransformationManager.RestoreOriginalHealthAndShields");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBeastGirlTransformationManager::Server_StartReverseTransformation(bool bFromOptOut)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlTransformationManager.Server_StartReverseTransformation");
    
        UBeastGirlTransformationManager___Server_StartReverseTransformation_Params Params{};
        Params.bFromOptOut = bFromOptOut;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeastGirlTransformationManager::SetBeastGirlPawn(ABeastGirlStandInPawn* BeastGirlPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlTransformationManager.SetBeastGirlPawn");
    
        UBeastGirlTransformationManager___SetBeastGirlPawn_Params Params{};
        Params.BeastGirlPawn = BeastGirlPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBeastGirlTransformationManager::StartReverseTransformation(bool bFromOptOut)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastGirlTransformationManager.StartReverseTransformation");
    
        UBeastGirlTransformationManager___StartReverseTransformation_Params Params{};
        Params.bFromOptOut = bFromOptOut;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void IBeastPlayerAnimationInterface::GetAnimData(bool& bIsInTransformAnimation, FBeastGirlTransformationData& ReplicatedTransformData, EBeastGirlDiveState& DiveState)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeastGirlRuntime.BeastPlayerAnimationInterface.GetAnimData");
    
        IBeastPlayerAnimationInterface___GetAnimData_Params Params{};
        Params.bIsInTransformAnimation = bIsInTransformAnimation;
        Params.ReplicatedTransformData = ReplicatedTransformData;
        Params.DiveState = DiveState;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        bIsInTransformAnimation = Params.bIsInTransformAnimation;
        ReplicatedTransformData = Params.ReplicatedTransformData;
        DiveState = Params.DiveState;
    }

} // namespace UE

