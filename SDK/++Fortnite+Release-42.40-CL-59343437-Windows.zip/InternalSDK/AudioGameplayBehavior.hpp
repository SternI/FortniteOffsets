/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioGameplayBehavior
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000118 (0x000058)
    class alignas(0x8) UAudioGameplayBehavior : public UActorComponent
    {
    public:
        void**                                      VTable_0000C0;                  // 0x0000C0 (0x000008) VTable [17 slots] -> 0x1470D760
        bool                                        bKillOnSoundsFinished;          // 0x0000C8 (0x000001) [Default: true]
        bool                                        bTickWhileStopped;              // 0x0000C9 (0x000001) [Default: false]
        uint8                                       UnknownData_0000CA[0x000006];   // 0x0000CA (0x000006)
        MULTI_INLINE_DELEGATE(OnAllSoundsFinished)  OnAllSoundsFinished;            // 0x0000D0 (0x000010)
        MULTI_INLINE_DELEGATE(OnSoundFinished)      OnSoundFinished;                // 0x0000E0 (0x000010)
        TArray<FActiveVoice>                        PlayingSounds;                  // 0x0000F0 (0x000010)
        UAudioComponentGroup*                       ComponentGroupOwner;            // 0x000100 (0x000008) [Default: nullptr]
        bool                                        bReleaseActiveVoicesOnFadeOut;  // 0x000108 (0x000001) [Default: false]
        uint8                                       UnknownData_000109[0x00000F];   // 0x000109 (0x00000F)
    
    public: // Functions
        void                            BP_OnFinished(); // 0x000545D2 [RequiredAPI | BlueprintCosmetic | Event | Public | BlueprintEvent]
        void                            BP_OnGroupSet(UAudioComponentGroup* SoundGroup); // 0x000545D2 [RequiredAPI | BlueprintCosmetic | Event | Public | BlueprintEvent]
        void                            BP_OnStart(); // 0x000545D2 [RequiredAPI | BlueprintCosmetic | Event | Public | BlueprintEvent]
        void                            BP_OnStop(); // 0x000545D2 [RequiredAPI | BlueprintCosmetic | Event | Public | BlueprintEvent]
        void                            BP_OnUnvirtualized(); // 0x000545D2 [RequiredAPI | BlueprintCosmetic | Event | Public | BlueprintEvent]
        void                            BP_OnVirtualized(); // 0x000545D2 [RequiredAPI | BlueprintCosmetic | Event | Public | BlueprintEvent]
        void                            DisableVirtualization(); // 0x10D2CD16 [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                            EnableVirtualization(); // 0x10D2CD2C [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        bool                            GetBoolParamValue(FName ParamName); // 0x07FEE36C [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float                           GetFloatParamValue(FName ParamName); // 0x07FEE4F8 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EAudioGameplayBehaviorPlayState GetPlayState(); // 0x1078134E [Native | Public | BlueprintCallable | BlueprintPure]
        UAudioComponentGroup*           GetSoundGroup(); // 0x0FA57AF6 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        EAudioGameplayBehaviorPlayState GetStopState(); // 0x0DB76134 [RequiredAPI | Native | Public | BlueprintCallable]
        FString                         GetStringParamValue(FName ParamName); // 0x07FEE690 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                            IsPlayingAny(); // 0x0F289C3E [RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                            IsVirtualized(); // 0x0CA7B46E [Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                            Kill(); // 0x0F269470 [RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                            PlayFrom(UAudioComponentGroup* SoundGroup); // 0x055A1B08 [RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        FActiveVoice                    PlaySound(USoundBase* Sound, float InFadeInTime, float InTargetVolume, float InStartTime, bool bDisableAttenuation, EAudioFaderCurve InFadeCurve, FVector InRelativeLocation, FRotator InRelativeRotation); // 0x07FEE856 [Final | RequiredAPI | BlueprintCosmetic | Native | Public | HasDefaults | BlueprintCallable]
        void                            SetPlayState(EAudioGameplayBehaviorPlayState NewState); // 0x0790A9A4 [RequiredAPI | Native | Public | BlueprintCallable]
        void                            Start(); // 0x0117BAB8 [RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                            Stop(); // 0x01274662 [RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                            StopAllPlayingVoices(float InFadeOutTime); // 0x07FEF57A [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                            StopById(FPlayingId ID, float InFadeOutTime, EAudioFaderCurve InFadeCurve); // 0x07FEF750 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            StopComponent(UAudioComponent* Comp, float InFadeOutTime, EAudioFaderCurve InFadeCurve); // 0x07FEFB32 [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                            StopSound(USoundBase* Sound, float InFadeOutTime, EAudioFaderCurve InFadeCurve); // 0x07FEFEDE [Final | RequiredAPI | BlueprintCosmetic | Native | Public | BlueprintCallable]
        void                            SubscribeToBoolParam(FName ParamName, BoolParamCallback Delegate); // 0x07FF026C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            SubscribeToEvent(FName EventName, SoundCallback Delegate); // 0x07FF063C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                            SubscribeToStringParam(FName ParamName, StringParamCallback Delegate); // 0x07FF0A0C [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FActiveVoice
    {
        USoundBase*         Sound;                          // 0x000000 (0x000008)
        UAudioComponent*    Component;                      // 0x000008 (0x000008)
        FPlayingId          ID;                             // 0x000010 (0x000004)
        uint8               UnknownData_000014[0x000004];   // 0x000014 (0x000004)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAudioGameplayBehaviorInstance
    {
        UClass*                 Sound;      // 0x000000 (0x000008) [Default: 0xA481812]
        UAudioGameplayBehavior* Instance;   // 0x000008 (0x000008) [Default: 0xC396478]
    };
    // Size: 0x000004 (0x000004)
    struct FPlayingId
    {
        uint8   UnknownData_000000[0x000004];   // 0x000000 (0x000004)
    };
}

