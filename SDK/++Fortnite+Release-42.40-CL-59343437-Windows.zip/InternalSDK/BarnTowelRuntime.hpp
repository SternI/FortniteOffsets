/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BarnTowelRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000C80 (0x000000)
    class AAFortGameplayCueNotifyLoop_BarnTowel : public AAFortGameplayCueNotifyLoop_Jetpack
    {
    public:
    };
    // Size: 0x001B40 (0x000000)
    class AFortWeaponBarnTowel : public AFortWeaponJetpack
    {
    public:
    };
    // Size: 0x0013E0 (0x000000)
    class UBarnTowelLayerAnimInstance : public UJetpackLayerAnimInstance
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class UFortBarnTowelFlyingBlueprintLibrary : public UFortJetpackFlyingBlueprintLibrary
    {
    public:
    };
    // Size: 0x000470 (0x000000)
    class UFortCameraModifier_BarnTowel : public UFortCameraModifier_Jetpack
    {
    public:
    };
    // Size: 0x000DB8 (0x000000)
    class UFortGameplayAbility_LaunchBarnTowel : public UFortGameplayAbility_LaunchJetpack
    {
    public:
    };
    // Size: 0x000120 (0x000000)
    class UFortMovementMode_BarnTowelFlyingRuntimeData : public UFortMovementMode_JetpackFlyingRuntimeData
    {
    public:
    };
    // Size: 0x0029B0 (0x000000)
    class UFortMovementMode_ExtLogicFlyingBarnTowel : public UFortMovementMode_ExtLogicFlyingJetpack
    {
    public:
    };
    // Size: 0x000030 (0x000000)
    struct FBarnTowelFlyingStatusConfig : public FJetpackFlyingStatusConfig
    {
    };
}

