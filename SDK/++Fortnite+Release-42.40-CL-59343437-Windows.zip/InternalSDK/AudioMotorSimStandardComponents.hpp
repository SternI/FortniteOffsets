/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioMotorSimStandardComponents
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000138 (0x000068)
    class alignas(0x8) UBoostMotorSimComponent : public UAudioMotorSimComponent
    {
    public:
        float               ThrottleScale;                  // 0x0000D0 (0x000004) [Default: 5f]
        float               InterpExp;                      // 0x0000D4 (0x000004) [Default: 4f]
        float               InterpTime;                     // 0x0000D8 (0x000004) [Default: 2f]
        bool                ScaleThrottleWithBoostStrength; // 0x0000DC (0x000001) [Default: false]
        bool                bModifyPitch;                   // 0x0000DD (0x000001) [Default: true]
        uint8               UnknownData_0000DE[0x000002];   // 0x0000DE (0x000002)
        float               PitchModifierInterpSpeed;       // 0x0000E0 (0x000004) [Default: 1f]
        uint8               UnknownData_0000E4[0x000004];   // 0x0000E4 (0x000004)
        FRuntimeFloatCurve  BoostToPitchCurve;              // 0x0000E8 (0x000048)
        uint8               UnknownData_000130[0x000008];   // 0x000130 (0x000008)
    };
    // Size: 0x000138 (0x000068)
    class alignas(0x8) UMotorPhysicsSimComponent : public UAudioMotorSimComponent
    {
    public:
        float                                   Weight;                         // 0x0000D0 (0x000004) [Default: 900f]
        float                                   EngineTorque;                   // 0x0000D4 (0x000004) [Default: 2500f]
        float                                   BrakingHorsePower;              // 0x0000D8 (0x000004) [Default: 6000f]
        uint8                                   UnknownData_0000DC[0x000004];   // 0x0000DC (0x000004)
        TArray<float>                           GearRatios;                     // 0x0000E0 (0x000010)
        float                                   ClutchedGearRatio;              // 0x0000F0 (0x000004) [Default: 10f]
        bool                                    bUseInfiniteGears;              // 0x0000F4 (0x000001) [Default: false]
        bool                                    bAlwaysDownshiftToZerothGear;   // 0x0000F5 (0x000001) [Default: false]
        uint8                                   UnknownData_0000F6[0x000002];   // 0x0000F6 (0x000002)
        float                                   InfiniteGearRatio;              // 0x0000F8 (0x000004) [Default: 0.9f]
        float                                   UpShiftMaxRpm;                  // 0x0000FC (0x000004) [Default: 0.97f]
        float                                   DownShiftStartRpm;              // 0x000100 (0x000004) [Default: 0.94f]
        float                                   ClutchedForceModifier;          // 0x000104 (0x000004) [Default: 1f]
        float                                   ClutchedDecelScale;             // 0x000108 (0x000004) [Default: 1f]
        float                                   EngineGearRatio;                // 0x00010C (0x000004) [Default: 50f]
        float                                   EngineFriction;                 // 0x000110 (0x000004) [Default: 0.66f]
        float                                   GroundFriction;                 // 0x000114 (0x000004) [Default: 1f]
        float                                   WindResistancePerVelocity;      // 0x000118 (0x000004) [Default: 0.015f]
        float                                   ThrottleInterpolationTime;      // 0x00011C (0x000004) [Default: 0.05f]
        float                                   RpmInterpSpeed;                 // 0x000120 (0x000004) [Default: 0f]
        uint8                                   UnknownData_000124[0x000004];   // 0x000124 (0x000004)
        MULTI_INLINE_DELEGATE(OnGearChanged)    OnGearChangedEvent;             // 0x000128 (0x000010)
    };
    // Size: 0x000120 (0x000050)
    class alignas(0x8) UResistanceMotorSimComponent : public UAudioMotorSimComponent
    {
    public:
        float               UpSpeedMaxFriction;     // 0x0000D0 (0x000004) [Default: 1f]
        float               MinSpeed;               // 0x0000D4 (0x000004) [Default: 100f]
        FRuntimeFloatCurve  SideSpeedFrictionCurve; // 0x0000D8 (0x000048)
    };
    // Size: 0x000130 (0x000060)
    class alignas(0x8) URevLimiterMotorSimComponent : public UAudioMotorSimComponent
    {
    public:
        float                                           LimitTime;                      // 0x0000D0 (0x000004) [Default: 0f]
        float                                           DecelScale;                     // 0x0000D4 (0x000004) [Default: 0f]
        float                                           AirMaxThrottleTime;             // 0x0000D8 (0x000004) [Default: 0f]
        float                                           SideSpeedThreshold;             // 0x0000DC (0x000004) [Default: 0f]
        float                                           LimiterMaxRpm;                  // 0x0000E0 (0x000004) [Default: 0f]
        bool                                            bShiftBackToZero;               // 0x0000E4 (0x000001) [Default: false]
        bool                                            bRevLimitOnClutchEngaged;       // 0x0000E5 (0x000001) [Default: false]
        uint8                                           UnknownData_0000E6[0x000002];   // 0x0000E6 (0x000002)
        float                                           ClutchedRecoverRPM;             // 0x0000E8 (0x000004) [Default: 0f]
        bool                                            bRevLimitOnReverse;             // 0x0000EC (0x000001) [Default: false]
        uint8                                           UnknownData_0000ED[0x000003];   // 0x0000ED (0x000003)
        float                                           ReverseMaxRPM;                  // 0x0000F0 (0x000004) [Default: 0f]
        float                                           ReverseRecoverRPM;              // 0x0000F4 (0x000004) [Default: 0f]
        bool                                            bHoldRPMInReverse;              // 0x0000F8 (0x000001) [Default: false]
        uint8                                           UnknownData_0000F9[0x000007];   // 0x0000F9 (0x000007)
        MULTI_INLINE_DELEGATE(OnRevLimiterHit)          OnRevLimiterHit;                // 0x000100 (0x000010)
        MULTI_INLINE_DELEGATE(OnRevLimiterStateChanged) OnRevLimiterStateChanged;       // 0x000110 (0x000010)
        uint8                                           UnknownData_000120[0x000010];   // 0x000120 (0x000010)
    };
    // Size: 0x0000D8 (0x000008)
    class alignas(0x4) UReverseMotorSimComponent : public UAudioMotorSimComponent
    {
    public:
        float   ReverseEngineResistanceModifier;    // 0x0000D0 (0x000004) [Default: 1f]
        uint8   UnknownData_0000D4[0x000004];       // 0x0000D4 (0x000004)
    };
    // Size: 0x000108 (0x000038)
    class alignas(0x8) URpmCurveMotorSimComponent : public UAudioMotorSimComponent
    {
    public:
        TArray<FMotorSimGearCurve>                  Gears;                          // 0x0000D0 (0x000010)
        float                                       InterpSpeed;                    // 0x0000E0 (0x000004) [Default: 0f]
        uint8                                       UnknownData_0000E4[0x000004];   // 0x0000E4 (0x000004)
        MULTI_INLINE_DELEGATE(OnGearChangedEvent)   OnUpShift;                      // 0x0000E8 (0x000010)
        MULTI_INLINE_DELEGATE(OnGearChangedEvent)   OnDownShift;                    // 0x0000F8 (0x000010)
    };
    // Size: 0x000110 (0x000040)
    class alignas(0x8) UThrottleStateMotorSimComponent : public UAudioMotorSimComponent
    {
    public:
        MULTI_INLINE_DELEGATE(OnThrottleChanged)    OnThrottleEngaged;              // 0x0000D0 (0x000010)
        MULTI_INLINE_DELEGATE(OnThrottleChanged)    OnThrottleReleased;             // 0x0000E0 (0x000010)
        MULTI_INLINE_DELEGATE(OnEngineBlowoff)      OnEngineBlowoff;                // 0x0000F0 (0x000010)
        float                                       BlowoffMinThrottleTime;         // 0x000100 (0x000004) [Default: 1f]
        uint8                                       UnknownData_000104[0x00000C];   // 0x000104 (0x00000C)
    };
    // Size: 0x000138 (0x000068)
    class alignas(0x8) UVelocitySyncMotorSimComponent : public UAudioMotorSimComponent
    {
    public:
        float               NoThrottleTime;                 // 0x0000D0 (0x000004) [Default: 0.1f]
        float               SpeedThreshold;                 // 0x0000D4 (0x000004) [Default: 200f]
        FRuntimeFloatCurve  SpeedToRpmCurve;                // 0x0000D8 (0x000048)
        float               InterpSpeed;                    // 0x000120 (0x000004) [Default: 3f]
        float               InterpTime;                     // 0x000124 (0x000004) [Default: 0.1f]
        float               FirstGearThrottleThreshold;     // 0x000128 (0x000004) [Default: 0.5f]
        uint8               UnknownData_00012C[0x00000C];   // 0x00012C (0x00000C)
    };
    // Size: 0x00000C (0x00000B)
    struct alignas(0x4) FMotorPhysicsSimConfigData : public FAudioMotorSimConfigData
    {
        float   EngineTorque;       // 0x000004 (0x000004)
        float   BrakingHorsePower;  // 0x000008 (0x000004)
    };
    // Size: 0x000050 (0x000050)
    struct alignas(0x8) FMotorSimGearCurve
    {
        FRuntimeFloatCurve  RpmCurve;                       // 0x000000 (0x000048)
        float               SpeedTopThreshold;              // 0x000048 (0x000004)
        uint8               UnknownData_00004C[0x000004];   // 0x00004C (0x000004)
    };
}

