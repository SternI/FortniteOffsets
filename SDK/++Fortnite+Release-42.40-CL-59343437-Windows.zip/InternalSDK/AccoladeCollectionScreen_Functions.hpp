/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AccoladeCollectionScreen_Functions
 * ============================================================
 */

#include "AccoladeCollectionScreen.hpp"

namespace UE
{

    struct UPinnedAccoladeWidget___BP_PopulateAccoladeInfo_Params
    {
        FText   Description;    // 0x000000 (0x000010) [OutParam]
        int32   Achieved;       // 0x000010 (0x000004) [Default: 426705696]
        int32   Total;          // 0x000014 (0x000004) [Default: 0]
    };

    struct UQuestAccoladeDataSource___OnControllerComponentAttached_Params
    {
        AFortPlayerController*      OwnerController;    // 0x000000 (0x000008) [Default: 0x1488CFC0]
        UFortControllerComponent*   AttachedComponent;  // 0x000008 (0x000008) [Default: 0x905E18DD00000031]
    };

} // namespace UE

