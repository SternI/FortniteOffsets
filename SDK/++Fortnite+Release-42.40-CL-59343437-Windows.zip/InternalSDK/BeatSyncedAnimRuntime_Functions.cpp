/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BeatSyncedAnimRuntime_Functions
 * ============================================================
 */

#include "BeatSyncedAnimRuntime_Functions.hpp"

namespace UE
{

    UFortItemDefinition* UBeatSyncedAnimLibrary::GetLastEmoteExecuted(AController* Controller)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeatSyncedAnimRuntime.BeatSyncedAnimLibrary.GetLastEmoteExecuted");
    
        UBeatSyncedAnimLibrary___GetLastEmoteExecuted_Params Params{};
        Params.Controller = Controller;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FBeatAndTime UFMBeatTimingUtils::GetCurrentBeatAndTime(UMusicClockComponent* MusicClock, UObject* WorldContext)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeatSyncedAnimRuntime.FMBeatTimingUtils.GetCurrentBeatAndTime");
    
        UFMBeatTimingUtils___GetCurrentBeatAndTime_Params Params{};
        Params.MusicClock = MusicClock;
        Params.WorldContext = WorldContext;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    AFortPlayerPawn* UMontageBeatSyncComponent::GetOwnerFortPlayerPawn()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeatSyncedAnimRuntime.MontageBeatSyncComponent.GetOwnerFortPlayerPawn");
    
        UMontageBeatSyncComponent___GetOwnerFortPlayerPawn_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    ASkeletalMeshActor* UMontageBeatSyncComponent::GetOwnerSkeletalMeshActor()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeatSyncedAnimRuntime.MontageBeatSyncComponent.GetOwnerSkeletalMeshActor");
    
        UMontageBeatSyncComponent___GetOwnerSkeletalMeshActor_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    USkeletalMeshComponent* UMontageBeatSyncComponent::GetOwnerSkeletalMeshComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeatSyncedAnimRuntime.MontageBeatSyncComponent.GetOwnerSkeletalMeshComponent");
    
        UMontageBeatSyncComponent___GetOwnerSkeletalMeshComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UMontageBeatSyncComponent::IsMusicPlaying()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeatSyncedAnimRuntime.MontageBeatSyncComponent.IsMusicPlaying");
    
        UMontageBeatSyncComponent___IsMusicPlaying_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UMontageBeatSyncComponent::OnClockPlayStateChanged(EMusicClockState NewState)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeatSyncedAnimRuntime.MontageBeatSyncComponent.OnClockPlayStateChanged");
    
        UMontageBeatSyncComponent___OnClockPlayStateChanged_Params Params{};
        Params.NewState = NewState;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UMontageBeatSyncComponent::OnMeshAnimInstanceInitialized()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeatSyncedAnimRuntime.MontageBeatSyncComponent.OnMeshAnimInstanceInitialized");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UMontageBeatSyncComponent::OnMontageEnded(UAnimMontage* Montage, bool bInterrupted)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeatSyncedAnimRuntime.MontageBeatSyncComponent.OnMontageEnded");
    
        UMontageBeatSyncComponent___OnMontageEnded_Params Params{};
        Params.Montage = Montage;
        Params.bInterrupted = bInterrupted;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UMontageBeatSyncComponent::OnMontageStarted(UAnimMontage* Montage)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeatSyncedAnimRuntime.MontageBeatSyncComponent.OnMontageStarted");
    
        UMontageBeatSyncComponent___OnMontageStarted_Params Params{};
        Params.Montage = Montage;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UMontageBeatSyncComponent::OnMusicEventClockStateChanged(UMusicEventInstance* MusicEvent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeatSyncedAnimRuntime.MontageBeatSyncComponent.OnMusicEventClockStateChanged");
    
        UMontageBeatSyncComponent___OnMusicEventClockStateChanged_Params Params{};
        Params.MusicEvent = MusicEvent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UMontageBeatSyncComponent::OnRep_BeatSyncingPermission()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeatSyncedAnimRuntime.MontageBeatSyncComponent.OnRep_BeatSyncingPermission");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UMontageBeatSyncComponent::OnRep_MusicClock(TWeakObjectPtr<UMusicClockComponent>& OldWeakMusicClockPtr)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeatSyncedAnimRuntime.MontageBeatSyncComponent.OnRep_MusicClock");
    
        UMontageBeatSyncComponent___OnRep_MusicClock_Params Params{};
        Params.OldWeakMusicClockPtr = OldWeakMusicClockPtr;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OldWeakMusicClockPtr = Params.OldWeakMusicClockPtr;
    }

    void UMontageBeatSyncComponent::ServerRPC_SetBeatSyncingPermission(bool bNewPermission)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeatSyncedAnimRuntime.MontageBeatSyncComponent.ServerRPC_SetBeatSyncingPermission");
    
        UMontageBeatSyncComponent___ServerRPC_SetBeatSyncingPermission_Params Params{};
        Params.bNewPermission = bNewPermission;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UMontageBeatSyncComponent::ServerRPC_SetMusicClock(UMusicClockComponent* NewMusicClock)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeatSyncedAnimRuntime.MontageBeatSyncComponent.ServerRPC_SetMusicClock");
    
        UMontageBeatSyncComponent___ServerRPC_SetMusicClock_Params Params{};
        Params.NewMusicClock = NewMusicClock;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UMontageBeatSyncComponent::ServerRPC_StartStopBSE(bool bStarted)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeatSyncedAnimRuntime.MontageBeatSyncComponent.ServerRPC_StartStopBSE");
    
        UMontageBeatSyncComponent___ServerRPC_StartStopBSE_Params Params{};
        Params.bStarted = bStarted;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UMontageBeatSyncComponent::SetMusicClock(UMusicClockComponent* NewMusicClock)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BeatSyncedAnimRuntime.MontageBeatSyncComponent.SetMusicClock");
    
        UMontageBeatSyncComponent___SetMusicClock_Params Params{};
        Params.NewMusicClock = NewMusicClock;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

