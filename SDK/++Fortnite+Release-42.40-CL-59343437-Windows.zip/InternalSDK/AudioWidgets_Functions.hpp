/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioWidgets_Functions
 * ============================================================
 */

#include "AudioWidgets.hpp"

namespace UE
{

    struct UAudioMaterialButton___GetIsPressed_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: false]
    };

    struct UAudioMaterialButton___SetIsPressed_Params
    {
        bool    InPressed;  // 0x000000 (0x000001) [Default: false]
    };

    struct UAudioMaterialKnob___GetFineTuneSpeed_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.45008e-26f]
    };

    struct UAudioMaterialKnob___GetIsLocked_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioMaterialKnob___GetMouseUsesStep_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioMaterialKnob___GetStepSize_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.45008e-26f]
    };

    struct UAudioMaterialKnob___GetTuneSpeed_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.45008e-26f]
    };

    struct UAudioMaterialKnob___GetValue_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.45008e-26f]
    };

    struct UAudioMaterialKnob___SetFineTuneSpeed_Params
    {
        float   InValue;    // 0x000000 (0x000004) [Default: 1.45008e-26f]
    };

    struct UAudioMaterialKnob___SetLocked_Params
    {
        bool    InLocked;   // 0x000000 (0x000001) [Default: true]
    };

    struct UAudioMaterialKnob___SetMouseUsesStep_Params
    {
        bool    InUsesStep; // 0x000000 (0x000001) [Default: true]
    };

    struct UAudioMaterialKnob___SetStepSize_Params
    {
        float   InValue;    // 0x000000 (0x000004) [Default: 1.45008e-26f]
    };

    struct UAudioMaterialKnob___SetTuneSpeed_Params
    {
        float   InValue;    // 0x000000 (0x000004) [Default: 1.45008e-26f]
    };

    struct UAudioMaterialKnob___SetValue_Params
    {
        float   InValue;    // 0x000000 (0x000004) [Default: 1.45008e-26f]
    };

    struct UAudioMaterialMeter___GetMeterChannelInfo_Params
    {
        TArray<FMeterChannelInfo>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAudioMaterialMeter___SetMeterChannelInfo_Params
    {
        TArray<FMeterChannelInfo>   InMeterChannelInfo; // 0x000000 (0x000010) [OutParam]
    };

    struct UAudioMaterialMeter___GetMeterChannelInfo_Params
    {
        TArray<FMeterChannelInfo>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAudioMaterialSlider___GetFineTuneSpeed_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.45041e-26f]
    };

    struct UAudioMaterialSlider___GetIsLocked_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioMaterialSlider___GetMouseUsesStep_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioMaterialSlider___GetStepSize_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.45041e-26f]
    };

    struct UAudioMaterialSlider___GetTuneSpeed_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.45041e-26f]
    };

    struct UAudioMaterialSlider___GetValue_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.45041e-26f]
    };

    struct UAudioMaterialSlider___SetFineTuneSpeed_Params
    {
        float   InValue;    // 0x000000 (0x000004) [Default: 1.45041e-26f]
    };

    struct UAudioMaterialSlider___SetLocked_Params
    {
        bool    bInLocked;  // 0x000000 (0x000001) [Default: true]
    };

    struct UAudioMaterialSlider___SetMouseUsesStep_Params
    {
        bool    bInUsesStep;    // 0x000000 (0x000001) [Default: true]
    };

    struct UAudioMaterialSlider___SetStepSize_Params
    {
        float   InValue;    // 0x000000 (0x000004) [Default: 1.45041e-26f]
    };

    struct UAudioMaterialSlider___SetTuneSpeed_Params
    {
        float   InValue;    // 0x000000 (0x000004) [Default: 1.45041e-26f]
    };

    struct UAudioMaterialSlider___SetValue_Params
    {
        float   InValue;    // 0x000000 (0x000004) [Default: 1.45041e-26f]
    };

    struct UAudioMeter___GetMeterChannelInfo_Params
    {
        TArray<FMeterChannelInfo>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAudioMeter___SetBackgroundColor_Params
    {
        FLinearColor    InValue;    // 0x000000 (0x000010)
    };

    struct UAudioMeter___SetMeterBackgroundColor_Params
    {
        FLinearColor    InValue;    // 0x000000 (0x000010)
    };

    struct UAudioMeter___SetMeterChannelInfo_Params
    {
        TArray<FMeterChannelInfo>   InMeterChannelInfo; // 0x000000 (0x000010) [OutParam]
    };

    struct UAudioMeter___SetMeterClippingColor_Params
    {
        FLinearColor    InValue;    // 0x000000 (0x000010)
    };

    struct UAudioMeter___SetMeterPeakColor_Params
    {
        FLinearColor    InValue;    // 0x000000 (0x000010)
    };

    struct UAudioMeter___SetMeterScaleColor_Params
    {
        FLinearColor    InValue;    // 0x000000 (0x000010)
    };

    struct UAudioMeter___SetMeterScaleLabelColor_Params
    {
        FLinearColor    InValue;    // 0x000000 (0x000010)
    };

    struct UAudioMeter___SetMeterValueColor_Params
    {
        FLinearColor    InValue;    // 0x000000 (0x000010)
    };

    struct UAudioMeter___GetMeterChannelInfo_Params
    {
        TArray<FMeterChannelInfo>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAudioOscilloscope___CanTriggeringBeSet_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioOscilloscope___GetOscilloscopeAudioSamples_Params
    {
        TArray<float>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAudioRadialSlider___GetOutputValue_Params
    {
        float   InSliderValue;  // 0x000000 (0x000004) [Default: 1.45085e-26f]
        float   ReturnValue;    // 0x000004 (0x000004) [ReturnValue] [Default: 0f]
    };

    struct UAudioRadialSlider___GetSliderValue_Params
    {
        float   OutputValue;    // 0x000000 (0x000004) [Default: 1.45085e-26f]
        float   ReturnValue;    // 0x000004 (0x000004) [ReturnValue] [Default: 0f]
    };

    struct UAudioRadialSlider___SetCenterBackgroundColor_Params
    {
        FLinearColor    InValue;    // 0x000000 (0x000010)
    };

    struct UAudioRadialSlider___SetHandStartEndRatio_Params
    {
        FVector2D   InHandStartEndRatio;    // 0x000000 (0x000010)
    };

    struct UAudioRadialSlider___SetOutputRange_Params
    {
        FVector2D   InOutputRange;  // 0x000000 (0x000010)
    };

    struct UAudioRadialSlider___SetShowLabelOnlyOnHover_Params
    {
        bool    bShowLabelOnlyOnHover;  // 0x000000 (0x000001) [Default: true]
    };

    struct UAudioRadialSlider___SetShowUnitsText_Params
    {
        bool    bShowUnitsText; // 0x000000 (0x000001) [Default: true]
    };

    struct UAudioRadialSlider___SetSliderBarColor_Params
    {
        FLinearColor    InValue;    // 0x000000 (0x000010)
    };

    struct UAudioRadialSlider___SetSliderProgressColor_Params
    {
        FLinearColor    InValue;    // 0x000000 (0x000010)
    };

    struct UAudioRadialSlider___SetSliderThickness_Params
    {
        float   InThickness;    // 0x000000 (0x000004) [Default: 1.45085e-26f]
    };

    struct UAudioRadialSlider___SetTextLabelBackgroundColor_Params
    {
        FSlateColor InColor;    // 0x000000 (0x000014)
    };

    struct UAudioRadialSlider___SetUnitsText_Params
    {
        FText   Units;  // 0x000000 (0x000010)
    };

    struct UAudioRadialSlider___SetUnitsTextReadOnly_Params
    {
        bool    bIsReadOnly;    // 0x000000 (0x000001) [Default: true]
    };

    struct UAudioRadialSlider___SetValueTextReadOnly_Params
    {
        bool    bIsReadOnly;    // 0x000000 (0x000001) [Default: true]
    };

    struct UAudioRadialSlider___SetWidgetLayout_Params
    {
        TEnumAsByte<EAudioRadialSliderLayout>   InLayout;   // 0x000000 (0x000001) [Default: 128]
    };

    struct UAudioSliderBase___GetLinValue_Params
    {
        float   OutputValue;    // 0x000000 (0x000004) [Default: 1.45123e-26f]
        float   ReturnValue;    // 0x000004 (0x000004) [ReturnValue] [Default: 0f]
    };

    struct UAudioSliderBase___GetOutputValue_Params
    {
        float   InSliderValue;  // 0x000000 (0x000004) [Default: 1.45123e-26f]
        float   ReturnValue;    // 0x000004 (0x000004) [ReturnValue] [Default: 0f]
    };

    struct UAudioSliderBase___GetSliderValue_Params
    {
        float   OutputValue;    // 0x000000 (0x000004) [Default: 1.45123e-26f]
        float   ReturnValue;    // 0x000004 (0x000004) [ReturnValue] [Default: 0f]
    };

    struct UAudioSliderBase___SetShowLabelOnlyOnHover_Params
    {
        bool    bShowLabelOnlyOnHover;  // 0x000000 (0x000001) [Default: false]
    };

    struct UAudioSliderBase___SetShowUnitsText_Params
    {
        bool    bShowUnitsText; // 0x000000 (0x000001) [Default: false]
    };

    struct UAudioSliderBase___SetSliderBackgroundColor_Params
    {
        FLinearColor    InValue;    // 0x000000 (0x000010)
    };

    struct UAudioSliderBase___SetSliderBarColor_Params
    {
        FLinearColor    InValue;    // 0x000000 (0x000010)
    };

    struct UAudioSliderBase___SetSliderThumbColor_Params
    {
        FLinearColor    InValue;    // 0x000000 (0x000010)
    };

    struct UAudioSliderBase___SetTextLabelBackgroundColor_Params
    {
        FSlateColor InColor;    // 0x000000 (0x000014)
    };

    struct UAudioSliderBase___SetUnitsText_Params
    {
        FText   Units;  // 0x000000 (0x000010)
    };

    struct UAudioSliderBase___SetUnitsTextReadOnly_Params
    {
        bool    bIsReadOnly;    // 0x000000 (0x000001) [Default: false]
    };

    struct UAudioSliderBase___SetValueTextReadOnly_Params
    {
        bool    bIsReadOnly;    // 0x000000 (0x000001) [Default: false]
    };

    struct UAudioSliderBase___SetWidgetBackgroundColor_Params
    {
        FLinearColor    InValue;    // 0x000000 (0x000010)
    };

    struct UAudioVectorscope___GetVectorscopeAudioSamples_Params
    {
        TArray<float>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

} // namespace UE

