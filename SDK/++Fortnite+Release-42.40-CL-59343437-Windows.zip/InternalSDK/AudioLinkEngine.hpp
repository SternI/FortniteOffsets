/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:10
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioLinkEngine
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class IAudioLinkBlueprintInterface : public IInterface
    {
    public:
    
    public: // Functions
        bool    IsLinkPlaying(); // 0x0D1A9122 [Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    PlayLink(float StartTime); // 0x0490E47C [Native | Public | BlueprintCallable]
        void    SetLinkSound(USoundBase* NewSound); // 0x0490E5EE [Native | Public | BlueprintCallable]
        void    StopLink(); // 0x0D1A9148 [Native | Public | BlueprintCallable]
    };
}

