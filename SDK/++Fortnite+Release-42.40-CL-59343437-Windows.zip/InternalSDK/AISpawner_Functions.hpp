/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AISpawner_Functions
 * ============================================================
 */

#include "AISpawner.hpp"

namespace UE
{

    struct AFortAthenaMutator_AISpawner___HandleCreativeModeratorModeActivatedChanged_Params
    {
        AFortPlayerPawnAthena*  Pawn;   // 0x000000 (0x000008) [Default: 0x149BC4B0]
    };

    struct AFortAthenaMutator_AISpawner___HandlePlayerPawnChanged_Params
    {
        AFortPlayerPawn*        NewPawn;    // 0x000000 (0x000008) [Default: 0x149BC4B0]
        AFortPlayerPawn*        OldPawn;    // 0x000008 (0x000008) [Default: 0xC76218DD00000031]
        AFortPlayerController*  PC;         // 0x000010 (0x000008) [Default: 0x19975790]
    };

    struct UAISpawnerPreviewerComponent___SetActorForPreview_Params
    {
        UClass*                         InActorClass;           // 0x000000 (0x000008) [Default: 0x149BBE50]
        TArray<UCustomCharacterPart*>   OptionalCharacterParts; // 0x000008 (0x000010)
    };

    struct UAISpawnerPreviewerComponent___SetCIDForPreview_Params
    {
        UAthenaCharacterItemDefinition* InCID;      // 0x000000 (0x000008) [Default: 0x149BBE50]
        TArray<FMcpVariantChannelInfo>  InVariants; // 0x000008 (0x000010)
    };

    struct UAISpawnerPreviewerComponent___SetPreviewByAssets_Params
    {
        FCharacterPreviewAssets PreviewAssets;  // 0x000000 (0x000080) [OutParam]
    };

} // namespace UE

