/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:04
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AugmentedReality_Functions
 * ============================================================
 */

#include "AugmentedReality.hpp"

namespace UE
{

    struct AARActor___AddARComponent_Params
    {
        UClass*         InComponentClass;   // 0x000000 (0x000008) [Default: 0x130E90A0]
        FGuid           NativeID;           // 0x000008 (0x000010) [OutParam]
        UARComponent*   ReturnValue;        // 0x000018 (0x000008) [ReturnValue] [Default: 0x17A72C80]
    };

    struct AARSharedWorldGameMode___GetARSharedWorldGameState_Params
    {
        AARSharedWorldGameState*    ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x139830A0]
    };

    struct AARSharedWorldGameMode___SetARSharedWorldData_Params
    {
        TArray<uint8>   ARWorldData;    // 0x000000 (0x000010)
    };

    struct AARSharedWorldGameMode___SetPreviewImageData_Params
    {
        TArray<uint8>   ImageData;  // 0x000000 (0x000010)
    };

    struct AARSharedWorldPlayerController___ClientInitSharedWorld_Params
    {
        int32   PreviewImageSize;   // 0x000000 (0x000004) [Default: 328745584]
        int32   ARWorldDataSize;    // 0x000004 (0x000004) [Default: 0]
    };

    struct AARSharedWorldPlayerController___ClientUpdateARWorldData_Params
    {
        int32           Offset;                         // 0x000000 (0x000004) [Default: 328745584]
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<uint8>   Buffer;                         // 0x000008 (0x000010)
    };

    struct AARSharedWorldPlayerController___ClientUpdatePreviewImageData_Params
    {
        int32           Offset;                         // 0x000000 (0x000004) [Default: 328745584]
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<uint8>   Buffer;                         // 0x000008 (0x000010)
    };

    struct AARSkyLight___SetEnvironmentCaptureProbe_Params
    {
        UAREnvironmentCaptureProbe* InCaptureProbe; // 0x000000 (0x000008) [Default: 0x13985210]
    };

    struct UARBasicLightEstimate___GetAmbientColor_Params
    {
        FLinearColor    ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UARBasicLightEstimate___GetAmbientColorTemperatureKelvin_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.69852e-27f]
    };

    struct UARBasicLightEstimate___GetAmbientIntensityLumens_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.69852e-27f]
    };

    struct UARBlueprintLibrary___AddManualEnvironmentCaptureProbe_Params
    {
        FVector Location;       // 0x000000 (0x000018)
        FVector Extent;         // 0x000018 (0x000018)
        bool    ReturnValue;    // 0x000030 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARBlueprintLibrary___AddRuntimeCandidateImage_Params
    {
        UARSessionConfig*   SessionConfig;                  // 0x000000 (0x000008) [Default: 0x130A5F60]
        UTexture2D*         CandidateTexture;               // 0x000008 (0x000008) [Default: 0xBD2C18DD00000031]
        FString             FriendlyName;                   // 0x000010 (0x000010) [Default: L""]
        float               PhysicalWidth;                  // 0x000020 (0x000004) [Default: 52.6755f]
        uint8               UnknownData_000024[0x000004];   // 0x000024 (0x000004)
        UARCandidateImage*  ReturnValue;                    // 0x000028 (0x000008) [ReturnValue] [Default: 0x13988B80]
    };

    struct UARBlueprintLibrary___AddTrackedPointWithName_Params
    {
        FTransform  WorldTransform;             // 0x000000 (0x000060) [OutParam]
        FString     PointName;                  // 0x000060 (0x000010) [Default: L""]
        bool        bDeletePointsWithSameName;  // 0x000070 (0x000001) [Default: false]
        bool        ReturnValue;                // 0x000071 (0x000001) [ReturnValue] [Default: false]
    };

    struct UARBlueprintLibrary___CalculateAlignmentTransform_Params
    {
        FTransform  TransformInFirstCoordinateSystem;   // 0x000000 (0x000060) [OutParam]
        FTransform  TransformInSecondCoordinateSystem;  // 0x000060 (0x000060) [OutParam]
        FTransform  AlignmentTransform;                 // 0x0000C0 (0x000060) [OutParam]
    };

    struct UARBlueprintLibrary___CalculateClosestIntersection_Params
    {
        TArray<FVector> StartPoints;            // 0x000000 (0x000010) [OutParam]
        TArray<FVector> EndPoints;              // 0x000010 (0x000010) [OutParam]
        FVector         ClosestIntersection;    // 0x000020 (0x000018) [OutParam]
    };

    struct UARBlueprintLibrary___DebugDrawPin_Params
    {
        UARPin*         ARPin;              // 0x000000 (0x000008) [Default: 0x130A5F60]
        UObject*        WorldContextObject; // 0x000008 (0x000008) [Default: 0xBD2C18DD00000031]
        FLinearColor    Color;              // 0x000010 (0x000010)
        float           Scale;              // 0x000020 (0x000004) [Default: 52.6755f]
        float           PersistForSeconds;  // 0x000024 (0x000004) [Default: 0f]
    };

    struct UARBlueprintLibrary___DebugDrawTrackedGeometry_Params
    {
        UARTrackedGeometry* TrackedGeometry;    // 0x000000 (0x000008) [Default: 0x130A5F60]
        UObject*            WorldContextObject; // 0x000008 (0x000008) [Default: 0xBD2C18DD00000031]
        FLinearColor        Color;              // 0x000010 (0x000010)
        float               OutlineThickness;   // 0x000020 (0x000004) [Default: 52.6755f]
        float               PersistForSeconds;  // 0x000024 (0x000004) [Default: 0f]
    };

    struct UARBlueprintLibrary___FindTrackedPointsByName_Params
    {
        FString                     PointName;      // 0x000000 (0x000010) [Default: L"??"]
        TArray<UARTrackedPoint*>    ReturnValue;    // 0x000010 (0x000010) [ReturnValue]
    };

    struct UARBlueprintLibrary___GetAlignmentTransform_Params
    {
        FTransform  ReturnValue;    // 0x000000 (0x000060) [ReturnValue]
    };

    struct UARBlueprintLibrary___GetAllGeometries_Params
    {
        TArray<UARTrackedGeometry*> ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UARBlueprintLibrary___GetAllGeometriesByClass_Params
    {
        UClass*                     GeometryClass;  // 0x000000 (0x000008) [Default: 0x130A5F60]
        TArray<UARTrackedGeometry*> ReturnValue;    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UARBlueprintLibrary___GetAllPins_Params
    {
        TArray<UARPin*> ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UARBlueprintLibrary___GetAllTracked2DPoses_Params
    {
        TArray<FARPose2D>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UARBlueprintLibrary___GetARSessionStatus_Params
    {
        FARSessionStatus    ReturnValue;    // 0x000000 (0x000018) [ReturnValue]
    };

    struct UARBlueprintLibrary___GetARTexture_Params
    {
        EARTextureType  TextureType;                    // 0x000000 (0x000001) [Default: EARTextureType(96)]
        uint8           UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        UARTexture*     ReturnValue;                    // 0x000008 (0x000008) [ReturnValue] [Default: 0xBD2C18DD00000031]
    };

    struct UARBlueprintLibrary___GetARWorldScale_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.74651e-27f]
    };

    struct UARBlueprintLibrary___GetCameraIntrinsics_Params
    {
        FARCameraIntrinsics OutCameraIntrinsics;    // 0x000000 (0x000028) [OutParam]
        bool                ReturnValue;            // 0x000028 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARBlueprintLibrary___GetCurrentLightEstimate_Params
    {
        UARLightEstimate*   ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x130A5F60]
    };

    struct UARBlueprintLibrary___GetNumberOfTrackedFacesSupported_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 319446880]
    };

    struct UARBlueprintLibrary___GetObjectClassificationAtLocation_Params
    {
        FVector                 InWorldLocation;                // 0x000000 (0x000018) [OutParam]
        EARObjectClassification OutClassification;              // 0x000018 (0x000001) [OutParam] [Default: EARObjectClassification(128)]
        uint8                   UnknownData_000019[0x000007];   // 0x000019 (0x000007)
        FVector                 OutClassificationLocation;      // 0x000020 (0x000018) [OutParam]
        float                   MaxLocationDiff;                // 0x000038 (0x000004) [Default: 1.09639e-24f]
        bool                    ReturnValue;                    // 0x00003C (0x000001) [ReturnValue] [Default: false]
    };

    struct UARBlueprintLibrary___GetPointCloud_Params
    {
        TArray<FVector> ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UARBlueprintLibrary___GetSessionConfig_Params
    {
        UARSessionConfig*   ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x130A5F60]
    };

    struct UARBlueprintLibrary___GetSupportedVideoFormats_Params
    {
        EARSessionType          SessionType;                    // 0x000000 (0x000001) [Default: EARSessionType(96)]
        uint8                   UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        TArray<FARVideoFormat>  ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UARBlueprintLibrary___GetTrackingQuality_Params
    {
        EARTrackingQuality  ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARTrackingQuality(96)]
    };

    struct UARBlueprintLibrary___GetTrackingQualityReason_Params
    {
        EARTrackingQualityReason    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARTrackingQualityReason(96)]
    };

    struct UARBlueprintLibrary___GetWorldMappingStatus_Params
    {
        EARWorldMappingState    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARWorldMappingState(96)]
    };

    struct UARBlueprintLibrary___IsARPinLocalStoreReady_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARBlueprintLibrary___IsARPinLocalStoreSupported_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARBlueprintLibrary___IsARSupported_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARBlueprintLibrary___IsSceneReconstructionSupported_Params
    {
        EARSessionType          SessionType;                // 0x000000 (0x000001) [Default: EARSessionType(96)]
        EARSceneReconstruction  SceneReconstructionMethod;  // 0x000001 (0x000001) [Default: EARSceneReconstruction(95)]
        bool                    ReturnValue;                // 0x000002 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARBlueprintLibrary___IsSessionTrackingFeatureSupported_Params
    {
        EARSessionType              SessionType;            // 0x000000 (0x000001) [Default: EARSessionType(96)]
        EARSessionTrackingFeature   SessionTrackingFeature; // 0x000001 (0x000001) [Default: EARSessionTrackingFeature(95)]
        bool                        ReturnValue;            // 0x000002 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARBlueprintLibrary___IsSessionTypeSupported_Params
    {
        EARSessionType  SessionType;    // 0x000000 (0x000001) [Default: EARSessionType(96)]
        bool            ReturnValue;    // 0x000001 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARBlueprintLibrary___LineTraceTrackedObjects_Params
    {
        FVector2D               ScreenCoord;                    // 0x000000 (0x000010)
        bool                    bTestFeaturePoints;             // 0x000010 (0x000001) [Default: true]
        bool                    bTestGroundPlane;               // 0x000011 (0x000001) [Default: true]
        bool                    bTestPlaneExtents;              // 0x000012 (0x000001) [Default: true]
        bool                    bTestPlaneBoundaryPolygon;      // 0x000013 (0x000001) [Default: true]
        uint8                   UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        TArray<FARTraceResult>  ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UARBlueprintLibrary___LineTraceTrackedObjects3D_Params
    {
        FVector                 Start;                          // 0x000000 (0x000018)
        FVector                 End;                            // 0x000018 (0x000018)
        bool                    bTestFeaturePoints;             // 0x000030 (0x000001) [Default: true]
        bool                    bTestGroundPlane;               // 0x000031 (0x000001) [Default: false]
        bool                    bTestPlaneExtents;              // 0x000032 (0x000001) [Default: false]
        bool                    bTestPlaneBoundaryPolygon;      // 0x000033 (0x000001) [Default: false]
        uint8                   UnknownData_000034[0x000004];   // 0x000034 (0x000004)
        TArray<FARTraceResult>  ReturnValue;                    // 0x000038 (0x000010) [ReturnValue]
    };

    struct UARBlueprintLibrary___LoadARPinsFromLocalStore_Params
    {
        TMap<FName, UARPin*>    ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UARBlueprintLibrary___PinComponent_Params
    {
        USceneComponent*    ComponentToPin;                 // 0x000000 (0x000008) [Default: 0x130A5F60]
        uint8               UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        FTransform          PinToWorldTransform;            // 0x000010 (0x000060) [OutParam]
        UARTrackedGeometry* TrackedGeometry;                // 0x000070 (0x000008) [Default: nullptr]
        FName               DebugName;                      // 0x000078 (0x000004) [Default: FName(328765008) -> L""]
        uint8               UnknownData_00007C[0x000004];   // 0x00007C (0x000004)
        UARPin*             ReturnValue;                    // 0x000080 (0x000008) [ReturnValue] [Default: 0xBB2C18DD00000031]
    };

    struct UARBlueprintLibrary___PinComponentToARPin_Params
    {
        USceneComponent*    ComponentToPin; // 0x000000 (0x000008) [Default: 0x130A5F60]
        UARPin*             Pin;            // 0x000008 (0x000008) [Default: 0xBD2C18DD00000031]
        bool                ReturnValue;    // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARBlueprintLibrary___PinComponentToTraceResult_Params
    {
        USceneComponent*    ComponentToPin;                 // 0x000000 (0x000008) [Default: 0x130A5F60]
        uint8               UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        FARTraceResult      TraceResult;                    // 0x000010 (0x000090) [OutParam]
        FName               DebugName;                      // 0x0000A0 (0x000004) [Default: NAME_None]
        uint8               UnknownData_0000A4[0x000004];   // 0x0000A4 (0x000004)
        UARPin*             ReturnValue;                    // 0x0000A8 (0x000008) [ReturnValue] [Default: nullptr]
    };

    struct UARBlueprintLibrary___RemoveARPinFromLocalStore_Params
    {
        FName   InSaveName; // 0x000000 (0x000004) [Default: FName(319446880) -> L""]
    };

    struct UARBlueprintLibrary___RemovePin_Params
    {
        UARPin* PinToRemove;    // 0x000000 (0x000008) [Default: 0x130A5F60]
    };

    struct UARBlueprintLibrary___ResizeXRCamera_Params
    {
        FIntPoint   InSize;         // 0x000000 (0x000008) [OutParam]
        FIntPoint   ReturnValue;    // 0x000008 (0x000008) [ReturnValue]
    };

    struct UARBlueprintLibrary___SaveARPinToLocalStore_Params
    {
        FName   InSaveName;                     // 0x000000 (0x000004) [Default: FName(319446880) -> L""]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UARPin* InPin;                          // 0x000008 (0x000008) [Default: 0xBD2C18DD00000031]
        bool    ReturnValue;                    // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARBlueprintLibrary___SetAlignmentTransform_Params
    {
        FTransform  InAlignmentTransform;   // 0x000000 (0x000060) [OutParam]
    };

    struct UARBlueprintLibrary___SetARWorldOriginLocationAndRotation_Params
    {
        FVector     OriginLocation;             // 0x000000 (0x000018)
        FRotator    OriginRotation;             // 0x000018 (0x000018)
        bool        bIsTransformInWorldSpace;   // 0x000030 (0x000001) [Default: true]
        bool        bMaintainUpDirection;       // 0x000031 (0x000001) [Default: false]
    };

    struct UARBlueprintLibrary___SetARWorldScale_Params
    {
        float   InWorldScale;   // 0x000000 (0x000004) [Default: 1.74651e-27f]
    };

    struct UARBlueprintLibrary___SetEnabledXRCamera_Params
    {
        bool    bOnOff; // 0x000000 (0x000001) [Default: true]
    };

    struct UARBlueprintLibrary___StartARSession_Params
    {
        UARSessionConfig*   SessionConfig;  // 0x000000 (0x000008) [Default: 0x130A5F60]
    };

    struct UARBlueprintLibrary___ToggleARCapture_Params
    {
        bool            bOnOff;         // 0x000000 (0x000001) [Default: true]
        EARCaptureType  CaptureType;    // 0x000001 (0x000001) [Default: EARCaptureType(95)]
        bool            ReturnValue;    // 0x000002 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARBlueprintLibrary___UnpinComponent_Params
    {
        USceneComponent*    ComponentToUnpin;   // 0x000000 (0x000008) [Default: 0x130A5F60]
    };

    struct UARCandidateImage___GetCandidateTexture_Params
    {
        UTexture2D* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x13988B80]
    };

    struct UARCandidateImage___GetFriendlyName_Params
    {
        FString ReturnValue;    // 0x000000 (0x000010) [ReturnValue] [Default: L"??"]
    };

    struct UARCandidateImage___GetOrientation_Params
    {
        EARCandidateImageOrientation    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARCandidateImageOrientation(128)]
    };

    struct UARCandidateImage___GetPhysicalHeight_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 3.85078e-27f]
    };

    struct UARCandidateImage___GetPhysicalWidth_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 3.85078e-27f]
    };

    struct UARCandidateObject___GetBoundingBox_Params
    {
        FBox    ReturnValue;    // 0x000000 (0x000038) [ReturnValue]
    };

    struct UARCandidateObject___GetCandidateObjectData_Params
    {
        TArray<uint8>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UARCandidateObject___GetFriendlyName_Params
    {
        FString ReturnValue;    // 0x000000 (0x000010) [ReturnValue] [Default: L"??"]
    };

    struct UARCandidateObject___SetBoundingBox_Params
    {
        FBox    InBoundingBox;  // 0x000000 (0x000038) [OutParam]
    };

    struct UARCandidateObject___SetCandidateObjectData_Params
    {
        TArray<uint8>   InCandidateObject;  // 0x000000 (0x000010) [OutParam]
    };

    struct UARCandidateObject___SetFriendlyName_Params
    {
        FString NewName;    // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UARComponent___GetMRMesh_Params
    {
        UMRMeshComponent*   ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1397CB10]
    };

    struct UARComponent___SetNativeID_Params
    {
        FGuid   NativeID;   // 0x000000 (0x000010)
    };

    struct UARDependencyHandler___CheckARServiceAvailability_Params
    {
        UObject*                WorldContextObject; // 0x000000 (0x000008) [Default: 0x13981470]
        FLatentActionInfo       LatentInfo;         // 0x000008 (0x000018)
        EARServiceAvailability  OutAvailability;    // 0x000020 (0x000001) [OutParam] [Default: EARServiceAvailability(187)]
    };

    struct UARDependencyHandler___GetARDependencyHandler_Params
    {
        UARDependencyHandler*   ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x13981470]
    };

    struct UARDependencyHandler___InstallARService_Params
    {
        UObject*                        WorldContextObject; // 0x000000 (0x000008) [Default: 0x13981470]
        FLatentActionInfo               LatentInfo;         // 0x000008 (0x000018)
        EARServiceInstallRequestResult  OutInstallResult;   // 0x000020 (0x000001) [OutParam] [Default: EARServiceInstallRequestResult(187)]
    };

    struct UARDependencyHandler___RequestARSessionPermission_Params
    {
        UObject*                            WorldContextObject;     // 0x000000 (0x000008) [Default: 0x13981470]
        UARSessionConfig*                   SessionConfig;          // 0x000008 (0x000008) [Default: 0xB92C18DD00000031]
        FLatentActionInfo                   LatentInfo;             // 0x000010 (0x000018)
        EARServicePermissionRequestResult   OutPermissionResult;    // 0x000028 (0x000001) [OutParam] [Default: EARServicePermissionRequestResult(0)]
    };

    struct UARDependencyHandler___StartARSessionLatent_Params
    {
        UObject*            WorldContextObject; // 0x000000 (0x000008) [Default: 0x13981470]
        UARSessionConfig*   SessionConfig;      // 0x000008 (0x000008) [Default: 0xB92C18DD00000031]
        FLatentActionInfo   LatentInfo;         // 0x000010 (0x000018)
    };

    struct UAREnvironmentCaptureProbe___GetEnvironmentCaptureTexture_Params
    {
        UAREnvironmentCaptureProbeTexture*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x139876E0]
    };

    struct UAREnvironmentCaptureProbe___GetExtent_Params
    {
        FVector ReturnValue;    // 0x000000 (0x000018) [ReturnValue]
    };

    struct UAREnvironmentProbeComponent___ReceiveAdd_Params
    {
        FAREnvironmentProbeUpdatePayload    Payload;    // 0x000000 (0x000060) [OutParam]
    };

    struct UAREnvironmentProbeComponent___ReceiveUpdate_Params
    {
        FAREnvironmentProbeUpdatePayload    Payload;    // 0x000000 (0x000060) [OutParam]
    };

    struct UAREnvironmentProbeComponent___ServerUpdatePayload_Params
    {
        FAREnvironmentProbeUpdatePayload    NewPayload; // 0x000000 (0x000060)
    };

    struct UARFaceComponent___ReceiveAdd_Params
    {
        FARFaceUpdatePayload    Payload;    // 0x000000 (0x000060) [OutParam]
    };

    struct UARFaceComponent___ReceiveUpdate_Params
    {
        FARFaceUpdatePayload    Payload;    // 0x000000 (0x000060) [OutParam]
    };

    struct UARFaceComponent___ServerUpdatePayload_Params
    {
        FARFaceUpdatePayload    NewPayload; // 0x000000 (0x000060)
    };

    struct UARFaceComponent___SetFaceComponentDebugMode_Params
    {
        EFaceComponentDebugMode NewDebugMode;   // 0x000000 (0x000001) [Default: EFaceComponentDebugMode(48)]
    };

    struct UARFaceGeometry___GetBlendShapes_Params
    {
        TMap<EARFaceBlendShape, float>  ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UARFaceGeometry___GetBlendShapeValue_Params
    {
        EARFaceBlendShape   BlendShape;                     // 0x000000 (0x000001) [Default: EARFaceBlendShape(64)]
        uint8               UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        float               ReturnValue;                    // 0x000004 (0x000004) [ReturnValue] [Default: 0f]
    };

    struct UARFaceGeometry___GetLocalSpaceEyeTransform_Params
    {
        EAREye      Eye;                            // 0x000000 (0x000001) [Default: EAREye(64)]
        uint8       UnknownData_000001[0x00000F];   // 0x000001 (0x00000F)
        FTransform  ReturnValue;                    // 0x000010 (0x000060) [ReturnValue]
    };

    struct UARFaceGeometry___GetWorldSpaceEyeTransform_Params
    {
        EAREye      Eye;                            // 0x000000 (0x000001) [Default: EAREye(64)]
        uint8       UnknownData_000001[0x00000F];   // 0x000001 (0x00000F)
        FTransform  ReturnValue;                    // 0x000010 (0x000060) [ReturnValue]
    };

    struct UARGeoAnchor___GetAltitudeMeters_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 3.84977e-27f]
    };

    struct UARGeoAnchor___GetAltitudeSource_Params
    {
        EARAltitudeSource   ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARAltitudeSource(80)]
    };

    struct UARGeoAnchor___GetLatitude_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 3.84977e-27f]
    };

    struct UARGeoAnchor___GetLongitude_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 3.84977e-27f]
    };

    struct UARGeoAnchorComponent___ReceiveAdd_Params
    {
        FARGeoAnchorUpdatePayload   Payload;    // 0x000000 (0x0000A0) [OutParam]
    };

    struct UARGeoAnchorComponent___ReceiveUpdate_Params
    {
        FARGeoAnchorUpdatePayload   Payload;    // 0x000000 (0x0000A0) [OutParam]
    };

    struct UARGeoAnchorComponent___ServerUpdatePayload_Params
    {
        FARGeoAnchorUpdatePayload   NewPayload; // 0x000000 (0x0000A0)
    };

    struct UARGeoAnchorComponent___SetGeoAnchorComponentDebugMode_Params
    {
        EGeoAnchorComponentDebugMode    NewDebugMode;   // 0x000000 (0x000001) [Default: EGeoAnchorComponentDebugMode(48)]
    };

    struct UARGeoTrackingSupport___AddGeoAnchorAtLocation_Params
    {
        float   Longitude;          // 0x000000 (0x000004) [Default: 3.83939e-27f]
        float   Latitude;           // 0x000004 (0x000004) [Default: 0f]
        FString OptionalAnchorName; // 0x000008 (0x000010) [Default: L""]
        bool    ReturnValue;        // 0x000018 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARGeoTrackingSupport___AddGeoAnchorAtLocationWithAltitude_Params
    {
        float   Longitude;                      // 0x000000 (0x000004) [Default: 3.83939e-27f]
        float   Latitude;                       // 0x000004 (0x000004) [Default: 0f]
        float   AltitudeMeters;                 // 0x000008 (0x000004) [Default: 6.86636e-44f]
        uint8   UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FString OptionalAnchorName;             // 0x000010 (0x000010) [Default: L""]
        bool    ReturnValue;                    // 0x000020 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARGeoTrackingSupport___GetGeoTrackingAccuracy_Params
    {
        EARGeoTrackingAccuracy  ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARGeoTrackingAccuracy(16)]
    };

    struct UARGeoTrackingSupport___GetGeoTrackingState_Params
    {
        EARGeoTrackingState ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARGeoTrackingState(16)]
    };

    struct UARGeoTrackingSupport___GetGeoTrackingStateReason_Params
    {
        EARGeoTrackingStateReason   ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARGeoTrackingStateReason(16)]
    };

    struct UARGeoTrackingSupport___GetGeoTrackingSupport_Params
    {
        UARGeoTrackingSupport*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x13981810]
    };

    struct UARGetCandidateObjectAsyncTaskBlueprintProxy___ARGetCandidateObject_Params
    {
        UObject*                                        WorldContextObject; // 0x000000 (0x000008) [Default: 0x1397C7B0]
        FVector                                         Location;           // 0x000008 (0x000018)
        FVector                                         Extent;             // 0x000020 (0x000018)
        UARGetCandidateObjectAsyncTaskBlueprintProxy*   ReturnValue;        // 0x000038 (0x000008) [ReturnValue] [Default: nullptr]
    };

    struct UARImageComponent___ReceiveAdd_Params
    {
        FARImageUpdatePayload   Payload;    // 0x000000 (0x0000A0) [OutParam]
    };

    struct UARImageComponent___ReceiveUpdate_Params
    {
        FARImageUpdatePayload   Payload;    // 0x000000 (0x0000A0) [OutParam]
    };

    struct UARImageComponent___ServerUpdatePayload_Params
    {
        FARImageUpdatePayload   NewPayload; // 0x000000 (0x0000A0)
    };

    struct UARImageComponent___SetImageComponentDebugMode_Params
    {
        EImageComponentDebugMode    NewDebugMode;   // 0x000000 (0x000001) [Default: EImageComponentDebugMode(224)]
    };

    struct UARLifeCycleComponent___ServerDestroyARActor_Params
    {
        AARActor*   Actor;  // 0x000000 (0x000008) [Default: 0x139820F0]
    };

    struct UARLifeCycleComponent___ServerSpawnARActor_Params
    {
        UClass* ComponentClass; // 0x000000 (0x000008) [Default: 0x139820F0]
        FGuid   NativeID;       // 0x000008 (0x000010)
    };

    struct UARLifeCycleComponent___InstanceARActorSpawnedDelegate_Params
    {
        UClass*     ComponentClass; // 0x000000 (0x000008) [Default: 0x139820F0]
        FGuid       NativeID;       // 0x000008 (0x000010)
        AARActor*   SpawnedActor;   // 0x000018 (0x000008) [Default: 0x17A72C80]
    };

    struct UARLifeCycleComponent___InstanceARActorToBeDestroyedDelegate_Params
    {
        AARActor*   Actor;  // 0x000000 (0x000008) [Default: 0x139820F0]
    };

    struct UARMeshComponent___ReceiveAdd_Params
    {
        FARMeshUpdatePayload    Payload;    // 0x000000 (0x000090) [OutParam]
    };

    struct UARMeshComponent___ReceiveUpdate_Params
    {
        FARMeshUpdatePayload    Payload;    // 0x000000 (0x000090) [OutParam]
    };

    struct UARMeshComponent___ServerUpdatePayload_Params
    {
        FARMeshUpdatePayload    NewPayload; // 0x000000 (0x000090)
    };

    struct UARMeshGeometry___GetObjectClassificationAtLocation_Params
    {
        FVector                 InWorldLocation;                // 0x000000 (0x000018) [OutParam]
        EARObjectClassification OutClassification;              // 0x000018 (0x000001) [OutParam] [Default: EARObjectClassification(128)]
        uint8                   UnknownData_000019[0x000007];   // 0x000019 (0x000007)
        FVector                 OutClassificationLocation;      // 0x000020 (0x000018) [OutParam]
        float                   MaxLocationDiff;                // 0x000038 (0x000004) [Default: 0f]
        bool                    ReturnValue;                    // 0x00003C (0x000001) [ReturnValue] [Default: false]
    };

    struct UARObjectComponent___ReceiveAdd_Params
    {
        FARObjectUpdatePayload  Payload;    // 0x000000 (0x000060) [OutParam]
    };

    struct UARObjectComponent___ReceiveUpdate_Params
    {
        FARObjectUpdatePayload  Payload;    // 0x000000 (0x000060) [OutParam]
    };

    struct UARObjectComponent___ServerUpdatePayload_Params
    {
        FARObjectUpdatePayload  NewPayload; // 0x000000 (0x000060)
    };

    struct UARPin___DebugDraw_Params
    {
        UWorld*         World;              // 0x000000 (0x000008) [Default: 0x139827F0]
        FLinearColor    Color;              // 0x000008 (0x000010) [OutParam]
        float           Scale;              // 0x000018 (0x000004) [Default: 1.08034e-24f]
        float           PersistForSeconds;  // 0x00001C (0x000004) [Default: 0f]
    };

    struct UARPin___GetDebugName_Params
    {
        FName   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: FName(328738800) -> L""]
    };

    struct UARPin___GetLocalToTrackingTransform_Params
    {
        FTransform  ReturnValue;    // 0x000000 (0x000060) [ReturnValue]
    };

    struct UARPin___GetLocalToWorldTransform_Params
    {
        FTransform  ReturnValue;    // 0x000000 (0x000060) [ReturnValue]
    };

    struct UARPin___GetPinnedComponent_Params
    {
        USceneComponent*    ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x139827F0]
    };

    struct UARPin___GetTrackedGeometry_Params
    {
        UARTrackedGeometry* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x139827F0]
    };

    struct UARPin___GetTrackingState_Params
    {
        EARTrackingState    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARTrackingState(240)]
    };

    struct UARPlaneComponent___GetObjectClassificationDebugColors_Params
    {
        TMap<EARObjectClassification, FLinearColor> ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UARPlaneComponent___ReceiveAdd_Params
    {
        FARPlaneUpdatePayload   Payload;    // 0x000000 (0x0000D0) [OutParam]
    };

    struct UARPlaneComponent___ReceiveUpdate_Params
    {
        FARPlaneUpdatePayload   Payload;    // 0x000000 (0x0000D0) [OutParam]
    };

    struct UARPlaneComponent___ServerUpdatePayload_Params
    {
        FARPlaneUpdatePayload   NewPayload; // 0x000000 (0x0000D0)
    };

    struct UARPlaneComponent___SetObjectClassificationDebugColors_Params
    {
        TMap<EARObjectClassification, FLinearColor> InColors;   // 0x000000 (0x000010) [OutParam]
    };

    struct UARPlaneComponent___SetPlaneComponentDebugMode_Params
    {
        EPlaneComponentDebugMode    NewDebugMode;   // 0x000000 (0x000001) [Default: EPlaneComponentDebugMode(208)]
    };

    struct UARPlaneGeometry___GetBoundaryPolygonInLocalSpace_Params
    {
        TArray<FVector> ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UARPlaneGeometry___GetCenter_Params
    {
        FVector ReturnValue;    // 0x000000 (0x000018) [ReturnValue]
    };

    struct UARPlaneGeometry___GetExtent_Params
    {
        FVector ReturnValue;    // 0x000000 (0x000018) [ReturnValue]
    };

    struct UARPlaneGeometry___GetOrientation_Params
    {
        EARPlaneOrientation ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARPlaneOrientation(192)]
    };

    struct UARPlaneGeometry___GetSubsumedBy_Params
    {
        UARPlaneGeometry*   ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x139867C0]
    };

    struct UARPointComponent___ReceiveAdd_Params
    {
        FARPointUpdatePayload   Payload;    // 0x000000 (0x000001) [OutParam]
    };

    struct UARPointComponent___ReceiveUpdate_Params
    {
        FARPointUpdatePayload   Payload;    // 0x000000 (0x000001) [OutParam]
    };

    struct UARPointComponent___ServerUpdatePayload_Params
    {
        FARPointUpdatePayload   NewPayload; // 0x000000 (0x000001)
    };

    struct UARPoseComponent___ReceiveAdd_Params
    {
        FARPoseUpdatePayload    Payload;    // 0x000000 (0x000070) [OutParam]
    };

    struct UARPoseComponent___ReceiveUpdate_Params
    {
        FARPoseUpdatePayload    Payload;    // 0x000000 (0x000070) [OutParam]
    };

    struct UARPoseComponent___ServerUpdatePayload_Params
    {
        FARPoseUpdatePayload    NewPayload; // 0x000000 (0x000070)
    };

    struct UARPoseComponent___SetPoseComponentDebugMode_Params
    {
        EPoseComponentDebugMode NewDebugMode;   // 0x000000 (0x000001) [Default: EPoseComponentDebugMode(64)]
    };

    struct UARQRCodeComponent___ReceiveAdd_Params
    {
        FARQRCodeUpdatePayload  Payload;    // 0x000000 (0x0000B0) [OutParam]
    };

    struct UARQRCodeComponent___ReceiveUpdate_Params
    {
        FARQRCodeUpdatePayload  Payload;    // 0x000000 (0x0000B0) [OutParam]
    };

    struct UARQRCodeComponent___ServerUpdatePayload_Params
    {
        FARQRCodeUpdatePayload  NewPayload; // 0x000000 (0x0000B0)
    };

    struct UARQRCodeComponent___SetQRCodeComponentDebugMode_Params
    {
        EQRCodeComponentDebugMode   NewDebugMode;   // 0x000000 (0x000001) [Default: EQRCodeComponentDebugMode(144)]
    };

    struct UARSaveWorldAsyncTaskBlueprintProxy___ARSaveWorld_Params
    {
        UObject*                                WorldContextObject; // 0x000000 (0x000008) [Default: 0x1397C4B0]
        UARSaveWorldAsyncTaskBlueprintProxy*    ReturnValue;        // 0x000008 (0x000008) [ReturnValue] [Default: 0xA32C18DD00000031]
    };

    struct UARSessionConfig___AddCandidateImage_Params
    {
        UARCandidateImage*  NewCandidateImage;  // 0x000000 (0x000008) [Default: 0x13982DF0]
    };

    struct UARSessionConfig___AddCandidateObject_Params
    {
        UARCandidateObject* CandidateObject;    // 0x000000 (0x000008) [Default: 0x13982DF0]
    };

    struct UARSessionConfig___GetCandidateImageList_Params
    {
        TArray<UARCandidateImage*>  ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UARSessionConfig___GetCandidateObjectList_Params
    {
        TArray<UARCandidateObject*> ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UARSessionConfig___GetDesiredVideoFormat_Params
    {
        FARVideoFormat  ReturnValue;    // 0x000000 (0x00000C) [ReturnValue]
    };

    struct UARSessionConfig___GetEnabledSessionTrackingFeature_Params
    {
        EARSessionTrackingFeature   ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARSessionTrackingFeature(240)]
    };

    struct UARSessionConfig___GetEnvironmentCaptureProbeType_Params
    {
        EAREnvironmentCaptureProbeType  ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EAREnvironmentCaptureProbeType(240)]
    };

    struct UARSessionConfig___GetFaceTrackingDirection_Params
    {
        EARFaceTrackingDirection    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARFaceTrackingDirection(240)]
    };

    struct UARSessionConfig___GetFaceTrackingUpdate_Params
    {
        EARFaceTrackingUpdate   ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARFaceTrackingUpdate(240)]
    };

    struct UARSessionConfig___GetFrameSyncMode_Params
    {
        EARFrameSyncMode    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARFrameSyncMode(240)]
    };

    struct UARSessionConfig___GetLightEstimationMode_Params
    {
        EARLightEstimationMode  ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARLightEstimationMode(240)]
    };

    struct UARSessionConfig___GetMaxNumSimultaneousImagesTracked_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 328740336]
    };

    struct UARSessionConfig___GetPlaneDetectionMode_Params
    {
        EARPlaneDetectionMode   ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARPlaneDetectionMode(240)]
    };

    struct UARSessionConfig___GetSceneReconstructionMethod_Params
    {
        EARSceneReconstruction  ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARSceneReconstruction(240)]
    };

    struct UARSessionConfig___GetSessionType_Params
    {
        EARSessionType  ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARSessionType(240)]
    };

    struct UARSessionConfig___GetWorldAlignment_Params
    {
        EARWorldAlignment   ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARWorldAlignment(240)]
    };

    struct UARSessionConfig___GetWorldMapData_Params
    {
        TArray<uint8>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UARSessionConfig___RemoveCandidateImage_Params
    {
        UARCandidateImage*  CandidateImage; // 0x000000 (0x000008) [Default: 0x13982DF0]
    };

    struct UARSessionConfig___RemoveCandidateImageAtIndex_Params
    {
        int32   Index;  // 0x000000 (0x000004) [Default: 328740336]
    };

    struct UARSessionConfig___SetCandidateObjectList_Params
    {
        TArray<UARCandidateObject*> InCandidateObjects; // 0x000000 (0x000010) [OutParam]
    };

    struct UARSessionConfig___SetDesiredVideoFormat_Params
    {
        FARVideoFormat  NewFormat;  // 0x000000 (0x00000C)
    };

    struct UARSessionConfig___SetEnableAutoFocus_Params
    {
        bool    bNewValue;  // 0x000000 (0x000001) [Default: true]
    };

    struct UARSessionConfig___SetFaceTrackingDirection_Params
    {
        EARFaceTrackingDirection    InDirection;    // 0x000000 (0x000001) [Default: EARFaceTrackingDirection(240)]
    };

    struct UARSessionConfig___SetFaceTrackingUpdate_Params
    {
        EARFaceTrackingUpdate   InUpdate;   // 0x000000 (0x000001) [Default: EARFaceTrackingUpdate(240)]
    };

    struct UARSessionConfig___SetResetCameraTracking_Params
    {
        bool    bNewValue;  // 0x000000 (0x000001) [Default: true]
    };

    struct UARSessionConfig___SetResetTrackedObjects_Params
    {
        bool    bNewValue;  // 0x000000 (0x000001) [Default: true]
    };

    struct UARSessionConfig___SetSceneReconstructionMethod_Params
    {
        EARSceneReconstruction  InSceneReconstructionMethod;    // 0x000000 (0x000001) [Default: EARSceneReconstruction(240)]
    };

    struct UARSessionConfig___SetSessionTrackingFeatureToEnable_Params
    {
        EARSessionTrackingFeature   InSessionTrackingFeature;   // 0x000000 (0x000001) [Default: EARSessionTrackingFeature(240)]
    };

    struct UARSessionConfig___SetWorldMapData_Params
    {
        TArray<uint8>   WorldMapData;   // 0x000000 (0x000010)
    };

    struct UARSessionConfig___ShouldEnableAutoFocus_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARSessionConfig___ShouldEnableCameraTracking_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARSessionConfig___ShouldRenderCameraOverlay_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARSessionConfig___ShouldResetCameraTracking_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARSessionConfig___ShouldResetTrackedObjects_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARTraceResultLibrary___GetDistanceFromCamera_Params
    {
        FARTraceResult  TraceResult;    // 0x000000 (0x000090) [OutParam]
        float           ReturnValue;    // 0x000090 (0x000004) [ReturnValue] [Default: 0f]
    };

    struct UARTraceResultLibrary___GetLocalToTrackingTransform_Params
    {
        FARTraceResult  TraceResult;    // 0x000000 (0x000090) [OutParam]
        FTransform      ReturnValue;    // 0x000090 (0x000060) [ReturnValue]
    };

    struct UARTraceResultLibrary___GetLocalToWorldTransform_Params
    {
        FARTraceResult  TraceResult;    // 0x000000 (0x000090) [OutParam]
        FTransform      ReturnValue;    // 0x000090 (0x000060) [ReturnValue]
    };

    struct UARTraceResultLibrary___GetLocalTransform_Params
    {
        FARTraceResult  TraceResult;    // 0x000000 (0x000090) [OutParam]
        FTransform      ReturnValue;    // 0x000090 (0x000060) [ReturnValue]
    };

    struct UARTraceResultLibrary___GetTraceChannel_Params
    {
        FARTraceResult          TraceResult;    // 0x000000 (0x000090) [OutParam]
        EARLineTraceChannels    ReturnValue;    // 0x000090 (0x000001) [ReturnValue] [Default: EARLineTraceChannels(0)]
    };

    struct UARTraceResultLibrary___GetTrackedGeometry_Params
    {
        FARTraceResult      TraceResult;    // 0x000000 (0x000090) [OutParam]
        UARTrackedGeometry* ReturnValue;    // 0x000090 (0x000008) [ReturnValue] [Default: nullptr]
    };

    struct UARTrackedGeometry___GetDebugName_Params
    {
        FName   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: FName(328754416) -> L""]
    };

    struct UARTrackedGeometry___GetLastUpdateFrameNumber_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 328754416]
    };

    struct UARTrackedGeometry___GetLastUpdateTimestamp_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 3.84697e-27f]
    };

    struct UARTrackedGeometry___GetLocalToTrackingTransform_Params
    {
        FTransform  ReturnValue;    // 0x000000 (0x000060) [ReturnValue]
    };

    struct UARTrackedGeometry___GetLocalToWorldTransform_Params
    {
        FTransform  ReturnValue;    // 0x000000 (0x000060) [ReturnValue]
    };

    struct UARTrackedGeometry___GetName_Params
    {
        FString ReturnValue;    // 0x000000 (0x000010) [ReturnValue] [Default: L"??"]
    };

    struct UARTrackedGeometry___GetObjectClassification_Params
    {
        EARObjectClassification ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARObjectClassification(240)]
    };

    struct UARTrackedGeometry___GetTrackingState_Params
    {
        EARTrackingState    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EARTrackingState(240)]
    };

    struct UARTrackedGeometry___GetUnderlyingMesh_Params
    {
        UMRMeshComponent*   ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x139864F0]
    };

    struct UARTrackedGeometry___HasSpatialMeshUsageFlag_Params
    {
        EARSpatialMeshUsageFlags    InFlag;         // 0x000000 (0x000001) [Default: EARSpatialMeshUsageFlags(240)]
        bool                        ReturnValue;    // 0x000001 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARTrackedGeometry___IsTracked_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UARTrackedImage___GetDetectedImage_Params
    {
        UARCandidateImage*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x13986CE0]
    };

    struct UARTrackedImage___GetEstimateSize_Params
    {
        FVector2D   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UARTrackedObject___GetDetectedObject_Params
    {
        UARCandidateObject* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x13987970]
    };

    struct UARTrackedPose___GetTrackedPoseData_Params
    {
        FARPose3D   ReturnValue;    // 0x000000 (0x000050) [ReturnValue]
    };

    struct UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy___CheckGeoTrackingAvailability_Params
    {
        UObject*                                                WorldContextObject; // 0x000000 (0x000008) [Default: 0x13981AE0]
        UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy*   ReturnValue;        // 0x000008 (0x000008) [ReturnValue] [Default: 0x952C18DD00000031]
    };

    struct UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy___CheckGeoTrackingAvailabilityAtLocation_Params
    {
        UObject*                                                WorldContextObject; // 0x000000 (0x000008) [Default: 0x13981AE0]
        float                                                   Longitude;          // 0x000008 (0x000004) [Default: 6.86636e-44f]
        float                                                   Latitude;           // 0x00000C (0x000004) [Default: -3.47547e-26f]
        UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy*   ReturnValue;        // 0x000010 (0x000008) [ReturnValue] [Default: 0x17A86350]
    };

    struct UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy___GeoTrackingAvailabilityDelegate_Params
    {
        bool    bIsAvailable;                   // 0x000000 (0x000001) [Default: true]
        uint8   UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        FString Error;                          // 0x000008 (0x000010) [Default: L""]
    };

    struct UGetGeoLocationAsyncTaskBlueprintProxy___GetGeoLocationAtWorldPosition_Params
    {
        UObject*                                WorldContextObject; // 0x000000 (0x000008) [Default: 0x13981DE0]
        FVector                                 WorldPosition;      // 0x000008 (0x000018) [OutParam]
        UGetGeoLocationAsyncTaskBlueprintProxy* ReturnValue;        // 0x000020 (0x000008) [ReturnValue] [Default: 0xF54CB3BB]
    };

    struct UGetGeoLocationAsyncTaskBlueprintProxy___GetGeoLocationDelegate_Params
    {
        float   Longitude;                      // 0x000000 (0x000004) [Default: 3.83997e-27f]
        float   Latitude;                       // 0x000004 (0x000004) [Default: 0f]
        float   Altitude;                       // 0x000008 (0x000004) [Default: 6.86636e-44f]
        uint8   UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FString Error;                          // 0x000010 (0x000010) [Default: L""]
    };

} // namespace UE

