/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BallisticShieldBaseRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0012A0 (0x000130)
    class alignas(0x4) UBallisticShieldItemLayerAnimInstance : public UFortPlayerAnimInstanceProxy
    {
    public:
        bool    bIsRush;                        // 0x001170 (0x000001) [Default: false]
        bool    bIsEquipping;                   // 0x001171 (0x000001) [Default: false]
        bool    bEnterLanding;                  // 0x001172 (0x000001) [Default: false]
        bool    bExitLanding;                   // 0x001173 (0x000001) [Default: false]
        bool    bIsShieldBlocking;              // 0x001174 (0x000001) [Default: false]
        bool    bIsStaggerBuildup;              // 0x001175 (0x000001) [Default: false]
        uint8   UnknownData_001176[0x000002];   // 0x001176 (0x000002)
        float   Yaw;                            // 0x001178 (0x000004) [Default: 0f]
        float   ChargeAOAlpha;                  // 0x00117C (0x000004) [Default: 0f]
        int32   GenderAndSize;                  // 0x001180 (0x000004) [Default: 0]
        float   ReloadUBAlpha;                  // 0x001184 (0x000004) [Default: 0f]
        float   MaskLeftArmAlpha;               // 0x001188 (0x000004) [Default: 0f]
        float   StaggerAmount;                  // 0x00118C (0x000004) [Default: 0f]
        uint8   UnknownData_001190[0x000110];   // 0x001190 (0x000110)
    };
    // Size: 0x000028 (0x000000)
    class IBallisticShieldWeaponInterface : public IInterface
    {
    public:
    
    public: // Functions
        void    GetBallisticShieldData(EBallisticShieldPlayerActionState& BallisticShieldPlayerState, float& StaggerBuildupPercent); // 0x07FB7D48 [Native | Event | Public | HasOutParms | BlueprintEvent]
    };
    // Size: 0x000620 (0x000038)
    class alignas(0x8) UFortMovementMode_ELBShieldSprint : public UFortMovementMode_ELTacSprint
    {
    public:
        TSoftClassPtr<UClass>   GrantedAbility;                 // 0x0005E8 (0x000020) [Default: nullptr]
        uint8                   UnknownData_000608[0x000018];   // 0x000608 (0x000018)
    };
    // Size: 0x0000B0 (0x000088)
    class alignas(0x8) UTargetingFilterTask_BShieldCharge : public UTargetingFilterTask_BasicFilterTemplate
    {
    public:
        TArray<UClass*> WalkableActorClasses;   // 0x000028 (0x000010)
        FScalableFloat  BashableActorAngle;     // 0x000038 (0x000028)
        FScalableFloat  MainTraceDistance;      // 0x000060 (0x000028)
        FScalableFloat  FloorHitZTolerance;     // 0x000088 (0x000028)
    };
}

