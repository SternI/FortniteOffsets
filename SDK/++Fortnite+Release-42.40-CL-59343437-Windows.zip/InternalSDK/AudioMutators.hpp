/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:07
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioMutators
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000048 (0x000020)
    class alignas(0x8) UAudioMutator : public UAudioMutatorBase
    {
    public:
        TArray<FInstancedStruct>    Selectors;  // 0x000028 (0x000010)
        TArray<FInstancedStruct>    Actions;    // 0x000038 (0x000010)
    };
    // Size: 0x000028 (0x000000)
    class UAudioMutatorBase : public UObject
    {
    public:
    };
    // Size: 0x0000E0 (0x0000B0)
    class alignas(0x8) UAudioMutatorsSubsystem : public UAudioEngineSubsystem
    {
    public:
        void**  VTable_000030;                  // 0x000030 (0x000008) VTable [12 slots] -> 0x1337D810
        uint8   UnknownData_000038[0x000010];   // 0x000038 (0x000010)
        void**  VTable_000048;                  // 0x000048 (0x000008) VTable [12 slots] -> 0x1337E130
        uint8   UnknownData_000050[0x000090];   // 0x000050 (0x000090)
    
    public: // Functions
        void    AddMutator(UAudioMutatorBase* Mutator); // 0x05214030 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    RemoveMutator(UAudioMutatorBase* Mutator); // 0x052141B8 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    ReplaceMutator(UAudioMutatorBase* Mutator); // 0x05214340 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000048 (0x000018)
    class alignas(0x8) UAudioOwnerRegistry : public UAudioEngineSubsystem
    {
    public:
        void**  VTable_000030;                  // 0x000030 (0x000008) VTable [181 slots] -> 0x1337DB80
        uint8   UnknownData_000038[0x000010];   // 0x000038 (0x000010)
    };
    // Size: 0x000068 (0x000040)
    class alignas(0x8) UBranchAudioMutator : public UAudioMutatorBase
    {
    public:
        FInstancedStruct            ActivationSelector;     // 0x000028 (0x000010)
        FInstancedStruct            InclusionSelector;      // 0x000038 (0x000010)
        TArray<FInstancedStruct>    InclusionGroupActions;  // 0x000048 (0x000010)
        TArray<FInstancedStruct>    ExclusionGroupActions;  // 0x000058 (0x000010)
    };
    // Size: 0x000048 (0x000010)
    class alignas(0x8) UGameFeatureAction_AddAudioMutators : public UGameFeatureAction_AudioActionBase
    {
    public:
        TArray<UAudioMutatorBase*>  Mutators;   // 0x000038 (0x000010)
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x8) USoundSelectorPresetAsset : public UDataAsset
    {
    public:
        FInstancedStruct    Selector;   // 0x000028 (0x000010)
    };
    // Size: 0x000048 (0x000020)
    class alignas(0x8) UStatefulAudioMutator : public UAudioMutatorBase
    {
    public:
        FInstancedStruct            Selector;   // 0x000028 (0x000010)
        TArray<FInstancedStruct>    Actions;    // 0x000038 (0x000010)
    };
    // Size: 0x000008 (0x000000)
    struct FAudioMutatorAction : public FAudioMutatorActionBase
    {
    };
    // Size: 0x000008 (0x000008)
    struct FAudioMutatorActionBase
    {
        uint8   UnknownData_000000[0x000008];   // 0x000000 (0x000008)
    };
    // Size: 0x000008 (0x000000)
    struct FAudioMutatorParseParamAction : public FAudioMutatorStatefulActionBase
    {
    };
    // Size: 0x000008 (0x000008)
    struct FAudioMutatorSelector
    {
        uint8   UnknownData_000000[0x000008];   // 0x000000 (0x000008)
    };
    // Size: 0x000008 (0x000000)
    struct FAudioMutatorStatefulActionBase : public FAudioMutatorActionBase
    {
    };
    // Size: 0x000008 (0x000000)
    struct FAudioMutatorStatefulSoundAction : public FAudioMutatorStatefulActionBase
    {
    };
    // Size: 0x000018 (0x000010)
    struct alignas(0x8) FSoundActionModulator : public FAudioMutatorAction
    {
        USoundModulatorBase*    Modulator;                      // 0x000008 (0x000008)
        EModulationDestination  Destination;                    // 0x000010 (0x000001)
        uint8                   UnknownData_000011[0x000007];   // 0x000011 (0x000007)
    };
    // Size: 0x000010 (0x000008)
    struct alignas(0x4) FSoundActionPitch : public FAudioMutatorAction
    {
        float   PitchMultiplier;                // 0x000008 (0x000004)
        uint8   UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
    };
    // Size: 0x000048 (0x000040)
    struct alignas(0x8) FSoundActionRerouteSubmixSend : public FAudioMutatorAction
    {
        TSoftObjectPtr<USoundSubmix>    SubmixToFind;       // 0x000008 (0x000020)
        TSoftObjectPtr<USoundSubmix>    ReplacementSubmix;  // 0x000028 (0x000020)
    };
    // Size: 0x000010 (0x000008)
    struct alignas(0x8) FSoundActionSourceEffect : public FAudioMutatorAction
    {
        USoundEffectSourcePresetChain*  PresetChain;    // 0x000008 (0x000008)
    };
    // Size: 0x000020 (0x000018)
    struct alignas(0x8) FSoundActionSubmixSend : public FAudioMutatorAction
    {
        TArray<FSoundSubmixSendInfo>    SubmixSends;                    // 0x000008 (0x000010)
        bool                            bOverrideExistingSendLevels;    // 0x000018 (0x000001)
        uint8                           UnknownData_000019[0x000007];   // 0x000019 (0x000007)
    };
    // Size: 0x000010 (0x000008)
    struct alignas(0x4) FSoundActionVolume : public FAudioMutatorAction
    {
        float   VolumeMultiplier;               // 0x000008 (0x000004)
        uint8   UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
    };
    // Size: 0x000018 (0x000010)
    struct alignas(0x8) FSoundSelectorActorClass : public FAudioMutatorSelector
    {
        UClass* ActorClass;                     // 0x000008 (0x000008)
        bool    bExactClass;                    // 0x000010 (0x000001)
        uint8   UnknownData_000011[0x000007];   // 0x000011 (0x000007)
    };
    // Size: 0x000010 (0x000008)
    struct alignas(0x8) FSoundSelectorActorInstance : public FAudioMutatorSelector
    {
        TWeakObjectPtr<AActor>  Actor;  // 0x000008 (0x000008) [Default: nullptr]
    };
    // Size: 0x000008 (0x000000)
    struct FSoundSelectorAlways : public FSoundSelectorConditionalBase
    {
    };
    // Size: 0x000018 (0x000010)
    struct alignas(0x8) FSoundSelectorConditionalAll : public FSoundSelectorConditionalBase
    {
        TArray<FInstancedStruct>    Selectors;  // 0x000008 (0x000010)
    };
    // Size: 0x000018 (0x000010)
    struct alignas(0x8) FSoundSelectorConditionalAny : public FSoundSelectorConditionalBase
    {
        TArray<FInstancedStruct>    Selectors;  // 0x000008 (0x000010)
    };
    // Size: 0x000008 (0x000000)
    struct FSoundSelectorConditionalBase : public FAudioMutatorSelector
    {
    };
    // Size: 0x000018 (0x000010)
    struct alignas(0x8) FSoundSelectorConditionalNone : public FSoundSelectorConditionalBase
    {
        TArray<FInstancedStruct>    Selectors;  // 0x000008 (0x000010)
    };
    // Size: 0x000010 (0x000008)
    struct alignas(0x4) FSoundSelectorOwnerTag : public FAudioMutatorSelector
    {
        FGameplayTag    Tag;                            // 0x000008 (0x000004)
        bool            bExactMatch;                    // 0x00000C (0x000001)
        uint8           UnknownData_00000D[0x000003];   // 0x00000D (0x000003)
    };
    // Size: 0x000010 (0x000008)
    struct alignas(0x8) FSoundSelectorPreset : public FAudioMutatorSelector
    {
        USoundSelectorPresetAsset*  Preset; // 0x000008 (0x000008)
    };
    // Size: 0x000018 (0x000010)
    struct alignas(0x8) FSoundSelectorSoundBaseSubclass : public FAudioMutatorSelector
    {
        UClass* SoundBaseSubclass;              // 0x000008 (0x000008)
        bool    bExactClass;                    // 0x000010 (0x000001)
        uint8   UnknownData_000011[0x000007];   // 0x000011 (0x000007)
    };
    // Size: 0x000018 (0x000010)
    struct alignas(0x8) FSoundSelectorSoundClass : public FAudioMutatorSelector
    {
        USoundClass*    SoundClass;                     // 0x000008 (0x000008)
        bool            bExactClass;                    // 0x000010 (0x000001)
        uint8           UnknownData_000011[0x000007];   // 0x000011 (0x000007)
    };
    // Size: 0x000010 (0x000008)
    struct alignas(0x4) FSoundSelectorTag : public FAudioMutatorSelector
    {
        FGameplayTag    Tag;                            // 0x000008 (0x000004)
        bool            bExactMatch;                    // 0x00000C (0x000001)
        uint8           UnknownData_00000D[0x000003];   // 0x00000D (0x000003)
    };
    // Size: 0x000018 (0x000010)
    struct alignas(0x8) FStatefulActionModulator : public FAudioMutatorStatefulSoundAction
    {
        USoundModulatorBase*    Modulator;                      // 0x000008 (0x000008)
        EModulationDestination  Destination;                    // 0x000010 (0x000001)
        uint8                   UnknownData_000011[0x000007];   // 0x000011 (0x000007)
    };
    // Size: 0x000010 (0x000008)
    struct alignas(0x4) FStatefulActionPitch : public FAudioMutatorParseParamAction
    {
        float   PitchMultiplier;                // 0x000008 (0x000004)
        uint8   UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
    };
    // Size: 0x000010 (0x000008)
    struct alignas(0x8) FStatefulActionSourceEffect : public FAudioMutatorStatefulSoundAction
    {
        USoundEffectSourcePresetChain*  PresetChain;    // 0x000008 (0x000008)
    };
    // Size: 0x000010 (0x000008)
    struct alignas(0x4) FStatefulActionVolume : public FAudioMutatorParseParamAction
    {
        float   VolumeMultiplier;               // 0x000008 (0x000004)
        uint8   UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
    };
}

