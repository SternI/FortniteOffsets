/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioWidgets
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000380 (0x000000)
    class UAudioFrequencyRadialSlider : public UAudioRadialSlider
    {
    public:
    };
    // Size: 0x0008C0 (0x000010)
    class alignas(0x8) UAudioFrequencySlider : public UAudioSliderBase
    {
    public:
        FVector2D   OutputRange;    // 0x0008B0 (0x000010)
    };
    // Size: 0x000238 (0x0000D0)
    class alignas(0x8) UAudioMaterialButton : public UWidget
    {
    public:
        FAudioMaterialButtonStyle                               WidgetStyle;                    // 0x000168 (0x000088)
        MULTI_INLINE_DELEGATE(OnButtonPressedChangedEvent)      OnButtonPressedChangedEvent;    // 0x0001F0 (0x000010)
        MULTI_INLINE_DELEGATE(OnButtonMouseCaptureBeginEvent)   OnMouseCaptureBegin;            // 0x000200 (0x000010)
        MULTI_INLINE_DELEGATE(OnButtonMouseCaptureEndEvent)     OnMouseCaptureEnd;              // 0x000210 (0x000010)
        bool                                                    bIsPressed;                     // 0x000220 (0x000001) [Default: false]
        uint8                                                   UnknownData_000221[0x000017];   // 0x000221 (0x000017)
    
    public: // Functions
        bool    GetIsPressed(); // 0x10D654C4 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    SetIsPressed(bool InPressed); // 0x080078F8 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x0000B8 (0x000088)
    class alignas(0x8) UAudioMaterialButtonWidgetStyle : public USlateWidgetStyleContainerBase
    {
    public:
        FAudioMaterialButtonStyle   ButtonStyle;    // 0x000030 (0x000088)
    };
    // Size: 0x0001E8 (0x000080)
    class alignas(0x8) UAudioMaterialEnvelope : public UWidget
    {
    public:
        FAudioMaterialEnvelopeStyle     WidgetStyle;                    // 0x000168 (0x000048)
        FAudioMaterialEnvelopeSettings  EnvelopeSettings;               // 0x0001B0 (0x000024)
        uint8                           UnknownData_0001D4[0x000014];   // 0x0001D4 (0x000014)
    };
    // Size: 0x000390 (0x000228)
    class alignas(0x8) UAudioMaterialKnob : public UWidget
    {
    public:
        uint8                                               UnknownData_000168[0x000008];   // 0x000168 (0x000008)
        FAudioMaterialKnobStyle                             WidgetStyle;                    // 0x000170 (0x0001C0)
        MULTI_INLINE_DELEGATE(OnKnobValueChangedEvent)      OnKnobValueChanged;             // 0x000330 (0x000010)
        MULTI_INLINE_DELEGATE(OnKnobMouseCaptureBeginEvent) OnMouseCaptureBegin;            // 0x000340 (0x000010)
        MULTI_INLINE_DELEGATE(OnKnobMouseCaptureEndEvent)   OnMouseCaptureEnd;              // 0x000350 (0x000010)
        float                                               Value;                          // 0x000360 (0x000004) [Default: 1f]
        float                                               TuneSpeed;                      // 0x000364 (0x000004) [Default: 0.2f]
        float                                               FineTuneSpeed;                  // 0x000368 (0x000004) [Default: 0.05f]
        bool                                                bLocked;                        // 0x00036C (0x000001) [Default: false]
        bool                                                bMouseUsesStep;                 // 0x00036D (0x000001) [Default: false]
        uint8                                               UnknownData_00036E[0x000002];   // 0x00036E (0x000002)
        float                                               StepSize;                       // 0x000370 (0x000004) [Default: 0.01f]
        uint8                                               UnknownData_000374[0x00001C];   // 0x000374 (0x00001C)
    
    public: // Functions
        float   GetFineTuneSpeed(); // 0x10D65F0A [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool    GetIsLocked(); // 0x10D65F28 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool    GetMouseUsesStep(); // 0x10D65F42 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float   GetStepSize(); // 0x0F4113B8 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float   GetTuneSpeed(); // 0x10D65F5C [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float   GetValue(); // 0x10D65F7A [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure]
        void    SetFineTuneSpeed(float InValue); // 0x08007A92 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetLocked(bool InLocked); // 0x08007C74 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetMouseUsesStep(bool InUsesStep); // 0x08007E3E [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetStepSize(float InValue); // 0x08008008 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetTuneSpeed(float InValue); // 0x080081DA [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetValue(float InValue); // 0x080083BC [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x0001F0 (0x0001C0)
    class alignas(0x8) UAudioMaterialKnobWidgetStyle : public USlateWidgetStyleContainerBase
    {
    public:
        FAudioMaterialKnobStyle KnobStyle;  // 0x000030 (0x0001C0)
    };
    // Size: 0x000280 (0x000118)
    class alignas(0x8) UAudioMaterialMeter : public UWidget
    {
    public:
        FAudioMaterialMeterStyle    WidgetStyle;                    // 0x000168 (0x0000E8)
        TEnumAsByte<EOrientation>   orientation;                    // 0x000250 (0x000001) [Default: 1]
        uint8                       UnknownData_000251[0x000003];   // 0x000251 (0x000003)
        GetMeterChannelInfo         MeterChannelInfoDelegate;       // 0x000254 (0x00000C)
        uint8                       UnknownData_000260[0x000010];   // 0x000260 (0x000010)
        TArray<FMeterChannelInfo>   MeterChannelInfo;               // 0x000270 (0x000010)
    
    public: // Functions
        TArray<FMeterChannelInfo>   GetMeterChannelInfo(); // 0x10D66A34 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                        SetMeterChannelInfo(TArray<FMeterChannelInfo>& InMeterChannelInfo); // 0x0800852A [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        TArray<FMeterChannelInfo>   GetMeterChannelInfo(); // 0x000545D2 [Public | Delegate]
    };
    // Size: 0x000118 (0x0000E8)
    class alignas(0x8) UAudioMaterialMeterWidgetStyle : public USlateWidgetStyleContainerBase
    {
    public:
        FAudioMaterialMeterStyle    MeterStyle; // 0x000030 (0x0000E8)
    };
    // Size: 0x000320 (0x0001B8)
    class alignas(0x8) UAudioMaterialSlider : public UWidget
    {
    public:
        uint8                                                   UnknownData_000168[0x000008];   // 0x000168 (0x000008)
        FAudioMaterialSliderStyle                               WidgetStyle;                    // 0x000170 (0x000150)
        MULTI_INLINE_DELEGATE(OnSliderFloatValueChangedEvent)   OnValueChanged;                 // 0x0002C0 (0x000010)
        MULTI_INLINE_DELEGATE(OnSliderMouseCaptureBeginEvent)   OnMouseCaptureBegin;            // 0x0002D0 (0x000010)
        MULTI_INLINE_DELEGATE(OnSliderMouseCaptureEndEvent)     OnMouseCaptureEnd;              // 0x0002E0 (0x000010)
        float                                                   Value;                          // 0x0002F0 (0x000004) [Default: 1f]
        TEnumAsByte<EOrientation>                               orientation;                    // 0x0002F4 (0x000001) [Default: 0]
        uint8                                                   UnknownData_0002F5[0x000003];   // 0x0002F5 (0x000003)
        float                                                   TuneSpeed;                      // 0x0002F8 (0x000004) [Default: 0.2f]
        float                                                   FineTuneSpeed;                  // 0x0002FC (0x000004) [Default: 0.05f]
        bool                                                    bLocked;                        // 0x000300 (0x000001) [Default: false]
        bool                                                    bMouseUsesStep;                 // 0x000301 (0x000001) [Default: false]
        uint8                                                   UnknownData_000302[0x000002];   // 0x000302 (0x000002)
        float                                                   StepSize;                       // 0x000304 (0x000004) [Default: 0.01f]
        uint8                                                   UnknownData_000308[0x000018];   // 0x000308 (0x000018)
    
    public: // Functions
        float   GetFineTuneSpeed(); // 0x10D67B3A [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool    GetIsLocked(); // 0x10D67B58 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool    GetMouseUsesStep(); // 0x10D67B72 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float   GetStepSize(); // 0x10D67B8C [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float   GetTuneSpeed(); // 0x10D67BAA [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        float   GetValue(); // 0x10D67BC8 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void    SetFineTuneSpeed(float InValue); // 0x080086B6 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetLocked(bool bInLocked); // 0x08008898 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetMouseUsesStep(bool bInUsesStep); // 0x08008A62 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetStepSize(float InValue); // 0x08008C2C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetTuneSpeed(float InValue); // 0x08008DFE [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetValue(float InValue); // 0x08008FE0 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000180 (0x000150)
    class alignas(0x8) UAudioMaterialSliderWidgetStyle : public USlateWidgetStyleContainerBase
    {
    public:
        FAudioMaterialSliderStyle   SliderStyle;    // 0x000030 (0x000150)
    };
    // Size: 0x000700 (0x000598)
    class alignas(0x8) UAudioMeter : public UWidget
    {
    public:
        TArray<FMeterChannelInfo>   MeterChannelInfo;               // 0x000168 (0x000010)
        GetMeterChannelInfo         MeterChannelInfoDelegate;       // 0x000178 (0x00000C)
        uint8                       UnknownData_000184[0x00000C];   // 0x000184 (0x00000C)
        FAudioMeterStyle            WidgetStyle;                    // 0x000190 (0x0004E0)
        TEnumAsByte<EOrientation>   orientation;                    // 0x000670 (0x000001) [Default: 1]
        uint8                       UnknownData_000671[0x000003];   // 0x000671 (0x000003)
        FLinearColor                BackgroundColor;                // 0x000674 (0x000010)
        FLinearColor                MeterBackgroundColor;           // 0x000684 (0x000010)
        FLinearColor                MeterValueColor;                // 0x000694 (0x000010)
        FLinearColor                MeterPeakColor;                 // 0x0006A4 (0x000010)
        FLinearColor                MeterClippingColor;             // 0x0006B4 (0x000010)
        FLinearColor                MeterScaleColor;                // 0x0006C4 (0x000010)
        FLinearColor                MeterScaleLabelColor;           // 0x0006D4 (0x000010)
        uint8                       UnknownData_0006E4[0x00001C];   // 0x0006E4 (0x00001C)
    
    public: // Functions
        TArray<FMeterChannelInfo>   GetMeterChannelInfo(); // 0x10D6D374 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                        SetBackgroundColor(FLinearColor InValue); // 0x0800A2E0 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void                        SetMeterBackgroundColor(FLinearColor InValue); // 0x0800A472 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void                        SetMeterChannelInfo(TArray<FMeterChannelInfo>& InMeterChannelInfo); // 0x0800A604 [Final | RequiredAPI | Native | Public | HasOutParms | BlueprintCallable]
        void                        SetMeterClippingColor(FLinearColor InValue); // 0x0800A790 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void                        SetMeterPeakColor(FLinearColor InValue); // 0x0800A922 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void                        SetMeterScaleColor(FLinearColor InValue); // 0x0800AAB4 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void                        SetMeterScaleLabelColor(FLinearColor InValue); // 0x0800AC46 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void                        SetMeterValueColor(FLinearColor InValue); // 0x0800ADD8 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        TArray<FMeterChannelInfo>   GetMeterChannelInfo(); // 0x000545D2 [Public | Delegate]
    };
    // Size: 0x000630 (0x0004C8)
    class alignas(0x8) UAudioOscilloscope : public UWidget
    {
    public:
        uint8                           UnknownData_000168[0x000008];   // 0x000168 (0x000008)
        FAudioOscilloscopePanelStyle    OscilloscopeStyle;              // 0x000170 (0x000440)
        UAudioBus*                      AudioBus;                       // 0x0005B0 (0x000008) [Default: nullptr]
        float                           MaxTimeWindowMs;                // 0x0005B8 (0x000004) [Default: 5000f]
        float                           TimeWindowMs;                   // 0x0005BC (0x000004) [Default: 10f]
        float                           AnalysisPeriodMs;               // 0x0005C0 (0x000004) [Default: 10f]
        bool                            bShowTimeGrid;                  // 0x0005C4 (0x000001) [Default: true]
        EXAxisLabelsUnit                TimeGridLabelsUnit;             // 0x0005C5 (0x000001) [Default: EXAxisLabelsUnit(0)]
        bool                            bShowAmplitudeGrid;             // 0x0005C6 (0x000001) [Default: true]
        bool                            bShowAmplitudeLabels;           // 0x0005C7 (0x000001) [Default: true]
        EYAxisLabelsUnit                AmplitudeGridLabelsUnit;        // 0x0005C8 (0x000001) [Default: EYAxisLabelsUnit(0)]
        EAudioOscilloscopeTriggerMode   TriggerMode;                    // 0x0005C9 (0x000001) [Default: EAudioOscilloscopeTriggerMode(0)]
        uint8                           UnknownData_0005CA[0x000002];   // 0x0005CA (0x000002)
        float                           TriggerThreshold;               // 0x0005CC (0x000004) [Default: 0f]
        EAudioPanelLayoutType           PanelLayoutType;                // 0x0005D0 (0x000001) [Default: EAudioPanelLayoutType(0)]
        uint8                           UnknownData_0005D1[0x000003];   // 0x0005D1 (0x000003)
        int32                           ChannelToAnalyze;               // 0x0005D4 (0x000004) [Default: 1]
        uint8                           UnknownData_0005D8[0x000058];   // 0x0005D8 (0x000058)
    
    public: // Functions
        bool            CanTriggeringBeSet(); // 0x10D6FEA8 [Final | Native | Private]
        void            StartProcessing(); // 0x10D6FEDA [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void            StopProcessing(); // 0x10D6FEFC [Final | RequiredAPI | Native | Public | BlueprintCallable]
        TArray<float>   GetOscilloscopeAudioSamples(); // 0x000545D2 [Public | Delegate]
    };
    // Size: 0x000380 (0x000218)
    class alignas(0x8) UAudioRadialSlider : public UWidget
    {
    public:
        float                                                               Value;                          // 0x000168 (0x000004) [Default: 0f]
        GetFloat                                                            ValueDelegate;                  // 0x00016C (0x00000C)
        TEnumAsByte<EAudioRadialSliderLayout>                               WidgetLayout;                   // 0x000178 (0x000001) [Default: 2]
        uint8                                                               UnknownData_000179[0x000003];   // 0x000179 (0x000003)
        FLinearColor                                                        CenterBackgroundColor;          // 0x00017C (0x000010)
        FLinearColor                                                        SliderProgressColor;            // 0x00018C (0x000010)
        FLinearColor                                                        SliderBarColor;                 // 0x00019C (0x000010)
        uint8                                                               UnknownData_0001AC[0x000004];   // 0x0001AC (0x000004)
        FVector2D                                                           HandStartEndRatio;              // 0x0001B0 (0x000010)
        FText                                                               UnitsText;                      // 0x0001C0 (0x000010)
        FLinearColor                                                        TextLabelBackgroundColor;       // 0x0001D0 (0x000010)
        bool                                                                ShowLabelOnlyOnHover;           // 0x0001E0 (0x000001) [Default: false]
        bool                                                                ShowUnitsText;                  // 0x0001E1 (0x000001) [Default: true]
        bool                                                                IsUnitsTextReadOnly;            // 0x0001E2 (0x000001) [Default: true]
        bool                                                                IsValueTextReadOnly;            // 0x0001E3 (0x000001) [Default: false]
        float                                                               SliderThickness;                // 0x0001E4 (0x000004) [Default: 5f]
        FVector2D                                                           OutputRange;                    // 0x0001E8 (0x000010)
        MULTI_INLINE_DELEGATE(OnAudioRadialSliderValueChangedEvent)         OnValueChanged;                 // 0x0001F8 (0x000010)
        MULTI_INLINE_DELEGATE(OnAudioRadialSliderMouseCaptureBeginEvent)    OnMouseCaptureBegin;            // 0x000208 (0x000010)
        MULTI_INLINE_DELEGATE(OnAudioRadialSliderMouseCaptureEndEvent)      OnMouseCaptureEnd;              // 0x000218 (0x000010)
        uint8                                                               UnknownData_000228[0x000008];   // 0x000228 (0x000008)
        void**                                                              VTable_000230;                  // 0x000230 (0x000008) VTable [3 slots] -> 0x1471CAC0
        uint8                                                               UnknownData_000238[0x000008];   // 0x000238 (0x000008)
        void**                                                              VTable_000240;                  // 0x000240 (0x000008) VTable [3 slots] -> 0x1471CA80
        uint8                                                               UnknownData_000248[0x000008];   // 0x000248 (0x000008)
        void**                                                              VTable_000250;                  // 0x000250 (0x000008) VTable [1 slots] -> 0x12E10A60
        uint8                                                               UnknownData_000258[0x000128];   // 0x000258 (0x000128)
    
    public: // Functions
        float   GetOutputValue(float InSliderValue); // 0x0800AF6A [Final | RequiredAPI | Native | Public | BlueprintCallable]
        float   GetSliderValue(float OutputValue); // 0x0800B0EC [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetCenterBackgroundColor(FLinearColor InValue); // 0x0800B26E [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void    SetHandStartEndRatio(FVector2D InHandStartEndRatio); // 0x0800B3FA [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void    SetOutputRange(FVector2D InOutputRange); // 0x0800B582 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void    SetShowLabelOnlyOnHover(bool bShowLabelOnlyOnHover); // 0x0800B70C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetShowUnitsText(bool bShowUnitsText); // 0x0800B89C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetSliderBarColor(FLinearColor InValue); // 0x0800BA26 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void    SetSliderProgressColor(FLinearColor InValue); // 0x0800BBB2 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void    SetSliderThickness(float InThickness); // 0x0800BD3E [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetTextLabelBackgroundColor(FSlateColor InColor); // 0x0800BED0 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetUnitsText(FText Units); // 0x0800C056 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetUnitsTextReadOnly(bool bIsReadOnly); // 0x0800C2A8 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetValueTextReadOnly(bool bIsReadOnly); // 0x0800C432 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetWidgetLayout(TEnumAsByte<EAudioRadialSliderLayout> InLayout); // 0x0800C5D6 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x0008C0 (0x000010)
    class alignas(0x8) UAudioSlider : public UAudioSliderBase
    {
    public:
        TWeakObjectPtr<UCurveFloat> LinToOutputCurve;   // 0x0008B0 (0x000008) [Default: nullptr]
        TWeakObjectPtr<UCurveFloat> OutputToLinCurve;   // 0x0008B8 (0x000008) [Default: nullptr]
    };
    // Size: 0x0008B0 (0x000748)
    class alignas(0x8) UAudioSliderBase : public UWidget
    {
    public:
        float                                           Value;                              // 0x000168 (0x000004) [Default: 0f]
        uint8                                           UnknownData_00016C[0x000004];       // 0x00016C (0x000004)
        FText                                           UnitsText;                          // 0x000170 (0x000010)
        FLinearColor                                    TextLabelBackgroundColor;           // 0x000180 (0x000010)
        GetLinearColor                                  TextLabelBackgroundColorDelegate;   // 0x000190 (0x00000C)
        bool                                            ShowLabelOnlyOnHover;               // 0x00019C (0x000001) [Default: false]
        bool                                            ShowUnitsText;                      // 0x00019D (0x000001) [Default: true]
        bool                                            IsUnitsTextReadOnly;                // 0x00019E (0x000001) [Default: true]
        bool                                            IsValueTextReadOnly;                // 0x00019F (0x000001) [Default: false]
        GetFloat                                        ValueDelegate;                      // 0x0001A0 (0x00000C)
        FLinearColor                                    SliderBackgroundColor;              // 0x0001AC (0x000010)
        GetLinearColor                                  SliderBackgroundColorDelegate;      // 0x0001BC (0x00000C)
        FLinearColor                                    SliderBarColor;                     // 0x0001C8 (0x000010)
        GetLinearColor                                  SliderBarColorDelegate;             // 0x0001D8 (0x00000C)
        FLinearColor                                    SliderThumbColor;                   // 0x0001E4 (0x000010)
        GetLinearColor                                  SliderThumbColorDelegate;           // 0x0001F4 (0x00000C)
        FLinearColor                                    WidgetBackgroundColor;              // 0x000200 (0x000010)
        GetLinearColor                                  WidgetBackgroundColorDelegate;      // 0x000210 (0x00000C)
        TEnumAsByte<EOrientation>                       orientation;                        // 0x00021C (0x000001) [Default: 1]
        uint8                                           UnknownData_00021D[0x000003];       // 0x00021D (0x000003)
        MULTI_INLINE_DELEGATE(OnFloatValueChangedEvent) OnValueChanged;                     // 0x000220 (0x000010)
        MULTI_INLINE_DELEGATE(OnMouseCaptureBeginEvent) OnMouseCaptureBegin;                // 0x000230 (0x000010)
        MULTI_INLINE_DELEGATE(OnMouseCaptureEndEvent)   OnMouseCaptureEnd;                  // 0x000240 (0x000010)
        void**                                          VTable_000250;                      // 0x000250 (0x000008) VTable [3 slots] -> 0x1471CAA0
        uint8                                           UnknownData_000258[0x000008];       // 0x000258 (0x000008)
        void**                                          VTable_000260;                      // 0x000260 (0x000008) VTable [3 slots] -> 0x12E16650
        uint8                                           UnknownData_000268[0x000008];       // 0x000268 (0x000008)
        void**                                          VTable_000270;                      // 0x000270 (0x000008) VTable [1 slots] -> 0x12E10A60
        uint8                                           UnknownData_000278[0x0000A8];       // 0x000278 (0x0000A8)
        void**                                          VTable_000320;                      // 0x000320 (0x000008) VTable [1 slots] -> 0x12E10A60
        uint8                                           UnknownData_000328[0x0000A8];       // 0x000328 (0x0000A8)
        void**                                          VTable_0003D0;                      // 0x0003D0 (0x000008) VTable [1 slots] -> 0x12E10A60
        uint8                                           UnknownData_0003D8[0x0000A8];       // 0x0003D8 (0x0000A8)
        void**                                          VTable_000480;                      // 0x000480 (0x000008) VTable [1 slots] -> 0x12E10A60
        uint8                                           UnknownData_000488[0x0000A8];       // 0x000488 (0x0000A8)
        void**                                          VTable_000530;                      // 0x000530 (0x000008) VTable [1 slots] -> 0x12E10A60
        uint8                                           UnknownData_000538[0x0000A8];       // 0x000538 (0x0000A8)
        void**                                          VTable_0005E0;                      // 0x0005E0 (0x000008) VTable [1 slots] -> 0x12E10A60
        uint8                                           UnknownData_0005E8[0x0000B8];       // 0x0005E8 (0x0000B8)
        void**                                          VTable_0006A0;                      // 0x0006A0 (0x000008) VTable [3 slots] -> 0x1471CA80
        uint8                                           UnknownData_0006A8[0x000008];       // 0x0006A8 (0x000008)
        void**                                          VTable_0006B0;                      // 0x0006B0 (0x000008) VTable [1 slots] -> 0x12E10A60
        uint8                                           UnknownData_0006B8[0x0000C8];       // 0x0006B8 (0x0000C8)
        void**                                          VTable_000780;                      // 0x000780 (0x000008) VTable [1 slots] -> 0x12E10A60
        uint8                                           UnknownData_000788[0x000128];       // 0x000788 (0x000128)
    
    public: // Functions
        float   GetLinValue(float OutputValue); // 0x0800C754 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        float   GetOutputValue(float InSliderValue); // 0x0800C8D6 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        float   GetSliderValue(float OutputValue); // 0x0800C754 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetShowLabelOnlyOnHover(bool bShowLabelOnlyOnHover); // 0x0800CA58 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetShowUnitsText(bool bShowUnitsText); // 0x0800CBE8 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetSliderBackgroundColor(FLinearColor InValue); // 0x0800CD72 [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void    SetSliderBarColor(FLinearColor InValue); // 0x0800CEFE [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void    SetSliderThumbColor(FLinearColor InValue); // 0x0800D08A [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
        void    SetTextLabelBackgroundColor(FSlateColor InColor); // 0x0800D216 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetUnitsText(FText Units); // 0x0800D39C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetUnitsTextReadOnly(bool bIsReadOnly); // 0x0800D5EE [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetValueTextReadOnly(bool bIsReadOnly); // 0x0800D778 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void    SetWidgetBackgroundColor(FLinearColor InValue); // 0x0800D91C [Final | RequiredAPI | Native | Public | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000370 (0x000208)
    class alignas(0x8) UAudioVectorscope : public UWidget
    {
    public:
        uint8                       UnknownData_000168[0x000008];   // 0x000168 (0x000008)
        FAudioVectorscopePanelStyle VectorscopeStyle;               // 0x000170 (0x000190)
        UAudioBus*                  AudioBus;                       // 0x000300 (0x000008) [Default: nullptr]
        bool                        bShowGrid;                      // 0x000308 (0x000001) [Default: true]
        uint8                       UnknownData_000309[0x000003];   // 0x000309 (0x000003)
        int32                       GridDivisions;                  // 0x00030C (0x000004) [Default: 2]
        float                       MaxDisplayPersistenceMs;        // 0x000310 (0x000004) [Default: 500f]
        float                       DisplayPersistenceMs;           // 0x000314 (0x000004) [Default: 60f]
        float                       Scale;                          // 0x000318 (0x000004) [Default: 1f]
        EAudioPanelLayoutType       PanelLayoutType;                // 0x00031C (0x000001) [Default: EAudioPanelLayoutType(0)]
        uint8                       UnknownData_00031D[0x000053];   // 0x00031D (0x000053)
    
    public: // Functions
        void            StartProcessing(); // 0x10D7D9D2 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void            StopProcessing(); // 0x10D7D9F4 [Final | RequiredAPI | Native | Public | BlueprintCallable]
        TArray<float>   GetVectorscopeAudioSamples(); // 0x000545D2 [Public | Delegate]
    };
    // Size: 0x000380 (0x000000)
    class UAudioVolumeRadialSlider : public UAudioRadialSlider
    {
    public:
    };
    // Size: 0x0008C0 (0x000000)
    class UAudioVolumeSlider : public UAudioSlider
    {
    public:
    };
    // Size: 0x000088 (0x000070)
    struct alignas(0x8) FAudioMaterialButtonStyle : public FAudioMaterialWidgetStyle
    {
        FLinearColor    ButtonMainColor;                // 0x000018 (0x000010)
        FLinearColor    ButtonMainColorTint_1;          // 0x000028 (0x000010)
        FLinearColor    ButtonMainColorTint_2;          // 0x000038 (0x000010)
        FLinearColor    ButtonAccentColor;              // 0x000048 (0x000010)
        FLinearColor    ButtonShadowColor;              // 0x000058 (0x000010)
        FLinearColor    ButtonUnpressedOutlineColor;    // 0x000068 (0x000010)
        FLinearColor    ButtonPressedOutlineColor;      // 0x000078 (0x000010)
    };
    // Size: 0x000024 (0x000024)
    struct alignas(0x4) FAudioMaterialEnvelopeSettings
    {
        EAudioMaterialEnvelopeType  EnvelopeType;                   // 0x000000 (0x000001)
        uint8                       UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        float                       AttackCurve;                    // 0x000004 (0x000004)
        float                       AttackValue;                    // 0x000008 (0x000004)
        float                       AttackTime;                     // 0x00000C (0x000004)
        float                       DecayCurve;                     // 0x000010 (0x000004)
        float                       DecayTime;                      // 0x000014 (0x000004)
        float                       SustainValue;                   // 0x000018 (0x000004)
        float                       ReleaseCurve;                   // 0x00001C (0x000004)
        float                       ReleaseTime;                    // 0x000020 (0x000004)
    };
    // Size: 0x000048 (0x000030)
    struct alignas(0x8) FAudioMaterialEnvelopeStyle : public FAudioMaterialWidgetStyle
    {
        FLinearColor    CurveColor;         // 0x000018 (0x000010)
        FLinearColor    BackgroundColor;    // 0x000028 (0x000010)
        FLinearColor    OutlineColor;       // 0x000038 (0x000010)
    };
    // Size: 0x0001C0 (0x0001A8)
    struct alignas(0x8) FAudioMaterialKnobStyle : public FAudioMaterialWidgetStyle
    {
        FLinearColor        KnobMainColor;                  // 0x000018 (0x000010)
        FLinearColor        KnobAccentColor;                // 0x000028 (0x000010)
        FLinearColor        KnobShadowColor;                // 0x000038 (0x000010)
        FLinearColor        KnobSmoothBevelColor;           // 0x000048 (0x000010)
        FLinearColor        KnobIndicatorDotColor;          // 0x000058 (0x000010)
        FLinearColor        KnobEdgeFillColor;              // 0x000068 (0x000010)
        FLinearColor        KnobBarColor;                   // 0x000078 (0x000010)
        FLinearColor        KnobBarShadowColor;             // 0x000088 (0x000010)
        FLinearColor        KnobBarFillMinColor;            // 0x000098 (0x000010)
        FLinearColor        KnobBarFillMidColor;            // 0x0000A8 (0x000010)
        FLinearColor        KnobBarFillMaxColor;            // 0x0000B8 (0x000010)
        FLinearColor        KnobBarFillTintColor;           // 0x0000C8 (0x000010)
        uint8               UnknownData_0000D8[0x000008];   // 0x0000D8 (0x000008)
        FAudioTextBoxStyle  TextBoxStyle;                   // 0x0000E0 (0x0000E0)
    };
    // Size: 0x0000E8 (0x0000D0)
    struct alignas(0x8) FAudioMaterialMeterStyle : public FAudioMaterialWidgetStyle
    {
        FLinearColor    MeterFillMinColor;              // 0x000018 (0x000010)
        FLinearColor    MeterFillMidColor;              // 0x000028 (0x000010)
        FLinearColor    MeterFillMaxColor;              // 0x000038 (0x000010)
        FLinearColor    MeterFillBackgroundColor;       // 0x000048 (0x000010)
        FVector2D       MeterPadding;                   // 0x000058 (0x000010)
        FVector2D       ValueRangeDb;                   // 0x000068 (0x000010)
        bool            bShowScale;                     // 0x000078 (0x000001)
        bool            bScaleSide;                     // 0x000079 (0x000001)
        uint8           UnknownData_00007A[0x000002];   // 0x00007A (0x000002)
        float           ScaleHashOffset;                // 0x00007C (0x000004)
        float           ScaleHashWidth;                 // 0x000080 (0x000004)
        float           ScaleHashHeight;                // 0x000084 (0x000004)
        int32           DecibelsPerHash;                // 0x000088 (0x000004)
        uint8           UnknownData_00008C[0x000004];   // 0x00008C (0x000004)
        FSlateFontInfo  Font;                           // 0x000090 (0x000058)
    };
    // Size: 0x000150 (0x000138)
    struct alignas(0x8) FAudioMaterialSliderStyle : public FAudioMaterialWidgetStyle
    {
        FLinearColor        SliderBackgroundColor;          // 0x000018 (0x000010)
        FLinearColor        SliderBackgroundAccentColor;    // 0x000028 (0x000010)
        FLinearColor        SliderValueMainColor;           // 0x000038 (0x000010)
        FLinearColor        SliderHandleMainColor;          // 0x000048 (0x000010)
        FLinearColor        SliderHandleOutlineColor;       // 0x000058 (0x000010)
        uint8               UnknownData_000068[0x000008];   // 0x000068 (0x000008)
        FAudioTextBoxStyle  TextBoxStyle;                   // 0x000070 (0x0000E0)
    };
    // Size: 0x000018 (0x000010)
    struct alignas(0x8) FAudioMaterialWidgetStyle : public FSlateWidgetStyle
    {
        UMaterialInterface* Material;       // 0x000008 (0x000008)
        FVector2f           DesiredSize;    // 0x000010 (0x000008)
    };
    // Size: 0x000068 (0x000000)
    struct FAudioMeterDefaultColorStyle : public FAudioMeterDefaultColorWidgetStyle
    {
    };
    // Size: 0x0004E0 (0x000000)
    struct FAudioMeterStyle : public FAudioMeterWidgetStyle
    {
    };
    // Size: 0x000440 (0x000438)
    struct alignas(0x8) FAudioOscilloscopePanelStyle : public FSlateWidgetStyle
    {
        uint8                                   UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        FFixedSampleSequenceRulerStyle          TimeRulerStyle;                 // 0x000010 (0x000230)
        FSampledSequenceValueGridOverlayStyle   ValueGridStyle;                 // 0x000240 (0x000098)
        uint8                                   UnknownData_0002D8[0x000008];   // 0x0002D8 (0x000008)
        FSampledSequenceViewerStyle             WaveViewerStyle;                // 0x0002E0 (0x000140)
        FTriggerThresholdLineStyle              TriggerThresholdLineStyle;      // 0x000420 (0x000018)
        uint8                                   UnknownData_000438[0x000008];   // 0x000438 (0x000008)
    };
    // Size: 0x000140 (0x000138)
    struct alignas(0x8) FAudioRadialSliderStyle : public FSlateWidgetStyle
    {
        uint8               UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        FAudioTextBoxStyle  TextBoxStyle;                   // 0x000010 (0x0000E0)
        FSlateColor         CenterBackgroundColor;          // 0x0000F0 (0x000014)
        FSlateColor         SliderBarColor;                 // 0x000104 (0x000014)
        FSlateColor         SliderProgressColor;            // 0x000118 (0x000014)
        float               LabelPadding;                   // 0x00012C (0x000004)
        float               DefaultSliderRadius;            // 0x000130 (0x000004)
        uint8               UnknownData_000134[0x00000C];   // 0x000134 (0x00000C)
    };
    // Size: 0x000650 (0x000648)
    struct alignas(0x8) FAudioSliderStyle : public FSlateWidgetStyle
    {
        uint8               UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        FSliderStyle        SliderStyle;                    // 0x000010 (0x000440)
        FAudioTextBoxStyle  TextBoxStyle;                   // 0x000450 (0x0000E0)
        FSlateBrush         WidgetBackgroundImage;          // 0x000530 (0x0000B0)
        FSlateColor         SliderBackgroundColor;          // 0x0005E0 (0x000014)
        uint8               UnknownData_0005F4[0x000004];   // 0x0005F4 (0x000004)
        FVector2D           SliderBackgroundSize;           // 0x0005F8 (0x000010)
        float               LabelPadding;                   // 0x000608 (0x000004)
        FSlateColor         SliderBarColor;                 // 0x00060C (0x000014)
        FSlateColor         SliderThumbColor;               // 0x000620 (0x000014)
        FSlateColor         WidgetBackgroundColor;          // 0x000634 (0x000014)
        uint8               UnknownData_000648[0x000008];   // 0x000648 (0x000008)
    };
    // Size: 0x000120 (0x000118)
    struct alignas(0x8) FAudioSpectrumPlotStyle : public FSlateWidgetStyle
    {
        FSlateColor     BackgroundColor;                // 0x000008 (0x000014)
        FSlateColor     GridColor;                      // 0x00001C (0x000014)
        FSlateColor     AxisLabelColor;                 // 0x000030 (0x000014)
        uint8           UnknownData_000044[0x000004];   // 0x000044 (0x000004)
        FSlateFontInfo  AxisLabelFont;                  // 0x000048 (0x000058)
        FSlateColor     SpectrumColor;                  // 0x0000A0 (0x000014)
        FSlateColor     CrosshairColor;                 // 0x0000B4 (0x000014)
        FSlateFontInfo  CrosshairLabelFont;             // 0x0000C8 (0x000058)
    };
    // Size: 0x0000E0 (0x0000D8)
    struct alignas(0x8) FAudioTextBoxStyle : public FSlateWidgetStyle
    {
        uint8       UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        FSlateBrush BackgroundImage;                // 0x000010 (0x0000B0)
        FSlateColor BackgroundColor;                // 0x0000C0 (0x000014)
        uint8       UnknownData_0000D4[0x00000C];   // 0x0000D4 (0x00000C)
    };
    // Size: 0x000190 (0x000188)
    struct alignas(0x8) FAudioVectorscopePanelStyle : public FSlateWidgetStyle
    {
        FSampledSequenceValueGridOverlayStyle   ValueGridStyle;     // 0x000008 (0x000098)
        FSampledSequenceVectorViewerStyle       VectorViewerStyle;  // 0x0000A0 (0x0000F0)
    };
    // Size: 0x000230 (0x000228)
    struct alignas(0x8) FFixedSampleSequenceRulerStyle : public FSlateWidgetStyle
    {
        float           HandleWidth;                    // 0x000008 (0x000004)
        FSlateColor     HandleColor;                    // 0x00000C (0x000014)
        FSlateBrush     HandleBrush;                    // 0x000020 (0x0000B0)
        FSlateColor     TicksColor;                     // 0x0000D0 (0x000014)
        FSlateColor     TicksTextColor;                 // 0x0000E4 (0x000014)
        FSlateFontInfo  TicksTextFont;                  // 0x0000F8 (0x000058)
        float           TicksTextOffset;                // 0x000150 (0x000004)
        FSlateColor     BackgroundColor;                // 0x000154 (0x000014)
        uint8           UnknownData_000168[0x000008];   // 0x000168 (0x000008)
        FSlateBrush     BackgroundBrush;                // 0x000170 (0x0000B0)
        float           DesiredWidth;                   // 0x000220 (0x000004)
        float           DesiredHeight;                  // 0x000224 (0x000004)
        uint8           UnknownData_000228[0x000008];   // 0x000228 (0x000008)
    };
    // Size: 0x0000A0 (0x000000)
    struct FLoudnessMeterRackUnitSettings : public FLoudnessMeterSettings
    {
    };
    // Size: 0x000014 (0x000000)
    struct FLoudnessMetricDisplayOptions : public FLoudnessMeterDisplayOptions
    {
    };
    // Size: 0x000014 (0x000000)
    struct FMeterChannelInfo : public FAudioMeterChannelInfo
    {
    };
    // Size: 0x000028 (0x000020)
    struct alignas(0x8) FPlayheadOverlayStyle : public FSlateWidgetStyle
    {
        FSlateColor PlayheadColor;  // 0x000008 (0x000014)
        float       PlayheadWidth;  // 0x00001C (0x000004)
        float       DesiredWidth;   // 0x000020 (0x000004)
        float       DesiredHeight;  // 0x000024 (0x000004)
    };
    // Size: 0x000098 (0x000090)
    struct alignas(0x8) FSampledSequenceValueGridOverlayStyle : public FSlateWidgetStyle
    {
        FSlateColor     GridColor;                      // 0x000008 (0x000014)
        float           GridThickness;                  // 0x00001C (0x000004) [Default: 0f]
        FSlateColor     LabelTextColor;                 // 0x000020 (0x000014)
        uint8           UnknownData_000034[0x000004];   // 0x000034 (0x000004)
        FSlateFontInfo  LabelTextFont;                  // 0x000038 (0x000058)
        float           DesiredWidth;                   // 0x000090 (0x000004) [Default: 1.36163e-36f]
        float           DesiredHeight;                  // 0x000094 (0x000004) [Default: 0f]
    };
    // Size: 0x0000F0 (0x0000E8)
    struct alignas(0x8) FSampledSequenceVectorViewerStyle : public FSlateWidgetStyle
    {
        FSlateColor     BackgroundColor;                // 0x000008 (0x000014)
        uint8           UnknownData_00001C[0x000004];   // 0x00001C (0x000004)
        FSlateBrush     BackgroundBrush;                // 0x000020 (0x0000B0)
        FLinearColor    LineColor;                      // 0x0000D0 (0x000010)
        float           LineThickness;                  // 0x0000E0 (0x000004)
        uint8           UnknownData_0000E4[0x00000C];   // 0x0000E4 (0x00000C)
    };
    // Size: 0x000140 (0x000138)
    struct alignas(0x8) FSampledSequenceViewerStyle : public FSlateWidgetStyle
    {
        FSlateColor SequenceColor;                  // 0x000008 (0x000014)
        float       SequenceLineThickness;          // 0x00001C (0x000004)
        FSlateColor MajorGridLineColor;             // 0x000020 (0x000014)
        FSlateColor MinorGridLineColor;             // 0x000034 (0x000014)
        FSlateColor ZeroCrossingLineColor;          // 0x000048 (0x000014)
        float       ZeroCrossingLineThickness;      // 0x00005C (0x000004)
        float       SampleMarkersSize;              // 0x000060 (0x000004)
        FSlateColor SequenceBackgroundColor;        // 0x000064 (0x000014)
        uint8       UnknownData_000078[0x000008];   // 0x000078 (0x000008)
        FSlateBrush BackgroundBrush;                // 0x000080 (0x0000B0)
        float       DesiredWidth;                   // 0x000130 (0x000004)
        float       DesiredHeight;                  // 0x000134 (0x000004)
        uint8       UnknownData_000138[0x000008];   // 0x000138 (0x000008)
    };
    // Size: 0x000007 (0x000007)
    struct FSpectrogramRackUnitSettings
    {
        EAudioSpectrumAnalyzerType                      AnalyzerType;       // 0x000000 (0x000001) [Default: EAudioSpectrumAnalyzerType(0)]
        EFFTSize                                        FFTAnalyzerFFTSize; // 0x000001 (0x000001) [Default: EFFTSize(0)]
        EConstantQFFTSizeEnum                           CQTAnalyzerFFTSize; // 0x000002 (0x000001) [Default: EConstantQFFTSizeEnum(0)]
        EAudioSpectrogramFrequencyAxisPixelBucketMode   PixelPlotMode;      // 0x000003 (0x000001) [Default: EAudioSpectrogramFrequencyAxisPixelBucketMode(0)]
        EAudioSpectrogramFrequencyAxisScale             FrequencyScale;     // 0x000004 (0x000001) [Default: EAudioSpectrogramFrequencyAxisScale(0)]
        EAudioColorGradient                             ColorMap;           // 0x000005 (0x000001) [Default: EAudioColorGradient(0)]
        TEnumAsByte<EOrientation>                       orientation;        // 0x000006 (0x000001) [Default: 0]
    };
    // Size: 0x000009 (0x000009)
    struct FSpectrumAnalyzerRackUnitSettings
    {
        EAudioSpectrumAnalyzerBallistics                Ballistics;                     // 0x000000 (0x000001)
        EAudioSpectrumAnalyzerType                      AnalyzerType;                   // 0x000001 (0x000001)
        EFFTSize                                        FFTAnalyzerFFTSize;             // 0x000002 (0x000001)
        EConstantQFFTSizeEnum                           CQTAnalyzerFFTSize;             // 0x000003 (0x000001)
        EAudioSpectrumPlotTilt                          TiltSpectrum;                   // 0x000004 (0x000001)
        EAudioSpectrumPlotFrequencyAxisPixelBucketMode  PixelPlotMode;                  // 0x000005 (0x000001)
        EAudioSpectrumPlotFrequencyAxisScale            FrequencyScale;                 // 0x000006 (0x000001)
        bool                                            bDisplayFrequencyAxisLabels;    // 0x000007 (0x000001)
        bool                                            bDisplaySoundLevelAxisLabels;   // 0x000008 (0x000001)
    };
    // Size: 0x000018 (0x000010)
    struct alignas(0x8) FTriggerThresholdLineStyle : public FSlateWidgetStyle
    {
        FLinearColor    LineColor;  // 0x000008 (0x000010)
    };
}

