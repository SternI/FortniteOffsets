/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AuroraFortniteUI_Functions
 * ============================================================
 */

#include "AuroraFortniteUI.hpp"

namespace UE
{

    struct AAuroraFortniteUIDirector___OnOfferPurchaseConfirmed_Params
    {
        FInstancedStruct    Invoice;    // 0x000000 (0x000010) [OutParam]
    };

    struct AAuroraFortniteUIDirector___OnOfferSelected_Params
    {
        FGuid   OfferId;    // 0x000000 (0x000010) [OutParam]
    };

    struct UAuroraFortniteTransitionableWidget___UpdateIsTransitioning_Params
    {
        bool    bInIsTransitioning; // 0x000000 (0x000001) [Default: true]
    };

    struct UFortAuroraOfferVM___CreateAuroraOfferVM_Params
    {
        FInstancedStruct        OfferData;              // 0x000000 (0x000010) [OutParam]
        TMap<FString, int64>    OwnedProductQuantities; // 0x000010 (0x000010) [OutParam]
        AFortPlayerController*  InOwningPlayer;         // 0x000020 (0x000008) [Default: 0x91E18EBB]
        UFortAuroraOfferVM*     ReturnValue;            // 0x000028 (0x000008) [ReturnValue] [Default: 0x14909B10]
    };

    struct UFortAuroraOfferVM___GetDisplayType_Params
    {
        FText   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UFortAuroraOfferVM___GetLegalText_Params
    {
        FText   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UFortAuroraShopVM___BroadcastOnOfferSelected_Params
    {
        FGuid   OfferId;    // 0x000000 (0x000010) [OutParam]
    };

    struct UFortAuroraShopVM___GetLastErrorCode_Params
    {
        FText   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UFortAuroraShopVM___IsInTestMode_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UFortAuroraShopVM___IsMtxPurchaseFlowEnabled_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UFortAuroraShopVM___SetCatalogOffers_Params
    {
        FGuid                       InCatalogId;            // 0x000000 (0x000010) [OutParam]
        TArray<FInstancedStruct>    Offers;                 // 0x000010 (0x000010) [OutParam]
        FText                       Title;                  // 0x000020 (0x000010) [OutParam]
        TMap<FString, int64>        OwnedProductQuantities; // 0x000030 (0x000010) [OutParam]
    };

    struct UFortAuroraShopVM___SetInspectedOffer_Params
    {
        FInstancedStruct        Invoice;                // 0x000000 (0x000010) [OutParam]
        FInstancedStruct        offer;                  // 0x000010 (0x000010) [OutParam]
        TMap<FString, int64>    OwnedProductQuantities; // 0x000020 (0x000010) [OutParam]
    };

    struct UFortAuroraShopVM___SetInspectionState_Params
    {
        EFortAuroraOfferRequestState    State;  // 0x000000 (0x000001) [Default: EFortAuroraOfferRequestState(80)]
    };

    struct UFortAuroraShopVM___SetPurchaseState_Params
    {
        EFortAuroraOfferRequestState    State;  // 0x000000 (0x000001) [Default: EFortAuroraOfferRequestState(80)]
    };

    struct UFortAuroraShopVM___ShouldForceAllowTestPurchases_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UFortAuroraShopVM___UpdateLastErrorCode_Params
    {
        FString InErrorCode;    // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UFortAuroraShopVM___UpdateOwnedProductQuantities_Params
    {
        TMap<FString, int64>    OwnedProductQuantities; // 0x000000 (0x000010) [OutParam]
    };

} // namespace UE

