/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:36
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AuroraFortnite/_Verse/VNI/AuroraDeprecated_Functions
 * ============================================================
 */

#include "AuroraDeprecated.hpp"

namespace UE
{

    struct U_SolarisSignatureFunctionOuter___VerseFunction_0_Params
    {
        double          __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000008) [Default: 1.5736e-315]
        Uprice_vbucks*  RetVal;                         // 0x000008 (0x000008) [ReturnValue] [Default: 0x714C1CDD00280031]
    };

    struct U_Root____L_2fFortnite_2ecom_2fMarketplace_N_RGetPriceVBucks_L_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Rprice__vbucks_R_Params
    {
        Uprice_vbucks*  __verse_0xB2CDDD72_Argument;    // 0x000000 (0x000008) [Default: 0x12FBEC60]
        double          RetVal;                         // 0x000008 (0x000008) [ReturnValue] [Default: 8.72911e+232]
    };

} // namespace UE

