/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:36
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AuroraFortnite/_Verse/VNI/AuroraFortniteRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class U_Root : public UObject
    {
    public:
    
    public: // Functions
        void            _InitCDO(); // 0x000545D2 [FUNC_None]
        static double          _L_2fUnrealEngine_2ecom_2fMarketplace_N_RGetPriceVBucks_L_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Rprice__vbucks_R(Uprice_vbucks* __verse_0xB2CDDD72_Argument); // 0x10D9A12A [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
        static Uprice_vbucks*  _L_2fUnrealEngine_2ecom_2fMarketplace_N_RMakePriceVBucks_L_Nfloat_R(double __verse_0xB2CDDD72_Argument); // 0x10D9A11E [Final | Native | Static | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000030 (0x000008)
    class alignas(0x8) Uprice_vbucks : public Uprice_dimension
    {
    public:
        double  __verse_0x193A13B7_Amount;  // 0x000028 (0x000008) [Default: 0]
    
    public: // Functions
        void    _Block(); // 0x000545D2 [FUNC_None]
        void    _InitCDO(); // 0x000545D2 [FUNC_None]
        void    _InitInstance(); // 0x000545D2 [FUNC_None]
    };
}

