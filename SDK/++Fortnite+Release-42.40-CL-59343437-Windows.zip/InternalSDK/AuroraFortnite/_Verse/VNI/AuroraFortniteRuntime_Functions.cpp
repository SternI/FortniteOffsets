/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:36
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AuroraFortnite/_Verse/VNI/AuroraFortniteRuntime_Functions
 * ============================================================
 */

#include "AuroraFortniteRuntime_Functions.hpp"

namespace UE
{

    void U_Root::_InitCDO()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteRuntime._Root._InitCDO");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    double U_Root::_L_2fUnrealEngine_2ecom_2fMarketplace_N_RGetPriceVBucks_L_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Rprice__vbucks_R(Uprice_vbucks* __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteRuntime._Root._L_2fUnrealEngine_2ecom_2fMarketplace_N_RGetPriceVBucks_L_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Rprice__vbucks_R");
    
        U_Root____L_2fUnrealEngine_2ecom_2fMarketplace_N_RGetPriceVBucks_L_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Rprice__vbucks_R_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    Uprice_vbucks* U_Root::_L_2fUnrealEngine_2ecom_2fMarketplace_N_RMakePriceVBucks_L_Nfloat_R(double __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteRuntime._Root._L_2fUnrealEngine_2ecom_2fMarketplace_N_RMakePriceVBucks_L_Nfloat_R");
    
        U_Root____L_2fUnrealEngine_2ecom_2fMarketplace_N_RMakePriceVBucks_L_Nfloat_R_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    void Uprice_vbucks::_Block()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteRuntime.price_vbucks._Block");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Uprice_vbucks::_InitCDO()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteRuntime.price_vbucks._InitCDO");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void Uprice_vbucks::_InitInstance()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraFortniteRuntime.price_vbucks._InitInstance");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

} // namespace UE

