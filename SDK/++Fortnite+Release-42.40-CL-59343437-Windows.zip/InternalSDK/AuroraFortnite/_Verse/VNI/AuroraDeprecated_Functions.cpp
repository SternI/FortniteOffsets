/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:36
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AuroraFortnite/_Verse/VNI/AuroraDeprecated_Functions
 * ============================================================
 */

#include "AuroraDeprecated_Functions.hpp"

namespace UE
{

    Uprice_vbucks* U_SolarisSignatureFunctionOuter::VerseFunction_0(double __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraDeprecated.$SolarisSignatureFunctionOuter.VerseFunction_0");
    
        U_SolarisSignatureFunctionOuter___VerseFunction_0_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

    void U_Root::_InitCDO()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraDeprecated._Root._InitCDO");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    double U_Root::_L_2fFortnite_2ecom_2fMarketplace_N_RGetPriceVBucks_L_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Rprice__vbucks_R(Uprice_vbucks* __verse_0xB2CDDD72_Argument)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AuroraDeprecated._Root._L_2fFortnite_2ecom_2fMarketplace_N_RGetPriceVBucks_L_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Rprice__vbucks_R");
    
        U_Root____L_2fFortnite_2ecom_2fMarketplace_N_RGetPriceVBucks_L_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Rprice__vbucks_R_Params Params{};
        Params.__verse_0xB2CDDD72_Argument = __verse_0xB2CDDD72_Argument;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.RetVal;
    }

} // namespace UE

