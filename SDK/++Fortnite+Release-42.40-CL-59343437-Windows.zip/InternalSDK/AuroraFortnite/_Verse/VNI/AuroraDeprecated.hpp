/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:36
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AuroraFortnite/_Verse/VNI/AuroraDeprecated
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class U_SolarisSignatureFunctionOuter : public UObject
    {
    public:
    
    public: // Functions
        Uprice_vbucks*  VerseFunction_0(double __verse_0xB2CDDD72_Argument); // 0x000545D2 [Delegate | HasOutParms]
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x8) U_Root : public UObject
    {
    public:
        uint8   __verse_0xBA37D963_MakePriceVBucks[0x000010];   // 0x000028 (0x000010)
    
    public: // Functions
        void    _InitCDO(); // 0x000545D2 [FUNC_None]
        static double  _L_2fFortnite_2ecom_2fMarketplace_N_RGetPriceVBucks_L_N_L_2fUnrealEngine_2ecom_2fMarketplace_N_Rprice__vbucks_R(Uprice_vbucks* __verse_0xB2CDDD72_Argument); // 0x000545D2 [Final | Static | Public | HasOutParms | BlueprintCallable]
    };
}

