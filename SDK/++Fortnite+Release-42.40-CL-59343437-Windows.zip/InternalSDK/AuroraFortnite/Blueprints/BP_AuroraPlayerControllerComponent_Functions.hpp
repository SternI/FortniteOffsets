/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:37
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AuroraFortnite/Blueprints/BP_AuroraPlayerControllerComponent_Functions
 * ============================================================
 */

#include "BP_AuroraPlayerControllerComponent.hpp"

namespace UE
{

    struct UBP_AuroraPlayerControllerComponent_C___ReceiveEndPlay_Params
    {
        TEnumAsByte<EEndPlayReason> EndPlayReason;  // 0x000000 (0x000001) [Default: 48]
    };

    struct UBP_AuroraPlayerControllerComponent_C___OnPurchaseInvoiceRequested_Params
    {
        FInstancedStruct    InInvoice;  // 0x000000 (0x000010) [OutParam]
    };

    struct UBP_AuroraPlayerControllerComponent_C___OnOfferSelected_Params
    {
        FGuid   InOfferInstanceId;  // 0x000000 (0x000010)
    };

    struct UBP_AuroraPlayerControllerComponent_C___OnEventReceived_EFC2B600475ECDA3623EFEAE82187209_Params
    {
        UAsyncAction_StartListeningToEvent* ProxyObject;    // 0x000000 (0x000008) [Default: 0x14906030]
    };

    struct UBP_AuroraPlayerControllerComponent_C___OnEventReceived_EC9CCDF448252C8CBD51DFB7B5C245BC_Params
    {
        UAsyncAction_StartListeningToEvent* ProxyObject;    // 0x000000 (0x000008) [Default: 0x14906030]
    };

    struct UBP_AuroraPlayerControllerComponent_C___OnEventReceived_C109555749A732E343C009AD05F24165_Params
    {
        UAsyncAction_StartListeningToEvent* ProxyObject;    // 0x000000 (0x000008) [Default: 0x14906030]
    };

    struct UBP_AuroraPlayerControllerComponent_C___OnEventReceived_4644CD3E41C7FFE0B5B81A98D3492ADD_Params
    {
        UAsyncAction_StartListeningToEvent* ProxyObject;    // 0x000000 (0x000008) [Default: 0x14906030]
    };

    struct UBP_AuroraPlayerControllerComponent_C___ExecuteUbergraph_BP_AuroraPlayerControllerComponent_Params
    {
        int32                                   EntryPoint;                                             // 0x000000 (0x000004) [Default: 345006128]
        uint8                                   UnknownData_000004[0x000004];                           // 0x000004 (0x000004)
        UAsyncAction_StartListeningToEvent*     K2Node_CustomEvent_ProxyObject_3;                       // 0x000008 (0x000008) [Default: 0x3471CDD00280031]
        AsyncGameplayEventDelegate              K2Node_CreateDelegate_OutputDelegate;                   // 0x000010 (0x00000C)
        uint8                                   UnknownData_00001C[0x000004];                           // 0x00001C (0x000004)
        FAuroraPurchaseInvoiceRequested         Temp_struct_Variable;                                   // 0x000020 (0x000010)
        UAsyncAction_StartListeningToEvent*     Temp_object_Variable;                                   // 0x000030 (0x000008) [Default: 0x130A96B0]
        FAuroraOfferSelected                    Temp_struct_Variable_1;                                 // 0x000038 (0x000010)
        UAsyncAction_StartListeningToEvent*     K2Node_CustomEvent_ProxyObject_2;                       // 0x000048 (0x000008) [Default: nullptr]
        AsyncGameplayEventDelegate              K2Node_CreateDelegate_OutputDelegate_1;                 // 0x000050 (0x00000C)
        FAuroraOfferSelected                    Temp_struct_Variable_2;                                 // 0x00005C (0x000010)
        uint8                                   UnknownData_00006C[0x000004];                           // 0x00006C (0x000004)
        UAsyncAction_StartListeningToEvent*     Temp_object_Variable_1;                                 // 0x000070 (0x000008) [Default: nullptr]
        bool                                    CallFunc_GetPayload_ReturnValue;                        // 0x000078 (0x000001) [Default: false]
        FAuroraOnDialogClosed                   Temp_struct_Variable_3;                                 // 0x000079 (0x000001)
        uint8                                   UnknownData_00007A[0x000006];                           // 0x00007A (0x000006)
        UAsyncAction_StartListeningToEvent*     K2Node_CustomEvent_ProxyObject_1;                       // 0x000080 (0x000008) [Default: nullptr]
        AsyncGameplayEventDelegate              K2Node_CreateDelegate_OutputDelegate_2;                 // 0x000088 (0x00000C)
        FAuroraOnDialogClosed                   Temp_struct_Variable_4;                                 // 0x000094 (0x000001)
        uint8                                   UnknownData_000095[0x000003];                           // 0x000095 (0x000003)
        UAsyncAction_StartListeningToEvent*     Temp_object_Variable_2;                                 // 0x000098 (0x000008) [Default: 0x2060C0]
        bool                                    CallFunc_GetPayload_ReturnValue_1;                      // 0x0000A0 (0x000001) [Default: false]
        FAuroraOnPurchaseCanceled               Temp_struct_Variable_5;                                 // 0x0000A1 (0x000001)
        uint8                                   UnknownData_0000A2[0x000006];                           // 0x0000A2 (0x000006)
        UAsyncAction_StartListeningToEvent*     K2Node_CustomEvent_ProxyObject;                         // 0x0000A8 (0x000008) [Default: nullptr]
        AsyncGameplayEventDelegate              K2Node_CreateDelegate_OutputDelegate_3;                 // 0x0000B0 (0x00000C)
        FAuroraOnPurchaseCanceled               Temp_struct_Variable_6;                                 // 0x0000BC (0x000001)
        uint8                                   UnknownData_0000BD[0x000003];                           // 0x0000BD (0x000003)
        UAsyncAction_StartListeningToEvent*     Temp_object_Variable_3;                                 // 0x0000C0 (0x000008) [Default: nullptr]
        bool                                    CallFunc_GetPayload_ReturnValue_2;                      // 0x0000C8 (0x000001) [Default: false]
        TEnumAsByte<EEndPlayReason>             K2Node_Event_EndPlayReason;                             // 0x0000C9 (0x000001) [Default: 0]
        uint8                                   UnknownData_0000CA[0x000006];                           // 0x0000CA (0x000006)
        UGameplayEventRouterComponent*          CallFunc_GetGlobalEventRouter_ReturnValue;              // 0x0000D0 (0x000008) [Default: nullptr]
        UGameplayEventRouterComponent*          CallFunc_GetGlobalEventRouter_ReturnValue_1;            // 0x0000D8 (0x000008) [Default: nullptr]
        UGameplayEventRouterComponent*          CallFunc_GetGlobalEventRouter_ReturnValue_2;            // 0x0000E0 (0x000008) [Default: nullptr]
        UGameplayEventRouterComponent*          CallFunc_GetGlobalEventRouter_ReturnValue_3;            // 0x0000E8 (0x000008) [Default: nullptr]
        UGameplayEventRouterComponent*          CallFunc_GetGlobalEventRouter_ReturnValue_4;            // 0x0000F0 (0x000008) [Default: nullptr]
        FAuroraPurchaseInvoiceRequested         Temp_struct_Variable_7;                                 // 0x0000F8 (0x000010)
        FInstancedStruct                        K2Node_CustomEvent_InInvoice;                           // 0x000108 (0x000010)
        bool                                    CallFunc_GetPayload_ReturnValue_3;                      // 0x000118 (0x000001) [Default: false]
        uint8                                   UnknownData_000119[0x000003];                           // 0x000119 (0x000003)
        FGuid                                   K2Node_CustomEvent_InOfferInstanceId;                   // 0x00011C (0x000010)
        uint8                                   UnknownData_00012C[0x000004];                           // 0x00012C (0x000004)
        UGameplayEventRouterComponent*          CallFunc_GetGlobalEventRouter_ReturnValue_5;            // 0x000130 (0x000008) [Default: nullptr]
        UGameplayEventRouterComponent*          CallFunc_GetGlobalEventRouter_ReturnValue_6;            // 0x000138 (0x000008) [Default: nullptr]
        FGuid                                   K2Node_Event_InCatalogId;                               // 0x000140 (0x000010)
        TArray<FInstancedStruct>                K2Node_Event_InOffers;                                  // 0x000150 (0x000010)
        FText                                   K2Node_Event_InTitle;                                   // 0x000160 (0x000010)
        FInstancedStruct                        K2Node_Event_InInvoice_2;                               // 0x000170 (0x000010)
        bool                                    K2Node_Event_bInSuccessful;                             // 0x000180 (0x000001) [Default: true]
        uint8                                   UnknownData_000181[0x000007];                           // 0x000181 (0x000007)
        FString                                 K2Node_Event_InErrorCode_1;                             // 0x000188 (0x000010) [Default: L""]
        FInstancedStruct                        K2Node_Event_InInvoice_1;                               // 0x000198 (0x000010)
        bool                                    K2Node_Event_bSuccessful_2;                             // 0x0001A8 (0x000001) [Default: false]
        uint8                                   UnknownData_0001A9[0x000007];                           // 0x0001A9 (0x000007)
        FInstancedStruct                        K2Node_Event_InOffer;                                   // 0x0001B0 (0x000010)
        FAuroraStartPurchaseRequested           K2Node_MakeStruct_AuroraStartPurchaseRequested;         // 0x0001C0 (0x000028)
        FInstancedStruct                        K2Node_Event_InInvoice;                                 // 0x0001E8 (0x000010)
        bool                                    K2Node_Event_bSuccessful_1;                             // 0x0001F8 (0x000001) [Default: false]
        uint8                                   UnknownData_0001F9[0x000007];                           // 0x0001F9 (0x000007)
        FInstancedStruct                        K2Node_Event_InReceipt_1;                               // 0x000200 (0x000010)
        FString                                 K2Node_Event_InErrorCode;                               // 0x000210 (0x000010) [Default: L""]
        FInstancedStruct                        K2Node_Event_InReceipt;                                 // 0x000220 (0x000010)
        bool                                    K2Node_Event_bSuccessful;                               // 0x000230 (0x000001) [Default: true]
        uint8                                   UnknownData_000231[0x000007];                           // 0x000231 (0x000007)
        FAuroraInvoicePurchased                 K2Node_MakeStruct_AuroraInvoicePurchased;               // 0x000238 (0x000038)
        FAuroraPurchaseResultFinalized          K2Node_MakeStruct_AuroraPurchaseResultFinalized;        // 0x000270 (0x000018)
        UGameplayEventRouterComponent*          CallFunc_GetGlobalEventRouter_ReturnValue_7;            // 0x000288 (0x000008) [Default: 0x134314D0]
        TMap<FString, int64>                    CallFunc_GetOwnedProductQuantities_ReturnValue;         // 0x000290 (0x000010)
        TMap<FString, int64>                    CallFunc_GetOwnedProductQuantities_ReturnValue_1;       // 0x0002A0 (0x000010)
        FAuroraShowOfferCatalogRequested        K2Node_MakeStruct_AuroraShowOfferCatalogRequested;      // 0x0002B0 (0x000040)
        FAuroraStartPurchaseOfferQueried        K2Node_MakeStruct_AuroraStartPurchaseOfferQueried;      // 0x0002F0 (0x000038)
        TMap<FString, int64>                    K2Node_Event_InOwnedProductQuantities;                  // 0x000328 (0x000010)
        UGameplayEventRouterComponent*          CallFunc_GetGlobalEventRouter_ReturnValue_8;            // 0x000338 (0x000008) [Default: nullptr]
        FAuroraOwnedProductQuantitiesChanged    K2Node_MakeStruct_AuroraOwnedProductQuantitiesChanged;  // 0x000340 (0x000010)
        FGuid                                   K2Node_Event_InOfferInstanceId;                         // 0x000350 (0x000010)
        UGameplayEventRouterComponent*          CallFunc_GetGlobalEventRouter_ReturnValue_9;            // 0x000360 (0x000008) [Default: 0x1]
        FAuroraStartPurchaseRequested           K2Node_MakeStruct_AuroraStartPurchaseRequested_1;       // 0x000368 (0x000028)
        bool                                    K2Node_Event_bForce;                                    // 0x000390 (0x000001) [Default: true]
        uint8                                   UnknownData_000391[0x000007];                           // 0x000391 (0x000007)
        UGameplayEventRouterComponent*          CallFunc_GetGlobalEventRouter_ReturnValue_10;           // 0x000398 (0x000008) [Default: nullptr]
        FAuroraHideOfferCatalogRequested        K2Node_MakeStruct_AuroraHideOfferCatalogRequested;      // 0x0003A0 (0x000001)
        uint8                                   UnknownData_0003A1[0x000007];                           // 0x0003A1 (0x000007)
        AActor*                                 CallFunc_GetOwner_ReturnValue;                          // 0x0003A8 (0x000008) [Default: nullptr]
        UAsyncAction_StartListeningToEvent*     CallFunc_StartListeningToEvent_ReturnValue;             // 0x0003B0 (0x000008) [Default: nullptr]
        AActor*                                 CallFunc_GetOwner_ReturnValue_1;                        // 0x0003B8 (0x000008) [Default: nullptr]
        UAsyncAction_StartListeningToEvent*     CallFunc_StartListeningToEvent_ReturnValue_1;           // 0x0003C0 (0x000008) [Default: nullptr]
        bool                                    CallFunc_IsValid_ReturnValue;                           // 0x0003C8 (0x000001) [Default: false]
        bool                                    CallFunc_IsValid_ReturnValue_1;                         // 0x0003C9 (0x000001) [Default: false]
        uint8                                   UnknownData_0003CA[0x000006];                           // 0x0003CA (0x000006)
        AActor*                                 CallFunc_GetOwner_ReturnValue_2;                        // 0x0003D0 (0x000008) [Default: nullptr]
        AActor*                                 CallFunc_GetOwner_ReturnValue_3;                        // 0x0003D8 (0x000008) [Default: nullptr]
        UAsyncAction_StartListeningToEvent*     CallFunc_StartListeningToEvent_ReturnValue_2;           // 0x0003E0 (0x000008) [Default: 0x7FE959B70380]
        bool                                    CallFunc_K2_BroadcastEvent_ReturnValue;                 // 0x0003E8 (0x000001) [Default: true]
        bool                                    CallFunc_IsValid_ReturnValue_2;                         // 0x0003E9 (0x000001) [Default: false]
        uint8                                   UnknownData_0003EA[0x000006];                           // 0x0003EA (0x000006)
        AActor*                                 CallFunc_GetOwner_ReturnValue_4;                        // 0x0003F0 (0x000008) [Default: nullptr]
        AActor*                                 CallFunc_GetOwner_ReturnValue_5;                        // 0x0003F8 (0x000008) [Default: nullptr]
        bool                                    CallFunc_K2_BroadcastEvent_ReturnValue_1;               // 0x000400 (0x000001) [Default: false]
        bool                                    CallFunc_K2_BroadcastEvent_ReturnValue_2;               // 0x000401 (0x000001) [Default: false]
        uint8                                   UnknownData_000402[0x000006];                           // 0x000402 (0x000006)
        AActor*                                 CallFunc_GetOwner_ReturnValue_6;                        // 0x000408 (0x000008) [Default: nullptr]
        AActor*                                 CallFunc_GetOwner_ReturnValue_7;                        // 0x000410 (0x000008) [Default: nullptr]
        bool                                    CallFunc_K2_BroadcastEvent_ReturnValue_3;               // 0x000418 (0x000001) [Default: false]
        bool                                    CallFunc_K2_BroadcastEvent_ReturnValue_4;               // 0x000419 (0x000001) [Default: false]
        uint8                                   UnknownData_00041A[0x000006];                           // 0x00041A (0x000006)
        AActor*                                 CallFunc_GetOwner_ReturnValue_8;                        // 0x000420 (0x000008) [Default: nullptr]
        AActor*                                 CallFunc_GetOwner_ReturnValue_9;                        // 0x000428 (0x000008) [Default: nullptr]
        bool                                    CallFunc_K2_BroadcastEvent_ReturnValue_5;               // 0x000430 (0x000001) [Default: true]
        bool                                    CallFunc_K2_BroadcastEvent_ReturnValue_6;               // 0x000431 (0x000001) [Default: false]
        uint8                                   UnknownData_000432[0x000006];                           // 0x000432 (0x000006)
        AActor*                                 CallFunc_GetOwner_ReturnValue_10;                       // 0x000438 (0x000008) [Default: nullptr]
        bool                                    CallFunc_K2_BroadcastEvent_ReturnValue_7;               // 0x000440 (0x000001) [Default: false]
        uint8                                   UnknownData_000441[0x000007];                           // 0x000441 (0x000007)
        UGameplayEventRouterComponent*          CallFunc_GetGlobalEventRouter_ReturnValue_11;           // 0x000448 (0x000008) [Default: 0x7FEE58812CC0]
        AActor*                                 CallFunc_GetOwner_ReturnValue_11;                       // 0x000450 (0x000008) [Default: 0x330000002F0]
        UAsyncAction_StartListeningToEvent*     CallFunc_StartListeningToEvent_ReturnValue_3;           // 0x000458 (0x000008) [Default: nullptr]
        bool                                    CallFunc_IsValid_ReturnValue_3;                         // 0x000460 (0x000001) [Default: false]
    };

    struct UBP_AuroraPlayerControllerComponent_C___BP_StartPurchaseInvoiceOfferQueried_Params
    {
        FInstancedStruct    InInvoice;                      // 0x000000 (0x000010) [OutParam]
        bool                bSuccessful;                    // 0x000010 (0x000001) [Default: true]
        uint8               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FInstancedStruct    InOffer;                        // 0x000018 (0x000010) [OutParam]
    };

    struct UBP_AuroraPlayerControllerComponent_C___BP_StartPurchaseInvoice_Params
    {
        FInstancedStruct    InInvoice;                      // 0x000000 (0x000010) [OutParam]
        bool                bInSuccessful;                  // 0x000010 (0x000001) [Default: true]
        uint8               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FString             InErrorCode;                    // 0x000018 (0x000010) [Default: L""]
    };

    struct UBP_AuroraPlayerControllerComponent_C___BP_ShowOffersDialog_Params
    {
        FGuid                       InCatalogId;    // 0x000000 (0x000010) [OutParam]
        TArray<FInstancedStruct>    InOffers;       // 0x000010 (0x000010) [OutParam]
        FText                       InTitle;        // 0x000020 (0x000010) [OutParam]
    };

    struct UBP_AuroraPlayerControllerComponent_C___BP_OnPurchasedInvoice_Params
    {
        FInstancedStruct    InInvoice;                      // 0x000000 (0x000010) [OutParam]
        bool                bSuccessful;                    // 0x000010 (0x000001) [Default: true]
        uint8               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FInstancedStruct    InReceipt;                      // 0x000018 (0x000010) [OutParam]
        FString             InErrorCode;                    // 0x000028 (0x000010) [Default: L""]
    };

    struct UBP_AuroraPlayerControllerComponent_C___BP_OnOwnedProductQuantitiesChanged_Params
    {
        TMap<FString, int64>    InOwnedProductQuantities;   // 0x000000 (0x000010) [OutParam]
    };

    struct UBP_AuroraPlayerControllerComponent_C___BP_OnIntentPurchaseOfferFailed_Params
    {
        FGuid   InOfferInstanceId;  // 0x000000 (0x000010) [OutParam]
    };

    struct UBP_AuroraPlayerControllerComponent_C___BP_OnFinalizedPurchaseResult_Params
    {
        FInstancedStruct    InReceipt;      // 0x000000 (0x000010) [OutParam]
        bool                bSuccessful;    // 0x000010 (0x000001) [Default: true]
    };

    struct UBP_AuroraPlayerControllerComponent_C___BP_CloseOffersDialog_Params
    {
        bool    bForce; // 0x000000 (0x000001) [Default: true]
    };

} // namespace UE

