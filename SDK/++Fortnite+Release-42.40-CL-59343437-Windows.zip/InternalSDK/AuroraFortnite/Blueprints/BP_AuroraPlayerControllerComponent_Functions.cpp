/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:37
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AuroraFortnite/Blueprints/BP_AuroraPlayerControllerComponent_Functions
 * ============================================================
 */

#include "BP_AuroraPlayerControllerComponent_Functions.hpp"

namespace UE
{

    void UBP_AuroraPlayerControllerComponent_C::ReceiveEndPlay(TEnumAsByte<EEndPlayReason> EndPlayReason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AuroraPlayerControllerComponent.BP_AuroraPlayerControllerComponent_C.ReceiveEndPlay");
    
        UBP_AuroraPlayerControllerComponent_C___ReceiveEndPlay_Params Params{};
        Params.EndPlayReason = EndPlayReason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_AuroraPlayerControllerComponent_C::ReceiveBeginPlay()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AuroraPlayerControllerComponent.BP_AuroraPlayerControllerComponent_C.ReceiveBeginPlay");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBP_AuroraPlayerControllerComponent_C::OnPurchaseInvoiceRequested(FInstancedStruct& InInvoice)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AuroraPlayerControllerComponent.BP_AuroraPlayerControllerComponent_C.OnPurchaseInvoiceRequested");
    
        UBP_AuroraPlayerControllerComponent_C___OnPurchaseInvoiceRequested_Params Params{};
        Params.InInvoice = InInvoice;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InInvoice = Params.InInvoice;
    }

    void UBP_AuroraPlayerControllerComponent_C::OnOfferSelected(FGuid InOfferInstanceId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AuroraPlayerControllerComponent.BP_AuroraPlayerControllerComponent_C.OnOfferSelected");
    
        UBP_AuroraPlayerControllerComponent_C___OnOfferSelected_Params Params{};
        Params.InOfferInstanceId = InOfferInstanceId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_AuroraPlayerControllerComponent_C::OnOfferPurchaseCanceled()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AuroraPlayerControllerComponent.BP_AuroraPlayerControllerComponent_C.OnOfferPurchaseCanceled");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBP_AuroraPlayerControllerComponent_C::OnEventReceived_EFC2B600475ECDA3623EFEAE82187209(UAsyncAction_StartListeningToEvent* ProxyObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AuroraPlayerControllerComponent.BP_AuroraPlayerControllerComponent_C.OnEventReceived_EFC2B600475ECDA3623EFEAE82187209");
    
        UBP_AuroraPlayerControllerComponent_C___OnEventReceived_EFC2B600475ECDA3623EFEAE82187209_Params Params{};
        Params.ProxyObject = ProxyObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_AuroraPlayerControllerComponent_C::OnEventReceived_EC9CCDF448252C8CBD51DFB7B5C245BC(UAsyncAction_StartListeningToEvent* ProxyObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AuroraPlayerControllerComponent.BP_AuroraPlayerControllerComponent_C.OnEventReceived_EC9CCDF448252C8CBD51DFB7B5C245BC");
    
        UBP_AuroraPlayerControllerComponent_C___OnEventReceived_EC9CCDF448252C8CBD51DFB7B5C245BC_Params Params{};
        Params.ProxyObject = ProxyObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_AuroraPlayerControllerComponent_C::OnEventReceived_C109555749A732E343C009AD05F24165(UAsyncAction_StartListeningToEvent* ProxyObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AuroraPlayerControllerComponent.BP_AuroraPlayerControllerComponent_C.OnEventReceived_C109555749A732E343C009AD05F24165");
    
        UBP_AuroraPlayerControllerComponent_C___OnEventReceived_C109555749A732E343C009AD05F24165_Params Params{};
        Params.ProxyObject = ProxyObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_AuroraPlayerControllerComponent_C::OnEventReceived_4644CD3E41C7FFE0B5B81A98D3492ADD(UAsyncAction_StartListeningToEvent* ProxyObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AuroraPlayerControllerComponent.BP_AuroraPlayerControllerComponent_C.OnEventReceived_4644CD3E41C7FFE0B5B81A98D3492ADD");
    
        UBP_AuroraPlayerControllerComponent_C___OnEventReceived_4644CD3E41C7FFE0B5B81A98D3492ADD_Params Params{};
        Params.ProxyObject = ProxyObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_AuroraPlayerControllerComponent_C::ExecuteUbergraph_BP_AuroraPlayerControllerComponent(int32 EntryPoint, UAsyncAction_StartListeningToEvent* K2Node_CustomEvent_ProxyObject_3, AsyncGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate, FAuroraPurchaseInvoiceRequested Temp_struct_Variable, UAsyncAction_StartListeningToEvent* Temp_object_Variable, FAuroraOfferSelected Temp_struct_Variable_1, UAsyncAction_StartListeningToEvent* K2Node_CustomEvent_ProxyObject_2, AsyncGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate_1, FAuroraOfferSelected Temp_struct_Variable_2, UAsyncAction_StartListeningToEvent* Temp_object_Variable_1, bool CallFunc_GetPayload_ReturnValue, FAuroraOnDialogClosed Temp_struct_Variable_3, UAsyncAction_StartListeningToEvent* K2Node_CustomEvent_ProxyObject_1, AsyncGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate_2, FAuroraOnDialogClosed Temp_struct_Variable_4, UAsyncAction_StartListeningToEvent* Temp_object_Variable_2, bool CallFunc_GetPayload_ReturnValue_1, FAuroraOnPurchaseCanceled Temp_struct_Variable_5, UAsyncAction_StartListeningToEvent* K2Node_CustomEvent_ProxyObject, AsyncGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate_3, FAuroraOnPurchaseCanceled Temp_struct_Variable_6, UAsyncAction_StartListeningToEvent* Temp_object_Variable_3, bool CallFunc_GetPayload_ReturnValue_2, TEnumAsByte<EEndPlayReason> K2Node_Event_EndPlayReason, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_1, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_2, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_3, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_4, FAuroraPurchaseInvoiceRequested Temp_struct_Variable_7, FInstancedStruct K2Node_CustomEvent_InInvoice, bool CallFunc_GetPayload_ReturnValue_3, FGuid K2Node_CustomEvent_InOfferInstanceId, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_5, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_6, FGuid K2Node_Event_InCatalogId, TArray<FInstancedStruct> K2Node_Event_InOffers, FText K2Node_Event_InTitle, FInstancedStruct K2Node_Event_InInvoice_2, bool K2Node_Event_bInSuccessful, FString K2Node_Event_InErrorCode_1, FInstancedStruct K2Node_Event_InInvoice_1, bool K2Node_Event_bSuccessful_2, FInstancedStruct K2Node_Event_InOffer, FAuroraStartPurchaseRequested K2Node_MakeStruct_AuroraStartPurchaseRequested, FInstancedStruct K2Node_Event_InInvoice, bool K2Node_Event_bSuccessful_1, FInstancedStruct K2Node_Event_InReceipt_1, FString K2Node_Event_InErrorCode, FInstancedStruct K2Node_Event_InReceipt, bool K2Node_Event_bSuccessful, FAuroraInvoicePurchased K2Node_MakeStruct_AuroraInvoicePurchased, FAuroraPurchaseResultFinalized K2Node_MakeStruct_AuroraPurchaseResultFinalized, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_7, TMap<FString, int64> CallFunc_GetOwnedProductQuantities_ReturnValue, TMap<FString, int64> CallFunc_GetOwnedProductQuantities_ReturnValue_1, FAuroraShowOfferCatalogRequested K2Node_MakeStruct_AuroraShowOfferCatalogRequested, FAuroraStartPurchaseOfferQueried K2Node_MakeStruct_AuroraStartPurchaseOfferQueried, TMap<FString, int64> K2Node_Event_InOwnedProductQuantities, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_8, FAuroraOwnedProductQuantitiesChanged K2Node_MakeStruct_AuroraOwnedProductQuantitiesChanged, FGuid K2Node_Event_InOfferInstanceId, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_9, FAuroraStartPurchaseRequested K2Node_MakeStruct_AuroraStartPurchaseRequested_1, bool K2Node_Event_bForce, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_10, FAuroraHideOfferCatalogRequested K2Node_MakeStruct_AuroraHideOfferCatalogRequested, AActor* CallFunc_GetOwner_ReturnValue, UAsyncAction_StartListeningToEvent* CallFunc_StartListeningToEvent_ReturnValue, AActor* CallFunc_GetOwner_ReturnValue_1, UAsyncAction_StartListeningToEvent* CallFunc_StartListeningToEvent_ReturnValue_1, bool CallFunc_IsValid_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, AActor* CallFunc_GetOwner_ReturnValue_2, AActor* CallFunc_GetOwner_ReturnValue_3, UAsyncAction_StartListeningToEvent* CallFunc_StartListeningToEvent_ReturnValue_2, bool CallFunc_K2_BroadcastEvent_ReturnValue, bool CallFunc_IsValid_ReturnValue_2, AActor* CallFunc_GetOwner_ReturnValue_4, AActor* CallFunc_GetOwner_ReturnValue_5, bool CallFunc_K2_BroadcastEvent_ReturnValue_1, bool CallFunc_K2_BroadcastEvent_ReturnValue_2, AActor* CallFunc_GetOwner_ReturnValue_6, AActor* CallFunc_GetOwner_ReturnValue_7, bool CallFunc_K2_BroadcastEvent_ReturnValue_3, bool CallFunc_K2_BroadcastEvent_ReturnValue_4, AActor* CallFunc_GetOwner_ReturnValue_8, AActor* CallFunc_GetOwner_ReturnValue_9, bool CallFunc_K2_BroadcastEvent_ReturnValue_5, bool CallFunc_K2_BroadcastEvent_ReturnValue_6, AActor* CallFunc_GetOwner_ReturnValue_10, bool CallFunc_K2_BroadcastEvent_ReturnValue_7, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_11, AActor* CallFunc_GetOwner_ReturnValue_11, UAsyncAction_StartListeningToEvent* CallFunc_StartListeningToEvent_ReturnValue_3, bool CallFunc_IsValid_ReturnValue_3)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AuroraPlayerControllerComponent.BP_AuroraPlayerControllerComponent_C.ExecuteUbergraph_BP_AuroraPlayerControllerComponent");
    
        UBP_AuroraPlayerControllerComponent_C___ExecuteUbergraph_BP_AuroraPlayerControllerComponent_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.K2Node_CustomEvent_ProxyObject_3 = K2Node_CustomEvent_ProxyObject_3;
        Params.K2Node_CreateDelegate_OutputDelegate = K2Node_CreateDelegate_OutputDelegate;
        Params.Temp_struct_Variable = Temp_struct_Variable;
        Params.Temp_object_Variable = Temp_object_Variable;
        Params.Temp_struct_Variable_1 = Temp_struct_Variable_1;
        Params.K2Node_CustomEvent_ProxyObject_2 = K2Node_CustomEvent_ProxyObject_2;
        Params.K2Node_CreateDelegate_OutputDelegate_1 = K2Node_CreateDelegate_OutputDelegate_1;
        Params.Temp_struct_Variable_2 = Temp_struct_Variable_2;
        Params.Temp_object_Variable_1 = Temp_object_Variable_1;
        Params.CallFunc_GetPayload_ReturnValue = CallFunc_GetPayload_ReturnValue;
        Params.Temp_struct_Variable_3 = Temp_struct_Variable_3;
        Params.K2Node_CustomEvent_ProxyObject_1 = K2Node_CustomEvent_ProxyObject_1;
        Params.K2Node_CreateDelegate_OutputDelegate_2 = K2Node_CreateDelegate_OutputDelegate_2;
        Params.Temp_struct_Variable_4 = Temp_struct_Variable_4;
        Params.Temp_object_Variable_2 = Temp_object_Variable_2;
        Params.CallFunc_GetPayload_ReturnValue_1 = CallFunc_GetPayload_ReturnValue_1;
        Params.Temp_struct_Variable_5 = Temp_struct_Variable_5;
        Params.K2Node_CustomEvent_ProxyObject = K2Node_CustomEvent_ProxyObject;
        Params.K2Node_CreateDelegate_OutputDelegate_3 = K2Node_CreateDelegate_OutputDelegate_3;
        Params.Temp_struct_Variable_6 = Temp_struct_Variable_6;
        Params.Temp_object_Variable_3 = Temp_object_Variable_3;
        Params.CallFunc_GetPayload_ReturnValue_2 = CallFunc_GetPayload_ReturnValue_2;
        Params.K2Node_Event_EndPlayReason = K2Node_Event_EndPlayReason;
        Params.CallFunc_GetGlobalEventRouter_ReturnValue = CallFunc_GetGlobalEventRouter_ReturnValue;
        Params.CallFunc_GetGlobalEventRouter_ReturnValue_1 = CallFunc_GetGlobalEventRouter_ReturnValue_1;
        Params.CallFunc_GetGlobalEventRouter_ReturnValue_2 = CallFunc_GetGlobalEventRouter_ReturnValue_2;
        Params.CallFunc_GetGlobalEventRouter_ReturnValue_3 = CallFunc_GetGlobalEventRouter_ReturnValue_3;
        Params.CallFunc_GetGlobalEventRouter_ReturnValue_4 = CallFunc_GetGlobalEventRouter_ReturnValue_4;
        Params.Temp_struct_Variable_7 = Temp_struct_Variable_7;
        Params.K2Node_CustomEvent_InInvoice = K2Node_CustomEvent_InInvoice;
        Params.CallFunc_GetPayload_ReturnValue_3 = CallFunc_GetPayload_ReturnValue_3;
        Params.K2Node_CustomEvent_InOfferInstanceId = K2Node_CustomEvent_InOfferInstanceId;
        Params.CallFunc_GetGlobalEventRouter_ReturnValue_5 = CallFunc_GetGlobalEventRouter_ReturnValue_5;
        Params.CallFunc_GetGlobalEventRouter_ReturnValue_6 = CallFunc_GetGlobalEventRouter_ReturnValue_6;
        Params.K2Node_Event_InCatalogId = K2Node_Event_InCatalogId;
        Params.K2Node_Event_InOffers = K2Node_Event_InOffers;
        Params.K2Node_Event_InTitle = K2Node_Event_InTitle;
        Params.K2Node_Event_InInvoice_2 = K2Node_Event_InInvoice_2;
        Params.K2Node_Event_bInSuccessful = K2Node_Event_bInSuccessful;
        Params.K2Node_Event_InErrorCode_1 = K2Node_Event_InErrorCode_1;
        Params.K2Node_Event_InInvoice_1 = K2Node_Event_InInvoice_1;
        Params.K2Node_Event_bSuccessful_2 = K2Node_Event_bSuccessful_2;
        Params.K2Node_Event_InOffer = K2Node_Event_InOffer;
        Params.K2Node_MakeStruct_AuroraStartPurchaseRequested = K2Node_MakeStruct_AuroraStartPurchaseRequested;
        Params.K2Node_Event_InInvoice = K2Node_Event_InInvoice;
        Params.K2Node_Event_bSuccessful_1 = K2Node_Event_bSuccessful_1;
        Params.K2Node_Event_InReceipt_1 = K2Node_Event_InReceipt_1;
        Params.K2Node_Event_InErrorCode = K2Node_Event_InErrorCode;
        Params.K2Node_Event_InReceipt = K2Node_Event_InReceipt;
        Params.K2Node_Event_bSuccessful = K2Node_Event_bSuccessful;
        Params.K2Node_MakeStruct_AuroraInvoicePurchased = K2Node_MakeStruct_AuroraInvoicePurchased;
        Params.K2Node_MakeStruct_AuroraPurchaseResultFinalized = K2Node_MakeStruct_AuroraPurchaseResultFinalized;
        Params.CallFunc_GetGlobalEventRouter_ReturnValue_7 = CallFunc_GetGlobalEventRouter_ReturnValue_7;
        Params.CallFunc_GetOwnedProductQuantities_ReturnValue = CallFunc_GetOwnedProductQuantities_ReturnValue;
        Params.CallFunc_GetOwnedProductQuantities_ReturnValue_1 = CallFunc_GetOwnedProductQuantities_ReturnValue_1;
        Params.K2Node_MakeStruct_AuroraShowOfferCatalogRequested = K2Node_MakeStruct_AuroraShowOfferCatalogRequested;
        Params.K2Node_MakeStruct_AuroraStartPurchaseOfferQueried = K2Node_MakeStruct_AuroraStartPurchaseOfferQueried;
        Params.K2Node_Event_InOwnedProductQuantities = K2Node_Event_InOwnedProductQuantities;
        Params.CallFunc_GetGlobalEventRouter_ReturnValue_8 = CallFunc_GetGlobalEventRouter_ReturnValue_8;
        Params.K2Node_MakeStruct_AuroraOwnedProductQuantitiesChanged = K2Node_MakeStruct_AuroraOwnedProductQuantitiesChanged;
        Params.K2Node_Event_InOfferInstanceId = K2Node_Event_InOfferInstanceId;
        Params.CallFunc_GetGlobalEventRouter_ReturnValue_9 = CallFunc_GetGlobalEventRouter_ReturnValue_9;
        Params.K2Node_MakeStruct_AuroraStartPurchaseRequested_1 = K2Node_MakeStruct_AuroraStartPurchaseRequested_1;
        Params.K2Node_Event_bForce = K2Node_Event_bForce;
        Params.CallFunc_GetGlobalEventRouter_ReturnValue_10 = CallFunc_GetGlobalEventRouter_ReturnValue_10;
        Params.K2Node_MakeStruct_AuroraHideOfferCatalogRequested = K2Node_MakeStruct_AuroraHideOfferCatalogRequested;
        Params.CallFunc_GetOwner_ReturnValue = CallFunc_GetOwner_ReturnValue;
        Params.CallFunc_StartListeningToEvent_ReturnValue = CallFunc_StartListeningToEvent_ReturnValue;
        Params.CallFunc_GetOwner_ReturnValue_1 = CallFunc_GetOwner_ReturnValue_1;
        Params.CallFunc_StartListeningToEvent_ReturnValue_1 = CallFunc_StartListeningToEvent_ReturnValue_1;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
        Params.CallFunc_GetOwner_ReturnValue_2 = CallFunc_GetOwner_ReturnValue_2;
        Params.CallFunc_GetOwner_ReturnValue_3 = CallFunc_GetOwner_ReturnValue_3;
        Params.CallFunc_StartListeningToEvent_ReturnValue_2 = CallFunc_StartListeningToEvent_ReturnValue_2;
        Params.CallFunc_K2_BroadcastEvent_ReturnValue = CallFunc_K2_BroadcastEvent_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_2 = CallFunc_IsValid_ReturnValue_2;
        Params.CallFunc_GetOwner_ReturnValue_4 = CallFunc_GetOwner_ReturnValue_4;
        Params.CallFunc_GetOwner_ReturnValue_5 = CallFunc_GetOwner_ReturnValue_5;
        Params.CallFunc_K2_BroadcastEvent_ReturnValue_1 = CallFunc_K2_BroadcastEvent_ReturnValue_1;
        Params.CallFunc_K2_BroadcastEvent_ReturnValue_2 = CallFunc_K2_BroadcastEvent_ReturnValue_2;
        Params.CallFunc_GetOwner_ReturnValue_6 = CallFunc_GetOwner_ReturnValue_6;
        Params.CallFunc_GetOwner_ReturnValue_7 = CallFunc_GetOwner_ReturnValue_7;
        Params.CallFunc_K2_BroadcastEvent_ReturnValue_3 = CallFunc_K2_BroadcastEvent_ReturnValue_3;
        Params.CallFunc_K2_BroadcastEvent_ReturnValue_4 = CallFunc_K2_BroadcastEvent_ReturnValue_4;
        Params.CallFunc_GetOwner_ReturnValue_8 = CallFunc_GetOwner_ReturnValue_8;
        Params.CallFunc_GetOwner_ReturnValue_9 = CallFunc_GetOwner_ReturnValue_9;
        Params.CallFunc_K2_BroadcastEvent_ReturnValue_5 = CallFunc_K2_BroadcastEvent_ReturnValue_5;
        Params.CallFunc_K2_BroadcastEvent_ReturnValue_6 = CallFunc_K2_BroadcastEvent_ReturnValue_6;
        Params.CallFunc_GetOwner_ReturnValue_10 = CallFunc_GetOwner_ReturnValue_10;
        Params.CallFunc_K2_BroadcastEvent_ReturnValue_7 = CallFunc_K2_BroadcastEvent_ReturnValue_7;
        Params.CallFunc_GetGlobalEventRouter_ReturnValue_11 = CallFunc_GetGlobalEventRouter_ReturnValue_11;
        Params.CallFunc_GetOwner_ReturnValue_11 = CallFunc_GetOwner_ReturnValue_11;
        Params.CallFunc_StartListeningToEvent_ReturnValue_3 = CallFunc_StartListeningToEvent_ReturnValue_3;
        Params.CallFunc_IsValid_ReturnValue_3 = CallFunc_IsValid_ReturnValue_3;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_AuroraPlayerControllerComponent_C::BP_StartPurchaseInvoiceOfferQueried(FInstancedStruct& InInvoice, bool bSuccessful, FInstancedStruct& InOffer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AuroraPlayerControllerComponent.BP_AuroraPlayerControllerComponent_C.BP_StartPurchaseInvoiceOfferQueried");
    
        UBP_AuroraPlayerControllerComponent_C___BP_StartPurchaseInvoiceOfferQueried_Params Params{};
        Params.InInvoice = InInvoice;
        Params.bSuccessful = bSuccessful;
        Params.InOffer = InOffer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InInvoice = Params.InInvoice;
        InOffer = Params.InOffer;
    }

    void UBP_AuroraPlayerControllerComponent_C::BP_StartPurchaseInvoice(FInstancedStruct& InInvoice, bool bInSuccessful, FString InErrorCode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AuroraPlayerControllerComponent.BP_AuroraPlayerControllerComponent_C.BP_StartPurchaseInvoice");
    
        UBP_AuroraPlayerControllerComponent_C___BP_StartPurchaseInvoice_Params Params{};
        Params.InInvoice = InInvoice;
        Params.bInSuccessful = bInSuccessful;
        Params.InErrorCode = InErrorCode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InInvoice = Params.InInvoice;
    }

    void UBP_AuroraPlayerControllerComponent_C::BP_ShowOffersDialog(FGuid& InCatalogId, TArray<FInstancedStruct>& InOffers, FText& InTitle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AuroraPlayerControllerComponent.BP_AuroraPlayerControllerComponent_C.BP_ShowOffersDialog");
    
        UBP_AuroraPlayerControllerComponent_C___BP_ShowOffersDialog_Params Params{};
        Params.InCatalogId = InCatalogId;
        Params.InOffers = InOffers;
        Params.InTitle = InTitle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InCatalogId = Params.InCatalogId;
        InOffers = Params.InOffers;
        InTitle = Params.InTitle;
    }

    void UBP_AuroraPlayerControllerComponent_C::BP_OnPurchasedInvoice(FInstancedStruct& InInvoice, bool bSuccessful, FInstancedStruct& InReceipt, FString InErrorCode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AuroraPlayerControllerComponent.BP_AuroraPlayerControllerComponent_C.BP_OnPurchasedInvoice");
    
        UBP_AuroraPlayerControllerComponent_C___BP_OnPurchasedInvoice_Params Params{};
        Params.InInvoice = InInvoice;
        Params.bSuccessful = bSuccessful;
        Params.InReceipt = InReceipt;
        Params.InErrorCode = InErrorCode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InInvoice = Params.InInvoice;
        InReceipt = Params.InReceipt;
    }

    void UBP_AuroraPlayerControllerComponent_C::BP_OnOwnedProductQuantitiesChanged(TMap<FString, int64>& InOwnedProductQuantities)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AuroraPlayerControllerComponent.BP_AuroraPlayerControllerComponent_C.BP_OnOwnedProductQuantitiesChanged");
    
        UBP_AuroraPlayerControllerComponent_C___BP_OnOwnedProductQuantitiesChanged_Params Params{};
        Params.InOwnedProductQuantities = InOwnedProductQuantities;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InOwnedProductQuantities = Params.InOwnedProductQuantities;
    }

    void UBP_AuroraPlayerControllerComponent_C::BP_OnIntentPurchaseOfferFailed(FGuid& InOfferInstanceId)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AuroraPlayerControllerComponent.BP_AuroraPlayerControllerComponent_C.BP_OnIntentPurchaseOfferFailed");
    
        UBP_AuroraPlayerControllerComponent_C___BP_OnIntentPurchaseOfferFailed_Params Params{};
        Params.InOfferInstanceId = InOfferInstanceId;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InOfferInstanceId = Params.InOfferInstanceId;
    }

    void UBP_AuroraPlayerControllerComponent_C::BP_OnFinalizedPurchaseResult(FInstancedStruct& InReceipt, bool bSuccessful)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AuroraPlayerControllerComponent.BP_AuroraPlayerControllerComponent_C.BP_OnFinalizedPurchaseResult");
    
        UBP_AuroraPlayerControllerComponent_C___BP_OnFinalizedPurchaseResult_Params Params{};
        Params.InReceipt = InReceipt;
        Params.bSuccessful = bSuccessful;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InReceipt = Params.InReceipt;
    }

    void UBP_AuroraPlayerControllerComponent_C::BP_CloseOffersDialog(bool bForce)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_AuroraPlayerControllerComponent.BP_AuroraPlayerControllerComponent_C.BP_CloseOffersDialog");
    
        UBP_AuroraPlayerControllerComponent_C___BP_CloseOffersDialog_Params Params{};
        Params.bForce = bForce;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

