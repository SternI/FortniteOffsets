/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:37
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /AuroraFortnite/Blueprints/BP_AuroraPlayerControllerComponent
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000230 (0x000028)
    class alignas(0x8) UBP_AuroraPlayerControllerComponent_C : public UAuroraFortnitePlayerControllerComponent
    {
    public:
        FPointerToUberGraphFrame            UberGraphFrame;             // 0x000208 (0x000008)
        UAsyncAction_StartListeningToEvent* OfferSelectedEvent;         // 0x000210 (0x000008) [Default: nullptr]
        UAsyncAction_StartListeningToEvent* PurchaseInvoiceEvent;       // 0x000218 (0x000008) [Default: nullptr]
        UAsyncAction_StartListeningToEvent* OnDialogClosedEvent;        // 0x000220 (0x000008) [Default: nullptr]
        UAsyncAction_StartListeningToEvent* OnPurchaseCanceledEvent;    // 0x000228 (0x000008) [Default: nullptr]
    
    public: // Functions
        void    ReceiveEndPlay(TEnumAsByte<EEndPlayReason> EndPlayReason); // 0x000545D2 [Event | Public | BlueprintEvent]
        void    ReceiveBeginPlay(); // 0x000545D2 [Event | Public | BlueprintEvent]
        void    OnPurchaseInvoiceRequested(FInstancedStruct& InInvoice); // 0x000545D2 [HasOutParms | BlueprintCallable | BlueprintEvent]
        void    OnOfferSelected(FGuid InOfferInstanceId); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnOfferPurchaseCanceled(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnEventReceived_EFC2B600475ECDA3623EFEAE82187209(UAsyncAction_StartListeningToEvent* ProxyObject); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnEventReceived_EC9CCDF448252C8CBD51DFB7B5C245BC(UAsyncAction_StartListeningToEvent* ProxyObject); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnEventReceived_C109555749A732E343C009AD05F24165(UAsyncAction_StartListeningToEvent* ProxyObject); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnEventReceived_4644CD3E41C7FFE0B5B81A98D3492ADD(UAsyncAction_StartListeningToEvent* ProxyObject); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    ExecuteUbergraph_BP_AuroraPlayerControllerComponent(int32 EntryPoint, UAsyncAction_StartListeningToEvent* K2Node_CustomEvent_ProxyObject_3, AsyncGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate, FAuroraPurchaseInvoiceRequested Temp_struct_Variable, UAsyncAction_StartListeningToEvent* Temp_object_Variable, FAuroraOfferSelected Temp_struct_Variable_1, UAsyncAction_StartListeningToEvent* K2Node_CustomEvent_ProxyObject_2, AsyncGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate_1, FAuroraOfferSelected Temp_struct_Variable_2, UAsyncAction_StartListeningToEvent* Temp_object_Variable_1, bool CallFunc_GetPayload_ReturnValue, FAuroraOnDialogClosed Temp_struct_Variable_3, UAsyncAction_StartListeningToEvent* K2Node_CustomEvent_ProxyObject_1, AsyncGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate_2, FAuroraOnDialogClosed Temp_struct_Variable_4, UAsyncAction_StartListeningToEvent* Temp_object_Variable_2, bool CallFunc_GetPayload_ReturnValue_1, FAuroraOnPurchaseCanceled Temp_struct_Variable_5, UAsyncAction_StartListeningToEvent* K2Node_CustomEvent_ProxyObject, AsyncGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate_3, FAuroraOnPurchaseCanceled Temp_struct_Variable_6, UAsyncAction_StartListeningToEvent* Temp_object_Variable_3, bool CallFunc_GetPayload_ReturnValue_2, TEnumAsByte<EEndPlayReason> K2Node_Event_EndPlayReason, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_1, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_2, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_3, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_4, FAuroraPurchaseInvoiceRequested Temp_struct_Variable_7, FInstancedStruct K2Node_CustomEvent_InInvoice, bool CallFunc_GetPayload_ReturnValue_3, FGuid K2Node_CustomEvent_InOfferInstanceId, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_5, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_6, FGuid K2Node_Event_InCatalogId, TArray<FInstancedStruct> K2Node_Event_InOffers, FText K2Node_Event_InTitle, FInstancedStruct K2Node_Event_InInvoice_2, bool K2Node_Event_bInSuccessful, FString K2Node_Event_InErrorCode_1, FInstancedStruct K2Node_Event_InInvoice_1, bool K2Node_Event_bSuccessful_2, FInstancedStruct K2Node_Event_InOffer, FAuroraStartPurchaseRequested K2Node_MakeStruct_AuroraStartPurchaseRequested, FInstancedStruct K2Node_Event_InInvoice, bool K2Node_Event_bSuccessful_1, FInstancedStruct K2Node_Event_InReceipt_1, FString K2Node_Event_InErrorCode, FInstancedStruct K2Node_Event_InReceipt, bool K2Node_Event_bSuccessful, FAuroraInvoicePurchased K2Node_MakeStruct_AuroraInvoicePurchased, FAuroraPurchaseResultFinalized K2Node_MakeStruct_AuroraPurchaseResultFinalized, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_7, TMap<FString, int64> CallFunc_GetOwnedProductQuantities_ReturnValue, TMap<FString, int64> CallFunc_GetOwnedProductQuantities_ReturnValue_1, FAuroraShowOfferCatalogRequested K2Node_MakeStruct_AuroraShowOfferCatalogRequested, FAuroraStartPurchaseOfferQueried K2Node_MakeStruct_AuroraStartPurchaseOfferQueried, TMap<FString, int64> K2Node_Event_InOwnedProductQuantities, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_8, FAuroraOwnedProductQuantitiesChanged K2Node_MakeStruct_AuroraOwnedProductQuantitiesChanged, FGuid K2Node_Event_InOfferInstanceId, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_9, FAuroraStartPurchaseRequested K2Node_MakeStruct_AuroraStartPurchaseRequested_1, bool K2Node_Event_bForce, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_10, FAuroraHideOfferCatalogRequested K2Node_MakeStruct_AuroraHideOfferCatalogRequested, AActor* CallFunc_GetOwner_ReturnValue, UAsyncAction_StartListeningToEvent* CallFunc_StartListeningToEvent_ReturnValue, AActor* CallFunc_GetOwner_ReturnValue_1, UAsyncAction_StartListeningToEvent* CallFunc_StartListeningToEvent_ReturnValue_1, bool CallFunc_IsValid_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, AActor* CallFunc_GetOwner_ReturnValue_2, AActor* CallFunc_GetOwner_ReturnValue_3, UAsyncAction_StartListeningToEvent* CallFunc_StartListeningToEvent_ReturnValue_2, bool CallFunc_K2_BroadcastEvent_ReturnValue, bool CallFunc_IsValid_ReturnValue_2, AActor* CallFunc_GetOwner_ReturnValue_4, AActor* CallFunc_GetOwner_ReturnValue_5, bool CallFunc_K2_BroadcastEvent_ReturnValue_1, bool CallFunc_K2_BroadcastEvent_ReturnValue_2, AActor* CallFunc_GetOwner_ReturnValue_6, AActor* CallFunc_GetOwner_ReturnValue_7, bool CallFunc_K2_BroadcastEvent_ReturnValue_3, bool CallFunc_K2_BroadcastEvent_ReturnValue_4, AActor* CallFunc_GetOwner_ReturnValue_8, AActor* CallFunc_GetOwner_ReturnValue_9, bool CallFunc_K2_BroadcastEvent_ReturnValue_5, bool CallFunc_K2_BroadcastEvent_ReturnValue_6, AActor* CallFunc_GetOwner_ReturnValue_10, bool CallFunc_K2_BroadcastEvent_ReturnValue_7, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_11, AActor* CallFunc_GetOwner_ReturnValue_11, UAsyncAction_StartListeningToEvent* CallFunc_StartListeningToEvent_ReturnValue_3, bool CallFunc_IsValid_ReturnValue_3); // 0x000545D2 [Final | UbergraphFunction | HasDefaults]
        void    BP_StartPurchaseInvoiceOfferQueried(FInstancedStruct& InInvoice, bool bSuccessful, FInstancedStruct& InOffer); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
        void    BP_StartPurchaseInvoice(FInstancedStruct& InInvoice, bool bInSuccessful, FString InErrorCode); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
        void    BP_ShowOffersDialog(FGuid& InCatalogId, TArray<FInstancedStruct>& InOffers, FText& InTitle); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
        void    BP_OnPurchasedInvoice(FInstancedStruct& InInvoice, bool bSuccessful, FInstancedStruct& InReceipt, FString InErrorCode); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
        void    BP_OnOwnedProductQuantitiesChanged(TMap<FString, int64>& InOwnedProductQuantities); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
        void    BP_OnIntentPurchaseOfferFailed(FGuid& InOfferInstanceId); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
        void    BP_OnFinalizedPurchaseResult(FInstancedStruct& InReceipt, bool bSuccessful); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
        void    BP_CloseOffersDialog(bool bForce); // 0x000545D2 [Event | Protected | BlueprintEvent]
    };
}

