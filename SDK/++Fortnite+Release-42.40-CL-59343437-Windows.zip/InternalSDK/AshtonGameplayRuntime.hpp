/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AshtonGameplayRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x001310 (0x000070)
    class alignas(0x8) UAshtonShieldLayerAnimInstance : public UBallisticShieldItemLayerAnimInstance
    {
    public:
        bool                    bIsShieldHit;                                   // 0x0012A0 (0x000001) [Default: false]
        uint8                   UnknownData_0012A1[0x000003];                   // 0x0012A1 (0x000003)
        float                   ShieldHitAlpha;                                 // 0x0012A4 (0x000004) [Default: 0f]
        FGameplayTag            UnusableTagName;                                // 0x0012A8 (0x000004)
        FGameplayTag            ShieldChargeTagName;                            // 0x0012AC (0x000004)
        UFortWeaponAnimSet*     AshtonShieldThrowAnimAssetFortWeaponAnimSet;    // 0x0012B0 (0x000008) [Default: nullptr]
        UFortWeaponAnimSet*     AshtonShieldAnimAssetFortWeaponAnimSet;         // 0x0012B8 (0x000008) [Default: nullptr]
        UProxyTable*            DefaultNoWeaponProxyTable;                      // 0x0012C0 (0x000008) [Default: nullptr]
        FFortPlayerAnimAssets   PlayerAnimAssetsOverride;                       // 0x0012C8 (0x000010)
        uint8                   UnknownData_0012D8[0x000038];                   // 0x0012D8 (0x000038)
    };
    // Size: 0x000028 (0x000000)
    class IAshtonShieldWeaponInterface : public IInterface
    {
    public:
    
    public: // Functions
        void    GetAshtonShieldData(FScalableFloat& BlockHealth, float& DamageCount); // 0x07FBBE28 [Native | Event | Public | HasOutParms | BlueprintEvent]
    };
}

