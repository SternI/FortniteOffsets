/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BattleRoyaleGame
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0000C0 (0x000000)
    class UFortGameStateComponent_BattleRoyalePlacementInfo : public UFortGameStateComponent_PlacementInfo
    {
    public:
    };
}

