/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BladeHazardRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000938 (0x000018)
    class alignas(0x8) AFortBladeHazard : public ABuildingGameplayActor
    {
    public:
        EFortSawBladeSpinningDirection  SpinningDirection;              // 0x000920 (0x000001) [Default: EFortSawBladeSpinningDirection(0)]
        uint8                           UnknownData_000921[0x000007];   // 0x000921 (0x000007)
        TArray<FTransform>              CustomForceDirections;          // 0x000928 (0x000010)
    
    public: // Functions
        FVector GetForceDirectionForHit(FHitResult& Hit); // 0x080EEFA4 [Final | Native | Protected | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure | Const]
    };
}

