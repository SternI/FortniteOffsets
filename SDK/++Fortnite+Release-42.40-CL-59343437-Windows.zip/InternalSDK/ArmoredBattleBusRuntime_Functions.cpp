/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArmoredBattleBusRuntime_Functions
 * ============================================================
 */

#include "ArmoredBattleBusRuntime_Functions.hpp"

namespace UE
{

    void UFortArmoredBattleBusPassengerAnimInstance::GenerateCharacterPitchAndYawForSlopedTerrain(AFortAthenaVehicle* VehicleActor, float& TurretYaw, float& TurretPitch, FRotator& PawnYawRotator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GenerateCharacterPitchAndYawForSlopedTerrain");
    
        UFortArmoredBattleBusPassengerAnimInstance___GenerateCharacterPitchAndYawForSlopedTerrain_Params Params{};
        Params.VehicleActor = VehicleActor;
        Params.TurretYaw = TurretYaw;
        Params.TurretPitch = TurretPitch;
        Params.PawnYawRotator = PawnYawRotator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        TurretYaw = Params.TurretYaw;
        TurretPitch = Params.TurretPitch;
        PawnYawRotator = Params.PawnYawRotator;
    }

    FTransform UFortArmoredBattleBusPassengerAnimInstance::GetFootAttachTransform(USkeletalMeshComponent* BusMeshComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetFootAttachTransform");
    
        UFortArmoredBattleBusPassengerAnimInstance___GetFootAttachTransform_Params Params{};
        Params.BusMeshComponent = BusMeshComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FVector UFortArmoredBattleBusPassengerAnimInstance::GetHandAttachLocation(USkeletalMeshComponent* BusMeshComponent, FName FrontHandAttachBoneName, FName RearHandAttachBoneName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetHandAttachLocation");
    
        UFortArmoredBattleBusPassengerAnimInstance___GetHandAttachLocation_Params Params{};
        Params.BusMeshComponent = BusMeshComponent;
        Params.FrontHandAttachBoneName = FrontHandAttachBoneName;
        Params.RearHandAttachBoneName = RearHandAttachBoneName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FTransform UFortArmoredBattleBusPassengerAnimInstance::GetPassengerTransform(USkeletalMeshComponent* BusMeshComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetPassengerTransform");
    
        UFortArmoredBattleBusPassengerAnimInstance___GetPassengerTransform_Params Params{};
        Params.BusMeshComponent = BusMeshComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FVector UFortArmoredBattleBusPassengerAnimInstance::UnrotateHandAttachLocation(FVector& HandLocation, FVector& FootLocation, FRotator& FootRotation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UnrotateHandAttachLocation");
    
        UFortArmoredBattleBusPassengerAnimInstance___UnrotateHandAttachLocation_Params Params{};
        Params.HandLocation = HandLocation;
        Params.FootLocation = FootLocation;
        Params.FootRotation = FootRotation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        HandLocation = Params.HandLocation;
        FootLocation = Params.FootLocation;
        FootRotation = Params.FootRotation;
    
        return Params.ReturnValue;
    }

    void UFortArmoredBattleBusPassengerAnimInstance::UpdateHandPositionsSlopeValues(USkeletalMeshComponent* BusMeshComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateHandPositionsSlopeValues");
    
        UFortArmoredBattleBusPassengerAnimInstance___UpdateHandPositionsSlopeValues_Params Params{};
        Params.BusMeshComponent = BusMeshComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortArmoredBattleBusPassengerAnimInstance::UpdateSmoothedVehicleYawRate(AFortAthenaVehicle* VehicleActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateSmoothedVehicleYawRate");
    
        UFortArmoredBattleBusPassengerAnimInstance___UpdateSmoothedVehicleYawRate_Params Params{};
        Params.VehicleActor = VehicleActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortArmoredBattleBusPassengerAnimInstance::UpdateYawDeltaSmoothed(AFortAthenaVehicle* VehicleActor, FName SocketName, FRotator& NewRotation, float& SmoothedYawValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateYawDeltaSmoothed");
    
        UFortArmoredBattleBusPassengerAnimInstance___UpdateYawDeltaSmoothed_Params Params{};
        Params.VehicleActor = VehicleActor;
        Params.SocketName = SocketName;
        Params.NewRotation = NewRotation;
        Params.SmoothedYawValue = SmoothedYawValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        NewRotation = Params.NewRotation;
        SmoothedYawValue = Params.SmoothedYawValue;
    }

    void UFortArmoredBattleBusVehicleAnimInstance::GetPitchAndYaw(AFortAthenaVehicle* VehicleActor, AFortPlayerPawn* GunnerActor, float& AdjustedPitch, float& AdjustedYaw, bool& bIsLocalPlayerControlled, FRotator& YawRotator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance.GetPitchAndYaw");
    
        UFortArmoredBattleBusVehicleAnimInstance___GetPitchAndYaw_Params Params{};
        Params.VehicleActor = VehicleActor;
        Params.GunnerActor = GunnerActor;
        Params.AdjustedPitch = AdjustedPitch;
        Params.AdjustedYaw = AdjustedYaw;
        Params.bIsLocalPlayerControlled = bIsLocalPlayerControlled;
        Params.YawRotator = YawRotator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        AdjustedPitch = Params.AdjustedPitch;
        AdjustedYaw = Params.AdjustedYaw;
        bIsLocalPlayerControlled = Params.bIsLocalPlayerControlled;
        YawRotator = Params.YawRotator;
    }

    float UFortArmoredBattleBusVehicleAnimInstance::UpdateSmoothedVehicleYawRate(AFortAthenaVehicle* VehicleActor, FRotator PreviousRotator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance.UpdateSmoothedVehicleYawRate");
    
        UFortArmoredBattleBusVehicleAnimInstance___UpdateSmoothedVehicleYawRate_Params Params{};
        Params.VehicleActor = VehicleActor;
        Params.PreviousRotator = PreviousRotator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortArmoredBattleBusVehicleAnimInstance::UpdateTurretAimPitchWeaponYaw(AFortAthenaVehicle* OwnerVehicle, AFortPlayerPawn* GunnerActor, FName SocketName, float YawOffset, float& TurretAimPitch, float& YawDeltaSmoothed, FRotator& WeaponYaw)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance.UpdateTurretAimPitchWeaponYaw");
    
        UFortArmoredBattleBusVehicleAnimInstance___UpdateTurretAimPitchWeaponYaw_Params Params{};
        Params.OwnerVehicle = OwnerVehicle;
        Params.GunnerActor = GunnerActor;
        Params.SocketName = SocketName;
        Params.YawOffset = YawOffset;
        Params.TurretAimPitch = TurretAimPitch;
        Params.YawDeltaSmoothed = YawDeltaSmoothed;
        Params.WeaponYaw = WeaponYaw;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        TurretAimPitch = Params.TurretAimPitch;
        YawDeltaSmoothed = Params.YawDeltaSmoothed;
        WeaponYaw = Params.WeaponYaw;
    }

    float UFortArmoredBattleBusVehicleAnimInstance::UpdateYawDeltaSmoothed(AFortAthenaVehicle* VehicleActor, FName SocketName, FRotator NewRotation, float SmoothedYawValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance.UpdateYawDeltaSmoothed");
    
        UFortArmoredBattleBusVehicleAnimInstance___UpdateYawDeltaSmoothed_Params Params{};
        Params.VehicleActor = VehicleActor;
        Params.SocketName = SocketName;
        Params.NewRotation = NewRotation;
        Params.SmoothedYawValue = SmoothedYawValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

} // namespace UE

