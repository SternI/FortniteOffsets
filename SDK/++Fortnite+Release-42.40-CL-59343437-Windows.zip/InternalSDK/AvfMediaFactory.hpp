/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AvfMediaFactory
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000030 (0x000008)
    class UAvfMediaSettings : public UObject
    {
    public:
        bool    NativeAudioOut;                 // 0x000028 (0x000001) [Default: false]
        uint8   UnknownData_000029[0x000007];   // 0x000029 (0x000007)
    };
}

