/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioGameplayBehavior_Functions
 * ============================================================
 */

#include "AudioGameplayBehavior.hpp"

namespace UE
{

    struct UAudioGameplayBehavior___BP_OnGroupSet_Params
    {
        UAudioComponentGroup*   SoundGroup; // 0x000000 (0x000008) [Default: 0x148ED210]
    };

    struct UAudioGameplayBehavior___GetBoolParamValue_Params
    {
        FName   ParamName;      // 0x000000 (0x000004) [Default: FName(344904208) -> L""]
        bool    ReturnValue;    // 0x000004 (0x000001) [ReturnValue] [Default: false]
    };

    struct UAudioGameplayBehavior___GetFloatParamValue_Params
    {
        FName   ParamName;      // 0x000000 (0x000004) [Default: FName(344904208) -> L""]
        float   ReturnValue;    // 0x000004 (0x000004) [ReturnValue] [Default: 0f]
    };

    struct UAudioGameplayBehavior___GetPlayState_Params
    {
        EAudioGameplayBehaviorPlayState ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EAudioGameplayBehaviorPlayState(16)]
    };

    struct UAudioGameplayBehavior___GetSoundGroup_Params
    {
        UAudioComponentGroup*   ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x148ED210]
    };

    struct UAudioGameplayBehavior___GetStopState_Params
    {
        EAudioGameplayBehaviorPlayState ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EAudioGameplayBehaviorPlayState(16)]
    };

    struct UAudioGameplayBehavior___GetStringParamValue_Params
    {
        FName   ParamName;                      // 0x000000 (0x000004) [Default: FName(344904208) -> L""]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FString ReturnValue;                    // 0x000008 (0x000010) [ReturnValue] [Default: L""]
    };

    struct UAudioGameplayBehavior___IsPlayingAny_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioGameplayBehavior___IsVirtualized_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioGameplayBehavior___PlayFrom_Params
    {
        UAudioComponentGroup*   SoundGroup; // 0x000000 (0x000008) [Default: 0x148ED210]
    };

    struct UAudioGameplayBehavior___PlaySound_Params
    {
        USoundBase*         Sound;                          // 0x000000 (0x000008) [Default: 0x148ED210]
        float               InFadeInTime;                   // 0x000008 (0x000004) [Default: 6.86636e-44f]
        float               InTargetVolume;                 // 0x00000C (0x000004) [Default: -4.46502e-26f]
        float               InStartTime;                    // 0x000010 (0x000004) [Default: 1.30158e-23f]
        bool                bDisableAttenuation;            // 0x000014 (0x000001) [Default: false]
        EAudioFaderCurve    InFadeCurve;                    // 0x000015 (0x000001) [Default: EAudioFaderCurve(0)]
        uint8               UnknownData_000016[0x000002];   // 0x000016 (0x000002)
        FVector             InRelativeLocation;             // 0x000018 (0x000018)
        FRotator            InRelativeRotation;             // 0x000030 (0x000018)
        FActiveVoice        ReturnValue;                    // 0x000048 (0x000018) [ReturnValue]
    };

    struct UAudioGameplayBehavior___SetPlayState_Params
    {
        EAudioGameplayBehaviorPlayState NewState;   // 0x000000 (0x000001) [Default: EAudioGameplayBehaviorPlayState(16)]
    };

    struct UAudioGameplayBehavior___StopAllPlayingVoices_Params
    {
        float   InFadeOutTime;  // 0x000000 (0x000004) [Default: 1.44212e-26f]
    };

    struct UAudioGameplayBehavior___StopById_Params
    {
        FPlayingId          ID;             // 0x000000 (0x000004)
        float               InFadeOutTime;  // 0x000004 (0x000004) [Default: 0f]
        EAudioFaderCurve    InFadeCurve;    // 0x000008 (0x000001) [Default: EAudioFaderCurve(49)]
    };

    struct UAudioGameplayBehavior___StopComponent_Params
    {
        UAudioComponent*    Comp;           // 0x000000 (0x000008) [Default: 0x148ED210]
        float               InFadeOutTime;  // 0x000008 (0x000004) [Default: 6.86636e-44f]
        EAudioFaderCurve    InFadeCurve;    // 0x00000C (0x000001) [Default: EAudioFaderCurve(221)]
    };

    struct UAudioGameplayBehavior___StopSound_Params
    {
        USoundBase*         Sound;          // 0x000000 (0x000008) [Default: 0x148ED210]
        float               InFadeOutTime;  // 0x000008 (0x000004) [Default: 6.86636e-44f]
        EAudioFaderCurve    InFadeCurve;    // 0x00000C (0x000001) [Default: EAudioFaderCurve(221)]
    };

    struct UAudioGameplayBehavior___SubscribeToBoolParam_Params
    {
        FName               ParamName;  // 0x000000 (0x000004) [Default: FName(344904208) -> L""]
        BoolParamCallback   Delegate;   // 0x000004 (0x00000C)
    };

    struct UAudioGameplayBehavior___SubscribeToEvent_Params
    {
        FName           EventName;  // 0x000000 (0x000004) [Default: FName(344904208) -> L""]
        SoundCallback   Delegate;   // 0x000004 (0x00000C)
    };

    struct UAudioGameplayBehavior___SubscribeToStringParam_Params
    {
        FName               ParamName;  // 0x000000 (0x000004) [Default: FName(344904208) -> L""]
        StringParamCallback Delegate;   // 0x000004 (0x00000C)
    };

} // namespace UE

