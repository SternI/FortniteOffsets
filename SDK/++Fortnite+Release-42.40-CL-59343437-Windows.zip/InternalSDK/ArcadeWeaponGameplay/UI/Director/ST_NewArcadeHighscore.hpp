/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /ArcadeWeaponGameplay/UI/Director/ST_NewArcadeHighscore
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000004 (0x000004)
    struct alignas(0x4) FST_NewArcadeHighscore
    {
        int32   NewHS_4_F44E53994BFECFFDCC61B4AEAA3E713F;   // 0x000000 (0x000004) [Default: 0]
    };
}

