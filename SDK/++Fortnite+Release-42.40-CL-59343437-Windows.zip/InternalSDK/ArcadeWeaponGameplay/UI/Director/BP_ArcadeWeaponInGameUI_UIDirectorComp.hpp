/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:44
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /ArcadeWeaponGameplay/UI/Director/BP_ArcadeWeaponInGameUI_UIDirectorComp
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000100 (0x000040)
    class alignas(0x8) UBP_ArcadeWeaponInGameUI_UIDirectorComp_C : public UFortDynamicUIDirectorComponent
    {
    public:
        FPointerToUberGraphFrame            UberGraphFrame;                 // 0x0000C0 (0x000008)
        UAsyncAction_StartListeningToEvent* WeaponEquippedHandle;           // 0x0000C8 (0x000008) [Default: nullptr]
        UAsyncAction_StartListeningToEvent* WeaponUnequippedHandle;         // 0x0000D0 (0x000008) [Default: nullptr]
        UDynamicUIScene*                    ArcadeWeaponInfoScene;          // 0x0000D8 (0x000008) [Default: nullptr]
        FTimerHandle                        RemoveSceneTimerHandle;         // 0x0000E0 (0x000008)
        AFortWeapon*                        Current_Weapon;                 // 0x0000E8 (0x000008) [Default: nullptr]
        bool                                HighScoreShown;                 // 0x0000F0 (0x000001) [Default: false]
        uint8                               UnknownData_0000F1[0x000007];   // 0x0000F1 (0x000007)
        UBPC_ArcadeWeaponScoreManager_C*    ArcadeScoreComponent;           // 0x0000F8 (0x000008) [Default: nullptr]
    
    public: // Functions
        void    AddArcadeWeaponInfoScene(AFortDynamicUIDirector* CallFunc_GetOwningFortDynamicUIDirector_ReturnValue, bool CallFunc_IsSceneActive_ReturnValue); // 0x000545D2 [Public | BlueprintCallable | BlueprintEvent]
        void    ExecuteUbergraph_BP_ArcadeWeaponInGameUI_UIDirectorComp(int32 EntryPoint, FFortEvent_WeaponEquipped Temp_struct_Variable, UBPC_WeaponScore_C* CallFunc_GetComponentByClass_ReturnValue, bool CallFunc_IsValid_ReturnValue, AsyncGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate, UAsyncAction_StartListeningToEvent* K2Node_CustomEvent_ProxyObject, FFortEvent_WeaponEquipped Temp_struct_Variable_1, UAsyncAction_StartListeningToEvent* Temp_object_Variable, bool CallFunc_GetPayload_ReturnValue, OnNewHighScore K2Node_CreateDelegate_OutputDelegate_1, bool CallFunc_IsValid_ReturnValue_1, bool CallFunc_IsValid_ReturnValue_2, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue, APlayerController* CallFunc_GetOwningLocalPlayerController_ReturnValue, FFortEvent_WeaponEquipped Temp_struct_Variable_2, AFortPlayerController* K2Node_DynamicCast_AsFort_Player_Controller, bool K2Node_DynamicCast_bSuccess, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_1, UAsyncAction_StartListeningToEvent* CallFunc_StartListeningToEvent_ReturnValue, UAsyncAction_StartListeningToEvent* CallFunc_StartListeningToEvent_ReturnValue_1, bool CallFunc_IsValid_ReturnValue_3, bool CallFunc_IsValid_ReturnValue_4, TEnumAsByte<EEndPlayReason> K2Node_Event_EndPlayReason, APlayerController* CallFunc_GetOwningLocalPlayerController_ReturnValue_1, int32 K2Node_CustomEvent_NewHighScore, FST_NewArcadeHighscore K2Node_MakeStruct_ST_NewArcadeHighscore, UBPC_ArcadeWeaponScoreManager_C* CallFunc_GetComponentByClass_ReturnValue_1, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_2, bool CallFunc_K2_BroadcastEvent_ReturnValue, UAsyncAction_StartListeningToEvent* Temp_object_Variable_1, FFortEvent_WeaponEquipped Temp_struct_Variable_3, bool CallFunc_GetPayload_ReturnValue_1, bool CallFunc_Not_PreBool_ReturnValue, APlayerController* CallFunc_GetOwningLocalPlayerController_ReturnValue_2, UBPC_ArcadeWeaponScoreManager_C* CallFunc_GetComponentByClass_ReturnValue_2, UBPC_WeaponScore_C* CallFunc_GetComponentByClass_ReturnValue_3, int32 CallFunc_GetHighScore_ReturnValue, bool CallFunc_IsValid_ReturnValue_5, bool CallFunc_NotEqual_IntInt_ReturnValue, bool CallFunc_BooleanAND_ReturnValue, UAsyncAction_StartListeningToEvent* K2Node_CustomEvent_ProxyObject_1, AsyncGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate_2); // 0x000545D2 [Final | UbergraphFunction | HasDefaults]
        void    HandleWeaponEquipped(UDynamicUIScene* Temp_object_Variable, UDynamicUIScene* Temp_object_Variable_1, bool Temp_bool_Variable, APlayerController* CallFunc_GetOwningLocalPlayerController_ReturnValue, bool CallFunc_IsUsingInputType_ReturnValue, bool CallFunc_IsValid_ReturnValue, UDynamicUIScene* K2Node_Select_Default, UBPC_WeaponScore_C* CallFunc_GetComponentByClass_ReturnValue, bool CallFunc_IsValid_ReturnValue_1); // 0x000545D2 [Public | BlueprintCallable | BlueprintEvent]
        void    HandleWeaponUnequipped(AFortWeapon* PreviousWeapon, FTimerHandle CallFunc_K2_SetTimer_ReturnValue, UBPC_WeaponScore_C* CallFunc_GetComponentByClass_ReturnValue, bool CallFunc_IsValid_ReturnValue, bool CallFunc_IsValid_ReturnValue_1); // 0x000545D2 [Public | HasDefaults | BlueprintCallable | BlueprintEvent]
        void    OnEventReceived_078A7C334A39C0F1B16B07AA030406BB(UAsyncAction_StartListeningToEvent* ProxyObject); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnEventReceived_0F3BC3114554695278E0F793C6DA0E6E(UAsyncAction_StartListeningToEvent* ProxyObject); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnReadyToShowUI(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    ReceiveEndPlay(TEnumAsByte<EEndPlayReason> EndPlayReason); // 0x000545D2 [Event | Public | BlueprintEvent]
        void    RemoveArcadeWeaponInfoScene(AFortDynamicUIDirector* CallFunc_GetOwningFortDynamicUIDirector_ReturnValue, bool CallFunc_IsSceneActive_ReturnValue); // 0x000545D2 [Public | BlueprintCallable | BlueprintEvent]
        void    SendNewHighScore(int32 NewHighScore); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
    };
}

