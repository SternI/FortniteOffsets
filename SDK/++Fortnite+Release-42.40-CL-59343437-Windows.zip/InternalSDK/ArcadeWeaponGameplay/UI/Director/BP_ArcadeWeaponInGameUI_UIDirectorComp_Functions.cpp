/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:44
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /ArcadeWeaponGameplay/UI/Director/BP_ArcadeWeaponInGameUI_UIDirectorComp_Functions
 * ============================================================
 */

#include "BP_ArcadeWeaponInGameUI_UIDirectorComp_Functions.hpp"

namespace UE
{

    void UBP_ArcadeWeaponInGameUI_UIDirectorComp_C::AddArcadeWeaponInfoScene(AFortDynamicUIDirector* CallFunc_GetOwningFortDynamicUIDirector_ReturnValue, bool CallFunc_IsSceneActive_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_ArcadeWeaponInGameUI_UIDirectorComp.BP_ArcadeWeaponInGameUI_UIDirectorComp_C.AddArcadeWeaponInfoScene");
    
        UBP_ArcadeWeaponInGameUI_UIDirectorComp_C___AddArcadeWeaponInfoScene_Params Params{};
        Params.CallFunc_GetOwningFortDynamicUIDirector_ReturnValue = CallFunc_GetOwningFortDynamicUIDirector_ReturnValue;
        Params.CallFunc_IsSceneActive_ReturnValue = CallFunc_IsSceneActive_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_ArcadeWeaponInGameUI_UIDirectorComp_C::ExecuteUbergraph_BP_ArcadeWeaponInGameUI_UIDirectorComp(int32 EntryPoint, FFortEvent_WeaponEquipped Temp_struct_Variable, UBPC_WeaponScore_C* CallFunc_GetComponentByClass_ReturnValue, bool CallFunc_IsValid_ReturnValue, AsyncGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate, UAsyncAction_StartListeningToEvent* K2Node_CustomEvent_ProxyObject, FFortEvent_WeaponEquipped Temp_struct_Variable_1, UAsyncAction_StartListeningToEvent* Temp_object_Variable, bool CallFunc_GetPayload_ReturnValue, OnNewHighScore K2Node_CreateDelegate_OutputDelegate_1, bool CallFunc_IsValid_ReturnValue_1, bool CallFunc_IsValid_ReturnValue_2, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue, APlayerController* CallFunc_GetOwningLocalPlayerController_ReturnValue, FFortEvent_WeaponEquipped Temp_struct_Variable_2, AFortPlayerController* K2Node_DynamicCast_AsFort_Player_Controller, bool K2Node_DynamicCast_bSuccess, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_1, UAsyncAction_StartListeningToEvent* CallFunc_StartListeningToEvent_ReturnValue, UAsyncAction_StartListeningToEvent* CallFunc_StartListeningToEvent_ReturnValue_1, bool CallFunc_IsValid_ReturnValue_3, bool CallFunc_IsValid_ReturnValue_4, TEnumAsByte<EEndPlayReason> K2Node_Event_EndPlayReason, APlayerController* CallFunc_GetOwningLocalPlayerController_ReturnValue_1, int32 K2Node_CustomEvent_NewHighScore, FST_NewArcadeHighscore K2Node_MakeStruct_ST_NewArcadeHighscore, UBPC_ArcadeWeaponScoreManager_C* CallFunc_GetComponentByClass_ReturnValue_1, UGameplayEventRouterComponent* CallFunc_GetGlobalEventRouter_ReturnValue_2, bool CallFunc_K2_BroadcastEvent_ReturnValue, UAsyncAction_StartListeningToEvent* Temp_object_Variable_1, FFortEvent_WeaponEquipped Temp_struct_Variable_3, bool CallFunc_GetPayload_ReturnValue_1, bool CallFunc_Not_PreBool_ReturnValue, APlayerController* CallFunc_GetOwningLocalPlayerController_ReturnValue_2, UBPC_ArcadeWeaponScoreManager_C* CallFunc_GetComponentByClass_ReturnValue_2, UBPC_WeaponScore_C* CallFunc_GetComponentByClass_ReturnValue_3, int32 CallFunc_GetHighScore_ReturnValue, bool CallFunc_IsValid_ReturnValue_5, bool CallFunc_NotEqual_IntInt_ReturnValue, bool CallFunc_BooleanAND_ReturnValue, UAsyncAction_StartListeningToEvent* K2Node_CustomEvent_ProxyObject_1, AsyncGameplayEventDelegate K2Node_CreateDelegate_OutputDelegate_2)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_ArcadeWeaponInGameUI_UIDirectorComp.BP_ArcadeWeaponInGameUI_UIDirectorComp_C.ExecuteUbergraph_BP_ArcadeWeaponInGameUI_UIDirectorComp");
    
        UBP_ArcadeWeaponInGameUI_UIDirectorComp_C___ExecuteUbergraph_BP_ArcadeWeaponInGameUI_UIDirectorComp_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.Temp_struct_Variable = Temp_struct_Variable;
        Params.CallFunc_GetComponentByClass_ReturnValue = CallFunc_GetComponentByClass_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.K2Node_CreateDelegate_OutputDelegate = K2Node_CreateDelegate_OutputDelegate;
        Params.K2Node_CustomEvent_ProxyObject = K2Node_CustomEvent_ProxyObject;
        Params.Temp_struct_Variable_1 = Temp_struct_Variable_1;
        Params.Temp_object_Variable = Temp_object_Variable;
        Params.CallFunc_GetPayload_ReturnValue = CallFunc_GetPayload_ReturnValue;
        Params.K2Node_CreateDelegate_OutputDelegate_1 = K2Node_CreateDelegate_OutputDelegate_1;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
        Params.CallFunc_IsValid_ReturnValue_2 = CallFunc_IsValid_ReturnValue_2;
        Params.CallFunc_GetGlobalEventRouter_ReturnValue = CallFunc_GetGlobalEventRouter_ReturnValue;
        Params.CallFunc_GetOwningLocalPlayerController_ReturnValue = CallFunc_GetOwningLocalPlayerController_ReturnValue;
        Params.Temp_struct_Variable_2 = Temp_struct_Variable_2;
        Params.K2Node_DynamicCast_AsFort_Player_Controller = K2Node_DynamicCast_AsFort_Player_Controller;
        Params.K2Node_DynamicCast_bSuccess = K2Node_DynamicCast_bSuccess;
        Params.CallFunc_GetGlobalEventRouter_ReturnValue_1 = CallFunc_GetGlobalEventRouter_ReturnValue_1;
        Params.CallFunc_StartListeningToEvent_ReturnValue = CallFunc_StartListeningToEvent_ReturnValue;
        Params.CallFunc_StartListeningToEvent_ReturnValue_1 = CallFunc_StartListeningToEvent_ReturnValue_1;
        Params.CallFunc_IsValid_ReturnValue_3 = CallFunc_IsValid_ReturnValue_3;
        Params.CallFunc_IsValid_ReturnValue_4 = CallFunc_IsValid_ReturnValue_4;
        Params.K2Node_Event_EndPlayReason = K2Node_Event_EndPlayReason;
        Params.CallFunc_GetOwningLocalPlayerController_ReturnValue_1 = CallFunc_GetOwningLocalPlayerController_ReturnValue_1;
        Params.K2Node_CustomEvent_NewHighScore = K2Node_CustomEvent_NewHighScore;
        Params.K2Node_MakeStruct_ST_NewArcadeHighscore = K2Node_MakeStruct_ST_NewArcadeHighscore;
        Params.CallFunc_GetComponentByClass_ReturnValue_1 = CallFunc_GetComponentByClass_ReturnValue_1;
        Params.CallFunc_GetGlobalEventRouter_ReturnValue_2 = CallFunc_GetGlobalEventRouter_ReturnValue_2;
        Params.CallFunc_K2_BroadcastEvent_ReturnValue = CallFunc_K2_BroadcastEvent_ReturnValue;
        Params.Temp_object_Variable_1 = Temp_object_Variable_1;
        Params.Temp_struct_Variable_3 = Temp_struct_Variable_3;
        Params.CallFunc_GetPayload_ReturnValue_1 = CallFunc_GetPayload_ReturnValue_1;
        Params.CallFunc_Not_PreBool_ReturnValue = CallFunc_Not_PreBool_ReturnValue;
        Params.CallFunc_GetOwningLocalPlayerController_ReturnValue_2 = CallFunc_GetOwningLocalPlayerController_ReturnValue_2;
        Params.CallFunc_GetComponentByClass_ReturnValue_2 = CallFunc_GetComponentByClass_ReturnValue_2;
        Params.CallFunc_GetComponentByClass_ReturnValue_3 = CallFunc_GetComponentByClass_ReturnValue_3;
        Params.CallFunc_GetHighScore_ReturnValue = CallFunc_GetHighScore_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_5 = CallFunc_IsValid_ReturnValue_5;
        Params.CallFunc_NotEqual_IntInt_ReturnValue = CallFunc_NotEqual_IntInt_ReturnValue;
        Params.CallFunc_BooleanAND_ReturnValue = CallFunc_BooleanAND_ReturnValue;
        Params.K2Node_CustomEvent_ProxyObject_1 = K2Node_CustomEvent_ProxyObject_1;
        Params.K2Node_CreateDelegate_OutputDelegate_2 = K2Node_CreateDelegate_OutputDelegate_2;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_ArcadeWeaponInGameUI_UIDirectorComp_C::HandleWeaponEquipped(UDynamicUIScene* Temp_object_Variable, UDynamicUIScene* Temp_object_Variable_1, bool Temp_bool_Variable, APlayerController* CallFunc_GetOwningLocalPlayerController_ReturnValue, bool CallFunc_IsUsingInputType_ReturnValue, bool CallFunc_IsValid_ReturnValue, UDynamicUIScene* K2Node_Select_Default, UBPC_WeaponScore_C* CallFunc_GetComponentByClass_ReturnValue, bool CallFunc_IsValid_ReturnValue_1)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_ArcadeWeaponInGameUI_UIDirectorComp.BP_ArcadeWeaponInGameUI_UIDirectorComp_C.HandleWeaponEquipped");
    
        UBP_ArcadeWeaponInGameUI_UIDirectorComp_C___HandleWeaponEquipped_Params Params{};
        Params.Temp_object_Variable = Temp_object_Variable;
        Params.Temp_object_Variable_1 = Temp_object_Variable_1;
        Params.Temp_bool_Variable = Temp_bool_Variable;
        Params.CallFunc_GetOwningLocalPlayerController_ReturnValue = CallFunc_GetOwningLocalPlayerController_ReturnValue;
        Params.CallFunc_IsUsingInputType_ReturnValue = CallFunc_IsUsingInputType_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.K2Node_Select_Default = K2Node_Select_Default;
        Params.CallFunc_GetComponentByClass_ReturnValue = CallFunc_GetComponentByClass_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_ArcadeWeaponInGameUI_UIDirectorComp_C::HandleWeaponUnequipped(AFortWeapon* PreviousWeapon, FTimerHandle CallFunc_K2_SetTimer_ReturnValue, UBPC_WeaponScore_C* CallFunc_GetComponentByClass_ReturnValue, bool CallFunc_IsValid_ReturnValue, bool CallFunc_IsValid_ReturnValue_1)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_ArcadeWeaponInGameUI_UIDirectorComp.BP_ArcadeWeaponInGameUI_UIDirectorComp_C.HandleWeaponUnequipped");
    
        UBP_ArcadeWeaponInGameUI_UIDirectorComp_C___HandleWeaponUnequipped_Params Params{};
        Params.PreviousWeapon = PreviousWeapon;
        Params.CallFunc_K2_SetTimer_ReturnValue = CallFunc_K2_SetTimer_ReturnValue;
        Params.CallFunc_GetComponentByClass_ReturnValue = CallFunc_GetComponentByClass_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_ArcadeWeaponInGameUI_UIDirectorComp_C::OnEventReceived_078A7C334A39C0F1B16B07AA030406BB(UAsyncAction_StartListeningToEvent* ProxyObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_ArcadeWeaponInGameUI_UIDirectorComp.BP_ArcadeWeaponInGameUI_UIDirectorComp_C.OnEventReceived_078A7C334A39C0F1B16B07AA030406BB");
    
        UBP_ArcadeWeaponInGameUI_UIDirectorComp_C___OnEventReceived_078A7C334A39C0F1B16B07AA030406BB_Params Params{};
        Params.ProxyObject = ProxyObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_ArcadeWeaponInGameUI_UIDirectorComp_C::OnEventReceived_0F3BC3114554695278E0F793C6DA0E6E(UAsyncAction_StartListeningToEvent* ProxyObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_ArcadeWeaponInGameUI_UIDirectorComp.BP_ArcadeWeaponInGameUI_UIDirectorComp_C.OnEventReceived_0F3BC3114554695278E0F793C6DA0E6E");
    
        UBP_ArcadeWeaponInGameUI_UIDirectorComp_C___OnEventReceived_0F3BC3114554695278E0F793C6DA0E6E_Params Params{};
        Params.ProxyObject = ProxyObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_ArcadeWeaponInGameUI_UIDirectorComp_C::OnReadyToShowUI()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_ArcadeWeaponInGameUI_UIDirectorComp.BP_ArcadeWeaponInGameUI_UIDirectorComp_C.OnReadyToShowUI");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBP_ArcadeWeaponInGameUI_UIDirectorComp_C::ReceiveEndPlay(TEnumAsByte<EEndPlayReason> EndPlayReason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_ArcadeWeaponInGameUI_UIDirectorComp.BP_ArcadeWeaponInGameUI_UIDirectorComp_C.ReceiveEndPlay");
    
        UBP_ArcadeWeaponInGameUI_UIDirectorComp_C___ReceiveEndPlay_Params Params{};
        Params.EndPlayReason = EndPlayReason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_ArcadeWeaponInGameUI_UIDirectorComp_C::RemoveArcadeWeaponInfoScene(AFortDynamicUIDirector* CallFunc_GetOwningFortDynamicUIDirector_ReturnValue, bool CallFunc_IsSceneActive_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_ArcadeWeaponInGameUI_UIDirectorComp.BP_ArcadeWeaponInGameUI_UIDirectorComp_C.RemoveArcadeWeaponInfoScene");
    
        UBP_ArcadeWeaponInGameUI_UIDirectorComp_C___RemoveArcadeWeaponInfoScene_Params Params{};
        Params.CallFunc_GetOwningFortDynamicUIDirector_ReturnValue = CallFunc_GetOwningFortDynamicUIDirector_ReturnValue;
        Params.CallFunc_IsSceneActive_ReturnValue = CallFunc_IsSceneActive_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_ArcadeWeaponInGameUI_UIDirectorComp_C::SendNewHighScore(int32 NewHighScore)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_ArcadeWeaponInGameUI_UIDirectorComp.BP_ArcadeWeaponInGameUI_UIDirectorComp_C.SendNewHighScore");
    
        UBP_ArcadeWeaponInGameUI_UIDirectorComp_C___SendNewHighScore_Params Params{};
        Params.NewHighScore = NewHighScore;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

