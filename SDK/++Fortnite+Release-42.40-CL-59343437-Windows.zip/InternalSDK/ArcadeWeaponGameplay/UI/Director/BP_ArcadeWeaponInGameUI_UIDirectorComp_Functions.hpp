/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:44
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /ArcadeWeaponGameplay/UI/Director/BP_ArcadeWeaponInGameUI_UIDirectorComp_Functions
 * ============================================================
 */

#include "BP_ArcadeWeaponInGameUI_UIDirectorComp.hpp"

namespace UE
{

    struct UBP_ArcadeWeaponInGameUI_UIDirectorComp_C___AddArcadeWeaponInfoScene_Params
    {
        AFortDynamicUIDirector* CallFunc_GetOwningFortDynamicUIDirector_ReturnValue;    // 0x000000 (0x000008) [Default: 0x1447E500]
        bool                    CallFunc_IsSceneActive_ReturnValue;                     // 0x000008 (0x000001) [Default: true]
    };

    struct UBP_ArcadeWeaponInGameUI_UIDirectorComp_C___ExecuteUbergraph_BP_ArcadeWeaponInGameUI_UIDirectorComp_Params
    {
        int32                               EntryPoint;                                             // 0x000000 (0x000004) [Default: 340256000]
        uint8                               UnknownData_000004[0x000004];                           // 0x000004 (0x000004)
        FFortEvent_WeaponEquipped           Temp_struct_Variable;                                   // 0x000008 (0x000010)
        UBPC_WeaponScore_C*                 CallFunc_GetComponentByClass_ReturnValue;               // 0x000018 (0x000008) [Default: 0x7FE99A31CDC0]
        bool                                CallFunc_IsValid_ReturnValue;                           // 0x000020 (0x000001) [Default: true]
        uint8                               UnknownData_000021[0x000003];                           // 0x000021 (0x000003)
        AsyncGameplayEventDelegate          K2Node_CreateDelegate_OutputDelegate;                   // 0x000024 (0x00000C)
        UAsyncAction_StartListeningToEvent* K2Node_CustomEvent_ProxyObject;                         // 0x000030 (0x000008) [Default: 0x130A96B0]
        FFortEvent_WeaponEquipped           Temp_struct_Variable_1;                                 // 0x000038 (0x000010)
        UAsyncAction_StartListeningToEvent* Temp_object_Variable;                                   // 0x000048 (0x000008) [Default: nullptr]
        bool                                CallFunc_GetPayload_ReturnValue;                        // 0x000050 (0x000001) [Default: false]
        uint8                               UnknownData_000051[0x000003];                           // 0x000051 (0x000003)
        OnNewHighScore                      K2Node_CreateDelegate_OutputDelegate_1;                 // 0x000054 (0x00000C)
        bool                                CallFunc_IsValid_ReturnValue_1;                         // 0x000060 (0x000001) [Default: false]
        bool                                CallFunc_IsValid_ReturnValue_2;                         // 0x000061 (0x000001) [Default: false]
        uint8                               UnknownData_000062[0x000006];                           // 0x000062 (0x000006)
        UGameplayEventRouterComponent*      CallFunc_GetGlobalEventRouter_ReturnValue;              // 0x000068 (0x000008) [Default: nullptr]
        APlayerController*                  CallFunc_GetOwningLocalPlayerController_ReturnValue;    // 0x000070 (0x000008) [Default: nullptr]
        FFortEvent_WeaponEquipped           Temp_struct_Variable_2;                                 // 0x000078 (0x000010)
        AFortPlayerController*              K2Node_DynamicCast_AsFort_Player_Controller;            // 0x000088 (0x000008) [Default: 0xFFFFFFF]
        bool                                K2Node_DynamicCast_bSuccess;                            // 0x000090 (0x000001) [Default: true]
        uint8                               UnknownData_000091[0x000007];                           // 0x000091 (0x000007)
        UGameplayEventRouterComponent*      CallFunc_GetGlobalEventRouter_ReturnValue_1;            // 0x000098 (0x000008) [Default: 0x1206040]
        UAsyncAction_StartListeningToEvent* CallFunc_StartListeningToEvent_ReturnValue;             // 0x0000A0 (0x000008) [Default: nullptr]
        UAsyncAction_StartListeningToEvent* CallFunc_StartListeningToEvent_ReturnValue_1;           // 0x0000A8 (0x000008) [Default: nullptr]
        bool                                CallFunc_IsValid_ReturnValue_3;                         // 0x0000B0 (0x000001) [Default: false]
        bool                                CallFunc_IsValid_ReturnValue_4;                         // 0x0000B1 (0x000001) [Default: false]
        TEnumAsByte<EEndPlayReason>         K2Node_Event_EndPlayReason;                             // 0x0000B2 (0x000001) [Default: 0]
        uint8                               UnknownData_0000B3[0x000005];                           // 0x0000B3 (0x000005)
        APlayerController*                  CallFunc_GetOwningLocalPlayerController_ReturnValue_1;  // 0x0000B8 (0x000008) [Default: nullptr]
        int32                               K2Node_CustomEvent_NewHighScore;                        // 0x0000C0 (0x000004) [Default: 1484939904]
        FST_NewArcadeHighscore              K2Node_MakeStruct_ST_NewArcadeHighscore;                // 0x0000C4 (0x000004)
        UBPC_ArcadeWeaponScoreManager_C*    CallFunc_GetComponentByClass_ReturnValue_1;             // 0x0000C8 (0x000008) [Default: nullptr]
        UGameplayEventRouterComponent*      CallFunc_GetGlobalEventRouter_ReturnValue_2;            // 0x0000D0 (0x000008) [Default: nullptr]
        bool                                CallFunc_K2_BroadcastEvent_ReturnValue;                 // 0x0000D8 (0x000001) [Default: false]
        uint8                               UnknownData_0000D9[0x000007];                           // 0x0000D9 (0x000007)
        UAsyncAction_StartListeningToEvent* Temp_object_Variable_1;                                 // 0x0000E0 (0x000008) [Default: nullptr]
        FFortEvent_WeaponEquipped           Temp_struct_Variable_3;                                 // 0x0000E8 (0x000010)
        bool                                CallFunc_GetPayload_ReturnValue_1;                      // 0x0000F8 (0x000001) [Default: false]
        bool                                CallFunc_Not_PreBool_ReturnValue;                       // 0x0000F9 (0x000001) [Default: false]
        uint8                               UnknownData_0000FA[0x000006];                           // 0x0000FA (0x000006)
        APlayerController*                  CallFunc_GetOwningLocalPlayerController_ReturnValue_2;  // 0x000100 (0x000008) [Default: 0x12FAF560]
        UBPC_ArcadeWeaponScoreManager_C*    CallFunc_GetComponentByClass_ReturnValue_2;             // 0x000108 (0x000008) [Default: 0xAB4512DD00280001]
        UBPC_WeaponScore_C*                 CallFunc_GetComponentByClass_ReturnValue_3;             // 0x000110 (0x000008) [Default: 0x16A286C0]
        int32                               CallFunc_GetHighScore_ReturnValue;                      // 0x000118 (0x000004) [Default: -651010048]
        bool                                CallFunc_IsValid_ReturnValue_5;                         // 0x00011C (0x000001) [Default: true]
        bool                                CallFunc_NotEqual_IntInt_ReturnValue;                   // 0x00011D (0x000001) [Default: true]
        bool                                CallFunc_BooleanAND_ReturnValue;                        // 0x00011E (0x000001) [Default: false]
        uint8                               UnknownByte_00011F;                                     // 0x00011F (0x000001)
        UAsyncAction_StartListeningToEvent* K2Node_CustomEvent_ProxyObject_1;                       // 0x000120 (0x000008) [Default: 0x14DA2AE0406BC]
        AsyncGameplayEventDelegate          K2Node_CreateDelegate_OutputDelegate_2;                 // 0x000128 (0x00000C)
    };

    struct UBP_ArcadeWeaponInGameUI_UIDirectorComp_C___HandleWeaponEquipped_Params
    {
        UDynamicUIScene*    Temp_object_Variable;                                   // 0x000000 (0x000008) [Default: 0x1447E500]
        UDynamicUIScene*    Temp_object_Variable_1;                                 // 0x000008 (0x000008) [Default: 0xAC4512DD00280031]
        bool                Temp_bool_Variable;                                     // 0x000010 (0x000001) [Default: false]
        uint8               UnknownData_000011[0x000007];                           // 0x000011 (0x000007)
        APlayerController*  CallFunc_GetOwningLocalPlayerController_ReturnValue;    // 0x000018 (0x000008) [Default: 0x7FE99A31CDC0]
        bool                CallFunc_IsUsingInputType_ReturnValue;                  // 0x000020 (0x000001) [Default: true]
        bool                CallFunc_IsValid_ReturnValue;                           // 0x000021 (0x000001) [Default: true]
        uint8               UnknownData_000022[0x000006];                           // 0x000022 (0x000006)
        UDynamicUIScene*    K2Node_Select_Default;                                  // 0x000028 (0x000008) [Default: 0x133D5F70]
        UBPC_WeaponScore_C* CallFunc_GetComponentByClass_ReturnValue;               // 0x000030 (0x000008) [Default: 0x130A96B0]
        bool                CallFunc_IsValid_ReturnValue_1;                         // 0x000038 (0x000001) [Default: true]
    };

    struct UBP_ArcadeWeaponInGameUI_UIDirectorComp_C___HandleWeaponUnequipped_Params
    {
        AFortWeapon*        PreviousWeapon;                             // 0x000000 (0x000008) [Default: 0x1447E500]
        FTimerHandle        CallFunc_K2_SetTimer_ReturnValue;           // 0x000008 (0x000008)
        UBPC_WeaponScore_C* CallFunc_GetComponentByClass_ReturnValue;   // 0x000010 (0x000008) [Default: 0x7FEDD9326000]
        bool                CallFunc_IsValid_ReturnValue;               // 0x000018 (0x000001) [Default: true]
        bool                CallFunc_IsValid_ReturnValue_1;             // 0x000019 (0x000001) [Default: true]
    };

    struct UBP_ArcadeWeaponInGameUI_UIDirectorComp_C___OnEventReceived_078A7C334A39C0F1B16B07AA030406BB_Params
    {
        UAsyncAction_StartListeningToEvent* ProxyObject;    // 0x000000 (0x000008) [Default: 0x1447E500]
    };

    struct UBP_ArcadeWeaponInGameUI_UIDirectorComp_C___OnEventReceived_0F3BC3114554695278E0F793C6DA0E6E_Params
    {
        UAsyncAction_StartListeningToEvent* ProxyObject;    // 0x000000 (0x000008) [Default: 0x1447E500]
    };

    struct UBP_ArcadeWeaponInGameUI_UIDirectorComp_C___ReceiveEndPlay_Params
    {
        TEnumAsByte<EEndPlayReason> EndPlayReason;  // 0x000000 (0x000001) [Default: 0]
    };

    struct UBP_ArcadeWeaponInGameUI_UIDirectorComp_C___RemoveArcadeWeaponInfoScene_Params
    {
        AFortDynamicUIDirector* CallFunc_GetOwningFortDynamicUIDirector_ReturnValue;    // 0x000000 (0x000008) [Default: 0x1447E500]
        bool                    CallFunc_IsSceneActive_ReturnValue;                     // 0x000008 (0x000001) [Default: true]
    };

    struct UBP_ArcadeWeaponInGameUI_UIDirectorComp_C___SendNewHighScore_Params
    {
        int32   NewHighScore;   // 0x000000 (0x000004) [Default: 340256000]
    };

} // namespace UE

