/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:44
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /ArcadeWeaponGameplay/Gameplay/BPC_WeaponScore_Functions
 * ============================================================
 */

#include "BPC_WeaponScore.hpp"

namespace UE
{

    struct UBPC_WeaponScore_C___CheckIfTrickShot_Params
    {
        FTrickShotConfig    ReturnValue;                            // 0x000000 (0x000030) [ReturnValue]
        FTrickShotConfig    CallFunc_CheckIfTrickShot_ReturnValue;  // 0x000030 (0x000030)
    };

    struct UBPC_WeaponScore_C___ExecuteUbergraph_BPC_WeaponScore_Params
    {
        int32                               EntryPoint;                                             // 0x000000 (0x000004) [Default: 344680144]
        uint8                               UnknownData_000004[0x000004];                           // 0x000004 (0x000004)
        FArcadeWeaponScoreData              K2Node_Event_ScoreData;                                 // 0x000008 (0x000048)
        UBPC_ArcadeWeaponScoreManager_C*    CallFunc_GetComponentByClass_ReturnValue;               // 0x000050 (0x000008) [Default: nullptr]
        bool                                CallFunc_Greater_IntInt_ReturnValue;                    // 0x000058 (0x000001) [Default: false]
        bool                                CallFunc_IsValid_ReturnValue;                           // 0x000059 (0x000001) [Default: false]
        bool                                CallFunc_BooleanAND_ReturnValue;                        // 0x00005A (0x000001) [Default: false]
        uint8                               UnknownData_00005B[0x000005];                           // 0x00005B (0x000005)
        AActor*                             CallFunc_GetOwner_ReturnValue;                          // 0x000060 (0x000008) [Default: nullptr]
        AActor*                             CallFunc_GetOwner_ReturnValue_1;                        // 0x000068 (0x000008) [Default: nullptr]
        AFortPlayerPawn*                    K2Node_DynamicCast_AsFort_Player_Pawn;                  // 0x000070 (0x000008) [Default: nullptr]
        bool                                K2Node_DynamicCast_bSuccess;                            // 0x000078 (0x000001) [Default: false]
        bool                                CallFunc_BooleanAND_ReturnValue_1;                      // 0x000079 (0x000001) [Default: false]
        uint8                               UnknownData_00007A[0x000002];                           // 0x00007A (0x000002)
        int32                               K2Node_CustomEvent_NewHighScore;                        // 0x00007C (0x000004) [Default: 0]
        bool                                CallFunc_IsPlayerPawnLocallyControlled_ReturnValue;     // 0x000080 (0x000001) [Default: false]
        bool                                CallFunc_IsPlayerPawnLocallyControlled_ReturnValue_1;   // 0x000081 (0x000001) [Default: false]
        uint8                               UnknownData_000082[0x000002];                           // 0x000082 (0x000002)
        OnNewHighScore                      K2Node_CreateDelegate_OutputDelegate;                   // 0x000084 (0x00000C)
    };

    struct UBPC_WeaponScore_C___HandleCurrentScoreChanged_Params
    {
        FArcadeWeaponScoreData  CurrentScoreData;   // 0x000000 (0x000048)
    };

    struct UBPC_WeaponScore_C___IsPlayerPawnLocallyControlled_Params
    {
        bool                ReturnValue;                                // 0x000000 (0x000001) [ReturnValue] [Default: true]
        uint8               UnknownData_000001[0x000007];               // 0x000001 (0x000007)
        AFortPlayerPawn*    CallFunc_GetPlayerPawn_ReturnValue;         // 0x000008 (0x000008) [Default: 0xD62912DD00280031]
        bool                CallFunc_IsLocallyControlled_ReturnValue;   // 0x000010 (0x000001) [Default: false]
    };

    struct UBPC_WeaponScore_C___NewHighScore_Params
    {
        int32   NewHighScore;   // 0x000000 (0x000004) [Default: 344680144]
    };

    struct UBPC_WeaponScore_C___OnScoreDataChanged_Params
    {
        FArcadeWeaponScoreData  ScoreData;  // 0x000000 (0x000048) [OutParam]
    };

    struct UBPC_WeaponScore_C___UpdateScore_Params
    {
        FArcadeWeaponScoreData  Score_Data; // 0x000000 (0x000048)
    };

} // namespace UE

