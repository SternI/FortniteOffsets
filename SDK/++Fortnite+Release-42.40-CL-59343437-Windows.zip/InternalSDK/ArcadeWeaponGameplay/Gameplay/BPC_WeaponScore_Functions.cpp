/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:44
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /ArcadeWeaponGameplay/Gameplay/BPC_WeaponScore_Functions
 * ============================================================
 */

#include "BPC_WeaponScore_Functions.hpp"

namespace UE
{

    FTrickShotConfig UBPC_WeaponScore_C::CheckIfTrickShot(FTrickShotConfig CallFunc_CheckIfTrickShot_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BPC_WeaponScore.BPC_WeaponScore_C.CheckIfTrickShot");
    
        UBPC_WeaponScore_C___CheckIfTrickShot_Params Params{};
        Params.CallFunc_CheckIfTrickShot_ReturnValue = CallFunc_CheckIfTrickShot_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBPC_WeaponScore_C::ExecuteUbergraph_BPC_WeaponScore(int32 EntryPoint, FArcadeWeaponScoreData K2Node_Event_ScoreData, UBPC_ArcadeWeaponScoreManager_C* CallFunc_GetComponentByClass_ReturnValue, bool CallFunc_Greater_IntInt_ReturnValue, bool CallFunc_IsValid_ReturnValue, bool CallFunc_BooleanAND_ReturnValue, AActor* CallFunc_GetOwner_ReturnValue, AActor* CallFunc_GetOwner_ReturnValue_1, AFortPlayerPawn* K2Node_DynamicCast_AsFort_Player_Pawn, bool K2Node_DynamicCast_bSuccess, bool CallFunc_BooleanAND_ReturnValue_1, int32 K2Node_CustomEvent_NewHighScore, bool CallFunc_IsPlayerPawnLocallyControlled_ReturnValue, bool CallFunc_IsPlayerPawnLocallyControlled_ReturnValue_1, OnNewHighScore K2Node_CreateDelegate_OutputDelegate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BPC_WeaponScore.BPC_WeaponScore_C.ExecuteUbergraph_BPC_WeaponScore");
    
        UBPC_WeaponScore_C___ExecuteUbergraph_BPC_WeaponScore_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.K2Node_Event_ScoreData = K2Node_Event_ScoreData;
        Params.CallFunc_GetComponentByClass_ReturnValue = CallFunc_GetComponentByClass_ReturnValue;
        Params.CallFunc_Greater_IntInt_ReturnValue = CallFunc_Greater_IntInt_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_BooleanAND_ReturnValue = CallFunc_BooleanAND_ReturnValue;
        Params.CallFunc_GetOwner_ReturnValue = CallFunc_GetOwner_ReturnValue;
        Params.CallFunc_GetOwner_ReturnValue_1 = CallFunc_GetOwner_ReturnValue_1;
        Params.K2Node_DynamicCast_AsFort_Player_Pawn = K2Node_DynamicCast_AsFort_Player_Pawn;
        Params.K2Node_DynamicCast_bSuccess = K2Node_DynamicCast_bSuccess;
        Params.CallFunc_BooleanAND_ReturnValue_1 = CallFunc_BooleanAND_ReturnValue_1;
        Params.K2Node_CustomEvent_NewHighScore = K2Node_CustomEvent_NewHighScore;
        Params.CallFunc_IsPlayerPawnLocallyControlled_ReturnValue = CallFunc_IsPlayerPawnLocallyControlled_ReturnValue;
        Params.CallFunc_IsPlayerPawnLocallyControlled_ReturnValue_1 = CallFunc_IsPlayerPawnLocallyControlled_ReturnValue_1;
        Params.K2Node_CreateDelegate_OutputDelegate = K2Node_CreateDelegate_OutputDelegate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBPC_WeaponScore_C::HandleCurrentScoreChanged(FArcadeWeaponScoreData CurrentScoreData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BPC_WeaponScore.BPC_WeaponScore_C.HandleCurrentScoreChanged");
    
        UBPC_WeaponScore_C___HandleCurrentScoreChanged_Params Params{};
        Params.CurrentScoreData = CurrentScoreData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UBPC_WeaponScore_C::IsPlayerPawnLocallyControlled(AFortPlayerPawn* CallFunc_GetPlayerPawn_ReturnValue, bool CallFunc_IsLocallyControlled_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BPC_WeaponScore.BPC_WeaponScore_C.IsPlayerPawnLocallyControlled");
    
        UBPC_WeaponScore_C___IsPlayerPawnLocallyControlled_Params Params{};
        Params.CallFunc_GetPlayerPawn_ReturnValue = CallFunc_GetPlayerPawn_ReturnValue;
        Params.CallFunc_IsLocallyControlled_ReturnValue = CallFunc_IsLocallyControlled_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UBPC_WeaponScore_C::NewHighScore(int32 NewHighScore)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BPC_WeaponScore.BPC_WeaponScore_C.NewHighScore");
    
        UBPC_WeaponScore_C___NewHighScore_Params Params{};
        Params.NewHighScore = NewHighScore;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBPC_WeaponScore_C::OnScoreDataChanged(FArcadeWeaponScoreData& ScoreData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BPC_WeaponScore.BPC_WeaponScore_C.OnScoreDataChanged");
    
        UBPC_WeaponScore_C___OnScoreDataChanged_Params Params{};
        Params.ScoreData = ScoreData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ScoreData = Params.ScoreData;
    }

    void UBPC_WeaponScore_C::ReceiveBeginPlay()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BPC_WeaponScore.BPC_WeaponScore_C.ReceiveBeginPlay");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBPC_WeaponScore_C::UpdateScore(FArcadeWeaponScoreData Score_Data)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BPC_WeaponScore.BPC_WeaponScore_C.UpdateScore");
    
        UBPC_WeaponScore_C___UpdateScore_Params Params{};
        Params.Score_Data = Score_Data;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

