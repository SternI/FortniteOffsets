/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:44
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /ArcadeWeaponGameplay/Gameplay/BPC_WeaponScore
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000180 (0x000080)
    class alignas(0x8) UBPC_WeaponScore_C : public UFortWeaponComponent_ArcadeWeapon
    {
    public:
        FPointerToUberGraphFrame            UberGraphFrame;                 // 0x000100 (0x000008)
        UBPC_ArcadeWeaponScoreManager_C*    ScoreManager;                   // 0x000108 (0x000008) [Default: nullptr]
        AFortPawn*                          Hit_Fort_Pawn;                  // 0x000110 (0x000008) [Default: nullptr]
        bool                                Just_Broke_Record_;             // 0x000118 (0x000001) [Default: false]
        bool                                ShouldPlayHighScoreSound;       // 0x000119 (0x000001) [Default: false]
        uint8                               UnknownData_00011A[0x000006];   // 0x00011A (0x000006)
        FArcadeWeaponScoreData              Score_Data;                     // 0x000120 (0x000048)
        MULTI_INLINE_DELEGATE(UpdateScore)  UpdateScore;                    // 0x000168 (0x000010)
        AFortPlayerPawn*                    PlayerPawn;                     // 0x000178 (0x000008) [Default: nullptr]
    
    public: // Functions
        FTrickShotConfig    CheckIfTrickShot(FTrickShotConfig CallFunc_CheckIfTrickShot_ReturnValue); // 0x000545D2 [Event | Protected | HasOutParms | HasDefaults | BlueprintCallable | BlueprintEvent | BlueprintPure | Const]
        void                ExecuteUbergraph_BPC_WeaponScore(int32 EntryPoint, FArcadeWeaponScoreData K2Node_Event_ScoreData, UBPC_ArcadeWeaponScoreManager_C* CallFunc_GetComponentByClass_ReturnValue, bool CallFunc_Greater_IntInt_ReturnValue, bool CallFunc_IsValid_ReturnValue, bool CallFunc_BooleanAND_ReturnValue, AActor* CallFunc_GetOwner_ReturnValue, AActor* CallFunc_GetOwner_ReturnValue_1, AFortPlayerPawn* K2Node_DynamicCast_AsFort_Player_Pawn, bool K2Node_DynamicCast_bSuccess, bool CallFunc_BooleanAND_ReturnValue_1, int32 K2Node_CustomEvent_NewHighScore, bool CallFunc_IsPlayerPawnLocallyControlled_ReturnValue, bool CallFunc_IsPlayerPawnLocallyControlled_ReturnValue_1, OnNewHighScore K2Node_CreateDelegate_OutputDelegate); // 0x000545D2 [Final | UbergraphFunction | HasDefaults]
        void                HandleCurrentScoreChanged(FArcadeWeaponScoreData CurrentScoreData); // 0x000545D2 [Public | BlueprintCallable | BlueprintEvent]
        bool                IsPlayerPawnLocallyControlled(AFortPlayerPawn* CallFunc_GetPlayerPawn_ReturnValue, bool CallFunc_IsLocallyControlled_ReturnValue); // 0x000545D2 [Public | HasOutParms | BlueprintCallable | BlueprintEvent | BlueprintPure]
        void                NewHighScore(int32 NewHighScore); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void                OnScoreDataChanged(FArcadeWeaponScoreData& ScoreData); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
        void                ReceiveBeginPlay(); // 0x000545D2 [Event | Public | BlueprintEvent]
        void                UpdateScore(FArcadeWeaponScoreData Score_Data); // 0x000545D2 [Public | Delegate | BlueprintCallable | BlueprintEvent]
    };
}

