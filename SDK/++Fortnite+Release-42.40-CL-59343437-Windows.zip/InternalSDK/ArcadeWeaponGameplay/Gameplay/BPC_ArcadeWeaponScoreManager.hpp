/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:44
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /ArcadeWeaponGameplay/Gameplay/BPC_ArcadeWeaponScoreManager
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000380 (0x000000)
    class UBPC_ArcadeWeaponScoreManager_C : public UFortPlayerStateComponent_ArcadeWeaponPersistence
    {
    public:
    };
}

