/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BeatSyncedAnimRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000038 (0x000000)
    class UAnimNotify_BeatMarker : public UAnimNotify
    {
    public:
    };
    // Size: 0x000028 (0x000000)
    class UBeatSyncedAnimLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static UFortItemDefinition*    GetLastEmoteExecuted(AController* Controller); // 0x080E6650 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
    };
    // Size: 0x000028 (0x000000)
    class UFMBeatTimingUtils : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static FBeatAndTime    GetCurrentBeatAndTime(UMusicClockComponent* MusicClock, UObject* WorldContext); // 0x080E67BE [Final | RequiredAPI | Native | Static | Public | BlueprintCallable | BlueprintPure]
    };
    // Size: 0x000148 (0x000088)
    class alignas(0x8) UMontageBeatSyncComponent : public UActorComponent
    {
    public:
        uint8                                   UnknownData_0000C0[0x000020];   // 0x0000C0 (0x000020)
        TWeakObjectPtr<UMusicClockComponent>    WeakMusicClockPtr;              // 0x0000E0 (0x000008) [Default: nullptr]
        TWeakObjectPtr<UMusicEventInstance>     WeakMusicEventPtr;              // 0x0000E8 (0x000008) [Default: nullptr]
        bool                                    bBeatSyncingPermission;         // 0x0000F0 (0x000001) [Default: true]
        uint8                                   UnknownData_0000F1[0x000007];   // 0x0000F1 (0x000007)
        AFortPlayerPawn*                        OwnerFortPlayerPawn;            // 0x0000F8 (0x000008) [Default: nullptr]
        ASkeletalMeshActor*                     OwnerSkeletalMeshActor;         // 0x000100 (0x000008) [Default: nullptr]
        USkeletalMeshComponent*                 OwnerMeshComponent;             // 0x000108 (0x000008) [Default: nullptr]
        FBeatSyncMontageInfo                    ActiveMontageInfo;              // 0x000110 (0x000020)
        uint8                                   UnknownData_000130[0x000018];   // 0x000130 (0x000018)
    
    public: // Functions
        AFortPlayerPawn*        GetOwnerFortPlayerPawn(); // 0x10E1ED28 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        ASkeletalMeshActor*     GetOwnerSkeletalMeshActor(); // 0x10E1ED4E [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        USkeletalMeshComponent* GetOwnerSkeletalMeshComponent(); // 0x0FE32F3E [Final | Native | Public | BlueprintCallable | BlueprintPure]
        bool                    IsMusicPlaying(); // 0x10E1ED74 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                    OnClockPlayStateChanged(EMusicClockState NewState); // 0x080E6AB2 [Final | Native | Private]
        void                    OnMeshAnimInstanceInitialized(); // 0x10E1EDEE [Final | Native | Private]
        void                    OnMontageEnded(UAnimMontage* Montage, bool bInterrupted); // 0x080E6C1A [Final | Native | Private]
        void                    OnMontageStarted(UAnimMontage* Montage); // 0x080E7038 [Final | Native | Private]
        void                    OnMusicEventClockStateChanged(UMusicEventInstance* MusicEvent); // 0x080E7348 [Final | Native | Private]
        void                    OnRep_BeatSyncingPermission(); // 0x10E1EE04 [Final | Native | Private]
        void                    OnRep_MusicClock(TWeakObjectPtr<UMusicClockComponent>& OldWeakMusicClockPtr); // 0x080E74BE [Final | Native | Private | HasOutParms]
        void                    ServerRPC_SetBeatSyncingPermission(bool bNewPermission); // 0x040ED1DC [RequiredAPI | Net | NetReliable | Native | Event | Protected | NetServer]
        void                    ServerRPC_SetMusicClock(UMusicClockComponent* NewMusicClock); // 0x04381806 [RequiredAPI | Net | NetReliable | Native | Event | Public | NetServer]
        void                    ServerRPC_StartStopBSE(bool bStarted); // 0x040ED1DC [Final | Net | NetReliable | Native | Event | Private | NetServer]
        void                    SetMusicClock(UMusicClockComponent* NewMusicClock); // 0x080E7636 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x0000A8 (0x000060)
    struct alignas(0x8) FAnimNode_PlayBeatSyncedAnim : public FAnimNode_SequenceEvaluator
    {
        UAnimSequenceBase*                  InSequence;                     // 0x000048 (0x000008) [Default: nullptr]
        UMusicClockComponent*               MusicClock;                     // 0x000050 (0x000008) [Default: nullptr]
        float                               TempoMultiplier;                // 0x000058 (0x000004) [Default: 0f]
        bool                                bEnableTempoVariants;           // 0x00005C (0x000001) [Default: false]
        uint8                               UnknownData_00005D[0x000003];   // 0x00005D (0x000003)
        float                               TempoVariantHysteresis;         // 0x000060 (0x000004) [Default: 0f]
        bool                                bShowDebug;                     // 0x000064 (0x000001) [Default: false]
        uint8                               UnknownData_000065[0x000003];   // 0x000065 (0x000003)
        TArray<UBeatSyncedAnimMetaData*>    BpsBuckets;                     // 0x000068 (0x000010)
        UAnimSequenceBase*                  OldAnimSequence;                // 0x000078 (0x000008) [Default: nullptr]
        uint8                               UnknownData_000080[0x000028];   // 0x000080 (0x000028)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x4) FBeatAndTime
    {
        float   Beat;                           // 0x000000 (0x000004)
        float   time;                           // 0x000004 (0x000004)
        float   BeatsPerSecond;                 // 0x000008 (0x000004)
        bool    IsValid;                        // 0x00000C (0x000001)
        uint8   UnknownData_00000D[0x000003];   // 0x00000D (0x000003)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FBeatSyncMontageInfo
    {
        UAnimInstance*              AnimInstance;                   // 0x000000 (0x000008)
        UAnimMontage*               Montage;                        // 0x000008 (0x000008)
        UBeatSyncedEmoteMetaData*   MetaData;                       // 0x000010 (0x000008)
        uint8                       UnknownData_000018[0x000008];   // 0x000018 (0x000008)
    };
}

