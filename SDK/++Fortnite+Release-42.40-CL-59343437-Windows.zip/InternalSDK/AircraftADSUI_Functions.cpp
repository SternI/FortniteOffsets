/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AircraftADSUI_Functions
 * ============================================================
 */

#include "AircraftADSUI_Functions.hpp"

namespace UE
{

    bool UAircraftADSPOIVM::IsGolden()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AircraftADSUI.AircraftADSPOIVM.IsGolden");
    
        UAircraftADSPOIVM___IsGolden_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAircraftADSPOIVM::IsPOISelected()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AircraftADSUI.AircraftADSPOIVM.IsPOISelected");
    
        UAircraftADSPOIVM___IsPOISelected_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FText UAircraftADSPOIVM::POIName()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AircraftADSUI.AircraftADSPOIVM.POIName");
    
        UAircraftADSPOIVM___POIName_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAircraftADSPOIVM::SetPOIVolume(AFortPoiVolume* InPOIVolume)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AircraftADSUI.AircraftADSPOIVM.SetPOIVolume");
    
        UAircraftADSPOIVM___SetPOIVolume_Params Params{};
        Params.InPOIVolume = InPOIVolume;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortPlayerControllerComponent_AircraftADSUI::HandleEnterAircraft(AController* Controller)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AircraftADSUI.FortPlayerControllerComponent_AircraftADSUI.HandleEnterAircraft");
    
        UFortPlayerControllerComponent_AircraftADSUI___HandleEnterAircraft_Params Params{};
        Params.Controller = Controller;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortPlayerControllerComponent_AircraftADSUI::HandleExitAircraft(AController* Controller)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AircraftADSUI.FortPlayerControllerComponent_AircraftADSUI.HandleExitAircraft");
    
        UFortPlayerControllerComponent_AircraftADSUI___HandleExitAircraft_Params Params{};
        Params.Controller = Controller;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool UFortPlayerControllerComponent_AircraftADSUI::IsPOIBubbleEnabled()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AircraftADSUI.FortPlayerControllerComponent_AircraftADSUI.IsPOIBubbleEnabled");
    
        UFortPlayerControllerComponent_AircraftADSUI___IsPOIBubbleEnabled_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortPlayerControllerComponent_AircraftADSUI::OnAircraftZoomInActivated()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AircraftADSUI.FortPlayerControllerComponent_AircraftADSUI.OnAircraftZoomInActivated");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortPlayerControllerComponent_AircraftADSUI::OnAircraftZoomInDeactivated()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AircraftADSUI.FortPlayerControllerComponent_AircraftADSUI.OnAircraftZoomInDeactivated");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortPlayerControllerComponent_AircraftADSUI::OnEnterAircraft()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AircraftADSUI.FortPlayerControllerComponent_AircraftADSUI.OnEnterAircraft");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortPlayerControllerComponent_AircraftADSUI::OnExitAircraft()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AircraftADSUI.FortPlayerControllerComponent_AircraftADSUI.OnExitAircraft");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortPlayerControllerComponent_AircraftADSUI::OnPOIVolumeSelectionChanged(AFortPoiVolume* POIVolume)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AircraftADSUI.FortPlayerControllerComponent_AircraftADSUI.OnPOIVolumeSelectionChanged");
    
        UFortPlayerControllerComponent_AircraftADSUI___OnPOIVolumeSelectionChanged_Params Params{};
        Params.POIVolume = POIVolume;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

