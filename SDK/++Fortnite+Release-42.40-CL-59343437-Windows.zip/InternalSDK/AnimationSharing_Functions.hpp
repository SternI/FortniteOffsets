/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimationSharing_Functions
 * ============================================================
 */

#include "AnimationSharing.hpp"

namespace UE
{

    struct UAnimSharingStateInstance___GetInstancedActors_Params
    {
        TArray<AActor*> Actors; // 0x000000 (0x000010) [OutParam]
    };

    struct UAnimationSharingManager___AnimationSharingEnabled_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAnimationSharingManager___CreateAnimationSharingManager_Params
    {
        UObject*                WorldContextObject; // 0x000000 (0x000008) [Default: 0x136B6230]
        UAnimationSharingSetup* Setup;              // 0x000008 (0x000008) [Default: 0xE22B18DD00000031]
        bool                    ReturnValue;        // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAnimationSharingManager___GetAnimationSharingManager_Params
    {
        UObject*                    WorldContextObject; // 0x000000 (0x000008) [Default: 0x136B6230]
        UAnimationSharingManager*   ReturnValue;        // 0x000008 (0x000008) [ReturnValue] [Default: 0xE22B18DD00000031]
    };

    struct UAnimationSharingManager___RegisterActorWithSkeletonBP_Params
    {
        AActor*     InActor;            // 0x000000 (0x000008) [Default: 0x136B6230]
        Uskeleton*  SharingSkeleton;    // 0x000008 (0x000008) [Default: 0xE22B18DD00000031]
        bool        ReturnValue;        // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAnimationSharingStateProcessor___GetAnimationStateEnum_Params
    {
        UEnum*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x136B5960]
    };

    struct UAnimationSharingStateProcessor___ProcessActorState_Params
    {
        int32   OutState;                       // 0x000000 (0x000004) [OutParam] [Default: 325802336]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        AActor* InActor;                        // 0x000008 (0x000008) [Default: 0xF87A18DD00000031]
        uint8   CurrentState;                   // 0x000010 (0x000001) [Default: 48]
        uint8   OnDemandState;                  // 0x000011 (0x000001) [Default: 16]
        bool    bShouldProcess;                 // 0x000012 (0x000001) [OutParam] [Default: true]
    };

} // namespace UE

