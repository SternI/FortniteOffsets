/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AppleImageUtils_Functions
 * ============================================================
 */

#include "AppleImageUtils.hpp"

namespace UE
{

    struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy___CreateProxyObjectForConvertToHEIF_Params
    {
        UTexture*                                       SourceImage;                    // 0x000000 (0x000008) [Default: 0x136B7380]
        int32                                           Quality;                        // 0x000008 (0x000004) [Default: 49]
        bool                                            bWantColor;                     // 0x00000C (0x000001) [Default: true]
        bool                                            bUseGpu;                        // 0x00000D (0x000001) [Default: true]
        uint8                                           UnknownData_00000E[0x000002];   // 0x00000E (0x000002)
        float                                           Scale;                          // 0x000010 (0x000004) [Default: 7.73316e-25f]
        ETextureRotationDirection                       Rotate;                         // 0x000014 (0x000001) [Default: ETextureRotationDirection(0)]
        uint8                                           UnknownData_000015[0x000003];   // 0x000015 (0x000003)
        UAppleImageUtilsBaseAsyncTaskBlueprintProxy*    ReturnValue;                    // 0x000018 (0x000008) [ReturnValue] [Default: 0x176F3A90]
    };

    struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy___CreateProxyObjectForConvertToJPEG_Params
    {
        UTexture*                                       SourceImage;                    // 0x000000 (0x000008) [Default: 0x136B7380]
        int32                                           Quality;                        // 0x000008 (0x000004) [Default: 49]
        bool                                            bWantColor;                     // 0x00000C (0x000001) [Default: true]
        bool                                            bUseGpu;                        // 0x00000D (0x000001) [Default: true]
        uint8                                           UnknownData_00000E[0x000002];   // 0x00000E (0x000002)
        float                                           Scale;                          // 0x000010 (0x000004) [Default: 7.73316e-25f]
        ETextureRotationDirection                       Rotate;                         // 0x000014 (0x000001) [Default: ETextureRotationDirection(0)]
        uint8                                           UnknownData_000015[0x000003];   // 0x000015 (0x000003)
        UAppleImageUtilsBaseAsyncTaskBlueprintProxy*    ReturnValue;                    // 0x000018 (0x000008) [ReturnValue] [Default: 0x176F3A90]
    };

    struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy___CreateProxyObjectForConvertToPNG_Params
    {
        UTexture*                                       SourceImage;                    // 0x000000 (0x000008) [Default: 0x136B7380]
        bool                                            bWantColor;                     // 0x000008 (0x000001) [Default: true]
        bool                                            bUseGpu;                        // 0x000009 (0x000001) [Default: false]
        uint8                                           UnknownData_00000A[0x000002];   // 0x00000A (0x000002)
        float                                           Scale;                          // 0x00000C (0x000004) [Default: -2.01996e+23f]
        ETextureRotationDirection                       Rotate;                         // 0x000010 (0x000001) [Default: ETextureRotationDirection(112)]
        uint8                                           UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        UAppleImageUtilsBaseAsyncTaskBlueprintProxy*    ReturnValue;                    // 0x000018 (0x000008) [ReturnValue] [Default: 0x176F3A90]
    };

    struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy___CreateProxyObjectForConvertToTIFF_Params
    {
        UTexture*                                       SourceImage;                    // 0x000000 (0x000008) [Default: 0x136B7380]
        bool                                            bWantColor;                     // 0x000008 (0x000001) [Default: true]
        bool                                            bUseGpu;                        // 0x000009 (0x000001) [Default: false]
        uint8                                           UnknownData_00000A[0x000002];   // 0x00000A (0x000002)
        float                                           Scale;                          // 0x00000C (0x000004) [Default: -2.01996e+23f]
        ETextureRotationDirection                       Rotate;                         // 0x000010 (0x000001) [Default: ETextureRotationDirection(112)]
        uint8                                           UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        UAppleImageUtilsBaseAsyncTaskBlueprintProxy*    ReturnValue;                    // 0x000018 (0x000008) [ReturnValue] [Default: 0x176F3A90]
    };

} // namespace UE

