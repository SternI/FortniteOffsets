/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioAnalyzer_Functions
 * ============================================================
 */

#include "AudioAnalyzer_Functions.hpp"

namespace UE
{

    void UAudioAnalyzer::StartAnalyzing(UObject* WorldContextObject, UAudioBus* AudioBusToAnalyze)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioAnalyzer.AudioAnalyzer.StartAnalyzing");
    
        UAudioAnalyzer___StartAnalyzing_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.AudioBusToAnalyze = AudioBusToAnalyze;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioAnalyzer::StopAnalyzing(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioAnalyzer.AudioAnalyzer.StopAnalyzing");
    
        UAudioAnalyzer___StopAnalyzing_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

