/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AmpleHammer
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000058 (0x000030)
    class alignas(0x8) UAmpleHammerPINModalHelper : public UObject
    {
    public:
        FText   Description;        // 0x000028 (0x000010)
        FText   InfoTitle;          // 0x000038 (0x000010)
        FText   InfoDescription;    // 0x000048 (0x000010)
    };
    // Size: 0x000028 (0x000000)
    class UAmpleHammerRequestConsentHelper : public UObject
    {
    public:
    };
}

