/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BeastGirlRuntime_Functions
 * ============================================================
 */

#include "BeastGirlRuntime.hpp"

namespace UE
{

    struct ABeastGirlStandInPawn___BP_OnOutOfHealth_Params
    {
        AFortPawn*  OriginalPawn;   // 0x000000 (0x000008) [Default: 0x14954210]
    };

    struct ABeastGirlStandInPawn___BP_OnRestoreToOriginalPawn_Params
    {
        AFortPawn*  OriginalPawn;   // 0x000000 (0x000008) [Default: 0x14954210]
    };

    struct ABeastGirlStandInPawn___ForceBackblingVisibility_Params
    {
        AFortPlayerPawn*    Pawn;   // 0x000000 (0x000008) [Default: 0x14954210]
    };

    struct ABeastGirlStandInPawn___ForceRefreshEquippedWeapon_Params
    {
        AFortWeapon*    NewWeapon;  // 0x000000 (0x000008) [Default: 0x14954210]
    };

    struct ABeastGirlStandInPawn___GameplayTagCallback_InsideSafeZone_Params
    {
        FGameplayTag    Tag;        // 0x000000 (0x000004)
        int32           NewCount;   // 0x000004 (0x000004) [Default: 0]
    };

    struct ABeastGirlStandInPawn___GameplayTagCallback_SprintActive_Params
    {
        FGameplayTag    Tag;        // 0x000000 (0x000004)
        int32           NewCount;   // 0x000004 (0x000004) [Default: 0]
    };

    struct ABeastGirlStandInPawn___GetTransformationAnimations_Params
    {
        bool                                bIsOptOut;                      // 0x000000 (0x000001) [Default: true]
        uint8                               UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        FBeastGirlTransformationAnimations  ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct ABeastGirlStandInPawn___HandleCapsuleHit_Params
    {
        UPrimitiveComponent*    HitComponent;   // 0x000000 (0x000008) [Default: 0x14954210]
        AActor*                 OtherActor;     // 0x000008 (0x000008) [Default: 0x346318DD00000031]
        UPrimitiveComponent*    OtherComp;      // 0x000010 (0x000008) [Default: 0x19891FA0]
        FVector                 NormalImpulse;  // 0x000018 (0x000018)
        FHitResult              Hit;            // 0x000030 (0x0000F8) [OutParam]
    };

    struct ABeastGirlStandInPawn___HandleOnWeaponEquipped_Params
    {
        AFortWeapon*    NewWeapon;  // 0x000000 (0x000008) [Default: 0x14954210]
        AFortWeapon*    PrevWeapon; // 0x000008 (0x000008) [Default: 0x346318DD00000031]
    };

    struct ABeastGirlStandInPawn___OnBeastGirlDidDamage_Params
    {
        AActor*                 DamagedActor;                   // 0x000000 (0x000008) [Default: 0x14954210]
        float                   Damage;                         // 0x000008 (0x000004) [Default: 6.86636e-44f]
        uint8                   UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        AController*            InstigatedBy;                   // 0x000010 (0x000008) [Default: 0x19891FA0]
        AActor*                 DamageCauser;                   // 0x000018 (0x000008) [Default: 0x1988CA50]
        FVector                 HitLocation;                    // 0x000020 (0x000018)
        UPrimitiveComponent*    FHitComponent;                  // 0x000038 (0x000008) [Default: nullptr]
        FName                   BoneName;                       // 0x000040 (0x000004) [Default: NAME_None]
        uint8                   UnknownData_000044[0x000004];   // 0x000044 (0x000004)
        FVector                 Momentum;                       // 0x000048 (0x000018)
    };

    struct ABeastGirlStandInPawn___OnPlayerEliminated_Params
    {
        FFortVerbMessage_PawnEliminated Event;  // 0x000000 (0x000148) [OutParam]
    };

    struct ABeastGirlStandInPawn___ReplaceAndPossess_Params
    {
        AFortPlayerPawn*    PlayerPawn; // 0x000000 (0x000008) [Default: 0x14954210]
    };

    struct ABeastGirlStandInPawn___RestoreToOriginalPawn_Params
    {
        AFortPlayerController*  FallbackController; // 0x000000 (0x000008) [Default: 0x14954210]
    };

    struct ABeastGirlStandInPawn___SetIsTransformingInto_Params
    {
        bool    bTransformingInto;  // 0x000000 (0x000001) [Default: true]
    };

    struct ABeastGirlStandInPawn___SetReplicatedTransformationData_Params
    {
        bool    bIsOptOut;  // 0x000000 (0x000001) [Default: true]
        bool    bIsInWater; // 0x000001 (0x000001) [Default: true]
    };

    struct ABeastGirlStandInPawn___SpawnBeastGirlForPlayerPawn_Params
    {
        AFortPlayerPawn*        PlayerPawn;     // 0x000000 (0x000008) [Default: 0x14954210]
        UClass*                 ClassToSpawn;   // 0x000008 (0x000008) [Default: 0x346318DD00000031]
        ABeastGirlStandInPawn*  ReturnValue;    // 0x000010 (0x000008) [ReturnValue] [Default: 0x19891FA0]
    };

    struct UBeastGirlTransformationManager___GetNewDurability_Params
    {
        float                       FinalBeastGirlHealth;           // 0x000000 (0x000004) [Default: 1.50871e-26f]
        uint8                       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UFortWorldItemDefinition*   ItemDefinition;                 // 0x000008 (0x000008) [Default: 0x136318DD00000031]
        float                       ReturnValue;                    // 0x000010 (0x000004) [ReturnValue] [Default: 1.41868e-23f]
    };

    struct UBeastGirlTransformationManager___HasEnoughDurability_Params
    {
        AFortWeapon*    CurrentWeapon;  // 0x000000 (0x000008) [Default: 0x14956A70]
        bool            ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBeastGirlTransformationManager___NewCode_AddConsumableWithRemainingHealth_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBeastGirlTransformationManager___OldCode_AddConsumableWithRemainingHealth_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBeastGirlTransformationManager___Server_StartReverseTransformation_Params
    {
        bool    bFromOptOut;    // 0x000000 (0x000001) [Default: true]
    };

    struct UBeastGirlTransformationManager___SetBeastGirlPawn_Params
    {
        ABeastGirlStandInPawn*  BeastGirlPawn;  // 0x000000 (0x000008) [Default: 0x14956A70]
    };

    struct UBeastGirlTransformationManager___StartReverseTransformation_Params
    {
        bool    bFromOptOut;    // 0x000000 (0x000001) [Default: true]
    };

    struct IBeastPlayerAnimationInterface___GetAnimData_Params
    {
        bool                            bIsInTransformAnimation;    // 0x000000 (0x000001) [OutParam] [Default: true]
        FBeastGirlTransformationData    ReplicatedTransformData;    // 0x000001 (0x000001) [OutParam]
        EBeastGirlDiveState             DiveState;                  // 0x000002 (0x000001) [OutParam] [Default: EBeastGirlDiveState(250)]
    };

} // namespace UE

