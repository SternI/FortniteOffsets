/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BattleTracksRuntime_Functions
 * ============================================================
 */

#include "BattleTracksRuntime.hpp"

namespace UE
{

    struct UBattleTracksPlayerComponent___BP_HandlePlayerPlaceChanged_Params
    {
        int32   Placement;  // 0x000000 (0x000004) [Default: 345209200]
    };

    struct UBattleTracksPlayerComponent___BP_HandlePossessedPawnChanged_Params
    {
        APawn*  OldPawn;    // 0x000000 (0x000008) [Default: 0x14937970]
        APawn*  NewPawn;    // 0x000008 (0x000008) [Default: 0x875C18DD00000031]
    };

    struct UBattleTracksPlayerComponent___GetSongInMomentSlot_Params
    {
        FGameplayTag                        MomentTag;                      // 0x000000 (0x000004) [OutParam]
        uint8                               UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TScriptInterface<IFortMusicItem>    ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UBattleTracksPlayerComponent___HandlePlaySongEvent_Params
    {
        FFortBattleTracksPlaySongEvent  Event;  // 0x000000 (0x000048) [OutParam]
    };

    struct UBattleTracksPlayerComponent___HandlePossessedPawnChanged_Params
    {
        APawn*  OldPawn;    // 0x000000 (0x000008) [Default: 0x14937970]
        APawn*  NewPawn;    // 0x000008 (0x000008) [Default: 0x875C18DD00000031]
    };

    struct UBattleTracksPlayerComponent___HandlePrepareSongEvent_Params
    {
        FFortBattleTracksPrepareSongEvent   Event;  // 0x000000 (0x000048) [OutParam]
    };

    struct UBattleTracksPlayerComponent___HandleStopSongEvent_Params
    {
        FFortBattleTracksStopSongEvent  Event;  // 0x000000 (0x000001) [OutParam]
    };

    struct UBattleTracksPlayerComponent___PlayEquippedJamTrack_Params
    {
        int32                   Index;                          // 0x000000 (0x000004) [Default: 345209200]
        uint8                   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FFortMusicPlayerParams  PlayerParams;                   // 0x000008 (0x000090)
    };

    struct UBattleTracksPlayerComponent___PlayMomentTrack_Params
    {
        FGameplayTag            MomentTag;                      // 0x000000 (0x000004) [OutParam]
        uint8                   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FFortMusicPlayerParams  PlayerParams;                   // 0x000008 (0x000090)
    };

    struct UBattleTracksPlayerComponent___PrepareEquippedJamTrack_Params
    {
        int32                   Index;                          // 0x000000 (0x000004) [Default: 345209200]
        uint8                   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FFortMusicPlayerParams  PlayerParams;                   // 0x000008 (0x000090)
    };

    struct UBattleTracksPlayerComponent___PrepareMomentTrack_Params
    {
        FGameplayTag            MomentTag;                      // 0x000000 (0x000004) [OutParam]
        uint8                   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FFortMusicPlayerParams  PlayerParams;                   // 0x000008 (0x000090)
    };

    struct UBattleTracksPlayerComponent___PrepareSong_Params
    {
        TScriptInterface<IFortMusicItem>    Song;           // 0x000000 (0x000010)
        FFortMusicPlayerParams              PlayerParams;   // 0x000010 (0x000090)
    };

    struct UBattleTracksPlayerComponent___ShouldPrepareVictorySongEarly_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UBattleTracksPlayerComponent___StopSong_Params
    {
        float   FadeOutTime;    // 0x000000 (0x000004) [Default: 1.48911e-26f]
    };

} // namespace UE

