/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BikeKidUI
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0002C0 (0x000020)
    class alignas(0x8) ABikeKidUIDirector : public ADynamicUIDirectorBase
    {
    public:
        FGameplayTagContainer   HUDTagsToHide;  // 0x0002A0 (0x000020)
    
    public: // Functions
        void    BP_OnBikeKidDeployed(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    BP_OnBikeKidDismissed(); // 0x000545D2 [Event | Protected | BlueprintEvent]
    };
    // Size: 0x000400 (0x0000F8)
    class alignas(0x8) UBikeKidHUD : public UUserWidget
    {
    public:
        float                               TimeToConfirmTargetCache;       // 0x000308 (0x000004) [Default: -1f]
        float                               InitialHealth;                  // 0x00030C (0x000004) [Default: 1f]
        FScalableFloat                      WarningRange;                   // 0x000310 (0x000028)
        FScalableFloat                      SignalLossRange;                // 0x000338 (0x000028)
        FScalableFloat                      UpdateSignalInterval;           // 0x000360 (0x000028)
        FGameplayTag                        MarkAbilityTag;                 // 0x000388 (0x000004)
        FGameplayTag                        DismissAbilityTag;              // 0x00038C (0x000004)
        FGameplayTag                        SpeedBoostAbilityTag;           // 0x000390 (0x000004)
        uint8                               UnknownData_000394[0x000004];   // 0x000394 (0x000004)
        UOverlay*                           Overlay_Health;                 // 0x000398 (0x000008) [Default: nullptr]
        UOverlay*                           Overlay_EnergyLevel;            // 0x0003A0 (0x000008) [Default: nullptr]
        UOverlay*                           Overlay_Reticle;                // 0x0003A8 (0x000008) [Default: nullptr]
        UOverlay*                           Overlay_TetheringIndicator;     // 0x0003B0 (0x000008) [Default: nullptr]
        float                               MaxHealthCache;                 // 0x0003B8 (0x000004) [Default: 100f]
        float                               MaxEnergyCache;                 // 0x0003BC (0x000004) [Default: 100f]
        uint8                               UnknownData_0003C0[0x000028];   // 0x0003C0 (0x000028)
        FTimerHandle                        SignalDataTimerHandle;          // 0x0003E8 (0x000008)
        TArray<FBikeKidWidgetIdentifier>    HUDIdentifiers;                 // 0x0003F0 (0x000010)
    
    public: // Functions
        AFortBikeKid*   GetControlledBikeKid(); // 0x10E29996 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        float           GetTargetConfirmationTime(); // 0x10E29A40 [Final | Native | Private | BlueprintCallable]
        void            OnBikeKidDismissAbilityUsed(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void            OnBikeKidEnergyChanged(float EnergyPercentage); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void            OnBikeKidHealthUpdated(float HealthPercentage, float CurrentHealth); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void            OnBikeKidMarkAbilityEnd(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void            OnBikeKidMarkAbilityUsed(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void            OnBikeKidSignalDataUpdated(float DistanceFromPlayer, float SignalPercentage); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void            OnBikeKidSpeedBoostAbilityEnd(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void            OnBikeKidSpeedBoostAbilityUsed(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void            OnOwningPlayerDamaged(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void            OnReticleChangeAbilityActivated(FGameplayTag UpdatedTag); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void            OnTargetingStatusChanged(FBikeKidStatusData& StatusData); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
    };
    // Size: 0x000328 (0x000020)
    class UBikeKidTetherIndicator : public UUserWidget
    {
    public:
        uint8   UnknownData_000308[0x000020];   // 0x000308 (0x000020)
    
    public: // Functions
        void            BP_OnEnterSignalLossRange(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void            BP_OnEnterWarningRange(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void            BP_OnExitWarningRange(); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void            BP_WhileInWarningRange(float SignalIntensityPercentage); // 0x000545D2 [Event | Protected | BlueprintEvent]
        AFortBikeKid*   GetControlledBikeKid(); // 0x10E29996 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
    };
    // Size: 0x0000B0 (0x000020)
    class alignas(0x8) UFortMobileActionButtonBehaviorExtension_BikeKidUse : public UFortMobileActionButtonBehaviorExtension
    {
    public:
        FGameplayTagContainer   ContextTagToCheck;  // 0x000090 (0x000020)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FBikeKidWidgetIdentifier
    {
        FGameplayTagContainer   Tags;       // 0x000000 (0x000020)
        TWeakObjectPtr<UWidget> WeakWdiget; // 0x000020 (0x000008)
    };
}

