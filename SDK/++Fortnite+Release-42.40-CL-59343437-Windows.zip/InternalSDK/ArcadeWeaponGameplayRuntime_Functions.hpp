/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArcadeWeaponGameplayRuntime_Functions
 * ============================================================
 */

#include "ArcadeWeaponGameplayRuntime.hpp"

namespace UE
{

    struct UFortControllerComponent_ArcadeWeaponLeaderboard___GetActiveLeaderboardMode_Params
    {
        EArcadeWeaponLeaderboardMode    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EArcadeWeaponLeaderboardMode(32)]
    };

    struct UFortControllerComponent_ArcadeWeaponLeaderboard___GetEntryForPlayer_Params
    {
        APlayerState*                   PlayerState;    // 0x000000 (0x000008) [Default: 0x148B5A20]
        FArcadeWeaponLeaderboardEntry   OutEntry;       // 0x000008 (0x000060) [OutParam]
        bool                            ReturnValue;    // 0x000068 (0x000001) [ReturnValue] [Default: false]
    };

    struct UFortControllerComponent_ArcadeWeaponLeaderboard___GetLocalPlayerRank_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344676896]
    };

    struct UFortControllerComponent_ArcadeWeaponLeaderboard___GetNumEntries_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344676896]
    };

    struct UFortControllerComponent_ArcadeWeaponLeaderboard___GetRankedEntries_Params
    {
        TArray<FArcadeWeaponLeaderboardEntry>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UFortControllerComponent_ArcadeWeaponLeaderboard___GetRankedFriendsEntries_Params
    {
        TArray<FArcadeWeaponLeaderboardEntry>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UFortControllerComponent_ArcadeWeaponLeaderboard___GetRankedGlobalEntries_Params
    {
        TArray<FArcadeWeaponLeaderboardEntry>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UFortControllerComponent_ArcadeWeaponLeaderboard___HandleNewHighScore_Params
    {
        int32   NewHighScore;   // 0x000000 (0x000004) [Default: 344676896]
    };

    struct UFortControllerComponent_ArcadeWeaponLeaderboard___HandleScoreDataChanged_Params
    {
        FArcadeWeaponScoreData  ScoreData;  // 0x000000 (0x000048) [OutParam]
    };

    struct UFortControllerComponent_ArcadeWeaponLeaderboard___IsLeaderboardEnabled_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UFortControllerComponent_ArcadeWeaponLeaderboard___RequestFriendsLeaderboard_Params
    {
        EArcadeWeaponLeaderboardMode    Mode;   // 0x000000 (0x000001) [Default: EArcadeWeaponLeaderboardMode(32)]
    };

    struct UFortControllerComponent_ArcadeWeaponLeaderboard___RequestGlobalLeaderboard_Params
    {
        EArcadeWeaponLeaderboardMode    Mode;   // 0x000000 (0x000001) [Default: EArcadeWeaponLeaderboardMode(32)]
    };

    struct UFortPlayerStateComponent_ArcadeWeaponPersistence___GetCumulativeScore_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344678672]
    };

    struct UFortPlayerStateComponent_ArcadeWeaponPersistence___GetCurrentScoreData_Params
    {
        FArcadeWeaponScoreData  ReturnValue;    // 0x000000 (0x000048) [ReturnValue]
    };

    struct UFortPlayerStateComponent_ArcadeWeaponPersistence___GetHighScore_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344678672]
    };

    struct UFortPlayerStateComponent_ArcadeWeaponPersistence___GetHighScoreForMode_Params
    {
        EArcadeWeaponLeaderboardMode    Mode;                           // 0x000000 (0x000001) [Default: EArcadeWeaponLeaderboardMode(16)]
        uint8                           UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        int32                           ReturnValue;                    // 0x000004 (0x000004) [ReturnValue] [Default: 0]
    };

    struct UFortPlayerStateComponent_ArcadeWeaponPersistence___GetStreak_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344678672]
    };

    struct UFortPlayerStateComponent_ArcadeWeaponPersistence___HandlePlayerPersistenceAvailable_Params
    {
        EFortSaveFrameworkPersistence_AvailableType AvailableType;                  // 0x000000 (0x000001) [Default: EFortSaveFrameworkPersistence_AvailableType(16)]
        uint8                                       UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        FInstancedStruct                            InPersistenceDataRoot;          // 0x000008 (0x000010) [OutParam]
    };

    struct UFortPlayerStateComponent_ArcadeWeaponPersistence___IsUsingMinigameScore_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UFortPlayerStateComponent_ArcadeWeaponPersistence___OnRep_HighScoreBuild_Params
    {
        int32   OldValue;   // 0x000000 (0x000004) [Default: 344678672]
    };

    struct UFortPlayerStateComponent_ArcadeWeaponPersistence___OnRep_HighScoreZeroBuild_Params
    {
        int32   OldValue;   // 0x000000 (0x000004) [Default: 344678672]
    };

    struct UFortPlayerStateComponent_ArcadeWeaponPersistence___TrySetNewHighScore_Params
    {
        int32   NewScore;       // 0x000000 (0x000004) [Default: 344678672]
        bool    ReturnValue;    // 0x000004 (0x000001) [ReturnValue] [Default: false]
    };

    struct UFortPlayerStateComponent_ArcadeWeaponPersistence___UpdateScoreAndStreak_Params
    {
        FArcadeWeaponScoreData  InScoreData;    // 0x000000 (0x000048) [OutParam]
        FArcadeWeaponScoreData  OutScoreData;   // 0x000048 (0x000048) [OutParam]
    };

    struct UFortWeaponComponent_ArcadeWeapon___CheckIfTrickShot_Params
    {
        FTrickShotConfig    ReturnValue;    // 0x000000 (0x000030) [ReturnValue]
    };

    struct UFortWeaponComponent_ArcadeWeapon___GetArcadeWeaponPersistenceComponent_Params
    {
        UFortPlayerStateComponent_ArcadeWeaponPersistence*  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x148B66D0]
    };

    struct UFortWeaponComponent_ArcadeWeapon___GetCurrentScoreData_Params
    {
        FArcadeWeaponScoreData  ReturnValue;    // 0x000000 (0x000048) [ReturnValue]
    };

    struct UFortWeaponComponent_ArcadeWeapon___GetPlayerPawn_Params
    {
        AFortPlayerPawn*    ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x148B66D0]
    };

    struct UFortWeaponComponent_ArcadeWeapon___OnScoreDataChanged_Params
    {
        FArcadeWeaponScoreData  ScoreData;  // 0x000000 (0x000048) [OutParam]
    };

} // namespace UE

