/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AbilitySystemGameFeatureActions
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000048 (0x000020)
    class alignas(0x8) UGameFeatureAction_AddAttributeDefaults : public UGameFeatureAction
    {
    public:
        bool                    bApplyOnRegister;               // 0x000028 (0x000001) [Default: true]
        uint8                   UnknownData_000029[0x000007];   // 0x000029 (0x000007)
        TArray<FSoftObjectPath> AttribDefaultTableNames;        // 0x000030 (0x000010)
        uint8                   UnknownData_000040[0x000008];   // 0x000040 (0x000008)
    };
}

