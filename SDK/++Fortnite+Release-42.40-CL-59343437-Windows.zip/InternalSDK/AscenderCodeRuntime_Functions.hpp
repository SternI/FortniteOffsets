/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AscenderCodeRuntime_Functions
 * ============================================================
 */

#include "AscenderCodeRuntime.hpp"

namespace UE
{

    struct AFortAscenderZipline___ApplyStructureDamage_Params
    {
        ABuildingSMActor*   BuildingActor;  // 0x000000 (0x000008) [Default: 0x148D19F0]
        AActor*             DamageSource;   // 0x000008 (0x000008) [Default: 0x3F5D18DD00000031]
    };

    struct AFortAscenderZipline___BP_HandlePlayerStartedUsingHandle_Params
    {
        AFortPlayerPawn*    player; // 0x000000 (0x000008) [Default: 0x148D19F0]
    };

    struct AFortAscenderZipline___BP_HandlePlayerStoppedUsingHandle_Params
    {
        AFortPlayerPawn*    player; // 0x000000 (0x000008) [Default: 0x148D19F0]
    };

    struct AFortAscenderZipline___GetHandleComponent_Params
    {
        UPrimitiveComponent*    ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x148D19F0]
    };

    struct AFortAscenderZipline___GetInteractComponentOverride_Params
    {
        AFortPlayerPawn*        InteractingPawn;    // 0x000000 (0x000008) [Default: 0x148D19F0]
        UPrimitiveComponent*    InteractComponent;  // 0x000008 (0x000008) [Default: 0x3F5D18DD00000031]
        UPrimitiveComponent*    ReturnValue;        // 0x000010 (0x000008) [ReturnValue] [Default: 0x1976E640]
    };

    struct AFortAscenderZipline___GetPawnUsingHandle_Params
    {
        AFortPlayerPawn*    ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x148D19F0]
    };

    struct AFortAscenderZipline___GetTopComponent_Params
    {
        UPrimitiveComponent*    ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x148D19F0]
    };

    struct AFortAscenderZipline___HandleFloorActorDestroyed_Params
    {
        AActor* Actor;  // 0x000000 (0x000008) [Default: 0x148D19F0]
    };

    struct AFortAscenderZipline___HandlePawnUsingHandleDied_Params
    {
        AFortPawn*  DeadPawn;   // 0x000000 (0x000008) [Default: 0x148D19F0]
    };

    struct AFortAscenderZipline___IsUsingHandle_Params
    {
        AFortPawn*  PawnToCheck;    // 0x000000 (0x000008) [Default: 0x148D19F0]
        bool        ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct AFortAscenderZipline___SetupAscender_Params
    {
        bool    bFromConstruction;  // 0x000000 (0x000001) [Default: true]
        bool    bFromReplication;   // 0x000001 (0x000001) [Default: true]
    };

    struct UFortCheatManager_AscenderZipline___RemoveAscenders_Params
    {
        bool    bRemoveAscendersOn; // 0x000000 (0x000001) [Default: true]
    };

    struct UFortPawnComponent_AscenderMontageProvider___GetSuitableMontage_Params
    {
        bool            bAscending;                     // 0x000000 (0x000001) [Default: true]
        uint8           UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        UAnimMontage*   ReturnValue;                    // 0x000008 (0x000008) [ReturnValue] [Default: 0x375D18DD00000031]
    };

} // namespace UE

