/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:08
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AssembledMeshSystem_Functions
 * ============================================================
 */

#include "AssembledMeshSystem_Functions.hpp"

namespace UE
{

    void UAssembledMeshUserComponent::CustomizationCompleted(int32 PartIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssembledMeshSystem.AssembledMeshUserComponent.CustomizationCompleted");
    
        UAssembledMeshUserComponent___CustomizationCompleted_Params Params{};
        Params.PartIndex = PartIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAssembledMeshUserComponent::GatherAndAssignAssembledMeshParts()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssembledMeshSystem.AssembledMeshUserComponent.GatherAndAssignAssembledMeshParts");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    USkeletalMeshComponent* UAssembledMeshUserComponent::GetAttachToComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssembledMeshSystem.AssembledMeshUserComponent.GetAttachToComponent");
    
        UAssembledMeshUserComponent___GetAttachToComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAssembledMeshSchema* UAssembledMeshUserComponent::GetMeshPart()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssembledMeshSystem.AssembledMeshUserComponent.GetMeshPart");
    
        UAssembledMeshUserComponent___GetMeshPart_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAssembledMeshSchema* UAssembledMeshUserComponent::GetMeshPartByIndex(int32 MeshPartIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssembledMeshSystem.AssembledMeshUserComponent.GetMeshPartByIndex");
    
        UAssembledMeshUserComponent___GetMeshPartByIndex_Params Params{};
        Params.MeshPartIndex = MeshPartIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 UAssembledMeshUserComponent::GetNumMeshParts()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssembledMeshSystem.AssembledMeshUserComponent.GetNumMeshParts");
    
        UAssembledMeshUserComponent___GetNumMeshParts_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAssembledMeshUserComponent::OnRep_MeshParts()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssembledMeshSystem.AssembledMeshUserComponent.OnRep_MeshParts");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAssembledMeshUserComponent::SetMeshPart(UAssembledMeshSchema* InMeshPart)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssembledMeshSystem.AssembledMeshUserComponent.SetMeshPart");
    
        UAssembledMeshUserComponent___SetMeshPart_Params Params{};
        Params.InMeshPart = InMeshPart;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAssembledMeshUserComponent::SetMeshParts(TArray<TSoftObjectPtr<UAssembledMeshSchema>> InMeshParts)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AssembledMeshSystem.AssembledMeshUserComponent.SetMeshParts");
    
        UAssembledMeshUserComponent___SetMeshParts_Params Params{};
        Params.InMeshParts = InMeshParts;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

