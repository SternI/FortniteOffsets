/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AircraftADS
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000178 (0x0000B0)
    class alignas(0x8) UFortControllerComponent_AircraftADS : public UFortControllerComponent
    {
    public:
        MULTI_INLINE_DELEGATE(OnADSCameraActivation)    OnADSCameraActivation;          // 0x0000C8 (0x000010)
        MULTI_INLINE_DELEGATE(OnADSCameraDeactivation)  OnADSCameraDeactivation;        // 0x0000D8 (0x000010)
        FFortCachedScalableFloat                        AircraftCameraEnabled;          // 0x0000E8 (0x000030)
        FFortCachedScalableFloat                        ADSCooldown;                    // 0x000118 (0x000030)
        FGameplayTag                                    CameraModeTag;                  // 0x000148 (0x000004)
        uint8                                           UnknownData_00014C[0x000004];   // 0x00014C (0x000004)
        UClass*                                         ZoomInCameraModeClass;          // 0x000150 (0x000008) [Default: nullptr]
        uint8                                           UnknownData_000158[0x000020];   // 0x000158 (0x000020)
    
    public: // Functions
        void    BP_OnZoomInCameraActivate(AFortPlayerController* Initiator); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    BP_OnZoomInCameraDeactivate(AFortPlayerController* Initiator); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void    OnExitAircraft(AController* Controller); // 0x07ECFD90 [Final | Native | Protected]
        void    OnADSCameraActivation(AFortPlayerController* Controller); // 0x000545D2 [MulticastDelegate | Public | Delegate]
        void    OnADSCameraDeactivation(AFortPlayerController* Controller); // 0x000545D2 [MulticastDelegate | Public | Delegate]
    };
}

