/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BallisticShieldGameplay/Gameplay/CameraMode_BallisticShield_Bash
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x002090 (0x000000)
    class UCameraMode_BallisticShield_Bash_C : public UFortHoverboardCameraMode
    {
    public:
    };
}

