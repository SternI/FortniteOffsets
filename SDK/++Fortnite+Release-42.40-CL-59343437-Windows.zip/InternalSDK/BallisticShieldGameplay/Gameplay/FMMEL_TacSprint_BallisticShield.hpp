/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BallisticShieldGameplay/Gameplay/FMMEL_TacSprint_BallisticShield
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000628 (0x000008)
    class alignas(0x8) UFMMEL_TacSprint_BallisticShield_C : public UFortMovementMode_ELBShieldSprint
    {
    public:
        FPointerToUberGraphFrame    UberGraphFrame; // 0x000620 (0x000008)
    
    public: // Functions
        void    BP_OnExtensionActivate(FMMERuntimeContext& RuntimeContext); // 0x000545D2 [Event | Public | HasOutParms | BlueprintEvent]
        void    BP_OnExtensionDeactivate(FMMERuntimeContext& RuntimeContext); // 0x000545D2 [Event | Public | HasOutParms | BlueprintEvent]
        void    ExecuteUbergraph_FMMEL_TacSprint_BallisticShield(int32 EntryPoint, FMMERuntimeContext K2Node_Event_RuntimeContext, FMMERuntimeContext K2Node_Event_RuntimeContext_1); // 0x000545D2 [Final | UbergraphFunction | HasDefaults]
    };
}

