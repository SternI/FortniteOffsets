/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BallisticShieldGameplay/Gameplay/FMMEL_TacSprint_BallisticShield_Functions
 * ============================================================
 */

#include "FMMEL_TacSprint_BallisticShield_Functions.hpp"

namespace UE
{

    void UFMMEL_TacSprint_BallisticShield_C::BP_OnExtensionActivate(FMMERuntimeContext& RuntimeContext)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("FMMEL_TacSprint_BallisticShield.FMMEL_TacSprint_BallisticShield_C.BP_OnExtensionActivate");
    
        UFMMEL_TacSprint_BallisticShield_C___BP_OnExtensionActivate_Params Params{};
        Params.RuntimeContext = RuntimeContext;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        RuntimeContext = Params.RuntimeContext;
    }

    void UFMMEL_TacSprint_BallisticShield_C::BP_OnExtensionDeactivate(FMMERuntimeContext& RuntimeContext)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("FMMEL_TacSprint_BallisticShield.FMMEL_TacSprint_BallisticShield_C.BP_OnExtensionDeactivate");
    
        UFMMEL_TacSprint_BallisticShield_C___BP_OnExtensionDeactivate_Params Params{};
        Params.RuntimeContext = RuntimeContext;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        RuntimeContext = Params.RuntimeContext;
    }

    void UFMMEL_TacSprint_BallisticShield_C::ExecuteUbergraph_FMMEL_TacSprint_BallisticShield(int32 EntryPoint, FMMERuntimeContext K2Node_Event_RuntimeContext, FMMERuntimeContext K2Node_Event_RuntimeContext_1)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("FMMEL_TacSprint_BallisticShield.FMMEL_TacSprint_BallisticShield_C.ExecuteUbergraph_FMMEL_TacSprint_BallisticShield");
    
        UFMMEL_TacSprint_BallisticShield_C___ExecuteUbergraph_FMMEL_TacSprint_BallisticShield_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.K2Node_Event_RuntimeContext = K2Node_Event_RuntimeContext;
        Params.K2Node_Event_RuntimeContext_1 = K2Node_Event_RuntimeContext_1;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

