/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:45
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BallisticShieldGameplay/Gameplay/FMMEL_TacSprint_BallisticShield_Functions
 * ============================================================
 */

#include "FMMEL_TacSprint_BallisticShield.hpp"

namespace UE
{

    struct UFMMEL_TacSprint_BallisticShield_C___BP_OnExtensionActivate_Params
    {
        FMMERuntimeContext  RuntimeContext; // 0x000000 (0x000010) [OutParam]
    };

    struct UFMMEL_TacSprint_BallisticShield_C___BP_OnExtensionDeactivate_Params
    {
        FMMERuntimeContext  RuntimeContext; // 0x000000 (0x000010) [OutParam]
    };

    struct UFMMEL_TacSprint_BallisticShield_C___ExecuteUbergraph_FMMEL_TacSprint_BallisticShield_Params
    {
        int32               EntryPoint;                     // 0x000000 (0x000004) [Default: 344817568]
        FMMERuntimeContext  K2Node_Event_RuntimeContext;    // 0x000004 (0x000010)
        FMMERuntimeContext  K2Node_Event_RuntimeContext_1;  // 0x000014 (0x000010)
    };

} // namespace UE

