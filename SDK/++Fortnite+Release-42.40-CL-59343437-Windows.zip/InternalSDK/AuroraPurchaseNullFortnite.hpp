/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AuroraPurchaseNullFortnite
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000138 (0x000058)
    class alignas(0x8) UAuroraPurchaseNullFortnite : public UAuroraPurchaseNull
    {
    public:
        int64   MaxEntitlementMaxCount;         // 0x0000E0 (0x000008) [Default: 10000000ll]
        int64   OfferMaxEntitlementQuantity;    // 0x0000E8 (0x000008) [Default: 500000ll]
        int64   MaxOfferMinAge;                 // 0x0000F0 (0x000008) [Default: 120ll]
        int32   MaxOfferDepth;                  // 0x0000F8 (0x000004) [Default: 5]
        int32   MaxOfferOffers;                 // 0x0000FC (0x000004) [Default: 200]
        int32   MaxOfferEntitlements;           // 0x000100 (0x000004) [Default: 100]
        int32   OfferPriceMultiple;             // 0x000104 (0x000004) [Default: 50]
        int32   MinOfferPrice;                  // 0x000108 (0x000004) [Default: 50]
        int32   MaxOfferPrice;                  // 0x00010C (0x000004) [Default: 5000]
        int32   MinSubOfferPrice;               // 0x000110 (0x000004) [Default: 0]
        int32   MaxSubOfferPrice;               // 0x000114 (0x000004) [Default: 5000]
        int32   MaxSubstitutionDepth;           // 0x000118 (0x000004) [Default: 1]
        bool    bAllowMessageInSubstitution;    // 0x00011C (0x000001) [Default: false]
        uint8   UnknownData_00011D[0x000003];   // 0x00011D (0x000003)
        int32   NameMaxLength;                  // 0x000120 (0x000004) [Default: 50]
        int32   NameMinLength;                  // 0x000124 (0x000004) [Default: 0]
        uint8   UnknownData_000128[0x000004];   // 0x000128 (0x000004)
        int32   DescriptionMinLength;           // 0x00012C (0x000004) [Default: 0]
        int32   ShortDescriptionMaxLength;      // 0x000130 (0x000004) [Default: 100]
        int32   ShortDescriptionMinLength;      // 0x000134 (0x000004) [Default: 0]
    };
}

