/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:48
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /ActorWeakpointsCore/GameplayActors/BGA_WeakpointActor_Base_Functions
 * ============================================================
 */

#include "BGA_WeakpointActor_Base_Functions.hpp"

namespace UE
{

    float ABGA_WeakpointActor_Base_C::BlueprintModifyIncomingDamage(float Damage, FGameplayTagContainer& DamageTags, FGameplayEffectContextHandle& EffectContext, AController* EventInstigator, AActor* DamageCauser, FHitResult CallFunc_EffectContextGetHitResult_ReturnValue, float CallFunc_BlueprintModifyIncomingDamage_ReturnValue, double CallFunc_ProcessHitResult_ModifiedDamage, double CallFunc_ProcessHitResult_Damage_ImplicitCast, float K2Node_FunctionResult_ReturnValue_ImplicitCast)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.BlueprintModifyIncomingDamage");
    
        ABGA_WeakpointActor_Base_C___BlueprintModifyIncomingDamage_Params Params{};
        Params.Damage = Damage;
        Params.DamageTags = DamageTags;
        Params.EffectContext = EffectContext;
        Params.EventInstigator = EventInstigator;
        Params.DamageCauser = DamageCauser;
        Params.CallFunc_EffectContextGetHitResult_ReturnValue = CallFunc_EffectContextGetHitResult_ReturnValue;
        Params.CallFunc_BlueprintModifyIncomingDamage_ReturnValue = CallFunc_BlueprintModifyIncomingDamage_ReturnValue;
        Params.CallFunc_ProcessHitResult_ModifiedDamage = CallFunc_ProcessHitResult_ModifiedDamage;
        Params.CallFunc_ProcessHitResult_Damage_ImplicitCast = CallFunc_ProcessHitResult_Damage_ImplicitCast;
        Params.K2Node_FunctionResult_ReturnValue_ImplicitCast = K2Node_FunctionResult_ReturnValue_ImplicitCast;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        DamageTags = Params.DamageTags;
        EffectContext = Params.EffectContext;
    
        return Params.ReturnValue;
    }

    void ABGA_WeakpointActor_Base_C::DamageWeakPoint(double Damage, bool CallFunc_LessEqual_DoubleDouble_ReturnValue, double CallFunc_Subtract_DoubleDouble_ReturnValue, bool CallFunc_Less_DoubleDouble_ReturnValue, bool CallFunc_ShouldDamageWeakpoint_bShouldDamage, double CallFunc_SelectFloat_ReturnValue, bool CallFunc_HasAuthority_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.DamageWeakPoint");
    
        ABGA_WeakpointActor_Base_C___DamageWeakPoint_Params Params{};
        Params.Damage = Damage;
        Params.CallFunc_LessEqual_DoubleDouble_ReturnValue = CallFunc_LessEqual_DoubleDouble_ReturnValue;
        Params.CallFunc_Subtract_DoubleDouble_ReturnValue = CallFunc_Subtract_DoubleDouble_ReturnValue;
        Params.CallFunc_Less_DoubleDouble_ReturnValue = CallFunc_Less_DoubleDouble_ReturnValue;
        Params.CallFunc_ShouldDamageWeakpoint_bShouldDamage = CallFunc_ShouldDamageWeakpoint_bShouldDamage;
        Params.CallFunc_SelectFloat_ReturnValue = CallFunc_SelectFloat_ReturnValue;
        Params.CallFunc_HasAuthority_ReturnValue = CallFunc_HasAuthority_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABGA_WeakpointActor_Base_C::DestroyWeakpoint(AActor* CallFunc_GetParentActor_ReturnValue, bool CallFunc_HasAuthority_ReturnValue, UBP_ActorWeakpoints_UtilityComponent_C* CallFunc_GetComponentByClass_ReturnValue, bool CallFunc_IsValid_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.DestroyWeakpoint");
    
        ABGA_WeakpointActor_Base_C___DestroyWeakpoint_Params Params{};
        Params.CallFunc_GetParentActor_ReturnValue = CallFunc_GetParentActor_ReturnValue;
        Params.CallFunc_HasAuthority_ReturnValue = CallFunc_HasAuthority_ReturnValue;
        Params.CallFunc_GetComponentByClass_ReturnValue = CallFunc_GetComponentByClass_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABGA_WeakpointActor_Base_C::DisableWeakpoint(bool CallFunc_HasAuthority_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.DisableWeakpoint");
    
        ABGA_WeakpointActor_Base_C___DisableWeakpoint_Params Params{};
        Params.CallFunc_HasAuthority_ReturnValue = CallFunc_HasAuthority_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABGA_WeakpointActor_Base_C::EnableWeakpoint(bool CallFunc_HasAuthority_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.EnableWeakpoint");
    
        ABGA_WeakpointActor_Base_C___EnableWeakpoint_Params Params{};
        Params.CallFunc_HasAuthority_ReturnValue = CallFunc_HasAuthority_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABGA_WeakpointActor_Base_C::ExecuteUbergraph_BGA_WeakpointActor_Base(int32 EntryPoint, bool CallFunc_SetMaxHealth_DontCreateASC_ReturnValue, AActor* CallFunc_GetParentActor_ReturnValue, UAbilitySystemComponent* CallFunc_GetAbilitySystemComponent_ReturnValue, bool CallFunc_IsValid_ReturnValue, float K2Node_Event_Damage, FGameplayTagContainer K2Node_Event_DamageTags, FVector K2Node_Event_Momentum, FHitResult K2Node_Event_HitInfo, AFortPawn* K2Node_Event_InstigatedBy, AActor* K2Node_Event_DamageCauser, FGameplayEffectContextHandle K2Node_Event_EffectContext, FVector CallFunc_K2_GetActorLocation_ReturnValue, bool CallFunc_IsLocallyControlled_ReturnValue, bool CallFunc_BreakHitResult_bBlockingHit, bool CallFunc_BreakHitResult_bInitialOverlap, float CallFunc_BreakHitResult_Time, float CallFunc_BreakHitResult_Distance, FVector CallFunc_BreakHitResult_Location, FVector CallFunc_BreakHitResult_ImpactPoint, FVector CallFunc_BreakHitResult_Normal, FVector CallFunc_BreakHitResult_ImpactNormal, UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat, AActor* CallFunc_BreakHitResult_HitActor, UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent, FName CallFunc_BreakHitResult_HitBoneName, FName CallFunc_BreakHitResult_BoneName, int32 CallFunc_BreakHitResult_HitItem, int32 CallFunc_BreakHitResult_ElementIndex, int32 CallFunc_BreakHitResult_FaceIndex, FVector CallFunc_BreakHitResult_TraceStart, FVector CallFunc_BreakHitResult_TraceEnd, FRotator CallFunc_Conv_VectorToRotator_ReturnValue, UFXSystemComponent* CallFunc_SpawnFXAtLocation_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, UFortAbilitySystemComponent* CallFunc_GetFortAbilitySystemComponent_ReturnValue, FGameplayEffectSpecHandle CallFunc_MakeOutgoingSpec_ReturnValue, float K2Node_Event_Damage_1, FGameplayTagContainer K2Node_Event_DamageTags_1, FVector K2Node_Event_Momentum_1, FHitResult K2Node_Event_HitInfo_1, AController* K2Node_Event_InstigatedBy_1, AActor* K2Node_Event_DamageCauser_1, FGameplayEffectContextHandle K2Node_Event_EffectContext_1, UAbilitySystemComponent* CallFunc_GetAbilitySystemComponent_ReturnValue_1, FGameplayEffectSpecHandle CallFunc_AssignTagSetByCallerMagnitude_ReturnValue, FActiveGameplayEffectHandle CallFunc_BP_ApplyGameplayEffectSpecToTarget_ReturnValue, FHitResult K2Node_CustomEvent_Hit_Result, bool CallFunc_BreakHitResult_bBlockingHit_1, bool CallFunc_BreakHitResult_bInitialOverlap_1, float CallFunc_BreakHitResult_Time_1, float CallFunc_BreakHitResult_Distance_1, FVector CallFunc_BreakHitResult_Location_1, FVector CallFunc_BreakHitResult_ImpactPoint_1, FVector CallFunc_BreakHitResult_Normal_1, FVector CallFunc_BreakHitResult_ImpactNormal_1, UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat_1, AActor* CallFunc_BreakHitResult_HitActor_1, UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent_1, FName CallFunc_BreakHitResult_HitBoneName_1, FName CallFunc_BreakHitResult_BoneName_1, int32 CallFunc_BreakHitResult_HitItem_1, int32 CallFunc_BreakHitResult_ElementIndex_1, int32 CallFunc_BreakHitResult_FaceIndex_1, FVector CallFunc_BreakHitResult_TraceStart_1, FVector CallFunc_BreakHitResult_TraceEnd_1, FRotator CallFunc_Conv_VectorToRotator_ReturnValue_1, bool CallFunc_IsDedicatedServer_ReturnValue, UFXSystemComponent* CallFunc_SpawnFXAtLocation_ReturnValue_1, bool CallFunc_IsValid_ReturnValue_2, bool CallFunc_IsDedicatedServer_ReturnValue_1, bool CallFunc_IsValid_ReturnValue_3, bool CallFunc_IsValid_ReturnValue_4, FGameplayEffectSpecHandle CallFunc_MakeSpecHandleByClass_ReturnValue, FGameplayEffectSpecHandle CallFunc_AssignTagSetByCallerMagnitude_ReturnValue_1, bool CallFunc_IsLocallyViewed_ReturnValue, FActiveGameplayEffectHandle CallFunc_BP_ApplyGameplayEffectSpecToTarget_ReturnValue_1, double CallFunc_DamageWeakpoint_Damage_ImplicitCast, double CallFunc_NotifyParent_Damage_ImplicitCast)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.ExecuteUbergraph_BGA_WeakpointActor_Base");
    
        ABGA_WeakpointActor_Base_C___ExecuteUbergraph_BGA_WeakpointActor_Base_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.CallFunc_SetMaxHealth_DontCreateASC_ReturnValue = CallFunc_SetMaxHealth_DontCreateASC_ReturnValue;
        Params.CallFunc_GetParentActor_ReturnValue = CallFunc_GetParentActor_ReturnValue;
        Params.CallFunc_GetAbilitySystemComponent_ReturnValue = CallFunc_GetAbilitySystemComponent_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.K2Node_Event_Damage = K2Node_Event_Damage;
        Params.K2Node_Event_DamageTags = K2Node_Event_DamageTags;
        Params.K2Node_Event_Momentum = K2Node_Event_Momentum;
        Params.K2Node_Event_HitInfo = K2Node_Event_HitInfo;
        Params.K2Node_Event_InstigatedBy = K2Node_Event_InstigatedBy;
        Params.K2Node_Event_DamageCauser = K2Node_Event_DamageCauser;
        Params.K2Node_Event_EffectContext = K2Node_Event_EffectContext;
        Params.CallFunc_K2_GetActorLocation_ReturnValue = CallFunc_K2_GetActorLocation_ReturnValue;
        Params.CallFunc_IsLocallyControlled_ReturnValue = CallFunc_IsLocallyControlled_ReturnValue;
        Params.CallFunc_BreakHitResult_bBlockingHit = CallFunc_BreakHitResult_bBlockingHit;
        Params.CallFunc_BreakHitResult_bInitialOverlap = CallFunc_BreakHitResult_bInitialOverlap;
        Params.CallFunc_BreakHitResult_Time = CallFunc_BreakHitResult_Time;
        Params.CallFunc_BreakHitResult_Distance = CallFunc_BreakHitResult_Distance;
        Params.CallFunc_BreakHitResult_Location = CallFunc_BreakHitResult_Location;
        Params.CallFunc_BreakHitResult_ImpactPoint = CallFunc_BreakHitResult_ImpactPoint;
        Params.CallFunc_BreakHitResult_Normal = CallFunc_BreakHitResult_Normal;
        Params.CallFunc_BreakHitResult_ImpactNormal = CallFunc_BreakHitResult_ImpactNormal;
        Params.CallFunc_BreakHitResult_PhysMat = CallFunc_BreakHitResult_PhysMat;
        Params.CallFunc_BreakHitResult_HitActor = CallFunc_BreakHitResult_HitActor;
        Params.CallFunc_BreakHitResult_HitComponent = CallFunc_BreakHitResult_HitComponent;
        Params.CallFunc_BreakHitResult_HitBoneName = CallFunc_BreakHitResult_HitBoneName;
        Params.CallFunc_BreakHitResult_BoneName = CallFunc_BreakHitResult_BoneName;
        Params.CallFunc_BreakHitResult_HitItem = CallFunc_BreakHitResult_HitItem;
        Params.CallFunc_BreakHitResult_ElementIndex = CallFunc_BreakHitResult_ElementIndex;
        Params.CallFunc_BreakHitResult_FaceIndex = CallFunc_BreakHitResult_FaceIndex;
        Params.CallFunc_BreakHitResult_TraceStart = CallFunc_BreakHitResult_TraceStart;
        Params.CallFunc_BreakHitResult_TraceEnd = CallFunc_BreakHitResult_TraceEnd;
        Params.CallFunc_Conv_VectorToRotator_ReturnValue = CallFunc_Conv_VectorToRotator_ReturnValue;
        Params.CallFunc_SpawnFXAtLocation_ReturnValue = CallFunc_SpawnFXAtLocation_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
        Params.CallFunc_GetFortAbilitySystemComponent_ReturnValue = CallFunc_GetFortAbilitySystemComponent_ReturnValue;
        Params.CallFunc_MakeOutgoingSpec_ReturnValue = CallFunc_MakeOutgoingSpec_ReturnValue;
        Params.K2Node_Event_Damage_1 = K2Node_Event_Damage_1;
        Params.K2Node_Event_DamageTags_1 = K2Node_Event_DamageTags_1;
        Params.K2Node_Event_Momentum_1 = K2Node_Event_Momentum_1;
        Params.K2Node_Event_HitInfo_1 = K2Node_Event_HitInfo_1;
        Params.K2Node_Event_InstigatedBy_1 = K2Node_Event_InstigatedBy_1;
        Params.K2Node_Event_DamageCauser_1 = K2Node_Event_DamageCauser_1;
        Params.K2Node_Event_EffectContext_1 = K2Node_Event_EffectContext_1;
        Params.CallFunc_GetAbilitySystemComponent_ReturnValue_1 = CallFunc_GetAbilitySystemComponent_ReturnValue_1;
        Params.CallFunc_AssignTagSetByCallerMagnitude_ReturnValue = CallFunc_AssignTagSetByCallerMagnitude_ReturnValue;
        Params.CallFunc_BP_ApplyGameplayEffectSpecToTarget_ReturnValue = CallFunc_BP_ApplyGameplayEffectSpecToTarget_ReturnValue;
        Params.K2Node_CustomEvent_Hit_Result = K2Node_CustomEvent_Hit_Result;
        Params.CallFunc_BreakHitResult_bBlockingHit_1 = CallFunc_BreakHitResult_bBlockingHit_1;
        Params.CallFunc_BreakHitResult_bInitialOverlap_1 = CallFunc_BreakHitResult_bInitialOverlap_1;
        Params.CallFunc_BreakHitResult_Time_1 = CallFunc_BreakHitResult_Time_1;
        Params.CallFunc_BreakHitResult_Distance_1 = CallFunc_BreakHitResult_Distance_1;
        Params.CallFunc_BreakHitResult_Location_1 = CallFunc_BreakHitResult_Location_1;
        Params.CallFunc_BreakHitResult_ImpactPoint_1 = CallFunc_BreakHitResult_ImpactPoint_1;
        Params.CallFunc_BreakHitResult_Normal_1 = CallFunc_BreakHitResult_Normal_1;
        Params.CallFunc_BreakHitResult_ImpactNormal_1 = CallFunc_BreakHitResult_ImpactNormal_1;
        Params.CallFunc_BreakHitResult_PhysMat_1 = CallFunc_BreakHitResult_PhysMat_1;
        Params.CallFunc_BreakHitResult_HitActor_1 = CallFunc_BreakHitResult_HitActor_1;
        Params.CallFunc_BreakHitResult_HitComponent_1 = CallFunc_BreakHitResult_HitComponent_1;
        Params.CallFunc_BreakHitResult_HitBoneName_1 = CallFunc_BreakHitResult_HitBoneName_1;
        Params.CallFunc_BreakHitResult_BoneName_1 = CallFunc_BreakHitResult_BoneName_1;
        Params.CallFunc_BreakHitResult_HitItem_1 = CallFunc_BreakHitResult_HitItem_1;
        Params.CallFunc_BreakHitResult_ElementIndex_1 = CallFunc_BreakHitResult_ElementIndex_1;
        Params.CallFunc_BreakHitResult_FaceIndex_1 = CallFunc_BreakHitResult_FaceIndex_1;
        Params.CallFunc_BreakHitResult_TraceStart_1 = CallFunc_BreakHitResult_TraceStart_1;
        Params.CallFunc_BreakHitResult_TraceEnd_1 = CallFunc_BreakHitResult_TraceEnd_1;
        Params.CallFunc_Conv_VectorToRotator_ReturnValue_1 = CallFunc_Conv_VectorToRotator_ReturnValue_1;
        Params.CallFunc_IsDedicatedServer_ReturnValue = CallFunc_IsDedicatedServer_ReturnValue;
        Params.CallFunc_SpawnFXAtLocation_ReturnValue_1 = CallFunc_SpawnFXAtLocation_ReturnValue_1;
        Params.CallFunc_IsValid_ReturnValue_2 = CallFunc_IsValid_ReturnValue_2;
        Params.CallFunc_IsDedicatedServer_ReturnValue_1 = CallFunc_IsDedicatedServer_ReturnValue_1;
        Params.CallFunc_IsValid_ReturnValue_3 = CallFunc_IsValid_ReturnValue_3;
        Params.CallFunc_IsValid_ReturnValue_4 = CallFunc_IsValid_ReturnValue_4;
        Params.CallFunc_MakeSpecHandleByClass_ReturnValue = CallFunc_MakeSpecHandleByClass_ReturnValue;
        Params.CallFunc_AssignTagSetByCallerMagnitude_ReturnValue_1 = CallFunc_AssignTagSetByCallerMagnitude_ReturnValue_1;
        Params.CallFunc_IsLocallyViewed_ReturnValue = CallFunc_IsLocallyViewed_ReturnValue;
        Params.CallFunc_BP_ApplyGameplayEffectSpecToTarget_ReturnValue_1 = CallFunc_BP_ApplyGameplayEffectSpecToTarget_ReturnValue_1;
        Params.CallFunc_DamageWeakpoint_Damage_ImplicitCast = CallFunc_DamageWeakpoint_Damage_ImplicitCast;
        Params.CallFunc_NotifyParent_Damage_ImplicitCast = CallFunc_NotifyParent_Damage_ImplicitCast;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    AActor* ABGA_WeakpointActor_Base_C::GetTargetOwner()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.GetTargetOwner");
    
        ABGA_WeakpointActor_Base_C___GetTargetOwner_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void ABGA_WeakpointActor_Base_C::HandleCollisionEnabled()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.HandleCollisionEnabled");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    bool ABGA_WeakpointActor_Base_C::IsValidAutoFireTarget(AActor* Attacker)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.IsValidAutoFireTarget");
    
        ABGA_WeakpointActor_Base_C___IsValidAutoFireTarget_Params Params{};
        Params.Attacker = Attacker;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void ABGA_WeakpointActor_Base_C::NotifyParent(double Damage, AController* InstigatedBy, AActor* DamageCauser)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.NotifyParent");
    
        ABGA_WeakpointActor_Base_C___NotifyParent_Params Params{};
        Params.Damage = Damage;
        Params.InstigatedBy = InstigatedBy;
        Params.DamageCauser = DamageCauser;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABGA_WeakpointActor_Base_C::OnDamagePlayEffects(float Damage, FGameplayTagContainer& DamageTags, FVector Momentum, FHitResult& HitInfo, AFortPawn* InstigatedBy, AActor* DamageCauser, FGameplayEffectContextHandle EffectContext)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.OnDamagePlayEffects");
    
        ABGA_WeakpointActor_Base_C___OnDamagePlayEffects_Params Params{};
        Params.Damage = Damage;
        Params.DamageTags = DamageTags;
        Params.Momentum = Momentum;
        Params.HitInfo = HitInfo;
        Params.InstigatedBy = InstigatedBy;
        Params.DamageCauser = DamageCauser;
        Params.EffectContext = EffectContext;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        DamageTags = Params.DamageTags;
        HitInfo = Params.HitInfo;
    }

    void ABGA_WeakpointActor_Base_C::OnDamageServer(float Damage, FGameplayTagContainer& DamageTags, FVector Momentum, FHitResult& HitInfo, AController* InstigatedBy, AActor* DamageCauser, FGameplayEffectContextHandle EffectContext)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.OnDamageServer");
    
        ABGA_WeakpointActor_Base_C___OnDamageServer_Params Params{};
        Params.Damage = Damage;
        Params.DamageTags = DamageTags;
        Params.Momentum = Momentum;
        Params.HitInfo = HitInfo;
        Params.InstigatedBy = InstigatedBy;
        Params.DamageCauser = DamageCauser;
        Params.EffectContext = EffectContext;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        DamageTags = Params.DamageTags;
        HitInfo = Params.HitInfo;
    }

    void ABGA_WeakpointActor_Base_C::OnRep_bCollisionEnabled()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.OnRep_bCollisionEnabled");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ABGA_WeakpointActor_Base_C::PlayRicochet(FHitResult Hit_Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.PlayRicochet");
    
        ABGA_WeakpointActor_Base_C___PlayRicochet_Params Params{};
        Params.Hit_Result = Hit_Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABGA_WeakpointActor_Base_C::ProcessHealthDepleted()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.ProcessHealthDepleted");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ABGA_WeakpointActor_Base_C::ProcessHitResult(double Damage, FHitResult HitResult, double& ModifiedDamage)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.ProcessHitResult");
    
        ABGA_WeakpointActor_Base_C___ProcessHitResult_Params Params{};
        Params.Damage = Damage;
        Params.HitResult = HitResult;
        Params.ModifiedDamage = ModifiedDamage;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ModifiedDamage = Params.ModifiedDamage;
    }

    void ABGA_WeakpointActor_Base_C::ReceiveBeginPlay()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.ReceiveBeginPlay");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void ABGA_WeakpointActor_Base_C::ResetWeakpointHealth(float CallFunc_GetValueAtLevel_ReturnValue, bool CallFunc_Greater_DoubleDouble_ReturnValue, double K2Node_VariableSet_Weakpoint_CurrentHealth_ImplicitCast, double CallFunc_Greater_DoubleDouble_A_ImplicitCast)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.ResetWeakpointHealth");
    
        ABGA_WeakpointActor_Base_C___ResetWeakpointHealth_Params Params{};
        Params.CallFunc_GetValueAtLevel_ReturnValue = CallFunc_GetValueAtLevel_ReturnValue;
        Params.CallFunc_Greater_DoubleDouble_ReturnValue = CallFunc_Greater_DoubleDouble_ReturnValue;
        Params.K2Node_VariableSet_Weakpoint_CurrentHealth_ImplicitCast = K2Node_VariableSet_Weakpoint_CurrentHealth_ImplicitCast;
        Params.CallFunc_Greater_DoubleDouble_A_ImplicitCast = CallFunc_Greater_DoubleDouble_A_ImplicitCast;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABGA_WeakpointActor_Base_C::SetWeakpointCollisionKind(TEnumAsByte<Enum_WeakpointActor_CollisionKind> WeakpointCollisionKind, UBoxComponent* BoxCollision, UCapsuleComponent* CapsuleCollision, USphereComponent* SphereCollision, bool K2Node_SwitchEnum_CmpSuccess)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.SetWeakpointCollisionKind");
    
        ABGA_WeakpointActor_Base_C___SetWeakpointCollisionKind_Params Params{};
        Params.WeakpointCollisionKind = WeakpointCollisionKind;
        Params.BoxCollision = BoxCollision;
        Params.CapsuleCollision = CapsuleCollision;
        Params.SphereCollision = SphereCollision;
        Params.K2Node_SwitchEnum_CmpSuccess = K2Node_SwitchEnum_CmpSuccess;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool ABGA_WeakpointActor_Base_C::ShouldAlliesAutoFireOnDeployedTarget()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.ShouldAlliesAutoFireOnDeployedTarget");
    
        ABGA_WeakpointActor_Base_C___ShouldAlliesAutoFireOnDeployedTarget_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool ABGA_WeakpointActor_Base_C::ShouldAutoFireOnSelfDeployedTarget()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.ShouldAutoFireOnSelfDeployedTarget");
    
        ABGA_WeakpointActor_Base_C___ShouldAutoFireOnSelfDeployedTarget_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void ABGA_WeakpointActor_Base_C::ShouldDamageWeakpoint(bool& bShouldDamage, bool CallFunc_BooleanAND_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.ShouldDamageWeakpoint");
    
        ABGA_WeakpointActor_Base_C___ShouldDamageWeakpoint_Params Params{};
        Params.bShouldDamage = bShouldDamage;
        Params.CallFunc_BooleanAND_ReturnValue = CallFunc_BooleanAND_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        bShouldDamage = Params.bShouldDamage;
    }

    void ABGA_WeakpointActor_Base_C::UpdateWeakpointCollision(bool bEnableCollision, TEnumAsByte<Enum_WeakpointActor_CollisionKind> CollisionKind, UPrimitiveComponent* CollisionComponent, UPrimitiveComponent* CollisionKindComponent, TEnumAsByte<ECollisionResponse> Temp_byte_Variable, bool CallFunc_IsValid_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, bool K2Node_SwitchEnum_CmpSuccess, bool Temp_bool_Variable, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_1, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_2, bool Temp_bool_Variable_1, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_3, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_4, bool Temp_bool_Variable_2, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_5, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_6, bool Temp_bool_Variable_3, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_7, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_8, bool Temp_bool_Variable_4, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_9, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_10, bool Temp_bool_Variable_5, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_11, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_12, bool Temp_bool_Variable_6, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_13, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_14, bool Temp_bool_Variable_7, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_15, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_16, bool Temp_bool_Variable_8, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_17, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_18, bool Temp_bool_Variable_9, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_19, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_20, bool Temp_bool_Variable_10, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_21, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_22, bool Temp_bool_Variable_11, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_23, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_24, bool Temp_bool_Variable_12, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_25, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_26, bool Temp_bool_Variable_13, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_27, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_28, bool Temp_bool_Variable_14, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_29, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_30, bool Temp_bool_Variable_15, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_31, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_32, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_33, bool Temp_bool_Variable_16, TEnumAsByte<ECollisionResponse> K2Node_Select_Default, TEnumAsByte<ECollisionResponse> K2Node_Select_Default_1, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_34, TEnumAsByte<ECollisionResponse> K2Node_Select_Default_2, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_35, TEnumAsByte<ECollisionResponse> K2Node_Select_Default_3, bool Temp_bool_Variable_17, TEnumAsByte<ECollisionResponse> K2Node_Select_Default_4, TEnumAsByte<ECollisionResponse> K2Node_Select_Default_5, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_36, TEnumAsByte<ECollisionResponse> Temp_byte_Variable_37, TEnumAsByte<ECollisionResponse> K2Node_Select_Default_6, TEnumAsByte<ECollisionResponse> K2Node_Select_Default_7, TEnumAsByte<ECollisionResponse> K2Node_Select_Default_8, bool Temp_bool_Variable_18, TEnumAsByte<ECollisionResponse> K2Node_Select_Default_9, TEnumAsByte<ECollisionResponse> K2Node_Select_Default_10, TEnumAsByte<ECollisionEnabled> Temp_byte_Variable_38, TEnumAsByte<ECollisionResponse> K2Node_Select_Default_11, TEnumAsByte<ECollisionResponse> K2Node_Select_Default_12, TEnumAsByte<ECollisionResponse> K2Node_Select_Default_13, TEnumAsByte<ECollisionEnabled> Temp_byte_Variable_39, TEnumAsByte<ECollisionResponse> K2Node_Select_Default_14, bool Temp_bool_Variable_19, TEnumAsByte<ECollisionResponse> K2Node_Select_Default_15, TEnumAsByte<ECollisionEnabled> K2Node_Select_Default_16, TEnumAsByte<ECollisionResponse> K2Node_Select_Default_17, bool Temp_bool_Variable_20, TEnumAsByte<ECollisionResponse> K2Node_Select_Default_18, TEnumAsByte<ECollisionResponse> K2Node_Select_Default_19, UPrimitiveComponent* K2Node_Select_Default_20)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.UpdateWeakpointCollision");
    
        ABGA_WeakpointActor_Base_C___UpdateWeakpointCollision_Params Params{};
        Params.bEnableCollision = bEnableCollision;
        Params.CollisionKind = CollisionKind;
        Params.CollisionComponent = CollisionComponent;
        Params.CollisionKindComponent = CollisionKindComponent;
        Params.Temp_byte_Variable = Temp_byte_Variable;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
        Params.K2Node_SwitchEnum_CmpSuccess = K2Node_SwitchEnum_CmpSuccess;
        Params.Temp_bool_Variable = Temp_bool_Variable;
        Params.Temp_byte_Variable_1 = Temp_byte_Variable_1;
        Params.Temp_byte_Variable_2 = Temp_byte_Variable_2;
        Params.Temp_bool_Variable_1 = Temp_bool_Variable_1;
        Params.Temp_byte_Variable_3 = Temp_byte_Variable_3;
        Params.Temp_byte_Variable_4 = Temp_byte_Variable_4;
        Params.Temp_bool_Variable_2 = Temp_bool_Variable_2;
        Params.Temp_byte_Variable_5 = Temp_byte_Variable_5;
        Params.Temp_byte_Variable_6 = Temp_byte_Variable_6;
        Params.Temp_bool_Variable_3 = Temp_bool_Variable_3;
        Params.Temp_byte_Variable_7 = Temp_byte_Variable_7;
        Params.Temp_byte_Variable_8 = Temp_byte_Variable_8;
        Params.Temp_bool_Variable_4 = Temp_bool_Variable_4;
        Params.Temp_byte_Variable_9 = Temp_byte_Variable_9;
        Params.Temp_byte_Variable_10 = Temp_byte_Variable_10;
        Params.Temp_bool_Variable_5 = Temp_bool_Variable_5;
        Params.Temp_byte_Variable_11 = Temp_byte_Variable_11;
        Params.Temp_byte_Variable_12 = Temp_byte_Variable_12;
        Params.Temp_bool_Variable_6 = Temp_bool_Variable_6;
        Params.Temp_byte_Variable_13 = Temp_byte_Variable_13;
        Params.Temp_byte_Variable_14 = Temp_byte_Variable_14;
        Params.Temp_bool_Variable_7 = Temp_bool_Variable_7;
        Params.Temp_byte_Variable_15 = Temp_byte_Variable_15;
        Params.Temp_byte_Variable_16 = Temp_byte_Variable_16;
        Params.Temp_bool_Variable_8 = Temp_bool_Variable_8;
        Params.Temp_byte_Variable_17 = Temp_byte_Variable_17;
        Params.Temp_byte_Variable_18 = Temp_byte_Variable_18;
        Params.Temp_bool_Variable_9 = Temp_bool_Variable_9;
        Params.Temp_byte_Variable_19 = Temp_byte_Variable_19;
        Params.Temp_byte_Variable_20 = Temp_byte_Variable_20;
        Params.Temp_bool_Variable_10 = Temp_bool_Variable_10;
        Params.Temp_byte_Variable_21 = Temp_byte_Variable_21;
        Params.Temp_byte_Variable_22 = Temp_byte_Variable_22;
        Params.Temp_bool_Variable_11 = Temp_bool_Variable_11;
        Params.Temp_byte_Variable_23 = Temp_byte_Variable_23;
        Params.Temp_byte_Variable_24 = Temp_byte_Variable_24;
        Params.Temp_bool_Variable_12 = Temp_bool_Variable_12;
        Params.Temp_byte_Variable_25 = Temp_byte_Variable_25;
        Params.Temp_byte_Variable_26 = Temp_byte_Variable_26;
        Params.Temp_bool_Variable_13 = Temp_bool_Variable_13;
        Params.Temp_byte_Variable_27 = Temp_byte_Variable_27;
        Params.Temp_byte_Variable_28 = Temp_byte_Variable_28;
        Params.Temp_bool_Variable_14 = Temp_bool_Variable_14;
        Params.Temp_byte_Variable_29 = Temp_byte_Variable_29;
        Params.Temp_byte_Variable_30 = Temp_byte_Variable_30;
        Params.Temp_bool_Variable_15 = Temp_bool_Variable_15;
        Params.Temp_byte_Variable_31 = Temp_byte_Variable_31;
        Params.Temp_byte_Variable_32 = Temp_byte_Variable_32;
        Params.Temp_byte_Variable_33 = Temp_byte_Variable_33;
        Params.Temp_bool_Variable_16 = Temp_bool_Variable_16;
        Params.K2Node_Select_Default = K2Node_Select_Default;
        Params.K2Node_Select_Default_1 = K2Node_Select_Default_1;
        Params.Temp_byte_Variable_34 = Temp_byte_Variable_34;
        Params.K2Node_Select_Default_2 = K2Node_Select_Default_2;
        Params.Temp_byte_Variable_35 = Temp_byte_Variable_35;
        Params.K2Node_Select_Default_3 = K2Node_Select_Default_3;
        Params.Temp_bool_Variable_17 = Temp_bool_Variable_17;
        Params.K2Node_Select_Default_4 = K2Node_Select_Default_4;
        Params.K2Node_Select_Default_5 = K2Node_Select_Default_5;
        Params.Temp_byte_Variable_36 = Temp_byte_Variable_36;
        Params.Temp_byte_Variable_37 = Temp_byte_Variable_37;
        Params.K2Node_Select_Default_6 = K2Node_Select_Default_6;
        Params.K2Node_Select_Default_7 = K2Node_Select_Default_7;
        Params.K2Node_Select_Default_8 = K2Node_Select_Default_8;
        Params.Temp_bool_Variable_18 = Temp_bool_Variable_18;
        Params.K2Node_Select_Default_9 = K2Node_Select_Default_9;
        Params.K2Node_Select_Default_10 = K2Node_Select_Default_10;
        Params.Temp_byte_Variable_38 = Temp_byte_Variable_38;
        Params.K2Node_Select_Default_11 = K2Node_Select_Default_11;
        Params.K2Node_Select_Default_12 = K2Node_Select_Default_12;
        Params.K2Node_Select_Default_13 = K2Node_Select_Default_13;
        Params.Temp_byte_Variable_39 = Temp_byte_Variable_39;
        Params.K2Node_Select_Default_14 = K2Node_Select_Default_14;
        Params.Temp_bool_Variable_19 = Temp_bool_Variable_19;
        Params.K2Node_Select_Default_15 = K2Node_Select_Default_15;
        Params.K2Node_Select_Default_16 = K2Node_Select_Default_16;
        Params.K2Node_Select_Default_17 = K2Node_Select_Default_17;
        Params.Temp_bool_Variable_20 = Temp_bool_Variable_20;
        Params.K2Node_Select_Default_18 = K2Node_Select_Default_18;
        Params.K2Node_Select_Default_19 = K2Node_Select_Default_19;
        Params.K2Node_Select_Default_20 = K2Node_Select_Default_20;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void ABGA_WeakpointActor_Base_C::WeakPointDestroyed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BGA_WeakpointActor_Base.BGA_WeakpointActor_Base_C.WeakPointDestroyed");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

} // namespace UE

