/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:48
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /ActorWeakpointsCore/GameplayActors/BGA_WeakpointActor_Base_Functions
 * ============================================================
 */

#include "BGA_WeakpointActor_Base.hpp"

namespace UE
{

    struct ABGA_WeakpointActor_Base_C___BlueprintModifyIncomingDamage_Params
    {
        float                           Damage;                                             // 0x000000 (0x000004) [Default: 4.47479e-27f]
        uint8                           UnknownData_000004[0x000004];                       // 0x000004 (0x000004)
        FGameplayTagContainer           DamageTags;                                         // 0x000008 (0x000020) [OutParam]
        FGameplayEffectContextHandle    EffectContext;                                      // 0x000028 (0x000018) [OutParam]
        AController*                    EventInstigator;                                    // 0x000040 (0x000008) [Default: nullptr]
        AActor*                         DamageCauser;                                       // 0x000048 (0x000008) [Default: nullptr]
        float                           ReturnValue;                                        // 0x000050 (0x000004) [ReturnValue] [Default: 0f]
        uint8                           UnknownData_000054[0x000004];                       // 0x000054 (0x000004)
        FHitResult                      CallFunc_EffectContextGetHitResult_ReturnValue;     // 0x000058 (0x0000F8)
        float                           CallFunc_BlueprintModifyIncomingDamage_ReturnValue; // 0x000150 (0x000004)
        uint8                           UnknownData_000154[0x000004];                       // 0x000154 (0x000004)
        double                          CallFunc_ProcessHitResult_ModifiedDamage;           // 0x000158 (0x000008) [Default: 0]
        double                          CallFunc_ProcessHitResult_Damage_ImplicitCast;      // 0x000160 (0x000008) [Default: 1.39618e-309]
        float                           K2Node_FunctionResult_ReturnValue_ImplicitCast;     // 0x000168 (0x000004) [Default: 0f]
    };

    struct ABGA_WeakpointActor_Base_C___DamageWeakPoint_Params
    {
        double  Damage;                                         // 0x000000 (0x000008) [Default: 1.63232e-315]
        bool    CallFunc_LessEqual_DoubleDouble_ReturnValue;    // 0x000008 (0x000001) [Default: true]
        uint8   UnknownData_000009[0x000007];                   // 0x000009 (0x000007)
        double  CallFunc_Subtract_DoubleDouble_ReturnValue;     // 0x000010 (0x000008) [Default: 6.9495e-310]
        bool    CallFunc_Less_DoubleDouble_ReturnValue;         // 0x000018 (0x000001) [Default: true]
        bool    CallFunc_ShouldDamageWeakpoint_bShouldDamage;   // 0x000019 (0x000001) [Default: true]
        uint8   UnknownData_00001A[0x000006];                   // 0x00001A (0x000006)
        double  CallFunc_SelectFloat_ReturnValue;               // 0x000020 (0x000008) [Default: 1.16766e-314]
        bool    CallFunc_HasAuthority_ReturnValue;              // 0x000028 (0x000001) [Default: true]
    };

    struct ABGA_WeakpointActor_Base_C___DestroyWeakpoint_Params
    {
        AActor*                                 CallFunc_GetParentActor_ReturnValue;        // 0x000000 (0x000008) [Default: 0x13B143C0]
        bool                                    CallFunc_HasAuthority_ReturnValue;          // 0x000008 (0x000001) [Default: true]
        uint8                                   UnknownData_000009[0x000007];               // 0x000009 (0x000007)
        UBP_ActorWeakpoints_UtilityComponent_C* CallFunc_GetComponentByClass_ReturnValue;   // 0x000010 (0x000008) [Default: 0x7FEDD9AD97E0]
        bool                                    CallFunc_IsValid_ReturnValue;               // 0x000018 (0x000001) [Default: true]
    };

    struct ABGA_WeakpointActor_Base_C___DisableWeakpoint_Params
    {
        bool    CallFunc_HasAuthority_ReturnValue;  // 0x000000 (0x000001) [Default: true]
    };

    struct ABGA_WeakpointActor_Base_C___EnableWeakpoint_Params
    {
        bool    CallFunc_HasAuthority_ReturnValue;  // 0x000000 (0x000001) [Default: true]
    };

    struct ABGA_WeakpointActor_Base_C___ExecuteUbergraph_BGA_WeakpointActor_Base_Params
    {
        int32                           EntryPoint;                                                 // 0x000000 (0x000004) [Default: 330384320]
        bool                            CallFunc_SetMaxHealth_DontCreateASC_ReturnValue;            // 0x000004 (0x000001) [Default: false]
        uint8                           UnknownData_000005[0x000003];                               // 0x000005 (0x000003)
        AActor*                         CallFunc_GetParentActor_ReturnValue;                        // 0x000008 (0x000008) [Default: 0x625B1DDD00280031]
        UAbilitySystemComponent*        CallFunc_GetAbilitySystemComponent_ReturnValue;             // 0x000010 (0x000008) [Default: 0x7FEDD9AD97E0]
        bool                            CallFunc_IsValid_ReturnValue;                               // 0x000018 (0x000001) [Default: true]
        uint8                           UnknownData_000019[0x000003];                               // 0x000019 (0x000003)
        float                           K2Node_Event_Damage;                                        // 0x00001C (0x000004) [Default: 4.58855e-41f]
        FGameplayTagContainer           K2Node_Event_DamageTags;                                    // 0x000020 (0x000020)
        FVector                         K2Node_Event_Momentum;                                      // 0x000040 (0x000018)
        FHitResult                      K2Node_Event_HitInfo;                                       // 0x000058 (0x0000F8)
        AFortPawn*                      K2Node_Event_InstigatedBy;                                  // 0x000150 (0x000008) [Default: 0xFFFFFFFF]
        AActor*                         K2Node_Event_DamageCauser;                                  // 0x000158 (0x000008) [Default: nullptr]
        FGameplayEffectContextHandle    K2Node_Event_EffectContext;                                 // 0x000160 (0x000018)
        FVector                         CallFunc_K2_GetActorLocation_ReturnValue;                   // 0x000178 (0x000018)
        bool                            CallFunc_IsLocallyControlled_ReturnValue;                   // 0x000190 (0x000001) [Default: false]
        bool                            CallFunc_BreakHitResult_bBlockingHit;                       // 0x000191 (0x000001) [Default: false]
        bool                            CallFunc_BreakHitResult_bInitialOverlap;                    // 0x000192 (0x000001) [Default: false]
        uint8                           UnknownByte_000193;                                         // 0x000193 (0x000001)
        float                           CallFunc_BreakHitResult_Time;                               // 0x000194 (0x000004) [Default: 0f]
        float                           CallFunc_BreakHitResult_Distance;                           // 0x000198 (0x000004) [Default: 0f]
        uint8                           UnknownData_00019C[0x000004];                               // 0x00019C (0x000004)
        FVector                         CallFunc_BreakHitResult_Location;                           // 0x0001A0 (0x000018)
        FVector                         CallFunc_BreakHitResult_ImpactPoint;                        // 0x0001B8 (0x000018)
        FVector                         CallFunc_BreakHitResult_Normal;                             // 0x0001D0 (0x000018)
        FVector                         CallFunc_BreakHitResult_ImpactNormal;                       // 0x0001E8 (0x000018)
        UPhysicalMaterial*              CallFunc_BreakHitResult_PhysMat;                            // 0x000200 (0x000008) [Default: nullptr]
        AActor*                         CallFunc_BreakHitResult_HitActor;                           // 0x000208 (0x000008) [Default: nullptr]
        UPrimitiveComponent*            CallFunc_BreakHitResult_HitComponent;                       // 0x000210 (0x000008) [Default: nullptr]
        FName                           CallFunc_BreakHitResult_HitBoneName;                        // 0x000218 (0x000004) [Default: NAME_None]
        FName                           CallFunc_BreakHitResult_BoneName;                           // 0x00021C (0x000004) [Default: NAME_None]
        int32                           CallFunc_BreakHitResult_HitItem;                            // 0x000220 (0x000004) [Default: 0]
        int32                           CallFunc_BreakHitResult_ElementIndex;                       // 0x000224 (0x000004) [Default: 0]
        int32                           CallFunc_BreakHitResult_FaceIndex;                          // 0x000228 (0x000004) [Default: 0]
        uint8                           UnknownData_00022C[0x000004];                               // 0x00022C (0x000004)
        FVector                         CallFunc_BreakHitResult_TraceStart;                         // 0x000230 (0x000018)
        FVector                         CallFunc_BreakHitResult_TraceEnd;                           // 0x000248 (0x000018)
        FRotator                        CallFunc_Conv_VectorToRotator_ReturnValue;                  // 0x000260 (0x000018)
        UFXSystemComponent*             CallFunc_SpawnFXAtLocation_ReturnValue;                     // 0x000278 (0x000008) [Default: 0x13B150A0]
        bool                            CallFunc_IsValid_ReturnValue_1;                             // 0x000280 (0x000001) [Default: true]
        uint8                           UnknownData_000281[0x000007];                               // 0x000281 (0x000007)
        UFortAbilitySystemComponent*    CallFunc_GetFortAbilitySystemComponent_ReturnValue;         // 0x000288 (0x000008) [Default: 0x13B15100]
        FGameplayEffectSpecHandle       CallFunc_MakeOutgoingSpec_ReturnValue;                      // 0x000290 (0x000010)
        float                           K2Node_Event_Damage_1;                                      // 0x0002A0 (0x000004) [Default: 4.47618e-27f]
        uint8                           UnknownData_0002A4[0x000004];                               // 0x0002A4 (0x000004)
        FGameplayTagContainer           K2Node_Event_DamageTags_1;                                  // 0x0002A8 (0x000020)
        FVector                         K2Node_Event_Momentum_1;                                    // 0x0002C8 (0x000018)
        FHitResult                      K2Node_Event_HitInfo_1;                                     // 0x0002E0 (0x0000F8)
        AController*                    K2Node_Event_InstigatedBy_1;                                // 0x0003D8 (0x000008) [Default: nullptr]
        AActor*                         K2Node_Event_DamageCauser_1;                                // 0x0003E0 (0x000008) [Default: nullptr]
        FGameplayEffectContextHandle    K2Node_Event_EffectContext_1;                               // 0x0003E8 (0x000018)
        UAbilitySystemComponent*        CallFunc_GetAbilitySystemComponent_ReturnValue_1;           // 0x000400 (0x000008) [Default: nullptr]
        FGameplayEffectSpecHandle       CallFunc_AssignTagSetByCallerMagnitude_ReturnValue;         // 0x000408 (0x000010)
        FActiveGameplayEffectHandle     CallFunc_BP_ApplyGameplayEffectSpecToTarget_ReturnValue;    // 0x000418 (0x000014)
        uint8                           UnknownData_00042C[0x000004];                               // 0x00042C (0x000004)
        FHitResult                      K2Node_CustomEvent_Hit_Result;                              // 0x000430 (0x0000F8)
        bool                            CallFunc_BreakHitResult_bBlockingHit_1;                     // 0x000528 (0x000001) [Default: true]
        bool                            CallFunc_BreakHitResult_bInitialOverlap_1;                  // 0x000529 (0x000001) [Default: false]
        uint8                           UnknownData_00052A[0x000002];                               // 0x00052A (0x000002)
        float                           CallFunc_BreakHitResult_Time_1;                             // 0x00052C (0x000004) [Default: 0f]
        float                           CallFunc_BreakHitResult_Distance_1;                         // 0x000530 (0x000004) [Default: 0f]
        uint8                           UnknownData_000534[0x000004];                               // 0x000534 (0x000004)
        FVector                         CallFunc_BreakHitResult_Location_1;                         // 0x000538 (0x000018)
        FVector                         CallFunc_BreakHitResult_ImpactPoint_1;                      // 0x000550 (0x000018)
        FVector                         CallFunc_BreakHitResult_Normal_1;                           // 0x000568 (0x000018)
        FVector                         CallFunc_BreakHitResult_ImpactNormal_1;                     // 0x000580 (0x000018)
        UPhysicalMaterial*              CallFunc_BreakHitResult_PhysMat_1;                          // 0x000598 (0x000008) [Default: nullptr]
        AActor*                         CallFunc_BreakHitResult_HitActor_1;                         // 0x0005A0 (0x000008) [Default: nullptr]
        UPrimitiveComponent*            CallFunc_BreakHitResult_HitComponent_1;                     // 0x0005A8 (0x000008) [Default: nullptr]
        FName                           CallFunc_BreakHitResult_HitBoneName_1;                      // 0x0005B0 (0x000004) [Default: NAME_None]
        FName                           CallFunc_BreakHitResult_BoneName_1;                         // 0x0005B4 (0x000004) [Default: FName(1065353216) -> L""]
        int32                           CallFunc_BreakHitResult_HitItem_1;                          // 0x0005B8 (0x000004) [Default: 0]
        int32                           CallFunc_BreakHitResult_ElementIndex_1;                     // 0x0005BC (0x000004) [Default: 0]
        int32                           CallFunc_BreakHitResult_FaceIndex_1;                        // 0x0005C0 (0x000004) [Default: 0]
        uint8                           UnknownData_0005C4[0x000004];                               // 0x0005C4 (0x000004)
        FVector                         CallFunc_BreakHitResult_TraceStart_1;                       // 0x0005C8 (0x000018)
        FVector                         CallFunc_BreakHitResult_TraceEnd_1;                         // 0x0005E0 (0x000018)
        FRotator                        CallFunc_Conv_VectorToRotator_ReturnValue_1;                // 0x0005F8 (0x000018)
        bool                            CallFunc_IsDedicatedServer_ReturnValue;                     // 0x000610 (0x000001) [Default: false]
        uint8                           UnknownData_000611[0x000007];                               // 0x000611 (0x000007)
        UFXSystemComponent*             CallFunc_SpawnFXAtLocation_ReturnValue_1;                   // 0x000618 (0x000008) [Default: nullptr]
        bool                            CallFunc_IsValid_ReturnValue_2;                             // 0x000620 (0x000001) [Default: false]
        bool                            CallFunc_IsDedicatedServer_ReturnValue_1;                   // 0x000621 (0x000001) [Default: false]
        bool                            CallFunc_IsValid_ReturnValue_3;                             // 0x000622 (0x000001) [Default: false]
        bool                            CallFunc_IsValid_ReturnValue_4;                             // 0x000623 (0x000001) [Default: false]
        uint8                           UnknownData_000624[0x000004];                               // 0x000624 (0x000004)
        FGameplayEffectSpecHandle       CallFunc_MakeSpecHandleByClass_ReturnValue;                 // 0x000628 (0x000010)
        FGameplayEffectSpecHandle       CallFunc_AssignTagSetByCallerMagnitude_ReturnValue_1;       // 0x000638 (0x000010)
        bool                            CallFunc_IsLocallyViewed_ReturnValue;                       // 0x000648 (0x000001) [Default: false]
        uint8                           UnknownData_000649[0x000003];                               // 0x000649 (0x000003)
        FActiveGameplayEffectHandle     CallFunc_BP_ApplyGameplayEffectSpecToTarget_ReturnValue_1;  // 0x00064C (0x000014)
        double                          CallFunc_DamageWeakpoint_Damage_ImplicitCast;               // 0x000660 (0x000008) [Default: 0]
        double                          CallFunc_NotifyParent_Damage_ImplicitCast;                  // 0x000668 (0x000008) [Default: 0]
    };

    struct ABGA_WeakpointActor_Base_C___GetTargetOwner_Params
    {
        AActor* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x13B143C0]
    };

    struct ABGA_WeakpointActor_Base_C___IsValidAutoFireTarget_Params
    {
        AActor* Attacker;       // 0x000000 (0x000008) [Default: 0x13B143C0]
        bool    ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct ABGA_WeakpointActor_Base_C___NotifyParent_Params
    {
        double          Damage;         // 0x000000 (0x000008) [Default: 1.63232e-315]
        AController*    InstigatedBy;   // 0x000008 (0x000008) [Default: 0x625B1DDD00280031]
        AActor*         DamageCauser;   // 0x000010 (0x000008) [Default: 0x7FEDD9AD97E0]
    };

    struct ABGA_WeakpointActor_Base_C___OnDamagePlayEffects_Params
    {
        float                           Damage;                         // 0x000000 (0x000004) [Default: 4.47479e-27f]
        uint8                           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FGameplayTagContainer           DamageTags;                     // 0x000008 (0x000020) [OutParam]
        FVector                         Momentum;                       // 0x000028 (0x000018)
        FHitResult                      HitInfo;                        // 0x000040 (0x0000F8) [OutParam]
        AFortPawn*                      InstigatedBy;                   // 0x000138 (0x000008) [Default: nullptr]
        AActor*                         DamageCauser;                   // 0x000140 (0x000008) [Default: nullptr]
        FGameplayEffectContextHandle    EffectContext;                  // 0x000148 (0x000018)
    };

    struct ABGA_WeakpointActor_Base_C___OnDamageServer_Params
    {
        float                           Damage;                         // 0x000000 (0x000004) [Default: 4.47479e-27f]
        uint8                           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FGameplayTagContainer           DamageTags;                     // 0x000008 (0x000020) [OutParam]
        FVector                         Momentum;                       // 0x000028 (0x000018)
        FHitResult                      HitInfo;                        // 0x000040 (0x0000F8) [OutParam]
        AController*                    InstigatedBy;                   // 0x000138 (0x000008) [Default: nullptr]
        AActor*                         DamageCauser;                   // 0x000140 (0x000008) [Default: nullptr]
        FGameplayEffectContextHandle    EffectContext;                  // 0x000148 (0x000018)
    };

    struct ABGA_WeakpointActor_Base_C___PlayRicochet_Params
    {
        FHitResult  Hit_Result; // 0x000000 (0x0000F8)
    };

    struct ABGA_WeakpointActor_Base_C___ProcessHitResult_Params
    {
        double      Damage;         // 0x000000 (0x000008) [Default: 1.63232e-315]
        FHitResult  HitResult;      // 0x000008 (0x0000F8)
        double      ModifiedDamage; // 0x000100 (0x000008) [OutParam] [Default: 0]
    };

    struct ABGA_WeakpointActor_Base_C___ResetWeakpointHealth_Params
    {
        float   CallFunc_GetValueAtLevel_ReturnValue;                       // 0x000000 (0x000004) [Default: 4.47479e-27f]
        bool    CallFunc_Greater_DoubleDouble_ReturnValue;                  // 0x000004 (0x000001) [Default: false]
        uint8   UnknownData_000005[0x000003];                               // 0x000005 (0x000003)
        double  K2Node_VariableSet_Weakpoint_CurrentHealth_ImplicitCast;    // 0x000008 (0x000008) [Default: 6.24617e+165]
        double  CallFunc_Greater_DoubleDouble_A_ImplicitCast;               // 0x000010 (0x000008) [Default: 6.9495e-310]
    };

    struct ABGA_WeakpointActor_Base_C___SetWeakpointCollisionKind_Params
    {
        TEnumAsByte<Enum_WeakpointActor_CollisionKind>  WeakpointCollisionKind;         // 0x000000 (0x000001) [Default: 192]
        uint8                                           UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        UBoxComponent*                                  BoxCollision;                   // 0x000008 (0x000008) [Default: 0x625B1DDD00280031]
        UCapsuleComponent*                              CapsuleCollision;               // 0x000010 (0x000008) [Default: 0x7FEDD9AD97E0]
        USphereComponent*                               SphereCollision;                // 0x000018 (0x000008) [Default: 0x7FE99A3CD3C0]
        bool                                            K2Node_SwitchEnum_CmpSuccess;   // 0x000020 (0x000001) [Default: true]
    };

    struct ABGA_WeakpointActor_Base_C___ShouldAlliesAutoFireOnDeployedTarget_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct ABGA_WeakpointActor_Base_C___ShouldAutoFireOnSelfDeployedTarget_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct ABGA_WeakpointActor_Base_C___ShouldDamageWeakpoint_Params
    {
        bool    bShouldDamage;                      // 0x000000 (0x000001) [OutParam] [Default: true]
        bool    CallFunc_BooleanAND_ReturnValue;    // 0x000001 (0x000001) [Default: true]
    };

    struct ABGA_WeakpointActor_Base_C___UpdateWeakpointCollision_Params
    {
        bool                                            bEnableCollision;               // 0x000000 (0x000001) [Default: true]
        TEnumAsByte<Enum_WeakpointActor_CollisionKind>  CollisionKind;                  // 0x000001 (0x000001) [Default: 67]
        uint8                                           UnknownData_000002[0x000006];   // 0x000002 (0x000006)
        UPrimitiveComponent*                            CollisionComponent;             // 0x000008 (0x000008) [Default: 0x625B1DDD00280031]
        UPrimitiveComponent*                            CollisionKindComponent;         // 0x000010 (0x000008) [Default: 0x7FEDD9AD97E0]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable;             // 0x000018 (0x000001) [Default: 192]
        bool                                            CallFunc_IsValid_ReturnValue;   // 0x000019 (0x000001) [Default: true]
        bool                                            CallFunc_IsValid_ReturnValue_1; // 0x00001A (0x000001) [Default: true]
        bool                                            K2Node_SwitchEnum_CmpSuccess;   // 0x00001B (0x000001) [Default: true]
        bool                                            Temp_bool_Variable;             // 0x00001C (0x000001) [Default: true]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_1;           // 0x00001D (0x000001) [Default: 127]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_2;           // 0x00001E (0x000001) [Default: 0]
        bool                                            Temp_bool_Variable_1;           // 0x00001F (0x000001) [Default: false]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_3;           // 0x000020 (0x000001) [Default: 188]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_4;           // 0x000021 (0x000001) [Default: 57]
        bool                                            Temp_bool_Variable_2;           // 0x000022 (0x000001) [Default: true]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_5;           // 0x000023 (0x000001) [Default: 140]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_6;           // 0x000024 (0x000001) [Default: 0]
        bool                                            Temp_bool_Variable_3;           // 0x000025 (0x000001) [Default: false]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_7;           // 0x000026 (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_8;           // 0x000027 (0x000001) [Default: 0]
        bool                                            Temp_bool_Variable_4;           // 0x000028 (0x000001) [Default: true]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_9;           // 0x000029 (0x000001) [Default: 40]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_10;          // 0x00002A (0x000001) [Default: 12]
        bool                                            Temp_bool_Variable_5;           // 0x00002B (0x000001) [Default: true]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_11;          // 0x00002C (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_12;          // 0x00002D (0x000001) [Default: 0]
        bool                                            Temp_bool_Variable_6;           // 0x00002E (0x000001) [Default: false]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_13;          // 0x00002F (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_14;          // 0x000030 (0x000001) [Default: 0]
        bool                                            Temp_bool_Variable_7;           // 0x000031 (0x000001) [Default: false]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_15;          // 0x000032 (0x000001) [Default: 154]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_16;          // 0x000033 (0x000001) [Default: 0]
        bool                                            Temp_bool_Variable_8;           // 0x000034 (0x000001) [Default: false]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_17;          // 0x000035 (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_18;          // 0x000036 (0x000001) [Default: 0]
        bool                                            Temp_bool_Variable_9;           // 0x000037 (0x000001) [Default: false]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_19;          // 0x000038 (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_20;          // 0x000039 (0x000001) [Default: 0]
        bool                                            Temp_bool_Variable_10;          // 0x00003A (0x000001) [Default: false]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_21;          // 0x00003B (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_22;          // 0x00003C (0x000001) [Default: 0]
        bool                                            Temp_bool_Variable_11;          // 0x00003D (0x000001) [Default: false]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_23;          // 0x00003E (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_24;          // 0x00003F (0x000001) [Default: 0]
        bool                                            Temp_bool_Variable_12;          // 0x000040 (0x000001) [Default: false]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_25;          // 0x000041 (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_26;          // 0x000042 (0x000001) [Default: 0]
        bool                                            Temp_bool_Variable_13;          // 0x000043 (0x000001) [Default: false]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_27;          // 0x000044 (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_28;          // 0x000045 (0x000001) [Default: 0]
        bool                                            Temp_bool_Variable_14;          // 0x000046 (0x000001) [Default: false]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_29;          // 0x000047 (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_30;          // 0x000048 (0x000001) [Default: 0]
        bool                                            Temp_bool_Variable_15;          // 0x000049 (0x000001) [Default: false]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_31;          // 0x00004A (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_32;          // 0x00004B (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_33;          // 0x00004C (0x000001) [Default: 0]
        bool                                            Temp_bool_Variable_16;          // 0x00004D (0x000001) [Default: false]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default;          // 0x00004E (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default_1;        // 0x00004F (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_34;          // 0x000050 (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default_2;        // 0x000051 (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_35;          // 0x000052 (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default_3;        // 0x000053 (0x000001) [Default: 0]
        bool                                            Temp_bool_Variable_17;          // 0x000054 (0x000001) [Default: false]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default_4;        // 0x000055 (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default_5;        // 0x000056 (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_36;          // 0x000057 (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 Temp_byte_Variable_37;          // 0x000058 (0x000001) [Default: 96]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default_6;        // 0x000059 (0x000001) [Default: 104]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default_7;        // 0x00005A (0x000001) [Default: 36]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default_8;        // 0x00005B (0x000001) [Default: 169]
        bool                                            Temp_bool_Variable_18;          // 0x00005C (0x000001) [Default: true]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default_9;        // 0x00005D (0x000001) [Default: 1]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default_10;       // 0x00005E (0x000001) [Default: 0]
        TEnumAsByte<ECollisionEnabled>                  Temp_byte_Variable_38;          // 0x00005F (0x000001) [Default: 2]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default_11;       // 0x000060 (0x000001) [Default: 1]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default_12;       // 0x000061 (0x000001) [Default: 1]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default_13;       // 0x000062 (0x000001) [Default: 0]
        TEnumAsByte<ECollisionEnabled>                  Temp_byte_Variable_39;          // 0x000063 (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default_14;       // 0x000064 (0x000001) [Default: 0]
        bool                                            Temp_bool_Variable_19;          // 0x000065 (0x000001) [Default: false]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default_15;       // 0x000066 (0x000001) [Default: 0]
        TEnumAsByte<ECollisionEnabled>                  K2Node_Select_Default_16;       // 0x000067 (0x000001) [Default: 0]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default_17;       // 0x000068 (0x000001) [Default: 0]
        bool                                            Temp_bool_Variable_20;          // 0x000069 (0x000001) [Default: false]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default_18;       // 0x00006A (0x000001) [Default: 128]
        TEnumAsByte<ECollisionResponse>                 K2Node_Select_Default_19;       // 0x00006B (0x000001) [Default: 63]
        uint8                                           UnknownData_00006C[0x000004];   // 0x00006C (0x000004)
        UPrimitiveComponent*                            K2Node_Select_Default_20;       // 0x000070 (0x000008) [Default: nullptr]
    };

} // namespace UE

