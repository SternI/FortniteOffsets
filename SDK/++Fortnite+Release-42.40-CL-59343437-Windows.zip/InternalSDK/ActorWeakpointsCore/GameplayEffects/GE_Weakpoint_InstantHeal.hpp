/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /ActorWeakpointsCore/GameplayEffects/GE_Weakpoint_InstantHeal
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000C40 (0x000000)
    class UGE_Weakpoint_InstantHeal_C : public UGameplayEffect
    {
    public:
    };
}

