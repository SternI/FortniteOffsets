/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:48
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /ActorWeakpointsCore/Components/BP_ActorWeakpoints_UtilityComponent_Functions
 * ============================================================
 */

#include "BP_ActorWeakpoints_UtilityComponent_Functions.hpp"

namespace UE
{

    void UBP_ActorWeakpoints_UtilityComponent_C::DebugPrintArray(TArray<ABGA_WeakpointActor_Base_C*>& TargetArray, int32 CallFunc_Array_Length_ReturnValue, int32 CallFunc_Array_Length_ReturnValue_1, int32 Temp_int_Array_Index_Variable, bool CallFunc_LessEqual_IntInt_ReturnValue, int32 Temp_int_Loop_Counter_Variable, bool CallFunc_Less_IntInt_ReturnValue, int32 CallFunc_Add_IntInt_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_ActorWeakpoints_UtilityComponent.BP_ActorWeakpoints_UtilityComponent_C.DebugPrintArray");
    
        UBP_ActorWeakpoints_UtilityComponent_C___DebugPrintArray_Params Params{};
        Params.TargetArray = TargetArray;
        Params.CallFunc_Array_Length_ReturnValue = CallFunc_Array_Length_ReturnValue;
        Params.CallFunc_Array_Length_ReturnValue_1 = CallFunc_Array_Length_ReturnValue_1;
        Params.Temp_int_Array_Index_Variable = Temp_int_Array_Index_Variable;
        Params.CallFunc_LessEqual_IntInt_ReturnValue = CallFunc_LessEqual_IntInt_ReturnValue;
        Params.Temp_int_Loop_Counter_Variable = Temp_int_Loop_Counter_Variable;
        Params.CallFunc_Less_IntInt_ReturnValue = CallFunc_Less_IntInt_ReturnValue;
        Params.CallFunc_Add_IntInt_ReturnValue = CallFunc_Add_IntInt_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        TargetArray = Params.TargetArray;
    }

    void UBP_ActorWeakpoints_UtilityComponent_C::ExecuteUbergraph_BP_ActorWeakpoints_UtilityComponent(int32 EntryPoint, AActor* CallFunc_GetOwner_ReturnValue, bool CallFunc_IsValid_ReturnValue, bool CallFunc_HasAuthority_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_ActorWeakpoints_UtilityComponent.BP_ActorWeakpoints_UtilityComponent_C.ExecuteUbergraph_BP_ActorWeakpoints_UtilityComponent");
    
        UBP_ActorWeakpoints_UtilityComponent_C___ExecuteUbergraph_BP_ActorWeakpoints_UtilityComponent_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.CallFunc_GetOwner_ReturnValue = CallFunc_GetOwner_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_HasAuthority_ReturnValue = CallFunc_HasAuthority_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_ActorWeakpoints_UtilityComponent_C::InitComponent(TArray<AActor*> CallFunc_GetAllChildActors_ChildActors, int32 Temp_int_Array_Index_Variable, int32 CallFunc_Array_Length_ReturnValue, AActor* CallFunc_Array_Get_Item, TScriptInterface<IGameplayTagAssetInterface> K2Node_DynamicCast_AsGameplay_Tag_Asset_Interface, bool K2Node_DynamicCast_bSuccess, ABGA_WeakpointActor_Base_C* K2Node_DynamicCast_AsBGA_Weakpoint_Actor_Base, bool K2Node_DynamicCast_bSuccess_1, bool CallFunc_HasMatchingGameplayTag_ReturnValue, bool Temp_bool_Variable, int32 CallFunc_Array_AddUnique_ReturnValue, int32 Temp_int_Loop_Counter_Variable, AActor* CallFunc_GetOwner_ReturnValue, bool CallFunc_Less_IntInt_ReturnValue, int32 CallFunc_Add_IntInt_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_ActorWeakpoints_UtilityComponent.BP_ActorWeakpoints_UtilityComponent_C.InitComponent");
    
        UBP_ActorWeakpoints_UtilityComponent_C___InitComponent_Params Params{};
        Params.CallFunc_GetAllChildActors_ChildActors = CallFunc_GetAllChildActors_ChildActors;
        Params.Temp_int_Array_Index_Variable = Temp_int_Array_Index_Variable;
        Params.CallFunc_Array_Length_ReturnValue = CallFunc_Array_Length_ReturnValue;
        Params.CallFunc_Array_Get_Item = CallFunc_Array_Get_Item;
        Params.K2Node_DynamicCast_AsGameplay_Tag_Asset_Interface = K2Node_DynamicCast_AsGameplay_Tag_Asset_Interface;
        Params.K2Node_DynamicCast_bSuccess = K2Node_DynamicCast_bSuccess;
        Params.K2Node_DynamicCast_AsBGA_Weakpoint_Actor_Base = K2Node_DynamicCast_AsBGA_Weakpoint_Actor_Base;
        Params.K2Node_DynamicCast_bSuccess_1 = K2Node_DynamicCast_bSuccess_1;
        Params.CallFunc_HasMatchingGameplayTag_ReturnValue = CallFunc_HasMatchingGameplayTag_ReturnValue;
        Params.Temp_bool_Variable = Temp_bool_Variable;
        Params.CallFunc_Array_AddUnique_ReturnValue = CallFunc_Array_AddUnique_ReturnValue;
        Params.Temp_int_Loop_Counter_Variable = Temp_int_Loop_Counter_Variable;
        Params.CallFunc_GetOwner_ReturnValue = CallFunc_GetOwner_ReturnValue;
        Params.CallFunc_Less_IntInt_ReturnValue = CallFunc_Less_IntInt_ReturnValue;
        Params.CallFunc_Add_IntInt_ReturnValue = CallFunc_Add_IntInt_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_ActorWeakpoints_UtilityComponent_C::IsOwnedWeakpointActor(AActor* Actor, bool bRequireEnabled, bool& bIsWeakpoint, ABGA_WeakpointActor_Base_C* K2Node_DynamicCast_AsBGA_Weakpoint_Actor_Base, bool K2Node_DynamicCast_bSuccess, bool CallFunc_Array_Contains_ReturnValue, bool CallFunc_BooleanAND_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_ActorWeakpoints_UtilityComponent.BP_ActorWeakpoints_UtilityComponent_C.IsOwnedWeakpointActor");
    
        UBP_ActorWeakpoints_UtilityComponent_C___IsOwnedWeakpointActor_Params Params{};
        Params.Actor = Actor;
        Params.bRequireEnabled = bRequireEnabled;
        Params.bIsWeakpoint = bIsWeakpoint;
        Params.K2Node_DynamicCast_AsBGA_Weakpoint_Actor_Base = K2Node_DynamicCast_AsBGA_Weakpoint_Actor_Base;
        Params.K2Node_DynamicCast_bSuccess = K2Node_DynamicCast_bSuccess;
        Params.CallFunc_Array_Contains_ReturnValue = CallFunc_Array_Contains_ReturnValue;
        Params.CallFunc_BooleanAND_ReturnValue = CallFunc_BooleanAND_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        bIsWeakpoint = Params.bIsWeakpoint;
    }

    void UBP_ActorWeakpoints_UtilityComponent_C::ReceiveBeginPlay()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_ActorWeakpoints_UtilityComponent.BP_ActorWeakpoints_UtilityComponent_C.ReceiveBeginPlay");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UBP_ActorWeakpoints_UtilityComponent_C::RemoveWeakpoint(ABGA_WeakpointActor_Base_C* WeakpointActor, bool CallFunc_Array_RemoveItem_ReturnValue, bool CallFunc_Array_Contains_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_ActorWeakpoints_UtilityComponent.BP_ActorWeakpoints_UtilityComponent_C.RemoveWeakpoint");
    
        UBP_ActorWeakpoints_UtilityComponent_C___RemoveWeakpoint_Params Params{};
        Params.WeakpointActor = WeakpointActor;
        Params.CallFunc_Array_RemoveItem_ReturnValue = CallFunc_Array_RemoveItem_ReturnValue;
        Params.CallFunc_Array_Contains_ReturnValue = CallFunc_Array_Contains_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

