/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:48
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /ActorWeakpointsCore/Components/BP_ActorWeakpoints_UtilityComponent
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0000E8 (0x000028)
    class alignas(0x8) UBP_ActorWeakpoints_UtilityComponent_C : public UActorComponent
    {
    public:
        FPointerToUberGraphFrame            UberGraphFrame;                 // 0x0000C0 (0x000008)
        bool                                bDebugComponent;                // 0x0000C8 (0x000001) [Default: false]
        uint8                               UnknownData_0000C9[0x000007];   // 0x0000C9 (0x000007)
        AActor*                             ActorOwner;                     // 0x0000D0 (0x000008) [Default: nullptr]
        TArray<ABGA_WeakpointActor_Base_C*> WeakpointActorArray;            // 0x0000D8 (0x000010)
    
    public: // Functions
        void    DebugPrintArray(TArray<ABGA_WeakpointActor_Base_C*>& TargetArray, int32 CallFunc_Array_Length_ReturnValue, int32 CallFunc_Array_Length_ReturnValue_1, int32 Temp_int_Array_Index_Variable, bool CallFunc_LessEqual_IntInt_ReturnValue, int32 Temp_int_Loop_Counter_Variable, bool CallFunc_Less_IntInt_ReturnValue, int32 CallFunc_Add_IntInt_ReturnValue); // 0x000545D2 [Public | HasOutParms | BlueprintCallable | BlueprintEvent]
        void    ExecuteUbergraph_BP_ActorWeakpoints_UtilityComponent(int32 EntryPoint, AActor* CallFunc_GetOwner_ReturnValue, bool CallFunc_IsValid_ReturnValue, bool CallFunc_HasAuthority_ReturnValue); // 0x000545D2 [Final | UbergraphFunction]
        void    InitComponent(TArray<AActor*> CallFunc_GetAllChildActors_ChildActors, int32 Temp_int_Array_Index_Variable, int32 CallFunc_Array_Length_ReturnValue, AActor* CallFunc_Array_Get_Item, TScriptInterface<IGameplayTagAssetInterface> K2Node_DynamicCast_AsGameplay_Tag_Asset_Interface, bool K2Node_DynamicCast_bSuccess, ABGA_WeakpointActor_Base_C* K2Node_DynamicCast_AsBGA_Weakpoint_Actor_Base, bool K2Node_DynamicCast_bSuccess_1, bool CallFunc_HasMatchingGameplayTag_ReturnValue, bool Temp_bool_Variable, int32 CallFunc_Array_AddUnique_ReturnValue, int32 Temp_int_Loop_Counter_Variable, AActor* CallFunc_GetOwner_ReturnValue, bool CallFunc_Less_IntInt_ReturnValue, int32 CallFunc_Add_IntInt_ReturnValue); // 0x000545D2 [Public | BlueprintCallable | BlueprintEvent]
        void    IsOwnedWeakpointActor(AActor* Actor, bool bRequireEnabled, bool& bIsWeakpoint, ABGA_WeakpointActor_Base_C* K2Node_DynamicCast_AsBGA_Weakpoint_Actor_Base, bool K2Node_DynamicCast_bSuccess, bool CallFunc_Array_Contains_ReturnValue, bool CallFunc_BooleanAND_ReturnValue); // 0x000545D2 [Public | HasOutParms | BlueprintCallable | BlueprintEvent]
        void    ReceiveBeginPlay(); // 0x000545D2 [Event | Public | BlueprintEvent]
        void    RemoveWeakpoint(ABGA_WeakpointActor_Base_C* WeakpointActor, bool CallFunc_Array_RemoveItem_ReturnValue, bool CallFunc_Array_Contains_ReturnValue); // 0x000545D2 [Public | BlueprintCallable | BlueprintEvent]
    };
}

