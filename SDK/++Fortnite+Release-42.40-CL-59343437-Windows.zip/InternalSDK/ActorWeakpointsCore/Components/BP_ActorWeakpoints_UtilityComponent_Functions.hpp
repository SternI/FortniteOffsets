/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:48
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /ActorWeakpointsCore/Components/BP_ActorWeakpoints_UtilityComponent_Functions
 * ============================================================
 */

#include "BP_ActorWeakpoints_UtilityComponent.hpp"

namespace UE
{

    struct UBP_ActorWeakpoints_UtilityComponent_C___DebugPrintArray_Params
    {
        TArray<ABGA_WeakpointActor_Base_C*> TargetArray;                            // 0x000000 (0x000010) [OutParam]
        int32                               CallFunc_Array_Length_ReturnValue;      // 0x000010 (0x000004) [Default: -642932736]
        int32                               CallFunc_Array_Length_ReturnValue_1;    // 0x000014 (0x000004) [Default: 32749]
        int32                               Temp_int_Array_Index_Variable;          // 0x000018 (0x000004) [Default: -1707350624]
        bool                                CallFunc_LessEqual_IntInt_ReturnValue;  // 0x00001C (0x000001) [Default: true]
        uint8                               UnknownData_00001D[0x000003];           // 0x00001D (0x000003)
        int32                               Temp_int_Loop_Counter_Variable;         // 0x000020 (0x000004) [Default: -119588420]
        bool                                CallFunc_Less_IntInt_ReturnValue;       // 0x000024 (0x000001) [Default: false]
        uint8                               UnknownData_000025[0x000003];           // 0x000025 (0x000003)
        int32                               CallFunc_Add_IntInt_ReturnValue;        // 0x000028 (0x000004) [Default: 319903408]
    };

    struct UBP_ActorWeakpoints_UtilityComponent_C___ExecuteUbergraph_BP_ActorWeakpoints_UtilityComponent_Params
    {
        int32   EntryPoint;                         // 0x000000 (0x000004) [Default: 319902208]
        uint8   UnknownData_000004[0x000004];       // 0x000004 (0x000004)
        AActor* CallFunc_GetOwner_ReturnValue;      // 0x000008 (0x000008) [Default: 0x695B1DDD00280031]
        bool    CallFunc_IsValid_ReturnValue;       // 0x000010 (0x000001) [Default: false]
        bool    CallFunc_HasAuthority_ReturnValue;  // 0x000011 (0x000001) [Default: true]
    };

    struct UBP_ActorWeakpoints_UtilityComponent_C___InitComponent_Params
    {
        TArray<AActor*>                                 CallFunc_GetAllChildActors_ChildActors;             // 0x000000 (0x000010)
        int32                                           Temp_int_Array_Index_Variable;                      // 0x000010 (0x000004) [Default: -642932736]
        int32                                           CallFunc_Array_Length_ReturnValue;                  // 0x000014 (0x000004) [Default: 32749]
        AActor*                                         CallFunc_Array_Get_Item;                            // 0x000018 (0x000008) [Default: 0x7FE99A3BE5A0]
        TScriptInterface<IGameplayTagAssetInterface>    K2Node_DynamicCast_AsGameplay_Tag_Asset_Interface;  // 0x000020 (0x000010)
        bool                                            K2Node_DynamicCast_bSuccess;                        // 0x000030 (0x000001) [Default: true]
        uint8                                           UnknownData_000031[0x000007];                       // 0x000031 (0x000007)
        ABGA_WeakpointActor_Base_C*                     K2Node_DynamicCast_AsBGA_Weakpoint_Actor_Base;      // 0x000038 (0x000008) [Default: 0x130B78F0]
        bool                                            K2Node_DynamicCast_bSuccess_1;                      // 0x000040 (0x000001) [Default: true]
        bool                                            CallFunc_HasMatchingGameplayTag_ReturnValue;        // 0x000041 (0x000001) [Default: false]
        bool                                            Temp_bool_Variable;                                 // 0x000042 (0x000001) [Default: true]
        uint8                                           UnknownByte_000043;                                 // 0x000043 (0x000001)
        int32                                           CallFunc_Array_AddUnique_ReturnValue;               // 0x000044 (0x000004) [Default: 0]
        int32                                           Temp_int_Loop_Counter_Variable;                     // 0x000048 (0x000004) [Default: 0]
        uint8                                           UnknownData_00004C[0x000004];                       // 0x00004C (0x000004)
        AActor*                                         CallFunc_GetOwner_ReturnValue;                      // 0x000050 (0x000008) [Default: nullptr]
        bool                                            CallFunc_Less_IntInt_ReturnValue;                   // 0x000058 (0x000001) [Default: false]
        uint8                                           UnknownData_000059[0x000003];                       // 0x000059 (0x000003)
        int32                                           CallFunc_Add_IntInt_ReturnValue;                    // 0x00005C (0x000004) [Default: 0]
    };

    struct UBP_ActorWeakpoints_UtilityComponent_C___IsOwnedWeakpointActor_Params
    {
        AActor*                     Actor;                                          // 0x000000 (0x000008) [Default: 0x13115200]
        bool                        bRequireEnabled;                                // 0x000008 (0x000001) [Default: true]
        bool                        bIsWeakpoint;                                   // 0x000009 (0x000001) [OutParam] [Default: false]
        uint8                       UnknownData_00000A[0x000006];                   // 0x00000A (0x000006)
        ABGA_WeakpointActor_Base_C* K2Node_DynamicCast_AsBGA_Weakpoint_Actor_Base;  // 0x000010 (0x000008) [Default: 0x7FEDD9ADA000]
        bool                        K2Node_DynamicCast_bSuccess;                    // 0x000018 (0x000001) [Default: true]
        bool                        CallFunc_Array_Contains_ReturnValue;            // 0x000019 (0x000001) [Default: true]
        bool                        CallFunc_BooleanAND_ReturnValue;                // 0x00001A (0x000001) [Default: true]
    };

    struct UBP_ActorWeakpoints_UtilityComponent_C___RemoveWeakpoint_Params
    {
        ABGA_WeakpointActor_Base_C* WeakpointActor;                         // 0x000000 (0x000008) [Default: 0x13115200]
        bool                        CallFunc_Array_RemoveItem_ReturnValue;  // 0x000008 (0x000001) [Default: true]
        bool                        CallFunc_Array_Contains_ReturnValue;    // 0x000009 (0x000001) [Default: false]
    };

} // namespace UE

