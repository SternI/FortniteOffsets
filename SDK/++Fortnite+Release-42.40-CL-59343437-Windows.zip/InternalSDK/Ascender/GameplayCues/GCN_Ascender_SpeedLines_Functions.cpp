/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/GameplayCues/GCN_Ascender_SpeedLines_Functions
 * ============================================================
 */

#include "GCN_Ascender_SpeedLines_Functions.hpp"

namespace UE
{

    void UGCN_Ascender_SpeedLines_C::OnBurst(AActor* MyTarget, FGameplayCueParameters& Parameters, TArray<UParticleSystemComponent*>& ParticleComponents, TArray<UAudioComponent*>& AudioComponents, UCameraShakeBase* BurstCameraShakeInstance, ADecalActor* BurstDecalInstance, UParticleSystemComponent* CallFunc_Array_Get_Item, int32 CallFunc_Array_Length_ReturnValue, FHitResult CallFunc_K2_AddWorldOffset_SweepHitResult, bool CallFunc_Greater_IntInt_ReturnValue, FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult, FVector CallFunc_GetForwardVector_ReturnValue, FVector CallFunc_K2_GetComponentLocation_ReturnValue, FVector CallFunc_Multiply_VectorFloat_ReturnValue, FVector CallFunc_Add_VectorVector_ReturnValue, TArray<AActor*> Temp_object_Variable, FVector CallFunc_Subtract_VectorVector_ReturnValue, FVector CallFunc_Add_VectorVector_ReturnValue_1, TArray<TEnumAsByte<EObjectTypeQuery>> K2Node_MakeArray_Array, FHitResult CallFunc_LineTraceSingleForObjects_OutHit, bool CallFunc_LineTraceSingleForObjects_ReturnValue, bool CallFunc_BreakHitResult_bBlockingHit, bool CallFunc_BreakHitResult_bInitialOverlap, float CallFunc_BreakHitResult_Time, float CallFunc_BreakHitResult_Distance, FVector CallFunc_BreakHitResult_Location, FVector CallFunc_BreakHitResult_ImpactPoint, FVector CallFunc_BreakHitResult_Normal, FVector CallFunc_BreakHitResult_ImpactNormal, UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat, AActor* CallFunc_BreakHitResult_HitActor, UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent, FName CallFunc_BreakHitResult_HitBoneName, FName CallFunc_BreakHitResult_BoneName, int32 CallFunc_BreakHitResult_HitItem, int32 CallFunc_BreakHitResult_ElementIndex, int32 CallFunc_BreakHitResult_FaceIndex, FVector CallFunc_BreakHitResult_TraceStart, FVector CallFunc_BreakHitResult_TraceEnd, FVector CallFunc_Multiply_VectorFloat_ReturnValue_1, FRotator CallFunc_Conv_VectorToRotator_ReturnValue, FRotator CallFunc_Conv_VectorToRotator_ReturnValue_1, FHitResult CallFunc_K2_SetWorldLocationAndRotation_SweepHitResult, UDecalComponent* CallFunc_SpawnDecalAtLocation_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GCN_Ascender_SpeedLines.GCN_Ascender_SpeedLines_C.OnBurst");
    
        UGCN_Ascender_SpeedLines_C___OnBurst_Params Params{};
        Params.MyTarget = MyTarget;
        Params.Parameters = Parameters;
        Params.ParticleComponents = ParticleComponents;
        Params.AudioComponents = AudioComponents;
        Params.BurstCameraShakeInstance = BurstCameraShakeInstance;
        Params.BurstDecalInstance = BurstDecalInstance;
        Params.CallFunc_Array_Get_Item = CallFunc_Array_Get_Item;
        Params.CallFunc_Array_Length_ReturnValue = CallFunc_Array_Length_ReturnValue;
        Params.CallFunc_K2_AddWorldOffset_SweepHitResult = CallFunc_K2_AddWorldOffset_SweepHitResult;
        Params.CallFunc_Greater_IntInt_ReturnValue = CallFunc_Greater_IntInt_ReturnValue;
        Params.CallFunc_K2_SetWorldRotation_SweepHitResult = CallFunc_K2_SetWorldRotation_SweepHitResult;
        Params.CallFunc_GetForwardVector_ReturnValue = CallFunc_GetForwardVector_ReturnValue;
        Params.CallFunc_K2_GetComponentLocation_ReturnValue = CallFunc_K2_GetComponentLocation_ReturnValue;
        Params.CallFunc_Multiply_VectorFloat_ReturnValue = CallFunc_Multiply_VectorFloat_ReturnValue;
        Params.CallFunc_Add_VectorVector_ReturnValue = CallFunc_Add_VectorVector_ReturnValue;
        Params.Temp_object_Variable = Temp_object_Variable;
        Params.CallFunc_Subtract_VectorVector_ReturnValue = CallFunc_Subtract_VectorVector_ReturnValue;
        Params.CallFunc_Add_VectorVector_ReturnValue_1 = CallFunc_Add_VectorVector_ReturnValue_1;
        Params.K2Node_MakeArray_Array = K2Node_MakeArray_Array;
        Params.CallFunc_LineTraceSingleForObjects_OutHit = CallFunc_LineTraceSingleForObjects_OutHit;
        Params.CallFunc_LineTraceSingleForObjects_ReturnValue = CallFunc_LineTraceSingleForObjects_ReturnValue;
        Params.CallFunc_BreakHitResult_bBlockingHit = CallFunc_BreakHitResult_bBlockingHit;
        Params.CallFunc_BreakHitResult_bInitialOverlap = CallFunc_BreakHitResult_bInitialOverlap;
        Params.CallFunc_BreakHitResult_Time = CallFunc_BreakHitResult_Time;
        Params.CallFunc_BreakHitResult_Distance = CallFunc_BreakHitResult_Distance;
        Params.CallFunc_BreakHitResult_Location = CallFunc_BreakHitResult_Location;
        Params.CallFunc_BreakHitResult_ImpactPoint = CallFunc_BreakHitResult_ImpactPoint;
        Params.CallFunc_BreakHitResult_Normal = CallFunc_BreakHitResult_Normal;
        Params.CallFunc_BreakHitResult_ImpactNormal = CallFunc_BreakHitResult_ImpactNormal;
        Params.CallFunc_BreakHitResult_PhysMat = CallFunc_BreakHitResult_PhysMat;
        Params.CallFunc_BreakHitResult_HitActor = CallFunc_BreakHitResult_HitActor;
        Params.CallFunc_BreakHitResult_HitComponent = CallFunc_BreakHitResult_HitComponent;
        Params.CallFunc_BreakHitResult_HitBoneName = CallFunc_BreakHitResult_HitBoneName;
        Params.CallFunc_BreakHitResult_BoneName = CallFunc_BreakHitResult_BoneName;
        Params.CallFunc_BreakHitResult_HitItem = CallFunc_BreakHitResult_HitItem;
        Params.CallFunc_BreakHitResult_ElementIndex = CallFunc_BreakHitResult_ElementIndex;
        Params.CallFunc_BreakHitResult_FaceIndex = CallFunc_BreakHitResult_FaceIndex;
        Params.CallFunc_BreakHitResult_TraceStart = CallFunc_BreakHitResult_TraceStart;
        Params.CallFunc_BreakHitResult_TraceEnd = CallFunc_BreakHitResult_TraceEnd;
        Params.CallFunc_Multiply_VectorFloat_ReturnValue_1 = CallFunc_Multiply_VectorFloat_ReturnValue_1;
        Params.CallFunc_Conv_VectorToRotator_ReturnValue = CallFunc_Conv_VectorToRotator_ReturnValue;
        Params.CallFunc_Conv_VectorToRotator_ReturnValue_1 = CallFunc_Conv_VectorToRotator_ReturnValue_1;
        Params.CallFunc_K2_SetWorldLocationAndRotation_SweepHitResult = CallFunc_K2_SetWorldLocationAndRotation_SweepHitResult;
        Params.CallFunc_SpawnDecalAtLocation_ReturnValue = CallFunc_SpawnDecalAtLocation_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Parameters = Params.Parameters;
        ParticleComponents = Params.ParticleComponents;
        AudioComponents = Params.AudioComponents;
    }

} // namespace UE

