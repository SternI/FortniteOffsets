/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:26
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/GameplayCues/GC_Ascender_LinkToDestroyed
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000218 (0x000000)
    class UGC_Ascender_LinkToDestroyed_C : public UFortGameplayCueNotify_Burst
    {
    public:
    
    public: // Functions
        void    OnBurstGeneric(AActor* MyTarget, FGameplayCueParameters& Parameters, TArray<UFXSystemComponent*>& ParticleComponents, TArray<UAudioComponent*>& AudioComponents, UCameraShakeBase* BurstCameraShakeInstance, ADecalActor* BurstDecalInstance, UFXSystemComponent* CallFunc_Array_Get_Item, AB_Athena_Zipline_Ascender_C* K2Node_DynamicCast_AsB_Athena_Zipline_Ascender, bool K2Node_DynamicCast_bSuccess, FVector CallFunc_K2_GetActorLocation_ReturnValue, FRotator CallFunc_K2_GetComponentRotation_ReturnValue, FVector CallFunc_GetUpVector_ReturnValue, FRotator CallFunc_RotatorFromAxisAndAngle_ReturnValue, FRotator CallFunc_ComposeRotators_ReturnValue, FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult); // 0x000545D2 [Event | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintEvent | Const]
    };
}

