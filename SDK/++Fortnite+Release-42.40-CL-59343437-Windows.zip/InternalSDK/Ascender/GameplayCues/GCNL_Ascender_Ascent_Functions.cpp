/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/GameplayCues/GCNL_Ascender_Ascent_Functions
 * ============================================================
 */

#include "GCNL_Ascender_Ascent_Functions.hpp"

namespace UE
{

    void AGCNL_Ascender_Ascent_C::cameraShakeTimer()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GCNL_Ascender_Ascent.GCNL_Ascender_Ascent_C.cameraShakeTimer");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AGCNL_Ascender_Ascent_C::ExecuteUbergraph_GCNL_Ascender_Ascent(int32 EntryPoint, AActor* K2Node_Event_MyTarget_1, FGameplayCueParameters K2Node_Event_Parameters_1, TArray<UFXSystemComponent*> K2Node_Event_ParticleComponents_1, TArray<UAudioComponent*> K2Node_Event_AudioComponents_1, UCameraShakeBase* K2Node_Event_BurstCameraShakeInstance, ADecalActor* K2Node_Event_BurstDecalInstance, AActor* K2Node_Event_MyTarget, FGameplayCueParameters K2Node_Event_Parameters, TArray<UFXSystemComponent*> K2Node_Event_ParticleComponents, TArray<UAudioComponent*> K2Node_Event_AudioComponents, AFortPlayerPawn* K2Node_DynamicCast_AsFort_Player_Pawn, bool K2Node_DynamicCast_bSuccess, bool CallFunc_IsValid_ReturnValue, AController* CallFunc_GetController_ReturnValue, FVector CallFunc_GetVelocity_ReturnValue, bool CallFunc_IsLocalPlayerController_ReturnValue, double CallFunc_VSize_ReturnValue, double CallFunc_Subtract_DoubleDouble_ReturnValue, APlayerController* K2Node_DynamicCast_AsPlayer_Controller, bool K2Node_DynamicCast_bSuccess_1, double CallFunc_FMax_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, UCameraShakeBase* CallFunc_StartCameraShake_ReturnValue, ULegacyCameraShake* CallFunc_Conv_LegacyCameraShake_ReturnValue, AActor* K2Node_Event_MyTarget_2, FGameplayCueParameters K2Node_Event_Parameters_2, TArray<UFXSystemComponent*> K2Node_Event_ParticleComponents_2, TArray<UAudioComponent*> K2Node_Event_AudioComponents_2, UCameraShakeBase* K2Node_Event_BurstCameraShakeInstance_1, ADecalActor* K2Node_Event_BurstDecalInstance_1, TimerDynamicDelegate K2Node_CreateDelegate_OutputDelegate, FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue, float CallFunc_StartCameraShake_Scale_ImplicitCast)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GCNL_Ascender_Ascent.GCNL_Ascender_Ascent_C.ExecuteUbergraph_GCNL_Ascender_Ascent");
    
        AGCNL_Ascender_Ascent_C___ExecuteUbergraph_GCNL_Ascender_Ascent_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.K2Node_Event_MyTarget_1 = K2Node_Event_MyTarget_1;
        Params.K2Node_Event_Parameters_1 = K2Node_Event_Parameters_1;
        Params.K2Node_Event_ParticleComponents_1 = K2Node_Event_ParticleComponents_1;
        Params.K2Node_Event_AudioComponents_1 = K2Node_Event_AudioComponents_1;
        Params.K2Node_Event_BurstCameraShakeInstance = K2Node_Event_BurstCameraShakeInstance;
        Params.K2Node_Event_BurstDecalInstance = K2Node_Event_BurstDecalInstance;
        Params.K2Node_Event_MyTarget = K2Node_Event_MyTarget;
        Params.K2Node_Event_Parameters = K2Node_Event_Parameters;
        Params.K2Node_Event_ParticleComponents = K2Node_Event_ParticleComponents;
        Params.K2Node_Event_AudioComponents = K2Node_Event_AudioComponents;
        Params.K2Node_DynamicCast_AsFort_Player_Pawn = K2Node_DynamicCast_AsFort_Player_Pawn;
        Params.K2Node_DynamicCast_bSuccess = K2Node_DynamicCast_bSuccess;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_GetController_ReturnValue = CallFunc_GetController_ReturnValue;
        Params.CallFunc_GetVelocity_ReturnValue = CallFunc_GetVelocity_ReturnValue;
        Params.CallFunc_IsLocalPlayerController_ReturnValue = CallFunc_IsLocalPlayerController_ReturnValue;
        Params.CallFunc_VSize_ReturnValue = CallFunc_VSize_ReturnValue;
        Params.CallFunc_Subtract_DoubleDouble_ReturnValue = CallFunc_Subtract_DoubleDouble_ReturnValue;
        Params.K2Node_DynamicCast_AsPlayer_Controller = K2Node_DynamicCast_AsPlayer_Controller;
        Params.K2Node_DynamicCast_bSuccess_1 = K2Node_DynamicCast_bSuccess_1;
        Params.CallFunc_FMax_ReturnValue = CallFunc_FMax_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
        Params.CallFunc_StartCameraShake_ReturnValue = CallFunc_StartCameraShake_ReturnValue;
        Params.CallFunc_Conv_LegacyCameraShake_ReturnValue = CallFunc_Conv_LegacyCameraShake_ReturnValue;
        Params.K2Node_Event_MyTarget_2 = K2Node_Event_MyTarget_2;
        Params.K2Node_Event_Parameters_2 = K2Node_Event_Parameters_2;
        Params.K2Node_Event_ParticleComponents_2 = K2Node_Event_ParticleComponents_2;
        Params.K2Node_Event_AudioComponents_2 = K2Node_Event_AudioComponents_2;
        Params.K2Node_Event_BurstCameraShakeInstance_1 = K2Node_Event_BurstCameraShakeInstance_1;
        Params.K2Node_Event_BurstDecalInstance_1 = K2Node_Event_BurstDecalInstance_1;
        Params.K2Node_CreateDelegate_OutputDelegate = K2Node_CreateDelegate_OutputDelegate;
        Params.CallFunc_K2_SetTimerDelegate_ReturnValue = CallFunc_K2_SetTimerDelegate_ReturnValue;
        Params.CallFunc_StartCameraShake_Scale_ImplicitCast = CallFunc_StartCameraShake_Scale_ImplicitCast;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AGCNL_Ascender_Ascent_C::OnApplicationGeneric(AActor* MyTarget, FGameplayCueParameters& Parameters, TArray<UFXSystemComponent*>& ParticleComponents, TArray<UAudioComponent*>& AudioComponents, UCameraShakeBase* BurstCameraShakeInstance, ADecalActor* BurstDecalInstance)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GCNL_Ascender_Ascent.GCNL_Ascender_Ascent_C.OnApplicationGeneric");
    
        AGCNL_Ascender_Ascent_C___OnApplicationGeneric_Params Params{};
        Params.MyTarget = MyTarget;
        Params.Parameters = Parameters;
        Params.ParticleComponents = ParticleComponents;
        Params.AudioComponents = AudioComponents;
        Params.BurstCameraShakeInstance = BurstCameraShakeInstance;
        Params.BurstDecalInstance = BurstDecalInstance;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Parameters = Params.Parameters;
        ParticleComponents = Params.ParticleComponents;
        AudioComponents = Params.AudioComponents;
    }

    void AGCNL_Ascender_Ascent_C::OnLoopingStartGeneric(AActor* MyTarget, FGameplayCueParameters& Parameters, TArray<UFXSystemComponent*>& ParticleComponents, TArray<UAudioComponent*>& AudioComponents)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GCNL_Ascender_Ascent.GCNL_Ascender_Ascent_C.OnLoopingStartGeneric");
    
        AGCNL_Ascender_Ascent_C___OnLoopingStartGeneric_Params Params{};
        Params.MyTarget = MyTarget;
        Params.Parameters = Parameters;
        Params.ParticleComponents = ParticleComponents;
        Params.AudioComponents = AudioComponents;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Parameters = Params.Parameters;
        ParticleComponents = Params.ParticleComponents;
        AudioComponents = Params.AudioComponents;
    }

    void AGCNL_Ascender_Ascent_C::OnRemovalGeneric(AActor* MyTarget, FGameplayCueParameters& Parameters, TArray<UFXSystemComponent*>& ParticleComponents, TArray<UAudioComponent*>& AudioComponents, UCameraShakeBase* BurstCameraShakeInstance, ADecalActor* BurstDecalInstance)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GCNL_Ascender_Ascent.GCNL_Ascender_Ascent_C.OnRemovalGeneric");
    
        AGCNL_Ascender_Ascent_C___OnRemovalGeneric_Params Params{};
        Params.MyTarget = MyTarget;
        Params.Parameters = Parameters;
        Params.ParticleComponents = ParticleComponents;
        Params.AudioComponents = AudioComponents;
        Params.BurstCameraShakeInstance = BurstCameraShakeInstance;
        Params.BurstDecalInstance = BurstDecalInstance;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Parameters = Params.Parameters;
        ParticleComponents = Params.ParticleComponents;
        AudioComponents = Params.AudioComponents;
    }

} // namespace UE

