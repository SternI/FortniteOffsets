/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:26
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/GameplayCues/GC_Ascender_LinkToDestroyed_Functions
 * ============================================================
 */

#include "GC_Ascender_LinkToDestroyed_Functions.hpp"

namespace UE
{

    void UGC_Ascender_LinkToDestroyed_C::OnBurstGeneric(AActor* MyTarget, FGameplayCueParameters& Parameters, TArray<UFXSystemComponent*>& ParticleComponents, TArray<UAudioComponent*>& AudioComponents, UCameraShakeBase* BurstCameraShakeInstance, ADecalActor* BurstDecalInstance, UFXSystemComponent* CallFunc_Array_Get_Item, AB_Athena_Zipline_Ascender_C* K2Node_DynamicCast_AsB_Athena_Zipline_Ascender, bool K2Node_DynamicCast_bSuccess, FVector CallFunc_K2_GetActorLocation_ReturnValue, FRotator CallFunc_K2_GetComponentRotation_ReturnValue, FVector CallFunc_GetUpVector_ReturnValue, FRotator CallFunc_RotatorFromAxisAndAngle_ReturnValue, FRotator CallFunc_ComposeRotators_ReturnValue, FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GC_Ascender_LinkToDestroyed.GC_Ascender_LinkToDestroyed_C.OnBurstGeneric");
    
        UGC_Ascender_LinkToDestroyed_C___OnBurstGeneric_Params Params{};
        Params.MyTarget = MyTarget;
        Params.Parameters = Parameters;
        Params.ParticleComponents = ParticleComponents;
        Params.AudioComponents = AudioComponents;
        Params.BurstCameraShakeInstance = BurstCameraShakeInstance;
        Params.BurstDecalInstance = BurstDecalInstance;
        Params.CallFunc_Array_Get_Item = CallFunc_Array_Get_Item;
        Params.K2Node_DynamicCast_AsB_Athena_Zipline_Ascender = K2Node_DynamicCast_AsB_Athena_Zipline_Ascender;
        Params.K2Node_DynamicCast_bSuccess = K2Node_DynamicCast_bSuccess;
        Params.CallFunc_K2_GetActorLocation_ReturnValue = CallFunc_K2_GetActorLocation_ReturnValue;
        Params.CallFunc_K2_GetComponentRotation_ReturnValue = CallFunc_K2_GetComponentRotation_ReturnValue;
        Params.CallFunc_GetUpVector_ReturnValue = CallFunc_GetUpVector_ReturnValue;
        Params.CallFunc_RotatorFromAxisAndAngle_ReturnValue = CallFunc_RotatorFromAxisAndAngle_ReturnValue;
        Params.CallFunc_ComposeRotators_ReturnValue = CallFunc_ComposeRotators_ReturnValue;
        Params.CallFunc_K2_SetWorldRotation_SweepHitResult = CallFunc_K2_SetWorldRotation_SweepHitResult;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Parameters = Params.Parameters;
        ParticleComponents = Params.ParticleComponents;
        AudioComponents = Params.AudioComponents;
    }

} // namespace UE

