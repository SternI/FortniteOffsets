/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/GameplayCues/GCNL_Ascender_Ascent
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000CA8 (0x000060)
    class alignas(0x8) AGCNL_Ascender_Ascent_C : public AFortGameplayCueNotify_Loop
    {
    public:
        FPointerToUberGraphFrame    UberGraphFrame;     // 0x000C48 (0x000008)
        AFortPlayerPawn*            PlayerPawn;         // 0x000C50 (0x000008) [Default: nullptr]
        double                      MinCamShakeAmp;     // 0x000C58 (0x000008) [Default: 0.05]
        double                      MaxCamShakeAmp;     // 0x000C60 (0x000008) [Default: 0.75]
        double                      MinCamShakeFreq;    // 0x000C68 (0x000008) [Default: 8]
        double                      MaxCamShakeFreq;    // 0x000C70 (0x000008) [Default: 50]
        ULegacyCameraShake*         matineeCamShake;    // 0x000C78 (0x000008) [Default: nullptr]
        FScalableFloat              MaxAscenderSpeed;   // 0x000C80 (0x000028)
    
    public: // Functions
        void    cameraShakeTimer(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    ExecuteUbergraph_GCNL_Ascender_Ascent(int32 EntryPoint, AActor* K2Node_Event_MyTarget_1, FGameplayCueParameters K2Node_Event_Parameters_1, TArray<UFXSystemComponent*> K2Node_Event_ParticleComponents_1, TArray<UAudioComponent*> K2Node_Event_AudioComponents_1, UCameraShakeBase* K2Node_Event_BurstCameraShakeInstance, ADecalActor* K2Node_Event_BurstDecalInstance, AActor* K2Node_Event_MyTarget, FGameplayCueParameters K2Node_Event_Parameters, TArray<UFXSystemComponent*> K2Node_Event_ParticleComponents, TArray<UAudioComponent*> K2Node_Event_AudioComponents, AFortPlayerPawn* K2Node_DynamicCast_AsFort_Player_Pawn, bool K2Node_DynamicCast_bSuccess, bool CallFunc_IsValid_ReturnValue, AController* CallFunc_GetController_ReturnValue, FVector CallFunc_GetVelocity_ReturnValue, bool CallFunc_IsLocalPlayerController_ReturnValue, double CallFunc_VSize_ReturnValue, double CallFunc_Subtract_DoubleDouble_ReturnValue, APlayerController* K2Node_DynamicCast_AsPlayer_Controller, bool K2Node_DynamicCast_bSuccess_1, double CallFunc_FMax_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, UCameraShakeBase* CallFunc_StartCameraShake_ReturnValue, ULegacyCameraShake* CallFunc_Conv_LegacyCameraShake_ReturnValue, AActor* K2Node_Event_MyTarget_2, FGameplayCueParameters K2Node_Event_Parameters_2, TArray<UFXSystemComponent*> K2Node_Event_ParticleComponents_2, TArray<UAudioComponent*> K2Node_Event_AudioComponents_2, UCameraShakeBase* K2Node_Event_BurstCameraShakeInstance_1, ADecalActor* K2Node_Event_BurstDecalInstance_1, TimerDynamicDelegate K2Node_CreateDelegate_OutputDelegate, FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue, float CallFunc_StartCameraShake_Scale_ImplicitCast); // 0x000545D2 [Final | UbergraphFunction | HasDefaults]
        void    OnApplicationGeneric(AActor* MyTarget, FGameplayCueParameters& Parameters, TArray<UFXSystemComponent*>& ParticleComponents, TArray<UAudioComponent*>& AudioComponents, UCameraShakeBase* BurstCameraShakeInstance, ADecalActor* BurstDecalInstance); // 0x000545D2 [Event | Public | HasOutParms | BlueprintEvent]
        void    OnLoopingStartGeneric(AActor* MyTarget, FGameplayCueParameters& Parameters, TArray<UFXSystemComponent*>& ParticleComponents, TArray<UAudioComponent*>& AudioComponents); // 0x000545D2 [Event | Public | HasOutParms | BlueprintEvent]
        void    OnRemovalGeneric(AActor* MyTarget, FGameplayCueParameters& Parameters, TArray<UFXSystemComponent*>& ParticleComponents, TArray<UAudioComponent*>& AudioComponents, UCameraShakeBase* BurstCameraShakeInstance, ADecalActor* BurstDecalInstance); // 0x000545D2 [Event | Public | HasOutParms | BlueprintEvent]
    };
}

