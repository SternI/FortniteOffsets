/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/GameplayCues/GCNL_Ascender_Ascent_Functions
 * ============================================================
 */

#include "GCNL_Ascender_Ascent.hpp"

namespace UE
{

    struct AGCNL_Ascender_Ascent_C___ExecuteUbergraph_GCNL_Ascender_Ascent_Params
    {
        int32                       EntryPoint;                                     // 0x000000 (0x000004) [Default: 329812032]
        uint8                       UnknownData_000004[0x000004];                   // 0x000004 (0x000004)
        AActor*                     K2Node_Event_MyTarget_1;                        // 0x000008 (0x000008) [Default: 0xAA1B1DDD00280031]
        FGameplayCueParameters      K2Node_Event_Parameters_1;                      // 0x000010 (0x0000D0)
        TArray<UFXSystemComponent*> K2Node_Event_ParticleComponents_1;              // 0x0000E0 (0x000010)
        TArray<UAudioComponent*>    K2Node_Event_AudioComponents_1;                 // 0x0000F0 (0x000010)
        UCameraShakeBase*           K2Node_Event_BurstCameraShakeInstance;          // 0x000100 (0x000008) [Default: nullptr]
        ADecalActor*                K2Node_Event_BurstDecalInstance;                // 0x000108 (0x000008) [Default: nullptr]
        AActor*                     K2Node_Event_MyTarget;                          // 0x000110 (0x000008) [Default: nullptr]
        FGameplayCueParameters      K2Node_Event_Parameters;                        // 0x000118 (0x0000D0)
        TArray<UFXSystemComponent*> K2Node_Event_ParticleComponents;                // 0x0001E8 (0x000010)
        TArray<UAudioComponent*>    K2Node_Event_AudioComponents;                   // 0x0001F8 (0x000010)
        AFortPlayerPawn*            K2Node_DynamicCast_AsFort_Player_Pawn;          // 0x000208 (0x000008) [Default: nullptr]
        bool                        K2Node_DynamicCast_bSuccess;                    // 0x000210 (0x000001) [Default: false]
        bool                        CallFunc_IsValid_ReturnValue;                   // 0x000211 (0x000001) [Default: false]
        uint8                       UnknownData_000212[0x000006];                   // 0x000212 (0x000006)
        AController*                CallFunc_GetController_ReturnValue;             // 0x000218 (0x000008) [Default: nullptr]
        FVector                     CallFunc_GetVelocity_ReturnValue;               // 0x000220 (0x000018)
        bool                        CallFunc_IsLocalPlayerController_ReturnValue;   // 0x000238 (0x000001) [Default: false]
        uint8                       UnknownData_000239[0x000007];                   // 0x000239 (0x000007)
        double                      CallFunc_VSize_ReturnValue;                     // 0x000240 (0x000008) [Default: 6.94844e-310]
        double                      CallFunc_Subtract_DoubleDouble_ReturnValue;     // 0x000248 (0x000008) [Default: 4.24399e-314]
        APlayerController*          K2Node_DynamicCast_AsPlayer_Controller;         // 0x000250 (0x000008) [Default: nullptr]
        bool                        K2Node_DynamicCast_bSuccess_1;                  // 0x000258 (0x000001) [Default: false]
        uint8                       UnknownData_000259[0x000007];                   // 0x000259 (0x000007)
        double                      CallFunc_FMax_ReturnValue;                      // 0x000260 (0x000008) [Default: 0]
        bool                        CallFunc_IsValid_ReturnValue_1;                 // 0x000268 (0x000001) [Default: false]
        uint8                       UnknownData_000269[0x000007];                   // 0x000269 (0x000007)
        UCameraShakeBase*           CallFunc_StartCameraShake_ReturnValue;          // 0x000270 (0x000008) [Default: 0x1]
        ULegacyCameraShake*         CallFunc_Conv_LegacyCameraShake_ReturnValue;    // 0x000278 (0x000008) [Default: 0x1780E8BB00000000]
        AActor*                     K2Node_Event_MyTarget_2;                        // 0x000280 (0x000008) [Default: 0x1001780E8BB]
        FGameplayCueParameters      K2Node_Event_Parameters_2;                      // 0x000288 (0x0000D0)
        TArray<UFXSystemComponent*> K2Node_Event_ParticleComponents_2;              // 0x000358 (0x000010)
        TArray<UAudioComponent*>    K2Node_Event_AudioComponents_2;                 // 0x000368 (0x000010)
        UCameraShakeBase*           K2Node_Event_BurstCameraShakeInstance_1;        // 0x000378 (0x000008) [Default: nullptr]
        ADecalActor*                K2Node_Event_BurstDecalInstance_1;              // 0x000380 (0x000008) [Default: nullptr]
        TimerDynamicDelegate        K2Node_CreateDelegate_OutputDelegate;           // 0x000388 (0x00000C)
        uint8                       UnknownData_000394[0x000004];                   // 0x000394 (0x000004)
        FTimerHandle                CallFunc_K2_SetTimerDelegate_ReturnValue;       // 0x000398 (0x000008)
        float                       CallFunc_StartCameraShake_Scale_ImplicitCast;   // 0x0003A0 (0x000004) [Default: 0f]
    };

    struct AGCNL_Ascender_Ascent_C___OnApplicationGeneric_Params
    {
        AActor*                     MyTarget;                   // 0x000000 (0x000008) [Default: 0x13A88840]
        FGameplayCueParameters      Parameters;                 // 0x000008 (0x0000D0) [OutParam]
        TArray<UFXSystemComponent*> ParticleComponents;         // 0x0000D8 (0x000010) [OutParam]
        TArray<UAudioComponent*>    AudioComponents;            // 0x0000E8 (0x000010) [OutParam]
        UCameraShakeBase*           BurstCameraShakeInstance;   // 0x0000F8 (0x000008) [Default: nullptr]
        ADecalActor*                BurstDecalInstance;         // 0x000100 (0x000008) [Default: nullptr]
    };

    struct AGCNL_Ascender_Ascent_C___OnLoopingStartGeneric_Params
    {
        AActor*                     MyTarget;           // 0x000000 (0x000008) [Default: 0x13A88840]
        FGameplayCueParameters      Parameters;         // 0x000008 (0x0000D0) [OutParam]
        TArray<UFXSystemComponent*> ParticleComponents; // 0x0000D8 (0x000010) [OutParam]
        TArray<UAudioComponent*>    AudioComponents;    // 0x0000E8 (0x000010) [OutParam]
    };

    struct AGCNL_Ascender_Ascent_C___OnRemovalGeneric_Params
    {
        AActor*                     MyTarget;                   // 0x000000 (0x000008) [Default: 0x13A88840]
        FGameplayCueParameters      Parameters;                 // 0x000008 (0x0000D0) [OutParam]
        TArray<UFXSystemComponent*> ParticleComponents;         // 0x0000D8 (0x000010) [OutParam]
        TArray<UAudioComponent*>    AudioComponents;            // 0x0000E8 (0x000010) [OutParam]
        UCameraShakeBase*           BurstCameraShakeInstance;   // 0x0000F8 (0x000008) [Default: nullptr]
        ADecalActor*                BurstDecalInstance;         // 0x000100 (0x000008) [Default: nullptr]
    };

} // namespace UE

