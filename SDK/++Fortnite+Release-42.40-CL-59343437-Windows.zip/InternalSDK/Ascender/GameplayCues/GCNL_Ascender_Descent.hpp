/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/GameplayCues/GCNL_Ascender_Descent
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000CA0 (0x000010)
    class alignas(0x8) AGCNL_Ascender_Descent_C : public AFortGameplayCueNotifyLoop_SoundIndicator
    {
    public:
        FPointerToUberGraphFrame    UberGraphFrame; // 0x000C90 (0x000008)
        UAudioComponent*            AudioComponent; // 0x000C98 (0x000008) [Default: nullptr]
    
    public: // Functions
        void    ExecuteUbergraph_GCNL_Ascender_Descent(int32 EntryPoint, AActor* K2Node_Event_MyTarget, FGameplayCueParameters K2Node_Event_Parameters, TArray<UFXSystemComponent*> K2Node_Event_ParticleComponents, TArray<UAudioComponent*> K2Node_Event_AudioComponents, UAudioComponent* CallFunc_Array_Get_Item); // 0x000545D2 [Final | UbergraphFunction | HasDefaults]
        void    OnLoopingStartGeneric(AActor* MyTarget, FGameplayCueParameters& Parameters, TArray<UFXSystemComponent*>& ParticleComponents, TArray<UAudioComponent*>& AudioComponents); // 0x000545D2 [Event | Public | HasOutParms | BlueprintEvent]
    };
}

