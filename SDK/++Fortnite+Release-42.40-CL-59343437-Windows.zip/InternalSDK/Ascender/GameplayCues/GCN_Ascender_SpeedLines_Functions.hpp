/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/GameplayCues/GCN_Ascender_SpeedLines_Functions
 * ============================================================
 */

#include "GCN_Ascender_SpeedLines.hpp"

namespace UE
{

    struct UGCN_Ascender_SpeedLines_C___OnBurst_Params
    {
        AActor*                                 MyTarget;                                               // 0x000000 (0x000008) [Default: 0x13A87E10]
        FGameplayCueParameters                  Parameters;                                             // 0x000008 (0x0000D0) [OutParam]
        TArray<UParticleSystemComponent*>       ParticleComponents;                                     // 0x0000D8 (0x000010) [OutParam]
        TArray<UAudioComponent*>                AudioComponents;                                        // 0x0000E8 (0x000010) [OutParam]
        UCameraShakeBase*                       BurstCameraShakeInstance;                               // 0x0000F8 (0x000008) [Default: nullptr]
        ADecalActor*                            BurstDecalInstance;                                     // 0x000100 (0x000008) [Default: nullptr]
        UParticleSystemComponent*               CallFunc_Array_Get_Item;                                // 0x000108 (0x000008) [Default: nullptr]
        int32                                   CallFunc_Array_Length_ReturnValue;                      // 0x000110 (0x000004) [Default: 1]
        uint8                                   UnknownData_000114[0x000004];                           // 0x000114 (0x000004)
        FHitResult                              CallFunc_K2_AddWorldOffset_SweepHitResult;              // 0x000118 (0x0000F8)
        bool                                    CallFunc_Greater_IntInt_ReturnValue;                    // 0x000210 (0x000001) [Default: false]
        uint8                                   UnknownData_000211[0x000007];                           // 0x000211 (0x000007)
        FHitResult                              CallFunc_K2_SetWorldRotation_SweepHitResult;            // 0x000218 (0x0000F8)
        FVector                                 CallFunc_GetForwardVector_ReturnValue;                  // 0x000310 (0x000018)
        FVector                                 CallFunc_K2_GetComponentLocation_ReturnValue;           // 0x000328 (0x000018)
        FVector                                 CallFunc_Multiply_VectorFloat_ReturnValue;              // 0x000340 (0x000018)
        FVector                                 CallFunc_Add_VectorVector_ReturnValue;                  // 0x000358 (0x000018)
        TArray<AActor*>                         Temp_object_Variable;                                   // 0x000370 (0x000010)
        FVector                                 CallFunc_Subtract_VectorVector_ReturnValue;             // 0x000380 (0x000018)
        FVector                                 CallFunc_Add_VectorVector_ReturnValue_1;                // 0x000398 (0x000018)
        TArray<TEnumAsByte<EObjectTypeQuery>>   K2Node_MakeArray_Array;                                 // 0x0003B0 (0x000010)
        FHitResult                              CallFunc_LineTraceSingleForObjects_OutHit;              // 0x0003C0 (0x0000F8)
        bool                                    CallFunc_LineTraceSingleForObjects_ReturnValue;         // 0x0004B8 (0x000001) [Default: true]
        bool                                    CallFunc_BreakHitResult_bBlockingHit;                   // 0x0004B9 (0x000001) [Default: true]
        bool                                    CallFunc_BreakHitResult_bInitialOverlap;                // 0x0004BA (0x000001) [Default: true]
        uint8                                   UnknownByte_0004BB;                                     // 0x0004BB (0x000001)
        float                                   CallFunc_BreakHitResult_Time;                           // 0x0004BC (0x000004) [Default: 4.58883e-41f]
        float                                   CallFunc_BreakHitResult_Distance;                       // 0x0004C0 (0x000004) [Default: -2.83616e-24f]
        uint8                                   UnknownData_0004C4[0x000004];                           // 0x0004C4 (0x000004)
        FVector                                 CallFunc_BreakHitResult_Location;                       // 0x0004C8 (0x000018)
        FVector                                 CallFunc_BreakHitResult_ImpactPoint;                    // 0x0004E0 (0x000018)
        FVector                                 CallFunc_BreakHitResult_Normal;                         // 0x0004F8 (0x000018)
        FVector                                 CallFunc_BreakHitResult_ImpactNormal;                   // 0x000510 (0x000018)
        UPhysicalMaterial*                      CallFunc_BreakHitResult_PhysMat;                        // 0x000528 (0x000008) [Default: 0x7FEB985D2700]
        AActor*                                 CallFunc_BreakHitResult_HitActor;                       // 0x000530 (0x000008) [Default: 0x7FEB985D30E0]
        UPrimitiveComponent*                    CallFunc_BreakHitResult_HitComponent;                   // 0x000538 (0x000008) [Default: 0x7FEB985D4380]
        FName                                   CallFunc_BreakHitResult_HitBoneName;                    // 0x000540 (0x000004) [Default: FName(-1738713792) -> L""]
        FName                                   CallFunc_BreakHitResult_BoneName;                       // 0x000544 (0x000004) [Default: FName(32747) -> L""]
        int32                                   CallFunc_BreakHitResult_HitItem;                        // 0x000548 (0x000004) [Default: -1738714912]
        int32                                   CallFunc_BreakHitResult_ElementIndex;                   // 0x00054C (0x000004) [Default: 32747]
        int32                                   CallFunc_BreakHitResult_FaceIndex;                      // 0x000550 (0x000004) [Default: -1738714688]
        uint8                                   UnknownData_000554[0x000004];                           // 0x000554 (0x000004)
        FVector                                 CallFunc_BreakHitResult_TraceStart;                     // 0x000558 (0x000018)
        FVector                                 CallFunc_BreakHitResult_TraceEnd;                       // 0x000570 (0x000018)
        FVector                                 CallFunc_Multiply_VectorFloat_ReturnValue_1;            // 0x000588 (0x000018)
        FRotator                                CallFunc_Conv_VectorToRotator_ReturnValue;              // 0x0005A0 (0x000018)
        FRotator                                CallFunc_Conv_VectorToRotator_ReturnValue_1;            // 0x0005B8 (0x000018)
        FHitResult                              CallFunc_K2_SetWorldLocationAndRotation_SweepHitResult; // 0x0005D0 (0x0000F8)
        UDecalComponent*                        CallFunc_SpawnDecalAtLocation_ReturnValue;              // 0x0006C8 (0x000008) [Default: 0xAB1B1DDD002C0021]
    };

} // namespace UE

