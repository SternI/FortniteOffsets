/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:26
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/GameplayCues/GC_Ascender_LinkToDestroyed_Functions
 * ============================================================
 */

#include "GC_Ascender_LinkToDestroyed.hpp"

namespace UE
{

    struct UGC_Ascender_LinkToDestroyed_C___OnBurstGeneric_Params
    {
        AActor*                         MyTarget;                                       // 0x000000 (0x000008) [Default: 0x13A87E10]
        FGameplayCueParameters          Parameters;                                     // 0x000008 (0x0000D0) [OutParam]
        TArray<UFXSystemComponent*>     ParticleComponents;                             // 0x0000D8 (0x000010) [OutParam]
        TArray<UAudioComponent*>        AudioComponents;                                // 0x0000E8 (0x000010) [OutParam]
        UCameraShakeBase*               BurstCameraShakeInstance;                       // 0x0000F8 (0x000008) [Default: nullptr]
        ADecalActor*                    BurstDecalInstance;                             // 0x000100 (0x000008) [Default: nullptr]
        UFXSystemComponent*             CallFunc_Array_Get_Item;                        // 0x000108 (0x000008) [Default: nullptr]
        AB_Athena_Zipline_Ascender_C*   K2Node_DynamicCast_AsB_Athena_Zipline_Ascender; // 0x000110 (0x000008) [Default: 0x1]
        bool                            K2Node_DynamicCast_bSuccess;                    // 0x000118 (0x000001) [Default: false]
        uint8                           UnknownData_000119[0x000007];                   // 0x000119 (0x000007)
        FVector                         CallFunc_K2_GetActorLocation_ReturnValue;       // 0x000120 (0x000018)
        FRotator                        CallFunc_K2_GetComponentRotation_ReturnValue;   // 0x000138 (0x000018)
        FVector                         CallFunc_GetUpVector_ReturnValue;               // 0x000150 (0x000018)
        FRotator                        CallFunc_RotatorFromAxisAndAngle_ReturnValue;   // 0x000168 (0x000018)
        FRotator                        CallFunc_ComposeRotators_ReturnValue;           // 0x000180 (0x000018)
        FHitResult                      CallFunc_K2_SetWorldRotation_SweepHitResult;    // 0x000198 (0x0000F8)
    };

} // namespace UE

