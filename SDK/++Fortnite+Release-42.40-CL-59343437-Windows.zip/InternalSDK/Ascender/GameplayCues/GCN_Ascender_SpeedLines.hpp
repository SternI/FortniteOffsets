/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/GameplayCues/GCN_Ascender_SpeedLines
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000220 (0x000008)
    class alignas(0x8) UGCN_Ascender_SpeedLines_C : public UFortGameplayCueNotify_Burst
    {
    public:
        UMaterialInterface* Decal_Material; // 0x000218 (0x000008) [Default: 0x7FEE18C87700]
    
    public: // Functions
        void    OnBurst(AActor* MyTarget, FGameplayCueParameters& Parameters, TArray<UParticleSystemComponent*>& ParticleComponents, TArray<UAudioComponent*>& AudioComponents, UCameraShakeBase* BurstCameraShakeInstance, ADecalActor* BurstDecalInstance, UParticleSystemComponent* CallFunc_Array_Get_Item, int32 CallFunc_Array_Length_ReturnValue, FHitResult CallFunc_K2_AddWorldOffset_SweepHitResult, bool CallFunc_Greater_IntInt_ReturnValue, FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult, FVector CallFunc_GetForwardVector_ReturnValue, FVector CallFunc_K2_GetComponentLocation_ReturnValue, FVector CallFunc_Multiply_VectorFloat_ReturnValue, FVector CallFunc_Add_VectorVector_ReturnValue, TArray<AActor*> Temp_object_Variable, FVector CallFunc_Subtract_VectorVector_ReturnValue, FVector CallFunc_Add_VectorVector_ReturnValue_1, TArray<TEnumAsByte<EObjectTypeQuery>> K2Node_MakeArray_Array, FHitResult CallFunc_LineTraceSingleForObjects_OutHit, bool CallFunc_LineTraceSingleForObjects_ReturnValue, bool CallFunc_BreakHitResult_bBlockingHit, bool CallFunc_BreakHitResult_bInitialOverlap, float CallFunc_BreakHitResult_Time, float CallFunc_BreakHitResult_Distance, FVector CallFunc_BreakHitResult_Location, FVector CallFunc_BreakHitResult_ImpactPoint, FVector CallFunc_BreakHitResult_Normal, FVector CallFunc_BreakHitResult_ImpactNormal, UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat, AActor* CallFunc_BreakHitResult_HitActor, UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent, FName CallFunc_BreakHitResult_HitBoneName, FName CallFunc_BreakHitResult_BoneName, int32 CallFunc_BreakHitResult_HitItem, int32 CallFunc_BreakHitResult_ElementIndex, int32 CallFunc_BreakHitResult_FaceIndex, FVector CallFunc_BreakHitResult_TraceStart, FVector CallFunc_BreakHitResult_TraceEnd, FVector CallFunc_Multiply_VectorFloat_ReturnValue_1, FRotator CallFunc_Conv_VectorToRotator_ReturnValue, FRotator CallFunc_Conv_VectorToRotator_ReturnValue_1, FHitResult CallFunc_K2_SetWorldLocationAndRotation_SweepHitResult, UDecalComponent* CallFunc_SpawnDecalAtLocation_ReturnValue); // 0x000545D2 [Event | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintEvent | Const]
    };
}

