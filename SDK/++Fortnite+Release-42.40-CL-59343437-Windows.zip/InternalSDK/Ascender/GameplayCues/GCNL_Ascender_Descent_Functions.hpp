/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/GameplayCues/GCNL_Ascender_Descent_Functions
 * ============================================================
 */

#include "GCNL_Ascender_Descent.hpp"

namespace UE
{

    struct AGCNL_Ascender_Descent_C___ExecuteUbergraph_GCNL_Ascender_Descent_Params
    {
        int32                       EntryPoint;                         // 0x000000 (0x000004) [Default: 329839024]
        uint8                       UnknownData_000004[0x000004];       // 0x000004 (0x000004)
        AActor*                     K2Node_Event_MyTarget;              // 0x000008 (0x000008) [Default: 0x411B1DDD00280031]
        FGameplayCueParameters      K2Node_Event_Parameters;            // 0x000010 (0x0000D0)
        TArray<UFXSystemComponent*> K2Node_Event_ParticleComponents;    // 0x0000E0 (0x000010)
        TArray<UAudioComponent*>    K2Node_Event_AudioComponents;       // 0x0000F0 (0x000010)
        UAudioComponent*            CallFunc_Array_Get_Item;            // 0x000100 (0x000008) [Default: nullptr]
    };

    struct AGCNL_Ascender_Descent_C___OnLoopingStartGeneric_Params
    {
        AActor*                     MyTarget;           // 0x000000 (0x000008) [Default: 0x13A8F1B0]
        FGameplayCueParameters      Parameters;         // 0x000008 (0x0000D0) [OutParam]
        TArray<UFXSystemComponent*> ParticleComponents; // 0x0000D8 (0x000010) [OutParam]
        TArray<UAudioComponent*>    AudioComponents;    // 0x0000E8 (0x000010) [OutParam]
    };

} // namespace UE

