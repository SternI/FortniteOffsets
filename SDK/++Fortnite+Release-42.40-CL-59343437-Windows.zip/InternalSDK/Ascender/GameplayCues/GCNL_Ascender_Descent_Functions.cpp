/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/GameplayCues/GCNL_Ascender_Descent_Functions
 * ============================================================
 */

#include "GCNL_Ascender_Descent_Functions.hpp"

namespace UE
{

    void AGCNL_Ascender_Descent_C::ExecuteUbergraph_GCNL_Ascender_Descent(int32 EntryPoint, AActor* K2Node_Event_MyTarget, FGameplayCueParameters K2Node_Event_Parameters, TArray<UFXSystemComponent*> K2Node_Event_ParticleComponents, TArray<UAudioComponent*> K2Node_Event_AudioComponents, UAudioComponent* CallFunc_Array_Get_Item)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GCNL_Ascender_Descent.GCNL_Ascender_Descent_C.ExecuteUbergraph_GCNL_Ascender_Descent");
    
        AGCNL_Ascender_Descent_C___ExecuteUbergraph_GCNL_Ascender_Descent_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.K2Node_Event_MyTarget = K2Node_Event_MyTarget;
        Params.K2Node_Event_Parameters = K2Node_Event_Parameters;
        Params.K2Node_Event_ParticleComponents = K2Node_Event_ParticleComponents;
        Params.K2Node_Event_AudioComponents = K2Node_Event_AudioComponents;
        Params.CallFunc_Array_Get_Item = CallFunc_Array_Get_Item;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AGCNL_Ascender_Descent_C::OnLoopingStartGeneric(AActor* MyTarget, FGameplayCueParameters& Parameters, TArray<UFXSystemComponent*>& ParticleComponents, TArray<UAudioComponent*>& AudioComponents)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GCNL_Ascender_Descent.GCNL_Ascender_Descent_C.OnLoopingStartGeneric");
    
        AGCNL_Ascender_Descent_C___OnLoopingStartGeneric_Params Params{};
        Params.MyTarget = MyTarget;
        Params.Parameters = Parameters;
        Params.ParticleComponents = ParticleComponents;
        Params.AudioComponents = AudioComponents;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Parameters = Params.Parameters;
        ParticleComponents = Params.ParticleComponents;
        AudioComponents = Params.AudioComponents;
    }

} // namespace UE

