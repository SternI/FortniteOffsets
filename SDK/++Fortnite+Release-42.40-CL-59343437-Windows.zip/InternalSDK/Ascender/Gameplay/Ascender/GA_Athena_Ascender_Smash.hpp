/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:43
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/Gameplay/Ascender/GA_Athena_Ascender_Smash
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000CBD (0x00007D)
    class alignas(0x8) UGA_Athena_Ascender_Smash_C : public UGA_Athena_ZipLine_SmashParent_C
    {
    public:
        FPointerToUberGraphFrame        UberGraphFrame;                 // 0x000C40 (0x000008)
        UPrimitiveComponent*            ZiplineInteractComponent_0;     // 0x000C48 (0x000008) [Default: nullptr]
        AB_Athena_Zipline_Ascender_C*   AscenderZipline;                // 0x000C50 (0x000008) [Default: nullptr]
        FGameplayTag                    DescendingTag;                  // 0x000C58 (0x000004)
        uint8                           UnknownData_000C5C[0x000004];   // 0x000C5C (0x000004)
        UAnimMontage*                   M_AscendingAnim;                // 0x000C60 (0x000008) [Default: 0x7FED587D2200]
        UAnimMontage*                   M_DescendingAnim;               // 0x000C68 (0x000008) [Default: 0x7FED587E8000]
        FActiveGameplayEffectHandle     DescendingGE_Handle;            // 0x000C70 (0x000014)
        FActiveGameplayEffectHandle     AscendingGE_Handle;             // 0x000C84 (0x000014)
        UAnimMontage*                   F_AscendingAnim;                // 0x000C98 (0x000008) [Default: 0x7FED587EB600]
        UAnimMontage*                   F_DescendingAnim;               // 0x000CA0 (0x000008) [Default: 0x7FED587D2800]
        FActiveGameplayEffectHandle     ZiplinePassiveGE;               // 0x000CA8 (0x000014)
        bool                            bHolsterApplied;                // 0x000CBC (0x000001) [Default: false]
    
    public: // Functions
        void    DoFailSafeUnholster(bool CallFunc_GetConsoleVariableBoolValue_ReturnValue, bool CallFunc_GetConsoleVariableBoolValue_ReturnValue_1, bool CallFunc_BooleanAND_ReturnValue); // 0x000545D2 [Public | BlueprintCallable | BlueprintEvent]
        void    DoHolster(bool CallFunc_GetConsoleVariableBoolValue_ReturnValue); // 0x000545D2 [Public | BlueprintCallable | BlueprintEvent]
        void    DoUnholster(bool CallFunc_GetConsoleVariableBoolValue_ReturnValue); // 0x000545D2 [Public | BlueprintCallable | BlueprintEvent]
        void    ExecuteUbergraph_GA_Athena_Ascender_Smash(int32 EntryPoint, UAnimMontage* CallFunc_GetAscenderMontage_Montage, UAbilityTask_PlayMontageAndWait* CallFunc_CreatePlayMontageAndWaitProxy_ReturnValue, MontageWaitSimpleDelegate K2Node_CreateDelegate_OutputDelegate, bool CallFunc_IsValid_ReturnValue, MontageWaitSimpleDelegate K2Node_CreateDelegate_OutputDelegate_1, MontageWaitSimpleDelegate K2Node_CreateDelegate_OutputDelegate_2, bool CallFunc_IsPlayerUsingHandle_ReturnValue, bool CallFunc_IsPlayerUsingHandle_ReturnValue_1, MontageWaitSimpleDelegate K2Node_CreateDelegate_OutputDelegate_3, FGameplayEventData K2Node_Event_EventData_2, FGameplayEventData K2Node_Event_EventData_1, AB_Athena_Zipline_Ascender_C* K2Node_DynamicCast_AsB_Athena_Zipline_Ascender, bool K2Node_DynamicCast_bSuccess, UAbilitySystemComponent* CallFunc_GetAbilitySystemComponent_ReturnValue, FActiveGameplayEffectHandle CallFunc_BP_ApplyGameplayEffectToTarget_ReturnValue, UAbilitySystemComponent* CallFunc_GetAbilitySystemComponent_ReturnValue_1, FActiveGameplayEffectHandle CallFunc_BP_ApplyGameplayEffectToTarget_ReturnValue_1, FGameplayEventData K2Node_Event_EventData, MontageWaitSimpleDelegate K2Node_CreateDelegate_OutputDelegate_4, bool GameplayTagsK2Node_SwitchGameplayTag_CmpSuccess, bool CallFunc_IsValid_ReturnValue_1); // 0x000545D2 [Final | UbergraphFunction | HasDefaults]
        void    FallingTagRemoved(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    GameplayTagEvent_ZiplineEnter(FGameplayEventData& EventData); // 0x000545D2 [HasOutParms | BlueprintCallable | BlueprintEvent]
        void    GameplayTagEvent_ZiplineExit(FGameplayEventData& EventData); // 0x000545D2 [HasOutParms | BlueprintCallable | BlueprintEvent]
        void    GetAscenderMontage(UAnimMontage*& Montage, bool Temp_bool_Variable, bool Temp_bool_Variable_1, TEnumAsByte<EFortCustomGender> Temp_byte_Variable, bool CallFunc_IsPlayerUsingHandle_ReturnValue, UFortPawnComponent_AscenderMontageProvider* CallFunc_GetComponentByClass_ReturnValue, TEnumAsByte<EFortCustomGender> CallFunc_GetCharacterGender_ReturnValue, UAnimMontage* CallFunc_GetSuitableMontage_ReturnValue, bool CallFunc_IsValid_ReturnValue, bool CallFunc_IsPlayerUsingHandle_ReturnValue_1, UAnimMontage* K2Node_Select_Default, bool CallFunc_IsPlayerUsingHandle_ReturnValue_2, UAnimMontage* K2Node_Select_Default_1, UAnimMontage* K2Node_Select_Default_2); // 0x000545D2 [Public | HasOutParms | BlueprintCallable | BlueprintEvent | BlueprintPure]
        void    HandleGameplayEventTag(FGameplayEventData& EventData); // 0x000545D2 [HasOutParms | BlueprintCallable | BlueprintEvent]
        bool    IsPlayerUsingHandle(bool CallFunc_IsValid_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, AFortPlayerPawn* CallFunc_GetPawnUsingHandle_ReturnValue, bool CallFunc_EqualEqual_ObjectObject_ReturnValue); // 0x000545D2 [Public | HasOutParms | BlueprintCallable | BlueprintEvent | BlueprintPure]
        void    OnBlendedIn_899182BF4C098785CCBCFD85AA84455F(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnBlendOut_899182BF4C098785CCBCFD85AA84455F(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnCancelled_899182BF4C098785CCBCFD85AA84455F(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnCompleted_899182BF4C098785CCBCFD85AA84455F(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    OnInterrupted_899182BF4C098785CCBCFD85AA84455F(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    Pre_BeginZiplinging(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    SurroundingsCheck_MotorCheck(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    SurroundingsCheck_SmashObjects(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    ZiplinePostBegin_Event(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
        void    ZipliningComplete(); // 0x000545D2 [BlueprintCallable | BlueprintEvent]
    };
}

