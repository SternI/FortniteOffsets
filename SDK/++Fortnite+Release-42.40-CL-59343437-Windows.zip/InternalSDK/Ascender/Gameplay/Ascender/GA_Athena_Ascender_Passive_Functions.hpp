/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:43
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/Gameplay/Ascender/GA_Athena_Ascender_Passive_Functions
 * ============================================================
 */

#include "GA_Athena_Ascender_Passive.hpp"

namespace UE
{

    struct UGA_Athena_Ascender_Passive_C___ExecuteUbergraph_GA_Athena_Ascender_Passive_Params
    {
        int32                       EntryPoint;                     // 0x000000 (0x000004) [Default: 329745536]
        uint8                       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FGameplayAbilityActorInfo   K2Node_Event_ActorInfo;         // 0x000008 (0x000048)
    };

    struct UGA_Athena_Ascender_Passive_C___FailedToActivatePassiveAbility_Params
    {
        FGameplayAbilityActorInfo   ActorInfo;  // 0x000000 (0x000048)
    };

} // namespace UE

