/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:37
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/Gameplay/Ascender/B_Athena_Zipline_Ascender_Functions
 * ============================================================
 */

#include "B_Athena_Zipline_Ascender.hpp"

namespace UE
{

    struct AB_Athena_Zipline_Ascender_C___UserConstructionScript_Params
    {
        bool    CallFunc_IsDedicatedServer_ReturnValue; // 0x000000 (0x000001) [Default: true]
        bool    CallFunc_IsValid_ReturnValue;           // 0x000001 (0x000001) [Default: true]
        bool    CallFunc_IsValid_ReturnValue_1;         // 0x000002 (0x000001) [Default: true]
    };

    struct AB_Athena_Zipline_Ascender_C___ShouldUseDynamicDestructionNiagaraSystem_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct AB_Athena_Zipline_Ascender_C___ShouldUseDynamicDestructionMaterial_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct AB_Athena_Zipline_Ascender_C___ShouldShowSoundIndicator_Params
    {
        AFortPlayerController*              PlayerController;                           // 0x000000 (0x000008) [Default: 0x148D19F0]
        bool                                ReturnValue;                                // 0x000008 (0x000001) [ReturnValue] [Default: true]
        bool                                CallFunc_IsValid_ReturnValue;               // 0x000009 (0x000001) [Default: false]
        TEnumAsByte<EFortTeamAffiliation>   CallFunc_GetTeamAffiliation_ReturnValue;    // 0x00000A (0x000001) [Default: 40]
        bool                                CallFunc_EqualEqual_ByteByte_ReturnValue;   // 0x00000B (0x000001) [Default: false]
    };

    struct AB_Athena_Zipline_Ascender_C___SetCableTilingBySplineLength_Params
    {
        float   CallFunc_GetSplineLength_ReturnValue;                                       // 0x000000 (0x000004) [Default: 1.42476e-26f]
        uint8   UnknownData_000004[0x000004];                                               // 0x000004 (0x000004)
        double  CallFunc_Divide_DoubleDouble_ReturnValue;                                   // 0x000008 (0x000008) [Default: -2.96483e+155]
        int32   CallFunc_FTrunc_ReturnValue;                                                // 0x000010 (0x000004) [Default: -647938048]
        uint8   UnknownData_000014[0x000004];                                               // 0x000014 (0x000004)
        double  CallFunc_Conv_IntToDouble_ReturnValue;                                      // 0x000018 (0x000008) [Default: 6.9486e-310]
        double  CallFunc_Divide_DoubleDouble_A_ImplicitCast;                                // 0x000020 (0x000008) [Default: 1.2081e-314]
        float   CallFunc_SetScalarParameterValueOnMaterials_ParameterValue_ImplicitCast;    // 0x000028 (0x000004) [Default: 1.76903e-27f]
    };

    struct AB_Athena_Zipline_Ascender_C___PlayerDescendingStarted_Params
    {
        AFortPlayerPawn*    Sliding_Player; // 0x000000 (0x000008) [Default: 0x148D19F0]
    };

    struct AB_Athena_Zipline_Ascender_C___PawnIsInHandleRange_Params
    {
        AFortPawn*      Pawn;                                               // 0x000000 (0x000008) [Default: 0x148D19F0]
        bool            ReturnValue;                                        // 0x000008 (0x000001) [ReturnValue] [Default: true]
        uint8           UnknownData_000009[0x000007];                       // 0x000009 (0x000007)
        TArray<AActor*> CallFunc_GetOverlappingActors_OverlappingActors;    // 0x000010 (0x000010)
        bool            CallFunc_Array_Contains_ReturnValue;                // 0x000020 (0x000001) [Default: true]
    };

    struct AB_Athena_Zipline_Ascender_C___OnZipliningStopped_Params
    {
        AFortPlayerPawn*        InteractingPawn;        // 0x000000 (0x000008) [Default: 0x148D19F0]
        UPrimitiveComponent*    InteractComponent;      // 0x000008 (0x000008) [Default: 0xE0361CDD00280031]
        float                   ZiplineUsageDuration;   // 0x000010 (0x000004) [Default: -3.96264e+15f]
    };

    struct AB_Athena_Zipline_Ascender_C___OnZipliningStarted_Params
    {
        AFortPlayerPawn*        InteractingPawn;    // 0x000000 (0x000008) [Default: 0x148D19F0]
        UPrimitiveComponent*    InteractComponent;  // 0x000008 (0x000008) [Default: 0xE0361CDD00280031]
    };

    struct AB_Athena_Zipline_Ascender_C___OnReady_93837FC44A18F6AE57D3478CC43A98AB_Params
    {
        AFortGameStateAthena*   GameState;              // 0x000000 (0x000008) [Default: 0x148D19F0]
        UFortPlaylist*          Playlist;               // 0x000008 (0x000008) [Default: 0xE0361CDD00280031]
        FGameplayTagContainer   PlaylistContextTags;    // 0x000010 (0x000020) [OutParam]
    };

    struct AB_Athena_Zipline_Ascender_C___LocalOnFailedInteract_Params
    {
        AFortPlayerPawn*    InteractingPawn;    // 0x000000 (0x000008) [Default: 0x148D19F0]
    };

    struct AB_Athena_Zipline_Ascender_C___HotfixEnabled_Params
    {
        bool    CallFunc_GetValueAsBool_ReturnValue;    // 0x000000 (0x000001) [Default: true]
    };

    struct AB_Athena_Zipline_Ascender_C___HandleLinkedActorDestroyed_Params
    {
        AActor* DamageCauser;   // 0x000000 (0x000008) [Default: 0x148D19F0]
    };

    struct AB_Athena_Zipline_Ascender_C___GetTopComponent_Params
    {
        UPrimitiveComponent*    ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x148D19F0]
    };

    struct AB_Athena_Zipline_Ascender_C___GetLastSplinePointIndex_Params
    {
        int32   ReturnValue;                                    // 0x000000 (0x000004) [ReturnValue] [Default: 344791536]
        int32   CallFunc_GetNumberOfSplinePoints_ReturnValue;   // 0x000004 (0x000004) [Default: 0]
        int32   CallFunc_Subtract_IntInt_ReturnValue;           // 0x000008 (0x000004) [Default: 2621489]
    };

    struct AB_Athena_Zipline_Ascender_C___GetInteractComponentOverride_Params
    {
        AFortPlayerPawn*        InteractingPawn;                                // 0x000000 (0x000008) [Default: 0x148D19F0]
        UPrimitiveComponent*    InteractComponent;                              // 0x000008 (0x000008) [Default: 0xE0361CDD00280031]
        UPrimitiveComponent*    ReturnValue;                                    // 0x000010 (0x000008) [ReturnValue] [Default: 0x7FEDD9614000]
        bool                    CallFunc_IsValid_ReturnValue;                   // 0x000018 (0x000001) [Default: true]
        uint8                   UnknownData_000019[0x000007];                   // 0x000019 (0x000007)
        FVector                 CallFunc_K2_GetComponentLocation_ReturnValue;   // 0x000020 (0x000018)
        bool                    Temp_bool_Variable;                             // 0x000038 (0x000001) [Default: false]
        uint8                   UnknownData_000039[0x000007];                   // 0x000039 (0x000007)
        FVector                 CallFunc_K2_GetComponentLocation_ReturnValue_1; // 0x000040 (0x000018)
        double                  CallFunc_Add_DoubleDouble_ReturnValue;          // 0x000058 (0x000008) [Default: 5.67542e-299]
        double                  CallFunc_Vector_DistanceSquared_ReturnValue;    // 0x000060 (0x000008) [Default: 1.26975e-321]
        double                  CallFunc_Square_ReturnValue;                    // 0x000068 (0x000008)
        bool                    CallFunc_LessEqual_DoubleDouble_ReturnValue;    // 0x000070 (0x000001) [Default: false]
        uint8                   UnknownData_000071[0x000007];                   // 0x000071 (0x000007)
        UPrimitiveComponent*    K2Node_Select_Default;                          // 0x000078 (0x000008) [Default: nullptr]
        double                  CallFunc_Add_DoubleDouble_A_ImplicitCast;       // 0x000080 (0x000008) [Default: 0]
    };

    struct AB_Athena_Zipline_Ascender_C___GetHandleComponent_Params
    {
        UPrimitiveComponent*    ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x148D19F0]
    };

    struct AB_Athena_Zipline_Ascender_C___GetDynamicDestructionStaticMeshComponents_Params
    {
        TArray<UStaticMeshComponent*>   OutFullFXStaticMeshComponents;          // 0x000000 (0x000010) [OutParam]
        TArray<UStaticMeshComponent*>   OutVisibilityOnlyStaticMeshComponents;  // 0x000010 (0x000010) [OutParam]
        TArray<UStaticMeshComponent*>   OutShadowProxyStaticMeshComponents;     // 0x000020 (0x000010) [OutParam]
        TArray<UStaticMeshComponent*>   K2Node_MakeArray_Array;                 // 0x000030 (0x000010)
        TArray<UStaticMeshComponent*>   K2Node_MakeArray_Array_1;               // 0x000040 (0x000010)
    };

    struct AB_Athena_Zipline_Ascender_C___GetDynamicDestructionResourceType_Params
    {
        EDynamicDestructionResourceType ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: EDynamicDestructionResourceType(240)]
    };

    struct AB_Athena_Zipline_Ascender_C___GetBoundsComponents_Params
    {
        AActor*                     SelfActor;      // 0x000000 (0x000008) [Default: 0x148D19F0]
        TArray<USceneComponent*>    OutComponents;  // 0x000008 (0x000010) [OutParam]
    };

    struct AB_Athena_Zipline_Ascender_C___GetAffiliationsToShowFor_Params
    {
        TArray<TEnumAsByte<EFortTeamAffiliation>>   ReturnValue;            // 0x000000 (0x000010) [ReturnValue]
        TArray<TEnumAsByte<EFortTeamAffiliation>>   K2Node_MakeArray_Array; // 0x000010 (0x000010)
    };

    struct AB_Athena_Zipline_Ascender_C___ExecuteUbergraph_B_Athena_Zipline_Ascender_Params
    {
        int32                                                   EntryPoint;                                         // 0x000000 (0x000004) [Default: 344791536]
        PlaylistReadyAsyncDelegate                              K2Node_CreateDelegate_OutputDelegate;               // 0x000004 (0x00000C)
        bool                                                    CallFunc_IsValid_ReturnValue;                       // 0x000010 (0x000001) [Default: false]
        bool                                                    CallFunc_IsValid_ReturnValue_1;                     // 0x000011 (0x000001) [Default: true]
        uint8                                                   UnknownData_000012[0x000006];                       // 0x000012 (0x000006)
        AFortWeapon*                                            CallFunc_GetCurrentWeapon_ReturnValue;              // 0x000018 (0x000008) [Default: 0x7FE99A5F7730]
        AFortWeapon*                                            CallFunc_GetCurrentWeapon_ReturnValue_1;            // 0x000020 (0x000008) [Default: 0x91BF37BC]
        AFortWeaponRanged*                                      K2Node_DynamicCast_AsFort_Weapon_Ranged;            // 0x000028 (0x000008) [Default: 0x130C2840]
        bool                                                    K2Node_DynamicCast_bSuccess;                        // 0x000030 (0x000001) [Default: false]
        uint8                                                   UnknownData_000031[0x000007];                       // 0x000031 (0x000007)
        AFortWeaponRanged*                                      K2Node_DynamicCast_AsFort_Weapon_Ranged_1;          // 0x000038 (0x000008) [Default: nullptr]
        bool                                                    K2Node_DynamicCast_bSuccess_1;                      // 0x000040 (0x000001) [Default: false]
        uint8                                                   UnknownData_000041[0x000007];                       // 0x000041 (0x000007)
        AFortPlayerPawn*                                        K2Node_Event_Player_1;                              // 0x000048 (0x000008) [Default: nullptr]
        AFortPlayerPawn*                                        K2Node_Event_Player;                                // 0x000050 (0x000008) [Default: nullptr]
        bool                                                    CallFunc_IsLocallyViewed_ReturnValue;               // 0x000058 (0x000001) [Default: true]
        bool                                                    CallFunc_IsLocallyViewed_ReturnValue_1;             // 0x000059 (0x000001) [Default: true]
        uint8                                                   UnknownData_00005A[0x000006];                       // 0x00005A (0x000006)
        FVector                                                 CallFunc_K2_GetComponentLocation_ReturnValue;       // 0x000060 (0x000018)
        AFortPlayerPawn*                                        CallFunc_GetPawnUsingHandle_ReturnValue;            // 0x000078 (0x000008) [Default: nullptr]
        bool                                                    CallFunc_IsValid_ReturnValue_2;                     // 0x000080 (0x000001) [Default: false]
        uint8                                                   UnknownData_000081[0x000007];                       // 0x000081 (0x000007)
        UAudioComponent*                                        CallFunc_SpawnSoundAtLocation_ReturnValue;          // 0x000088 (0x000008) [Default: nullptr]
        TArray<AFortPlayerController*>                          Temp_object_Variable;                               // 0x000090 (0x000010)
        UAudioComponent*                                        CallFunc_SpawnSoundAttached_ReturnValue;            // 0x0000A0 (0x000008) [Default: nullptr]
        AFortPlayerPawn*                                        K2Node_Event_InteractingPawn_1;                     // 0x0000A8 (0x000008) [Default: nullptr]
        UPrimitiveComponent*                                    K2Node_Event_InteractComponent_1;                   // 0x0000B0 (0x000008) [Default: nullptr]
        TArray<AFortPlayerController*>                          Temp_object_Variable_1;                             // 0x0000B8 (0x000010)
        AFortPlayerPawn*                                        K2Node_CustomEvent_Sliding_Player;                  // 0x0000C8 (0x000008) [Default: nullptr]
        bool                                                    CallFunc_IsValid_ReturnValue_3;                     // 0x0000D0 (0x000001) [Default: false]
        uint8                                                   UnknownData_0000D1[0x000007];                       // 0x0000D1 (0x000007)
        TArray<FAudioParameter>                                 CallFunc_GetParameters_ReturnValue;                 // 0x0000D8 (0x000010)
        UAudioParameterComponent*                               CallFunc_GetAudioParameterComponent_ReturnValue;    // 0x0000E8 (0x000008) [Default: nullptr]
        bool                                                    CallFunc_IsValid_ReturnValue_4;                     // 0x0000F0 (0x000001) [Default: false]
        uint8                                                   UnknownData_0000F1[0x000007];                       // 0x0000F1 (0x000007)
        TArray<FAudioParameter>                                 CallFunc_GetParameters_ReturnValue_1;               // 0x0000F8 (0x000010)
        UAudioComponent*                                        CallFunc_SpawnSoundAttached_ReturnValue_1;          // 0x000108 (0x000008) [Default: nullptr]
        FVector                                                 CallFunc_K2_GetComponentLocation_ReturnValue_1;     // 0x000110 (0x000018)
        TScriptInterface<IAudioParameterControllerInterface>    CallFunc_SetParameters_Blueprint_self_CastInput;    // 0x000128 (0x000010)
        UAudioComponent*                                        CallFunc_SpawnSoundAttached_ReturnValue_2;          // 0x000138 (0x000008) [Default: nullptr]
        bool                                                    CallFunc_IsValid_ReturnValue_5;                     // 0x000140 (0x000001) [Default: false]
        uint8                                                   UnknownData_000141[0x000007];                       // 0x000141 (0x000007)
        AFortPlayerPawn*                                        K2Node_Event_InteractingPawn;                       // 0x000148 (0x000008) [Default: nullptr]
        UPrimitiveComponent*                                    K2Node_Event_InteractComponent;                     // 0x000150 (0x000008) [Default: 0x10002FFFFFFFF]
        float                                                   K2Node_Event_ZiplineUsageDuration;                  // 0x000158 (0x000004) [Default: 0f]
        OnAscenderSetupComplete                                 K2Node_CreateDelegate_OutputDelegate_1;             // 0x00015C (0x00000C)
        bool                                                    CallFunc_IsValid_ReturnValue_6;                     // 0x000168 (0x000001) [Default: false]
        uint8                                                   UnknownData_000169[0x000007];                       // 0x000169 (0x000007)
        UAudioParameterComponent*                               CallFunc_GetAudioParameterComponent_ReturnValue_1;  // 0x000170 (0x000008) [Default: nullptr]
        bool                                                    CallFunc_IsValid_ReturnValue_7;                     // 0x000178 (0x000001) [Default: false]
        bool                                                    CallFunc_IsValid_ReturnValue_8;                     // 0x000179 (0x000001) [Default: false]
        uint8                                                   UnknownData_00017A[0x000006];                       // 0x00017A (0x000006)
        UFortAsyncAction_CurrentPlaylistReady*                  CallFunc_PlaylistDataReadyAsync_ReturnValue;        // 0x000180 (0x000008) [Default: 0x4000000040A00000]
        bool                                                    CallFunc_IsValid_ReturnValue_9;                     // 0x000188 (0x000001) [Default: false]
        uint8                                                   UnknownData_000189[0x000007];                       // 0x000189 (0x000007)
        AFortGameStateAthena*                                   Temp_object_Variable_2;                             // 0x000190 (0x000008) [Default: nullptr]
        AFortPlayerPawn*                                        CallFunc_GetPawnUsingHandle_ReturnValue_1;          // 0x000198 (0x000008) [Default: nullptr]
        bool                                                    CallFunc_IsValid_ReturnValue_10;                    // 0x0001A0 (0x000001) [Default: false]
        uint8                                                   UnknownData_0001A1[0x000007];                       // 0x0001A1 (0x000007)
        UAudioComponent*                                        CallFunc_SpawnSoundAttached_ReturnValue_3;          // 0x0001A8 (0x000008) [Default: nullptr]
        FTimerHandle                                            CallFunc_K2_SetTimer_ReturnValue;                   // 0x0001B0 (0x000008)
        UFortPlaylist*                                          Temp_object_Variable_3;                             // 0x0001B8 (0x000008) [Default: nullptr]
        FGameplayTagContainer                                   Temp_struct_Variable;                               // 0x0001C0 (0x000020)
        FVector                                                 CallFunc_K2_GetComponentLocation_ReturnValue_2;     // 0x0001E0 (0x000018)
        FVector                                                 CallFunc_Add_VectorVector_ReturnValue;              // 0x0001F8 (0x000018)
        FGameplayCueParameters                                  CallFunc_MakeGameplayCueParameters_ReturnValue;     // 0x000210 (0x0000D0)
        AActor*                                                 K2Node_CustomEvent_DamageCauser;                    // 0x0002E0 (0x000008) [Default: 0x148D2A40]
        OnLinkedActorDestroyed                                  K2Node_CreateDelegate_OutputDelegate_2;             // 0x0002E8 (0x00000C)
        bool                                                    CallFunc_GetValueAsBool_ReturnValue;                // 0x0002F4 (0x000001) [Default: false]
        uint8                                                   UnknownData_0002F5[0x000003];                       // 0x0002F5 (0x000003)
        TScriptInterface<IAudioParameterControllerInterface>    CallFunc_SetParameters_Blueprint_self_CastInput_1;  // 0x0002F8 (0x000010)
        TScriptInterface<IAudioParameterControllerInterface>    CallFunc_SetParameters_Blueprint_self_CastInput_2;  // 0x000308 (0x000010)
        TScriptInterface<IAudioParameterControllerInterface>    CallFunc_SetParameters_Blueprint_self_CastInput_3;  // 0x000318 (0x000010)
        TScriptInterface<IAudioParameterControllerInterface>    CallFunc_SetParameters_Blueprint_self_CastInput_4;  // 0x000328 (0x000010)
        TArray<TEnumAsByte<EFortTeamAffiliation>>               K2Node_MakeArray_Array;                             // 0x000338 (0x000010)
        TScriptInterface<IAudioParameterControllerInterface>    CallFunc_SetParameters_Blueprint_self_CastInput_5;  // 0x000348 (0x000010)
        TArray<TEnumAsByte<EFortTeamAffiliation>>               K2Node_MakeArray_Array_1;                           // 0x000358 (0x000010)
        bool                                                    CallFunc_IsValid_ReturnValue_11;                    // 0x000368 (0x000001) [Default: false]
        uint8                                                   UnknownData_000369[0x000007];                       // 0x000369 (0x000007)
        AFortGameStateAthena*                                   K2Node_CustomEvent_GameState;                       // 0x000370 (0x000008) [Default: nullptr]
        UFortPlaylist*                                          K2Node_CustomEvent_Playlist;                        // 0x000378 (0x000008) [Default: 0xFFFF3F800000]
        FGameplayTagContainer                                   K2Node_CustomEvent_PlaylistContextTags;             // 0x000380 (0x000020)
    };

    struct AB_Athena_Zipline_Ascender_C___DeactivateCableWobble_Params
    {
        bool    CallFunc_IsDedicatedServer_ReturnValue;                                     // 0x000000 (0x000001) [Default: true]
        uint8   UnknownData_000001[0x000007];                                               // 0x000001 (0x000007)
        double  CallFunc_GetGameTimeInSeconds_ReturnValue;                                  // 0x000008 (0x000008) [Default: -2.96483e+155]
        double  CallFunc_Add_DoubleDouble_ReturnValue;                                      // 0x000010 (0x000008) [Default: 6.9495e-310]
        double  CallFunc_GetGameTimeInSeconds_ReturnValue_1;                                // 0x000018 (0x000008) [Default: 6.9486e-310]
        bool    CallFunc_Greater_DoubleDouble_ReturnValue;                                  // 0x000020 (0x000001) [Default: true]
        uint8   UnknownData_000021[0x000003];                                               // 0x000021 (0x000003)
        float   CallFunc_SetScalarParameterValueOnMaterials_ParameterValue_ImplicitCast;    // 0x000024 (0x000004) [Default: 0f]
    };

    struct AB_Athena_Zipline_Ascender_C___CanBeginZiplining_Params
    {
        AFortPlayerPawn*        InteractingPawn;                                    // 0x000000 (0x000008) [Default: 0x148D19F0]
        UPrimitiveComponent*    InteractComponent;                                  // 0x000008 (0x000008) [Default: 0xE0361CDD00280031]
        bool                    ReturnValue;                                        // 0x000010 (0x000001) [ReturnValue] [Default: false]
        bool                    CallFunc_IsDBNO_ReturnValue;                        // 0x000011 (0x000001) [Default: true]
        uint8                   UnknownData_000012[0x000006];                       // 0x000012 (0x000006)
        AFortPlayerPawn*        CallFunc_GetDBNOHoistee_ReturnValue;                // 0x000018 (0x000008) [Default: 0x7FE99A5F7730]
        bool                    CallFunc_AreExtraDBNOInteractionsEnabled_Enabled;   // 0x000020 (0x000001) [Default: true]
        bool                    CallFunc_IsValid_ReturnValue;                       // 0x000021 (0x000001) [Default: true]
        bool                    CallFunc_BooleanOR_ReturnValue;                     // 0x000022 (0x000001) [Default: true]
        bool                    CallFunc_Not_PreBool_ReturnValue;                   // 0x000023 (0x000001) [Default: true]
    };

    struct AB_Athena_Zipline_Ascender_C___CalculateLaunchVelocity_Params
    {
        AActor* PlayerPawn;                                     // 0x000000 (0x000008) [Default: 0x148D19F0]
        FVector LaunchVelocity;                                 // 0x000008 (0x000018) [OutParam]
        FVector CallFunc_GetActorForwardVector_ReturnValue;     // 0x000020 (0x000018)
        float   CallFunc_GetValueAtLevel_ReturnValue;           // 0x000038 (0x000004) [Default: 0f]
        uint8   UnknownData_00003C[0x000004];                   // 0x00003C (0x000004)
        double  CallFunc_Multiply_DoubleDouble_ReturnValue;     // 0x000040 (0x000008) [Default: 0]
        float   CallFunc_GetValueAtLevel_ReturnValue_1;         // 0x000048 (0x000004) [Default: 0f]
        uint8   UnknownData_00004C[0x000004];                   // 0x00004C (0x000004)
        FVector CallFunc_Multiply_VectorFloat_ReturnValue;      // 0x000050 (0x000018)
        FVector CallFunc_MakeVector_ReturnValue;                // 0x000068 (0x000018)
        FVector CallFunc_Add_VectorVector_ReturnValue;          // 0x000080 (0x000018)
        double  CallFunc_Multiply_DoubleDouble_A_ImplicitCast;  // 0x000098 (0x000008) [Default: 0]
        double  CallFunc_MakeVector_Z_ImplicitCast;             // 0x0000A0 (0x000008) [Default: 0]
    };

    struct AB_Athena_Zipline_Ascender_C___BP_HandlePlayerStoppedUsingHandle_Params
    {
        AFortPlayerPawn*    player; // 0x000000 (0x000008) [Default: 0x148D19F0]
    };

    struct AB_Athena_Zipline_Ascender_C___BP_HandlePlayerStartedUsingHandle_Params
    {
        AFortPlayerPawn*    player; // 0x000000 (0x000008) [Default: 0x148D19F0]
    };

    struct AB_Athena_Zipline_Ascender_C___BlueprintGetInteractionString_Params
    {
        AFortPawn*                              InteractingPawn;                                // 0x000000 (0x000008) [Default: 0x148D19F0]
        TEnumAsByte<EInteractionBeingAttempted> InteractionBeingAttempted;                      // 0x000008 (0x000001) [Default: 49]
        uint8                                   UnknownData_000009[0x000007];                   // 0x000009 (0x000007)
        FText                                   ReturnValue;                                    // 0x000010 (0x000010) [ReturnValue]
        bool                                    Temp_bool_Variable;                             // 0x000020 (0x000001) [Default: true]
        uint8                                   UnknownData_000021[0x000007];                   // 0x000021 (0x000007)
        FText                                   Temp_text_Variable;                             // 0x000028 (0x000010)
        FText                                   Temp_text_Variable_1;                           // 0x000038 (0x000010)
        bool                                    CallFunc_EqualEqual_ObjectObject_ReturnValue;   // 0x000048 (0x000001) [Default: false]
        uint8                                   UnknownData_000049[0x000007];                   // 0x000049 (0x000007)
        FText                                   K2Node_Select_Default;                          // 0x000050 (0x000010)
    };

    struct AB_Athena_Zipline_Ascender_C___BlueprintCanInteract_Params
    {
        AFortPawn*                                      InteractingPawn;                                        // 0x000000 (0x000008) [Default: 0x148D19F0]
        TEnumAsByte<EInteractionBeingAttempted>         InteractionBeingAttempted;                              // 0x000008 (0x000001) [Default: 49]
        TEnumAsByte<TInteractionType>                   InteractionType;                                        // 0x000009 (0x000001) [Default: 0]
        bool                                            ReturnValue;                                            // 0x00000A (0x000001) [ReturnValue] [Default: true]
        uint8                                           UnknownData_00000B[0x000005];                           // 0x00000B (0x000005)
        FGameplayTagContainer                           BlockInteractionTags_DBNO;                              // 0x000010 (0x000020)
        FGameplayTagContainer                           BlockInteractionTags;                                   // 0x000030 (0x000020)
        AFortPlayerPawn*                                K2Node_DynamicCast_AsFort_Player_Pawn;                  // 0x000050 (0x000008) [Default: nullptr]
        bool                                            K2Node_DynamicCast_bSuccess;                            // 0x000058 (0x000001) [Default: true]
        uint8                                           UnknownData_000059[0x000007];                           // 0x000059 (0x000007)
        UAbilitySystemComponent*                        CallFunc_GetAbilitySystemComponent_ReturnValue;         // 0x000060 (0x000008) [Default: 0x101]
        bool                                            CallFunc_AreExtraDBNOInteractionsEnabled_Enabled;       // 0x000068 (0x000001) [Default: false]
        uint8                                           UnknownData_000069[0x000007];                           // 0x000069 (0x000007)
        TScriptInterface<IGameplayTagAssetInterface>    CallFunc_HasMatchingGameplayTag_self_CastInput;         // 0x000070 (0x000010)
        bool                                            CallFunc_HasMatchingGameplayTag_ReturnValue;            // 0x000080 (0x000001) [Default: false]
        bool                                            CallFunc_Not_PreBool_ReturnValue;                       // 0x000081 (0x000001) [Default: false]
        bool                                            CallFunc_HasAuthority_ReturnValue;                      // 0x000082 (0x000001) [Default: false]
        bool                                            CallFunc_IsValid_ReturnValue;                           // 0x000083 (0x000001) [Default: false]
        uint8                                           UnknownData_000084[0x000004];                           // 0x000084 (0x000004)
        TScriptInterface<IGameplayTagAssetInterface>    CallFunc_HasAnyMatchingGameplayTags_self_CastInput;     // 0x000088 (0x000010)
        bool                                            CallFunc_HasAnyMatchingGameplayTags_ReturnValue;        // 0x000098 (0x000001) [Default: false]
        bool                                            CallFunc_Not_PreBool_ReturnValue_1;                     // 0x000099 (0x000001) [Default: false]
        uint8                                           UnknownData_00009A[0x000006];                           // 0x00009A (0x000006)
        TScriptInterface<IGameplayTagAssetInterface>    CallFunc_HasAnyMatchingGameplayTags_self_CastInput_1;   // 0x0000A0 (0x000010)
        bool                                            CallFunc_HasAnyMatchingGameplayTags_ReturnValue_1;      // 0x0000B0 (0x000001) [Default: false]
        bool                                            CallFunc_Not_PreBool_ReturnValue_2;                     // 0x0000B1 (0x000001) [Default: false]
        bool                                            CallFunc_BooleanAND_ReturnValue;                        // 0x0000B2 (0x000001) [Default: false]
    };

    struct AB_Athena_Zipline_Ascender_C___AttemptOverrideZiplineSocketOffset_Params
    {
        AFortPlayerPawn*        InteractingPawn;                                // 0x000000 (0x000008) [Default: 0x148D19F0]
        UPrimitiveComponent*    InteractComponent;                              // 0x000008 (0x000008) [Default: 0xE0361CDD00280031]
        FVector                 BaseSocketOffset;                               // 0x000010 (0x000018) [OutParam]
        FVector                 OutSocketOffset;                                // 0x000028 (0x000018) [OutParam]
        bool                    ReturnValue;                                    // 0x000040 (0x000001) [ReturnValue] [Default: false]
        bool                    Temp_bool_Variable;                             // 0x000041 (0x000001) [Default: false]
        uint8                   UnknownData_000042[0x000006];                   // 0x000042 (0x000006)
        UPrimitiveComponent*    CallFunc_GetHandleComponent_ReturnValue;        // 0x000048 (0x000008) [Default: nullptr]
        bool                    CallFunc_EqualEqual_ObjectObject_ReturnValue;   // 0x000050 (0x000001) [Default: false]
        uint8                   UnknownData_000051[0x000007];                   // 0x000051 (0x000007)
        FVector                 K2Node_Select_Default;                          // 0x000058 (0x000018)
        FVector                 CallFunc_Add_VectorVector_ReturnValue;          // 0x000070 (0x000018)
    };

    struct AB_Athena_Zipline_Ascender_C___AttachCapToEndOfSplineMesh_Params
    {
        FVector     CallFunc_MakeVector_ReturnValue;                // 0x000000 (0x000018)
        FVector     CallFunc_Add_VectorVector_ReturnValue;          // 0x000018 (0x000018)
        bool        CallFunc_IsValid_ReturnValue;                   // 0x000030 (0x000001) [Default: false]
        bool        CallFunc_IsValid_ReturnValue_1;                 // 0x000031 (0x000001) [Default: false]
        bool        CallFunc_IsValid_ReturnValue_2;                 // 0x000032 (0x000001) [Default: true]
        bool        CallFunc_BooleanAND_ReturnValue;                // 0x000033 (0x000001) [Default: false]
        bool        CallFunc_BooleanAND_ReturnValue_1;              // 0x000034 (0x000001) [Default: false]
        uint8       UnknownData_000035[0x000003];                   // 0x000035 (0x000003)
        FHitResult  CallFunc_K2_SetWorldLocation_SweepHitResult;    // 0x000038 (0x0000F8)
        double      CallFunc_MakeVector_Z_ImplicitCast;             // 0x000130 (0x000008) [Default: 0]
    };

    struct AB_Athena_Zipline_Ascender_C___AreExtraDBNOInteractionsEnabled_Params
    {
        AFortPawn*                      Pawn;                                                   // 0x000000 (0x000008) [Default: 0x148D19F0]
        bool                            Enabled;                                                // 0x000008 (0x000001) [OutParam] [Default: true]
        uint8                           UnknownData_000009[0x000007];                           // 0x000009 (0x000007)
        UDBNOBehaviorOverrideComponent* CallFunc_GetComponentByClass_ReturnValue;               // 0x000010 (0x000008) [Default: 0x7FEDD9614000]
        bool                            CallFunc_AreExtraDBNOInteractionsEnabled_ReturnValue;   // 0x000018 (0x000001) [Default: true]
        bool                            CallFunc_IsValid_ReturnValue;                           // 0x000019 (0x000001) [Default: true]
    };

    struct AB_Athena_Zipline_Ascender_C___ApplyStructureDamage_Params
    {
        ABuildingSMActor*           BuildingActor;                                  // 0x000000 (0x000008) [Default: 0x148D19F0]
        AActor*                     DamageSource;                                   // 0x000008 (0x000008) [Default: 0xE0361CDD00280031]
        UAbilitySystemComponent*    CallFunc_GetAbilitySystemComponent_ReturnValue; // 0x000010 (0x000008) [Default: 0x7FEDD9614000]
        TArray<UClass*>             K2Node_MakeArray_Array;                         // 0x000018 (0x000010)
        FVector                     CallFunc_K2_GetActorLocation_ReturnValue;       // 0x000028 (0x000018)
    };

    struct AB_Athena_Zipline_Ascender_C___ActivateCableWobble_Params
    {
        bool    CallFunc_IsDedicatedServer_ReturnValue;                                     // 0x000000 (0x000001) [Default: true]
        uint8   UnknownData_000001[0x000007];                                               // 0x000001 (0x000007)
        double  CallFunc_Add_DoubleDouble_ReturnValue;                                      // 0x000008 (0x000008) [Default: -2.96483e+155]
        double  CallFunc_GetGameTimeInSeconds_ReturnValue;                                  // 0x000010 (0x000008) [Default: 6.9495e-310]
        float   CallFunc_SetScalarParameterValueOnMaterials_ParameterValue_ImplicitCast;    // 0x000018 (0x000004) [Default: -4.62116e-23f]
        float   CallFunc_SetScalarParameterValueOnMaterials_ParameterValue_ImplicitCast_1;  // 0x00001C (0x000004) [Default: 4.58855e-41f]
    };

} // namespace UE

