/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:43
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/Gameplay/Ascender/GE_Athena_Ascender_Passive
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000C40 (0x000000)
    class UGE_Athena_Ascender_Passive_C : public UGE_Athena_ZipLine_Passive_C
    {
    public:
    };
}

