/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:37
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/Gameplay/Ascender/B_Athena_Zipline_Ascender_Functions
 * ============================================================
 */

#include "B_Athena_Zipline_Ascender_Functions.hpp"

namespace UE
{

    void AB_Athena_Zipline_Ascender_C::UserConstructionScript(bool CallFunc_IsDedicatedServer_ReturnValue, bool CallFunc_IsValid_ReturnValue, bool CallFunc_IsValid_ReturnValue_1)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.UserConstructionScript");
    
        AB_Athena_Zipline_Ascender_C___UserConstructionScript_Params Params{};
        Params.CallFunc_IsDedicatedServer_ReturnValue = CallFunc_IsDedicatedServer_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool AB_Athena_Zipline_Ascender_C::ShouldUseDynamicDestructionNiagaraSystem()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.ShouldUseDynamicDestructionNiagaraSystem");
    
        AB_Athena_Zipline_Ascender_C___ShouldUseDynamicDestructionNiagaraSystem_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool AB_Athena_Zipline_Ascender_C::ShouldUseDynamicDestructionMaterial()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.ShouldUseDynamicDestructionMaterial");
    
        AB_Athena_Zipline_Ascender_C___ShouldUseDynamicDestructionMaterial_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool AB_Athena_Zipline_Ascender_C::ShouldShowSoundIndicator(AFortPlayerController* PlayerController, bool CallFunc_IsValid_ReturnValue, TEnumAsByte<EFortTeamAffiliation> CallFunc_GetTeamAffiliation_ReturnValue, bool CallFunc_EqualEqual_ByteByte_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.ShouldShowSoundIndicator");
    
        AB_Athena_Zipline_Ascender_C___ShouldShowSoundIndicator_Params Params{};
        Params.PlayerController = PlayerController;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_GetTeamAffiliation_ReturnValue = CallFunc_GetTeamAffiliation_ReturnValue;
        Params.CallFunc_EqualEqual_ByteByte_ReturnValue = CallFunc_EqualEqual_ByteByte_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void AB_Athena_Zipline_Ascender_C::ShouldPlayWhooshTimer()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.ShouldPlayWhooshTimer");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AB_Athena_Zipline_Ascender_C::SetCableTilingBySplineLength(float CallFunc_GetSplineLength_ReturnValue, double CallFunc_Divide_DoubleDouble_ReturnValue, int32 CallFunc_FTrunc_ReturnValue, double CallFunc_Conv_IntToDouble_ReturnValue, double CallFunc_Divide_DoubleDouble_A_ImplicitCast, float CallFunc_SetScalarParameterValueOnMaterials_ParameterValue_ImplicitCast)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.SetCableTilingBySplineLength");
    
        AB_Athena_Zipline_Ascender_C___SetCableTilingBySplineLength_Params Params{};
        Params.CallFunc_GetSplineLength_ReturnValue = CallFunc_GetSplineLength_ReturnValue;
        Params.CallFunc_Divide_DoubleDouble_ReturnValue = CallFunc_Divide_DoubleDouble_ReturnValue;
        Params.CallFunc_FTrunc_ReturnValue = CallFunc_FTrunc_ReturnValue;
        Params.CallFunc_Conv_IntToDouble_ReturnValue = CallFunc_Conv_IntToDouble_ReturnValue;
        Params.CallFunc_Divide_DoubleDouble_A_ImplicitCast = CallFunc_Divide_DoubleDouble_A_ImplicitCast;
        Params.CallFunc_SetScalarParameterValueOnMaterials_ParameterValue_ImplicitCast = CallFunc_SetScalarParameterValueOnMaterials_ParameterValue_ImplicitCast;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AB_Athena_Zipline_Ascender_C::ReceiveBeginPlay()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.ReceiveBeginPlay");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AB_Athena_Zipline_Ascender_C::PlayerDescendingStarted(AFortPlayerPawn* Sliding_Player)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.PlayerDescendingStarted");
    
        AB_Athena_Zipline_Ascender_C___PlayerDescendingStarted_Params Params{};
        Params.Sliding_Player = Sliding_Player;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool AB_Athena_Zipline_Ascender_C::PawnIsInHandleRange(AFortPawn* Pawn, TArray<AActor*> CallFunc_GetOverlappingActors_OverlappingActors, bool CallFunc_Array_Contains_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.PawnIsInHandleRange");
    
        AB_Athena_Zipline_Ascender_C___PawnIsInHandleRange_Params Params{};
        Params.Pawn = Pawn;
        Params.CallFunc_GetOverlappingActors_OverlappingActors = CallFunc_GetOverlappingActors_OverlappingActors;
        Params.CallFunc_Array_Contains_ReturnValue = CallFunc_Array_Contains_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void AB_Athena_Zipline_Ascender_C::OnZipliningStopped(AFortPlayerPawn* InteractingPawn, UPrimitiveComponent* InteractComponent, float ZiplineUsageDuration)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.OnZipliningStopped");
    
        AB_Athena_Zipline_Ascender_C___OnZipliningStopped_Params Params{};
        Params.InteractingPawn = InteractingPawn;
        Params.InteractComponent = InteractComponent;
        Params.ZiplineUsageDuration = ZiplineUsageDuration;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AB_Athena_Zipline_Ascender_C::OnZipliningStarted(AFortPlayerPawn* InteractingPawn, UPrimitiveComponent* InteractComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.OnZipliningStarted");
    
        AB_Athena_Zipline_Ascender_C___OnZipliningStarted_Params Params{};
        Params.InteractingPawn = InteractingPawn;
        Params.InteractComponent = InteractComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AB_Athena_Zipline_Ascender_C::OnRep_BeDestroy()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.OnRep_BeDestroy");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AB_Athena_Zipline_Ascender_C::OnReady_93837FC44A18F6AE57D3478CC43A98AB(AFortGameStateAthena* GameState, UFortPlaylist* Playlist, FGameplayTagContainer& PlaylistContextTags)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.OnReady_93837FC44A18F6AE57D3478CC43A98AB");
    
        AB_Athena_Zipline_Ascender_C___OnReady_93837FC44A18F6AE57D3478CC43A98AB_Params Params{};
        Params.GameState = GameState;
        Params.Playlist = Playlist;
        Params.PlaylistContextTags = PlaylistContextTags;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        PlaylistContextTags = Params.PlaylistContextTags;
    }

    void AB_Athena_Zipline_Ascender_C::OnAscenderSetupComplete_Event()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.OnAscenderSetupComplete_Event");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AB_Athena_Zipline_Ascender_C::LocalOnFailedInteract(AFortPlayerPawn* InteractingPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.LocalOnFailedInteract");
    
        AB_Athena_Zipline_Ascender_C___LocalOnFailedInteract_Params Params{};
        Params.InteractingPawn = InteractingPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AB_Athena_Zipline_Ascender_C::HotfixEnabled(bool CallFunc_GetValueAsBool_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.HotfixEnabled");
    
        AB_Athena_Zipline_Ascender_C___HotfixEnabled_Params Params{};
        Params.CallFunc_GetValueAsBool_ReturnValue = CallFunc_GetValueAsBool_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AB_Athena_Zipline_Ascender_C::HandleLinkedActorDestroyed(AActor* DamageCauser)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.HandleLinkedActorDestroyed");
    
        AB_Athena_Zipline_Ascender_C___HandleLinkedActorDestroyed_Params Params{};
        Params.DamageCauser = DamageCauser;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UPrimitiveComponent* AB_Athena_Zipline_Ascender_C::GetTopComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.GetTopComponent");
    
        AB_Athena_Zipline_Ascender_C___GetTopComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    int32 AB_Athena_Zipline_Ascender_C::GetLastSplinePointIndex(int32 CallFunc_GetNumberOfSplinePoints_ReturnValue, int32 CallFunc_Subtract_IntInt_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.GetLastSplinePointIndex");
    
        AB_Athena_Zipline_Ascender_C___GetLastSplinePointIndex_Params Params{};
        Params.CallFunc_GetNumberOfSplinePoints_ReturnValue = CallFunc_GetNumberOfSplinePoints_ReturnValue;
        Params.CallFunc_Subtract_IntInt_ReturnValue = CallFunc_Subtract_IntInt_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UPrimitiveComponent* AB_Athena_Zipline_Ascender_C::GetInteractComponentOverride(AFortPlayerPawn* InteractingPawn, UPrimitiveComponent* InteractComponent, bool CallFunc_IsValid_ReturnValue, FVector CallFunc_K2_GetComponentLocation_ReturnValue, bool Temp_bool_Variable, FVector CallFunc_K2_GetComponentLocation_ReturnValue_1, double CallFunc_Add_DoubleDouble_ReturnValue, double CallFunc_Vector_DistanceSquared_ReturnValue, double CallFunc_Square_ReturnValue, bool CallFunc_LessEqual_DoubleDouble_ReturnValue, UPrimitiveComponent* K2Node_Select_Default, double CallFunc_Add_DoubleDouble_A_ImplicitCast)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.GetInteractComponentOverride");
    
        AB_Athena_Zipline_Ascender_C___GetInteractComponentOverride_Params Params{};
        Params.InteractingPawn = InteractingPawn;
        Params.InteractComponent = InteractComponent;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_K2_GetComponentLocation_ReturnValue = CallFunc_K2_GetComponentLocation_ReturnValue;
        Params.Temp_bool_Variable = Temp_bool_Variable;
        Params.CallFunc_K2_GetComponentLocation_ReturnValue_1 = CallFunc_K2_GetComponentLocation_ReturnValue_1;
        Params.CallFunc_Add_DoubleDouble_ReturnValue = CallFunc_Add_DoubleDouble_ReturnValue;
        Params.CallFunc_Vector_DistanceSquared_ReturnValue = CallFunc_Vector_DistanceSquared_ReturnValue;
        Params.CallFunc_Square_ReturnValue = CallFunc_Square_ReturnValue;
        Params.CallFunc_LessEqual_DoubleDouble_ReturnValue = CallFunc_LessEqual_DoubleDouble_ReturnValue;
        Params.K2Node_Select_Default = K2Node_Select_Default;
        Params.CallFunc_Add_DoubleDouble_A_ImplicitCast = CallFunc_Add_DoubleDouble_A_ImplicitCast;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UPrimitiveComponent* AB_Athena_Zipline_Ascender_C::GetHandleComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.GetHandleComponent");
    
        AB_Athena_Zipline_Ascender_C___GetHandleComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void AB_Athena_Zipline_Ascender_C::GetDynamicDestructionStaticMeshComponents(TArray<UStaticMeshComponent*>& OutFullFXStaticMeshComponents, TArray<UStaticMeshComponent*>& OutVisibilityOnlyStaticMeshComponents, TArray<UStaticMeshComponent*>& OutShadowProxyStaticMeshComponents, TArray<UStaticMeshComponent*> K2Node_MakeArray_Array, TArray<UStaticMeshComponent*> K2Node_MakeArray_Array_1)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.GetDynamicDestructionStaticMeshComponents");
    
        AB_Athena_Zipline_Ascender_C___GetDynamicDestructionStaticMeshComponents_Params Params{};
        Params.OutFullFXStaticMeshComponents = OutFullFXStaticMeshComponents;
        Params.OutVisibilityOnlyStaticMeshComponents = OutVisibilityOnlyStaticMeshComponents;
        Params.OutShadowProxyStaticMeshComponents = OutShadowProxyStaticMeshComponents;
        Params.K2Node_MakeArray_Array = K2Node_MakeArray_Array;
        Params.K2Node_MakeArray_Array_1 = K2Node_MakeArray_Array_1;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutFullFXStaticMeshComponents = Params.OutFullFXStaticMeshComponents;
        OutVisibilityOnlyStaticMeshComponents = Params.OutVisibilityOnlyStaticMeshComponents;
        OutShadowProxyStaticMeshComponents = Params.OutShadowProxyStaticMeshComponents;
    }

    EDynamicDestructionResourceType AB_Athena_Zipline_Ascender_C::GetDynamicDestructionResourceType()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.GetDynamicDestructionResourceType");
    
        AB_Athena_Zipline_Ascender_C___GetDynamicDestructionResourceType_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void AB_Athena_Zipline_Ascender_C::GetBoundsComponents(AActor* SelfActor, TArray<USceneComponent*>& OutComponents)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.GetBoundsComponents");
    
        AB_Athena_Zipline_Ascender_C___GetBoundsComponents_Params Params{};
        Params.SelfActor = SelfActor;
        Params.OutComponents = OutComponents;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutComponents = Params.OutComponents;
    }

    TArray<TEnumAsByte<EFortTeamAffiliation>> AB_Athena_Zipline_Ascender_C::GetAffiliationsToShowFor(TArray<TEnumAsByte<EFortTeamAffiliation>> K2Node_MakeArray_Array)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.GetAffiliationsToShowFor");
    
        AB_Athena_Zipline_Ascender_C___GetAffiliationsToShowFor_Params Params{};
        Params.K2Node_MakeArray_Array = K2Node_MakeArray_Array;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void AB_Athena_Zipline_Ascender_C::ExecuteUbergraph_B_Athena_Zipline_Ascender(int32 EntryPoint, PlaylistReadyAsyncDelegate K2Node_CreateDelegate_OutputDelegate, bool CallFunc_IsValid_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, AFortWeapon* CallFunc_GetCurrentWeapon_ReturnValue, AFortWeapon* CallFunc_GetCurrentWeapon_ReturnValue_1, AFortWeaponRanged* K2Node_DynamicCast_AsFort_Weapon_Ranged, bool K2Node_DynamicCast_bSuccess, AFortWeaponRanged* K2Node_DynamicCast_AsFort_Weapon_Ranged_1, bool K2Node_DynamicCast_bSuccess_1, AFortPlayerPawn* K2Node_Event_Player_1, AFortPlayerPawn* K2Node_Event_Player, bool CallFunc_IsLocallyViewed_ReturnValue, bool CallFunc_IsLocallyViewed_ReturnValue_1, FVector CallFunc_K2_GetComponentLocation_ReturnValue, AFortPlayerPawn* CallFunc_GetPawnUsingHandle_ReturnValue, bool CallFunc_IsValid_ReturnValue_2, UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue, TArray<AFortPlayerController*> Temp_object_Variable, UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue, AFortPlayerPawn* K2Node_Event_InteractingPawn_1, UPrimitiveComponent* K2Node_Event_InteractComponent_1, TArray<AFortPlayerController*> Temp_object_Variable_1, AFortPlayerPawn* K2Node_CustomEvent_Sliding_Player, bool CallFunc_IsValid_ReturnValue_3, TArray<FAudioParameter> CallFunc_GetParameters_ReturnValue, UAudioParameterComponent* CallFunc_GetAudioParameterComponent_ReturnValue, bool CallFunc_IsValid_ReturnValue_4, TArray<FAudioParameter> CallFunc_GetParameters_ReturnValue_1, UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue_1, FVector CallFunc_K2_GetComponentLocation_ReturnValue_1, TScriptInterface<IAudioParameterControllerInterface> CallFunc_SetParameters_Blueprint_self_CastInput, UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue_2, bool CallFunc_IsValid_ReturnValue_5, AFortPlayerPawn* K2Node_Event_InteractingPawn, UPrimitiveComponent* K2Node_Event_InteractComponent, float K2Node_Event_ZiplineUsageDuration, OnAscenderSetupComplete K2Node_CreateDelegate_OutputDelegate_1, bool CallFunc_IsValid_ReturnValue_6, UAudioParameterComponent* CallFunc_GetAudioParameterComponent_ReturnValue_1, bool CallFunc_IsValid_ReturnValue_7, bool CallFunc_IsValid_ReturnValue_8, UFortAsyncAction_CurrentPlaylistReady* CallFunc_PlaylistDataReadyAsync_ReturnValue, bool CallFunc_IsValid_ReturnValue_9, AFortGameStateAthena* Temp_object_Variable_2, AFortPlayerPawn* CallFunc_GetPawnUsingHandle_ReturnValue_1, bool CallFunc_IsValid_ReturnValue_10, UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue_3, FTimerHandle CallFunc_K2_SetTimer_ReturnValue, UFortPlaylist* Temp_object_Variable_3, FGameplayTagContainer Temp_struct_Variable, FVector CallFunc_K2_GetComponentLocation_ReturnValue_2, FVector CallFunc_Add_VectorVector_ReturnValue, FGameplayCueParameters CallFunc_MakeGameplayCueParameters_ReturnValue, AActor* K2Node_CustomEvent_DamageCauser, OnLinkedActorDestroyed K2Node_CreateDelegate_OutputDelegate_2, bool CallFunc_GetValueAsBool_ReturnValue, TScriptInterface<IAudioParameterControllerInterface> CallFunc_SetParameters_Blueprint_self_CastInput_1, TScriptInterface<IAudioParameterControllerInterface> CallFunc_SetParameters_Blueprint_self_CastInput_2, TScriptInterface<IAudioParameterControllerInterface> CallFunc_SetParameters_Blueprint_self_CastInput_3, TScriptInterface<IAudioParameterControllerInterface> CallFunc_SetParameters_Blueprint_self_CastInput_4, TArray<TEnumAsByte<EFortTeamAffiliation>> K2Node_MakeArray_Array, TScriptInterface<IAudioParameterControllerInterface> CallFunc_SetParameters_Blueprint_self_CastInput_5, TArray<TEnumAsByte<EFortTeamAffiliation>> K2Node_MakeArray_Array_1, bool CallFunc_IsValid_ReturnValue_11, AFortGameStateAthena* K2Node_CustomEvent_GameState, UFortPlaylist* K2Node_CustomEvent_Playlist, FGameplayTagContainer K2Node_CustomEvent_PlaylistContextTags)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.ExecuteUbergraph_B_Athena_Zipline_Ascender");
    
        AB_Athena_Zipline_Ascender_C___ExecuteUbergraph_B_Athena_Zipline_Ascender_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.K2Node_CreateDelegate_OutputDelegate = K2Node_CreateDelegate_OutputDelegate;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
        Params.CallFunc_GetCurrentWeapon_ReturnValue = CallFunc_GetCurrentWeapon_ReturnValue;
        Params.CallFunc_GetCurrentWeapon_ReturnValue_1 = CallFunc_GetCurrentWeapon_ReturnValue_1;
        Params.K2Node_DynamicCast_AsFort_Weapon_Ranged = K2Node_DynamicCast_AsFort_Weapon_Ranged;
        Params.K2Node_DynamicCast_bSuccess = K2Node_DynamicCast_bSuccess;
        Params.K2Node_DynamicCast_AsFort_Weapon_Ranged_1 = K2Node_DynamicCast_AsFort_Weapon_Ranged_1;
        Params.K2Node_DynamicCast_bSuccess_1 = K2Node_DynamicCast_bSuccess_1;
        Params.K2Node_Event_Player_1 = K2Node_Event_Player_1;
        Params.K2Node_Event_Player = K2Node_Event_Player;
        Params.CallFunc_IsLocallyViewed_ReturnValue = CallFunc_IsLocallyViewed_ReturnValue;
        Params.CallFunc_IsLocallyViewed_ReturnValue_1 = CallFunc_IsLocallyViewed_ReturnValue_1;
        Params.CallFunc_K2_GetComponentLocation_ReturnValue = CallFunc_K2_GetComponentLocation_ReturnValue;
        Params.CallFunc_GetPawnUsingHandle_ReturnValue = CallFunc_GetPawnUsingHandle_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_2 = CallFunc_IsValid_ReturnValue_2;
        Params.CallFunc_SpawnSoundAtLocation_ReturnValue = CallFunc_SpawnSoundAtLocation_ReturnValue;
        Params.Temp_object_Variable = Temp_object_Variable;
        Params.CallFunc_SpawnSoundAttached_ReturnValue = CallFunc_SpawnSoundAttached_ReturnValue;
        Params.K2Node_Event_InteractingPawn_1 = K2Node_Event_InteractingPawn_1;
        Params.K2Node_Event_InteractComponent_1 = K2Node_Event_InteractComponent_1;
        Params.Temp_object_Variable_1 = Temp_object_Variable_1;
        Params.K2Node_CustomEvent_Sliding_Player = K2Node_CustomEvent_Sliding_Player;
        Params.CallFunc_IsValid_ReturnValue_3 = CallFunc_IsValid_ReturnValue_3;
        Params.CallFunc_GetParameters_ReturnValue = CallFunc_GetParameters_ReturnValue;
        Params.CallFunc_GetAudioParameterComponent_ReturnValue = CallFunc_GetAudioParameterComponent_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_4 = CallFunc_IsValid_ReturnValue_4;
        Params.CallFunc_GetParameters_ReturnValue_1 = CallFunc_GetParameters_ReturnValue_1;
        Params.CallFunc_SpawnSoundAttached_ReturnValue_1 = CallFunc_SpawnSoundAttached_ReturnValue_1;
        Params.CallFunc_K2_GetComponentLocation_ReturnValue_1 = CallFunc_K2_GetComponentLocation_ReturnValue_1;
        Params.CallFunc_SetParameters_Blueprint_self_CastInput = CallFunc_SetParameters_Blueprint_self_CastInput;
        Params.CallFunc_SpawnSoundAttached_ReturnValue_2 = CallFunc_SpawnSoundAttached_ReturnValue_2;
        Params.CallFunc_IsValid_ReturnValue_5 = CallFunc_IsValid_ReturnValue_5;
        Params.K2Node_Event_InteractingPawn = K2Node_Event_InteractingPawn;
        Params.K2Node_Event_InteractComponent = K2Node_Event_InteractComponent;
        Params.K2Node_Event_ZiplineUsageDuration = K2Node_Event_ZiplineUsageDuration;
        Params.K2Node_CreateDelegate_OutputDelegate_1 = K2Node_CreateDelegate_OutputDelegate_1;
        Params.CallFunc_IsValid_ReturnValue_6 = CallFunc_IsValid_ReturnValue_6;
        Params.CallFunc_GetAudioParameterComponent_ReturnValue_1 = CallFunc_GetAudioParameterComponent_ReturnValue_1;
        Params.CallFunc_IsValid_ReturnValue_7 = CallFunc_IsValid_ReturnValue_7;
        Params.CallFunc_IsValid_ReturnValue_8 = CallFunc_IsValid_ReturnValue_8;
        Params.CallFunc_PlaylistDataReadyAsync_ReturnValue = CallFunc_PlaylistDataReadyAsync_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_9 = CallFunc_IsValid_ReturnValue_9;
        Params.Temp_object_Variable_2 = Temp_object_Variable_2;
        Params.CallFunc_GetPawnUsingHandle_ReturnValue_1 = CallFunc_GetPawnUsingHandle_ReturnValue_1;
        Params.CallFunc_IsValid_ReturnValue_10 = CallFunc_IsValid_ReturnValue_10;
        Params.CallFunc_SpawnSoundAttached_ReturnValue_3 = CallFunc_SpawnSoundAttached_ReturnValue_3;
        Params.CallFunc_K2_SetTimer_ReturnValue = CallFunc_K2_SetTimer_ReturnValue;
        Params.Temp_object_Variable_3 = Temp_object_Variable_3;
        Params.Temp_struct_Variable = Temp_struct_Variable;
        Params.CallFunc_K2_GetComponentLocation_ReturnValue_2 = CallFunc_K2_GetComponentLocation_ReturnValue_2;
        Params.CallFunc_Add_VectorVector_ReturnValue = CallFunc_Add_VectorVector_ReturnValue;
        Params.CallFunc_MakeGameplayCueParameters_ReturnValue = CallFunc_MakeGameplayCueParameters_ReturnValue;
        Params.K2Node_CustomEvent_DamageCauser = K2Node_CustomEvent_DamageCauser;
        Params.K2Node_CreateDelegate_OutputDelegate_2 = K2Node_CreateDelegate_OutputDelegate_2;
        Params.CallFunc_GetValueAsBool_ReturnValue = CallFunc_GetValueAsBool_ReturnValue;
        Params.CallFunc_SetParameters_Blueprint_self_CastInput_1 = CallFunc_SetParameters_Blueprint_self_CastInput_1;
        Params.CallFunc_SetParameters_Blueprint_self_CastInput_2 = CallFunc_SetParameters_Blueprint_self_CastInput_2;
        Params.CallFunc_SetParameters_Blueprint_self_CastInput_3 = CallFunc_SetParameters_Blueprint_self_CastInput_3;
        Params.CallFunc_SetParameters_Blueprint_self_CastInput_4 = CallFunc_SetParameters_Blueprint_self_CastInput_4;
        Params.K2Node_MakeArray_Array = K2Node_MakeArray_Array;
        Params.CallFunc_SetParameters_Blueprint_self_CastInput_5 = CallFunc_SetParameters_Blueprint_self_CastInput_5;
        Params.K2Node_MakeArray_Array_1 = K2Node_MakeArray_Array_1;
        Params.CallFunc_IsValid_ReturnValue_11 = CallFunc_IsValid_ReturnValue_11;
        Params.K2Node_CustomEvent_GameState = K2Node_CustomEvent_GameState;
        Params.K2Node_CustomEvent_Playlist = K2Node_CustomEvent_Playlist;
        Params.K2Node_CustomEvent_PlaylistContextTags = K2Node_CustomEvent_PlaylistContextTags;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AB_Athena_Zipline_Ascender_C::DeactivateCableWobble(bool CallFunc_IsDedicatedServer_ReturnValue, double CallFunc_GetGameTimeInSeconds_ReturnValue, double CallFunc_Add_DoubleDouble_ReturnValue, double CallFunc_GetGameTimeInSeconds_ReturnValue_1, bool CallFunc_Greater_DoubleDouble_ReturnValue, float CallFunc_SetScalarParameterValueOnMaterials_ParameterValue_ImplicitCast)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.DeactivateCableWobble");
    
        AB_Athena_Zipline_Ascender_C___DeactivateCableWobble_Params Params{};
        Params.CallFunc_IsDedicatedServer_ReturnValue = CallFunc_IsDedicatedServer_ReturnValue;
        Params.CallFunc_GetGameTimeInSeconds_ReturnValue = CallFunc_GetGameTimeInSeconds_ReturnValue;
        Params.CallFunc_Add_DoubleDouble_ReturnValue = CallFunc_Add_DoubleDouble_ReturnValue;
        Params.CallFunc_GetGameTimeInSeconds_ReturnValue_1 = CallFunc_GetGameTimeInSeconds_ReturnValue_1;
        Params.CallFunc_Greater_DoubleDouble_ReturnValue = CallFunc_Greater_DoubleDouble_ReturnValue;
        Params.CallFunc_SetScalarParameterValueOnMaterials_ParameterValue_ImplicitCast = CallFunc_SetScalarParameterValueOnMaterials_ParameterValue_ImplicitCast;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    bool AB_Athena_Zipline_Ascender_C::CanBeginZiplining(AFortPlayerPawn* InteractingPawn, UPrimitiveComponent* InteractComponent, bool CallFunc_IsDBNO_ReturnValue, AFortPlayerPawn* CallFunc_GetDBNOHoistee_ReturnValue, bool CallFunc_AreExtraDBNOInteractionsEnabled_Enabled, bool CallFunc_IsValid_ReturnValue, bool CallFunc_BooleanOR_ReturnValue, bool CallFunc_Not_PreBool_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.CanBeginZiplining");
    
        AB_Athena_Zipline_Ascender_C___CanBeginZiplining_Params Params{};
        Params.InteractingPawn = InteractingPawn;
        Params.InteractComponent = InteractComponent;
        Params.CallFunc_IsDBNO_ReturnValue = CallFunc_IsDBNO_ReturnValue;
        Params.CallFunc_GetDBNOHoistee_ReturnValue = CallFunc_GetDBNOHoistee_ReturnValue;
        Params.CallFunc_AreExtraDBNOInteractionsEnabled_Enabled = CallFunc_AreExtraDBNOInteractionsEnabled_Enabled;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_BooleanOR_ReturnValue = CallFunc_BooleanOR_ReturnValue;
        Params.CallFunc_Not_PreBool_ReturnValue = CallFunc_Not_PreBool_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void AB_Athena_Zipline_Ascender_C::CalculateLaunchVelocity(AActor* PlayerPawn, FVector& LaunchVelocity, FVector CallFunc_GetActorForwardVector_ReturnValue, float CallFunc_GetValueAtLevel_ReturnValue, double CallFunc_Multiply_DoubleDouble_ReturnValue, float CallFunc_GetValueAtLevel_ReturnValue_1, FVector CallFunc_Multiply_VectorFloat_ReturnValue, FVector CallFunc_MakeVector_ReturnValue, FVector CallFunc_Add_VectorVector_ReturnValue, double CallFunc_Multiply_DoubleDouble_A_ImplicitCast, double CallFunc_MakeVector_Z_ImplicitCast)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.CalculateLaunchVelocity");
    
        AB_Athena_Zipline_Ascender_C___CalculateLaunchVelocity_Params Params{};
        Params.PlayerPawn = PlayerPawn;
        Params.LaunchVelocity = LaunchVelocity;
        Params.CallFunc_GetActorForwardVector_ReturnValue = CallFunc_GetActorForwardVector_ReturnValue;
        Params.CallFunc_GetValueAtLevel_ReturnValue = CallFunc_GetValueAtLevel_ReturnValue;
        Params.CallFunc_Multiply_DoubleDouble_ReturnValue = CallFunc_Multiply_DoubleDouble_ReturnValue;
        Params.CallFunc_GetValueAtLevel_ReturnValue_1 = CallFunc_GetValueAtLevel_ReturnValue_1;
        Params.CallFunc_Multiply_VectorFloat_ReturnValue = CallFunc_Multiply_VectorFloat_ReturnValue;
        Params.CallFunc_MakeVector_ReturnValue = CallFunc_MakeVector_ReturnValue;
        Params.CallFunc_Add_VectorVector_ReturnValue = CallFunc_Add_VectorVector_ReturnValue;
        Params.CallFunc_Multiply_DoubleDouble_A_ImplicitCast = CallFunc_Multiply_DoubleDouble_A_ImplicitCast;
        Params.CallFunc_MakeVector_Z_ImplicitCast = CallFunc_MakeVector_Z_ImplicitCast;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        LaunchVelocity = Params.LaunchVelocity;
    }

    void AB_Athena_Zipline_Ascender_C::BP_HandleUpdatedLoweringCable()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.BP_HandleUpdatedLoweringCable");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AB_Athena_Zipline_Ascender_C::BP_HandleStoppedLoweringHandle()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.BP_HandleStoppedLoweringHandle");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AB_Athena_Zipline_Ascender_C::BP_HandleStoppedLoweringCable()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.BP_HandleStoppedLoweringCable");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AB_Athena_Zipline_Ascender_C::BP_HandleStartedLoweringHandle()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.BP_HandleStartedLoweringHandle");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AB_Athena_Zipline_Ascender_C::BP_HandleStartedLoweringCable()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.BP_HandleStartedLoweringCable");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AB_Athena_Zipline_Ascender_C::BP_HandlePlayerStoppedUsingHandle(AFortPlayerPawn* player)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.BP_HandlePlayerStoppedUsingHandle");
    
        AB_Athena_Zipline_Ascender_C___BP_HandlePlayerStoppedUsingHandle_Params Params{};
        Params.player = player;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AB_Athena_Zipline_Ascender_C::BP_HandlePlayerStartedUsingHandle(AFortPlayerPawn* player)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.BP_HandlePlayerStartedUsingHandle");
    
        AB_Athena_Zipline_Ascender_C___BP_HandlePlayerStartedUsingHandle_Params Params{};
        Params.player = player;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    FText AB_Athena_Zipline_Ascender_C::BlueprintGetInteractionString(AFortPawn* InteractingPawn, TEnumAsByte<EInteractionBeingAttempted> InteractionBeingAttempted, bool Temp_bool_Variable, FText Temp_text_Variable, FText Temp_text_Variable_1, bool CallFunc_EqualEqual_ObjectObject_ReturnValue, FText K2Node_Select_Default)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.BlueprintGetInteractionString");
    
        AB_Athena_Zipline_Ascender_C___BlueprintGetInteractionString_Params Params{};
        Params.InteractingPawn = InteractingPawn;
        Params.InteractionBeingAttempted = InteractionBeingAttempted;
        Params.Temp_bool_Variable = Temp_bool_Variable;
        Params.Temp_text_Variable = Temp_text_Variable;
        Params.Temp_text_Variable_1 = Temp_text_Variable_1;
        Params.CallFunc_EqualEqual_ObjectObject_ReturnValue = CallFunc_EqualEqual_ObjectObject_ReturnValue;
        Params.K2Node_Select_Default = K2Node_Select_Default;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool AB_Athena_Zipline_Ascender_C::BlueprintCanInteract(AFortPawn* InteractingPawn, TEnumAsByte<EInteractionBeingAttempted> InteractionBeingAttempted, TEnumAsByte<TInteractionType> InteractionType, FGameplayTagContainer BlockInteractionTags_DBNO, FGameplayTagContainer BlockInteractionTags, AFortPlayerPawn* K2Node_DynamicCast_AsFort_Player_Pawn, bool K2Node_DynamicCast_bSuccess, UAbilitySystemComponent* CallFunc_GetAbilitySystemComponent_ReturnValue, bool CallFunc_AreExtraDBNOInteractionsEnabled_Enabled, TScriptInterface<IGameplayTagAssetInterface> CallFunc_HasMatchingGameplayTag_self_CastInput, bool CallFunc_HasMatchingGameplayTag_ReturnValue, bool CallFunc_Not_PreBool_ReturnValue, bool CallFunc_HasAuthority_ReturnValue, bool CallFunc_IsValid_ReturnValue, TScriptInterface<IGameplayTagAssetInterface> CallFunc_HasAnyMatchingGameplayTags_self_CastInput, bool CallFunc_HasAnyMatchingGameplayTags_ReturnValue, bool CallFunc_Not_PreBool_ReturnValue_1, TScriptInterface<IGameplayTagAssetInterface> CallFunc_HasAnyMatchingGameplayTags_self_CastInput_1, bool CallFunc_HasAnyMatchingGameplayTags_ReturnValue_1, bool CallFunc_Not_PreBool_ReturnValue_2, bool CallFunc_BooleanAND_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.BlueprintCanInteract");
    
        AB_Athena_Zipline_Ascender_C___BlueprintCanInteract_Params Params{};
        Params.InteractingPawn = InteractingPawn;
        Params.InteractionBeingAttempted = InteractionBeingAttempted;
        Params.InteractionType = InteractionType;
        Params.BlockInteractionTags_DBNO = BlockInteractionTags_DBNO;
        Params.BlockInteractionTags = BlockInteractionTags;
        Params.K2Node_DynamicCast_AsFort_Player_Pawn = K2Node_DynamicCast_AsFort_Player_Pawn;
        Params.K2Node_DynamicCast_bSuccess = K2Node_DynamicCast_bSuccess;
        Params.CallFunc_GetAbilitySystemComponent_ReturnValue = CallFunc_GetAbilitySystemComponent_ReturnValue;
        Params.CallFunc_AreExtraDBNOInteractionsEnabled_Enabled = CallFunc_AreExtraDBNOInteractionsEnabled_Enabled;
        Params.CallFunc_HasMatchingGameplayTag_self_CastInput = CallFunc_HasMatchingGameplayTag_self_CastInput;
        Params.CallFunc_HasMatchingGameplayTag_ReturnValue = CallFunc_HasMatchingGameplayTag_ReturnValue;
        Params.CallFunc_Not_PreBool_ReturnValue = CallFunc_Not_PreBool_ReturnValue;
        Params.CallFunc_HasAuthority_ReturnValue = CallFunc_HasAuthority_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_HasAnyMatchingGameplayTags_self_CastInput = CallFunc_HasAnyMatchingGameplayTags_self_CastInput;
        Params.CallFunc_HasAnyMatchingGameplayTags_ReturnValue = CallFunc_HasAnyMatchingGameplayTags_ReturnValue;
        Params.CallFunc_Not_PreBool_ReturnValue_1 = CallFunc_Not_PreBool_ReturnValue_1;
        Params.CallFunc_HasAnyMatchingGameplayTags_self_CastInput_1 = CallFunc_HasAnyMatchingGameplayTags_self_CastInput_1;
        Params.CallFunc_HasAnyMatchingGameplayTags_ReturnValue_1 = CallFunc_HasAnyMatchingGameplayTags_ReturnValue_1;
        Params.CallFunc_Not_PreBool_ReturnValue_2 = CallFunc_Not_PreBool_ReturnValue_2;
        Params.CallFunc_BooleanAND_ReturnValue = CallFunc_BooleanAND_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool AB_Athena_Zipline_Ascender_C::AttemptOverrideZiplineSocketOffset(AFortPlayerPawn* InteractingPawn, UPrimitiveComponent* InteractComponent, FVector& BaseSocketOffset, FVector& OutSocketOffset, bool Temp_bool_Variable, UPrimitiveComponent* CallFunc_GetHandleComponent_ReturnValue, bool CallFunc_EqualEqual_ObjectObject_ReturnValue, FVector K2Node_Select_Default, FVector CallFunc_Add_VectorVector_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.AttemptOverrideZiplineSocketOffset");
    
        AB_Athena_Zipline_Ascender_C___AttemptOverrideZiplineSocketOffset_Params Params{};
        Params.InteractingPawn = InteractingPawn;
        Params.InteractComponent = InteractComponent;
        Params.BaseSocketOffset = BaseSocketOffset;
        Params.OutSocketOffset = OutSocketOffset;
        Params.Temp_bool_Variable = Temp_bool_Variable;
        Params.CallFunc_GetHandleComponent_ReturnValue = CallFunc_GetHandleComponent_ReturnValue;
        Params.CallFunc_EqualEqual_ObjectObject_ReturnValue = CallFunc_EqualEqual_ObjectObject_ReturnValue;
        Params.K2Node_Select_Default = K2Node_Select_Default;
        Params.CallFunc_Add_VectorVector_ReturnValue = CallFunc_Add_VectorVector_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BaseSocketOffset = Params.BaseSocketOffset;
        OutSocketOffset = Params.OutSocketOffset;
    
        return Params.ReturnValue;
    }

    void AB_Athena_Zipline_Ascender_C::AttachCapToEndOfSplineMesh(FVector CallFunc_MakeVector_ReturnValue, FVector CallFunc_Add_VectorVector_ReturnValue, bool CallFunc_IsValid_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, bool CallFunc_IsValid_ReturnValue_2, bool CallFunc_BooleanAND_ReturnValue, bool CallFunc_BooleanAND_ReturnValue_1, FHitResult CallFunc_K2_SetWorldLocation_SweepHitResult, double CallFunc_MakeVector_Z_ImplicitCast)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.AttachCapToEndOfSplineMesh");
    
        AB_Athena_Zipline_Ascender_C___AttachCapToEndOfSplineMesh_Params Params{};
        Params.CallFunc_MakeVector_ReturnValue = CallFunc_MakeVector_ReturnValue;
        Params.CallFunc_Add_VectorVector_ReturnValue = CallFunc_Add_VectorVector_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
        Params.CallFunc_IsValid_ReturnValue_2 = CallFunc_IsValid_ReturnValue_2;
        Params.CallFunc_BooleanAND_ReturnValue = CallFunc_BooleanAND_ReturnValue;
        Params.CallFunc_BooleanAND_ReturnValue_1 = CallFunc_BooleanAND_ReturnValue_1;
        Params.CallFunc_K2_SetWorldLocation_SweepHitResult = CallFunc_K2_SetWorldLocation_SweepHitResult;
        Params.CallFunc_MakeVector_Z_ImplicitCast = CallFunc_MakeVector_Z_ImplicitCast;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AB_Athena_Zipline_Ascender_C::AreExtraDBNOInteractionsEnabled(AFortPawn* Pawn, bool& Enabled, UDBNOBehaviorOverrideComponent* CallFunc_GetComponentByClass_ReturnValue, bool CallFunc_AreExtraDBNOInteractionsEnabled_ReturnValue, bool CallFunc_IsValid_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.AreExtraDBNOInteractionsEnabled");
    
        AB_Athena_Zipline_Ascender_C___AreExtraDBNOInteractionsEnabled_Params Params{};
        Params.Pawn = Pawn;
        Params.Enabled = Enabled;
        Params.CallFunc_GetComponentByClass_ReturnValue = CallFunc_GetComponentByClass_ReturnValue;
        Params.CallFunc_AreExtraDBNOInteractionsEnabled_ReturnValue = CallFunc_AreExtraDBNOInteractionsEnabled_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Enabled = Params.Enabled;
    }

    void AB_Athena_Zipline_Ascender_C::ApplyStructureDamage(ABuildingSMActor* BuildingActor, AActor* DamageSource, UAbilitySystemComponent* CallFunc_GetAbilitySystemComponent_ReturnValue, TArray<UClass*> K2Node_MakeArray_Array, FVector CallFunc_K2_GetActorLocation_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.ApplyStructureDamage");
    
        AB_Athena_Zipline_Ascender_C___ApplyStructureDamage_Params Params{};
        Params.BuildingActor = BuildingActor;
        Params.DamageSource = DamageSource;
        Params.CallFunc_GetAbilitySystemComponent_ReturnValue = CallFunc_GetAbilitySystemComponent_ReturnValue;
        Params.K2Node_MakeArray_Array = K2Node_MakeArray_Array;
        Params.CallFunc_K2_GetActorLocation_ReturnValue = CallFunc_K2_GetActorLocation_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AB_Athena_Zipline_Ascender_C::ActivateCableWobble(bool CallFunc_IsDedicatedServer_ReturnValue, double CallFunc_Add_DoubleDouble_ReturnValue, double CallFunc_GetGameTimeInSeconds_ReturnValue, float CallFunc_SetScalarParameterValueOnMaterials_ParameterValue_ImplicitCast, float CallFunc_SetScalarParameterValueOnMaterials_ParameterValue_ImplicitCast_1)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.ActivateCableWobble");
    
        AB_Athena_Zipline_Ascender_C___ActivateCableWobble_Params Params{};
        Params.CallFunc_IsDedicatedServer_ReturnValue = CallFunc_IsDedicatedServer_ReturnValue;
        Params.CallFunc_Add_DoubleDouble_ReturnValue = CallFunc_Add_DoubleDouble_ReturnValue;
        Params.CallFunc_GetGameTimeInSeconds_ReturnValue = CallFunc_GetGameTimeInSeconds_ReturnValue;
        Params.CallFunc_SetScalarParameterValueOnMaterials_ParameterValue_ImplicitCast = CallFunc_SetScalarParameterValueOnMaterials_ParameterValue_ImplicitCast;
        Params.CallFunc_SetScalarParameterValueOnMaterials_ParameterValue_ImplicitCast_1 = CallFunc_SetScalarParameterValueOnMaterials_ParameterValue_ImplicitCast_1;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

