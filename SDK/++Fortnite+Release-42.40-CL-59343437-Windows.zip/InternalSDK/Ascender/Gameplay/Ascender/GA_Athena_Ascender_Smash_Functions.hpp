/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:43
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/Gameplay/Ascender/GA_Athena_Ascender_Smash_Functions
 * ============================================================
 */

#include "GA_Athena_Ascender_Smash.hpp"

namespace UE
{

    struct UGA_Athena_Ascender_Smash_C___DoFailSafeUnholster_Params
    {
        bool    CallFunc_GetConsoleVariableBoolValue_ReturnValue;   // 0x000000 (0x000001) [Default: true]
        bool    CallFunc_GetConsoleVariableBoolValue_ReturnValue_1; // 0x000001 (0x000001) [Default: true]
        bool    CallFunc_BooleanAND_ReturnValue;                    // 0x000002 (0x000001) [Default: true]
    };

    struct UGA_Athena_Ascender_Smash_C___DoHolster_Params
    {
        bool    CallFunc_GetConsoleVariableBoolValue_ReturnValue;   // 0x000000 (0x000001) [Default: true]
    };

    struct UGA_Athena_Ascender_Smash_C___DoUnholster_Params
    {
        bool    CallFunc_GetConsoleVariableBoolValue_ReturnValue;   // 0x000000 (0x000001) [Default: true]
    };

    struct UGA_Athena_Ascender_Smash_C___ExecuteUbergraph_GA_Athena_Ascender_Smash_Params
    {
        int32                               EntryPoint;                                             // 0x000000 (0x000004) [Default: 329804944]
        uint8                               UnknownData_000004[0x000004];                           // 0x000004 (0x000004)
        UAnimMontage*                       CallFunc_GetAscenderMontage_Montage;                    // 0x000008 (0x000008) [Default: 0x7AE712DD00280031]
        UAbilityTask_PlayMontageAndWait*    CallFunc_CreatePlayMontageAndWaitProxy_ReturnValue;     // 0x000010 (0x000008) [Default: 0x7FEDD91D2A80]
        MontageWaitSimpleDelegate           K2Node_CreateDelegate_OutputDelegate;                   // 0x000018 (0x00000C)
        bool                                CallFunc_IsValid_ReturnValue;                           // 0x000024 (0x000001) [Default: false]
        uint8                               UnknownData_000025[0x000003];                           // 0x000025 (0x000003)
        MontageWaitSimpleDelegate           K2Node_CreateDelegate_OutputDelegate_1;                 // 0x000028 (0x00000C)
        MontageWaitSimpleDelegate           K2Node_CreateDelegate_OutputDelegate_2;                 // 0x000034 (0x00000C)
        bool                                CallFunc_IsPlayerUsingHandle_ReturnValue;               // 0x000040 (0x000001) [Default: true]
        bool                                CallFunc_IsPlayerUsingHandle_ReturnValue_1;             // 0x000041 (0x000001) [Default: false]
        uint8                               UnknownData_000042[0x000002];                           // 0x000042 (0x000002)
        MontageWaitSimpleDelegate           K2Node_CreateDelegate_OutputDelegate_3;                 // 0x000044 (0x00000C)
        FGameplayEventData                  K2Node_Event_EventData_2;                               // 0x000050 (0x0000C0)
        FGameplayEventData                  K2Node_Event_EventData_1;                               // 0x000110 (0x0000C0)
        AB_Athena_Zipline_Ascender_C*       K2Node_DynamicCast_AsB_Athena_Zipline_Ascender;         // 0x0001D0 (0x000008) [Default: nullptr]
        bool                                K2Node_DynamicCast_bSuccess;                            // 0x0001D8 (0x000001) [Default: false]
        uint8                               UnknownData_0001D9[0x000007];                           // 0x0001D9 (0x000007)
        UAbilitySystemComponent*            CallFunc_GetAbilitySystemComponent_ReturnValue;         // 0x0001E0 (0x000008) [Default: nullptr]
        FActiveGameplayEffectHandle         CallFunc_BP_ApplyGameplayEffectToTarget_ReturnValue;    // 0x0001E8 (0x000014)
        uint8                               UnknownData_0001FC[0x000004];                           // 0x0001FC (0x000004)
        UAbilitySystemComponent*            CallFunc_GetAbilitySystemComponent_ReturnValue_1;       // 0x000200 (0x000008) [Default: nullptr]
        FActiveGameplayEffectHandle         CallFunc_BP_ApplyGameplayEffectToTarget_ReturnValue_1;  // 0x000208 (0x000014)
        uint8                               UnknownData_00021C[0x000004];                           // 0x00021C (0x000004)
        FGameplayEventData                  K2Node_Event_EventData;                                 // 0x000220 (0x0000C0)
        MontageWaitSimpleDelegate           K2Node_CreateDelegate_OutputDelegate_4;                 // 0x0002E0 (0x00000C)
        bool                                GameplayTagsK2Node_SwitchGameplayTag_CmpSuccess;        // 0x0002EC (0x000001) [Default: false]
        bool                                CallFunc_IsValid_ReturnValue_1;                         // 0x0002ED (0x000001) [Default: false]
    };

    struct UGA_Athena_Ascender_Smash_C___GameplayTagEvent_ZiplineEnter_Params
    {
        FGameplayEventData  EventData;  // 0x000000 (0x0000C0) [OutParam]
    };

    struct UGA_Athena_Ascender_Smash_C___GameplayTagEvent_ZiplineExit_Params
    {
        FGameplayEventData  EventData;  // 0x000000 (0x0000C0) [OutParam]
    };

    struct UGA_Athena_Ascender_Smash_C___GetAscenderMontage_Params
    {
        UAnimMontage*                               Montage;                                    // 0x000000 (0x000008) [OutParam] [Default: 0x13A86C90]
        bool                                        Temp_bool_Variable;                         // 0x000008 (0x000001) [Default: true]
        bool                                        Temp_bool_Variable_1;                       // 0x000009 (0x000001) [Default: false]
        TEnumAsByte<EFortCustomGender>              Temp_byte_Variable;                         // 0x00000A (0x000001) [Default: 40]
        bool                                        CallFunc_IsPlayerUsingHandle_ReturnValue;   // 0x00000B (0x000001) [Default: false]
        uint8                                       UnknownData_00000C[0x000004];               // 0x00000C (0x000004)
        UFortPawnComponent_AscenderMontageProvider* CallFunc_GetComponentByClass_ReturnValue;   // 0x000010 (0x000008) [Default: 0x7FEDD91D2A80]
        TEnumAsByte<EFortCustomGender>              CallFunc_GetCharacterGender_ReturnValue;    // 0x000018 (0x000001) [Default: 192]
        uint8                                       UnknownData_000019[0x000007];               // 0x000019 (0x000007)
        UAnimMontage*                               CallFunc_GetSuitableMontage_ReturnValue;    // 0x000020 (0x000008) [Default: 0xEB7537BC]
        bool                                        CallFunc_IsValid_ReturnValue;               // 0x000028 (0x000001) [Default: true]
        bool                                        CallFunc_IsPlayerUsingHandle_ReturnValue_1; // 0x000029 (0x000001) [Default: true]
        uint8                                       UnknownData_00002A[0x000006];               // 0x00002A (0x000006)
        UAnimMontage*                               K2Node_Select_Default;                      // 0x000030 (0x000008) [Default: nullptr]
        bool                                        CallFunc_IsPlayerUsingHandle_ReturnValue_2; // 0x000038 (0x000001) [Default: false]
        uint8                                       UnknownData_000039[0x000007];               // 0x000039 (0x000007)
        UAnimMontage*                               K2Node_Select_Default_1;                    // 0x000040 (0x000008) [Default: 0x2]
        UAnimMontage*                               K2Node_Select_Default_2;                    // 0x000048 (0x000008) [Default: nullptr]
    };

    struct UGA_Athena_Ascender_Smash_C___HandleGameplayEventTag_Params
    {
        FGameplayEventData  EventData;  // 0x000000 (0x0000C0) [OutParam]
    };

    struct UGA_Athena_Ascender_Smash_C___IsPlayerUsingHandle_Params
    {
        bool                ReturnValue;                                    // 0x000000 (0x000001) [ReturnValue] [Default: true]
        bool                CallFunc_IsValid_ReturnValue;                   // 0x000001 (0x000001) [Default: true]
        bool                CallFunc_IsValid_ReturnValue_1;                 // 0x000002 (0x000001) [Default: true]
        uint8               UnknownData_000003[0x000005];                   // 0x000003 (0x000005)
        AFortPlayerPawn*    CallFunc_GetPawnUsingHandle_ReturnValue;        // 0x000008 (0x000008) [Default: 0x7AE712DD00280031]
        bool                CallFunc_EqualEqual_ObjectObject_ReturnValue;   // 0x000010 (0x000001) [Default: true]
    };

} // namespace UE

