/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:43
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/Gameplay/Ascender/GA_Athena_Ascender_Passive_Functions
 * ============================================================
 */

#include "GA_Athena_Ascender_Passive_Functions.hpp"

namespace UE
{

    void UGA_Athena_Ascender_Passive_C::ExecuteUbergraph_GA_Athena_Ascender_Passive(int32 EntryPoint, FGameplayAbilityActorInfo K2Node_Event_ActorInfo)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Passive.GA_Athena_Ascender_Passive_C.ExecuteUbergraph_GA_Athena_Ascender_Passive");
    
        UGA_Athena_Ascender_Passive_C___ExecuteUbergraph_GA_Athena_Ascender_Passive_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.K2Node_Event_ActorInfo = K2Node_Event_ActorInfo;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_Athena_Ascender_Passive_C::FailedToActivatePassiveAbility(FGameplayAbilityActorInfo ActorInfo)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Passive.GA_Athena_Ascender_Passive_C.FailedToActivatePassiveAbility");
    
        UGA_Athena_Ascender_Passive_C___FailedToActivatePassiveAbility_Params Params{};
        Params.ActorInfo = ActorInfo;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

