/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:43
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/Gameplay/Ascender/GA_Athena_Ascender_Smash_Functions
 * ============================================================
 */

#include "GA_Athena_Ascender_Smash_Functions.hpp"

namespace UE
{

    void UGA_Athena_Ascender_Smash_C::DoFailSafeUnholster(bool CallFunc_GetConsoleVariableBoolValue_ReturnValue, bool CallFunc_GetConsoleVariableBoolValue_ReturnValue_1, bool CallFunc_BooleanAND_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.DoFailSafeUnholster");
    
        UGA_Athena_Ascender_Smash_C___DoFailSafeUnholster_Params Params{};
        Params.CallFunc_GetConsoleVariableBoolValue_ReturnValue = CallFunc_GetConsoleVariableBoolValue_ReturnValue;
        Params.CallFunc_GetConsoleVariableBoolValue_ReturnValue_1 = CallFunc_GetConsoleVariableBoolValue_ReturnValue_1;
        Params.CallFunc_BooleanAND_ReturnValue = CallFunc_BooleanAND_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_Athena_Ascender_Smash_C::DoHolster(bool CallFunc_GetConsoleVariableBoolValue_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.DoHolster");
    
        UGA_Athena_Ascender_Smash_C___DoHolster_Params Params{};
        Params.CallFunc_GetConsoleVariableBoolValue_ReturnValue = CallFunc_GetConsoleVariableBoolValue_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_Athena_Ascender_Smash_C::DoUnholster(bool CallFunc_GetConsoleVariableBoolValue_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.DoUnholster");
    
        UGA_Athena_Ascender_Smash_C___DoUnholster_Params Params{};
        Params.CallFunc_GetConsoleVariableBoolValue_ReturnValue = CallFunc_GetConsoleVariableBoolValue_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_Athena_Ascender_Smash_C::ExecuteUbergraph_GA_Athena_Ascender_Smash(int32 EntryPoint, UAnimMontage* CallFunc_GetAscenderMontage_Montage, UAbilityTask_PlayMontageAndWait* CallFunc_CreatePlayMontageAndWaitProxy_ReturnValue, MontageWaitSimpleDelegate K2Node_CreateDelegate_OutputDelegate, bool CallFunc_IsValid_ReturnValue, MontageWaitSimpleDelegate K2Node_CreateDelegate_OutputDelegate_1, MontageWaitSimpleDelegate K2Node_CreateDelegate_OutputDelegate_2, bool CallFunc_IsPlayerUsingHandle_ReturnValue, bool CallFunc_IsPlayerUsingHandle_ReturnValue_1, MontageWaitSimpleDelegate K2Node_CreateDelegate_OutputDelegate_3, FGameplayEventData K2Node_Event_EventData_2, FGameplayEventData K2Node_Event_EventData_1, AB_Athena_Zipline_Ascender_C* K2Node_DynamicCast_AsB_Athena_Zipline_Ascender, bool K2Node_DynamicCast_bSuccess, UAbilitySystemComponent* CallFunc_GetAbilitySystemComponent_ReturnValue, FActiveGameplayEffectHandle CallFunc_BP_ApplyGameplayEffectToTarget_ReturnValue, UAbilitySystemComponent* CallFunc_GetAbilitySystemComponent_ReturnValue_1, FActiveGameplayEffectHandle CallFunc_BP_ApplyGameplayEffectToTarget_ReturnValue_1, FGameplayEventData K2Node_Event_EventData, MontageWaitSimpleDelegate K2Node_CreateDelegate_OutputDelegate_4, bool GameplayTagsK2Node_SwitchGameplayTag_CmpSuccess, bool CallFunc_IsValid_ReturnValue_1)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.ExecuteUbergraph_GA_Athena_Ascender_Smash");
    
        UGA_Athena_Ascender_Smash_C___ExecuteUbergraph_GA_Athena_Ascender_Smash_Params Params{};
        Params.EntryPoint = EntryPoint;
        Params.CallFunc_GetAscenderMontage_Montage = CallFunc_GetAscenderMontage_Montage;
        Params.CallFunc_CreatePlayMontageAndWaitProxy_ReturnValue = CallFunc_CreatePlayMontageAndWaitProxy_ReturnValue;
        Params.K2Node_CreateDelegate_OutputDelegate = K2Node_CreateDelegate_OutputDelegate;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.K2Node_CreateDelegate_OutputDelegate_1 = K2Node_CreateDelegate_OutputDelegate_1;
        Params.K2Node_CreateDelegate_OutputDelegate_2 = K2Node_CreateDelegate_OutputDelegate_2;
        Params.CallFunc_IsPlayerUsingHandle_ReturnValue = CallFunc_IsPlayerUsingHandle_ReturnValue;
        Params.CallFunc_IsPlayerUsingHandle_ReturnValue_1 = CallFunc_IsPlayerUsingHandle_ReturnValue_1;
        Params.K2Node_CreateDelegate_OutputDelegate_3 = K2Node_CreateDelegate_OutputDelegate_3;
        Params.K2Node_Event_EventData_2 = K2Node_Event_EventData_2;
        Params.K2Node_Event_EventData_1 = K2Node_Event_EventData_1;
        Params.K2Node_DynamicCast_AsB_Athena_Zipline_Ascender = K2Node_DynamicCast_AsB_Athena_Zipline_Ascender;
        Params.K2Node_DynamicCast_bSuccess = K2Node_DynamicCast_bSuccess;
        Params.CallFunc_GetAbilitySystemComponent_ReturnValue = CallFunc_GetAbilitySystemComponent_ReturnValue;
        Params.CallFunc_BP_ApplyGameplayEffectToTarget_ReturnValue = CallFunc_BP_ApplyGameplayEffectToTarget_ReturnValue;
        Params.CallFunc_GetAbilitySystemComponent_ReturnValue_1 = CallFunc_GetAbilitySystemComponent_ReturnValue_1;
        Params.CallFunc_BP_ApplyGameplayEffectToTarget_ReturnValue_1 = CallFunc_BP_ApplyGameplayEffectToTarget_ReturnValue_1;
        Params.K2Node_Event_EventData = K2Node_Event_EventData;
        Params.K2Node_CreateDelegate_OutputDelegate_4 = K2Node_CreateDelegate_OutputDelegate_4;
        Params.GameplayTagsK2Node_SwitchGameplayTag_CmpSuccess = GameplayTagsK2Node_SwitchGameplayTag_CmpSuccess;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UGA_Athena_Ascender_Smash_C::FallingTagRemoved()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.FallingTagRemoved");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_Athena_Ascender_Smash_C::GameplayTagEvent_ZiplineEnter(FGameplayEventData& EventData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.GameplayTagEvent_ZiplineEnter");
    
        UGA_Athena_Ascender_Smash_C___GameplayTagEvent_ZiplineEnter_Params Params{};
        Params.EventData = EventData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        EventData = Params.EventData;
    }

    void UGA_Athena_Ascender_Smash_C::GameplayTagEvent_ZiplineExit(FGameplayEventData& EventData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.GameplayTagEvent_ZiplineExit");
    
        UGA_Athena_Ascender_Smash_C___GameplayTagEvent_ZiplineExit_Params Params{};
        Params.EventData = EventData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        EventData = Params.EventData;
    }

    void UGA_Athena_Ascender_Smash_C::GetAscenderMontage(UAnimMontage*& Montage, bool Temp_bool_Variable, bool Temp_bool_Variable_1, TEnumAsByte<EFortCustomGender> Temp_byte_Variable, bool CallFunc_IsPlayerUsingHandle_ReturnValue, UFortPawnComponent_AscenderMontageProvider* CallFunc_GetComponentByClass_ReturnValue, TEnumAsByte<EFortCustomGender> CallFunc_GetCharacterGender_ReturnValue, UAnimMontage* CallFunc_GetSuitableMontage_ReturnValue, bool CallFunc_IsValid_ReturnValue, bool CallFunc_IsPlayerUsingHandle_ReturnValue_1, UAnimMontage* K2Node_Select_Default, bool CallFunc_IsPlayerUsingHandle_ReturnValue_2, UAnimMontage* K2Node_Select_Default_1, UAnimMontage* K2Node_Select_Default_2)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.GetAscenderMontage");
    
        UGA_Athena_Ascender_Smash_C___GetAscenderMontage_Params Params{};
        Params.Montage = Montage;
        Params.Temp_bool_Variable = Temp_bool_Variable;
        Params.Temp_bool_Variable_1 = Temp_bool_Variable_1;
        Params.Temp_byte_Variable = Temp_byte_Variable;
        Params.CallFunc_IsPlayerUsingHandle_ReturnValue = CallFunc_IsPlayerUsingHandle_ReturnValue;
        Params.CallFunc_GetComponentByClass_ReturnValue = CallFunc_GetComponentByClass_ReturnValue;
        Params.CallFunc_GetCharacterGender_ReturnValue = CallFunc_GetCharacterGender_ReturnValue;
        Params.CallFunc_GetSuitableMontage_ReturnValue = CallFunc_GetSuitableMontage_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_IsPlayerUsingHandle_ReturnValue_1 = CallFunc_IsPlayerUsingHandle_ReturnValue_1;
        Params.K2Node_Select_Default = K2Node_Select_Default;
        Params.CallFunc_IsPlayerUsingHandle_ReturnValue_2 = CallFunc_IsPlayerUsingHandle_ReturnValue_2;
        Params.K2Node_Select_Default_1 = K2Node_Select_Default_1;
        Params.K2Node_Select_Default_2 = K2Node_Select_Default_2;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Montage = Params.Montage;
    }

    void UGA_Athena_Ascender_Smash_C::HandleGameplayEventTag(FGameplayEventData& EventData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.HandleGameplayEventTag");
    
        UGA_Athena_Ascender_Smash_C___HandleGameplayEventTag_Params Params{};
        Params.EventData = EventData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        EventData = Params.EventData;
    }

    bool UGA_Athena_Ascender_Smash_C::IsPlayerUsingHandle(bool CallFunc_IsValid_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, AFortPlayerPawn* CallFunc_GetPawnUsingHandle_ReturnValue, bool CallFunc_EqualEqual_ObjectObject_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.IsPlayerUsingHandle");
    
        UGA_Athena_Ascender_Smash_C___IsPlayerUsingHandle_Params Params{};
        Params.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
        Params.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
        Params.CallFunc_GetPawnUsingHandle_ReturnValue = CallFunc_GetPawnUsingHandle_ReturnValue;
        Params.CallFunc_EqualEqual_ObjectObject_ReturnValue = CallFunc_EqualEqual_ObjectObject_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UGA_Athena_Ascender_Smash_C::OnBlendedIn_899182BF4C098785CCBCFD85AA84455F()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.OnBlendedIn_899182BF4C098785CCBCFD85AA84455F");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_Athena_Ascender_Smash_C::OnBlendOut_899182BF4C098785CCBCFD85AA84455F()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.OnBlendOut_899182BF4C098785CCBCFD85AA84455F");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_Athena_Ascender_Smash_C::OnCancelled_899182BF4C098785CCBCFD85AA84455F()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.OnCancelled_899182BF4C098785CCBCFD85AA84455F");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_Athena_Ascender_Smash_C::OnCompleted_899182BF4C098785CCBCFD85AA84455F()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.OnCompleted_899182BF4C098785CCBCFD85AA84455F");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_Athena_Ascender_Smash_C::OnInterrupted_899182BF4C098785CCBCFD85AA84455F()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.OnInterrupted_899182BF4C098785CCBCFD85AA84455F");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_Athena_Ascender_Smash_C::Pre_BeginZiplinging()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.Pre_BeginZiplinging");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_Athena_Ascender_Smash_C::SurroundingsCheck_MotorCheck()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.SurroundingsCheck_MotorCheck");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_Athena_Ascender_Smash_C::SurroundingsCheck_SmashObjects()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.SurroundingsCheck_SmashObjects");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_Athena_Ascender_Smash_C::ZiplinePostBegin_Event()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.ZiplinePostBegin_Event");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UGA_Athena_Ascender_Smash_C::ZipliningComplete()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("GA_Athena_Ascender_Smash.GA_Athena_Ascender_Smash_C.ZipliningComplete");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

} // namespace UE

