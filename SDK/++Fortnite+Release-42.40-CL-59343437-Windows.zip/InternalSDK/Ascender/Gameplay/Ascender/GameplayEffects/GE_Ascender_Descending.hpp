/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:43
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/Gameplay/Ascender/GameplayEffects/GE_Ascender_Descending
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000C40 (0x000000)
    class UGE_Ascender_Descending_C : public UGameplayEffect
    {
    public:
    };
}

