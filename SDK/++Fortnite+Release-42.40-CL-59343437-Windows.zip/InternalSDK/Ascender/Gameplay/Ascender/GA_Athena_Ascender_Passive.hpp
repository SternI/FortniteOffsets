/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:43
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Ascender/Gameplay/Ascender/GA_Athena_Ascender_Passive
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000B28 (0x000008)
    class alignas(0x8) UGA_Athena_Ascender_Passive_C : public UFortGameplayAbility
    {
    public:
        FPointerToUberGraphFrame    UberGraphFrame; // 0x000B20 (0x000008)
    
    public: // Functions
        void    ExecuteUbergraph_GA_Athena_Ascender_Passive(int32 EntryPoint, FGameplayAbilityActorInfo K2Node_Event_ActorInfo); // 0x000545D2 [Final | UbergraphFunction | HasDefaults]
        void    FailedToActivatePassiveAbility(FGameplayAbilityActorInfo ActorInfo); // 0x000545D2 [Event | Public | BlueprintEvent]
    };
}

