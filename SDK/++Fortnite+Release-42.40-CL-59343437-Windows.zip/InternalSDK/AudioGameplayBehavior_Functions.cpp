/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioGameplayBehavior_Functions
 * ============================================================
 */

#include "AudioGameplayBehavior_Functions.hpp"

namespace UE
{

    void UAudioGameplayBehavior::BP_OnFinished()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.BP_OnFinished");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioGameplayBehavior::BP_OnGroupSet(UAudioComponentGroup* SoundGroup)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.BP_OnGroupSet");
    
        UAudioGameplayBehavior___BP_OnGroupSet_Params Params{};
        Params.SoundGroup = SoundGroup;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioGameplayBehavior::BP_OnStart()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.BP_OnStart");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioGameplayBehavior::BP_OnStop()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.BP_OnStop");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioGameplayBehavior::BP_OnUnvirtualized()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.BP_OnUnvirtualized");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioGameplayBehavior::BP_OnVirtualized()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.BP_OnVirtualized");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioGameplayBehavior::DisableVirtualization()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.DisableVirtualization");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioGameplayBehavior::EnableVirtualization()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.EnableVirtualization");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    bool UAudioGameplayBehavior::GetBoolParamValue(FName ParamName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.GetBoolParamValue");
    
        UAudioGameplayBehavior___GetBoolParamValue_Params Params{};
        Params.ParamName = ParamName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAudioGameplayBehavior::GetFloatParamValue(FName ParamName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.GetFloatParamValue");
    
        UAudioGameplayBehavior___GetFloatParamValue_Params Params{};
        Params.ParamName = ParamName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EAudioGameplayBehaviorPlayState UAudioGameplayBehavior::GetPlayState()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.GetPlayState");
    
        UAudioGameplayBehavior___GetPlayState_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAudioComponentGroup* UAudioGameplayBehavior::GetSoundGroup()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.GetSoundGroup");
    
        UAudioGameplayBehavior___GetSoundGroup_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EAudioGameplayBehaviorPlayState UAudioGameplayBehavior::GetStopState()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.GetStopState");
    
        UAudioGameplayBehavior___GetStopState_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FString UAudioGameplayBehavior::GetStringParamValue(FName ParamName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.GetStringParamValue");
    
        UAudioGameplayBehavior___GetStringParamValue_Params Params{};
        Params.ParamName = ParamName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAudioGameplayBehavior::IsPlayingAny()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.IsPlayingAny");
    
        UAudioGameplayBehavior___IsPlayingAny_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAudioGameplayBehavior::IsVirtualized()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.IsVirtualized");
    
        UAudioGameplayBehavior___IsVirtualized_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioGameplayBehavior::Kill()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.Kill");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioGameplayBehavior::PlayFrom(UAudioComponentGroup* SoundGroup)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.PlayFrom");
    
        UAudioGameplayBehavior___PlayFrom_Params Params{};
        Params.SoundGroup = SoundGroup;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    FActiveVoice UAudioGameplayBehavior::PlaySound(USoundBase* Sound, float InFadeInTime, float InTargetVolume, float InStartTime, bool bDisableAttenuation, EAudioFaderCurve InFadeCurve, FVector InRelativeLocation, FRotator InRelativeRotation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.PlaySound");
    
        UAudioGameplayBehavior___PlaySound_Params Params{};
        Params.Sound = Sound;
        Params.InFadeInTime = InFadeInTime;
        Params.InTargetVolume = InTargetVolume;
        Params.InStartTime = InStartTime;
        Params.bDisableAttenuation = bDisableAttenuation;
        Params.InFadeCurve = InFadeCurve;
        Params.InRelativeLocation = InRelativeLocation;
        Params.InRelativeRotation = InRelativeRotation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioGameplayBehavior::SetPlayState(EAudioGameplayBehaviorPlayState NewState)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.SetPlayState");
    
        UAudioGameplayBehavior___SetPlayState_Params Params{};
        Params.NewState = NewState;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioGameplayBehavior::Start()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.Start");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioGameplayBehavior::Stop()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.Stop");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioGameplayBehavior::StopAllPlayingVoices(float InFadeOutTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.StopAllPlayingVoices");
    
        UAudioGameplayBehavior___StopAllPlayingVoices_Params Params{};
        Params.InFadeOutTime = InFadeOutTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioGameplayBehavior::StopById(FPlayingId ID, float InFadeOutTime, EAudioFaderCurve InFadeCurve)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.StopById");
    
        UAudioGameplayBehavior___StopById_Params Params{};
        Params.ID = ID;
        Params.InFadeOutTime = InFadeOutTime;
        Params.InFadeCurve = InFadeCurve;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioGameplayBehavior::StopComponent(UAudioComponent* Comp, float InFadeOutTime, EAudioFaderCurve InFadeCurve)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.StopComponent");
    
        UAudioGameplayBehavior___StopComponent_Params Params{};
        Params.Comp = Comp;
        Params.InFadeOutTime = InFadeOutTime;
        Params.InFadeCurve = InFadeCurve;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioGameplayBehavior::StopSound(USoundBase* Sound, float InFadeOutTime, EAudioFaderCurve InFadeCurve)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.StopSound");
    
        UAudioGameplayBehavior___StopSound_Params Params{};
        Params.Sound = Sound;
        Params.InFadeOutTime = InFadeOutTime;
        Params.InFadeCurve = InFadeCurve;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioGameplayBehavior::SubscribeToBoolParam(FName ParamName, BoolParamCallback Delegate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.SubscribeToBoolParam");
    
        UAudioGameplayBehavior___SubscribeToBoolParam_Params Params{};
        Params.ParamName = ParamName;
        Params.Delegate = Delegate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioGameplayBehavior::SubscribeToEvent(FName EventName, SoundCallback Delegate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.SubscribeToEvent");
    
        UAudioGameplayBehavior___SubscribeToEvent_Params Params{};
        Params.EventName = EventName;
        Params.Delegate = Delegate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioGameplayBehavior::SubscribeToStringParam(FName ParamName, StringParamCallback Delegate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioGameplayBehavior.AudioGameplayBehavior.SubscribeToStringParam");
    
        UAudioGameplayBehavior___SubscribeToStringParam_Params Params{};
        Params.ParamName = ParamName;
        Params.Delegate = Delegate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

