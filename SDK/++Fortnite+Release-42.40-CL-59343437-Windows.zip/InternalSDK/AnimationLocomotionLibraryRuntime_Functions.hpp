/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimationLocomotionLibraryRuntime_Functions
 * ============================================================
 */

#include "AnimationLocomotionLibraryRuntime.hpp"

namespace UE
{

    struct UAnimCharacterMovementLibrary___PredictGroundMovementPivotLocation_Params
    {
        FVector Acceleration;                   // 0x000000 (0x000018) [OutParam]
        FVector Velocity;                       // 0x000018 (0x000018) [OutParam]
        float   GroundFriction;                 // 0x000030 (0x000004) [Default: 6.86636e-44f]
        uint8   UnknownData_000034[0x000004];   // 0x000034 (0x000004)
        FVector ReturnValue;                    // 0x000038 (0x000018) [ReturnValue]
    };

    struct UAnimCharacterMovementLibrary___PredictGroundMovementStopLocation_Params
    {
        FVector Velocity;                       // 0x000000 (0x000018) [OutParam]
        bool    bUseSeparateBrakingFriction;    // 0x000018 (0x000001) [Default: true]
        uint8   UnknownData_000019[0x000003];   // 0x000019 (0x000003)
        float   BrakingFriction;                // 0x00001C (0x000004) [Default: 0f]
        float   GroundFriction;                 // 0x000020 (0x000004) [Default: -2.56842e+23f]
        float   BrakingFrictionFactor;          // 0x000024 (0x000004) [Default: 0f]
        float   BrakingDecelerationWalking;     // 0x000028 (0x000004) [Default: 1.74651e-27f]
        uint8   UnknownData_00002C[0x000004];   // 0x00002C (0x000004)
        FVector ReturnValue;                    // 0x000030 (0x000018) [ReturnValue]
    };

    struct UAnimDistanceMatchingLibrary___AdvanceTimeByDistanceMatching_Params
    {
        FAnimUpdateContext          UpdateContext;      // 0x000000 (0x000010) [OutParam]
        FSequenceEvaluatorReference SequenceEvaluator;  // 0x000010 (0x000010) [OutParam]
        float                       DistanceTraveled;   // 0x000020 (0x000004) [Default: -4.30909e+30f]
        FName                       DistanceCurveName;  // 0x000024 (0x000004) [Default: NAME_None]
        FVector2D                   PlayRateClamp;      // 0x000028 (0x000010)
        FSequenceEvaluatorReference ReturnValue;        // 0x000038 (0x000010) [ReturnValue]
    };

    struct UAnimDistanceMatchingLibrary___DistanceMatchToTarget_Params
    {
        FSequenceEvaluatorReference SequenceEvaluator;  // 0x000000 (0x000010) [OutParam]
        float                       DistanceToTarget;   // 0x000010 (0x000004) [Default: 1.24044e-23f]
        FName                       DistanceCurveName;  // 0x000014 (0x000004) [Default: NAME_None]
        FSequenceEvaluatorReference ReturnValue;        // 0x000018 (0x000010) [ReturnValue]
    };

    struct UAnimDistanceMatchingLibrary___SetPlayrateToMatchSpeed_Params
    {
        FSequencePlayerReference    SequencePlayer;                 // 0x000000 (0x000010) [OutParam]
        float                       SpeedToMatch;                   // 0x000010 (0x000004) [Default: 1.24044e-23f]
        uint8                       UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        FVector2D                   PlayRateClamp;                  // 0x000018 (0x000010)
        FSequencePlayerReference    ReturnValue;                    // 0x000028 (0x000010) [ReturnValue]
    };

} // namespace UE

