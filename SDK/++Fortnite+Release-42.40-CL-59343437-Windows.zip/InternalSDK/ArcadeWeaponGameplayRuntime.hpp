/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArcadeWeaponGameplayRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000290 (0x000030)
    class alignas(0x8) UFortArcadeWeaponAnimInstance : public UAnimInstance
    {
    public:
        FVector             LeftHandIKCorrection;           // 0x000260 (0x000018)
        float               LeftHandIKCorrectionAlpha;      // 0x000278 (0x000004) [Default: 0f]
        uint8               UnknownData_00027C[0x000004];   // 0x00027C (0x000004)
        AFortPlayerPawn*    FortPlayerPawn;                 // 0x000280 (0x000008) [Default: nullptr]
        uint8               UnknownData_000288[0x000008];   // 0x000288 (0x000008)
    };
    // Size: 0x000028 (0x000000)
    class UFortCheatManager_ArcadeWeaponPersistence : public UChildCheatManager
    {
    public:
    
    public: // Functions
        void    ClearHighScoreForAll(); // 0x0CA02B1A [Final | Exec | Native | Public]
        void    ClearMyHighScore(); // 0x0CA02B1A [Final | Exec | Native | Public]
    };
    // Size: 0x0001F0 (0x000128)
    class alignas(0x8) UFortControllerComponent_ArcadeWeaponLeaderboard : public UFortControllerComponent
    {
    public:
        MULTI_INLINE_DELEGATE(OnArcadeLeaderboardChanged)   OnLeaderboardModeChanged;       // 0x0000C8 (0x000010)
        MULTI_INLINE_DELEGATE(OnArcadeLeaderboardChanged)   OnFriendsLeaderboardChanged;    // 0x0000D8 (0x000010)
        MULTI_INLINE_DELEGATE(OnArcadeLeaderboardChanged)   OnGlobalLeaderboardChanged;     // 0x0000E8 (0x000010)
        TArray<FArcadeWeaponLeaderboardEntry>               RankedEntries;                  // 0x0000F8 (0x000010)
        TArray<FArcadeWeaponLeaderboardEntry>               RankedFriendsEntries;           // 0x000108 (0x000010)
        TArray<FArcadeWeaponLeaderboardEntry>               RankedGlobalEntries;            // 0x000118 (0x000010)
        uint8                                               UnknownData_000128[0x000090];   // 0x000128 (0x000090)
        void**                                              VTable_0001B8;                  // 0x0001B8 (0x000008) VTable [3 slots] -> 0x12F72C90
        uint8                                               UnknownData_0001C0[0x000030];   // 0x0001C0 (0x000030)
    
    public: // Functions
        EArcadeWeaponLeaderboardMode            GetActiveLeaderboardMode(); // 0x10C4A31C [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                                    GetEntryForPlayer(APlayerState* PlayerState, FArcadeWeaponLeaderboardEntry& OutEntry); // 0x07F3694C [Final | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        int32                                   GetLocalPlayerRank(); // 0x10C4A52C [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32                                   GetNumEntries(); // 0x0D24ECAE [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FArcadeWeaponLeaderboardEntry>   GetRankedEntries(); // 0x10C4A624 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FArcadeWeaponLeaderboardEntry>   GetRankedFriendsEntries(); // 0x10C4A680 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        TArray<FArcadeWeaponLeaderboardEntry>   GetRankedGlobalEntries(); // 0x10C4A6A0 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                                    HandleNewHighScore(int32 NewHighScore); // 0x07F36C6E [Final | Native | Private]
        void                                    HandleScoreDataChanged(FArcadeWeaponScoreData& ScoreData); // 0x07F36DD8 [Final | Native | Private | HasOutParms]
        bool                                    IsLeaderboardEnabled(); // 0x0CB033BC [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                                    PushGlobalScoreForPlayer(); // 0x0CA02B1A [Final | Native | Public | BlueprintCallable]
        void                                    RequestFriendsLeaderboard(EArcadeWeaponLeaderboardMode Mode); // 0x07F36F6C [Final | RequiredAPI | Native | Public | BlueprintCallable]
        void                                    RequestGlobalLeaderboard(EArcadeWeaponLeaderboardMode Mode); // 0x07F370D6 [Final | RequiredAPI | Native | Public | BlueprintCallable]
    };
    // Size: 0x000380 (0x0001F8)
    class alignas(0x8) UFortPlayerStateComponent_ArcadeWeaponPersistence : public UFortPlayerStateComponent_SaveFrameworkPersistence
    {
    public:
        MULTI_INLINE_DELEGATE(OnNewHighScore)       OnNewHighScore;                     // 0x000188 (0x000010)
        MULTI_INLINE_DELEGATE(OnScoreDataChanged)   OnScoreDataChanged;                 // 0x000198 (0x000010)
        int32                                       ReplicatedHighScoreBuild;           // 0x0001A8 (0x000004) [Default: 0]
        int32                                       ReplicatedHighScoreZeroBuild;       // 0x0001AC (0x000004) [Default: 0]
        FGameplayTagContainer                       LeaderboardDisabledPlaylistTags;    // 0x0001B0 (0x000020)
        FScalableFloat                              StreakThreshold;                    // 0x0001D0 (0x000028)
        FScalableFloat                              MaxSpriteStreakThreshold;           // 0x0001F8 (0x000028)
        FScalableFloat                              SpriteLevelComboScalarCurve;        // 0x000220 (0x000028)
        FGameplayTag                                RequiredSpriteTag;                  // 0x000248 (0x000004)
        uint8                                       UnknownData_00024C[0x000004];       // 0x00024C (0x000004)
        FFortCachedScalableFloat                    UseMinigameScore;                   // 0x000250 (0x000030)
        UClass*                                     MinigameScoreStatFilter;            // 0x000280 (0x000008) [Default: nullptr]
        FScalableFloat                              BotHighScoreAverageMultiplier;      // 0x000288 (0x000028)
        FScalableFloat                              BotHighScoreFallbackMax;            // 0x0002B0 (0x000028)
        uint8                                       UnknownData_0002D8[0x000050];       // 0x0002D8 (0x000050)
        FArcadeWeaponScoreData                      CurrentScoreData;                   // 0x000328 (0x000048)
        uint8                                       UnknownData_000370[0x000010];       // 0x000370 (0x000010)
    
    public: // Functions
        void                    ClearHighScore(); // 0x0CA02B1A [Final | BlueprintAuthorityOnly | Native | Public | BlueprintCallable]
        int32                   GetCumulativeScore(); // 0x0F883D8E [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FArcadeWeaponScoreData  GetCurrentScoreData(); // 0x10C4AF82 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32                   GetHighScore(); // 0x10C4AFC6 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32                   GetHighScoreForMode(EArcadeWeaponLeaderboardMode Mode); // 0x07F37240 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32                   GetStreak(); // 0x10C4AFEC [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                    HandlePlayerPersistenceAvailable(EFortSaveFrameworkPersistence_AvailableType AvailableType, FInstancedStruct& InPersistenceDataRoot); // 0x07F373B4 [Final | Native | Private | HasOutParms]
        bool                    IsUsingMinigameScore(); // 0x10C4B0AA [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                    OnMinigameScoreUpdate(); // 0x10C4B0D8 [Final | Native | Private]
        void                    OnRep_CurrentScoreData(); // 0x010C4602 [Final | Native | Protected]
        void                    OnRep_HighScoreBuild(int32 OldValue); // 0x07F37680 [Final | Native | Protected]
        void                    OnRep_HighScoreZeroBuild(int32 OldValue); // 0x07F377F2 [Final | Native | Protected]
        void                    ResetCombo(); // 0x10C4B1D6 [Final | BlueprintAuthorityOnly | Native | Public | BlueprintCallable]
        bool                    TrySetNewHighScore(int32 NewScore); // 0x07F37964 [Final | BlueprintAuthorityOnly | Native | Public | BlueprintCallable]
        void                    UpdateScoreAndStreak(FArcadeWeaponScoreData& InScoreData, FArcadeWeaponScoreData& OutScoreData); // 0x07F37AD8 [Final | BlueprintAuthorityOnly | Native | Public | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000100 (0x000040)
    class alignas(0x8) UFortWeaponComponent_ArcadeWeapon : public UFortWeaponComponent
    {
    public:
        void**                              VTable_0000C0;                  // 0x0000C0 (0x000008) VTable [3 slots] -> 0x146D6BD0
        TWeakObjectPtr<AFortWeaponRanged>   WeaponRef;                      // 0x0000C8 (0x000008) [Default: nullptr]
        TArray<FTrickShotConfig>            TrickShotConfigs;               // 0x0000D0 (0x000010)
        uint8                               UnknownData_0000E0[0x000020];   // 0x0000E0 (0x000020)
    
    public: // Functions
        FTrickShotConfig                                    CheckIfTrickShot(); // 0x10C4B91A [Native | Event | Protected | BlueprintCallable | BlueprintEvent | BlueprintPure | Const]
        UFortPlayerStateComponent_ArcadeWeaponPersistence*  GetArcadeWeaponPersistenceComponent(); // 0x10C4B994 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        FArcadeWeaponScoreData                              GetCurrentScoreData(); // 0x10C4BA18 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        AFortPlayerPawn*                                    GetPlayerPawn(); // 0x00DA0E60 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                                                OnScoreDataChanged(FArcadeWeaponScoreData& ScoreData); // 0x000545D2 [Event | Protected | HasOutParms | BlueprintEvent]
    };
    // Size: 0x000060 (0x000060)
    struct alignas(0x8) FArcadeWeaponLeaderboardEntry
    {
        FString             PlayerAccountId;                // 0x000000 (0x000010)
        FString             PlayerName;                     // 0x000010 (0x000010)
        int32               Highscore;                      // 0x000020 (0x000004)
        int32               CurrentMatchScore;              // 0x000024 (0x000004)
        int32               Rank;                           // 0x000028 (0x000004)
        bool                bIsLocalPlayer;                 // 0x00002C (0x000001)
        uint8               UnknownData_00002D[0x000003];   // 0x00002D (0x000003)
        FUniqueNetIdRepl    PlayerID;                       // 0x000030 (0x000030)
    };
    // Size: 0x000008 (0x000008)
    struct alignas(0x4) FArcadeWeaponPersistenceData
    {
        int32   HighScoreBuild;     // 0x000000 (0x000004)
        int32   HighScoreZeroBuild; // 0x000004 (0x000004)
    };
    // Size: 0x000048 (0x000048)
    struct alignas(0x8) FArcadeWeaponScoreData
    {
        int32                       Score;                  // 0x000000 (0x000004)
        int32                       Streak;                 // 0x000004 (0x000004)
        int32                       LastDamageAmount;       // 0x000008 (0x000004)
        int32                       LastScoreAmount;        // 0x00000C (0x000004)
        TWeakObjectPtr<AFortPawn>   LastDamagedFortPawn;    // 0x000010 (0x000008)
        FTrickShotConfig            TrickShotData;          // 0x000018 (0x000030)
    };
    // Size: 0x000030 (0x000030)
    struct alignas(0x8) FTrickShotConfig
    {
        ETrickShotType  Type;                           // 0x000000 (0x000001)
        uint8           UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        FGameplayTag    Tag;                            // 0x000004 (0x000004)
        FScalableFloat  Points;                         // 0x000008 (0x000028)
    };
}

