/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BattleRoyaleGameUI_Functions
 * ============================================================
 */

#include "BattleRoyaleGameUI_Functions.hpp"

namespace UE
{

    void UBattleRoyaleQuickbarViewModel::HandleSimpleBuildToggled(bool bIsEnabled)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleRoyaleGameUI.BattleRoyaleQuickbarViewModel.HandleSimpleBuildToggled");
    
        UBattleRoyaleQuickbarViewModel___HandleSimpleBuildToggled_Params Params{};
        Params.bIsEnabled = bIsEnabled;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    EFortRarity UInstituteChirpEquippedItemViewModel::GetRarity()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleRoyaleGameUI.InstituteChirpEquippedItemViewModel.GetRarity");
    
        UInstituteChirpEquippedItemViewModel___GetRarity_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UInstituteChirpGadgetFuelViewModel::InitializePlayerController(APlayerController* OwningPlayerController)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleRoyaleGameUI.InstituteChirpGadgetFuelViewModel.InitializePlayerController");
    
        UInstituteChirpGadgetFuelViewModel___InitializePlayerController_Params Params{};
        Params.OwningPlayerController = OwningPlayerController;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UInstituteChirpGadgetFuelViewModel::SetFortItem(UFortItem* InItem)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleRoyaleGameUI.InstituteChirpGadgetFuelViewModel.SetFortItem");
    
        UInstituteChirpGadgetFuelViewModel___SetFortItem_Params Params{};
        Params.InItem = InItem;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    int32 UInstituteChirpQuickbarSlotViewModel::GetNumberOfSlotsTaken()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleRoyaleGameUI.InstituteChirpQuickbarSlotViewModel.GetNumberOfSlotsTaken");
    
        UInstituteChirpQuickbarSlotViewModel___GetNumberOfSlotsTaken_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    EFortRarity UInstituteChirpQuickbarSlotViewModel::GetRarity()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleRoyaleGameUI.InstituteChirpQuickbarSlotViewModel.GetRarity");
    
        UInstituteChirpQuickbarSlotViewModel___GetRarity_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UInstituteChirpQuickbarSlotViewModel::InitializeWithType(APlayerController* InPlayerController, EFortQuickBars InQuickBarType, int32 InSlot)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleRoyaleGameUI.InstituteChirpQuickbarSlotViewModel.InitializeWithType");
    
        UInstituteChirpQuickbarSlotViewModel___InitializeWithType_Params Params{};
        Params.InPlayerController = InPlayerController;
        Params.InQuickBarType = InQuickBarType;
        Params.InSlot = InSlot;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UQuickbarGizmoSlotVM::HandleQuickbarContentsChanged(EFortQuickBars QuickBarIndex, TArray<int32>& ChangedSlots)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleRoyaleGameUI.QuickbarGizmoSlotVM.HandleQuickbarContentsChanged");
    
        UQuickbarGizmoSlotVM___HandleQuickbarContentsChanged_Params Params{};
        Params.QuickBarIndex = QuickBarIndex;
        Params.ChangedSlots = ChangedSlots;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ChangedSlots = Params.ChangedSlots;
    }

    void UQuickbarGizmoSlotVM::HandleQuickbarFullUpdate(EFortQuickBars QuickBarIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleRoyaleGameUI.QuickbarGizmoSlotVM.HandleQuickbarFullUpdate");
    
        UQuickbarGizmoSlotVM___HandleQuickbarFullUpdate_Params Params{};
        Params.QuickBarIndex = QuickBarIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UQuickbarGizmoSlotVM::HandleQuickBarSlotFocusChanged(EFortQuickBars QuickBarIndex, int32 FocusedSlotIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BattleRoyaleGameUI.QuickbarGizmoSlotVM.HandleQuickBarSlotFocusChanged");
    
        UQuickbarGizmoSlotVM___HandleQuickBarSlotFocusChanged_Params Params{};
        Params.QuickBarIndex = QuickBarIndex;
        Params.FocusedSlotIndex = FocusedSlotIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

