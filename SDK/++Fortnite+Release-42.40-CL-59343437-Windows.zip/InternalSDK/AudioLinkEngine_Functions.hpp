/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:10
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioLinkEngine_Functions
 * ============================================================
 */

#include "AudioLinkEngine.hpp"

namespace UE
{

    struct IAudioLinkBlueprintInterface___IsLinkPlaying_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct IAudioLinkBlueprintInterface___PlayLink_Params
    {
        float   StartTime;  // 0x000000 (0x000004) [Default: 1.5821e-27f]
    };

    struct IAudioLinkBlueprintInterface___SetLinkSound_Params
    {
        USoundBase* NewSound;   // 0x000000 (0x000008) [Default: 0x12FAB170]
    };

} // namespace UE

