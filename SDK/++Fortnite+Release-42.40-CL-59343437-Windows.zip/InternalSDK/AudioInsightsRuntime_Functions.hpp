/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioInsightsRuntime_Functions
 * ============================================================
 */

#include "AudioInsightsRuntime.hpp"

namespace UE
{

    struct UAudioInsightsBlueprintLibrary___LogAudioInsightsEvent_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        FString     EventName;          // 0x000008 (0x000010) [Default: L""]
        USoundBase* SoundAsset;         // 0x000018 (0x000008) [Default: 0x197BC670]
        AActor*     Actor;              // 0x000020 (0x000008) [Default: 0xA60D8DBB]
    };

    struct UAudioInsightsBlueprintLibrary___LogAudioInsightsEventForAudioComponent_Params
    {
        UObject*            WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        FString             EventName;          // 0x000008 (0x000010) [Default: L""]
        UAudioComponent*    AudioComponent;     // 0x000018 (0x000008) [Default: 0x197BC670]
    };

} // namespace UE

