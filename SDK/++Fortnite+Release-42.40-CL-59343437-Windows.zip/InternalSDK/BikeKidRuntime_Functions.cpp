/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BikeKidRuntime_Functions
 * ============================================================
 */

#include "BikeKidRuntime_Functions.hpp"

namespace UE
{

    void AFortAthenaMutator_BikeKid::OnViewTargetChanged(AFortPlayerController* PlayerController, AActor* OldViewTarget, AActor* NewViewTarget)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortAthenaMutator_BikeKid.OnViewTargetChanged");
    
        AFortAthenaMutator_BikeKid___OnViewTargetChanged_Params Params{};
        Params.PlayerController = PlayerController;
        Params.OldViewTarget = OldViewTarget;
        Params.NewViewTarget = NewViewTarget;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AFortBikeKid::BP_OnBikeKidDismissed(FGameplayTag& DismissalReason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.BP_OnBikeKidDismissed");
    
        AFortBikeKid___BP_OnBikeKidDismissed_Params Params{};
        Params.DismissalReason = DismissalReason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        DismissalReason = Params.DismissalReason;
    }

    void AFortBikeKid::BP_OnBikeKidLaunched()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.BP_OnBikeKidLaunched");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AFortBikeKid::BP_OnDestructionStarted()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.BP_OnDestructionStarted");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AFortBikeKid::GameplayCue_Damage(TEnumAsByte<EGameplayCueEvent> EventType, FGameplayCueParameters Parameters)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.GameplayCue_Damage");
    
        AFortBikeKid___GameplayCue_Damage_Params Params{};
        Params.EventType = EventType;
        Params.Parameters = Parameters;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    UFortBikeKidMovementComponent* AFortBikeKid::GetBikeKidMovementComponent()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.GetBikeKidMovementComponent");
    
        AFortBikeKid___GetBikeKidMovementComponent_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    AFortPawn* AFortBikeKid::GetControllingPlayerPawn()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.GetControllingPlayerPawn");
    
        AFortBikeKid___GetControllingPlayerPawn_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FRotator AFortBikeKid::GetDeltaRotator()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.GetDeltaRotator");
    
        AFortBikeKid___GetDeltaRotator_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void AFortBikeKid::GetForwardAndRightDotProducts_Native(float& OutForwardDot, float& OutRightDot)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.GetForwardAndRightDotProducts_Native");
    
        AFortBikeKid___GetForwardAndRightDotProducts_Native_Params Params{};
        Params.OutForwardDot = OutForwardDot;
        Params.OutRightDot = OutRightDot;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutForwardDot = Params.OutForwardDot;
        OutRightDot = Params.OutRightDot;
    }

    float AFortBikeKid::GetHealthPercentage()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.GetHealthPercentage");
    
        AFortBikeKid___GetHealthPercentage_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float AFortBikeKid::GetLaunchDelayRemaining()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.GetLaunchDelayRemaining");
    
        AFortBikeKid___GetLaunchDelayRemaining_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool AFortBikeKid::IsInLaunchDelay()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.IsInLaunchDelay");
    
        AFortBikeKid___IsInLaunchDelay_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void AFortBikeKid::OnCapsuleComponentHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, FHitResult& Hit)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.OnCapsuleComponentHit");
    
        AFortBikeKid___OnCapsuleComponentHit_Params Params{};
        Params.HitComponent = HitComponent;
        Params.OtherActor = OtherActor;
        Params.OtherComp = OtherComp;
        Params.NormalImpulse = NormalImpulse;
        Params.Hit = Hit;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Hit = Params.Hit;
    }

    void AFortBikeKid::OnDamagePlayEffects(float Damage, FGameplayTagContainer& DamageTags, FVector Momentum, FHitResult& HitInfo, AFortPawn* InstigatedBy, AActor* DamageCauser, FGameplayEffectContextHandle EffectContext)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.OnDamagePlayEffects");
    
        AFortBikeKid___OnDamagePlayEffects_Params Params{};
        Params.Damage = Damage;
        Params.DamageTags = DamageTags;
        Params.Momentum = Momentum;
        Params.HitInfo = HitInfo;
        Params.InstigatedBy = InstigatedBy;
        Params.DamageCauser = DamageCauser;
        Params.EffectContext = EffectContext;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        DamageTags = Params.DamageTags;
        HitInfo = Params.HitInfo;
    }

    void AFortBikeKid::OnDeathPlayEffects(float Damage, FGameplayTagContainer& DamageTags, FVector Momentum, FHitResult& HitInfo, AFortPawn* InstigatedBy, AActor* DamageCauser, FGameplayEffectContextHandle EffectContext)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.OnDeathPlayEffects");
    
        AFortBikeKid___OnDeathPlayEffects_Params Params{};
        Params.Damage = Damage;
        Params.DamageTags = DamageTags;
        Params.Momentum = Momentum;
        Params.HitInfo = HitInfo;
        Params.InstigatedBy = InstigatedBy;
        Params.DamageCauser = DamageCauser;
        Params.EffectContext = EffectContext;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        DamageTags = Params.DamageTags;
        HitInfo = Params.HitInfo;
    }

    void AFortBikeKid::OnRep_bExploded()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.OnRep_bExploded");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AFortBikeKid::OnRep_ControllingPlayerPawn(AFortPawn* OldPawn)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.OnRep_ControllingPlayerPawn");
    
        AFortBikeKid___OnRep_ControllingPlayerPawn_Params Params{};
        Params.OldPawn = OldPawn;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AFortBikeKid::OnRotationInputReceived(FRotator& RotationInput)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.OnRotationInputReceived");
    
        AFortBikeKid___OnRotationInputReceived_Params Params{};
        Params.RotationInput = RotationInput;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        RotationInput = Params.RotationInput;
    }

    void AFortBikeKid::SetAffiliationAudio()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.SetAffiliationAudio");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void AFortBikeKid::SetTeamMatesIndicator(bool bState)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.SetTeamMatesIndicator");
    
        AFortBikeKid___SetTeamMatesIndicator_Params Params{};
        Params.bState = bState;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void AFortBikeKid::SetupGameplayAudioParameters()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKid.SetupGameplayAudioParameters");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortBikeKidControllingComponent::BP_OnBikeKidDestroyed(FGameplayTag& DismissalReason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.BP_OnBikeKidDestroyed");
    
        UFortBikeKidControllingComponent___BP_OnBikeKidDestroyed_Params Params{};
        Params.DismissalReason = DismissalReason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        DismissalReason = Params.DismissalReason;
    }

    void UFortBikeKidControllingComponent::BP_OnDestructionStarted(bool bInstantDestruction, FGameplayTag DismissalReason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.BP_OnDestructionStarted");
    
        UFortBikeKidControllingComponent___BP_OnDestructionStarted_Params Params{};
        Params.bInstantDestruction = bInstantDestruction;
        Params.DismissalReason = DismissalReason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortBikeKidControllingComponent::BP_OnDismissal(FGameplayTag DismissalReason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.BP_OnDismissal");
    
        UFortBikeKidControllingComponent___BP_OnDismissal_Params Params{};
        Params.DismissalReason = DismissalReason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortBikeKidControllingComponent::BP_StartedControlling(AFortBikeKid* InBikeKid)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.BP_StartedControlling");
    
        UFortBikeKidControllingComponent___BP_StartedControlling_Params Params{};
        Params.InBikeKid = InBikeKid;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortBikeKidControllingComponent::ClampRotationInput(FRotator& InOutRotationInput)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.ClampRotationInput");
    
        UFortBikeKidControllingComponent___ClampRotationInput_Params Params{};
        Params.InOutRotationInput = InOutRotationInput;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InOutRotationInput = Params.InOutRotationInput;
    }

    AFortBikeKid* UFortBikeKidControllingComponent::GetControlledBikeKid()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.GetControlledBikeKid");
    
        UFortBikeKidControllingComponent___GetControlledBikeKid_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortBikeKidControllingComponent::NotifyClientBikeKidDestruction(FGameplayTag DestructionReason)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.NotifyClientBikeKidDestruction");
    
        UFortBikeKidControllingComponent___NotifyClientBikeKidDestruction_Params Params{};
        Params.DestructionReason = DestructionReason;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortBikeKidControllingComponent::NotifyClientStopControlling()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.NotifyClientStopControlling");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortBikeKidControllingComponent::OnControlledBikeClientDismiss()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.OnControlledBikeClientDismiss");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortBikeKidControllingComponent::OnLaunched()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.OnLaunched");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortBikeKidControllingComponent::OnOwningPlayerStartedDBNO()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.OnOwningPlayerStartedDBNO");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortBikeKidControllingComponent::OnPlayerInterruptionTagsChanged(FGameplayTag Tag, int32 NewCount)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.OnPlayerInterruptionTagsChanged");
    
        UFortBikeKidControllingComponent___OnPlayerInterruptionTagsChanged_Params Params{};
        Params.Tag = Tag;
        Params.NewCount = NewCount;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortBikeKidControllingComponent::OnRep_ControlledBikeKid()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.OnRep_ControlledBikeKid");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortBikeKidControllingComponent::OnWeaponEquipped(AFortWeapon* NewWeapon, AFortWeapon* PrevWeapon)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.OnWeaponEquipped");
    
        UFortBikeKidControllingComponent___OnWeaponEquipped_Params Params{};
        Params.NewWeapon = NewWeapon;
        Params.PrevWeapon = PrevWeapon;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortBikeKidControllingComponent::PlayerInputMassageAxis(float& InOutNewVal, UFortPlayerInput* PlayerInput, FKey& Key, float DeltaTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.PlayerInputMassageAxis");
    
        UFortBikeKidControllingComponent___PlayerInputMassageAxis_Params Params{};
        Params.InOutNewVal = InOutNewVal;
        Params.PlayerInput = PlayerInput;
        Params.Key = Key;
        Params.DeltaTime = DeltaTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InOutNewVal = Params.InOutNewVal;
        Key = Params.Key;
    }

    void UFortBikeKidControllingComponent::PlayerInputMassageVectorAxis(FVector& InOutNewVal, UFortPlayerInput* PlayerInput, FKey& Key, float DeltaTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.PlayerInputMassageVectorAxis");
    
        UFortBikeKidControllingComponent___PlayerInputMassageVectorAxis_Params Params{};
        Params.InOutNewVal = InOutNewVal;
        Params.PlayerInput = PlayerInput;
        Params.Key = Key;
        Params.DeltaTime = DeltaTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InOutNewVal = Params.InOutNewVal;
        Key = Params.Key;
    }

    void UFortBikeKidControllingComponent::PlayerInputOverrideGamepadLookRates(FRotator& InOutLookRatesBase, FRotator& InOutLookRatesFinal, UFortPlayerInput* PlayerInput, float DeltaTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.PlayerInputOverrideGamepadLookRates");
    
        UFortBikeKidControllingComponent___PlayerInputOverrideGamepadLookRates_Params Params{};
        Params.InOutLookRatesBase = InOutLookRatesBase;
        Params.InOutLookRatesFinal = InOutLookRatesFinal;
        Params.PlayerInput = PlayerInput;
        Params.DeltaTime = DeltaTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InOutLookRatesBase = Params.InOutLookRatesBase;
        InOutLookRatesFinal = Params.InOutLookRatesFinal;
    }

    void UFortBikeKidControllingComponent::PlayerInputOverrideTouchLookAccelerationMultiplier(float& InOutMultiplier, UFortPlayerInput* PlayerInput)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.PlayerInputOverrideTouchLookAccelerationMultiplier");
    
        UFortBikeKidControllingComponent___PlayerInputOverrideTouchLookAccelerationMultiplier_Params Params{};
        Params.InOutMultiplier = InOutMultiplier;
        Params.PlayerInput = PlayerInput;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InOutMultiplier = Params.InOutMultiplier;
    }

    void UFortBikeKidControllingComponent::PlayerInputProcessTouch(float& InOutLookYawDelta, float& InOutLookPitchDelta, UFortPlayerInput* PlayerInput, FVector2D& TouchLookInput, float DeltaTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.PlayerInputProcessTouch");
    
        UFortBikeKidControllingComponent___PlayerInputProcessTouch_Params Params{};
        Params.InOutLookYawDelta = InOutLookYawDelta;
        Params.InOutLookPitchDelta = InOutLookPitchDelta;
        Params.PlayerInput = PlayerInput;
        Params.TouchLookInput = TouchLookInput;
        Params.DeltaTime = DeltaTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InOutLookYawDelta = Params.InOutLookYawDelta;
        InOutLookPitchDelta = Params.InOutLookPitchDelta;
        TouchLookInput = Params.TouchLookInput;
    }

    void UFortBikeKidControllingComponent::ServerRequestBikeKidDismissal()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.ServerRequestBikeKidDismissal");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortBikeKidControllingComponent::StartControllingBikeKid(AFortBikeKid* BikeKidToControl)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.StartControllingBikeKid");
    
        UFortBikeKidControllingComponent___StartControllingBikeKid_Params Params{};
        Params.BikeKidToControl = BikeKidToControl;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortBikeKidControllingComponent::TryToStopControllingBikeKid(FBikeKidDismissalData& DeferredDestroyData)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidControllingComponent.TryToStopControllingBikeKid");
    
        UFortBikeKidControllingComponent___TryToStopControllingBikeKid_Params Params{};
        Params.DeferredDestroyData = DeferredDestroyData;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        DeferredDestroyData = Params.DeferredDestroyData;
    }

    void UFortBikeKidMovementComponent::SetHitBoxComponent(UBoxComponent* HitBox)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortBikeKidMovementComponent.SetHitBoxComponent");
    
        UFortBikeKidMovementComponent___SetHitBoxComponent_Params Params{};
        Params.HitBox = HitBox;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortChargingSet_BikeKidEnergy::OnRep_Energy(FFortGameplayAttributeData& OldValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortChargingSet_BikeKidEnergy.OnRep_Energy");
    
        UFortChargingSet_BikeKidEnergy___OnRep_Energy_Params Params{};
        Params.OldValue = OldValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OldValue = Params.OldValue;
    }

    AFortBikeKid* UFortGameplayAbility_BikeKid_Dismiss::GetControlledBikeKid()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortGameplayAbility_BikeKid_Dismiss.GetControlledBikeKid");
    
        UFortGameplayAbility_BikeKid_Dismiss___GetControlledBikeKid_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UFortGameplayAbility_BikeKid_MarkPotentialTargets::OnStartHighlightingTarget(AActor* Target)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortGameplayAbility_BikeKid_MarkPotentialTargets.OnStartHighlightingTarget");
    
        UFortGameplayAbility_BikeKid_MarkPotentialTargets___OnStartHighlightingTarget_Params Params{};
        Params.Target = Target;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortGameplayAbility_BikeKid_MarkPotentialTargets::OnStoppedHighlightingTarget(AActor* Target)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortGameplayAbility_BikeKid_MarkPotentialTargets.OnStoppedHighlightingTarget");
    
        UFortGameplayAbility_BikeKid_MarkPotentialTargets___OnStoppedHighlightingTarget_Params Params{};
        Params.Target = Target;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortGameplayAbility_BikeKid_PassiveMark::BP_OnTargetStatusChanged(AActor* ActiveTarget)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortGameplayAbility_BikeKid_PassiveMark.BP_OnTargetStatusChanged");
    
        UFortGameplayAbility_BikeKid_PassiveMark___BP_OnTargetStatusChanged_Params Params{};
        Params.ActiveTarget = ActiveTarget;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortGameplayAbility_BikeKid_PassiveMark::OnActorIndicatorExpired(AActor* IndicatedActor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortGameplayAbility_BikeKid_PassiveMark.OnActorIndicatorExpired");
    
        UFortGameplayAbility_BikeKid_PassiveMark___OnActorIndicatorExpired_Params Params{};
        Params.IndicatedActor = IndicatedActor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UFortGameplayAbility_BikeKid_PassiveMark::OnRep_CurrentTargetStatus()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortGameplayAbility_BikeKid_PassiveMark.OnRep_CurrentTargetStatus");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortGameplayAbility_BikeKid_SpeedBoost::OnBoostedIntoActor(FHitResult& HitResult)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortGameplayAbility_BikeKid_SpeedBoost.OnBoostedIntoActor");
    
        UFortGameplayAbility_BikeKid_SpeedBoost___OnBoostedIntoActor_Params Params{};
        Params.HitResult = HitResult;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        HitResult = Params.HitResult;
    }

    void UFortGameplayAbility_BikeKid_SpeedBoost::OnDoorBashed(FHitResult& HitResult, UFortBuildingWallDoorComponent* BashedDoor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortGameplayAbility_BikeKid_SpeedBoost.OnDoorBashed");
    
        UFortGameplayAbility_BikeKid_SpeedBoost___OnDoorBashed_Params Params{};
        Params.HitResult = HitResult;
        Params.BashedDoor = BashedDoor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        HitResult = Params.HitResult;
    }

    void UFortGameplayAbility_BikeKid_TargetingBase::BP_OnTargetsFound(FTargetingRequestHandle& TargetingHandle)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortGameplayAbility_BikeKid_TargetingBase.BP_OnTargetsFound");
    
        UFortGameplayAbility_BikeKid_TargetingBase___BP_OnTargetsFound_Params Params{};
        Params.TargetingHandle = TargetingHandle;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        TargetingHandle = Params.TargetingHandle;
    }

    void UFortGameplayAbility_BikeKid_TargetingBase::StartTargeting()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortGameplayAbility_BikeKid_TargetingBase.StartTargeting");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortGameplayAbility_BikeKid_TargetingBase::StopTargeting()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortGameplayAbility_BikeKid_TargetingBase.StopTargeting");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortGameplayAbility_BikeKid_Tether::StartCheckingDistances()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortGameplayAbility_BikeKid_Tether.StartCheckingDistances");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UFortGameplayAbility_BikeKid_Tether::StopCheckingDistances()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BikeKidRuntime.FortGameplayAbility_BikeKid_Tether.StopCheckingDistances");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

} // namespace UE

