/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:50
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeanstalkCosmetics/BP_BeanCosmeticMaterialsLibrary_Functions
 * ============================================================
 */

#include "BP_BeanCosmeticMaterialsLibrary_Functions.hpp"

namespace UE
{

    void UBP_BeanCosmeticMaterialsLibrary_C::GetColorFromIndex(UDataTable* DT_Colors, int32 Index, UObject* __WorldContext, FLinearColor& Color, bool& ColorFoundInDT, FString CallFunc_Conv_IntToString_ReturnValue, FName CallFunc_Conv_StringToName_ReturnValue, FAtomColorInfo CallFunc_GetDataTableRowFromName_OutRow, bool CallFunc_GetDataTableRowFromName_ReturnValue, FLinearColor CallFunc_Conv_ColorToLinearColor_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BeanCosmeticMaterialsLibrary.BP_BeanCosmeticMaterialsLibrary_C.GetColorFromIndex");
    
        UBP_BeanCosmeticMaterialsLibrary_C___GetColorFromIndex_Params Params{};
        Params.DT_Colors = DT_Colors;
        Params.Index = Index;
        Params.__WorldContext = __WorldContext;
        Params.Color = Color;
        Params.ColorFoundInDT = ColorFoundInDT;
        Params.CallFunc_Conv_IntToString_ReturnValue = CallFunc_Conv_IntToString_ReturnValue;
        Params.CallFunc_Conv_StringToName_ReturnValue = CallFunc_Conv_StringToName_ReturnValue;
        Params.CallFunc_GetDataTableRowFromName_OutRow = CallFunc_GetDataTableRowFromName_OutRow;
        Params.CallFunc_GetDataTableRowFromName_ReturnValue = CallFunc_GetDataTableRowFromName_ReturnValue;
        Params.CallFunc_Conv_ColorToLinearColor_ReturnValue = CallFunc_Conv_ColorToLinearColor_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Color = Params.Color;
        ColorFoundInDT = Params.ColorFoundInDT;
    }

    void UBP_BeanCosmeticMaterialsLibrary_C::GetMaterialValuesFromDT(UDataTable* DT_Materials, int32 RowNameToFind, UObject* __WorldContext, FBeanstalkCosmetics_MaterialTypeInfo& MaterialType, FString CallFunc_Conv_IntToString_ReturnValue, FName CallFunc_Conv_StringToName_ReturnValue, FBeanstalkCosmetics_MaterialTypeInfo CallFunc_GetDataTableRowFromName_OutRow, bool CallFunc_GetDataTableRowFromName_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BeanCosmeticMaterialsLibrary.BP_BeanCosmeticMaterialsLibrary_C.GetMaterialValuesFromDT");
    
        UBP_BeanCosmeticMaterialsLibrary_C___GetMaterialValuesFromDT_Params Params{};
        Params.DT_Materials = DT_Materials;
        Params.RowNameToFind = RowNameToFind;
        Params.__WorldContext = __WorldContext;
        Params.MaterialType = MaterialType;
        Params.CallFunc_Conv_IntToString_ReturnValue = CallFunc_Conv_IntToString_ReturnValue;
        Params.CallFunc_Conv_StringToName_ReturnValue = CallFunc_Conv_StringToName_ReturnValue;
        Params.CallFunc_GetDataTableRowFromName_OutRow = CallFunc_GetDataTableRowFromName_OutRow;
        Params.CallFunc_GetDataTableRowFromName_ReturnValue = CallFunc_GetDataTableRowFromName_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        MaterialType = Params.MaterialType;
    }

    void UBP_BeanCosmeticMaterialsLibrary_C::MergeMaterialPropsIntoMaterial(UMaterialInstanceDynamic* Material, FName ParameterName, UDataTable* DT_Materials, int32 MaterialIndexFromDT, UObject* __WorldContext, FBeanstalkCosmetics_MaterialTypeInfo CallFunc_GetMaterialValuesFromDT_MaterialType, FLinearColor CallFunc_MakeColor_ReturnValue, float CallFunc_MakeColor_R_ImplicitCast, float CallFunc_MakeColor_G_ImplicitCast, float CallFunc_MakeColor_B_ImplicitCast)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BeanCosmeticMaterialsLibrary.BP_BeanCosmeticMaterialsLibrary_C.MergeMaterialPropsIntoMaterial");
    
        UBP_BeanCosmeticMaterialsLibrary_C___MergeMaterialPropsIntoMaterial_Params Params{};
        Params.Material = Material;
        Params.ParameterName = ParameterName;
        Params.DT_Materials = DT_Materials;
        Params.MaterialIndexFromDT = MaterialIndexFromDT;
        Params.__WorldContext = __WorldContext;
        Params.CallFunc_GetMaterialValuesFromDT_MaterialType = CallFunc_GetMaterialValuesFromDT_MaterialType;
        Params.CallFunc_MakeColor_ReturnValue = CallFunc_MakeColor_ReturnValue;
        Params.CallFunc_MakeColor_R_ImplicitCast = CallFunc_MakeColor_R_ImplicitCast;
        Params.CallFunc_MakeColor_G_ImplicitCast = CallFunc_MakeColor_G_ImplicitCast;
        Params.CallFunc_MakeColor_B_ImplicitCast = CallFunc_MakeColor_B_ImplicitCast;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_BeanCosmeticMaterialsLibrary_C::SetColorMaterialParameterFromIndex(UMaterialInstanceDynamic* Material, FName ParameterName, UDataTable* DT_Colors, int32 ColorIndexFromDT, UObject* __WorldContext, FLinearColor CallFunc_GetColorFromIndex_Color, bool CallFunc_GetColorFromIndex_ColorFoundInDT)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BeanCosmeticMaterialsLibrary.BP_BeanCosmeticMaterialsLibrary_C.SetColorMaterialParameterFromIndex");
    
        UBP_BeanCosmeticMaterialsLibrary_C___SetColorMaterialParameterFromIndex_Params Params{};
        Params.Material = Material;
        Params.ParameterName = ParameterName;
        Params.DT_Colors = DT_Colors;
        Params.ColorIndexFromDT = ColorIndexFromDT;
        Params.__WorldContext = __WorldContext;
        Params.CallFunc_GetColorFromIndex_Color = CallFunc_GetColorFromIndex_Color;
        Params.CallFunc_GetColorFromIndex_ColorFoundInDT = CallFunc_GetColorFromIndex_ColorFoundInDT;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_BeanCosmeticMaterialsLibrary_C::SetMaterialUvPatternPositionFromTextureSlot(UMaterialInstanceDynamic* Material, FName ParameterName, int32 TextureSlot, UDataTable* DT_PatternAtlasTextureSlots, UObject* __WorldContext, FString CallFunc_Conv_IntToString_ReturnValue, FName CallFunc_Conv_StringToName_ReturnValue, FBeanstalkCosmetics_PatternAtlasTextureSlotsInfo CallFunc_GetDataTableRowFromName_OutRow, bool CallFunc_GetDataTableRowFromName_ReturnValue, FLinearColor CallFunc_Conv_VectorToLinearColor_ReturnValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BeanCosmeticMaterialsLibrary.BP_BeanCosmeticMaterialsLibrary_C.SetMaterialUvPatternPositionFromTextureSlot");
    
        UBP_BeanCosmeticMaterialsLibrary_C___SetMaterialUvPatternPositionFromTextureSlot_Params Params{};
        Params.Material = Material;
        Params.ParameterName = ParameterName;
        Params.TextureSlot = TextureSlot;
        Params.DT_PatternAtlasTextureSlots = DT_PatternAtlasTextureSlots;
        Params.__WorldContext = __WorldContext;
        Params.CallFunc_Conv_IntToString_ReturnValue = CallFunc_Conv_IntToString_ReturnValue;
        Params.CallFunc_Conv_StringToName_ReturnValue = CallFunc_Conv_StringToName_ReturnValue;
        Params.CallFunc_GetDataTableRowFromName_OutRow = CallFunc_GetDataTableRowFromName_OutRow;
        Params.CallFunc_GetDataTableRowFromName_ReturnValue = CallFunc_GetDataTableRowFromName_ReturnValue;
        Params.CallFunc_Conv_VectorToLinearColor_ReturnValue = CallFunc_Conv_VectorToLinearColor_ReturnValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UBP_BeanCosmeticMaterialsLibrary_C::Update_Character_Material(UBeanCosmeticItemDefinitionBase* BeanCD, UMaterialInstanceDynamic* BodyMaterial, UMaterialInstanceDynamic* CostumeBodyMaterial, UMaterialInstanceDynamic* CostumeHeadMaterial, UDataTable* DT_Colors, UDataTable* DT_Materials, UDataTable* DT_PatternAtlasTextureSlots, UDataTable* DT_Roughness, UObject* __WorldContext, UDataTable* DT_MaterialTypes, double GlobalEmissiveValue, double GlobalMetallicValue, UMaterialInstanceDynamic* Head_Costume_Material, UMaterialInstanceDynamic* Bean_Costume_Material, UMaterialInstanceDynamic* Bean_Body_Material, UBeanCosmeticItemDefinitionBase* CurrentBeanCID, double CallFunc_Conv_BoolToDouble_ReturnValue, double CallFunc_Conv_BoolToDouble_ReturnValue_1, double CallFunc_Conv_BoolToDouble_ReturnValue_2, FLinearColor CallFunc_MakeColor_ReturnValue, UObject* CallFunc_LoadAsset_Blocking_ReturnValue, UTexture2D* K2Node_DynamicCast_AsTexture_2D, bool K2Node_DynamicCast_bSuccess, float CallFunc_MakeColor_B_ImplicitCast, float CallFunc_MakeColor_G_ImplicitCast, float CallFunc_MakeColor_R_ImplicitCast)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_BeanCosmeticMaterialsLibrary.BP_BeanCosmeticMaterialsLibrary_C.Update_Character_Material");
    
        UBP_BeanCosmeticMaterialsLibrary_C___Update_Character_Material_Params Params{};
        Params.BeanCD = BeanCD;
        Params.BodyMaterial = BodyMaterial;
        Params.CostumeBodyMaterial = CostumeBodyMaterial;
        Params.CostumeHeadMaterial = CostumeHeadMaterial;
        Params.DT_Colors = DT_Colors;
        Params.DT_Materials = DT_Materials;
        Params.DT_PatternAtlasTextureSlots = DT_PatternAtlasTextureSlots;
        Params.DT_Roughness = DT_Roughness;
        Params.__WorldContext = __WorldContext;
        Params.DT_MaterialTypes = DT_MaterialTypes;
        Params.GlobalEmissiveValue = GlobalEmissiveValue;
        Params.GlobalMetallicValue = GlobalMetallicValue;
        Params.Head_Costume_Material = Head_Costume_Material;
        Params.Bean_Costume_Material = Bean_Costume_Material;
        Params.Bean_Body_Material = Bean_Body_Material;
        Params.CurrentBeanCID = CurrentBeanCID;
        Params.CallFunc_Conv_BoolToDouble_ReturnValue = CallFunc_Conv_BoolToDouble_ReturnValue;
        Params.CallFunc_Conv_BoolToDouble_ReturnValue_1 = CallFunc_Conv_BoolToDouble_ReturnValue_1;
        Params.CallFunc_Conv_BoolToDouble_ReturnValue_2 = CallFunc_Conv_BoolToDouble_ReturnValue_2;
        Params.CallFunc_MakeColor_ReturnValue = CallFunc_MakeColor_ReturnValue;
        Params.CallFunc_LoadAsset_Blocking_ReturnValue = CallFunc_LoadAsset_Blocking_ReturnValue;
        Params.K2Node_DynamicCast_AsTexture_2D = K2Node_DynamicCast_AsTexture_2D;
        Params.K2Node_DynamicCast_bSuccess = K2Node_DynamicCast_bSuccess;
        Params.CallFunc_MakeColor_B_ImplicitCast = CallFunc_MakeColor_B_ImplicitCast;
        Params.CallFunc_MakeColor_G_ImplicitCast = CallFunc_MakeColor_G_ImplicitCast;
        Params.CallFunc_MakeColor_R_ImplicitCast = CallFunc_MakeColor_R_ImplicitCast;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

