/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:50
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeanstalkCosmetics/CosmeticSteps/BP_FortCosmeticStep_ApplyBeanCD_Functions
 * ============================================================
 */

#include "BP_FortCosmeticStep_ApplyBeanCD_Functions.hpp"

namespace UE
{

    void UBP_FortCosmeticStep_ApplyBeanCD_C::BP_UpdateCosmeticMaterials(UBeanCosmeticItemDefinitionBase* BeanCD, UMaterialInstanceDynamic* MaterialBody, UMaterialInstanceDynamic* MaterialCostume, UMaterialInstanceDynamic* MaterialHead)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("BP_FortCosmeticStep_ApplyBeanCD.BP_FortCosmeticStep_ApplyBeanCD_C.BP_UpdateCosmeticMaterials");
    
        UBP_FortCosmeticStep_ApplyBeanCD_C___BP_UpdateCosmeticMaterials_Params Params{};
        Params.BeanCD = BeanCD;
        Params.MaterialBody = MaterialBody;
        Params.MaterialCostume = MaterialCostume;
        Params.MaterialHead = MaterialHead;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

