/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:50
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeanstalkCosmetics/CosmeticSteps/BP_FortCosmeticStep_ApplyBeanCD_Functions
 * ============================================================
 */

#include "BP_FortCosmeticStep_ApplyBeanCD.hpp"

namespace UE
{

    struct UBP_FortCosmeticStep_ApplyBeanCD_C___BP_UpdateCosmeticMaterials_Params
    {
        UBeanCosmeticItemDefinitionBase*    BeanCD;             // 0x000000 (0x000008) [Default: 0x1494D660]
        UMaterialInstanceDynamic*           MaterialBody;       // 0x000008 (0x000008) [Default: 0x54A81FDD00280031]
        UMaterialInstanceDynamic*           MaterialCostume;    // 0x000010 (0x000008) [Default: 0x7FEDD8E67540]
        UMaterialInstanceDynamic*           MaterialHead;       // 0x000018 (0x000008) [Default: 0x7FE99A7380A0]
    };

} // namespace UE

