/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:50
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeanstalkCosmetics/CosmeticSteps/BP_FortCosmeticStep_ApplyBeanCD
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0000C8 (0x000000)
    class UBP_FortCosmeticStep_ApplyBeanCD_C : public UFortCosmeticStep_ApplyBeanCD
    {
    public:
    
    public: // Functions
        void    BP_UpdateCosmeticMaterials(UBeanCosmeticItemDefinitionBase* BeanCD, UMaterialInstanceDynamic* MaterialBody, UMaterialInstanceDynamic* MaterialCostume, UMaterialInstanceDynamic* MaterialHead); // 0x000545D2 [Event | Public | BlueprintCallable | BlueprintEvent | Const]
    };
}

