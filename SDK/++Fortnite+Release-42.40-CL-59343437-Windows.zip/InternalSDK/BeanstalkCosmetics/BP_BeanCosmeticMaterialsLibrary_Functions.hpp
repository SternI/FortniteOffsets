/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:50
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeanstalkCosmetics/BP_BeanCosmeticMaterialsLibrary_Functions
 * ============================================================
 */

#include "BP_BeanCosmeticMaterialsLibrary.hpp"

namespace UE
{

    struct UBP_BeanCosmeticMaterialsLibrary_C___GetColorFromIndex_Params
    {
        UDataTable*     DT_Colors;                                      // 0x000000 (0x000008) [Default: 0x13109250]
        int32           Index;                                          // 0x000008 (0x000004) [Default: 2621489]
        uint8           UnknownData_00000C[0x000004];                   // 0x00000C (0x000004)
        UObject*        __WorldContext;                                 // 0x000010 (0x000008) [Default: 0x7FEDD8E672A0]
        FLinearColor    Color;                                          // 0x000018 (0x000010) [OutParam]
        bool            ColorFoundInDT;                                 // 0x000028 (0x000001) [OutParam] [Default: false]
        uint8           UnknownData_000029[0x000007];                   // 0x000029 (0x000007)
        FString         CallFunc_Conv_IntToString_ReturnValue;          // 0x000030 (0x000010) [Default: L""]
        FName           CallFunc_Conv_StringToName_ReturnValue;         // 0x000040 (0x000004) [Default: FName(724) -> L""]
        uint8           UnknownData_000044[0x000004];                   // 0x000044 (0x000004)
        FAtomColorInfo  CallFunc_GetDataTableRowFromName_OutRow;        // 0x000048 (0x000028)
        bool            CallFunc_GetDataTableRowFromName_ReturnValue;   // 0x000070 (0x000001) [Default: true]
        uint8           UnknownData_000071[0x000003];                   // 0x000071 (0x000003)
        FLinearColor    CallFunc_Conv_ColorToLinearColor_ReturnValue;   // 0x000074 (0x000010)
    };

    struct UBP_BeanCosmeticMaterialsLibrary_C___GetMaterialValuesFromDT_Params
    {
        UDataTable*                             DT_Materials;                                   // 0x000000 (0x000008) [Default: 0x13109250]
        int32                                   RowNameToFind;                                  // 0x000008 (0x000004) [Default: 2621489]
        uint8                                   UnknownData_00000C[0x000004];                   // 0x00000C (0x000004)
        UObject*                                __WorldContext;                                 // 0x000010 (0x000008) [Default: 0x7FEDD8E672A0]
        FBeanstalkCosmetics_MaterialTypeInfo    MaterialType;                                   // 0x000018 (0x000020) [OutParam]
        FString                                 CallFunc_Conv_IntToString_ReturnValue;          // 0x000038 (0x000010) [Default: L""]
        FName                                   CallFunc_Conv_StringToName_ReturnValue;         // 0x000048 (0x000004) [Default: FName(33) -> L""]
        uint8                                   UnknownData_00004C[0x000004];                   // 0x00004C (0x000004)
        FBeanstalkCosmetics_MaterialTypeInfo    CallFunc_GetDataTableRowFromName_OutRow;        // 0x000050 (0x000020)
        bool                                    CallFunc_GetDataTableRowFromName_ReturnValue;   // 0x000070 (0x000001) [Default: true]
    };

    struct UBP_BeanCosmeticMaterialsLibrary_C___MergeMaterialPropsIntoMaterial_Params
    {
        UMaterialInstanceDynamic*               Material;                                       // 0x000000 (0x000008) [Default: 0x13109250]
        FName                                   ParameterName;                                  // 0x000008 (0x000004) [Default: FName(2621489) -> L""]
        uint8                                   UnknownData_00000C[0x000004];                   // 0x00000C (0x000004)
        UDataTable*                             DT_Materials;                                   // 0x000010 (0x000008) [Default: 0x7FEDD8E672A0]
        int32                                   MaterialIndexFromDT;                            // 0x000018 (0x000004) [Default: -1704581408]
        uint8                                   UnknownData_00001C[0x000004];                   // 0x00001C (0x000004)
        UObject*                                __WorldContext;                                 // 0x000020 (0x000008) [Default: 0x8593E3BB]
        FBeanstalkCosmetics_MaterialTypeInfo    CallFunc_GetMaterialValuesFromDT_MaterialType;  // 0x000028 (0x000020)
        FLinearColor                            CallFunc_MakeColor_ReturnValue;                 // 0x000048 (0x000010)
        float                                   CallFunc_MakeColor_R_ImplicitCast;              // 0x000058 (0x000004) [Default: 0f]
        float                                   CallFunc_MakeColor_G_ImplicitCast;              // 0x00005C (0x000004) [Default: 4.72559f]
        float                                   CallFunc_MakeColor_B_ImplicitCast;              // 0x000060 (0x000004) [Default: 2.39185e-24f]
    };

    struct UBP_BeanCosmeticMaterialsLibrary_C___SetColorMaterialParameterFromIndex_Params
    {
        UMaterialInstanceDynamic*   Material;                                   // 0x000000 (0x000008) [Default: 0x13109250]
        FName                       ParameterName;                              // 0x000008 (0x000004) [Default: FName(2621489) -> L""]
        uint8                       UnknownData_00000C[0x000004];               // 0x00000C (0x000004)
        UDataTable*                 DT_Colors;                                  // 0x000010 (0x000008) [Default: 0x7FEDD8E672A0]
        int32                       ColorIndexFromDT;                           // 0x000018 (0x000004) [Default: -1704581408]
        uint8                       UnknownData_00001C[0x000004];               // 0x00001C (0x000004)
        UObject*                    __WorldContext;                             // 0x000020 (0x000008) [Default: 0x8593E3BB]
        FLinearColor                CallFunc_GetColorFromIndex_Color;           // 0x000028 (0x000010)
        bool                        CallFunc_GetColorFromIndex_ColorFoundInDT;  // 0x000038 (0x000001) [Default: true]
    };

    struct UBP_BeanCosmeticMaterialsLibrary_C___SetMaterialUvPatternPositionFromTextureSlot_Params
    {
        UMaterialInstanceDynamic*                           Material;                                       // 0x000000 (0x000008) [Default: 0x13109250]
        FName                                               ParameterName;                                  // 0x000008 (0x000004) [Default: FName(2621489) -> L""]
        int32                                               TextureSlot;                                    // 0x00000C (0x000004) [Default: 1353195485]
        UDataTable*                                         DT_PatternAtlasTextureSlots;                    // 0x000010 (0x000008) [Default: 0x7FEDD8E672A0]
        UObject*                                            __WorldContext;                                 // 0x000018 (0x000008) [Default: 0x7FE99A6626E0]
        FString                                             CallFunc_Conv_IntToString_ReturnValue;          // 0x000020 (0x000010) [Default: L""]
        FName                                               CallFunc_Conv_StringToName_ReturnValue;         // 0x000030 (0x000004) [Default: FName(406363184) -> L""]
        uint8                                               UnknownData_000034[0x000004];                   // 0x000034 (0x000004)
        FBeanstalkCosmetics_PatternAtlasTextureSlotsInfo    CallFunc_GetDataTableRowFromName_OutRow;        // 0x000038 (0x000028)
        bool                                                CallFunc_GetDataTableRowFromName_ReturnValue;   // 0x000060 (0x000001) [Default: true]
        uint8                                               UnknownData_000061[0x000003];                   // 0x000061 (0x000003)
        FLinearColor                                        CallFunc_Conv_VectorToLinearColor_ReturnValue;  // 0x000064 (0x000010)
    };

    struct UBP_BeanCosmeticMaterialsLibrary_C___Update_Character_Material_Params
    {
        UBeanCosmeticItemDefinitionBase*    BeanCD;                                     // 0x000000 (0x000008) [Default: 0x13109250]
        UMaterialInstanceDynamic*           BodyMaterial;                               // 0x000008 (0x000008) [Default: 0x50A81FDD00280031]
        UMaterialInstanceDynamic*           CostumeBodyMaterial;                        // 0x000010 (0x000008) [Default: 0x7FEDD8E672A0]
        UMaterialInstanceDynamic*           CostumeHeadMaterial;                        // 0x000018 (0x000008) [Default: 0x7FE99A6626E0]
        UDataTable*                         DT_Colors;                                  // 0x000020 (0x000008) [Default: 0x8593E3BB]
        UDataTable*                         DT_Materials;                               // 0x000028 (0x000008) [Default: 0x7FEBD946CC00]
        UDataTable*                         DT_PatternAtlasTextureSlots;                // 0x000030 (0x000008) [Default: 0x7FE918389C30]
        UDataTable*                         DT_Roughness;                               // 0x000038 (0x000008) [Default: 0x7FE91838C870]
        UObject*                            __WorldContext;                             // 0x000040 (0x000008) [Default: 0x198000002D4]
        UDataTable*                         DT_MaterialTypes;                           // 0x000048 (0x000008) [Default: 0x1800000021]
        double                              GlobalEmissiveValue;                        // 0x000050 (0x000008) [Default: 1056]
        double                              GlobalMetallicValue;                        // 0x000058 (0x000008) [Default: 1486]
        UMaterialInstanceDynamic*           Head_Costume_Material;                      // 0x000060 (0x000008) [Default: 0x7FE918390F60]
        UMaterialInstanceDynamic*           Bean_Costume_Material;                      // 0x000068 (0x000008) [Default: 0x7FE91839E0C0]
        UMaterialInstanceDynamic*           Bean_Body_Material;                         // 0x000070 (0x000008) [Default: 0x12300000345]
        UBeanCosmeticItemDefinitionBase*    CurrentBeanCID;                             // 0x000078 (0x000008) [Default: 0xF00000023]
        double                              CallFunc_Conv_BoolToDouble_ReturnValue;     // 0x000080 (0x000008) [Default: 63]
        double                              CallFunc_Conv_BoolToDouble_ReturnValue_1;   // 0x000088 (0x000008) [Default: 478]
        double                              CallFunc_Conv_BoolToDouble_ReturnValue_2;   // 0x000090 (0x000008) [Default: 1.87611e-315]
        FLinearColor                        CallFunc_MakeColor_ReturnValue;             // 0x000098 (0x000010)
        UObject*                            CallFunc_LoadAsset_Blocking_ReturnValue;    // 0x0000A8 (0x000008) [Default: 0x17C85C40]
        UTexture2D*                         K2Node_DynamicCast_AsTexture_2D;            // 0x0000B0 (0x000008) [Default: 0x17C85AB0]
        bool                                K2Node_DynamicCast_bSuccess;                // 0x0000B8 (0x000001) [Default: true]
        uint8                               UnknownData_0000B9[0x000003];               // 0x0000B9 (0x000003)
        float                               CallFunc_MakeColor_B_ImplicitCast;          // 0x0000BC (0x000004) [Default: 4.58911e-41f]
        float                               CallFunc_MakeColor_G_ImplicitCast;          // 0x0000C0 (0x000004) [Default: 7.82405e+14f]
        float                               CallFunc_MakeColor_R_ImplicitCast;          // 0x0000C4 (0x000004) [Default: 4.58841e-41f]
    };

} // namespace UE

