/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:50
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeanstalkCosmetics/Cosmetics/Datatables/BeanstalkCosmetics_PatternAtlasTextureSlotsInfo
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FBeanstalkCosmetics_PatternAtlasTextureSlotsInfo
    {
        FString Name_15_2545F8D141FCEFF4E1C26E95718DB478;       // 0x000000 (0x000010) [Default: L""]
        FVector UV_Values_20_EF64094F4DFFACDF1F733FA3C3858409;  // 0x000010 (0x000018)
    };
}

