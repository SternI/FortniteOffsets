/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:50
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeanstalkCosmetics/Cosmetics/Datatables/BeanstalkCosmetics_MaterialTypeInfo
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FBeanstalkCosmetics_MaterialTypeInfo
    {
        FName   Name_5_2545F8D141FCEFF4E1C26E95718DB478;        // 0x000000 (0x000004) [Default: NAME_None]
        uint8   UnknownData_000004[0x000004];                   // 0x000004 (0x000004)
        double  Metallic_17_26B17D57490B8DE99FD6AD85D810F3EB;   // 0x000008 (0x000008) [Default: 0]
        double  Roughness_10_EF64094F4DFFACDF1F733FA3C3858409;  // 0x000010 (0x000008) [Default: 0]
        double  Emissive_19_4467043B429E4D5BECF743BAE9E8BF3B;   // 0x000018 (0x000008) [Default: 0]
    };
}

