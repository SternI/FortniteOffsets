/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:50
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeanstalkCosmetics/Cosmetics/Frontend/ABP_BeanChar_Frontend
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000918 (0x0000C8)
    class alignas(0x8) UABP_BeanChar_Frontend_C : public UFrontendAnimInstance
    {
    public:
        FAnimSubsystemInstance      AnimBlueprintExtension_PropertyAccess;  // 0x000850 (0x000008)
        FAnimSubsystemInstance      AnimBlueprintExtension_Base;            // 0x000858 (0x000008)
        FAnimNode_Root              AnimGraphNode_Root;                     // 0x000860 (0x000020)
        FAnimNode_SequencePlayer    AnimGraphNode_SequencePlayer;           // 0x000880 (0x000050)
        FAnimNode_Slot              AnimGraphNode_Slot;                     // 0x0008D0 (0x000048)
    
    public: // Functions
        void    AnimGraph(FPoseLink& AnimGraph); // 0x000545D2 [HasOutParms | BlueprintCallable | BlueprintEvent]
    };
}

