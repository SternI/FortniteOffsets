/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:50
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeanstalkCosmetics/Cosmetics/Frontend/ABP_BeanChar_Frontend_Functions
 * ============================================================
 */

#include "ABP_BeanChar_Frontend_Functions.hpp"

namespace UE
{

    void UABP_BeanChar_Frontend_C::AnimGraph(FPoseLink& AnimGraph)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("ABP_BeanChar_Frontend.ABP_BeanChar_Frontend_C.AnimGraph");
    
        UABP_BeanChar_Frontend_C___AnimGraph_Params Params{};
        Params.AnimGraph = AnimGraph;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        AnimGraph = Params.AnimGraph;
    }

} // namespace UE

