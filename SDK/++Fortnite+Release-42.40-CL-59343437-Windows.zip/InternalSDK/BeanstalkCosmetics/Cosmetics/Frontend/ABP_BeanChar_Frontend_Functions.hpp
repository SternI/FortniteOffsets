/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:50
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeanstalkCosmetics/Cosmetics/Frontend/ABP_BeanChar_Frontend_Functions
 * ============================================================
 */

#include "ABP_BeanChar_Frontend.hpp"

namespace UE
{

    struct UABP_BeanChar_Frontend_C___AnimGraph_Params
    {
        FPoseLink   AnimGraph;  // 0x000000 (0x000010) [OutParam]
    };

} // namespace UE

