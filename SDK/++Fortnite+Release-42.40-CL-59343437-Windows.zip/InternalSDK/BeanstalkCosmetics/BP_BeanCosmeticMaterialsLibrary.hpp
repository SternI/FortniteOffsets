/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:50
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /BeanstalkCosmetics/BP_BeanCosmeticMaterialsLibrary
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class UBP_BeanCosmeticMaterialsLibrary_C : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static void    GetColorFromIndex(UDataTable* DT_Colors, int32 Index, UObject* __WorldContext, FLinearColor& Color, bool& ColorFoundInDT, FString CallFunc_Conv_IntToString_ReturnValue, FName CallFunc_Conv_StringToName_ReturnValue, FAtomColorInfo CallFunc_GetDataTableRowFromName_OutRow, bool CallFunc_GetDataTableRowFromName_ReturnValue, FLinearColor CallFunc_Conv_ColorToLinearColor_ReturnValue); // 0x000545D2 [Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintEvent | BlueprintPure]
        static void    GetMaterialValuesFromDT(UDataTable* DT_Materials, int32 RowNameToFind, UObject* __WorldContext, FBeanstalkCosmetics_MaterialTypeInfo& MaterialType, FString CallFunc_Conv_IntToString_ReturnValue, FName CallFunc_Conv_StringToName_ReturnValue, FBeanstalkCosmetics_MaterialTypeInfo CallFunc_GetDataTableRowFromName_OutRow, bool CallFunc_GetDataTableRowFromName_ReturnValue); // 0x000545D2 [Static | Public | HasOutParms | BlueprintCallable | BlueprintEvent | BlueprintPure]
        static void    MergeMaterialPropsIntoMaterial(UMaterialInstanceDynamic* Material, FName ParameterName, UDataTable* DT_Materials, int32 MaterialIndexFromDT, UObject* __WorldContext, FBeanstalkCosmetics_MaterialTypeInfo CallFunc_GetMaterialValuesFromDT_MaterialType, FLinearColor CallFunc_MakeColor_ReturnValue, float CallFunc_MakeColor_R_ImplicitCast, float CallFunc_MakeColor_G_ImplicitCast, float CallFunc_MakeColor_B_ImplicitCast); // 0x000545D2 [Static | Public | BlueprintCallable | BlueprintEvent]
        static void    SetColorMaterialParameterFromIndex(UMaterialInstanceDynamic* Material, FName ParameterName, UDataTable* DT_Colors, int32 ColorIndexFromDT, UObject* __WorldContext, FLinearColor CallFunc_GetColorFromIndex_Color, bool CallFunc_GetColorFromIndex_ColorFoundInDT); // 0x000545D2 [Static | Public | BlueprintCallable | BlueprintEvent]
        static void    SetMaterialUvPatternPositionFromTextureSlot(UMaterialInstanceDynamic* Material, FName ParameterName, int32 TextureSlot, UDataTable* DT_PatternAtlasTextureSlots, UObject* __WorldContext, FString CallFunc_Conv_IntToString_ReturnValue, FName CallFunc_Conv_StringToName_ReturnValue, FBeanstalkCosmetics_PatternAtlasTextureSlotsInfo CallFunc_GetDataTableRowFromName_OutRow, bool CallFunc_GetDataTableRowFromName_ReturnValue, FLinearColor CallFunc_Conv_VectorToLinearColor_ReturnValue); // 0x000545D2 [Static | Public | BlueprintCallable | BlueprintEvent]
        static void    Update_Character_Material(UBeanCosmeticItemDefinitionBase* BeanCD, UMaterialInstanceDynamic* BodyMaterial, UMaterialInstanceDynamic* CostumeBodyMaterial, UMaterialInstanceDynamic* CostumeHeadMaterial, UDataTable* DT_Colors, UDataTable* DT_Materials, UDataTable* DT_PatternAtlasTextureSlots, UDataTable* DT_Roughness, UObject* __WorldContext, UDataTable* DT_MaterialTypes, double GlobalEmissiveValue, double GlobalMetallicValue, UMaterialInstanceDynamic* Head_Costume_Material, UMaterialInstanceDynamic* Bean_Costume_Material, UMaterialInstanceDynamic* Bean_Body_Material, UBeanCosmeticItemDefinitionBase* CurrentBeanCID, double CallFunc_Conv_BoolToDouble_ReturnValue, double CallFunc_Conv_BoolToDouble_ReturnValue_1, double CallFunc_Conv_BoolToDouble_ReturnValue_2, FLinearColor CallFunc_MakeColor_ReturnValue, UObject* CallFunc_LoadAsset_Blocking_ReturnValue, UTexture2D* K2Node_DynamicCast_AsTexture_2D, bool K2Node_DynamicCast_bSuccess, float CallFunc_MakeColor_B_ImplicitCast, float CallFunc_MakeColor_G_ImplicitCast, float CallFunc_MakeColor_R_ImplicitCast); // 0x000545D2 [Static | Public | BlueprintCallable | BlueprintEvent]
    };
}

