/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:07
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioMutators_Functions
 * ============================================================
 */

#include "AudioMutators.hpp"

namespace UE
{

    struct UAudioMutatorsSubsystem___AddMutator_Params
    {
        UAudioMutatorBase*  Mutator;    // 0x000000 (0x000008) [Default: 0x1355D540]
    };

    struct UAudioMutatorsSubsystem___RemoveMutator_Params
    {
        UAudioMutatorBase*  Mutator;    // 0x000000 (0x000008) [Default: 0x1355D540]
    };

    struct UAudioMutatorsSubsystem___ReplaceMutator_Params
    {
        UAudioMutatorBase*  Mutator;    // 0x000000 (0x000008) [Default: 0x1355D540]
    };

} // namespace UE

