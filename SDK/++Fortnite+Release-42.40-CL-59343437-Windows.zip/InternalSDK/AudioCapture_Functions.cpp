/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioCapture_Functions
 * ============================================================
 */

#include "AudioCapture_Functions.hpp"

namespace UE
{

    bool UAudioCapture::GetAudioCaptureDeviceInfo(FAudioCaptureDeviceInfo& OutInfo)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioCapture.AudioCapture.GetAudioCaptureDeviceInfo");
    
        UAudioCapture___GetAudioCaptureDeviceInfo_Params Params{};
        Params.OutInfo = OutInfo;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OutInfo = Params.OutInfo;
    
        return Params.ReturnValue;
    }

    bool UAudioCapture::IsCapturingAudio()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioCapture.AudioCapture.IsCapturingAudio");
    
        UAudioCapture___IsCapturingAudio_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioCapture::StartCapturingAudio()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioCapture.AudioCapture.StartCapturingAudio");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioCapture::StopCapturingAudio()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioCapture.AudioCapture.StopCapturingAudio");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    FString UAudioCaptureBlueprintLibrary::Conv_AudioInputDeviceInfoToString(FAudioInputDeviceInfo& Info)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioCapture.AudioCaptureBlueprintLibrary.Conv_AudioInputDeviceInfoToString");
    
        UAudioCaptureBlueprintLibrary___Conv_AudioInputDeviceInfoToString_Params Params{};
        Params.Info = Info;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Info = Params.Info;
    
        return Params.ReturnValue;
    }

    void UAudioCaptureBlueprintLibrary::GetAvailableAudioInputDevices(UObject* WorldContextObject, OnAudioInputDevicesObtained& OnObtainDevicesEvent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioCapture.AudioCaptureBlueprintLibrary.GetAvailableAudioInputDevices");
    
        UAudioCaptureBlueprintLibrary___GetAvailableAudioInputDevices_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.OnObtainDevicesEvent = OnObtainDevicesEvent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        OnObtainDevicesEvent = Params.OnObtainDevicesEvent;
    }

    UAudioCapture* UAudioCaptureFunctionLibrary::CreateAudioCapture()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioCapture.AudioCaptureFunctionLibrary.CreateAudioCapture");
    
        UAudioCaptureFunctionLibrary___CreateAudioCapture_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

} // namespace UE

