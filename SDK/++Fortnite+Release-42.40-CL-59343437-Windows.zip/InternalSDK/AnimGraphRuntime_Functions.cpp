/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:09
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimGraphRuntime_Functions
 * ============================================================
 */

#include "AnimGraphRuntime_Functions.hpp"

namespace UE
{

    FAnimComponentSpacePoseContext UAnimExecutionContextLibrary::ConvertToComponentSpacePoseContext(FAnimExecutionContext& Context, EAnimExecutionContextConversionResult& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToComponentSpacePoseContext");
    
        UAnimExecutionContextLibrary___ConvertToComponentSpacePoseContext_Params Params{};
        Params.Context = Context;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Context = Params.Context;
        Result = Params.Result;
    
        return Params.ReturnValue;
    }

    FAnimInitializationContext UAnimExecutionContextLibrary::ConvertToInitializationContext(FAnimExecutionContext& Context, EAnimExecutionContextConversionResult& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToInitializationContext");
    
        UAnimExecutionContextLibrary___ConvertToInitializationContext_Params Params{};
        Params.Context = Context;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Context = Params.Context;
        Result = Params.Result;
    
        return Params.ReturnValue;
    }

    FAnimPoseContext UAnimExecutionContextLibrary::ConvertToPoseContext(FAnimExecutionContext& Context, EAnimExecutionContextConversionResult& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToPoseContext");
    
        UAnimExecutionContextLibrary___ConvertToPoseContext_Params Params{};
        Params.Context = Context;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Context = Params.Context;
        Result = Params.Result;
    
        return Params.ReturnValue;
    }

    FAnimUpdateContext UAnimExecutionContextLibrary::ConvertToUpdateContext(FAnimExecutionContext& Context, EAnimExecutionContextConversionResult& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToUpdateContext");
    
        UAnimExecutionContextLibrary___ConvertToUpdateContext_Params Params{};
        Params.Context = Context;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Context = Params.Context;
        Result = Params.Result;
    
        return Params.ReturnValue;
    }

    UAnimInstance* UAnimExecutionContextLibrary::GetAnimInstance(FAnimExecutionContext& Context)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimExecutionContextLibrary.GetAnimInstance");
    
        UAnimExecutionContextLibrary___GetAnimInstance_Params Params{};
        Params.Context = Context;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Context = Params.Context;
    
        return Params.ReturnValue;
    }

    FAnimNodeReference UAnimExecutionContextLibrary::GetAnimNodeReference(UAnimInstance* Instance, int32 Index)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimExecutionContextLibrary.GetAnimNodeReference");
    
        UAnimExecutionContextLibrary___GetAnimNodeReference_Params Params{};
        Params.Instance = Instance;
        Params.Index = Index;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAnimExecutionContextLibrary::GetCurrentWeight(FAnimUpdateContext& Context)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimExecutionContextLibrary.GetCurrentWeight");
    
        UAnimExecutionContextLibrary___GetCurrentWeight_Params Params{};
        Params.Context = Context;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Context = Params.Context;
    
        return Params.ReturnValue;
    }

    float UAnimExecutionContextLibrary::GetDeltaTime(FAnimUpdateContext& Context)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimExecutionContextLibrary.GetDeltaTime");
    
        UAnimExecutionContextLibrary___GetDeltaTime_Params Params{};
        Params.Context = Context;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Context = Params.Context;
    
        return Params.ReturnValue;
    }

    bool UAnimExecutionContextLibrary::IsActive(FAnimExecutionContext& Context)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimExecutionContextLibrary.IsActive");
    
        UAnimExecutionContextLibrary___IsActive_Params Params{};
        Params.Context = Context;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Context = Params.Context;
    
        return Params.ReturnValue;
    }

    FRigidBodyAnimNodeReference UAnimNodeRigidBodyLibrary::ConvertToRigidBodyAnimNode(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimNodeRigidBodyLibrary.ConvertToRigidBodyAnimNode");
    
        UAnimNodeRigidBodyLibrary___ConvertToRigidBodyAnimNode_Params Params{};
        Params.Node = Node;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        Result = Params.Result;
    
        return Params.ReturnValue;
    }

    void UAnimNodeRigidBodyLibrary::ConvertToRigidBodyAnimNodePure(FAnimNodeReference& Node, FRigidBodyAnimNodeReference& RigidBodyAnimNode, bool& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimNodeRigidBodyLibrary.ConvertToRigidBodyAnimNodePure");
    
        UAnimNodeRigidBodyLibrary___ConvertToRigidBodyAnimNodePure_Params Params{};
        Params.Node = Node;
        Params.RigidBodyAnimNode = RigidBodyAnimNode;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        RigidBodyAnimNode = Params.RigidBodyAnimNode;
        Result = Params.Result;
    }

    FRigidBodyAnimNodeReference UAnimNodeRigidBodyLibrary::SetOverridePhysicsAsset(FRigidBodyAnimNodeReference& Node, UPhysicsAsset* PhysicsAsset)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimNodeRigidBodyLibrary.SetOverridePhysicsAsset");
    
        UAnimNodeRigidBodyLibrary___SetOverridePhysicsAsset_Params Params{};
        Params.Node = Node;
        Params.PhysicsAsset = PhysicsAsset;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
    
        return Params.ReturnValue;
    }

    void UAnimationStateMachineLibrary::ConvertToAnimationStateMachine(FAnimNodeReference& Node, FAnimationStateMachineReference& AnimationState, EAnimNodeReferenceConversionResult& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateMachine");
    
        UAnimationStateMachineLibrary___ConvertToAnimationStateMachine_Params Params{};
        Params.Node = Node;
        Params.AnimationState = AnimationState;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        AnimationState = Params.AnimationState;
        Result = Params.Result;
    }

    void UAnimationStateMachineLibrary::ConvertToAnimationStateMachinePure(FAnimNodeReference& Node, FAnimationStateMachineReference& AnimationState, bool& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateMachinePure");
    
        UAnimationStateMachineLibrary___ConvertToAnimationStateMachinePure_Params Params{};
        Params.Node = Node;
        Params.AnimationState = AnimationState;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        AnimationState = Params.AnimationState;
        Result = Params.Result;
    }

    void UAnimationStateMachineLibrary::ConvertToAnimationStateResult(FAnimNodeReference& Node, FAnimationStateResultReference& AnimationState, EAnimNodeReferenceConversionResult& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateResult");
    
        UAnimationStateMachineLibrary___ConvertToAnimationStateResult_Params Params{};
        Params.Node = Node;
        Params.AnimationState = AnimationState;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        AnimationState = Params.AnimationState;
        Result = Params.Result;
    }

    void UAnimationStateMachineLibrary::ConvertToAnimationStateResultPure(FAnimNodeReference& Node, FAnimationStateResultReference& AnimationState, bool& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateResultPure");
    
        UAnimationStateMachineLibrary___ConvertToAnimationStateResultPure_Params Params{};
        Params.Node = Node;
        Params.AnimationState = AnimationState;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        AnimationState = Params.AnimationState;
        Result = Params.Result;
    }

    float UAnimationStateMachineLibrary::GetRelevantAnimTimeRemaining(FAnimUpdateContext& UpdateContext, FAnimationStateResultReference& Node)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimationStateMachineLibrary.GetRelevantAnimTimeRemaining");
    
        UAnimationStateMachineLibrary___GetRelevantAnimTimeRemaining_Params Params{};
        Params.UpdateContext = UpdateContext;
        Params.Node = Node;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        UpdateContext = Params.UpdateContext;
        Node = Params.Node;
    
        return Params.ReturnValue;
    }

    float UAnimationStateMachineLibrary::GetRelevantAnimTimeRemainingFraction(FAnimUpdateContext& UpdateContext, FAnimationStateResultReference& Node)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimationStateMachineLibrary.GetRelevantAnimTimeRemainingFraction");
    
        UAnimationStateMachineLibrary___GetRelevantAnimTimeRemainingFraction_Params Params{};
        Params.UpdateContext = UpdateContext;
        Params.Node = Node;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        UpdateContext = Params.UpdateContext;
        Node = Params.Node;
    
        return Params.ReturnValue;
    }

    FName UAnimationStateMachineLibrary::GetState(FAnimUpdateContext& UpdateContext, FAnimationStateMachineReference& Node)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimationStateMachineLibrary.GetState");
    
        UAnimationStateMachineLibrary___GetState_Params Params{};
        Params.UpdateContext = UpdateContext;
        Params.Node = Node;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        UpdateContext = Params.UpdateContext;
        Node = Params.Node;
    
        return Params.ReturnValue;
    }

    bool UAnimationStateMachineLibrary::IsStateBlendingIn(FAnimUpdateContext& UpdateContext, FAnimationStateResultReference& Node)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimationStateMachineLibrary.IsStateBlendingIn");
    
        UAnimationStateMachineLibrary___IsStateBlendingIn_Params Params{};
        Params.UpdateContext = UpdateContext;
        Params.Node = Node;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        UpdateContext = Params.UpdateContext;
        Node = Params.Node;
    
        return Params.ReturnValue;
    }

    bool UAnimationStateMachineLibrary::IsStateBlendingOut(FAnimUpdateContext& UpdateContext, FAnimationStateResultReference& Node)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimationStateMachineLibrary.IsStateBlendingOut");
    
        UAnimationStateMachineLibrary___IsStateBlendingOut_Params Params{};
        Params.UpdateContext = UpdateContext;
        Params.Node = Node;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        UpdateContext = Params.UpdateContext;
        Node = Params.Node;
    
        return Params.ReturnValue;
    }

    void UAnimationStateMachineLibrary::SetState(FAnimUpdateContext& UpdateContext, FAnimationStateMachineReference& Node, FName TargetState, float duration, TEnumAsByte<ETransitionLogicType> BlendType, UBlendProfile* BlendProfile, EAlphaBlendOption AlphaBlendOption, UCurveFloat* CustomBlendCurve)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.AnimationStateMachineLibrary.SetState");
    
        UAnimationStateMachineLibrary___SetState_Params Params{};
        Params.UpdateContext = UpdateContext;
        Params.Node = Node;
        Params.TargetState = TargetState;
        Params.duration = duration;
        Params.BlendType = BlendType;
        Params.BlendProfile = BlendProfile;
        Params.AlphaBlendOption = AlphaBlendOption;
        Params.CustomBlendCurve = CustomBlendCurve;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        UpdateContext = Params.UpdateContext;
        Node = Params.Node;
    }

    FBlendListBaseReference UBlendListBaseLibrary::ConvertToBlendListBase(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendListBaseLibrary.ConvertToBlendListBase");
    
        UBlendListBaseLibrary___ConvertToBlendListBase_Params Params{};
        Params.Node = Node;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        Result = Params.Result;
    
        return Params.ReturnValue;
    }

    void UBlendListBaseLibrary::ResetNode(FBlendListBaseReference& BlendListBase)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendListBaseLibrary.ResetNode");
    
        UBlendListBaseLibrary___ResetNode_Params Params{};
        Params.BlendListBase = BlendListBase;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlendListBase = Params.BlendListBase;
    }

    FBlendSpaceReference UBlendSpaceLibrary::ConvertToBlendSpace(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpaceLibrary.ConvertToBlendSpace");
    
        UBlendSpaceLibrary___ConvertToBlendSpace_Params Params{};
        Params.Node = Node;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        Result = Params.Result;
    
        return Params.ReturnValue;
    }

    void UBlendSpaceLibrary::ConvertToBlendSpacePure(FAnimNodeReference& Node, FBlendSpaceReference& BlendSpace, bool& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpaceLibrary.ConvertToBlendSpacePure");
    
        UBlendSpaceLibrary___ConvertToBlendSpacePure_Params Params{};
        Params.Node = Node;
        Params.BlendSpace = BlendSpace;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        BlendSpace = Params.BlendSpace;
        Result = Params.Result;
    }

    FVector UBlendSpaceLibrary::GetFilteredPosition(FBlendSpaceReference& BlendSpace)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpaceLibrary.GetFilteredPosition");
    
        UBlendSpaceLibrary___GetFilteredPosition_Params Params{};
        Params.BlendSpace = BlendSpace;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlendSpace = Params.BlendSpace;
    
        return Params.ReturnValue;
    }

    FVector UBlendSpaceLibrary::GetPosition(FBlendSpaceReference& BlendSpace)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpaceLibrary.GetPosition");
    
        UBlendSpaceLibrary___GetPosition_Params Params{};
        Params.BlendSpace = BlendSpace;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlendSpace = Params.BlendSpace;
    
        return Params.ReturnValue;
    }

    void UBlendSpaceLibrary::SnapToPosition(FBlendSpaceReference& BlendSpace, FVector NewPosition)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpaceLibrary.SnapToPosition");
    
        UBlendSpaceLibrary___SnapToPosition_Params Params{};
        Params.BlendSpace = BlendSpace;
        Params.NewPosition = NewPosition;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlendSpace = Params.BlendSpace;
    }

    FBlendSpacePlayerReference UBlendSpacePlayerLibrary::ConvertToBlendSpacePlayer(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpacePlayerLibrary.ConvertToBlendSpacePlayer");
    
        UBlendSpacePlayerLibrary___ConvertToBlendSpacePlayer_Params Params{};
        Params.Node = Node;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        Result = Params.Result;
    
        return Params.ReturnValue;
    }

    void UBlendSpacePlayerLibrary::ConvertToBlendSpacePlayerPure(FAnimNodeReference& Node, FBlendSpacePlayerReference& BlendSpacePlayer, bool& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpacePlayerLibrary.ConvertToBlendSpacePlayerPure");
    
        UBlendSpacePlayerLibrary___ConvertToBlendSpacePlayerPure_Params Params{};
        Params.Node = Node;
        Params.BlendSpacePlayer = BlendSpacePlayer;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        BlendSpacePlayer = Params.BlendSpacePlayer;
        Result = Params.Result;
    }

    float UBlendSpacePlayerLibrary::GetAccumulatedTime(FBlendSpacePlayerReference& BlendSpacePlayer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpacePlayerLibrary.GetAccumulatedTime");
    
        UBlendSpacePlayerLibrary___GetAccumulatedTime_Params Params{};
        Params.BlendSpacePlayer = BlendSpacePlayer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlendSpacePlayer = Params.BlendSpacePlayer;
    
        return Params.ReturnValue;
    }

    UBlendSpace* UBlendSpacePlayerLibrary::GetBlendSpace(FBlendSpacePlayerReference& BlendSpacePlayer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpacePlayerLibrary.GetBlendSpace");
    
        UBlendSpacePlayerLibrary___GetBlendSpace_Params Params{};
        Params.BlendSpacePlayer = BlendSpacePlayer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlendSpacePlayer = Params.BlendSpacePlayer;
    
        return Params.ReturnValue;
    }

    bool UBlendSpacePlayerLibrary::GetLoop(FBlendSpacePlayerReference& BlendSpacePlayer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpacePlayerLibrary.GetLoop");
    
        UBlendSpacePlayerLibrary___GetLoop_Params Params{};
        Params.BlendSpacePlayer = BlendSpacePlayer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlendSpacePlayer = Params.BlendSpacePlayer;
    
        return Params.ReturnValue;
    }

    float UBlendSpacePlayerLibrary::GetPlayRate(FBlendSpacePlayerReference& BlendSpacePlayer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpacePlayerLibrary.GetPlayRate");
    
        UBlendSpacePlayerLibrary___GetPlayRate_Params Params{};
        Params.BlendSpacePlayer = BlendSpacePlayer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlendSpacePlayer = Params.BlendSpacePlayer;
    
        return Params.ReturnValue;
    }

    FVector UBlendSpacePlayerLibrary::GetPosition(FBlendSpacePlayerReference& BlendSpacePlayer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpacePlayerLibrary.GetPosition");
    
        UBlendSpacePlayerLibrary___GetPosition_Params Params{};
        Params.BlendSpacePlayer = BlendSpacePlayer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlendSpacePlayer = Params.BlendSpacePlayer;
    
        return Params.ReturnValue;
    }

    float UBlendSpacePlayerLibrary::GetStartPosition(FBlendSpacePlayerReference& BlendSpacePlayer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpacePlayerLibrary.GetStartPosition");
    
        UBlendSpacePlayerLibrary___GetStartPosition_Params Params{};
        Params.BlendSpacePlayer = BlendSpacePlayer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlendSpacePlayer = Params.BlendSpacePlayer;
    
        return Params.ReturnValue;
    }

    FBlendSpacePlayerReference UBlendSpacePlayerLibrary::SetAccumulatedTime(FBlendSpacePlayerReference& BlendSpacePlayer, float time)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpacePlayerLibrary.SetAccumulatedTime");
    
        UBlendSpacePlayerLibrary___SetAccumulatedTime_Params Params{};
        Params.BlendSpacePlayer = BlendSpacePlayer;
        Params.time = time;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlendSpacePlayer = Params.BlendSpacePlayer;
    
        return Params.ReturnValue;
    }

    FBlendSpacePlayerReference UBlendSpacePlayerLibrary::SetBlendSpace(FBlendSpacePlayerReference& BlendSpacePlayer, UBlendSpace* BlendSpace)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpacePlayerLibrary.SetBlendSpace");
    
        UBlendSpacePlayerLibrary___SetBlendSpace_Params Params{};
        Params.BlendSpacePlayer = BlendSpacePlayer;
        Params.BlendSpace = BlendSpace;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlendSpacePlayer = Params.BlendSpacePlayer;
    
        return Params.ReturnValue;
    }

    FBlendSpacePlayerReference UBlendSpacePlayerLibrary::SetBlendSpaceWithInertialBlending(FAnimUpdateContext& UpdateContext, FBlendSpacePlayerReference& BlendSpacePlayer, UBlendSpace* BlendSpace, float BlendTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpacePlayerLibrary.SetBlendSpaceWithInertialBlending");
    
        UBlendSpacePlayerLibrary___SetBlendSpaceWithInertialBlending_Params Params{};
        Params.UpdateContext = UpdateContext;
        Params.BlendSpacePlayer = BlendSpacePlayer;
        Params.BlendSpace = BlendSpace;
        Params.BlendTime = BlendTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        UpdateContext = Params.UpdateContext;
        BlendSpacePlayer = Params.BlendSpacePlayer;
    
        return Params.ReturnValue;
    }

    FBlendSpacePlayerReference UBlendSpacePlayerLibrary::SetLoop(FBlendSpacePlayerReference& BlendSpacePlayer, bool bLoop)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpacePlayerLibrary.SetLoop");
    
        UBlendSpacePlayerLibrary___SetLoop_Params Params{};
        Params.BlendSpacePlayer = BlendSpacePlayer;
        Params.bLoop = bLoop;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlendSpacePlayer = Params.BlendSpacePlayer;
    
        return Params.ReturnValue;
    }

    FBlendSpacePlayerReference UBlendSpacePlayerLibrary::SetPlayRate(FBlendSpacePlayerReference& BlendSpacePlayer, float PlayRate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpacePlayerLibrary.SetPlayRate");
    
        UBlendSpacePlayerLibrary___SetPlayRate_Params Params{};
        Params.BlendSpacePlayer = BlendSpacePlayer;
        Params.PlayRate = PlayRate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlendSpacePlayer = Params.BlendSpacePlayer;
    
        return Params.ReturnValue;
    }

    FBlendSpacePlayerReference UBlendSpacePlayerLibrary::SetResetPlayTimeWhenBlendSpaceChanges(FBlendSpacePlayerReference& BlendSpacePlayer, bool bReset)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpacePlayerLibrary.SetResetPlayTimeWhenBlendSpaceChanges");
    
        UBlendSpacePlayerLibrary___SetResetPlayTimeWhenBlendSpaceChanges_Params Params{};
        Params.BlendSpacePlayer = BlendSpacePlayer;
        Params.bReset = bReset;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlendSpacePlayer = Params.BlendSpacePlayer;
    
        return Params.ReturnValue;
    }

    bool UBlendSpacePlayerLibrary::ShouldResetPlayTimeWhenBlendSpaceChanges(FBlendSpacePlayerReference& BlendSpacePlayer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpacePlayerLibrary.ShouldResetPlayTimeWhenBlendSpaceChanges");
    
        UBlendSpacePlayerLibrary___ShouldResetPlayTimeWhenBlendSpaceChanges_Params Params{};
        Params.BlendSpacePlayer = BlendSpacePlayer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlendSpacePlayer = Params.BlendSpacePlayer;
    
        return Params.ReturnValue;
    }

    void UBlendSpacePlayerLibrary::SnapToPosition(FBlendSpacePlayerReference& BlendSpacePlayer, FVector NewPosition)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.BlendSpacePlayerLibrary.SnapToPosition");
    
        UBlendSpacePlayerLibrary___SnapToPosition_Params Params{};
        Params.BlendSpacePlayer = BlendSpacePlayer;
        Params.NewPosition = NewPosition;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BlendSpacePlayer = Params.BlendSpacePlayer;
    }

    float UKismetAnimationLibrary::CalculateDirection(FVector& Velocity, FRotator& BaseRotation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.KismetAnimationLibrary.CalculateDirection");
    
        UKismetAnimationLibrary___CalculateDirection_Params Params{};
        Params.Velocity = Velocity;
        Params.BaseRotation = BaseRotation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Velocity = Params.Velocity;
        BaseRotation = Params.BaseRotation;
    
        return Params.ReturnValue;
    }

    float UKismetAnimationLibrary::K2_CalculateVelocityFromPositionHistory(float DeltaSeconds, FVector Position, FPositionHistory& History, int32 NumberOfSamples, float VelocityMin, float VelocityMax)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromPositionHistory");
    
        UKismetAnimationLibrary___K2_CalculateVelocityFromPositionHistory_Params Params{};
        Params.DeltaSeconds = DeltaSeconds;
        Params.Position = Position;
        Params.History = History;
        Params.NumberOfSamples = NumberOfSamples;
        Params.VelocityMin = VelocityMin;
        Params.VelocityMax = VelocityMax;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        History = Params.History;
    
        return Params.ReturnValue;
    }

    float UKismetAnimationLibrary::K2_CalculateVelocityFromSockets(float DeltaSeconds, USkeletalMeshComponent* Component, FName SocketOrBoneName, FName ReferenceSocketOrBone, TEnumAsByte<ERelativeTransformSpace> SocketSpace, FVector OffsetInBoneSpace, FPositionHistory& History, int32 NumberOfSamples, float VelocityMin, float VelocityMax, EEasingFuncType EasingType, FRuntimeFloatCurve& CustomCurve)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromSockets");
    
        UKismetAnimationLibrary___K2_CalculateVelocityFromSockets_Params Params{};
        Params.DeltaSeconds = DeltaSeconds;
        Params.Component = Component;
        Params.SocketOrBoneName = SocketOrBoneName;
        Params.ReferenceSocketOrBone = ReferenceSocketOrBone;
        Params.SocketSpace = SocketSpace;
        Params.OffsetInBoneSpace = OffsetInBoneSpace;
        Params.History = History;
        Params.NumberOfSamples = NumberOfSamples;
        Params.VelocityMin = VelocityMin;
        Params.VelocityMax = VelocityMax;
        Params.EasingType = EasingType;
        Params.CustomCurve = CustomCurve;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        History = Params.History;
        CustomCurve = Params.CustomCurve;
    
        return Params.ReturnValue;
    }

    FVector UKismetAnimationLibrary::K2_DirectionBetweenSockets(USkeletalMeshComponent* Component, FName SocketOrBoneNameFrom, FName SocketOrBoneNameTo)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.KismetAnimationLibrary.K2_DirectionBetweenSockets");
    
        UKismetAnimationLibrary___K2_DirectionBetweenSockets_Params Params{};
        Params.Component = Component;
        Params.SocketOrBoneNameFrom = SocketOrBoneNameFrom;
        Params.SocketOrBoneNameTo = SocketOrBoneNameTo;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UKismetAnimationLibrary::K2_DistanceBetweenTwoSocketsAndMapRange(USkeletalMeshComponent* Component, FName SocketOrBoneNameA, TEnumAsByte<ERelativeTransformSpace> SocketSpaceA, FName SocketOrBoneNameB, TEnumAsByte<ERelativeTransformSpace> SocketSpaceB, bool bRemapRange, float InRangeMin, float InRangeMax, float OutRangeMin, float OutRangeMax)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.KismetAnimationLibrary.K2_DistanceBetweenTwoSocketsAndMapRange");
    
        UKismetAnimationLibrary___K2_DistanceBetweenTwoSocketsAndMapRange_Params Params{};
        Params.Component = Component;
        Params.SocketOrBoneNameA = SocketOrBoneNameA;
        Params.SocketSpaceA = SocketSpaceA;
        Params.SocketOrBoneNameB = SocketOrBoneNameB;
        Params.SocketSpaceB = SocketSpaceB;
        Params.bRemapRange = bRemapRange;
        Params.InRangeMin = InRangeMin;
        Params.InRangeMax = InRangeMax;
        Params.OutRangeMin = OutRangeMin;
        Params.OutRangeMax = OutRangeMax;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UKismetAnimationLibrary::K2_EndProfilingTimer(bool bLog, FString LogPrefix)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.KismetAnimationLibrary.K2_EndProfilingTimer");
    
        UKismetAnimationLibrary___K2_EndProfilingTimer_Params Params{};
        Params.bLog = bLog;
        Params.LogPrefix = LogPrefix;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FTransform UKismetAnimationLibrary::K2_LookAt(FTransform& CurrentTransform, FVector& TargetPosition, FVector LookAtVector, bool bUseUpVector, FVector UpVector, float ClampConeInDegree)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.KismetAnimationLibrary.K2_LookAt");
    
        UKismetAnimationLibrary___K2_LookAt_Params Params{};
        Params.CurrentTransform = CurrentTransform;
        Params.TargetPosition = TargetPosition;
        Params.LookAtVector = LookAtVector;
        Params.bUseUpVector = bUseUpVector;
        Params.UpVector = UpVector;
        Params.ClampConeInDegree = ClampConeInDegree;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        CurrentTransform = Params.CurrentTransform;
        TargetPosition = Params.TargetPosition;
    
        return Params.ReturnValue;
    }

    float UKismetAnimationLibrary::K2_MakePerlinNoiseAndRemap(float Value, float RangeOutMin, float RangeOutMax)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseAndRemap");
    
        UKismetAnimationLibrary___K2_MakePerlinNoiseAndRemap_Params Params{};
        Params.Value = Value;
        Params.RangeOutMin = RangeOutMin;
        Params.RangeOutMax = RangeOutMax;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FVector UKismetAnimationLibrary::K2_MakePerlinNoiseVectorAndRemap(float X, float Y, float Z, float RangeOutMinX, float RangeOutMaxX, float RangeOutMinY, float RangeOutMaxY, float RangeOutMinZ, float RangeOutMaxZ)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseVectorAndRemap");
    
        UKismetAnimationLibrary___K2_MakePerlinNoiseVectorAndRemap_Params Params{};
        Params.X = X;
        Params.Y = Y;
        Params.Z = Z;
        Params.RangeOutMinX = RangeOutMinX;
        Params.RangeOutMaxX = RangeOutMaxX;
        Params.RangeOutMinY = RangeOutMinY;
        Params.RangeOutMaxY = RangeOutMaxY;
        Params.RangeOutMinZ = RangeOutMinZ;
        Params.RangeOutMaxZ = RangeOutMaxZ;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UKismetAnimationLibrary::K2_StartProfilingTimer()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.KismetAnimationLibrary.K2_StartProfilingTimer");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UKismetAnimationLibrary::K2_TwoBoneIK(FVector& RootPos, FVector& JointPos, FVector& EndPos, FVector& JointTarget, FVector& Effector, FVector& OutJointPos, FVector& OutEndPos, bool bAllowStretching, float StartStretchRatio, float MaxStretchScale)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.KismetAnimationLibrary.K2_TwoBoneIK");
    
        UKismetAnimationLibrary___K2_TwoBoneIK_Params Params{};
        Params.RootPos = RootPos;
        Params.JointPos = JointPos;
        Params.EndPos = EndPos;
        Params.JointTarget = JointTarget;
        Params.Effector = Effector;
        Params.OutJointPos = OutJointPos;
        Params.OutEndPos = OutEndPos;
        Params.bAllowStretching = bAllowStretching;
        Params.StartStretchRatio = StartStretchRatio;
        Params.MaxStretchScale = MaxStretchScale;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        RootPos = Params.RootPos;
        JointPos = Params.JointPos;
        EndPos = Params.EndPos;
        JointTarget = Params.JointTarget;
        Effector = Params.Effector;
        OutJointPos = Params.OutJointPos;
        OutEndPos = Params.OutEndPos;
    }

    void ULayeredBoneBlendLibrary::ConvertToLayeredBlendPerBonePure(FAnimNodeReference& Node, FLayeredBoneBlendReference& LayeredBoneBlend, bool& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.LayeredBoneBlendLibrary.ConvertToLayeredBlendPerBonePure");
    
        ULayeredBoneBlendLibrary___ConvertToLayeredBlendPerBonePure_Params Params{};
        Params.Node = Node;
        Params.LayeredBoneBlend = LayeredBoneBlend;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        LayeredBoneBlend = Params.LayeredBoneBlend;
        Result = Params.Result;
    }

    FLayeredBoneBlendReference ULayeredBoneBlendLibrary::ConvertToLayeredBoneBlend(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.LayeredBoneBlendLibrary.ConvertToLayeredBoneBlend");
    
        ULayeredBoneBlendLibrary___ConvertToLayeredBoneBlend_Params Params{};
        Params.Node = Node;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        Result = Params.Result;
    
        return Params.ReturnValue;
    }

    int32 ULayeredBoneBlendLibrary::GetNumPoses(FLayeredBoneBlendReference& LayeredBoneBlend)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.LayeredBoneBlendLibrary.GetNumPoses");
    
        ULayeredBoneBlendLibrary___GetNumPoses_Params Params{};
        Params.LayeredBoneBlend = LayeredBoneBlend;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        LayeredBoneBlend = Params.LayeredBoneBlend;
    
        return Params.ReturnValue;
    }

    FLayeredBoneBlendReference ULayeredBoneBlendLibrary::SetBlendMask(FAnimUpdateContext& UpdateContext, FLayeredBoneBlendReference& LayeredBoneBlend, int32 PoseIndex, FName BlendMaskName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.LayeredBoneBlendLibrary.SetBlendMask");
    
        ULayeredBoneBlendLibrary___SetBlendMask_Params Params{};
        Params.UpdateContext = UpdateContext;
        Params.LayeredBoneBlend = LayeredBoneBlend;
        Params.PoseIndex = PoseIndex;
        Params.BlendMaskName = BlendMaskName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        UpdateContext = Params.UpdateContext;
        LayeredBoneBlend = Params.LayeredBoneBlend;
    
        return Params.ReturnValue;
    }

    FLinkedAnimGraphReference ULinkedAnimGraphLibrary::ConvertToLinkedAnimGraph(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.LinkedAnimGraphLibrary.ConvertToLinkedAnimGraph");
    
        ULinkedAnimGraphLibrary___ConvertToLinkedAnimGraph_Params Params{};
        Params.Node = Node;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        Result = Params.Result;
    
        return Params.ReturnValue;
    }

    void ULinkedAnimGraphLibrary::ConvertToLinkedAnimGraphPure(FAnimNodeReference& Node, FLinkedAnimGraphReference& LinkedAnimGraph, bool& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.LinkedAnimGraphLibrary.ConvertToLinkedAnimGraphPure");
    
        ULinkedAnimGraphLibrary___ConvertToLinkedAnimGraphPure_Params Params{};
        Params.Node = Node;
        Params.LinkedAnimGraph = LinkedAnimGraph;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        LinkedAnimGraph = Params.LinkedAnimGraph;
        Result = Params.Result;
    }

    UAnimInstance* ULinkedAnimGraphLibrary::GetLinkedAnimInstance(FLinkedAnimGraphReference& Node)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.LinkedAnimGraphLibrary.GetLinkedAnimInstance");
    
        ULinkedAnimGraphLibrary___GetLinkedAnimInstance_Params Params{};
        Params.Node = Node;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
    
        return Params.ReturnValue;
    }

    bool ULinkedAnimGraphLibrary::HasLinkedAnimInstance(FLinkedAnimGraphReference& Node)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.LinkedAnimGraphLibrary.HasLinkedAnimInstance");
    
        ULinkedAnimGraphLibrary___HasLinkedAnimInstance_Params Params{};
        Params.Node = Node;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
    
        return Params.ReturnValue;
    }

    FMirrorAnimNodeReference UMirrorAnimLibrary::ConvertToMirrorNode(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.MirrorAnimLibrary.ConvertToMirrorNode");
    
        UMirrorAnimLibrary___ConvertToMirrorNode_Params Params{};
        Params.Node = Node;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        Result = Params.Result;
    
        return Params.ReturnValue;
    }

    void UMirrorAnimLibrary::ConvertToMirrorNodePure(FAnimNodeReference& Node, FMirrorAnimNodeReference& MirrorNode, bool& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.MirrorAnimLibrary.ConvertToMirrorNodePure");
    
        UMirrorAnimLibrary___ConvertToMirrorNodePure_Params Params{};
        Params.Node = Node;
        Params.MirrorNode = MirrorNode;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        MirrorNode = Params.MirrorNode;
        Result = Params.Result;
    }

    bool UMirrorAnimLibrary::GetMirror(FMirrorAnimNodeReference& MirrorNode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.MirrorAnimLibrary.GetMirror");
    
        UMirrorAnimLibrary___GetMirror_Params Params{};
        Params.MirrorNode = MirrorNode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        MirrorNode = Params.MirrorNode;
    
        return Params.ReturnValue;
    }

    UMirrorDataTable* UMirrorAnimLibrary::GetMirrorDataTable(FMirrorAnimNodeReference& MirrorNode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.MirrorAnimLibrary.GetMirrorDataTable");
    
        UMirrorAnimLibrary___GetMirrorDataTable_Params Params{};
        Params.MirrorNode = MirrorNode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        MirrorNode = Params.MirrorNode;
    
        return Params.ReturnValue;
    }

    float UMirrorAnimLibrary::GetMirrorTransitionBlendTime(FMirrorAnimNodeReference& MirrorNode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.MirrorAnimLibrary.GetMirrorTransitionBlendTime");
    
        UMirrorAnimLibrary___GetMirrorTransitionBlendTime_Params Params{};
        Params.MirrorNode = MirrorNode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        MirrorNode = Params.MirrorNode;
    
        return Params.ReturnValue;
    }

    FMirrorAnimNodeReference UMirrorAnimLibrary::SetMirror(FMirrorAnimNodeReference& MirrorNode, bool bInMirror)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.MirrorAnimLibrary.SetMirror");
    
        UMirrorAnimLibrary___SetMirror_Params Params{};
        Params.MirrorNode = MirrorNode;
        Params.bInMirror = bInMirror;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        MirrorNode = Params.MirrorNode;
    
        return Params.ReturnValue;
    }

    FMirrorAnimNodeReference UMirrorAnimLibrary::SetMirrorTransitionBlendTime(FMirrorAnimNodeReference& MirrorNode, float InBlendTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.MirrorAnimLibrary.SetMirrorTransitionBlendTime");
    
        UMirrorAnimLibrary___SetMirrorTransitionBlendTime_Params Params{};
        Params.MirrorNode = MirrorNode;
        Params.InBlendTime = InBlendTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        MirrorNode = Params.MirrorNode;
    
        return Params.ReturnValue;
    }

    FModifyCurveAnimNodeReference UModifyCurveAnimLibrary::ConvertToModifyCurveNode(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.ModifyCurveAnimLibrary.ConvertToModifyCurveNode");
    
        UModifyCurveAnimLibrary___ConvertToModifyCurveNode_Params Params{};
        Params.Node = Node;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        Result = Params.Result;
    
        return Params.ReturnValue;
    }

    void UModifyCurveAnimLibrary::ConvertToModifyCurveNodePure(FAnimNodeReference& Node, FModifyCurveAnimNodeReference& ModifyCurveNode, bool& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.ModifyCurveAnimLibrary.ConvertToModifyCurveNodePure");
    
        UModifyCurveAnimLibrary___ConvertToModifyCurveNodePure_Params Params{};
        Params.Node = Node;
        Params.ModifyCurveNode = ModifyCurveNode;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        ModifyCurveNode = Params.ModifyCurveNode;
        Result = Params.Result;
    }

    float UModifyCurveAnimLibrary::GetAlpha(FModifyCurveAnimNodeReference& ModifyCurveNode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.ModifyCurveAnimLibrary.GetAlpha");
    
        UModifyCurveAnimLibrary___GetAlpha_Params Params{};
        Params.ModifyCurveNode = ModifyCurveNode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ModifyCurveNode = Params.ModifyCurveNode;
    
        return Params.ReturnValue;
    }

    EModifyCurveApplyMode UModifyCurveAnimLibrary::GetApplyMode(FModifyCurveAnimNodeReference& ModifyCurveNode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.ModifyCurveAnimLibrary.GetApplyMode");
    
        UModifyCurveAnimLibrary___GetApplyMode_Params Params{};
        Params.ModifyCurveNode = ModifyCurveNode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ModifyCurveNode = Params.ModifyCurveNode;
    
        return Params.ReturnValue;
    }

    FModifyCurveAnimNodeReference UModifyCurveAnimLibrary::SetAlpha(FModifyCurveAnimNodeReference& ModifyCurveNode, float InAlpha)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.ModifyCurveAnimLibrary.SetAlpha");
    
        UModifyCurveAnimLibrary___SetAlpha_Params Params{};
        Params.ModifyCurveNode = ModifyCurveNode;
        Params.InAlpha = InAlpha;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ModifyCurveNode = Params.ModifyCurveNode;
    
        return Params.ReturnValue;
    }

    FModifyCurveAnimNodeReference UModifyCurveAnimLibrary::SetApplyMode(FModifyCurveAnimNodeReference& ModifyCurveNode, EModifyCurveApplyMode InMode)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.ModifyCurveAnimLibrary.SetApplyMode");
    
        UModifyCurveAnimLibrary___SetApplyMode_Params Params{};
        Params.ModifyCurveNode = ModifyCurveNode;
        Params.InMode = InMode;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ModifyCurveNode = Params.ModifyCurveNode;
    
        return Params.ReturnValue;
    }

    FModifyCurveAnimNodeReference UModifyCurveAnimLibrary::SetCurveMap(FModifyCurveAnimNodeReference& ModifyCurveNode, TMap<FName, float>& InCurveMap)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.ModifyCurveAnimLibrary.SetCurveMap");
    
        UModifyCurveAnimLibrary___SetCurveMap_Params Params{};
        Params.ModifyCurveNode = ModifyCurveNode;
        Params.InCurveMap = InCurveMap;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        ModifyCurveNode = Params.ModifyCurveNode;
        InCurveMap = Params.InCurveMap;
    
        return Params.ReturnValue;
    }

    UPlayMontageCallbackProxy* UPlayMontageCallbackProxy::CreateProxyObjectForPlayMontage(USkeletalMeshComponent* InSkeletalMeshComponent, UAnimMontage* MontageToPlay, float PlayRate, float StartingPosition, FName StartingSection, bool bShouldStopAllMontages)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.PlayMontageCallbackProxy.CreateProxyObjectForPlayMontage");
    
        UPlayMontageCallbackProxy___CreateProxyObjectForPlayMontage_Params Params{};
        Params.InSkeletalMeshComponent = InSkeletalMeshComponent;
        Params.MontageToPlay = MontageToPlay;
        Params.PlayRate = PlayRate;
        Params.StartingPosition = StartingPosition;
        Params.StartingSection = StartingSection;
        Params.bShouldStopAllMontages = bShouldStopAllMontages;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UPlayMontageCallbackProxy::OnMontageBlendingOut(UAnimMontage* Montage, bool bInterrupted)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageBlendingOut");
    
        UPlayMontageCallbackProxy___OnMontageBlendingOut_Params Params{};
        Params.Montage = Montage;
        Params.bInterrupted = bInterrupted;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPlayMontageCallbackProxy::OnMontageEnded(UAnimMontage* Montage, bool bInterrupted)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageEnded");
    
        UPlayMontageCallbackProxy___OnMontageEnded_Params Params{};
        Params.Montage = Montage;
        Params.bInterrupted = bInterrupted;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UPlayMontageCallbackProxy::OnNotifyBeginReceived(FName NotifyName, FBranchingPointNotifyPayload& BranchingPointNotifyPayload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyBeginReceived");
    
        UPlayMontageCallbackProxy___OnNotifyBeginReceived_Params Params{};
        Params.NotifyName = NotifyName;
        Params.BranchingPointNotifyPayload = BranchingPointNotifyPayload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BranchingPointNotifyPayload = Params.BranchingPointNotifyPayload;
    }

    void UPlayMontageCallbackProxy::OnNotifyEndReceived(FName NotifyName, FBranchingPointNotifyPayload& BranchingPointNotifyPayload)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyEndReceived");
    
        UPlayMontageCallbackProxy___OnNotifyEndReceived_Params Params{};
        Params.NotifyName = NotifyName;
        Params.BranchingPointNotifyPayload = BranchingPointNotifyPayload;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        BranchingPointNotifyPayload = Params.BranchingPointNotifyPayload;
    }

    FSequenceEvaluatorReference USequenceEvaluatorLibrary::AdvanceTime(FAnimUpdateContext& UpdateContext, FSequenceEvaluatorReference& SequenceEvaluator, float PlayRate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequenceEvaluatorLibrary.AdvanceTime");
    
        USequenceEvaluatorLibrary___AdvanceTime_Params Params{};
        Params.UpdateContext = UpdateContext;
        Params.SequenceEvaluator = SequenceEvaluator;
        Params.PlayRate = PlayRate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        UpdateContext = Params.UpdateContext;
        SequenceEvaluator = Params.SequenceEvaluator;
    
        return Params.ReturnValue;
    }

    FSequenceEvaluatorReference USequenceEvaluatorLibrary::ConvertToSequenceEvaluator(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequenceEvaluatorLibrary.ConvertToSequenceEvaluator");
    
        USequenceEvaluatorLibrary___ConvertToSequenceEvaluator_Params Params{};
        Params.Node = Node;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        Result = Params.Result;
    
        return Params.ReturnValue;
    }

    void USequenceEvaluatorLibrary::ConvertToSequenceEvaluatorPure(FAnimNodeReference& Node, FSequenceEvaluatorReference& SequenceEvaluator, bool& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequenceEvaluatorLibrary.ConvertToSequenceEvaluatorPure");
    
        USequenceEvaluatorLibrary___ConvertToSequenceEvaluatorPure_Params Params{};
        Params.Node = Node;
        Params.SequenceEvaluator = SequenceEvaluator;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        SequenceEvaluator = Params.SequenceEvaluator;
        Result = Params.Result;
    }

    float USequenceEvaluatorLibrary::GetAccumulatedTime(FSequenceEvaluatorReference& SequenceEvaluator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequenceEvaluatorLibrary.GetAccumulatedTime");
    
        USequenceEvaluatorLibrary___GetAccumulatedTime_Params Params{};
        Params.SequenceEvaluator = SequenceEvaluator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SequenceEvaluator = Params.SequenceEvaluator;
    
        return Params.ReturnValue;
    }

    UAnimSequenceBase* USequenceEvaluatorLibrary::GetSequence(FSequenceEvaluatorReference& SequenceEvaluator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequenceEvaluatorLibrary.GetSequence");
    
        USequenceEvaluatorLibrary___GetSequence_Params Params{};
        Params.SequenceEvaluator = SequenceEvaluator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SequenceEvaluator = Params.SequenceEvaluator;
    
        return Params.ReturnValue;
    }

    FSequenceEvaluatorReference USequenceEvaluatorLibrary::SetExplicitFrame(FSequenceEvaluatorReference& SequenceEvaluator, int32 Frame)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequenceEvaluatorLibrary.SetExplicitFrame");
    
        USequenceEvaluatorLibrary___SetExplicitFrame_Params Params{};
        Params.SequenceEvaluator = SequenceEvaluator;
        Params.Frame = Frame;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SequenceEvaluator = Params.SequenceEvaluator;
    
        return Params.ReturnValue;
    }

    FSequenceEvaluatorReference USequenceEvaluatorLibrary::SetExplicitTime(FSequenceEvaluatorReference& SequenceEvaluator, float time)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequenceEvaluatorLibrary.SetExplicitTime");
    
        USequenceEvaluatorLibrary___SetExplicitTime_Params Params{};
        Params.SequenceEvaluator = SequenceEvaluator;
        Params.time = time;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SequenceEvaluator = Params.SequenceEvaluator;
    
        return Params.ReturnValue;
    }

    FSequenceEvaluatorReference USequenceEvaluatorLibrary::SetSequence(FSequenceEvaluatorReference& SequenceEvaluator, UAnimSequenceBase* Sequence)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequenceEvaluatorLibrary.SetSequence");
    
        USequenceEvaluatorLibrary___SetSequence_Params Params{};
        Params.SequenceEvaluator = SequenceEvaluator;
        Params.Sequence = Sequence;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SequenceEvaluator = Params.SequenceEvaluator;
    
        return Params.ReturnValue;
    }

    FSequenceEvaluatorReference USequenceEvaluatorLibrary::SetSequenceWithInertialBlending(FAnimUpdateContext& UpdateContext, FSequenceEvaluatorReference& SequenceEvaluator, UAnimSequenceBase* Sequence, float BlendTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequenceEvaluatorLibrary.SetSequenceWithInertialBlending");
    
        USequenceEvaluatorLibrary___SetSequenceWithInertialBlending_Params Params{};
        Params.UpdateContext = UpdateContext;
        Params.SequenceEvaluator = SequenceEvaluator;
        Params.Sequence = Sequence;
        Params.BlendTime = BlendTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        UpdateContext = Params.UpdateContext;
        SequenceEvaluator = Params.SequenceEvaluator;
    
        return Params.ReturnValue;
    }

    float USequencePlayerLibrary::ComputePlayRateFromDuration(FSequencePlayerReference& SequencePlayer, float duration)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequencePlayerLibrary.ComputePlayRateFromDuration");
    
        USequencePlayerLibrary___ComputePlayRateFromDuration_Params Params{};
        Params.SequencePlayer = SequencePlayer;
        Params.duration = duration;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SequencePlayer = Params.SequencePlayer;
    
        return Params.ReturnValue;
    }

    FSequencePlayerReference USequencePlayerLibrary::ConvertToSequencePlayer(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequencePlayerLibrary.ConvertToSequencePlayer");
    
        USequencePlayerLibrary___ConvertToSequencePlayer_Params Params{};
        Params.Node = Node;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        Result = Params.Result;
    
        return Params.ReturnValue;
    }

    void USequencePlayerLibrary::ConvertToSequencePlayerPure(FAnimNodeReference& Node, FSequencePlayerReference& SequencePlayer, bool& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequencePlayerLibrary.ConvertToSequencePlayerPure");
    
        USequencePlayerLibrary___ConvertToSequencePlayerPure_Params Params{};
        Params.Node = Node;
        Params.SequencePlayer = SequencePlayer;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        SequencePlayer = Params.SequencePlayer;
        Result = Params.Result;
    }

    float USequencePlayerLibrary::GetAccumulatedTime(FSequencePlayerReference& SequencePlayer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequencePlayerLibrary.GetAccumulatedTime");
    
        USequencePlayerLibrary___GetAccumulatedTime_Params Params{};
        Params.SequencePlayer = SequencePlayer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SequencePlayer = Params.SequencePlayer;
    
        return Params.ReturnValue;
    }

    bool USequencePlayerLibrary::GetLoopAnimation(FSequencePlayerReference& SequencePlayer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequencePlayerLibrary.GetLoopAnimation");
    
        USequencePlayerLibrary___GetLoopAnimation_Params Params{};
        Params.SequencePlayer = SequencePlayer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SequencePlayer = Params.SequencePlayer;
    
        return Params.ReturnValue;
    }

    float USequencePlayerLibrary::GetPlayRate(FSequencePlayerReference& SequencePlayer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequencePlayerLibrary.GetPlayRate");
    
        USequencePlayerLibrary___GetPlayRate_Params Params{};
        Params.SequencePlayer = SequencePlayer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SequencePlayer = Params.SequencePlayer;
    
        return Params.ReturnValue;
    }

    FSequencePlayerReference USequencePlayerLibrary::GetSequence(FSequencePlayerReference& SequencePlayer, UAnimSequenceBase*& SequenceBase)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequencePlayerLibrary.GetSequence");
    
        USequencePlayerLibrary___GetSequence_Params Params{};
        Params.SequencePlayer = SequencePlayer;
        Params.SequenceBase = SequenceBase;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SequencePlayer = Params.SequencePlayer;
        SequenceBase = Params.SequenceBase;
    
        return Params.ReturnValue;
    }

    UAnimSequenceBase* USequencePlayerLibrary::GetSequencePure(FSequencePlayerReference& SequencePlayer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequencePlayerLibrary.GetSequencePure");
    
        USequencePlayerLibrary___GetSequencePure_Params Params{};
        Params.SequencePlayer = SequencePlayer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SequencePlayer = Params.SequencePlayer;
    
        return Params.ReturnValue;
    }

    float USequencePlayerLibrary::GetStartPosition(FSequencePlayerReference& SequencePlayer)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequencePlayerLibrary.GetStartPosition");
    
        USequencePlayerLibrary___GetStartPosition_Params Params{};
        Params.SequencePlayer = SequencePlayer;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SequencePlayer = Params.SequencePlayer;
    
        return Params.ReturnValue;
    }

    FSequencePlayerReference USequencePlayerLibrary::SetAccumulatedTime(FSequencePlayerReference& SequencePlayer, float time)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequencePlayerLibrary.SetAccumulatedTime");
    
        USequencePlayerLibrary___SetAccumulatedTime_Params Params{};
        Params.SequencePlayer = SequencePlayer;
        Params.time = time;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SequencePlayer = Params.SequencePlayer;
    
        return Params.ReturnValue;
    }

    FSequencePlayerReference USequencePlayerLibrary::SetPlayRate(FSequencePlayerReference& SequencePlayer, float PlayRate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequencePlayerLibrary.SetPlayRate");
    
        USequencePlayerLibrary___SetPlayRate_Params Params{};
        Params.SequencePlayer = SequencePlayer;
        Params.PlayRate = PlayRate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SequencePlayer = Params.SequencePlayer;
    
        return Params.ReturnValue;
    }

    FSequencePlayerReference USequencePlayerLibrary::SetSequence(FSequencePlayerReference& SequencePlayer, UAnimSequenceBase* Sequence)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequencePlayerLibrary.SetSequence");
    
        USequencePlayerLibrary___SetSequence_Params Params{};
        Params.SequencePlayer = SequencePlayer;
        Params.Sequence = Sequence;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SequencePlayer = Params.SequencePlayer;
    
        return Params.ReturnValue;
    }

    FSequencePlayerReference USequencePlayerLibrary::SetSequenceWithInertialBlending(FAnimUpdateContext& UpdateContext, FSequencePlayerReference& SequencePlayer, UAnimSequenceBase* Sequence, float BlendTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequencePlayerLibrary.SetSequenceWithInertialBlending");
    
        USequencePlayerLibrary___SetSequenceWithInertialBlending_Params Params{};
        Params.UpdateContext = UpdateContext;
        Params.SequencePlayer = SequencePlayer;
        Params.Sequence = Sequence;
        Params.BlendTime = BlendTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        UpdateContext = Params.UpdateContext;
        SequencePlayer = Params.SequencePlayer;
    
        return Params.ReturnValue;
    }

    FSequencePlayerReference USequencePlayerLibrary::SetStartPosition(FSequencePlayerReference& SequencePlayer, float StartPosition)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequencePlayerLibrary.SetStartPosition");
    
        USequencePlayerLibrary___SetStartPosition_Params Params{};
        Params.SequencePlayer = SequencePlayer;
        Params.StartPosition = StartPosition;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SequencePlayer = Params.SequencePlayer;
    
        return Params.ReturnValue;
    }

    bool ISequencerAnimationOverride::AllowsCinematicOverride()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequencerAnimationOverride.AllowsCinematicOverride");
    
        ISequencerAnimationOverride___AllowsCinematicOverride_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FName> ISequencerAnimationOverride::GetSequencerAnimSlotNames()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SequencerAnimationOverride.GetSequencerAnimSlotNames");
    
        ISequencerAnimationOverride___GetSequencerAnimSlotNames_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FSkeletalControlReference USkeletalControlLibrary::ConvertToSkeletalControl(FAnimNodeReference& Node, EAnimNodeReferenceConversionResult& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SkeletalControlLibrary.ConvertToSkeletalControl");
    
        USkeletalControlLibrary___ConvertToSkeletalControl_Params Params{};
        Params.Node = Node;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        Result = Params.Result;
    
        return Params.ReturnValue;
    }

    void USkeletalControlLibrary::ConvertToSkeletalControlPure(FAnimNodeReference& Node, FSkeletalControlReference& SkeletalControl, bool& Result)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SkeletalControlLibrary.ConvertToSkeletalControlPure");
    
        USkeletalControlLibrary___ConvertToSkeletalControlPure_Params Params{};
        Params.Node = Node;
        Params.SkeletalControl = SkeletalControl;
        Params.Result = Result;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Node = Params.Node;
        SkeletalControl = Params.SkeletalControl;
        Result = Params.Result;
    }

    float USkeletalControlLibrary::GetAlpha(FSkeletalControlReference& SkeletalControl)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SkeletalControlLibrary.GetAlpha");
    
        USkeletalControlLibrary___GetAlpha_Params Params{};
        Params.SkeletalControl = SkeletalControl;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SkeletalControl = Params.SkeletalControl;
    
        return Params.ReturnValue;
    }

    FSkeletalControlReference USkeletalControlLibrary::SetAlpha(FSkeletalControlReference& SkeletalControl, float Alpha)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimGraphRuntime.SkeletalControlLibrary.SetAlpha");
    
        USkeletalControlLibrary___SetAlpha_Params Params{};
        Params.SkeletalControl = SkeletalControl;
        Params.Alpha = Alpha;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SkeletalControl = Params.SkeletalControl;
    
        return Params.ReturnValue;
    }

} // namespace UE

