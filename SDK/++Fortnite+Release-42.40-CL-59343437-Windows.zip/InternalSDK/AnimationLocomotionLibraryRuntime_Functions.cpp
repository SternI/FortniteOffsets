/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimationLocomotionLibraryRuntime_Functions
 * ============================================================
 */

#include "AnimationLocomotionLibraryRuntime_Functions.hpp"

namespace UE
{

    FVector UAnimCharacterMovementLibrary::PredictGroundMovementPivotLocation(FVector& Acceleration, FVector& Velocity, float GroundFriction)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationLocomotionLibraryRuntime.AnimCharacterMovementLibrary.PredictGroundMovementPivotLocation");
    
        UAnimCharacterMovementLibrary___PredictGroundMovementPivotLocation_Params Params{};
        Params.Acceleration = Acceleration;
        Params.Velocity = Velocity;
        Params.GroundFriction = GroundFriction;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Acceleration = Params.Acceleration;
        Velocity = Params.Velocity;
    
        return Params.ReturnValue;
    }

    FVector UAnimCharacterMovementLibrary::PredictGroundMovementStopLocation(FVector& Velocity, bool bUseSeparateBrakingFriction, float BrakingFriction, float GroundFriction, float BrakingFrictionFactor, float BrakingDecelerationWalking)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationLocomotionLibraryRuntime.AnimCharacterMovementLibrary.PredictGroundMovementStopLocation");
    
        UAnimCharacterMovementLibrary___PredictGroundMovementStopLocation_Params Params{};
        Params.Velocity = Velocity;
        Params.bUseSeparateBrakingFriction = bUseSeparateBrakingFriction;
        Params.BrakingFriction = BrakingFriction;
        Params.GroundFriction = GroundFriction;
        Params.BrakingFrictionFactor = BrakingFrictionFactor;
        Params.BrakingDecelerationWalking = BrakingDecelerationWalking;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Velocity = Params.Velocity;
    
        return Params.ReturnValue;
    }

    FSequenceEvaluatorReference UAnimDistanceMatchingLibrary::AdvanceTimeByDistanceMatching(FAnimUpdateContext& UpdateContext, FSequenceEvaluatorReference& SequenceEvaluator, float DistanceTraveled, FName DistanceCurveName, FVector2D PlayRateClamp)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationLocomotionLibraryRuntime.AnimDistanceMatchingLibrary.AdvanceTimeByDistanceMatching");
    
        UAnimDistanceMatchingLibrary___AdvanceTimeByDistanceMatching_Params Params{};
        Params.UpdateContext = UpdateContext;
        Params.SequenceEvaluator = SequenceEvaluator;
        Params.DistanceTraveled = DistanceTraveled;
        Params.DistanceCurveName = DistanceCurveName;
        Params.PlayRateClamp = PlayRateClamp;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        UpdateContext = Params.UpdateContext;
        SequenceEvaluator = Params.SequenceEvaluator;
    
        return Params.ReturnValue;
    }

    FSequenceEvaluatorReference UAnimDistanceMatchingLibrary::DistanceMatchToTarget(FSequenceEvaluatorReference& SequenceEvaluator, float DistanceToTarget, FName DistanceCurveName)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationLocomotionLibraryRuntime.AnimDistanceMatchingLibrary.DistanceMatchToTarget");
    
        UAnimDistanceMatchingLibrary___DistanceMatchToTarget_Params Params{};
        Params.SequenceEvaluator = SequenceEvaluator;
        Params.DistanceToTarget = DistanceToTarget;
        Params.DistanceCurveName = DistanceCurveName;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SequenceEvaluator = Params.SequenceEvaluator;
    
        return Params.ReturnValue;
    }

    FSequencePlayerReference UAnimDistanceMatchingLibrary::SetPlayrateToMatchSpeed(FSequencePlayerReference& SequencePlayer, float SpeedToMatch, FVector2D PlayRateClamp)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AnimationLocomotionLibraryRuntime.AnimDistanceMatchingLibrary.SetPlayrateToMatchSpeed");
    
        UAnimDistanceMatchingLibrary___SetPlayrateToMatchSpeed_Params Params{};
        Params.SequencePlayer = SequencePlayer;
        Params.SpeedToMatch = SpeedToMatch;
        Params.PlayRateClamp = PlayRateClamp;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        SequencePlayer = Params.SequencePlayer;
    
        return Params.ReturnValue;
    }

} // namespace UE

