/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AISpawner
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000300 (0x000090)
    class alignas(0x8) ACreaturePreviewActor : public AActor
    {
    public:
        FCharacterPreviewAssets PreviewAssets;                  // 0x000270 (0x000080)
        uint8                   UnknownData_0002F0[0x000010];   // 0x0002F0 (0x000010)
    };
    // Size: 0x000418 (0x000018)
    class alignas(0x8) AFortAthenaMutator_AISpawner : public AFortAthenaMutator_GameModeBase
    {
    public:
        void**  VTable_000400;                  // 0x000400 (0x000008) VTable [5 slots] -> 0x147DD730
        uint8   UnknownData_000408[0x000010];   // 0x000408 (0x000010)
    
    public: // Functions
        void    HandleCreativeModeratorModeActivatedChanged(AFortPlayerPawnAthena* Pawn); // 0x082060E8 [Final | Native | Protected]
        void    HandlePlayerPawnChanged(AFortPlayerPawn* NewPawn, AFortPlayerPawn* OldPawn, AFortPlayerController* PC); // 0x0820624E [Final | Native | Protected]
    };
    // Size: 0x000100 (0x000040)
    class alignas(0x8) UAISpawnerPreviewCosmeticDownloadComponent : public UActorComponent
    {
    public:
        UCosmeticDownloadCandidateComponentNPC* CandidateComponent;             // 0x0000C0 (0x000008) [Default: nullptr]
        uint8                                   UnknownData_0000C8[0x000038];   // 0x0000C8 (0x000038)
    };
    // Size: 0x0002D0 (0x000040)
    class alignas(0x8) UAISpawnerPreviewerComponent : public UChildActorComponent
    {
    public:
        UClass* PlayerMannequinClass;           // 0x000290 (0x000008) [Default: nullptr]
        UClass* AIPawnPreviewClass;             // 0x000298 (0x000008) [Default: nullptr]
        UClass* DefaultCustomAnimationBPClass;  // 0x0002A0 (0x000008) [Default: nullptr]
        float   RotationWhenFacingY;            // 0x0002A8 (0x000004) [Default: -90f]
        uint8   UnknownData_0002AC[0x000024];   // 0x0002AC (0x000024)
    
    public: // Functions
        void    ClearActorPreview(); // 0x10EF8086 [Final | Native | Protected | BlueprintCallable]
        void    ClearCIDPreview(); // 0x10EF8086 [Final | Native | Protected | BlueprintCallable]
        void    SetActorForPreview(UClass* InActorClass, TArray<UCustomCharacterPart*> OptionalCharacterParts); // 0x08205A60 [Final | Native | Protected | BlueprintCallable]
        void    SetCIDForPreview(UAthenaCharacterItemDefinition* InCID, TArray<FMcpVariantChannelInfo> InVariants); // 0x08205D62 [Final | Native | Protected | BlueprintCallable]
        void    SetPreviewByAssets(FCharacterPreviewAssets& PreviewAssets); // 0x10EF85B0 [Final | Native | Protected | HasOutParms | BlueprintCallable]
    };
    // Size: 0x000058 (0x000030)
    class alignas(0x8) UFortGameFeatureAction_AddSpawnerDeviceBindingTrack : public UGameFeatureAction
    {
    public:
        FSoftClassPath  SpawnerDeviceClassPath; // 0x000028 (0x000018)
        FSoftClassPath  BindingTrackClassPath;  // 0x000040 (0x000018)
    };
}

