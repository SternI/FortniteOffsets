/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:08
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioModulation_Functions
 * ============================================================
 */

#include "AudioModulation_Functions.hpp"

namespace UE
{

    bool UAudioModulationDestination::ClearModulator()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationDestination.ClearModulator");
    
        UAudioModulationDestination___ClearModulator_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    USoundModulatorBase* UAudioModulationDestination::GetModulator()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationDestination.GetModulator");
    
        UAudioModulationDestination___GetModulator_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAudioModulationDestination::GetValue()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationDestination.GetValue");
    
        UAudioModulationDestination___GetValue_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAudioModulationDestination::SetModulator(USoundModulatorBase* InModulator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationDestination.SetModulator");
    
        UAudioModulationDestination___SetModulator_Params Params{};
        Params.InModulator = InModulator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioModulationStatics::ActivateBus(UObject* WorldContextObject, USoundControlBus* Bus)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.ActivateBus");
    
        UAudioModulationStatics___ActivateBus_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Bus = Bus;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioModulationStatics::ActivateBusMix(UObject* WorldContextObject, USoundControlBusMix* Mix)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.ActivateBusMix");
    
        UAudioModulationStatics___ActivateBusMix_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Mix = Mix;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioModulationStatics::ActivateGenerator(UObject* WorldContextObject, USoundModulationGenerator* Generator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.ActivateGenerator");
    
        UAudioModulationStatics___ActivateGenerator_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Generator = Generator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioModulationStatics::ClearAllGlobalBusMixValues(UObject* WorldContextObject, float FadeTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.ClearAllGlobalBusMixValues");
    
        UAudioModulationStatics___ClearAllGlobalBusMixValues_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.FadeTime = FadeTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioModulationStatics::ClearGlobalBusMixValue(UObject* WorldContextObject, USoundControlBus* Bus, float FadeTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.ClearGlobalBusMixValue");
    
        UAudioModulationStatics___ClearGlobalBusMixValue_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Bus = Bus;
        Params.FadeTime = FadeTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    USoundModulationGeneratorADEnvelope* UAudioModulationStatics::CreateADEnvelopeGenerator(UObject* WorldContextObject, FName Name, FSoundModulationADEnvelopeParams& Params)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.CreateADEnvelopeGenerator");
    
        UAudioModulationStatics___CreateADEnvelopeGenerator_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Name = Name;
        Params.Params = Params;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Params = Params.Params;
    
        return Params.ReturnValue;
    }

    USoundControlBus* UAudioModulationStatics::CreateBus(UObject* WorldContextObject, FName Name, USoundModulationParameter* Parameter, bool Activate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.CreateBus");
    
        UAudioModulationStatics___CreateBus_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Name = Name;
        Params.Parameter = Parameter;
        Params.Activate = Activate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    USoundControlBusMix* UAudioModulationStatics::CreateBusMix(UObject* WorldContextObject, FName Name, TArray<FSoundControlBusMixStage> Stages, bool Activate, double duration, bool bRetriggerOnActivation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.CreateBusMix");
    
        UAudioModulationStatics___CreateBusMix_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Name = Name;
        Params.Stages = Stages;
        Params.Activate = Activate;
        Params.duration = duration;
        Params.bRetriggerOnActivation = bRetriggerOnActivation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    USoundControlBusMix* UAudioModulationStatics::CreateBusMixFromValue(UObject* WorldContextObject, FName Name, TArray<USoundControlBus*>& Buses, float Value, float AttackTime, float ReleaseTime, bool bActivate)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.CreateBusMixFromValue");
    
        UAudioModulationStatics___CreateBusMixFromValue_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Name = Name;
        Params.Buses = Buses;
        Params.Value = Value;
        Params.AttackTime = AttackTime;
        Params.ReleaseTime = ReleaseTime;
        Params.bActivate = bActivate;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Buses = Params.Buses;
    
        return Params.ReturnValue;
    }

    FSoundControlBusMixStage UAudioModulationStatics::CreateBusMixStage(UObject* WorldContextObject, USoundControlBus* Bus, float Value, float AttackTime, float ReleaseTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.CreateBusMixStage");
    
        UAudioModulationStatics___CreateBusMixStage_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Bus = Bus;
        Params.Value = Value;
        Params.AttackTime = AttackTime;
        Params.ReleaseTime = ReleaseTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    USoundModulationGeneratorEnvelopeFollower* UAudioModulationStatics::CreateEnvelopeFollowerGenerator(UObject* WorldContextObject, FName Name, FEnvelopeFollowerGeneratorParams Params)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.CreateEnvelopeFollowerGenerator");
    
        UAudioModulationStatics___CreateEnvelopeFollowerGenerator_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Name = Name;
        Params.Params = Params;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    USoundModulationGeneratorLFO* UAudioModulationStatics::CreateLFOGenerator(UObject* WorldContextObject, FName Name, FSoundModulationLFOParams Params)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.CreateLFOGenerator");
    
        UAudioModulationStatics___CreateLFOGenerator_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Name = Name;
        Params.Params = Params;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    UAudioModulationDestination* UAudioModulationStatics::CreateModulationDestination(UObject* WorldContextObject, FName Name, USoundModulatorBase* Modulator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.CreateModulationDestination");
    
        UAudioModulationStatics___CreateModulationDestination_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Name = Name;
        Params.Modulator = Modulator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    USoundModulationParameter* UAudioModulationStatics::CreateModulationParameter(UObject* WorldContextObject, FName Name, UClass* ParamClass, float DefaultValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.CreateModulationParameter");
    
        UAudioModulationStatics___CreateModulationParameter_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Name = Name;
        Params.ParamClass = ParamClass;
        Params.DefaultValue = DefaultValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioModulationStatics::DeactivateAllBusMixes(UObject* WorldContextObject)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.DeactivateAllBusMixes");
    
        UAudioModulationStatics___DeactivateAllBusMixes_Params Params{};
        Params.WorldContextObject = WorldContextObject;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioModulationStatics::DeactivateBus(UObject* WorldContextObject, USoundControlBus* Bus)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.DeactivateBus");
    
        UAudioModulationStatics___DeactivateBus_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Bus = Bus;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioModulationStatics::DeactivateBusMix(UObject* WorldContextObject, USoundControlBusMix* Mix)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.DeactivateBusMix");
    
        UAudioModulationStatics___DeactivateBusMix_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Mix = Mix;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioModulationStatics::DeactivateGenerator(UObject* WorldContextObject, USoundModulationGenerator* Generator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.DeactivateGenerator");
    
        UAudioModulationStatics___DeactivateGenerator_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Generator = Generator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    TSet<USoundModulatorBase*> UAudioModulationStatics::GetModulatorsFromDestination(FSoundModulationDestinationSettings& Destination)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.GetModulatorsFromDestination");
    
        UAudioModulationStatics___GetModulatorsFromDestination_Params Params{};
        Params.Destination = Destination;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        Destination = Params.Destination;
    
        return Params.ReturnValue;
    }

    float UAudioModulationStatics::GetModulatorValue(UObject* WorldContextObject, USoundModulatorBase* Modulator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.GetModulatorValue");
    
        UAudioModulationStatics___GetModulatorValue_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Modulator = Modulator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAudioModulationStatics::IsControlBusMixActive(UObject* WorldContextObject, USoundControlBusMix* Mix)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.IsControlBusMixActive");
    
        UAudioModulationStatics___IsControlBusMixActive_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Mix = Mix;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    TArray<FSoundControlBusMixStage> UAudioModulationStatics::LoadMixFromProfile(UObject* WorldContextObject, USoundControlBusMix* Mix, bool bActivate, int32 ProfileIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.LoadMixFromProfile");
    
        UAudioModulationStatics___LoadMixFromProfile_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Mix = Mix;
        Params.bActivate = bActivate;
        Params.ProfileIndex = ProfileIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioModulationStatics::SaveMixToProfile(UObject* WorldContextObject, USoundControlBusMix* Mix, int32 ProfileIndex)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.SaveMixToProfile");
    
        UAudioModulationStatics___SaveMixToProfile_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Mix = Mix;
        Params.ProfileIndex = ProfileIndex;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioModulationStatics::SetGlobalBusMixValue(UObject* WorldContextObject, USoundControlBus* Bus, float Value, float FadeTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.SetGlobalBusMixValue");
    
        UAudioModulationStatics___SetGlobalBusMixValue_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Bus = Bus;
        Params.Value = Value;
        Params.FadeTime = FadeTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioModulationStatics::UpdateMix(UObject* WorldContextObject, USoundControlBusMix* Mix, TArray<FSoundControlBusMixStage> Stages, float FadeTime, double duration, bool bRetriggerOnActivation)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.UpdateMix");
    
        UAudioModulationStatics___UpdateMix_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Mix = Mix;
        Params.Stages = Stages;
        Params.FadeTime = FadeTime;
        Params.duration = duration;
        Params.bRetriggerOnActivation = bRetriggerOnActivation;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioModulationStatics::UpdateMixByFilter(UObject* WorldContextObject, USoundControlBusMix* Mix, FString AddressFilter, UClass* ParamClassFilter, USoundModulationParameter* ParamFilter, float Value, float FadeTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.UpdateMixByFilter");
    
        UAudioModulationStatics___UpdateMixByFilter_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Mix = Mix;
        Params.AddressFilter = AddressFilter;
        Params.ParamClassFilter = ParamClassFilter;
        Params.ParamFilter = ParamFilter;
        Params.Value = Value;
        Params.FadeTime = FadeTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioModulationStatics::UpdateMixFromObject(UObject* WorldContextObject, USoundControlBusMix* Mix, float FadeTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.UpdateMixFromObject");
    
        UAudioModulationStatics___UpdateMixFromObject_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Mix = Mix;
        Params.FadeTime = FadeTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioModulationStatics::UpdateModulator(UObject* WorldContextObject, USoundModulatorBase* Modulator)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStatics.UpdateModulator");
    
        UAudioModulationStatics___UpdateModulator_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.Modulator = Modulator;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    FColor UAudioModulationStyle::GetControlBusColor()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStyle.GetControlBusColor");
    
        UAudioModulationStyle___GetControlBusColor_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FColor UAudioModulationStyle::GetControlBusMixColor()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStyle.GetControlBusMixColor");
    
        UAudioModulationStyle___GetControlBusMixColor_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FColor UAudioModulationStyle::GetModulationGeneratorColor()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStyle.GetModulationGeneratorColor");
    
        UAudioModulationStyle___GetModulationGeneratorColor_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FColor UAudioModulationStyle::GetParameterColor()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStyle.GetParameterColor");
    
        UAudioModulationStyle___GetParameterColor_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    FColor UAudioModulationStyle::GetPatchColor()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.AudioModulationStyle.GetPatchColor");
    
        UAudioModulationStyle___GetPatchColor_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void USoundControlBusMix::ActivateMix()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.SoundControlBusMix.ActivateMix");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void USoundControlBusMix::DeactivateAllMixes()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.SoundControlBusMix.DeactivateAllMixes");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void USoundControlBusMix::DeactivateMix()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.SoundControlBusMix.DeactivateMix");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void USoundControlBusMix::LoadMixFromProfile()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.SoundControlBusMix.LoadMixFromProfile");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void USoundControlBusMix::SaveMixToProfile()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.SoundControlBusMix.SaveMixToProfile");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void USoundControlBusMix::SoloMix()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioModulation.SoundControlBusMix.SoloMix");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

} // namespace UE

