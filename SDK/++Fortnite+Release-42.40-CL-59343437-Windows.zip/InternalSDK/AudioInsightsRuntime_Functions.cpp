/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioInsightsRuntime_Functions
 * ============================================================
 */

#include "AudioInsightsRuntime_Functions.hpp"

namespace UE
{

    void UAudioInsightsBlueprintLibrary::LogAudioInsightsEvent(UObject* WorldContextObject, FString EventName, USoundBase* SoundAsset, AActor* Actor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioInsightsRuntime.AudioInsightsBlueprintLibrary.LogAudioInsightsEvent");
    
        UAudioInsightsBlueprintLibrary___LogAudioInsightsEvent_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.EventName = EventName;
        Params.SoundAsset = SoundAsset;
        Params.Actor = Actor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioInsightsBlueprintLibrary::LogAudioInsightsEventForAudioComponent(UObject* WorldContextObject, FString EventName, UAudioComponent* AudioComponent)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioInsightsRuntime.AudioInsightsBlueprintLibrary.LogAudioInsightsEventForAudioComponent");
    
        UAudioInsightsBlueprintLibrary___LogAudioInsightsEventForAudioComponent_Params Params{};
        Params.WorldContextObject = WorldContextObject;
        Params.EventName = EventName;
        Params.AudioComponent = AudioComponent;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

} // namespace UE

