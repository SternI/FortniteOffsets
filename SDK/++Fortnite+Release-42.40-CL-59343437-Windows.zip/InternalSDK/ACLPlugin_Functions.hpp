/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:48
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ACLPlugin_Functions
 * ============================================================
 */

#include "ACLPlugin.hpp"

namespace UE
{

    struct UAnimationCompressionLibraryDatabase___GetVisualFidelity_Params
    {
        UAnimationCompressionLibraryDatabase*   DatabaseAsset;  // 0x000000 (0x000008) [Default: 0x14854900]
        ACLVisualFidelity                       ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: ACLVisualFidelity(49)]
    };

    struct UAnimationCompressionLibraryDatabase___SetVisualFidelity_Params
    {
        UObject*                                WorldContextObject; // 0x000000 (0x000008) [Default: 0x14854900]
        FLatentActionInfo                       LatentInfo;         // 0x000008 (0x000018)
        UAnimationCompressionLibraryDatabase*   DatabaseAsset;      // 0x000020 (0x000008) [Default: 0xC77E8DBB]
        ACLVisualFidelityChangeResult           Result;             // 0x000028 (0x000001) [OutParam] [Default: ACLVisualFidelityChangeResult(0)]
        ACLVisualFidelity                       VisualFidelity;     // 0x000029 (0x000001) [Default: ACLVisualFidelity(0)]
    };

} // namespace UE

