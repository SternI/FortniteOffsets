/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ArmoredBattleBusRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x001240 (0x0000D0)
    class alignas(0x8) UFortArmoredBattleBusPassengerAnimInstance : public UFortPlayerAnimInstanceProxy
    {
    public:
        FRotator                                PreviousVehicleRotator;             // 0x001170 (0x000018)
        float                                   SmoothedVehicleYawRate;             // 0x001188 (0x000004) [Default: 0f]
        int32                                   PawnSeat;                           // 0x00118C (0x000004) [Default: 0]
        bool                                    bIsFrontTurretPassenger;            // 0x001190 (0x000001) [Default: false]
        bool                                    bIsRearTurretPassenger;             // 0x001191 (0x000001) [Default: false]
        uint8                                   UnknownData_001192[0x000002];       // 0x001192 (0x000002)
        float                                   Speed;                              // 0x001194 (0x000004) [Default: 0f]
        float                                   YawDelta;                           // 0x001198 (0x000004) [Default: 0f]
        float                                   TurretYaw;                          // 0x00119C (0x000004) [Default: 0f]
        float                                   TurretPitch;                        // 0x0011A0 (0x000004) [Default: 0f]
        uint8                                   UnknownData_0011A4[0x000004];       // 0x0011A4 (0x000004)
        FRotator                                TurretYawRotator;                   // 0x0011A8 (0x000018)
        float                                   SlopeRollDegreeAngle;               // 0x0011C0 (0x000004) [Default: 0f]
        float                                   SlopePitchDegreeAngle;              // 0x0011C4 (0x000004) [Default: 0f]
        FVector                                 HandAttachL;                        // 0x0011C8 (0x000018)
        FVector                                 HandAttachR;                        // 0x0011E0 (0x000018)
        TEnumAsByte<ERelativeTransformSpace>    TransformSpace;                     // 0x0011F8 (0x000001) [Default: 0]
        uint8                                   UnknownData_0011F9[0x000003];       // 0x0011F9 (0x000003)
        float                                   UpdateYawDeltaSmoothedLerpRate;     // 0x0011FC (0x000004) [Default: 0.71f]
        int32                                   TurretPassengerFront;               // 0x001200 (0x000004) [Default: 1]
        int32                                   TurretPassengerRear;                // 0x001204 (0x000004) [Default: 2]
        FName                                   FrontFootBoneName;                  // 0x001208 (0x000004) [Default: FName(-953250373) -> L"Passenger_Foot"]
        FName                                   RearFootBoneName;                   // 0x00120C (0x000004) [Default: FName(-550597189) -> L"Passenger_Foot_Rear"]
        FName                                   GunHandAttachBoneName_FrontLeft;    // 0x001210 (0x000004) [Default: FName(-735146565) -> L"turret_fr_gun_hand_attach_l"]
        FName                                   GunHandAttachBoneName_RearLeft;     // 0x001214 (0x000004) [Default: FName(-1523675717) -> L"turret_bk_gun_hand_attach_l"]
        FName                                   GunHandAttachBoneName_FrontRight;   // 0x001218 (0x000004) [Default: FName(-1238463045) -> L"turret_fr_gun_hand_attach_r"]
        FName                                   GunHandAttachBoneName_RearRight;    // 0x00121C (0x000004) [Default: FName(-2026992197) -> L"turret_bk_gun_hand_attach_r"]
        FName                                   PassengerBoneName_Front;            // 0x001220 (0x000004) [Default: FName(1816346553) -> L"Passenger"]
        FName                                   PassengerBoneName_Rear;             // 0x001224 (0x000004) [Default: FName(-1741779525) -> L"Passenger_Rear"]
        float                                   TurretPitchDegMin;                  // 0x001228 (0x000004) [Default: -90f]
        float                                   TurretPitchDegMax;                  // 0x00122C (0x000004) [Default: 90f]
        float                                   LocalPlayerTurretPitchEaseRate;     // 0x001230 (0x000004) [Default: 0.95f]
        uint8                                   UnknownData_001234[0x00000C];       // 0x001234 (0x00000C)
    
    public: // Functions
        void        GenerateCharacterPitchAndYawForSlopedTerrain(AFortAthenaVehicle* VehicleActor, float& TurretYaw, float& TurretPitch, FRotator& PawnYawRotator); // 0x07F4C120 [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        FTransform  GetFootAttachTransform(USkeletalMeshComponent* BusMeshComponent); // 0x07F4C596 [Final | Native | Public | HasDefaults | BlueprintCallable]
        FVector     GetHandAttachLocation(USkeletalMeshComponent* BusMeshComponent, FName FrontHandAttachBoneName, FName RearHandAttachBoneName); // 0x07F4C7AE [Final | Native | Public | HasDefaults | BlueprintCallable]
        FTransform  GetPassengerTransform(USkeletalMeshComponent* BusMeshComponent); // 0x07F4CB90 [Final | Native | Public | HasDefaults | BlueprintCallable]
        FVector     UnrotateHandAttachLocation(FVector& HandLocation, FVector& FootLocation, FRotator& FootRotation); // 0x07F4CD90 [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        void        UpdateHandPositionsSlopeValues(USkeletalMeshComponent* BusMeshComponent); // 0x07F4D16E [Final | Native | Public | BlueprintCallable]
        void        UpdateSmoothedVehicleYawRate(AFortAthenaVehicle* VehicleActor); // 0x07F4D2DC [Final | Native | Public | BlueprintCallable]
        void        UpdateYawDeltaSmoothed(AFortAthenaVehicle* VehicleActor, FName SocketName, FRotator& NewRotation, float& SmoothedYawValue); // 0x07F4D44A [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
    };
    // Size: 0x000590 (0x000090)
    class alignas(0x8) UFortArmoredBattleBusVehicleAnimInstance : public UFortVehicleAnimInstance
    {
    public:
        float       FrontTurretAimPitch;            // 0x000500 (0x000004) [Default: 0f]
        float       RearTurretAimPitch;             // 0x000504 (0x000004) [Default: 0f]
        float       FrontYawDeltaSmoothed;          // 0x000508 (0x000004) [Default: 0f]
        float       RearYawDeltaSmoothed;           // 0x00050C (0x000004) [Default: 0f]
        float       SmoothedVehicleYawRate;         // 0x000510 (0x000004) [Default: 0f]
        float       FrontYawDeltaSmoothedAlpha;     // 0x000514 (0x000004) [Default: 0f]
        float       RearYawDeltaSmoothedAlpha;      // 0x000518 (0x000004) [Default: 0f]
        uint8       UnknownData_00051C[0x000004];   // 0x00051C (0x000004)
        FRotator    FrontWeaponYaw;                 // 0x000520 (0x000018)
        FRotator    RearWeaponYaw;                  // 0x000538 (0x000018)
        FRotator    PreviousVehicleRotator;         // 0x000550 (0x000018)
        bool        bHasFrontTurretPassenger;       // 0x000568 (0x000001) [Default: false]
        bool        bHasRearTurretPassenger;        // 0x000569 (0x000001) [Default: false]
        uint8       UnknownData_00056A[0x000002];   // 0x00056A (0x000002)
        float       NetworkEaseRate;                // 0x00056C (0x000004) [Default: 0.95f]
        float       UpdateYawDeltaSmoothedLerpRate; // 0x000570 (0x000004) [Default: 0.71f]
        int32       FrontPassengerSeatIndex;        // 0x000574 (0x000004) [Default: 1]
        int32       RearPassengerSeatIndex;         // 0x000578 (0x000004) [Default: 2]
        float       FrontPassengerYawOffset;        // 0x00057C (0x000004) [Default: 0f]
        float       RearPassengerYawOffset;         // 0x000580 (0x000004) [Default: 180f]
        FName       FrontPassengerBoneName;         // 0x000584 (0x000004) [Default: FName(1816346553) -> L"Passenger"]
        FName       RearPassengerBoneName;          // 0x000588 (0x000004) [Default: FName(-1741779525) -> L"Passenger_Rear"]
        uint8       UnknownData_00058C[0x000004];   // 0x00058C (0x000004)
    
    public: // Functions
        void    GetPitchAndYaw(AFortAthenaVehicle* VehicleActor, AFortPlayerPawn* GunnerActor, float& AdjustedPitch, float& AdjustedYaw, bool& bIsLocalPlayerControlled, FRotator& YawRotator); // 0x07F4DCEE [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        float   UpdateSmoothedVehicleYawRate(AFortAthenaVehicle* VehicleActor, FRotator PreviousRotator); // 0x07F4E310 [Final | Native | Public | HasDefaults | BlueprintCallable]
        void    UpdateTurretAimPitchWeaponYaw(AFortAthenaVehicle* OwnerVehicle, AFortPlayerPawn* GunnerActor, FName SocketName, float YawOffset, float& TurretAimPitch, float& YawDeltaSmoothed, FRotator& WeaponYaw); // 0x07F4E5A2 [Final | Native | Public | HasOutParms | HasDefaults | BlueprintCallable]
        float   UpdateYawDeltaSmoothed(AFortAthenaVehicle* VehicleActor, FName SocketName, FRotator NewRotation, float SmoothedYawValue); // 0x07F4EC96 [Final | Native | Public | HasDefaults | BlueprintCallable]
    };
}

