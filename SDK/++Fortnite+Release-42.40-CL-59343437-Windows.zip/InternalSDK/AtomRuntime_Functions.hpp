/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AtomRuntime_Functions
 * ============================================================
 */

#include "AtomRuntime.hpp"

namespace UE
{

    struct UAtomColorComponent___GetColorLUTIndex_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344834704]
    };

    struct UAtomColorComponent___SetColorLUTAtlas_Params
    {
        UAtomColorLUTAtlas* InColorLUTAtlas;    // 0x000000 (0x000008) [Default: 0x148DC290]
    };

    struct UAtomColorComponent___SetColorLUTTexture_Params
    {
        UTexture2D* InColorLUTTexture;  // 0x000000 (0x000008) [Default: 0x148DC290]
    };

    struct UAtomColorLUTAtlas___FindOrAddLUTIndex_Params
    {
        UTexture2D* InTexture;      // 0x000000 (0x000008) [Default: 0x148DC770]
        int32       ReturnValue;    // 0x000008 (0x000004) [ReturnValue] [Default: 49]
    };

    struct UAtomColorLUTAtlas___GetAtlasSize_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344835952]
    };

    struct UAtomColorLUTAtlas___GetLUTIndex_Params
    {
        UTexture2D* InTexture;      // 0x000000 (0x000008) [Default: 0x148DC770]
        int32       ReturnValue;    // 0x000008 (0x000004) [ReturnValue] [Default: 49]
    };

    struct UAtomColorThemeComponent___GetAtomColorThemeLibraries_Params
    {
        TArray<FName>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAtomColorThemeComponent___GetColorThemeIndex_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344836672]
    };

    struct UAtomColorThemeComponent___GetThemeNames_Params
    {
        TArray<FName>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAtomColorThemeComponent___SetColorThemeByName_Params
    {
        FName   Name;           // 0x000000 (0x000004) [Default: FName(344836672) -> L""]
        bool    ReturnValue;    // 0x000004 (0x000001) [ReturnValue] [Default: false]
    };

    struct UAtomColorThemeComponent___SetColorThemeByTexture_Params
    {
        UTexture2D* Texture;        // 0x000000 (0x000008) [Default: 0x148DCA40]
        bool        ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAtomColorThemeLibrary___GetAtlasDynamicTextureSize_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344837936]
    };

    struct UAtomColorThemeLibrary___GetAtlasSize_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344837936]
    };

    struct UAtomColorThemeLibrary___GetNumberOfStaticThemesRows_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344837936]
    };

    struct UAtomColorThemeLibrary___IsLUTTextureCompatible_Params
    {
        UTexture2D* LUTTexture;     // 0x000000 (0x000008) [Default: 0x148DCF30]
        bool        ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAtomConnectivityQueryBlueprintLibrary___GetClosestConnectionPointInActors_Params
    {
        TArray<AActor*> Actors;         // 0x000000 (0x000010) [OutParam]
        FVector         Location;       // 0x000010 (0x000018) [OutParam]
        FVector         ReturnValue;    // 0x000028 (0x000018) [ReturnValue]
    };

    struct UAtomModel___GetChildIdentifier_Params
    {
        int32   InChildIdx;                     // 0x000000 (0x000004) [Default: 344841376]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FString ReturnValue;                    // 0x000008 (0x000010) [ReturnValue] [Default: L""]
    };

    struct UAtomModel___GetGeneratedMergedMeshes_Params
    {
        TArray<TSoftObjectPtr<UStaticMesh>> ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAtomModel___GetModelName_Params
    {
        FString ReturnValue;    // 0x000000 (0x000010) [ReturnValue] [Default: L"??"]
    };

    struct UAtomModel___GetModelPath_Params
    {
        FString ReturnValue;    // 0x000000 (0x000010) [ReturnValue] [Default: L"??"]
    };

    struct UAtomModel___GetPartsCollection_Params
    {
        FAtomModelPartsCollection   ReturnValue;    // 0x000000 (0x000080) [ReturnValue]
    };

    struct UAtomModel___GetPrimitivesForChildArray_Params
    {
        int32                               InChildIdx;                     // 0x000000 (0x000004) [Default: 344841376]
        uint8                               UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FAtomModelPrimitiveInstance> OutPrimitives;                  // 0x000008 (0x000010) [OutParam]
    };

    struct UAtomModel___GetRootGroupPivot_Params
    {
        FVector ReturnValue;    // 0x000000 (0x000018) [ReturnValue]
    };

    struct UAtomModel___GetTextureForDecorationTextureName_Params
    {
        FString     TextureName;    // 0x000000 (0x000010) [Default: L"??"]
        UTexture*   ReturnValue;    // 0x000010 (0x000008) [ReturnValue] [Default: 0x19797DC0]
    };

    struct UAtomModelComponent___ModelSupportsMaterialInstancePayload_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAtomModelPartsCollectionConnectivity___GetTechnicHoleConnectivityState_Params
    {
        FAtomPartConnectivityFieldReference TechnicHolePartConnectivityRef; // 0x000000 (0x0000C0) [OutParam]
        FAtomPartConnectivityFieldReference ConnectedPartConnectivityRef;   // 0x0000C0 (0x0000C0) [OutParam]
        EFieldConnectResult                 ReturnValue;                    // 0x000180 (0x000001) [ReturnValue] [Default: EFieldConnectResult(208)]
    };

    struct UAtomModelPartsCollectionConnectivity___GetTechnicPinConnectivityStates_Params
    {
        FAtomPartConnectivityFieldReference         TechnicPinPartConnectivityRef;  // 0x000000 (0x0000C0) [OutParam]
        TArray<FAtomPartConnectivityFieldReference> ConnectedPartsConnectivityRef;  // 0x0000C0 (0x000010) [OutParam]
        TArray<EFieldConnectResult>                 ReturnValue;                    // 0x0000D0 (0x000010) [ReturnValue]
    };

    struct UAtomModelProcessor___IncrementProgress_Params
    {
        int32   NumSteps;                       // 0x000000 (0x000004) [Default: 344854128]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FString Message;                        // 0x000008 (0x000010) [Default: L""]
    };

    struct UAtomModelProcessor___OnGetProcessModelTargetAssetPath_Params
    {
        UAtomModel*                 Model;                          // 0x000000 (0x000008) [Default: 0x148E0E70]
        uint8                       UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        FAtomModelPartsCollection   AtomModelPartsCollection;       // 0x000010 (0x000080) [OutParam]
        FString                     ReturnValue;                    // 0x000090 (0x000010) [ReturnValue] [Default: L""]
    };

    struct UAtomModelProcessor___OnGetProcessPrimitiveTargetAssetPath_Params
    {
        UAtomModel*                     Model;                      // 0x000000 (0x000008) [Default: 0x148E0E70]
        UAtomPrimitive*                 Primitive;                  // 0x000008 (0x000008) [Default: 0xEF5D18DD00000031]
        FAtomModelPartsCollection       AtomModelPartsCollection;   // 0x000010 (0x000080) [OutParam]
        FAtomOnProcessPrimitiveSettings Settings;                   // 0x000090 (0x000018) [OutParam]
        FString                         ReturnValue;                // 0x0000A8 (0x000010) [ReturnValue] [Default: L"??"]
    };

    struct UAtomModelProcessor___OnGetTargetAssetPath_Params
    {
        UAtomModel*                 Model;                      // 0x000000 (0x000008) [Default: 0x148E0E70]
        UAtomPrimitive*             Primitive;                  // 0x000008 (0x000008) [Default: 0xEF5D18DD00000031]
        FAtomModelPartsCollection   AtomModelPartsCollection;   // 0x000010 (0x000080) [OutParam]
        FString                     ReturnValue;                // 0x000090 (0x000010) [ReturnValue] [Default: L""]
    };

    struct UAtomModelProcessor___OnProcessModel_Params
    {
        UAtomModel*                     Model;                          // 0x000000 (0x000008) [Default: 0x148E0E70]
        uint8                           UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        FAtomModelPartsCollection       AtomModelPartsCollection;       // 0x000010 (0x000080) [OutParam]
        TArray<TSoftObjectPtr<UObject>> ExistingObjects;                // 0x000090 (0x000010) [OutParam]
        FAtomProcessorResult            ReturnValue;                    // 0x0000A0 (0x000028) [ReturnValue]
    };

    struct UAtomModelProcessor___OnProcessPrimitive_Params
    {
        UAtomModel*                     DummyModel;                 // 0x000000 (0x000008) [Default: 0x148E0E70]
        UAtomPrimitive*                 Primitive;                  // 0x000008 (0x000008) [Default: 0xEF5D18DD00000031]
        FAtomModelPartsCollection       AtomModelPartsCollection;   // 0x000010 (0x000080) [OutParam]
        FAtomOnProcessPrimitiveSettings Settings;                   // 0x000090 (0x000018) [OutParam]
        FAtomProcessorResult            ReturnValue;                // 0x0000A8 (0x000028) [ReturnValue]
    };

    struct UAtomPartsCollectionBlueprintLibrary___AddPartInstance_Params
    {
        FAtomModelPartsCollection   PartCollection; // 0x000000 (0x000080) [OutParam]
        FAtomModelPartInstanceInfo  PartInstance;   // 0x000080 (0x0000B0) [OutParam]
    };

    struct UAtomPartsCollectionBlueprintLibrary___Conv_ModelPartGuidToString_Params
    {
        FAtomModelPartGuid  InModelPartGuid;                // 0x000000 (0x000014) [OutParam]
        uint8               UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        FString             ReturnValue;                    // 0x000018 (0x000010) [ReturnValue] [Default: L""]
    };

    struct UAtomPartsCollectionBlueprintLibrary___Conv_StringToModelPartGuid_Params
    {
        FString             InString;       // 0x000000 (0x000010) [Default: L"??"]
        FAtomModelPartGuid  ReturnValue;    // 0x000010 (0x000014) [ReturnValue]
    };

    struct UAtomPartsCollectionBlueprintLibrary___CreateColorInfoFromColorId_Params
    {
        int32                   ColorId;        // 0x000000 (0x000004) [Default: 319446880]
        FAtomModelPartColorInfo ReturnValue;    // 0x000004 (0x00000C) [ReturnValue]
    };

    struct UAtomPartsCollectionBlueprintLibrary___CreatePartsCollectionConnectivity_Params
    {
        FAtomModelPartsCollection               PartsCollection;                // 0x000000 (0x000080) [OutParam]
        UAtomModel*                             Model;                          // 0x000080 (0x000008) [Default: 0xEB5D18DD00000031]
        float                                   Scale;                          // 0x000088 (0x000004) [Default: 1.29752e-23f]
        uint8                                   UnknownData_00008C[0x000004];   // 0x00008C (0x000004)
        UAtomModelPartsCollectionConnectivity*  ReturnValue;                    // 0x000090 (0x000008) [ReturnValue] [Default: 0x19797BD0]
    };

    struct UAtomPartsCollectionBlueprintLibrary___FilterCommonPartsToStyle_Params
    {
        FAtomModelPartsCollection   PartsCollection;                // 0x000000 (0x000080) [OutParam]
        FName                       GeometryStyle;                  // 0x000080 (0x000004) [Default: FName(49) -> L""]
        uint8                       UnknownData_000084[0x00000C];   // 0x000084 (0x00000C)
        FAtomModelPartsCollection   ReturnValue;                    // 0x000090 (0x000080) [ReturnValue]
    };

    struct UAtomPartsCollectionBlueprintLibrary___FilterGroup_Params
    {
        UAtomModel*                 Model;                          // 0x000000 (0x000008) [Default: 0x130A5F60]
        uint8                       UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        FAtomModelPartsCollection   PartsCollectionToFilter;        // 0x000010 (0x000080) [OutParam]
        FString                     GroupName;                      // 0x000090 (0x000010) [Default: L""]
        FString                     NewPartsCollectionName;         // 0x0000A0 (0x000010) [Default: L""]
        FAtomModelPartsCollection   ReturnValue;                    // 0x0000B0 (0x000080) [ReturnValue]
    };

    struct UAtomPartsCollectionBlueprintLibrary___FilterNonTransparent_Params
    {
        FAtomModelPartsCollection   PartsCollectionToFilter;    // 0x000000 (0x000080) [OutParam]
        FString                     NewPartsCollectionName;     // 0x000080 (0x000010) [Default: L""]
        FAtomModelPartsCollection   ReturnValue;                // 0x000090 (0x000080) [ReturnValue]
    };

    struct UAtomPartsCollectionBlueprintLibrary___FilterSelectionSet_Params
    {
        FAtomModelPartsCollection   PartsCollectionToFilter;    // 0x000000 (0x000080) [OutParam]
        FString                     SelectionSetName;           // 0x000080 (0x000010) [Default: L""]
        FString                     NewPartsCollectionName;     // 0x000090 (0x000010) [Default: L""]
        FAtomModelPartsCollection   ReturnValue;                // 0x0000A0 (0x000080) [ReturnValue]
    };

    struct UAtomPartsCollectionBlueprintLibrary___FilterTransparent_Params
    {
        FAtomModelPartsCollection   PartsCollectionToFilter;    // 0x000000 (0x000080) [OutParam]
        FString                     NewPartsCollectionName;     // 0x000080 (0x000010) [Default: L""]
        FAtomModelPartsCollection   ReturnValue;                // 0x000090 (0x000080) [ReturnValue]
    };

    struct UAtomPartsCollectionBlueprintLibrary___GetModelPartGuidHash_Params
    {
        FAtomModelPartGuid  InModelPartGuid;    // 0x000000 (0x000014) [OutParam]
        int32               ReturnValue;        // 0x000014 (0x000004) [ReturnValue] [Default: 0]
    };

    struct UAtomPartsCollectionBlueprintLibrary___GetName_Params
    {
        FAtomModelPartsCollection   PartsCollection;    // 0x000000 (0x000080) [OutParam]
        FString                     ReturnValue;        // 0x000080 (0x000010) [ReturnValue] [Default: L""]
    };

    struct UAtomPartsCollectionBlueprintLibrary___GetParts_Params
    {
        FAtomModelPartsCollection           PartsCollection;    // 0x000000 (0x000080) [OutParam]
        TArray<FAtomModelPartInstanceInfo>  ReturnValue;        // 0x000080 (0x000010) [ReturnValue]
    };

    struct UAtomPartsCollectionBlueprintLibrary___GetPrimitiveCommonParts_Params
    {
        UAtomPrimitive*                     Primitive;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        double                              Scale;          // 0x000008 (0x000008) [Default: -4.20714e+223]
        TArray<FAtomCommonPartAndTransform> ReturnValue;    // 0x000010 (0x000010) [ReturnValue]
    };

    struct UAtomPartsCollectionBlueprintLibrary___InitializeCommonParts_Params
    {
        UAtomModelPartsCollectionConnectivity*  PartsCollectionConnectivity;    // 0x000000 (0x000008) [Default: 0x130A5F60]
        int32                                   CommonPartOptimizationFlags;    // 0x000008 (0x000004) [Default: 49]
    };

    struct UAtomPartsCollectionBlueprintLibrary___PrimitiveHasConsistentCommonPartStyles_Params
    {
        UAtomPrimitive* Primitive;      // 0x000000 (0x000008) [Default: 0x130A5F60]
        bool            ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAtomPartsCollectionBlueprintLibrary___RemovePartInstance_Params
    {
        FAtomModelPartsCollection   PartCollection; // 0x000000 (0x000080) [OutParam]
        FAtomModelPartGuid          PartInstanceId; // 0x000080 (0x000014) [OutParam]
    };

    struct UAtomPartsCollectionBlueprintLibrary___ReplacePartInstance_Params
    {
        FAtomModelPartsCollection   PartCollection;         // 0x000000 (0x000080) [OutParam]
        FAtomModelPartInstanceInfo  SourcePartInstance;     // 0x000080 (0x0000B0) [OutParam]
        FAtomModelPartGuid          TargetPartInstanceId;   // 0x000130 (0x000014) [OutParam]
    };

    struct UAtomPartsCollectionBlueprintLibrary___SetName_Params
    {
        FAtomModelPartsCollection   PartsCollection;    // 0x000000 (0x000080) [OutParam]
        FString                     Name;               // 0x000080 (0x000010) [Default: L""]
    };

    struct UAtomPlacementResultHelperLibrary___Break_Params
    {
        FAtomPlacementResult                            PlacementResult;        // 0x000000 (0x000410) [OutParam]
        FTransform                                      OutTransformDelta;      // 0x000410 (0x000060) [OutParam]
        TArray<TScriptInterface<IAtomRejectionReason>>  OutRejectionReasons;    // 0x000470 (0x000010) [OutParam]
    };

    struct IAtomPlacementTool___BeginUpdatingPlacement_Params
    {
        FPlacementOperation NewPlacementOperation;  // 0x000000 (0x000590) [OutParam]
        bool                ReturnValue;            // 0x000590 (0x000001) [ReturnValue] [Default: false]
    };

    struct IAtomPlacementTool___EndUpdatingPlacement_Params
    {
        bool    bCancelled; // 0x000000 (0x000001) [Default: true]
    };

    struct IAtomPlacementTool___GetPlacementRejectionReasons_Params
    {
        TArray<TScriptInterface<IAtomRejectionReason>>  ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct IAtomPlacementTool___RegisterAndConnectActor_Params
    {
        AActor* Actor;          // 0x000000 (0x000008) [Default: 0x12FAB170]
        bool    ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct IAtomPlacementTool___UpdatePlacement_Params
    {
        FPlacementContextData   ContextData;    // 0x000000 (0x0000F0) [OutParam]
        bool                    ReturnValue;    // 0x0000F0 (0x000001) [ReturnValue] [Default: false]
    };

    struct UAtomPrimitive___GetBounds_Params
    {
        float               Scale;                          // 0x000000 (0x000004) [Default: 1.43465e-26f]
        uint8               UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FBoxSphereBounds    ReturnValue;                    // 0x000008 (0x000038) [ReturnValue]
    };

    struct UAtomPrimitive___GetCenterOfMass_Params
    {
        float   Scale;                          // 0x000000 (0x000004) [Default: 1.43465e-26f]
        uint8   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FVector ReturnValue;                    // 0x000008 (0x000018) [ReturnValue]
    };

    struct UAtomPrimitive___GetDecorationSurfaceIndex_Params
    {
        FString SurfaceName;    // 0x000000 (0x000010) [Default: L"??"]
        int32   ReturnValue;    // 0x000010 (0x000004) [ReturnValue] [Default: 427389168]
    };

    struct UAtomPrimitive___GetExportStyleMaxLOD_Params
    {
        FString ExportStyle;    // 0x000000 (0x000010) [Default: L"??"]
        int32   ReturnValue;    // 0x000010 (0x000004) [ReturnValue] [Default: 427389168]
    };

    struct UAtomPrimitive___GetGeometryContainerForBestExportStyle_Params
    {
        TArray<FString>                     GeometryStylePriorityList;      // 0x000000 (0x000010) [OutParam]
        int32                               LODIndex;                       // 0x000010 (0x000004) [Default: 427389168]
        uint8                               UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        UAtomPrimitiveGeometryContainer*    ReturnValue;                    // 0x000018 (0x000008) [ReturnValue] [Default: 0x19797BD0]
    };

    struct UAtomPrimitive___GetGeometryContainerForExportStyle_Params
    {
        FString                             ExportStyleName;                // 0x000000 (0x000010) [Default: L"??"]
        FString                             FallbackExportStyleName;        // 0x000010 (0x000010) [Default: L""]
        int32                               LODIndex;                       // 0x000020 (0x000004) [Default: -1627288133]
        bool                                bUseFallbacks;                  // 0x000024 (0x000001) [Default: false]
        uint8                               UnknownData_000025[0x000003];   // 0x000025 (0x000003)
        UAtomPrimitiveGeometryContainer*    ReturnValue;                    // 0x000028 (0x000008) [ReturnValue] [Default: nullptr]
    };

    struct UAtomPrimitive___GetMainGroupName_Params
    {
        int32   MainGroupId;    // 0x000000 (0x000004) [Default: 344855760]
        FName   ReturnValue;    // 0x000004 (0x000004) [ReturnValue] [Default: NAME_None]
    };

    struct UAtomPrimitive___GetSubMainGroupName_Params
    {
        int32   SubMainGroupId; // 0x000000 (0x000004) [Default: 344855760]
        FName   ReturnValue;    // 0x000004 (0x000004) [ReturnValue] [Default: NAME_None]
    };

    struct UAtomPrimitive___IsFlexElement_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAtomPrimitive___LoadDetailTextureForExportStyle_Params
    {
        FString                         ExportStyle;                    // 0x000000 (0x000010) [Default: L"??"]
        int32                           LOD;                            // 0x000010 (0x000004) [Default: 427389168]
        EAtomPrimitiveDetailTextureType TextureType;                    // 0x000014 (0x000001) [Default: EAtomPrimitiveDetailTextureType(0)]
        uint8                           UnknownData_000015[0x000003];   // 0x000015 (0x000003)
        UTexture*                       ReturnValue;                    // 0x000018 (0x000008) [ReturnValue] [Default: 0x19797BD0]
    };

    struct UAtomPrimitive___LoadDetailTextureForExportStyleAndSection_Params
    {
        FString                         ExportStyle;                    // 0x000000 (0x000010) [Default: L"??"]
        int32                           LOD;                            // 0x000010 (0x000004) [Default: 427389168]
        EAtomPrimitiveDetailTextureType TextureType;                    // 0x000014 (0x000001) [Default: EAtomPrimitiveDetailTextureType(0)]
        EPrimitiveGeometrySectionFlag   Section;                        // 0x000015 (0x000001) [Default: EPrimitiveGeometrySectionFlag(0)]
        uint8                           UnknownData_000016[0x000002];   // 0x000016 (0x000002)
        UTexture*                       ReturnValue;                    // 0x000018 (0x000008) [ReturnValue] [Default: 0x19797BD0]
    };

    struct UAtomPrimitiveBlueprintLibrary___GetDefaultPrimitiveScale_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 1.74651e-27f]
    };

    struct UAtomPrimitiveGeometry___Append_Params
    {
        UAtomPrimitiveGeometry* GeometryToAppend;               // 0x000000 (0x000008) [Default: 0x148E2E80]
        uint8                   UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        FTransform3f            Transform;                      // 0x000010 (0x000030) [OutParam]
        UAtomPrimitiveGeometry* ReturnValue;                    // 0x000040 (0x000008) [ReturnValue] [Default: 0x7FE998670EB0]
    };

    struct UAtomPrimitiveGeometry___AppendAndWeld_Params
    {
        UAtomPrimitiveGeometry* GeometryToAppend;               // 0x000000 (0x000008) [Default: 0x148E2E80]
        uint8                   UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        FTransform3f            Transform;                      // 0x000010 (0x000030) [OutParam]
        UAtomPrimitiveGeometry* ReturnValue;                    // 0x000040 (0x000008) [ReturnValue] [Default: 0x7FE998670EB0]
    };

    struct UAtomPrimitiveGeometry___AttachVerticesToBoneIndex_Params
    {
        int32   BoneIndex;  // 0x000000 (0x000004) [Default: 344862336]
    };

    struct UAtomPrimitiveGeometry___AttachVerticesToNamedBone_Params
    {
        FString BoneName;   // 0x000000 (0x000010) [Default: L"??"]
    };

    struct UAtomPrimitiveGeometry___BakeScale_Params
    {
        float                   Scale;                          // 0x000000 (0x000004) [Default: 1.43567e-26f]
        uint8                   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UAtomPrimitiveGeometry* ReturnValue;                    // 0x000008 (0x000008) [ReturnValue] [Default: 0xE55D18DD00000031]
    };

    struct UAtomPrimitiveGeometry___BakeTransform_Params
    {
        FTransform3f            Transform;      // 0x000000 (0x000030) [OutParam]
        UAtomPrimitiveGeometry* ReturnValue;    // 0x000030 (0x000008) [ReturnValue] [Default: 0x700000007]
    };

    struct UAtomPrimitiveGeometry___BakeTransforms_Params
    {
        TArray<FTransform3f>    Transforms;     // 0x000000 (0x000010) [OutParam]
        UAtomPrimitiveGeometry* ReturnValue;    // 0x000010 (0x000008) [ReturnValue] [Default: 0x197A59B0]
    };

    struct UAtomPrimitiveGeometry___ConvertVertexColorsLinearToSRGB_Params
    {
        UAtomPrimitiveGeometry* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x148E2E80]
    };

    struct UAtomPrimitiveGeometry___CopyNormalMapsToUV0_Params
    {
        UAtomPrimitiveGeometry* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x148E2E80]
    };

    struct UAtomPrimitiveGeometry___CreateAtomGeometryFromCommonPart_Params
    {
        FString                 ExportStyleName;                // 0x000000 (0x000010) [Default: L"??"]
        EAtomCommonPartType     CommonPartType;                 // 0x000010 (0x000001) [Default: EAtomCommonPartType(176)]
        uint8                   UnknownData_000011[0x000003];   // 0x000011 (0x000003)
        int32                   LODIndex;                       // 0x000014 (0x000004) [Default: 0]
        FString                 CommonPartsMeshPath;            // 0x000018 (0x000010) [Default: L""]
        UAtomPrimitiveGeometry* ReturnValue;                    // 0x000028 (0x000008) [ReturnValue] [Default: 0x7FEA985A4EA0]
    };

    struct UAtomPrimitiveGeometry___CreateEmptyAtomGeometry_Params
    {
        int32                   NumberOfUVChannels;             // 0x000000 (0x000004) [Default: 344862336]
        uint8                   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UAtomPrimitiveGeometry* ReturnValue;                    // 0x000008 (0x000008) [ReturnValue] [Default: 0xE55D18DD00000031]
    };

    struct UAtomPrimitiveGeometry___DuplicateGeometry_Params
    {
        UAtomPrimitiveGeometry* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x148E2E80]
    };

    struct UAtomPrimitiveGeometry___GetBoneIndexForName_Params
    {
        FString BoneName;       // 0x000000 (0x000010) [Default: L"??"]
        int32   ReturnValue;    // 0x000010 (0x000004) [ReturnValue] [Default: 427448752]
    };

    struct UAtomPrimitiveGeometry___GetCommonPartBestExportStyle_Params
    {
        TArray<FString>     GeometryStylePriorityList;      // 0x000000 (0x000010) [OutParam]
        EAtomCommonPartType CommonPartType;                 // 0x000010 (0x000001) [Default: EAtomCommonPartType(176)]
        uint8               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FString             OutGeometryStyle;               // 0x000018 (0x000010) [OutParam] [Default: L""]
        FString             CommonPartsMeshPath;            // 0x000028 (0x000010) [Default: L"???"]
        bool                ReturnValue;                    // 0x000038 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAtomPrimitiveGeometry___GetMaterialNames_Params
    {
        TArray<FString> ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAtomPrimitiveGeometry___GetNumberOfCommonPartLODs_Params
    {
        FString             ExportStyleName;                // 0x000000 (0x000010) [Default: L"??"]
        EAtomCommonPartType CommonPartType;                 // 0x000010 (0x000001) [Default: EAtomCommonPartType(176)]
        uint8               UnknownData_000011[0x000007];   // 0x000011 (0x000007)
        FString             CommonPartsMeshPath;            // 0x000018 (0x000010) [Default: L""]
        int32               ReturnValue;                    // 0x000028 (0x000004) [ReturnValue] [Default: -1738912096]
    };

    struct UAtomPrimitiveGeometry___SetMaterialName_Params
    {
        FString                 Name;                           // 0x000000 (0x000010) [Default: L"??"]
        int32                   PolygonGroupIndex;              // 0x000010 (0x000004) [Default: 427448752]
        uint8                   UnknownData_000014[0x000004];   // 0x000014 (0x000004)
        UAtomPrimitiveGeometry* ReturnValue;                    // 0x000018 (0x000008) [ReturnValue] [Default: 0x19797BD0]
    };

    struct UAtomPrimitiveGeometry___SetTiledUVs_Params
    {
        float                   TileSize;                       // 0x000000 (0x000004) [Default: 1.43567e-26f]
        uint8                   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UAtomPrimitiveGeometry* ReturnValue;                    // 0x000008 (0x000008) [ReturnValue] [Default: 0xE55D18DD00000031]
    };

    struct UAtomPrimitiveGeometry___SetVertexColor_Params
    {
        FColor                  Color;                          // 0x000000 (0x000004) [OutParam]
        uint8                   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UAtomPrimitiveGeometry* ReturnValue;                    // 0x000008 (0x000008) [ReturnValue] [Default: 0xE55D18DD00000031]
    };

    struct UAtomPrimitiveGeometry___SplitByPolygonGroup_Params
    {
        bool                            bIgnoreEmptyGroups;             // 0x000000 (0x000001) [Default: true]
        uint8                           UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        TArray<UAtomPrimitiveGeometry*> ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UAtomPrimitiveGeometry___ToSimplifiedStaticMesh_Params
    {
        float           Scale;                          // 0x000000 (0x000004) [Default: 1.43567e-26f]
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UObject*        Outer;                          // 0x000008 (0x000008) [Default: 0xE55D18DD00000031]
        FString         Name;                           // 0x000010 (0x000010) [Default: L""]
        bool            bFastBuild;                     // 0x000020 (0x000001) [Default: true]
        uint8           UnknownData_000021[0x000007];   // 0x000021 (0x000007)
        UStaticMesh*    ReturnValue;                    // 0x000028 (0x000008) [ReturnValue] [Default: 0x7FEA985A4EA0]
    };

    struct UAtomPrimitiveGeometryContainer___GetAllOtherPartNames_Params
    {
        TArray<FString> ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAtomPrimitiveGeometryContainer___GetAllUncommonPartNames_Params
    {
        TArray<FString> ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAtomPrimitiveGeometryContainer___GetCapsGeometry_Params
    {
        int32                                       ColorChangeIndex;               // 0x000000 (0x000004) [Default: 344863840]
        uint8                                       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FAtomPrimitiveGeometryAndTransform>  ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UAtomPrimitiveGeometryContainer___GetCollisionGeometry_Params
    {
        TArray<FAtomPrimitiveGeometryAndTransform>  ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAtomPrimitiveGeometryContainer___GetDefaultBoneTransforms_Params
    {
        float               Scale;                          // 0x000000 (0x000004) [Default: 1.4359e-26f]
        uint8               UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FTransform>  ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UAtomPrimitiveGeometryContainer___GetDetailsGeometry_Params
    {
        int32                                       ColorChangeIndex;               // 0x000000 (0x000004) [Default: 344863840]
        uint8                                       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FAtomPrimitiveGeometryAndTransform>  ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UAtomPrimitiveGeometryContainer___GetExportStyleName_Params
    {
        FString ReturnValue;    // 0x000000 (0x000010) [ReturnValue] [Default: L"??"]
    };

    struct UAtomPrimitiveGeometryContainer___GetGeometry_Params
    {
        EPrimitiveGeometryComplexity    PrimitiveGeometryComplexity;    // 0x000000 (0x000001) [Default: EPrimitiveGeometryComplexity(96)]
        uint8                           UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        UAtomPrimitiveGeometry*         ReturnValue;                    // 0x000008 (0x000008) [ReturnValue] [Default: 0xE45D18DD00000031]
    };

    struct UAtomPrimitiveGeometryContainer___GetGeometryOtherPartName_Params
    {
        EAtomPrimitiveGeometryOtherPartType OtherPartType;                  // 0x000000 (0x000001) [Default: EAtomPrimitiveGeometryOtherPartType(96)]
        uint8                               UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        FString                             ReturnValue;                    // 0x000008 (0x000010) [ReturnValue] [Default: L""]
    };

    struct UAtomPrimitiveGeometryContainer___GetGeometrySection_Params
    {
        int32                   PrimitiveGeometrySectionFlag;   // 0x000000 (0x000004) [Default: 344863840]
        uint8                   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        UAtomPrimitiveGeometry* ReturnValue;                    // 0x000008 (0x000008) [ReturnValue] [Default: 0xE45D18DD00000031]
    };

    struct UAtomPrimitiveGeometryContainer___GetGeometrySectionWithFilter_Params
    {
        int32                                       PrimitiveGeometrySectionFlag;   // 0x000000 (0x000004) [Default: 344863840]
        uint8                                       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FAtomPrimitiveGeometrySectionFilterParams   FilterParams;                   // 0x000008 (0x000048) [OutParam]
        UAtomPrimitiveGeometry*                     ReturnValue;                    // 0x000050 (0x000008) [ReturnValue] [Default: nullptr]
    };

    struct UAtomPrimitiveGeometryContainer___GetGeometrySectionWithMaterialNames_Params
    {
        int32                   PrimitiveGeometrySectionFlags;  // 0x000000 (0x000004) [Default: 344863840]
        uint8                   UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FString                 ShellMaterial;                  // 0x000008 (0x000010) [Default: L""]
        FString                 UndersideMaterial;              // 0x000018 (0x000010) [Default: L""]
        UAtomPrimitiveGeometry* ReturnValue;                    // 0x000028 (0x000008) [ReturnValue] [Default: nullptr]
    };

    struct UAtomPrimitiveGeometryContainer___GetGeometryUncommonPartName_Params
    {
        EAtomPrimitiveGeometryUncommonPartType  UncommonPartType;               // 0x000000 (0x000001) [Default: EAtomPrimitiveGeometryUncommonPartType(96)]
        uint8                                   UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        FString                                 ReturnValue;                    // 0x000008 (0x000010) [ReturnValue] [Default: L""]
    };

    struct UAtomPrimitiveGeometryContainer___GetGeometryWithMaterialNames_Params
    {
        EPrimitiveGeometryComplexity    PrimitiveGeometryComplexity;    // 0x000000 (0x000001) [Default: EPrimitiveGeometryComplexity(96)]
        uint8                           UnknownData_000001[0x000007];   // 0x000001 (0x000007)
        FString                         ShellMaterial;                  // 0x000008 (0x000010) [Default: L""]
        FString                         UndersideMaterial;              // 0x000018 (0x000010) [Default: L""]
        UAtomPrimitiveGeometry*         ReturnValue;                    // 0x000028 (0x000008) [ReturnValue] [Default: nullptr]
    };

    struct UAtomPrimitiveGeometryContainer___GetLOD_Params
    {
        int32   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 344863840]
    };

    struct UAtomPrimitiveGeometryContainer___GetOtherCapsGeometry_Params
    {
        int32                                       ColorChangeIndex;               // 0x000000 (0x000004) [Default: 344863840]
        uint8                                       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FAtomPrimitiveGeometryAndTransform>  ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UAtomPrimitiveGeometryContainer___GetOtherPartsGeometry_Params
    {
        int32                                       ColorChangeIndex;               // 0x000000 (0x000004) [Default: 344863840]
        uint8                                       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FAtomPrimitiveGeometryAndTransform>  ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UAtomPrimitiveGeometryContainer___GetOtherPartsGeometryWithFilter_Params
    {
        FAtomPrimitiveGeometrySectionFilterParams   FilterParams;   // 0x000000 (0x000048) [OutParam]
        TArray<FAtomPrimitiveGeometryAndTransform>  ReturnValue;    // 0x000048 (0x000010) [ReturnValue]
    };

    struct UAtomPrimitiveGeometryContainer___GetScaledCapsGeometry_Params
    {
        float                                       Scale;                          // 0x000000 (0x000004) [Default: 1.4359e-26f]
        uint8                                       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FAtomPrimitiveGeometryAndTransform>  ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UAtomPrimitiveGeometryContainer___GetScaledCollisionGeometry_Params
    {
        float                                       Scale;                          // 0x000000 (0x000004) [Default: 1.4359e-26f]
        uint8                                       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FAtomPrimitiveGeometryAndTransform>  ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UAtomPrimitiveGeometryContainer___GetScaledDetailsGeometry_Params
    {
        float                                       Scale;                          // 0x000000 (0x000004) [Default: 1.4359e-26f]
        uint8                                       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FAtomPrimitiveGeometryAndTransform>  ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UAtomPrimitiveGeometryContainer___GetScaledGeometry_Params
    {
        EPrimitiveGeometryComplexity    PrimitiveGeometryComplexity;    // 0x000000 (0x000001) [Default: EPrimitiveGeometryComplexity(96)]
        uint8                           UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        float                           Scale;                          // 0x000004 (0x000004) [Default: 0f]
        UAtomPrimitiveGeometry*         ReturnValue;                    // 0x000008 (0x000008) [ReturnValue] [Default: 0xE45D18DD00000031]
    };

    struct UAtomPrimitiveGeometryContainer___GetScaledShellGeometry_Params
    {
        float                               Scale;                          // 0x000000 (0x000004) [Default: 1.4359e-26f]
        uint8                               UnknownData_000004[0x00000C];   // 0x000004 (0x00000C)
        FAtomPrimitiveGeometryAndTransform  ReturnValue;                    // 0x000010 (0x000040) [ReturnValue]
    };

    struct UAtomPrimitiveGeometryContainer___GetSectionTextureName_Params
    {
        EPrimitiveGeometrySectionFlag   SectionType;                    // 0x000000 (0x000001) [Default: EPrimitiveGeometrySectionFlag(96)]
        EAtomPrimitiveDetailTextureType TextureType;                    // 0x000001 (0x000001) [Default: EAtomPrimitiveDetailTextureType(52)]
        uint8                           UnknownData_000002[0x000006];   // 0x000002 (0x000006)
        FString                         OutTextureName;                 // 0x000008 (0x000010) [OutParam] [Default: L""]
        bool                            ReturnValue;                    // 0x000018 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAtomPrimitiveGeometryContainer___GetShellGeometry_Params
    {
        int32                               ColorChangeIndex;               // 0x000000 (0x000004) [Default: 344863840]
        uint8                               UnknownData_000004[0x00000C];   // 0x000004 (0x00000C)
        FAtomPrimitiveGeometryAndTransform  ReturnValue;                    // 0x000010 (0x000040) [ReturnValue]
    };

    struct UAtomPrimitiveGeometryContainer___GetTechnicCapsGeometry_Params
    {
        int32                                       ColorChangeIndex;               // 0x000000 (0x000004) [Default: 344863840]
        uint8                                       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FAtomPrimitiveGeometryAndTransform>  ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UAtomPrimitiveGeometryContainer___GetTechnicConnectorsGeometry_Params
    {
        int32                                       ColorChangeIndex;               // 0x000000 (0x000004) [Default: 344863840]
        uint8                                       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FAtomPrimitiveGeometryAndTransform>  ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UAtomPrimitiveGeometryContainer___GetUncommonPartsGeometry_Params
    {
        int32                                       ColorChangeIndex;               // 0x000000 (0x000004) [Default: 344863840]
        uint8                                       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FAtomPrimitiveGeometryAndTransform>  ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UAtomPrimitiveGeometryContainer___GetUncommonPartsGeometryWithFilter_Params
    {
        FAtomPrimitiveGeometrySectionFilterParams   FilterParams;   // 0x000000 (0x000048) [OutParam]
        TArray<FAtomPrimitiveGeometryAndTransform>  ReturnValue;    // 0x000048 (0x000010) [ReturnValue]
    };

    struct UAtomPrimitiveGeometryContainer___HasCollisionGeometry_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAtomPrimitiveGeometryContainer___MakePrimitiveCollisionGeometry_Params
    {
        float                           Scale;                          // 0x000000 (0x000004) [Default: 1.4359e-26f]
        uint8                           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FAtomPrimitiveCollisionGeometry ReturnValue;                    // 0x000008 (0x0000A0) [ReturnValue]
    };

    struct UAtomProcessorBlueprintLibrary___AppendAtomProcessorResult_Params
    {
        FAtomProcessorResult    Result;         // 0x000000 (0x000028) [OutParam]
        FAtomProcessorResult    ResultToAppend; // 0x000028 (0x000028) [OutParam]
        FAtomProcessorResult    ReturnValue;    // 0x000050 (0x000028) [ReturnValue]
    };

    struct UAtomProcessorBlueprintLibrary___GetModelProcessor_Params
    {
        FAtomModelProcessorInstance ProcessorInstance;  // 0x000000 (0x000028) [OutParam]
        UAtomModelProcessor*        ReturnValue;        // 0x000028 (0x000008) [ReturnValue] [Default: 0x12FAB170]
    };

    struct UAtomProcessorBlueprintLibrary___GetProcessorClass_Params
    {
        FAtomModelProcessorInstance ProcessorInstance;  // 0x000000 (0x000028) [OutParam]
        UClass*                     ReturnValue;        // 0x000028 (0x000008) [ReturnValue] [Default: 0x12FAB170]
    };

    struct UAtomProcessorBlueprintLibrary___IsValid_Params
    {
        FAtomModelProcessorInstance ProcessorInstance;  // 0x000000 (0x000028) [OutParam]
        bool                        ReturnValue;        // 0x000028 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAtomProcessorBlueprintLibrary___SetModelProcessor_Params
    {
        FAtomModelProcessorInstance ProcessorInstance;  // 0x000000 (0x000028) [OutParam]
        UAtomModelProcessor*        ModelProcessor;     // 0x000028 (0x000008) [Default: 0x12FAB170]
        bool                        bUseCustomSettings; // 0x000030 (0x000001) [Default: true]
    };

    struct IAtomRejectionReason___GetRejectionMessage_Params
    {
        FString ReturnValue;    // 0x000000 (0x000010) [ReturnValue] [Default: L"??"]
    };

    struct UAtomRuntimeBlueprintLibrary___GetAllColorInfo_Params
    {
        TMap<int32, FAtomColorInfo> ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAtomRuntimeBlueprintLibrary___GetBitPackForColor_Params
    {
        FColor  Color;          // 0x000000 (0x000004) [OutParam]
        int32   ReturnValue;    // 0x000004 (0x000004) [ReturnValue] [Default: 0]
    };

    struct UAtomRuntimeBlueprintLibrary___GetBitPackForColorId_Params
    {
        int32   AtomColorId;    // 0x000000 (0x000004) [Default: 319446880]
        int32   ReturnValue;    // 0x000004 (0x000004) [ReturnValue] [Default: 0]
    };

    struct UAtomRuntimeBlueprintLibrary___GetBitPackForLUTMaterial_Params
    {
        int32   ColorId;        // 0x000000 (0x000004) [Default: 319446880]
        FGuid   PrimitiveUUID;  // 0x000004 (0x000010) [OutParam]
        int32   VariantId;      // 0x000014 (0x000004) [Default: 0]
        float   ReturnValue;    // 0x000018 (0x000004) [ReturnValue] [Default: 1.2898e-23f]
    };

    struct UAtomRuntimeBlueprintLibrary___GetCommonPartAssetDescriptionFromStaticMesh_Params
    {
        UStaticMesh*                    StaticMesh;     // 0x000000 (0x000008) [Default: 0x130A5F60]
        FAtomCommonPartAssetDescription OutDescription; // 0x000008 (0x00000C) [OutParam]
        EGetCommonPartDescriptionResult OutIsValid;     // 0x000014 (0x000001) [OutParam] [Default: EGetCommonPartDescriptionResult(0)]
    };

    struct UAtomRuntimeBlueprintLibrary___GetCommonPartCategoryFromType_Params
    {
        EAtomCommonPartType     CommonPartType; // 0x000000 (0x000001) [Default: EAtomCommonPartType(96)]
        EAtomCommonPartCategory ReturnValue;    // 0x000001 (0x000001) [ReturnValue] [Default: EAtomCommonPartCategory(95)]
    };

    struct UAtomRuntimeBlueprintLibrary___GetCommonPartDescriptionFromType_Params
    {
        EAtomCommonPartType         CommonPartType;                 // 0x000000 (0x000001) [Default: EAtomCommonPartType(96)]
        uint8                       UnknownData_000001[0x000003];   // 0x000001 (0x000003)
        FAtomCommonPartDescription  OutDescription;                 // 0x000004 (0x000010) [OutParam]
    };

    struct UAtomRuntimeBlueprintLibrary___GetInfoForColorId_Params
    {
        int32           ColorId;                        // 0x000000 (0x000004) [Default: 319446880]
        uint8           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FAtomColorInfo  ReturnValue;                    // 0x000008 (0x000028) [ReturnValue]
    };

    struct UAtomRuntimeSettings___GetAtomEditorModeColorDataTable_Params
    {
        UDataTable* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x148E43A0]
    };

    struct UAtomRuntimeSettings___GetColorDataTable_Params
    {
        UDataTable* ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x148E43A0]
    };

    struct UConnectivityBlueprintLibrary___AreActorsConnected_Params
    {
        AActor*                     ActorA;                     // 0x000000 (0x000008) [Default: 0x130A5F60]
        AActor*                     ActorB;                     // 0x000008 (0x000008) [Default: 0xDB5D18DD00000031]
        UConnectivityRegistration*  ConnectivityRegistration;   // 0x000010 (0x000008) [Default: 0x197A6180]
        bool                        ReturnValue;                // 0x000018 (0x000001) [ReturnValue] [Default: true]
    };

    struct IDirectPlacement___TryDirectPlacement_Params
    {
        FPlacementOperation     InPlacementOperation;   // 0x000000 (0x000590) [OutParam]
        FPlacementContextData   InPlacementContextData; // 0x000590 (0x0000F0) [OutParam]
        bool                    ReturnValue;            // 0x000680 (0x000001) [ReturnValue] [Default: false]
    };

    struct UDirectSnapPlacementTool___PickActorToDrag_Params
    {
        FRay    CastRay;        // 0x000000 (0x000030) [OutParam]
        AActor* ReturnValue;    // 0x000030 (0x000008) [ReturnValue] [Default: nullptr]
    };

    struct IDragPlacement___PickActorToDrag_Params
    {
        FRay    CastRay;        // 0x000000 (0x000030) [OutParam]
        AActor* ReturnValue;    // 0x000030 (0x000008) [ReturnValue] [Default: 0x148E6CC0]
    };

    struct UPlacementOperationBlueprintLibrary___MakeDragPlacementOperation_Params
    {
        TArray<AActor*>     Actors;                         // 0x000000 (0x000010) [OutParam]
        FTransform          StartTransform;                 // 0x000010 (0x000060) [OutParam]
        FVector             DragLocation;                   // 0x000070 (0x000018) [OutParam]
        uint8               UnknownData_000088[0x000008];   // 0x000088 (0x000008)
        FPlacementOperation ReturnValue;                    // 0x000090 (0x000590) [ReturnValue]
    };

    struct UPlacementOperationBlueprintLibrary___MakePlacementOperation_Params
    {
        TArray<AActor*>     Actors;         // 0x000000 (0x000010) [OutParam]
        FTransform          StartTransform; // 0x000010 (0x000060) [OutParam]
        FPlacementOperation ReturnValue;    // 0x000070 (0x000590) [ReturnValue]
    };

    struct UWorldConnectivityBlueprintLibrary___GetActor_Params
    {
        UObject*                    WorldContext;                   // 0x000000 (0x000008) [Default: 0x130A5F60]
        FWorldConnectivityHandle    Handle;                         // 0x000008 (0x000004) [OutParam]
        uint8                       UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        AActor*                     ReturnValue;                    // 0x000010 (0x000008) [ReturnValue] [Default: 0x197AEAA0]
    };

    struct UWorldConnectivityBlueprintLibrary___GetFieldCenter_Params
    {
        UObject*            WorldContext;                   // 0x000000 (0x000008) [Default: 0x130A5F60]
        uint8               UnknownData_000008[0x000008];   // 0x000008 (0x000008)
        FPlanarFieldInfo    Field;                          // 0x000010 (0x000090) [OutParam]
        FVector             ReturnValue;                    // 0x0000A0 (0x000018) [ReturnValue]
    };

    struct UWorldConnectivityBlueprintLibrary___GetTransform_Params
    {
        UObject*                    WorldContext;                   // 0x000000 (0x000008) [Default: 0x130A5F60]
        FWorldConnectivityHandle    Handle;                         // 0x000008 (0x000004) [OutParam]
        uint8                       UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FTransform                  ReturnValue;                    // 0x000010 (0x000060) [ReturnValue]
    };

    struct UWorldConnectivityBlueprintLibrary___IsValid_Params
    {
        FWorldConnectivityHandle    Handle;         // 0x000000 (0x000004) [OutParam]
        bool                        ReturnValue;    // 0x000004 (0x000001) [ReturnValue] [Default: false]
    };

    struct UWorldConnectivitySubsystem___DisconnectAllObjectConnections_Params
    {
        FWorldConnectivityHandle    Object; // 0x000000 (0x000004)
    };

    struct UWorldConnectivitySubsystem___DisconnectObjects_Params
    {
        FWorldConnectivityHandle    ObjectA;    // 0x000000 (0x000004)
        FWorldConnectivityHandle    ObjectB;    // 0x000004 (0x000004)
    };

    struct UWorldConnectivitySubsystem___GetActor_Params
    {
        FWorldConnectivityHandle    Handle;                         // 0x000000 (0x000004)
        uint8                       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        AActor*                     ReturnValue;                    // 0x000008 (0x000008) [ReturnValue] [Default: 0xD15D18DD00000031]
    };

    struct UWorldConnectivitySubsystem___GetAtomModel_Params
    {
        AActor*     Actor;          // 0x000000 (0x000008) [Default: 0x148E86D0]
        UAtomModel* ReturnValue;    // 0x000008 (0x000008) [ReturnValue] [Default: 0xD15D18DD00000031]
    };

    struct UWorldConnectivitySubsystem___GetAtomModelAssetUserData_Params
    {
        UObject*                    Object;         // 0x000000 (0x000008) [Default: 0x148E86D0]
        UAtomModelAssetUserData*    ReturnValue;    // 0x000008 (0x000008) [ReturnValue] [Default: 0xD15D18DD00000031]
    };

    struct UWorldConnectivitySubsystem___GetClosestFieldToPoint_Params
    {
        FWorldConnectivityHandle    Handle;                         // 0x000000 (0x000004)
        uint8                       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FVector                     WorldLocation;                  // 0x000008 (0x000018) [OutParam]
        EConnectionFieldGender      Type;                           // 0x000020 (0x000001) [Default: EConnectionFieldGender(187)]
        bool                        bSuccess;                       // 0x000021 (0x000001) [OutParam] [Default: true]
        uint8                       UnknownData_000022[0x00000E];   // 0x000022 (0x00000E)
        FPlanarFieldInfo            ReturnValue;                    // 0x000030 (0x000090) [ReturnValue]
    };

    struct UWorldConnectivitySubsystem___GetConnectedObjects_Params
    {
        FWorldConnectivityHandle            Object;                         // 0x000000 (0x000004)
        uint8                               UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FWorldConnectivityHandle>    ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UWorldConnectivitySubsystem___GetConnectedObjectsRecursively_Params
    {
        FWorldConnectivityHandle            Object;                         // 0x000000 (0x000004)
        uint8                               UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FWorldConnectivityHandle>    ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UWorldConnectivitySubsystem___GetConnectivityHandle_Params
    {
        AActor*                     Actor;          // 0x000000 (0x000008) [Default: 0x148E86D0]
        FWorldConnectivityHandle    ReturnValue;    // 0x000008 (0x000004) [ReturnValue]
    };

    struct UWorldConnectivitySubsystem___GetConnectivityHandles_Params
    {
        AActor*                             Actor;          // 0x000000 (0x000008) [Default: 0x148E86D0]
        TArray<FWorldConnectivityHandle>    ReturnValue;    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UWorldConnectivitySubsystem___GetOverlapPenetrationDepth_Params
    {
        AStaticMeshActor*   Actor1;         // 0x000000 (0x000008) [Default: 0x148E86D0]
        AStaticMeshActor*   Actor2;         // 0x000008 (0x000008) [Default: 0xD15D18DD00000031]
        FVector             Offset;         // 0x000010 (0x000018)
        FVector             ReturnValue;    // 0x000028 (0x000018) [ReturnValue]
    };

    struct UWorldConnectivitySubsystem___GetPlanarFieldCenter_Params
    {
        FPlanarFieldInfo    Field;          // 0x000000 (0x000090) [OutParam]
        FVector             ReturnValue;    // 0x000090 (0x000018) [ReturnValue]
    };

    struct UWorldConnectivitySubsystem___GetPlanarFields_Params
    {
        FWorldConnectivityHandle    Handle;                         // 0x000000 (0x000004)
        EConnectionFieldGender      Type;                           // 0x000004 (0x000001) [Default: EConnectionFieldGender(0)]
        uint8                       UnknownData_000005[0x000003];   // 0x000005 (0x000003)
        TArray<FPlanarFieldInfo>    ReturnValue;                    // 0x000008 (0x000010) [ReturnValue]
    };

    struct UWorldConnectivitySubsystem___GetTransform_Params
    {
        FWorldConnectivityHandle    Handle;                         // 0x000000 (0x000004)
        uint8                       UnknownData_000004[0x00000C];   // 0x000004 (0x00000C)
        FTransform                  ReturnValue;                    // 0x000010 (0x000060) [ReturnValue]
    };

    struct UWorldConnectivitySubsystem___PlanarGridStepSize_Params
    {
        double  ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 1.70396e-315]
    };

    struct UWorldConnectivitySubsystem___RegisterAtomActor_Params
    {
        AActor* Actor;          // 0x000000 (0x000008) [Default: 0x148E86D0]
        bool    ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct UWorldConnectivitySubsystem___RegisterConnectivityActor_Params
    {
        AActor*     Actor;          // 0x000000 (0x000008) [Default: 0x148E86D0]
        UAtomModel* Model;          // 0x000008 (0x000008) [Default: 0xD15D18DD00000031]
        bool        ReturnValue;    // 0x000010 (0x000001) [ReturnValue] [Default: true]
    };

    struct UWorldConnectivitySubsystem___RegisterCustomConnectivityActor_Params
    {
        AActor*                         Actor;              // 0x000000 (0x000008) [Default: 0x148E86D0]
        FSerializedConnectivityObjects  ConnectivityObject; // 0x000008 (0x000040) [OutParam]
    };

    struct UWorldConnectivitySubsystem___RegisterModelActor_Params
    {
        AActor*                         Actor;          // 0x000000 (0x000008) [Default: 0x148E86D0]
        FSerializedConnectivityObjects  Connections;    // 0x000008 (0x000040) [OutParam]
    };

    struct UWorldConnectivitySubsystem___RunPlanarConnectivityQuery_Params
    {
        AActor*                             AtomActorToPlace;               // 0x000000 (0x000008) [Default: 0x148E86D0]
        AActor*                             AtomActorToConnect;             // 0x000008 (0x000008) [Default: 0xD15D18DD00000031]
        FVector                             QueryStartLocation;             // 0x000010 (0x000018) [OutParam]
        FVector                             QueryEndLocation;               // 0x000028 (0x000018) [OutParam]
        TEnumAsByte<ECollisionChannel>      QueryCollisionChannel;          // 0x000040 (0x000001) [Default: 240]
        uint8                               UnknownData_000041[0x000003];   // 0x000041 (0x000003)
        int32                               QueryRadius;                    // 0x000044 (0x000004) [Default: 0]
        bool                                bPerformConnectionOnSuccess;    // 0x000048 (0x000001) [Default: true]
        uint8                               UnknownData_000049[0x000007];   // 0x000049 (0x000007)
        TArray<FConnectivityQueryResult>    ReturnValue;                    // 0x000050 (0x000010) [ReturnValue]
    };

    struct UWorldConnectivitySubsystem___TryConnectObjectAtLocation_Params
    {
        FWorldConnectivityHandle            ObjectToConnect;                // 0x000000 (0x000004)
        uint8                               UnknownData_000004[0x00000C];   // 0x000004 (0x00000C)
        FTransform                          DesiredObjectTransform;         // 0x000010 (0x000060) [OutParam]
        TArray<FWorldConnectivityHandle>    ConnectionCandidates;           // 0x000070 (0x000010) [OutParam]
        bool                                PerformConnection;              // 0x000080 (0x000001) [Default: false]
        bool                                ReturnValue;                    // 0x000081 (0x000001) [ReturnValue] [Default: false]
    };

    struct UWorldConnectivitySubsystem___UnregisterConnectivityActor_Params
    {
        AActor* Actor;  // 0x000000 (0x000008) [Default: 0x148E86D0]
    };

} // namespace UE

