/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AnimationWarpingRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000028 (0x000000)
    class UAnimationWarpingLibrary : public UBlueprintFunctionLibrary
    {
    public:
    
    public: // Functions
        static void        ApplyDeltaToOffsetRootBone(FOffsetRootBoneAnimNodeReference& OffsetRootBoneNode, FVector TranslationWorld, FQuat RotationWorld); // 0x056183D0 [Final | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable]
        static void        ConvertToOffsetRootBoneNodePure(FAnimNodeReference& Node, FOffsetRootBoneAnimNodeReference& OffsetRootBoneNode, bool& Result); // 0x056187A4 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static bool        GetCurveValueFromAnimation(UAnimSequenceBase* Animation, FName CurveName, float time, float& OutValue); // 0x05618BB8 [Final | RequiredAPI | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static bool        GetFloatValueFromCurve(UCurveFloat* InCurve, float time, float& OutValue); // 0x05618FD6 [Final | Native | Static | Public | HasOutParms | BlueprintCallable | BlueprintPure]
        static FTransform  GetOffsetRootTransform(FAnimNodeReference& Node); // 0x05619394 [Final | RequiredAPI | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
        static bool        GetVectorValueFromCurve(UCurveVector* InCurve, float time, FVector& OutValue); // 0x056195B6 [Final | Native | Static | Public | HasOutParms | HasDefaults | BlueprintCallable | BlueprintPure]
    };
    // Size: 0x0004C0 (0x0003F8)
    struct alignas(0x8) FAnimNode_FootPlacement : public FAnimNode_SkeletalControlBase
    {
        EWarpingEvaluationMode              PlantSpeedMode;                 // 0x0000C8 (0x000001) [Default: EWarpingEvaluationMode(0)]
        uint8                               UnknownData_0000C9[0x000003];   // 0x0000C9 (0x000003)
        FBoneReference                      IKFootRootBone;                 // 0x0000CC (0x00000C)
        FBoneReference                      PelvisBone;                     // 0x0000D8 (0x00000C)
        FFootPlacementPelvisSettings        PelvisSettings;                 // 0x0000E4 (0x000020)
        uint8                               UnknownData_000104[0x000004];   // 0x000104 (0x000004)
        TArray<FFootPlacemenLegDefinition>  LegDefinitions;                 // 0x000108 (0x000010)
        FFootPlacementPlantSettings         PlantSettings;                  // 0x000118 (0x000034)
        FFootPlacementInterpolationSettings InterpolationSettings;          // 0x00014C (0x00002C)
        FFootPlacementTraceSettings         TraceSettings;                  // 0x000178 (0x000018)
        FVector                             BaseTranslationDelta;           // 0x000190 (0x000018)
        uint8                               UnknownData_0001A8[0x000178];   // 0x0001A8 (0x000178)
        void**                              VTable_000320;                  // 0x000320 (0x000008) VTable [121 slots] -> 0x12DD06E0
        uint8                               UnknownData_000328[0x000188];   // 0x000328 (0x000188)
        void**                              VTable_0004B0;                  // 0x0004B0 (0x000008) VTable [121 slots] -> 0x12DD06E0
        uint8                               UnknownData_0004B8[0x000008];   // 0x0004B8 (0x000008)
    };
    // Size: 0x000100 (0x0000F0)
    struct alignas(0x8) FAnimNode_OffsetRootBone : public FAnimNode_Base
    {
        FPoseLink   Source;                         // 0x000010 (0x000010)
        uint8       UnknownData_000020[0x0000E0];   // 0x000020 (0x0000E0)
    };
    // Size: 0x000260 (0x000198)
    struct alignas(0x8) FAnimNode_OrientationWarping : public FAnimNode_SkeletalControlBase
    {
        EWarpingEvaluationMode      Mode;                                           // 0x0000C8 (0x000001)
        uint8                       UnknownData_0000C9[0x000003];                   // 0x0000C9 (0x000003)
        float                       TargetTime;                                     // 0x0000CC (0x000004)
        float                       OrientationAngle;                               // 0x0000D0 (0x000004)
        float                       LocomotionAngle;                                // 0x0000D4 (0x000004)
        FVector                     LocomotionDirection;                            // 0x0000D8 (0x000018)
        float                       MinRootMotionSpeedThreshold;                    // 0x0000F0 (0x000004)
        float                       LocomotionAngleDeltaThreshold;                  // 0x0000F4 (0x000004)
        TArray<FBoneReference>      SpineBones;                                     // 0x0000F8 (0x000010)
        FBoneReference              IKFootRootBone;                                 // 0x000108 (0x00000C)
        uint8                       UnknownData_000114[0x000004];                   // 0x000114 (0x000004)
        TArray<FBoneReference>      IKFootBones;                                    // 0x000118 (0x000010)
        UAnimationAsset*            CurrentAnimAsset;                               // 0x000128 (0x000008)
        float                       CurrentAnimAssetTime;                           // 0x000130 (0x000004)
        TEnumAsByte<EAxis>          RotationAxis;                                   // 0x000134 (0x000001)
        uint8                       UnknownData_000135[0x000003];                   // 0x000135 (0x000003)
        float                       DistributedBoneOrientationAlpha;                // 0x000138 (0x000004)
        float                       RotationInterpSpeed;                            // 0x00013C (0x000004)
        float                       CounterCompensateInterpSpeed;                   // 0x000140 (0x000004)
        float                       MaxCorrectionDegrees;                           // 0x000144 (0x000004)
        float                       MaxRootMotionDeltaToCompensateDegrees;          // 0x000148 (0x000004)
        bool                        bCounterCompenstateInterpolationByRootMotion;   // 0x00014C (0x000001)
        bool                        bScaleByGlobalBlendWeight;                      // 0x00014D (0x000001)
        bool                        bUseManualRootMotionVelocity;                   // 0x00014E (0x000001)
        uint8                       UnknownByte_00014F;                             // 0x00014F (0x000001)
        FVector                     ManualRootMotionVelocity;                       // 0x000150 (0x000018)
        EOrientationWarpingSpace    WarpingSpace;                                   // 0x000168 (0x000001)
        uint8                       UnknownData_000169[0x000007];                   // 0x000169 (0x000007)
        FTransform                  WarpingSpaceTransform;                          // 0x000170 (0x000060)
        uint8                       UnknownData_0001D0[0x000090];                   // 0x0001D0 (0x000090)
    };
    // Size: 0x000030 (0x000020)
    struct alignas(0x8) FAnimNode_OverrideRootMotion : public FAnimNode_Base
    {
        FPoseLink   Source;                         // 0x000010 (0x000010)
        uint8       UnknownData_000020[0x000010];   // 0x000020 (0x000010)
    };
    // Size: 0x0002D8 (0x000210)
    struct alignas(0x8) FAnimNode_SlopeWarping : public FAnimNode_SkeletalControlBase
    {
        uint8                               UnknownData_0000C8[0x000018];   // 0x0000C8 (0x000018)
        FBoneReference                      IKFootRootBone;                 // 0x0000E0 (0x00000C)
        FBoneReference                      PelvisBone;                     // 0x0000EC (0x00000C)
        TArray<FSlopeWarpingFootDefinition> FeetDefinitions;                // 0x0000F8 (0x000010)
        TArray<FSlopeWarpingFootData>       FeetData;                       // 0x000108 (0x000010)
        FVectorRK4SpringInterpolator        PelvisOffsetInterpolator;       // 0x000118 (0x000008)
        uint8                               UnknownData_000120[0x000058];   // 0x000120 (0x000058)
        FVector                             GravityDir;                     // 0x000178 (0x000018)
        FVector                             CustomFloorOffset;              // 0x000190 (0x000018)
        float                               CachedDeltaTime;                // 0x0001A8 (0x000004)
        uint8                               UnknownData_0001AC[0x000004];   // 0x0001AC (0x000004)
        FVector                             TargetFloorNormalWorldSpace;    // 0x0001B0 (0x000018)
        FVectorRK4SpringInterpolator        FloorNormalInterpolator;        // 0x0001C8 (0x000008)
        uint8                               UnknownData_0001D0[0x000058];   // 0x0001D0 (0x000058)
        FVector                             TargetFloorOffsetLocalSpace;    // 0x000228 (0x000018)
        FVectorRK4SpringInterpolator        FloorOffsetInterpolator;        // 0x000240 (0x000008)
        uint8                               UnknownData_000248[0x000058];   // 0x000248 (0x000058)
        float                               MaxStepHeight;                  // 0x0002A0 (0x000004)
        uint8                               bKeepMeshInsideOfCapsule : 1;   // 0x0002A4 (0x000001) : 0x0
        uint8                               bPullPelvisDown : 1;            // 0x0002A4 (0x000001) : 0x0
        uint8                               bUseCustomFloorOffset : 1;      // 0x0002A4 (0x000001) : 0x0
        uint8                               bWasOnGround : 1;               // 0x0002A4 (0x000001) : 0x0
        uint8                               bShowDebug : 1;                 // 0x0002A4 (0x000001) : 0x0
        uint8                               bFloorSmoothingInitialized : 1; // 0x0002A4 (0x000001) : 0x0
        uint8                               UnknownBit_0002A4_1 : 1;        // 0x0002A4 (0x000001) : 0x1
        uint8                               UnknownBit_0002A4_2 : 1;        // 0x0002A4 (0x000001) : 0x2
        uint8                               UnknownBit_0002A4_3 : 1;        // 0x0002A4 (0x000001) : 0x3
        uint8                               UnknownBit_0002A4_4 : 1;        // 0x0002A4 (0x000001) : 0x4
        uint8                               UnknownBit_0002A4_5 : 1;        // 0x0002A4 (0x000001) : 0x5
        uint8                               UnknownBit_0002A4_6 : 1;        // 0x0002A4 (0x000001) : 0x6
        uint8                               UnknownBit_0002A4_7 : 1;        // 0x0002A4 (0x000001) : 0x7
        uint8                               UnknownData_0002A5[0x000003];   // 0x0002A5 (0x000003)
        FVector                             ActorLocation;                  // 0x0002A8 (0x000018)
        FVector                             GravityDirCompSpace;            // 0x0002C0 (0x000018)
    };
    // Size: 0x0001B0 (0x0000E8)
    struct alignas(0x8) FAnimNode_Steering : public FAnimNode_SkeletalControlBase
    {
        uint8               UnknownData_0000C8[0x000008];   // 0x0000C8 (0x000008)
        FQuat               TargetOrientation;              // 0x0000D0 (0x000020)
        bool                bMirrored;                      // 0x0000F0 (0x000001)
        uint8               UnknownData_0000F1[0x000003];   // 0x0000F1 (0x000003)
        float               ProceduralTargetTime;           // 0x0000F4 (0x000004)
        float               TargetTime;                     // 0x0000F8 (0x000004)
        float               AnimatedTargetTime;             // 0x0000FC (0x000004)
        float               RootMotionThreshold;            // 0x000100 (0x000004)
        float               DisableSteeringBelowSpeed;      // 0x000104 (0x000004)
        float               DisableAdditiveBelowSpeed;      // 0x000108 (0x000004)
        float               MinScaleRatio;                  // 0x00010C (0x000004)
        float               MaxScaleRatio;                  // 0x000110 (0x000004)
        uint8               UnknownData_000114[0x000004];   // 0x000114 (0x000004)
        UMirrorDataTable*   MirrorDataTable;                // 0x000118 (0x000008)
        UAnimationAsset*    CurrentAnimAsset;               // 0x000120 (0x000008)
        float               CurrentAnimAssetTime;           // 0x000128 (0x000004)
        uint8               UnknownData_00012C[0x000084];   // 0x00012C (0x000084)
    };
    // Size: 0x000240 (0x000178)
    struct alignas(0x8) FAnimNode_StrideWarping : public FAnimNode_SkeletalControlBase
    {
        EWarpingEvaluationMode                  Mode;                                   // 0x0000C8 (0x000001)
        uint8                                   UnknownData_0000C9[0x000007];           // 0x0000C9 (0x000007)
        FVector                                 StrideDirection;                        // 0x0000D0 (0x000018)
        float                                   StrideScale;                            // 0x0000E8 (0x000004)
        float                                   LocomotionSpeed;                        // 0x0000EC (0x000004)
        float                                   MinRootMotionSpeedThreshold;            // 0x0000F0 (0x000004)
        FBoneReference                          PelvisBone;                             // 0x0000F4 (0x00000C)
        FBoneReference                          IKFootRootBone;                         // 0x000100 (0x00000C)
        uint8                                   UnknownData_00010C[0x000004];           // 0x00010C (0x000004)
        TArray<FStrideWarpingFootDefinition>    FootDefinitions;                        // 0x000110 (0x000010)
        FInputClampConstants                    StrideScaleModifier;                    // 0x000120 (0x000014)
        uint8                                   UnknownData_000134[0x000004];           // 0x000134 (0x000004)
        FWarpingVectorValue                     FloorNormalDirection;                   // 0x000138 (0x000020)
        FWarpingVectorValue                     GravityDirection;                       // 0x000158 (0x000020)
        FIKFootPelvisPullDownSolver             PelvisIKFootSolver;                     // 0x000178 (0x000080)
        bool                                    bOrientStrideDirectionUsingFloorNormal; // 0x0001F8 (0x000001)
        bool                                    bCompensateIKUsingFKThighRotation;      // 0x0001F9 (0x000001)
        bool                                    bClampIKUsingFKLimits;                  // 0x0001FA (0x000001)
        bool                                    bDisableIfMissingRootMotion;            // 0x0001FB (0x000001)
        uint8                                   UnknownData_0001FC[0x000044];           // 0x0001FC (0x000044)
    };
    // Size: 0x0000B0 (0x0000A0)
    struct alignas(0x8) FAnimNode_WarpTest : public FAnimNode_Base
    {
        FPoseLink           Source;                         // 0x000010 (0x000010)
        TArray<FTransform>  Transforms;                     // 0x000020 (0x000010)
        float               SecondsToWait;                  // 0x000030 (0x000004) [Default: 0f]
        uint8               UnknownData_000034[0x00007C];   // 0x000034 (0x00007C)
    };
    // Size: 0x000034 (0x000034)
    struct alignas(0x8) FFootPlacemenLegDefinition
    {
        FBoneReference  FKFootBone;             // 0x000000 (0x00000C)
        FBoneReference  IKFootBone;             // 0x00000C (0x00000C)
        FBoneReference  BallBone;               // 0x000018 (0x00000C)
        int32           NumBonesInLimb;         // 0x000024 (0x000004)
        FName           SpeedCurveName;         // 0x000028 (0x000004)
        FName           DisableLockCurveName;   // 0x00002C (0x000004)
        FName           DisableLegCurveName;    // 0x000030 (0x000004)
    };
    // Size: 0x00002C (0x00002C)
    struct alignas(0x4) FFootPlacementInterpolationSettings
    {
        float   UnplantLinearStiffness;         // 0x000000 (0x000004)
        float   UnplantLinearDamping;           // 0x000004 (0x000004)
        float   UnplantAngularStiffness;        // 0x000008 (0x000004)
        float   UnplantAngularDamping;          // 0x00000C (0x000004)
        float   SeparationStiffness;            // 0x000010 (0x000004)
        float   SeparationDamping;              // 0x000014 (0x000004)
        float   FloorLinearStiffness;           // 0x000018 (0x000004)
        float   FloorLinearDamping;             // 0x00001C (0x000004)
        float   FloorAngularStiffness;          // 0x000020 (0x000004)
        float   FloorAngularDamping;            // 0x000024 (0x000004)
        bool    bEnableFloorInterpolation;      // 0x000028 (0x000001)
        bool    bSmoothRootBone;                // 0x000029 (0x000001)
        bool    bEnableSeparationInterpolation; // 0x00002A (0x000001)
        uint8   UnknownByte_00002B;             // 0x00002B (0x000001)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x4) FFootPlacementPelvisSettings
    {
        float                           MaxOffset;                      // 0x000000 (0x000004)
        float                           LinearStiffness;                // 0x000004 (0x000004)
        float                           LinearDamping;                  // 0x000008 (0x000004)
        float                           HorizontalRebalancingWeight;    // 0x00000C (0x000004)
        float                           MaxOffsetHorizontal;            // 0x000010 (0x000004)
        float                           HeelLiftRatio;                  // 0x000014 (0x000004)
        EPelvisHeightMode               PelvisHeightMode;               // 0x000018 (0x000001)
        EActorMovementCompensationMode  ActorMovementCompensationMode;  // 0x000019 (0x000001)
        bool                            bEnableInterpolation;           // 0x00001A (0x000001)
        bool                            bDisablePelvisOffsetInAir;      // 0x00001B (0x000001)
        FName                           DisablePelvisCurveName;         // 0x00001C (0x000004)
    };
    // Size: 0x000034 (0x000034)
    struct alignas(0x4) FFootPlacementPlantSettings
    {
        float                   SpeedThreshold;                     // 0x000000 (0x000004)
        float                   DistanceToGround;                   // 0x000004 (0x000004)
        EFootPlacementLockType  LockType;                           // 0x000008 (0x000001)
        uint8                   UnknownData_000009[0x000003];       // 0x000009 (0x000003)
        float                   UnplantRadius;                      // 0x00000C (0x000004)
        float                   ReplantRadiusRatio;                 // 0x000010 (0x000004)
        float                   UnplantAngle;                       // 0x000014 (0x000004)
        float                   ReplantAngleRatio;                  // 0x000018 (0x000004)
        float                   MaxExtensionRatio;                  // 0x00001C (0x000004)
        float                   MinExtensionRatio;                  // 0x000020 (0x000004)
        float                   SeparatingDistance;                 // 0x000024 (0x000004)
        float                   UnalignmentSpeedThreshold;          // 0x000028 (0x000004)
        float                   AnkleTwistReduction;                // 0x00002C (0x000004)
        bool                    bReconstructWorldPlantFromVelocity; // 0x000030 (0x000001)
        bool                    bAdjustHeelBeforePlanting;          // 0x000031 (0x000001)
        uint8                   UnknownData_000032[0x000002];       // 0x000032 (0x000002)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FFootPlacementRootDefinition
    {
        FBoneReference  PelvisBone; // 0x000000 (0x00000C)
        FBoneReference  IKRootBone; // 0x00000C (0x00000C)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x4) FFootPlacementTraceSettings
    {
        float                           StartOffset;                    // 0x000000 (0x000004)
        float                           EndOffset;                      // 0x000004 (0x000004)
        float                           SweepRadius;                    // 0x000008 (0x000004)
        bool                            bDisableComplexTrace;           // 0x00000C (0x000001)
        TEnumAsByte<ETraceTypeQuery>    ComplexTraceChannel;            // 0x00000D (0x000001)
        uint8                           UnknownData_00000E[0x000002];   // 0x00000E (0x000002)
        float                           MaxGroundPenetration;           // 0x000010 (0x000004)
        TEnumAsByte<ETraceTypeQuery>    SimpleTraceChannel;             // 0x000014 (0x000001)
        bool                            bEnabled;                       // 0x000015 (0x000001)
        uint8                           UnknownData_000016[0x000002];   // 0x000016 (0x000002)
    };
    // Size: 0x000010 (0x000000)
    struct FOffsetRootBoneAnimNodeReference : public FAnimNodeReference
    {
    };
    // Size: 0x0000B0 (0x0000B0)
    struct FSlopeWarpingFootData
    {
        uint8   UnknownData_000000[0x0000B0];   // 0x000000 (0x0000B0)
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FSlopeWarpingFootDefinition
    {
        FBoneReference  IKFootBone;     // 0x000000 (0x00000C)
        FBoneReference  FKFootBone;     // 0x00000C (0x00000C)
        int32           NumBonesInLimb; // 0x000018 (0x000004) [Default: 379749280]
        float           FootSize;       // 0x00001C (0x000004) [Default: 0f]
    };
    // Size: 0x000024 (0x000024)
    struct alignas(0x8) FStrideWarpingFootDefinition
    {
        FBoneReference  IKFootBone; // 0x000000 (0x00000C)
        FBoneReference  FKFootBone; // 0x00000C (0x00000C)
        FBoneReference  ThighBone;  // 0x000018 (0x00000C)
    };
}

