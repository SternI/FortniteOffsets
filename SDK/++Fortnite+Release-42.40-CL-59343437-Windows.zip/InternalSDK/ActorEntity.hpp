/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/ActorEntity
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000168 (0x0000A8)
    class alignas(0x8) UActorEntityComponent : public UActorComponent
    {
    public:
        FActorEntityMappingArray    EntityMappingArray;             // 0x0000C0 (0x000070)
        bool                        bRemoveEntityOnDestruction;     // 0x000130 (0x000001) [Default: true]
        uint8                       UnknownData_000131[0x000037];   // 0x000131 (0x000037)
    };
    // Size: 0x0000E0 (0x000020)
    class alignas(0x8) UActorEntityPrefabComponent : public UActorComponent
    {
    public:
        TSoftClassPtr<UClass>   EntityClass;    // 0x0000C0 (0x000020) [Default: nullptr]
    };
    // Size: 0x000068 (0x000030)
    class alignas(0x8) UActorEntitySubsystem : public UWorldSubsystem
    {
    public:
        uint8                   UnknownData_000038[0x000028];   // 0x000038 (0x000028)
        UPhysicsQueryConvertor* PhysicsQueryConvertor;          // 0x000060 (0x000008) [Default: nullptr]
    };
    // Size: 0x000038 (0x000010)
    class UPhysicsComponentBridgeHelper : public UObject
    {
    public:
        uint8   UnknownData_000028[0x000010];   // 0x000028 (0x000010)
    
    public: // Functions
        void    HandleActorComponentHit(UPrimitiveComponent* PrimitiveComponent, AActor* OtherActor, UPrimitiveComponent* OtherComponent, FVector NormalImpulse, FHitResult& Hit); // 0x0553F4C8 [Final | Native | Private | HasOutParms | HasDefaults]
    };
    // Size: 0x000038 (0x000010)
    class alignas(0x8) UPhysicsQueryConvertor : public UObject
    {
    public:
        void**                  VTable_000028;          // 0x000028 (0x000008) VTable [3 slots] -> 0x1345E170
        UActorEntitySubsystem*  ActorEntitySubsystem;   // 0x000030 (0x000008) [Default: nullptr]
    };
    // Size: 0x000038 (0x000010)
    class UPossessableComponentBridgeHelper : public UObject
    {
    public:
        uint8   UnknownData_000028[0x000010];   // 0x000028 (0x000010)
    
    public: // Functions
        void    HandlePawnControllerChanged(APawn* OwnerPawn, AController* OldController, AController* NewController); // 0x0553D640 [Final | Native | Private]
    };
    // Size: 0x000068 (0x000068)
    struct alignas(0x8) FActorEntityInteropRules
    {
        TSoftClassPtr<UClass>               ActorClass;                             // 0x000000 (0x000020) [Default: 0x16A23710]
        EConsideredForActorEntityInterop    ActorEntityConsidered;                  // 0x000020 (0x000004) [Default: EConsideredForActorEntityInterop(318436160)]
        uint8                               UnknownData_000024[0x000004];           // 0x000024 (0x000004)
        TArray<TSoftClassPtr<UClass>>       AllowedEntityComponents;                // 0x000028 (0x000010)
        EConsideredForActorEntityInterop    SubEntitiesConsidered;                  // 0x000038 (0x000004) [Default: EConsideredForActorEntityInterop(3087015865)]
        uint8                               UnknownData_00003C[0x000004];           // 0x00003C (0x000004)
        TArray<FSubEntityInteropRules>      SubEntityRules;                         // 0x000040 (0x000010)
        bool                                bEnableEntityReplication;               // 0x000050 (0x000001) [Default: false]
        bool                                bDisableRootEntityTransformReplication; // 0x000051 (0x000001) [Default: false]
        uint8                               UnknownData_000052[0x000006];           // 0x000052 (0x000006)
        TArray<FName>                       ClientActorComponents;                  // 0x000058 (0x000010)
    };
    // Size: 0x000070 (0x000028)
    struct alignas(0x8) FActorEntityMappingArray : public FFastArraySerializer
    {
        uint8                                   UnknownData_000048[0x000018];   // 0x000048 (0x000018)
        TArray<FActorEntityMappingArrayItem>    Entities;                       // 0x000060 (0x000010)
    };
    // Size: 0x000020 (0x000014)
    struct alignas(0x8) FActorEntityMappingArrayItem : public FFastArraySerializerItem
    {
        uint8           UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        UBaseEntity*    Entity;                         // 0x000010 (0x000008)
        UObject*        Object;                         // 0x000018 (0x000008)
    };
    // Size: 0x000018 (0x000018)
    struct alignas(0x8) FSubEntityInteropRules
    {
        FName                               ComponentName;              // 0x000000 (0x000004)
        EConsideredForActorEntityInterop    Considered;                 // 0x000004 (0x000004)
        TArray<TSoftClassPtr<UClass>>       AllowedEntityComponents;    // 0x000008 (0x000010)
    };
}

