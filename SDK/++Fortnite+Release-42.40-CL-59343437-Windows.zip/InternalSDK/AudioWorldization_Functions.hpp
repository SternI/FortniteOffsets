/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:06
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioWorldization_Functions
 * ============================================================
 */

#include "AudioWorldization.hpp"

namespace UE
{

    struct UAudioWorldizationSubsystem___GetActorTagCounts_Params
    {
        TMap<FGameplayTag, int32>   ReturnValue;    // 0x000000 (0x000010) [ReturnValue]
    };

    struct UAudioWorldizationSubsystem___GetActorTags_Params
    {
        FGameplayTagContainer   ReturnValue;    // 0x000000 (0x000020) [ReturnValue]
    };

    struct UAudioWorldizationSubsystem___GetEnclosureFactor_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 2.97998e-27f]
    };

    struct UAudioWorldizationSubsystem___GetWallDistanceRatio_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 2.97998e-27f]
    };

    struct UAudioWorldizationSubsystem___IsAGVDisabled_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioWorldizationSubsystem___OverrideEffectSends_Params
    {
        FName                           InIdentifier;                   // 0x000000 (0x000004) [Default: FName(325851424) -> L""]
        uint8                           UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TArray<FAudioWorldizationSend>  InSends;                        // 0x000008 (0x000010) [OutParam]
    };

    struct UAudioWorldizationSubsystem___RemoveEffectSendOverride_Params
    {
        FName   InIdentifier;   // 0x000000 (0x000004) [Default: FName(325851424) -> L""]
    };

    struct UAudioWorldizationSubsystem___RemoveWorldizationSettings_Params
    {
        FName   InIdentifier;   // 0x000000 (0x000004) [Default: FName(325851424) -> L""]
    };

    struct UAudioWorldizationSubsystem___SetEnabled_Params
    {
        bool    bNewEnabled;    // 0x000000 (0x000001) [Default: true]
    };

    struct UAudioWorldizationSubsystem___SetWorldizationSettings_Params
    {
        FAudioWorldizationSettings  InSettings; // 0x000000 (0x000080) [OutParam]
    };

} // namespace UE

