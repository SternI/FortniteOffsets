/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:10
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioLinkEngine_Functions
 * ============================================================
 */

#include "AudioLinkEngine_Functions.hpp"

namespace UE
{

    bool IAudioLinkBlueprintInterface::IsLinkPlaying()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioLinkEngine.AudioLinkBlueprintInterface.IsLinkPlaying");
    
        IAudioLinkBlueprintInterface___IsLinkPlaying_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void IAudioLinkBlueprintInterface::PlayLink(float StartTime)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioLinkEngine.AudioLinkBlueprintInterface.PlayLink");
    
        IAudioLinkBlueprintInterface___PlayLink_Params Params{};
        Params.StartTime = StartTime;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void IAudioLinkBlueprintInterface::SetLinkSound(USoundBase* NewSound)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioLinkEngine.AudioLinkBlueprintInterface.SetLinkSound");
    
        IAudioLinkBlueprintInterface___SetLinkSound_Params Params{};
        Params.NewSound = NewSound;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void IAudioLinkBlueprintInterface::StopLink()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioLinkEngine.AudioLinkBlueprintInterface.StopLink");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

} // namespace UE

