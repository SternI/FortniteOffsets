/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AuroraPurchaseNull
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0000E0 (0x0000B8)
    class alignas(0x8) UAuroraPurchaseNull : public UObject
    {
    public:
        void**  VTable_000028;                  // 0x000028 (0x000008) VTable [21 slots] -> 0x1472C640
        void**  VTable_000030;                  // 0x000030 (0x000008) VTable [8 slots] -> 0x1472C6F0
        uint8   UnknownData_000038[0x0000A8];   // 0x000038 (0x0000A8)
    };
    // Size: 0x000020 (0x00001F)
    struct alignas(0x8) FAuroraInvoiceNull : public FAuroraInvoice
    {
        FInstancedStruct    offer;  // 0x000010 (0x000010)
    };
    // Size: 0x000020 (0x00001F)
    struct alignas(0x8) FAuroraReceiptNull : public FAuroraReceipt
    {
        FInstancedStruct    offer;  // 0x000010 (0x000010)
    };
}

