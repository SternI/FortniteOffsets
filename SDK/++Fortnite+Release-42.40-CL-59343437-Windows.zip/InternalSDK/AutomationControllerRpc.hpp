/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AutomationControllerRpc
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000068 (0x000000)
    class UAutomationControllerRpcRegistrationComponent : public UExternalRpcRegistrationComponent
    {
    public:
    };
}

