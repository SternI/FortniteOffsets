/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AIPatrolPath
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0003D8 (0x000318)
    class alignas(0x8) UAIPatrolPathComponent : public UActorComponent
    {
    public:
        void**                                                  VTable_0000C0;                      // 0x0000C0 (0x000008) VTable [27 slots] -> 0x147A6350
        void**                                                  VTable_0000C8;                      // 0x0000C8 (0x000008) VTable [5 slots] -> 0x147A6400
        void**                                                  VTable_0000D0;                      // 0x0000D0 (0x000008) VTable [3 slots] -> 0x147A6430
        void**                                                  VTable_0000D8;                      // 0x0000D8 (0x000008) VTable [5 slots] -> 0x147A6450
        void**                                                  VTable_0000E0;                      // 0x0000E0 (0x000008) VTable [2 slots] -> 0x147A6468
        TArray<FString>                                         SharedOptionNames;                  // 0x0000E8 (0x000010)
        TSoftClassPtr<UClass>                                   DefaultAIPawn;                      // 0x0000F8 (0x000020) [Default: nullptr]
        UClass*                                                 PathRendererClass;                  // 0x000118 (0x000008) [Default: nullptr]
        bool                                                    bAllowPartialPaths;                 // 0x000120 (0x000001) [Default: false]
        uint8                                                   UnknownData_000121[0x000007];       // 0x000121 (0x000007)
        FGameplayTagContainer                                   UnableToPlaceNewDeviceTags;         // 0x000128 (0x000020)
        FNavAgentProperties                                     CachedAIAgentProperties;            // 0x000148 (0x000030)
        UNavigationSystemV1*                                    CachedNavSystem;                    // 0x000178 (0x000008) [Default: nullptr]
        ANavigationData*                                        CachedNavData;                      // 0x000180 (0x000008) [Default: nullptr]
        UClass*                                                 CachedFilterClass;                  // 0x000188 (0x000008) [Default: nullptr]
        uint8                                                   UnknownData_000190[0x000010];       // 0x000190 (0x000010)
        MULTI_INLINE_DELEGATE(OnNextPatrolPointFailedToReach)   OnNextPatrolPointFailedToReach;     // 0x0001A0 (0x000010)
        MULTI_INLINE_DELEGATE(OnPatrolPointFailedToReach)       OnPatrolPointFailedToReach;         // 0x0001B0 (0x000010)
        MULTI_INLINE_DELEGATE(OnPatrolPointReached)             OnPatrolPointReached;               // 0x0001C0 (0x000010)
        MULTI_INLINE_DELEGATE(OnPatrolPathStarted)              OnPatrolPathStarted;                // 0x0001D0 (0x000010)
        MULTI_INLINE_DELEGATE(OnPatrolPathStopped)              OnPatrolPathStopped;                // 0x0001E0 (0x000010)
        uint8                                                   UnknownData_0001F0[0x000008];       // 0x0001F0 (0x000008)
        TArray<AActor*>                                         PatrolPath;                         // 0x0001F8 (0x000010)
        FPatrolPathSegmentDetails                               PathSegmentDetails;                 // 0x000208 (0x000108)
        uint8                                                   UnknownData_000310[0x000010];       // 0x000310 (0x000010)
        UAIPatrolPathComponent*                                 CopiedFrom;                         // 0x000320 (0x000008) [Default: nullptr]
        AActor*                                                 CurrentCloningNode;                 // 0x000328 (0x000008) [Default: nullptr]
        uint8                                                   UnknownData_000330[0x000008];       // 0x000330 (0x000008)
        UAIPatrolPathComponent*                                 CopiedFromCut;                      // 0x000338 (0x000008) [Default: nullptr]
        AFortCreativePatrolPath*                                PatrolPathActor;                    // 0x000340 (0x000008) [Default: nullptr]
        AFortAthenaPatrolPoint*                                 PatrolPointActor;                   // 0x000348 (0x000008) [Default: nullptr]
        TArray<UAIPatrolPathComponent*>                         MultiSelectActorToEnterList;        // 0x000350 (0x000010)
        uint8                                                   UnknownData_000360[0x000068];       // 0x000360 (0x000068)
        bool                                                    bCurrentlyPropagatingSharedOptions; // 0x0003C8 (0x000001) [Default: false]
        uint8                                                   UnknownData_0003C9[0x000007];       // 0x0003C9 (0x000007)
        UAIPatrolPathEditorComponent*                           PatrolPathEditorComponent;          // 0x0003D0 (0x000008) [Default: nullptr]
    
    public: // Functions
        bool                            CanNextPointBeReached(); // 0x10E68FF8 [Final | Native | Protected | BlueprintCallable | BlueprintPure | Const]
        void                            GeneratePathPoints(EFortCreativePatrolPathGroup PatrolPathGroup, bool bGenerationCausedByDuplication); // 0x081402E4 [Final | Native | Public | BlueprintCallable]
        TArray<UAIPatrolPathComponent*> GetLinkedPatrolPoints(); // 0x10E69468 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        bool                            GetNextAvailablePatrolPathIndex(int32& NextAvailableIndex); // 0x08140562 [Final | Native | Public | HasOutParms | BlueprintCallable | BlueprintPure | Const]
        UClass*                         GetPatrolFilterOptions(); // 0x000545D2 [Event | Public | BlueprintEvent]
        EPatrollingMode                 GetPatrollingMode(); // 0x000545D2 [Event | Public | BlueprintEvent | Const]
        EFortCreativePatrolPathGroup    GetPatrolPathGroup(); // 0x000545D2 [Event | Public | BlueprintEvent | Const]
        int32                           GetPatrolPathIndex(); // 0x10E6992E [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32                           GetPatrolPathIndexFromDevice(); // 0x000545D2 [Event | Public | BlueprintEvent | Const]
        UAIPatrolPathComponent*         GetPatrolPathPoint(int32 InPatrolPathIndex, int32 InPatrolPathPointIndex); // 0x081406E8 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32                           GetPatrolPathPointIndex(); // 0x10E69B1C [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32                           GetPatrolPathPointIndexFromDevice(); // 0x000545D2 [Event | Public | BlueprintEvent | Const]
        bool                            HasValidPatrolPath(); // 0x10E69BC0 [Final | Native | Public | BlueprintCallable | BlueprintPure | Const]
        void                            NextPatrolPointFailedToReach(AFortAthenaPatrolPoint* PathPoint, AAIController* PatrolInstigator); // 0x0814096E [Final | Native | Private]
        void                            NotifyEditorUserOptionChanged(TArray<FString>& UserOptions); // 0x0613DBA4 [Final | Native | Protected | HasOutParms | BlueprintCallable]
        void                            OnAnyPropertyChanged(); // 0x0CA02B1A [Final | Native | Protected]
        void                            OnPathExtremitiesChanged(bool bIsStart, bool bIsEnd); // 0x000545D2 [Event | Public | BlueprintEvent]
        void                            OnPatrolPathActorAssigned(); // 0x000545D2 [Event | Public | BlueprintEvent]
        void                            PatrolPathStarted(AAIController* Instigator); // 0x08140BEE [Final | Native | Private]
        void                            PatrolPathStopped(AAIController* Instigator); // 0x08140D78 [Final | Native | Private]
        void                            PatrolPointFailedToReach(AFortAthenaPatrolPoint* PathPoint, AAIController* Instigator); // 0x08140F02 [Final | Native | Private]
        void                            PatrolPointReached(AFortAthenaPatrolPoint* PathPoint, AAIController* Instigator, bool bReachedBackward); // 0x08141182 [Final | Native | Private]
        void                            PostFinishSpawningActor(); // 0x10E69E20 [Final | Native | Public | BlueprintCallable]
        void                            PropagatePatrolPathIndexToDevice(int32 NewPatrolPathIndex); // 0x000545D2 [Event | Protected | BlueprintEvent]
        void                            PropagatePatrolPathPointIndexToDevice(int32 NewPatrolPathPointIndex); // 0x000545D2 [Event | Protected | BlueprintEvent]
        bool                            RemovePoint(); // 0x10E69E40 [Final | Native | Public | BlueprintCallable]
        void                            RenderToNextAndPreviousPoint(); // 0x10E69E66 [Final | Native | Public | BlueprintCallable]
        void                            RenderToNextPoint(); // 0x10E69F10 [Final | Native | Public | BlueprintCallable]
        void                            RequestRenderPath(); // 0x10E6A054 [Final | Native | Public | BlueprintCallable]
        void                            SetPatrollingMode(EPatrollingMode NewMode); // 0x081417FC [Final | Native | Public | BlueprintCallable]
        void                            SetPatrolPathEnabled(bool bIsEnabled); // 0x08141984 [Final | Native | Public | BlueprintCallable]
        void                            SetPatrolPathGroup(EFortCreativePatrolPathGroup PatrolPathGroup); // 0x08141B2A [Final | Native | Public | BlueprintCallable]
        void                            SetRenderPath(bool bRenderPath); // 0x08141CA2 [Final | Native | Public | BlueprintCallable]
        bool                            ShouldRenderPath(); // 0x000545D2 [Event | Protected | BlueprintCallable | BlueprintEvent]
        void                            UpdateEditorComponent(); // 0x0CA02B1A [Final | Native | Public | BlueprintCallable]
    };
    // Size: 0x000670 (0x0000A0)
    class UAIPatrolPathEditorComponent : public UDebugDrawComponent
    {
    public:
        uint8   UnknownData_0005D0[0x0000A0];   // 0x0005D0 (0x0000A0)
    };
    // Size: 0x000108 (0x000108)
    struct alignas(0x8) FPatrolPathSegmentDetails
    {
        uint8                   UnknownData_000000[0x0000B8];   // 0x000000 (0x0000B8)
        UAIPatrolPathComponent* Start;                          // 0x0000B8 (0x000008)
        uint8                   UnknownData_0000C0[0x000048];   // 0x0000C0 (0x000048)
    };
}

