/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:46
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/BeanstalkCosmeticsRuntime
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x0008F8 (0x000000)
    class ABeanFortPlayerMannequin : public AFortPlayerMannequin
    {
    public:
    
    public: // Functions
        void    BP_UpdateCosmeticMaterials(UBeanCosmeticItemDefinitionBase* BeanCD, UMaterialInstanceDynamic* MaterialBody, UMaterialInstanceDynamic* MaterialCostume, UMaterialInstanceDynamic* MaterialHead); // 0x000545D2 [RequiredAPI | Event | Protected | BlueprintEvent]
    };
    // Size: 0x000318 (0x000028)
    class alignas(0x8) AFortAthenaMutator_BeanBRCosmeticsOverride : public AFortAthenaMutator_CosmeticLoadoutOverride
    {
    public:
        TSoftObjectPtr<UBeanCosmeticsData>  CosmeticsData;      // 0x0002F0 (0x000020) [Default: nullptr]
        UBeanCosmeticsData*                 CosmeticsDataCache; // 0x000310 (0x000008) [Default: nullptr]
    };
    // Size: 0x000028 (0x000000)
    class UBeanAccountItemDefinitionOverride : public UPrimaryDataAsset
    {
    public:
    };
    // Size: 0x000068 (0x000040)
    class alignas(0x8) UBeanAthenaCharacterItemDefinitionOverride : public UBeanAccountItemDefinitionOverride
    {
    public:
        TSoftObjectPtr<UAthenaCharacterItemDefinition>  BaseAthenaCharacterItemDefinition;          // 0x000028 (0x000020) [Default: nullptr]
        TSoftObjectPtr<UAthenaCharacterItemDefinition>  BeanAthenaCharacterItemDefinitionOverride;  // 0x000048 (0x000020) [Default: nullptr]
    
    public: // Functions
        static UAthenaCharacterItemDefinition*             GetBeanCharacterFromCID(TSoftObjectPtr<UAthenaCharacterItemDefinition> CID); // 0x080DB708 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
        static UBeanAthenaCharacterItemDefinitionOverride* GetBIDOFromCID(TSoftObjectPtr<UAthenaCharacterItemDefinition> CID); // 0x080DC0C6 [Final | RequiredAPI | Native | Static | Public | BlueprintCallable]
    };
    // Size: 0x0000E0 (0x0000B8)
    class alignas(0x8) UBeanCosmeticItemDefinitionBase : public UFortCosmeticItemAdditionalData
    {
    public:
        TSoftObjectPtr<UTexture2D>  Body_Pattern;                           // 0x000028 (0x000020) [Default: nullptr]
        int32                       BodyFaceplateColorIndex;                // 0x000048 (0x000004) [Default: 1]
        int32                       BodyFaceplateMaterialTypeIndex;         // 0x00004C (0x000004) [Default: 0]
        int32                       BodyEyesColorIndex;                     // 0x000050 (0x000004) [Default: 0]
        int32                       BodyEyesMaterialTypeIndex;              // 0x000054 (0x000004) [Default: 0]
        bool                        bEyelashes;                             // 0x000058 (0x000001) [Default: false]
        uint8                       UnknownData_000059[0x000003];           // 0x000059 (0x000003)
        int32                       EyelashesColorIndex;                    // 0x00005C (0x000004) [Default: 0]
        int32                       EyelashesMaterialTypeIndex;             // 0x000060 (0x000004) [Default: 0]
        bool                        bGlasses;                               // 0x000064 (0x000001) [Default: false]
        uint8                       UnknownData_000065[0x000003];           // 0x000065 (0x000003)
        int32                       GlassesFrameColorIndex;                 // 0x000068 (0x000004) [Default: 199]
        int32                       GlassesFrameMaterialTypeIndex;          // 0x00006C (0x000004) [Default: 0]
        bool                        bGlassesLenses;                         // 0x000070 (0x000001) [Default: false]
        uint8                       UnknownData_000071[0x000003];           // 0x000071 (0x000003)
        int32                       GlassesLensesColorIndex;                // 0x000074 (0x000004) [Default: 199]
        int32                       GlassesLensesMaterialTypeIndex;         // 0x000078 (0x000004) [Default: 0]
        int32                       HeadCostumeMainColorIndex;              // 0x00007C (0x000004) [Default: 199]
        int32                       HeadCostumeMainMaterialTypeIndex;       // 0x000080 (0x000004) [Default: 0]
        bool                        bHeadCostumeMainClothingPattern;        // 0x000084 (0x000001) [Default: false]
        uint8                       UnknownData_000085[0x000003];           // 0x000085 (0x000003)
        int32                       HeadCostumeSecondaryColorIndex;         // 0x000088 (0x000004) [Default: 199]
        int32                       HeadCostumeSecondaryMaterialTypeIndex;  // 0x00008C (0x000004) [Default: 0]
        bool                        bHeadCostumeSecondaryClothingPattern;   // 0x000090 (0x000001) [Default: false]
        uint8                       UnknownData_000091[0x000003];           // 0x000091 (0x000003)
        int32                       HeadCostumeAccentColorIndex;            // 0x000094 (0x000004) [Default: 199]
        int32                       HeadCostumeAccentMaterialTypeIndex;     // 0x000098 (0x000004) [Default: 0]
        bool                        bHeadCostumeAccentClothingPattern;      // 0x00009C (0x000001) [Default: false]
        uint8                       UnknownData_00009D[0x000003];           // 0x00009D (0x000003)
        int32                       BodyMainColorIndex;                     // 0x0000A0 (0x000004) [Default: 199]
        int32                       BodyMainMaterialTypeIndex;              // 0x0000A4 (0x000004) [Default: 0]
        int32                       BodySecondaryColorIndex;                // 0x0000A8 (0x000004) [Default: 199]
        int32                       BodySecondaryMaterialTypeIndex;         // 0x0000AC (0x000004) [Default: 0]
        int32                       CostumePatternAtlasTextureSlot;         // 0x0000B0 (0x000004) [Default: 0]
        int32                       HeadCostumePatternAtlasTextureSlot;     // 0x0000B4 (0x000004) [Default: 0]
        int32                       CostumeMainColorIndex;                  // 0x0000B8 (0x000004) [Default: 199]
        int32                       CostumeMainMaterialTypeIndex;           // 0x0000BC (0x000004) [Default: 0]
        bool                        bCostumeMainClothingPattern;            // 0x0000C0 (0x000001) [Default: false]
        uint8                       UnknownData_0000C1[0x000003];           // 0x0000C1 (0x000003)
        int32                       CostumeSecondaryColorIndex;             // 0x0000C4 (0x000004) [Default: 199]
        int32                       CostumeSecondaryMaterialTypeIndex;      // 0x0000C8 (0x000004) [Default: 0]
        bool                        bCostumeSecondaryClothingPattern;       // 0x0000CC (0x000001) [Default: false]
        uint8                       UnknownData_0000CD[0x000003];           // 0x0000CD (0x000003)
        int32                       CostumeAccentColorIndex;                // 0x0000D0 (0x000004) [Default: 199]
        int32                       CostumeAccentMaterialTypeIndex;         // 0x0000D4 (0x000004) [Default: 0]
        bool                        bCostumeAccentClothingPattern;          // 0x0000D8 (0x000001) [Default: false]
        uint8                       UnknownData_0000D9[0x000007];           // 0x0000D9 (0x000007)
    };
    // Size: 0x000078 (0x000050)
    class alignas(0x8) UBeanCosmeticsData : public UPrimaryDataAsset
    {
    public:
        UFortHeroType*                                          HeroType;                       // 0x000028 (0x000008) [Default: nullptr]
        TSoftObjectPtr<UAthenaCharacterItemDefinition>          BulkCosmeticsPlaceholderCID;    // 0x000030 (0x000020) [Default: nullptr]
        UDataTable*                                             CharacterCosmeticsMap;          // 0x000050 (0x000008) [Default: nullptr]
        UDataTable*                                             EmoteLookupMap;                 // 0x000058 (0x000008) [Default: nullptr]
        TArray<TSoftObjectPtr<UAthenaCharacterItemDefinition>>  DefaultCharacterCosmetics;      // 0x000060 (0x000010)
        UFortItemDefinition*                                    EmptyHandsPickaxeDef;           // 0x000070 (0x000008) [Default: nullptr]
    };
    // Size: 0x0000C8 (0x000048)
    class alignas(0x8) UFortCosmeticStep_ApplyBeanCD : public UFortCosmeticStep
    {
    public:
        FGameplayTagQuery   BeanPartQuery;  // 0x000080 (0x000048)
    
    public: // Functions
        void    BP_UpdateCosmeticMaterials(UBeanCosmeticItemDefinitionBase* BeanCD, UMaterialInstanceDynamic* MaterialBody, UMaterialInstanceDynamic* MaterialCostume, UMaterialInstanceDynamic* MaterialHead); // 0x000545D2 [Event | Public | BlueprintEvent | Const]
    };
    // Size: 0x000080 (0x000000)
    class UFortCosmeticStep_BeanRemoveBackpack : public UFortCosmeticStep
    {
    public:
    };
    // Size: 0x000028 (0x000020)
    struct alignas(0x8) FBeanCosmeticDataTableRow : public FTableRowBase
    {
        TSoftObjectPtr<UAthenaCharacterItemDefinition>  Definition; // 0x000008 (0x000020)
    };
    // Size: 0x000028 (0x000020)
    struct alignas(0x8) FBeanEmoteConversionRow : public FTableRowBase
    {
        TSoftObjectPtr<UAthenaDanceItemDefinition>  EmoteDefinition;    // 0x000008 (0x000020)
    };
}

