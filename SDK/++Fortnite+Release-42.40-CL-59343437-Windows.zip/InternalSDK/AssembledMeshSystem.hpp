/**
 * ============================================================
 *  AUEDumper - Generated SDK Header
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:08
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AssembledMeshSystem
 * ============================================================
 */

#pragma once

namespace UE
{
    // Size: 0x000188 (0x000160)
    class alignas(0x8) UAssembledMeshSchema : public UPrimaryDataAsset
    {
    public:
        FGameplayTag                                MeshSchemaTag;                  // 0x000028 (0x000004)
        uint8                                       UnknownData_00002C[0x000004];   // 0x00002C (0x000004)
        TSoftObjectPtr<UCustomizableObjectInstance> CustomizableObjectInstance;     // 0x000030 (0x000020) [Default: nullptr]
        TSoftObjectPtr<UCustomizableObject>         CustomizableObject;             // 0x000050 (0x000020) [Default: nullptr]
        int32                                       ComponentIndex;                 // 0x000070 (0x000004) [Default: 0]
        FName                                       ComponentName;                  // 0x000074 (0x000004) [Default: NAME_None]
        TSoftObjectPtr<USkeletalMesh>               SkeletalMesh;                   // 0x000078 (0x000020) [Default: nullptr]
        TArray<TSoftObjectPtr<USkeletalMesh>>       SkeletalMeshes;                 // 0x000098 (0x000010)
        TArray<FAssembledMaterialsOverride>         OverrideMaterialsPerMesh;       // 0x0000A8 (0x000010)
        TArray<FAssembledTextureOverrideData>       OverrideTextures;               // 0x0000B8 (0x000010)
        TMap<FString, FString>                      SelectedIntParams;              // 0x0000C8 (0x000010)
        TMap<FString, float>                        SelectedFloatParams;            // 0x0000D8 (0x000010)
        FAssembledMeshAttachmentRules               AttachmentRules;                // 0x0000E8 (0x000050)
        TSoftClassPtr<UClass>                       AnimClass;                      // 0x000138 (0x000020) [Default: nullptr]
        FGameplayTagContainer                       SoundLibraryTags;               // 0x000158 (0x000020)
        TArray<FInstancedStruct>                    AdditionalData;                 // 0x000178 (0x000010)
    };
    // Size: 0x000150 (0x000090)
    class alignas(0x8) UAssembledMeshUserComponent : public UActorComponent
    {
    public:
        TArray<UObject*>                                LoadedAssets;                   // 0x0000C0 (0x000010)
        uint8                                           UnknownData_0000D0[0x000030];   // 0x0000D0 (0x000030)
        TArray<UAssembledMeshSchema*>                   MeshParts;                      // 0x000100 (0x000010)
        TArray<TSoftObjectPtr<UAssembledMeshSchema>>    MeshPartSoftRefs;               // 0x000110 (0x000010)
        uint8                                           UnknownData_000120[0x000010];   // 0x000120 (0x000010)
        TArray<FAssembledComponentReferences>           MeshPartComponents;             // 0x000130 (0x000010)
        bool                                            bDuplicateCOIs;                 // 0x000140 (0x000001) [Default: false]
        uint8                                           bAssignMeshPartsOnBeginPlay : 1; // 0x000141 (0x000001) : 0x0 [Default: true]
        uint8                                           bSetRootMeshOnAttachComponent : 1; // 0x000141 (0x000001) : 0x0 [Default: true]
        uint8                                           UnknownBit_000141_1 : 1;        // 0x000141 (0x000001) : 0x1
        uint8                                           UnknownBit_000141_2 : 1;        // 0x000141 (0x000001) : 0x2
        uint8                                           UnknownBit_000141_3 : 1;        // 0x000141 (0x000001) : 0x3
        uint8                                           UnknownBit_000141_4 : 1;        // 0x000141 (0x000001) : 0x4
        uint8                                           UnknownBit_000141_5 : 1;        // 0x000141 (0x000001) : 0x5
        uint8                                           UnknownBit_000141_6 : 1;        // 0x000141 (0x000001) : 0x6
        uint8                                           UnknownBit_000141_7 : 1;        // 0x000141 (0x000001) : 0x7
        uint8                                           UnknownData_000142[0x00000E];   // 0x000142 (0x00000E)
    
    public: // Functions
        void                    CustomizationCompleted(int32 PartIndex); // 0x04FB6D0C [RequiredAPI | Native | Protected]
        void                    GatherAndAssignAssembledMeshParts(); // 0x0DAC6250 [Native | Public]
        USkeletalMeshComponent* GetAttachToComponent(); // 0x0DAC626A [RequiredAPI | Native | Event | Protected | BlueprintEvent]
        UAssembledMeshSchema*   GetMeshPart(); // 0x0CB4AC8C [Final | RequiredAPI | Native | Private | BlueprintCallable | BlueprintPure | Const]
        UAssembledMeshSchema*   GetMeshPartByIndex(int32 MeshPartIndex); // 0x04FB6E80 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure | Const]
        int32                   GetNumMeshParts(); // 0x0DAC62B2 [Final | RequiredAPI | Native | Public | BlueprintCallable | BlueprintPure]
        void                    OnRep_MeshParts(); // 0x04FB7014 [RequiredAPI | Native | Protected]
        void                    SetMeshPart(UAssembledMeshSchema* InMeshPart); // 0x04FB702E [Final | RequiredAPI | Native | Private | BlueprintCallable]
        void                    SetMeshParts(TArray<TSoftObjectPtr<UAssembledMeshSchema>> InMeshParts); // 0x04FB719C [Final | RequiredAPI | Native | Private | BlueprintCallable]
    };
    // Size: 0x000028 (0x000000)
    class IAssembledMeshUser_AttachToComponentSpecifier : public IInterface
    {
    public:
    };
    // Size: 0x0000A8 (0x000000)
    class UHeadAccDataAssetLink : public UDataAssetLink
    {
    public:
    };
    // Size: 0x0000A8 (0x000000)
    class UHipAccDataAssetLink : public UDataAssetLink
    {
    public:
    };
    // Size: 0x0000A8 (0x000000)
    class UNeckAccDataAssetLink : public UDataAssetLink
    {
    public:
    };
    // Size: 0x000020 (0x000020)
    struct alignas(0x8) FAssembledComponentReferences
    {
        USkeletalMeshComponent*             SkeletalMeshComponent;              // 0x000000 (0x000008)
        UCustomizableObjectInstanceUsage*   CustomizableObjectInstanceUsage;    // 0x000008 (0x000008)
        FGameplayTag                        AssembledMeshSchemaTag;             // 0x000010 (0x000004)
        uint8                               UnknownData_000014[0x00000C];       // 0x000014 (0x00000C)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FAssembledMaterialsOverride
    {
        TArray<TSoftObjectPtr<UMaterialInterface>>  Materials;  // 0x000000 (0x000010)
    };
    // Size: 0x000050 (0x000050)
    struct alignas(0x8) FAssembledMeshAttachmentRules
    {
        FName       AttachSocketName;               // 0x000000 (0x000004)
        uint8       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        FVector     AttachOffset;                   // 0x000008 (0x000018)
        FRotator    AttachRotation;                 // 0x000020 (0x000018)
        FVector     AttachScale;                    // 0x000038 (0x000018)
    };
    // Size: 0x000001 (0x000001)
    struct FAssembledMeshSchemaData
    {
        uint8   UnknownByte_000000; // 0x000000 (0x000001)
    };
    // Size: 0x000080 (0x00007F)
    struct alignas(0x8) FAssembledMeshSchemaData_Icons : public FAssembledMeshSchemaData
    {
        TSoftObjectPtr<UTexture2D>  SmallPreviewImage;  // 0x000020 (0x000020)
        TSoftObjectPtr<UTexture2D>  LargePreviewImage;  // 0x000040 (0x000020)
        TSoftObjectPtr<UTexture2D>  FullScreenImage;    // 0x000060 (0x000020)
    };
    // Size: 0x000028 (0x000028)
    struct alignas(0x8) FAssembledTextureOverrideData
    {
        FName                       ParamName;                      // 0x000000 (0x000004)
        uint8                       UnknownData_000004[0x000004];   // 0x000004 (0x000004)
        TSoftObjectPtr<UTexture2D>  Texture;                        // 0x000008 (0x000020)
    };
    // Size: 0x000010 (0x000010)
    struct alignas(0x8) FBaseParamData
    {
        FString ParamName;  // 0x000000 (0x000010)
    };
    // Size: 0x000020 (0x000010)
    struct alignas(0x4) FFloatParamData : public FBaseParamData
    {
        float   FloatValue;                     // 0x000010 (0x000004)
        float   MinFloatValue;                  // 0x000014 (0x000004)
        float   MaxFloatValue;                  // 0x000018 (0x000004)
        uint8   UnknownData_00001C[0x000004];   // 0x00001C (0x000004)
    };
    // Size: 0x000020 (0x000010)
    struct alignas(0x8) FIntParamData : public FBaseParamData
    {
        TArray<FString> ParamOptions;   // 0x000010 (0x000010)
    };
}

