/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:25:47
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioWidgets_Functions
 * ============================================================
 */

#include "AudioWidgets_Functions.hpp"

namespace UE
{

    bool UAudioMaterialButton::GetIsPressed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialButton.GetIsPressed");
    
        UAudioMaterialButton___GetIsPressed_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioMaterialButton::SetIsPressed(bool InPressed)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialButton.SetIsPressed");
    
        UAudioMaterialButton___SetIsPressed_Params Params{};
        Params.InPressed = InPressed;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    float UAudioMaterialKnob::GetFineTuneSpeed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialKnob.GetFineTuneSpeed");
    
        UAudioMaterialKnob___GetFineTuneSpeed_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAudioMaterialKnob::GetIsLocked()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialKnob.GetIsLocked");
    
        UAudioMaterialKnob___GetIsLocked_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAudioMaterialKnob::GetMouseUsesStep()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialKnob.GetMouseUsesStep");
    
        UAudioMaterialKnob___GetMouseUsesStep_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAudioMaterialKnob::GetStepSize()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialKnob.GetStepSize");
    
        UAudioMaterialKnob___GetStepSize_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAudioMaterialKnob::GetTuneSpeed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialKnob.GetTuneSpeed");
    
        UAudioMaterialKnob___GetTuneSpeed_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAudioMaterialKnob::GetValue()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialKnob.GetValue");
    
        UAudioMaterialKnob___GetValue_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioMaterialKnob::SetFineTuneSpeed(float InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialKnob.SetFineTuneSpeed");
    
        UAudioMaterialKnob___SetFineTuneSpeed_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMaterialKnob::SetLocked(bool InLocked)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialKnob.SetLocked");
    
        UAudioMaterialKnob___SetLocked_Params Params{};
        Params.InLocked = InLocked;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMaterialKnob::SetMouseUsesStep(bool InUsesStep)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialKnob.SetMouseUsesStep");
    
        UAudioMaterialKnob___SetMouseUsesStep_Params Params{};
        Params.InUsesStep = InUsesStep;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMaterialKnob::SetStepSize(float InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialKnob.SetStepSize");
    
        UAudioMaterialKnob___SetStepSize_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMaterialKnob::SetTuneSpeed(float InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialKnob.SetTuneSpeed");
    
        UAudioMaterialKnob___SetTuneSpeed_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMaterialKnob::SetValue(float InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialKnob.SetValue");
    
        UAudioMaterialKnob___SetValue_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    TArray<FMeterChannelInfo> UAudioMaterialMeter::GetMeterChannelInfo()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialMeter.GetMeterChannelInfo");
    
        UAudioMaterialMeter___GetMeterChannelInfo_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioMaterialMeter::SetMeterChannelInfo(TArray<FMeterChannelInfo>& InMeterChannelInfo)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialMeter.SetMeterChannelInfo");
    
        UAudioMaterialMeter___SetMeterChannelInfo_Params Params{};
        Params.InMeterChannelInfo = InMeterChannelInfo;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InMeterChannelInfo = Params.InMeterChannelInfo;
    }

    TArray<FMeterChannelInfo> UAudioMaterialMeter::GetMeterChannelInfo()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialMeter.GetMeterChannelInfo");
    
        UAudioMaterialMeter___GetMeterChannelInfo_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAudioMaterialSlider::GetFineTuneSpeed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialSlider.GetFineTuneSpeed");
    
        UAudioMaterialSlider___GetFineTuneSpeed_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAudioMaterialSlider::GetIsLocked()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialSlider.GetIsLocked");
    
        UAudioMaterialSlider___GetIsLocked_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAudioMaterialSlider::GetMouseUsesStep()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialSlider.GetMouseUsesStep");
    
        UAudioMaterialSlider___GetMouseUsesStep_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAudioMaterialSlider::GetStepSize()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialSlider.GetStepSize");
    
        UAudioMaterialSlider___GetStepSize_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAudioMaterialSlider::GetTuneSpeed()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialSlider.GetTuneSpeed");
    
        UAudioMaterialSlider___GetTuneSpeed_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAudioMaterialSlider::GetValue()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialSlider.GetValue");
    
        UAudioMaterialSlider___GetValue_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioMaterialSlider::SetFineTuneSpeed(float InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialSlider.SetFineTuneSpeed");
    
        UAudioMaterialSlider___SetFineTuneSpeed_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMaterialSlider::SetLocked(bool bInLocked)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialSlider.SetLocked");
    
        UAudioMaterialSlider___SetLocked_Params Params{};
        Params.bInLocked = bInLocked;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMaterialSlider::SetMouseUsesStep(bool bInUsesStep)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialSlider.SetMouseUsesStep");
    
        UAudioMaterialSlider___SetMouseUsesStep_Params Params{};
        Params.bInUsesStep = bInUsesStep;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMaterialSlider::SetStepSize(float InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialSlider.SetStepSize");
    
        UAudioMaterialSlider___SetStepSize_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMaterialSlider::SetTuneSpeed(float InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialSlider.SetTuneSpeed");
    
        UAudioMaterialSlider___SetTuneSpeed_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMaterialSlider::SetValue(float InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMaterialSlider.SetValue");
    
        UAudioMaterialSlider___SetValue_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    TArray<FMeterChannelInfo> UAudioMeter::GetMeterChannelInfo()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMeter.GetMeterChannelInfo");
    
        UAudioMeter___GetMeterChannelInfo_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioMeter::SetBackgroundColor(FLinearColor InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMeter.SetBackgroundColor");
    
        UAudioMeter___SetBackgroundColor_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMeter::SetMeterBackgroundColor(FLinearColor InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMeter.SetMeterBackgroundColor");
    
        UAudioMeter___SetMeterBackgroundColor_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMeter::SetMeterChannelInfo(TArray<FMeterChannelInfo>& InMeterChannelInfo)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMeter.SetMeterChannelInfo");
    
        UAudioMeter___SetMeterChannelInfo_Params Params{};
        Params.InMeterChannelInfo = InMeterChannelInfo;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        InMeterChannelInfo = Params.InMeterChannelInfo;
    }

    void UAudioMeter::SetMeterClippingColor(FLinearColor InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMeter.SetMeterClippingColor");
    
        UAudioMeter___SetMeterClippingColor_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMeter::SetMeterPeakColor(FLinearColor InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMeter.SetMeterPeakColor");
    
        UAudioMeter___SetMeterPeakColor_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMeter::SetMeterScaleColor(FLinearColor InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMeter.SetMeterScaleColor");
    
        UAudioMeter___SetMeterScaleColor_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMeter::SetMeterScaleLabelColor(FLinearColor InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMeter.SetMeterScaleLabelColor");
    
        UAudioMeter___SetMeterScaleLabelColor_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioMeter::SetMeterValueColor(FLinearColor InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMeter.SetMeterValueColor");
    
        UAudioMeter___SetMeterValueColor_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    TArray<FMeterChannelInfo> UAudioMeter::GetMeterChannelInfo()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioMeter.GetMeterChannelInfo");
    
        UAudioMeter___GetMeterChannelInfo_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    bool UAudioOscilloscope::CanTriggeringBeSet()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioOscilloscope.CanTriggeringBeSet");
    
        UAudioOscilloscope___CanTriggeringBeSet_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioOscilloscope::StartProcessing()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioOscilloscope.StartProcessing");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioOscilloscope::StopProcessing()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioOscilloscope.StopProcessing");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    TArray<float> UAudioOscilloscope::GetOscilloscopeAudioSamples()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioOscilloscope.GetOscilloscopeAudioSamples");
    
        UAudioOscilloscope___GetOscilloscopeAudioSamples_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAudioRadialSlider::GetOutputValue(float InSliderValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioRadialSlider.GetOutputValue");
    
        UAudioRadialSlider___GetOutputValue_Params Params{};
        Params.InSliderValue = InSliderValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAudioRadialSlider::GetSliderValue(float OutputValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioRadialSlider.GetSliderValue");
    
        UAudioRadialSlider___GetSliderValue_Params Params{};
        Params.OutputValue = OutputValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioRadialSlider::SetCenterBackgroundColor(FLinearColor InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioRadialSlider.SetCenterBackgroundColor");
    
        UAudioRadialSlider___SetCenterBackgroundColor_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioRadialSlider::SetHandStartEndRatio(FVector2D InHandStartEndRatio)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioRadialSlider.SetHandStartEndRatio");
    
        UAudioRadialSlider___SetHandStartEndRatio_Params Params{};
        Params.InHandStartEndRatio = InHandStartEndRatio;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioRadialSlider::SetOutputRange(FVector2D InOutputRange)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioRadialSlider.SetOutputRange");
    
        UAudioRadialSlider___SetOutputRange_Params Params{};
        Params.InOutputRange = InOutputRange;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioRadialSlider::SetShowLabelOnlyOnHover(bool bShowLabelOnlyOnHover)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioRadialSlider.SetShowLabelOnlyOnHover");
    
        UAudioRadialSlider___SetShowLabelOnlyOnHover_Params Params{};
        Params.bShowLabelOnlyOnHover = bShowLabelOnlyOnHover;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioRadialSlider::SetShowUnitsText(bool bShowUnitsText)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioRadialSlider.SetShowUnitsText");
    
        UAudioRadialSlider___SetShowUnitsText_Params Params{};
        Params.bShowUnitsText = bShowUnitsText;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioRadialSlider::SetSliderBarColor(FLinearColor InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioRadialSlider.SetSliderBarColor");
    
        UAudioRadialSlider___SetSliderBarColor_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioRadialSlider::SetSliderProgressColor(FLinearColor InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioRadialSlider.SetSliderProgressColor");
    
        UAudioRadialSlider___SetSliderProgressColor_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioRadialSlider::SetSliderThickness(float InThickness)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioRadialSlider.SetSliderThickness");
    
        UAudioRadialSlider___SetSliderThickness_Params Params{};
        Params.InThickness = InThickness;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioRadialSlider::SetTextLabelBackgroundColor(FSlateColor InColor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioRadialSlider.SetTextLabelBackgroundColor");
    
        UAudioRadialSlider___SetTextLabelBackgroundColor_Params Params{};
        Params.InColor = InColor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioRadialSlider::SetUnitsText(FText Units)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioRadialSlider.SetUnitsText");
    
        UAudioRadialSlider___SetUnitsText_Params Params{};
        Params.Units = Units;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioRadialSlider::SetUnitsTextReadOnly(bool bIsReadOnly)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioRadialSlider.SetUnitsTextReadOnly");
    
        UAudioRadialSlider___SetUnitsTextReadOnly_Params Params{};
        Params.bIsReadOnly = bIsReadOnly;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioRadialSlider::SetValueTextReadOnly(bool bIsReadOnly)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioRadialSlider.SetValueTextReadOnly");
    
        UAudioRadialSlider___SetValueTextReadOnly_Params Params{};
        Params.bIsReadOnly = bIsReadOnly;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioRadialSlider::SetWidgetLayout(TEnumAsByte<EAudioRadialSliderLayout> InLayout)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioRadialSlider.SetWidgetLayout");
    
        UAudioRadialSlider___SetWidgetLayout_Params Params{};
        Params.InLayout = InLayout;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    float UAudioSliderBase::GetLinValue(float OutputValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioSliderBase.GetLinValue");
    
        UAudioSliderBase___GetLinValue_Params Params{};
        Params.OutputValue = OutputValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAudioSliderBase::GetOutputValue(float InSliderValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioSliderBase.GetOutputValue");
    
        UAudioSliderBase___GetOutputValue_Params Params{};
        Params.InSliderValue = InSliderValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    float UAudioSliderBase::GetSliderValue(float OutputValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioSliderBase.GetSliderValue");
    
        UAudioSliderBase___GetSliderValue_Params Params{};
        Params.OutputValue = OutputValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

    void UAudioSliderBase::SetShowLabelOnlyOnHover(bool bShowLabelOnlyOnHover)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioSliderBase.SetShowLabelOnlyOnHover");
    
        UAudioSliderBase___SetShowLabelOnlyOnHover_Params Params{};
        Params.bShowLabelOnlyOnHover = bShowLabelOnlyOnHover;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioSliderBase::SetShowUnitsText(bool bShowUnitsText)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioSliderBase.SetShowUnitsText");
    
        UAudioSliderBase___SetShowUnitsText_Params Params{};
        Params.bShowUnitsText = bShowUnitsText;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioSliderBase::SetSliderBackgroundColor(FLinearColor InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioSliderBase.SetSliderBackgroundColor");
    
        UAudioSliderBase___SetSliderBackgroundColor_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioSliderBase::SetSliderBarColor(FLinearColor InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioSliderBase.SetSliderBarColor");
    
        UAudioSliderBase___SetSliderBarColor_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioSliderBase::SetSliderThumbColor(FLinearColor InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioSliderBase.SetSliderThumbColor");
    
        UAudioSliderBase___SetSliderThumbColor_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioSliderBase::SetTextLabelBackgroundColor(FSlateColor InColor)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioSliderBase.SetTextLabelBackgroundColor");
    
        UAudioSliderBase___SetTextLabelBackgroundColor_Params Params{};
        Params.InColor = InColor;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioSliderBase::SetUnitsText(FText Units)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioSliderBase.SetUnitsText");
    
        UAudioSliderBase___SetUnitsText_Params Params{};
        Params.Units = Units;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioSliderBase::SetUnitsTextReadOnly(bool bIsReadOnly)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioSliderBase.SetUnitsTextReadOnly");
    
        UAudioSliderBase___SetUnitsTextReadOnly_Params Params{};
        Params.bIsReadOnly = bIsReadOnly;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioSliderBase::SetValueTextReadOnly(bool bIsReadOnly)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioSliderBase.SetValueTextReadOnly");
    
        UAudioSliderBase___SetValueTextReadOnly_Params Params{};
        Params.bIsReadOnly = bIsReadOnly;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioSliderBase::SetWidgetBackgroundColor(FLinearColor InValue)
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioSliderBase.SetWidgetBackgroundColor");
    
        UAudioSliderBase___SetWidgetBackgroundColor_Params Params{};
        Params.InValue = InValue;
    
        if (Fn) ProcessEvent(Fn, &Params);
    }

    void UAudioVectorscope::StartProcessing()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioVectorscope.StartProcessing");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    void UAudioVectorscope::StopProcessing()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioVectorscope.StopProcessing");
    
        if (Fn) ProcessEvent(Fn, nullptr);
    }

    TArray<float> UAudioVectorscope::GetVectorscopeAudioSamples()
    {
        static UFunction* Fn = nullptr;
        if (!Fn) Fn = UObject::FindObject<UFunction>("AudioWidgets.AudioVectorscope.GetVectorscopeAudioSamples");
    
        UAudioVectorscope___GetVectorscopeAudioSamples_Params Params{};
    
        if (Fn) ProcessEvent(Fn, &Params);
    
        return Params.ReturnValue;
    }

} // namespace UE

