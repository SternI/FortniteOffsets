/**
 * ============================================================
 *  AUEDumper - Generated SDK Functions
 *  Author       : Stern
 *  Generated    : 2026-10-25 17:26:08
 *  Game Version : ++Fortnite+Release-42.40-CL-59343437-Windows
 *  Package      : /Script/AudioModulation_Functions
 * ============================================================
 */

#include "AudioModulation.hpp"

namespace UE
{

    struct UAudioModulationDestination___ClearModulator_Params
    {
        bool    ReturnValue;    // 0x000000 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioModulationDestination___GetModulator_Params
    {
        USoundModulatorBase*    ReturnValue;    // 0x000000 (0x000008) [ReturnValue] [Default: 0x1350AD20]
    };

    struct UAudioModulationDestination___GetValue_Params
    {
        float   ReturnValue;    // 0x000000 (0x000004) [ReturnValue] [Default: 2.63386e-27f]
    };

    struct UAudioModulationDestination___SetModulator_Params
    {
        USoundModulatorBase*    InModulator;    // 0x000000 (0x000008) [Default: 0x1350AD20]
        bool                    ReturnValue;    // 0x000008 (0x000001) [ReturnValue] [Default: true]
    };

    struct UAudioModulationStatics___ActivateBus_Params
    {
        UObject*            WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundControlBus*   Bus;                // 0x000008 (0x000008) [Default: 0xD52718DD00000031]
    };

    struct UAudioModulationStatics___ActivateBusMix_Params
    {
        UObject*                WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundControlBusMix*    Mix;                // 0x000008 (0x000008) [Default: 0xD52718DD00000031]
    };

    struct UAudioModulationStatics___ActivateGenerator_Params
    {
        UObject*                    WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundModulationGenerator*  Generator;          // 0x000008 (0x000008) [Default: 0xD52718DD00000031]
    };

    struct UAudioModulationStatics___ClearAllGlobalBusMixValues_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        float       FadeTime;           // 0x000008 (0x000004) [Default: 6.86636e-44f]
    };

    struct UAudioModulationStatics___ClearGlobalBusMixValue_Params
    {
        UObject*            WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundControlBus*   Bus;                // 0x000008 (0x000008) [Default: 0xD52718DD00000031]
        float               FadeTime;           // 0x000010 (0x000004) [Default: 5.98853e-25f]
    };

    struct UAudioModulationStatics___CreateADEnvelopeGenerator_Params
    {
        UObject*                                WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        FName                                   Name;               // 0x000008 (0x000004) [Default: FName(49) -> L""]
        FSoundModulationADEnvelopeParams        Params;             // 0x00000C (0x000014) [OutParam]
        USoundModulationGeneratorADEnvelope*    ReturnValue;        // 0x000020 (0x000008) [ReturnValue] [Default: 0xD05B2BB]
    };

    struct UAudioModulationStatics___CreateBus_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x130A5F60]
        FName                       Name;                           // 0x000008 (0x000004) [Default: FName(49) -> L""]
        uint8                       UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        USoundModulationParameter*  Parameter;                      // 0x000010 (0x000008) [Default: 0x17395600]
        bool                        Activate;                       // 0x000018 (0x000001) [Default: true]
        uint8                       UnknownData_000019[0x000007];   // 0x000019 (0x000007)
        USoundControlBus*           ReturnValue;                    // 0x000020 (0x000008) [ReturnValue] [Default: 0xD05B2BB]
    };

    struct UAudioModulationStatics___CreateBusMix_Params
    {
        UObject*                            WorldContextObject;             // 0x000000 (0x000008) [Default: 0x130A5F60]
        FName                               Name;                           // 0x000008 (0x000004) [Default: FName(49) -> L""]
        uint8                               UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        TArray<FSoundControlBusMixStage>    Stages;                         // 0x000010 (0x000010)
        bool                                Activate;                       // 0x000020 (0x000001) [Default: true]
        uint8                               UnknownData_000021[0x000007];   // 0x000021 (0x000007)
        double                              duration;                       // 0x000028 (0x000008) [Default: 1.57828e-315]
        bool                                bRetriggerOnActivation;         // 0x000030 (0x000001) [Default: true]
        uint8                               UnknownData_000031[0x000007];   // 0x000031 (0x000007)
        USoundControlBusMix*                ReturnValue;                    // 0x000038 (0x000008) [ReturnValue] [Default: 0x1738FB00]
    };

    struct UAudioModulationStatics___CreateBusMixFromValue_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x130A5F60]
        FName                       Name;                           // 0x000008 (0x000004) [Default: FName(49) -> L""]
        uint8                       UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        TArray<USoundControlBus*>   Buses;                          // 0x000010 (0x000010) [OutParam]
        float                       Value;                          // 0x000020 (0x000004) [Default: 4.11989e-31f]
        float                       AttackTime;                     // 0x000024 (0x000004) [Default: 0f]
        float                       ReleaseTime;                    // 0x000028 (0x000004) [Default: 1.74651e-27f]
        bool                        bActivate;                      // 0x00002C (0x000001) [Default: false]
        uint8                       UnknownData_00002D[0x000003];   // 0x00002D (0x000003)
        USoundControlBusMix*        ReturnValue;                    // 0x000030 (0x000008) [ReturnValue] [Default: 0xD42718DD00000031]
    };

    struct UAudioModulationStatics___CreateBusMixStage_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundControlBus*           Bus;                            // 0x000008 (0x000008) [Default: 0xD52718DD00000031]
        float                       Value;                          // 0x000010 (0x000004) [Default: 5.98853e-25f]
        float                       AttackTime;                     // 0x000014 (0x000004) [Default: 0f]
        float                       ReleaseTime;                    // 0x000018 (0x000004) [Default: 5.97613e-25f]
        uint8                       UnknownData_00001C[0x000004];   // 0x00001C (0x000004)
        FSoundControlBusMixStage    ReturnValue;                    // 0x000020 (0x000028) [ReturnValue]
    };

    struct UAudioModulationStatics___CreateEnvelopeFollowerGenerator_Params
    {
        UObject*                                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x130A5F60]
        FName                                       Name;                           // 0x000008 (0x000004) [Default: FName(49) -> L""]
        uint8                                       UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        FEnvelopeFollowerGeneratorParams            Params;                         // 0x000010 (0x000020)
        USoundModulationGeneratorEnvelopeFollower*  ReturnValue;                    // 0x000030 (0x000008) [ReturnValue] [Default: 0xD42718DD00000031]
    };

    struct UAudioModulationStatics___CreateLFOGenerator_Params
    {
        UObject*                        WorldContextObject;             // 0x000000 (0x000008) [Default: 0x130A5F60]
        FName                           Name;                           // 0x000008 (0x000004) [Default: FName(49) -> L""]
        FSoundModulationLFOParams       Params;                         // 0x00000C (0x000020)
        uint8                           UnknownData_00002C[0x000004];   // 0x00002C (0x000004)
        USoundModulationGeneratorLFO*   ReturnValue;                    // 0x000030 (0x000008) [ReturnValue] [Default: 0xD42718DD00000031]
    };

    struct UAudioModulationStatics___CreateModulationDestination_Params
    {
        UObject*                        WorldContextObject;             // 0x000000 (0x000008) [Default: 0x130A5F60]
        FName                           Name;                           // 0x000008 (0x000004) [Default: FName(49) -> L""]
        uint8                           UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        USoundModulatorBase*            Modulator;                      // 0x000010 (0x000008) [Default: 0x17395600]
        UAudioModulationDestination*    ReturnValue;                    // 0x000018 (0x000008) [ReturnValue] [Default: 0x1738F3C0]
    };

    struct UAudioModulationStatics___CreateModulationParameter_Params
    {
        UObject*                    WorldContextObject;             // 0x000000 (0x000008) [Default: 0x130A5F60]
        FName                       Name;                           // 0x000008 (0x000004) [Default: FName(49) -> L""]
        uint8                       UnknownData_00000C[0x000004];   // 0x00000C (0x000004)
        UClass*                     ParamClass;                     // 0x000010 (0x000008) [Default: 0x17395600]
        float                       DefaultValue;                   // 0x000018 (0x000004) [Default: 5.97613e-25f]
        uint8                       UnknownData_00001C[0x000004];   // 0x00001C (0x000004)
        USoundModulationParameter*  ReturnValue;                    // 0x000020 (0x000008) [ReturnValue] [Default: 0xD05B2BB]
    };

    struct UAudioModulationStatics___DeactivateAllBusMixes_Params
    {
        UObject*    WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
    };

    struct UAudioModulationStatics___DeactivateBus_Params
    {
        UObject*            WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundControlBus*   Bus;                // 0x000008 (0x000008) [Default: 0xD52718DD00000031]
    };

    struct UAudioModulationStatics___DeactivateBusMix_Params
    {
        UObject*                WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundControlBusMix*    Mix;                // 0x000008 (0x000008) [Default: 0xD52718DD00000031]
    };

    struct UAudioModulationStatics___DeactivateGenerator_Params
    {
        UObject*                    WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundModulationGenerator*  Generator;          // 0x000008 (0x000008) [Default: 0xD52718DD00000031]
    };

    struct UAudioModulationStatics___GetModulatorsFromDestination_Params
    {
        FSoundModulationDestinationSettings Destination;    // 0x000000 (0x000018) [OutParam]
        TSet<USoundModulatorBase*>          ReturnValue;    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UAudioModulationStatics___GetModulatorValue_Params
    {
        UObject*                WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundModulatorBase*    Modulator;          // 0x000008 (0x000008) [Default: 0xD52718DD00000031]
        float                   ReturnValue;        // 0x000010 (0x000004) [ReturnValue] [Default: 5.98853e-25f]
    };

    struct UAudioModulationStatics___IsControlBusMixActive_Params
    {
        UObject*                WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundControlBusMix*    Mix;                // 0x000008 (0x000008) [Default: 0xD52718DD00000031]
        bool                    ReturnValue;        // 0x000010 (0x000001) [ReturnValue] [Default: false]
    };

    struct UAudioModulationStatics___LoadMixFromProfile_Params
    {
        UObject*                            WorldContextObject;             // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundControlBusMix*                Mix;                            // 0x000008 (0x000008) [Default: 0xD52718DD00000031]
        bool                                bActivate;                      // 0x000010 (0x000001) [Default: false]
        uint8                               UnknownData_000011[0x000003];   // 0x000011 (0x000003)
        int32                               ProfileIndex;                   // 0x000014 (0x000004) [Default: 0]
        TArray<FSoundControlBusMixStage>    ReturnValue;                    // 0x000018 (0x000010) [ReturnValue]
    };

    struct UAudioModulationStatics___SaveMixToProfile_Params
    {
        UObject*                WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundControlBusMix*    Mix;                // 0x000008 (0x000008) [Default: 0xD52718DD00000031]
        int32                   ProfileIndex;       // 0x000010 (0x000004) [Default: 389633536]
    };

    struct UAudioModulationStatics___SetGlobalBusMixValue_Params
    {
        UObject*            WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundControlBus*   Bus;                // 0x000008 (0x000008) [Default: 0xD52718DD00000031]
        float               Value;              // 0x000010 (0x000004) [Default: 5.98853e-25f]
        float               FadeTime;           // 0x000014 (0x000004) [Default: 0f]
    };

    struct UAudioModulationStatics___UpdateMix_Params
    {
        UObject*                            WorldContextObject;             // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundControlBusMix*                Mix;                            // 0x000008 (0x000008) [Default: 0xD52718DD00000031]
        TArray<FSoundControlBusMixStage>    Stages;                         // 0x000010 (0x000010)
        float                               FadeTime;                       // 0x000020 (0x000004) [Default: 4.11989e-31f]
        uint8                               UnknownData_000024[0x000004];   // 0x000024 (0x000004)
        double                              duration;                       // 0x000028 (0x000008) [Default: 1.57828e-315]
        bool                                bRetriggerOnActivation;         // 0x000030 (0x000001) [Default: true]
    };

    struct UAudioModulationStatics___UpdateMixByFilter_Params
    {
        UObject*                    WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundControlBusMix*        Mix;                // 0x000008 (0x000008) [Default: 0xD52718DD00000031]
        FString                     AddressFilter;      // 0x000010 (0x000010) [Default: L""]
        UClass*                     ParamClassFilter;   // 0x000020 (0x000008) [Default: 0xD05B2BB]
        USoundModulationParameter*  ParamFilter;        // 0x000028 (0x000008) [Default: 0x130A5F60]
        float                       Value;              // 0x000030 (0x000004) [Default: 6.86636e-44f]
        float                       FadeTime;           // 0x000034 (0x000004) [Default: -2.87071e+12f]
    };

    struct UAudioModulationStatics___UpdateMixFromObject_Params
    {
        UObject*                WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundControlBusMix*    Mix;                // 0x000008 (0x000008) [Default: 0xD52718DD00000031]
        float                   FadeTime;           // 0x000010 (0x000004) [Default: 5.98853e-25f]
    };

    struct UAudioModulationStatics___UpdateModulator_Params
    {
        UObject*                WorldContextObject; // 0x000000 (0x000008) [Default: 0x130A5F60]
        USoundModulatorBase*    Modulator;          // 0x000008 (0x000008) [Default: 0xD52718DD00000031]
    };

    struct UAudioModulationStyle___GetControlBusColor_Params
    {
        FColor  ReturnValue;    // 0x000000 (0x000004) [ReturnValue]
    };

    struct UAudioModulationStyle___GetControlBusMixColor_Params
    {
        FColor  ReturnValue;    // 0x000000 (0x000004) [ReturnValue]
    };

    struct UAudioModulationStyle___GetModulationGeneratorColor_Params
    {
        FColor  ReturnValue;    // 0x000000 (0x000004) [ReturnValue]
    };

    struct UAudioModulationStyle___GetParameterColor_Params
    {
        FColor  ReturnValue;    // 0x000000 (0x000004) [ReturnValue]
    };

    struct UAudioModulationStyle___GetPatchColor_Params
    {
        FColor  ReturnValue;    // 0x000000 (0x000004) [ReturnValue]
    };

} // namespace UE

